// Formatting for DATE-ONLY database values ("2026-08-01" — Postgres `date`
// columns: night_date, check_in/check_out, event start_date...).
//
// `new Date("2026-08-01")` is parsed as UTC midnight, but toLocaleDateString /
// getDate() then render it in the BROWSER's timezone — a viewer west of UTC
// (e.g. a participant checking from the US) sees the previous day. Same class
// of bug as the hotel check-in shift fixed in 2026-07: render date-only values
// in UTC so the calendar date shown is always the calendar date stored.
//
// Not for real MOMENTS — when an email arrived, when a consolidation ran,
// when somebody edited a field. Those should render in the viewer's own
// timezone, and do.
//
// Flight and pickup times are neither: see formatScheduleTime below. This
// comment used to name them as moments, which is exactly the reasoning that
// put a flight leaving Frankfurt at 12:00 on screen as 14:00.

const DATE_ONLY = /^\d{4}-\d{2}-\d{2}$/

/**
 * Formatting for SCHEDULE times — a flight's departure, a shuttle's pickup,
 * an activity's start.
 *
 * These are wall clocks at a place, not instants to be re-expressed. FCM
 * writes "12:00" for a Frankfurt departure because that is what the boarding
 * pass says; the import stores that clock face verbatim, tagged UTC. Asking
 * the browser to render it "locally" adds the reader's own offset on top, so
 * an organizer in Brussels read 14:00 for a flight that leaves at 12:00 —
 * while the master list, rendered by the API, still said 12:00. Two screens,
 * one flight, two times.
 *
 * Same reasoning as formatDateOnly above, and the same fix: pin the zone so
 * the stored clock face is the one that reaches the reader.
 */
export function formatScheduleTime(
  value: string | null | undefined,
  localeTag: string = 'fr-FR',
  options: Intl.DateTimeFormatOptions = { dateStyle: 'short', timeStyle: 'short' },
): string {
  if (!value) return ''
  const d = new Date(value)
  if (isNaN(d.getTime())) return String(value)
  return d.toLocaleString(localeTag, { ...options, timeZone: 'UTC' })
}

/**
 * The BCP-47 tag for a UI locale.
 *
 * This ternary was written inline in eight files and forgotten in five more,
 * where dates were formatted 'fr-BE' whatever language the reader had picked.
 * One place, so the next screen cannot get it wrong.
 */
export function localeTag(locale: string): string {
  return locale === 'nl' ? 'nl-NL' : locale === 'en' ? 'en-US' : 'fr-FR'
}

export function formatDateOnly(
  value: string,
  localeTag: string = 'fr-FR',
  options: Intl.DateTimeFormatOptions = { day: '2-digit', month: '2-digit', year: 'numeric' },
): string {
  const iso = DATE_ONLY.test(value) ? `${value}T00:00:00Z` : value
  const d = new Date(iso)
  if (isNaN(d.getTime())) return value
  return d.toLocaleDateString(localeTag, { ...options, timeZone: 'UTC' })
}
