'use client'

import { useState } from 'react'

/**
 * Drag-to-reorder for a list, with the keyboard as a first-class path.
 *
 * Three lists in this product are arranged by hand — the form's questions, the
 * mini-site's sections, and an event's own questions — and each of them wants
 * the same behaviour: pick a row up, drop it somewhere else, and have the row
 * you are dragging over say so. Writing that three times is how the three
 * quietly stop behaving the same way.
 *
 * Two decisions are baked in rather than left to the caller:
 *
 * **The grip takes the arrow keys.** A list that can only be reordered by
 * dragging cannot be reordered by a keyboard at all, and one of these lists has
 * forty-six rows. So the handle is focusable and ArrowUp/ArrowDown move the row
 * — one control, both ways in.
 *
 * **A move is a splice, not a swap.** Dropping a row seven places up should put
 * it there and push everything else down, which is what a splice does. For the
 * adjacent case the arrow keys produce, the two are identical, so both paths
 * can share one implementation without the keyboard behaving oddly.
 *
 * `blocked` lets a caller refuse a drop it cannot draw — the questions list is
 * rendered in groups, and a row dropped into another group's rows would simply
 * reappear where it started, which reads as a bug rather than as a rule.
 */
export function useReorder(
  count: number,
  move: (from: number, to: number) => void,
  blocked?: (from: number, to: number) => boolean,
) {
  const [dragging, setDragging] = useState<number | null>(null)
  const [over, setOver] = useState<number | null>(null)

  const allowed = (from: number, to: number) =>
    from !== to && to >= 0 && to < count && !(blocked?.(from, to) ?? false)

  return {
    /** The row being carried, so the caller can fade it. */
    dragging,
    /** The row under the cursor, so the caller can mark the landing spot. */
    over,

    /** Spread onto each row: it is the drop target. */
    rowProps: (index: number) => ({
      onDragOver: (event: React.DragEvent) => {
        if (dragging === null || !allowed(dragging, index)) return
        // Without preventDefault the browser refuses the drop entirely, which
        // is also how a blocked drop is expressed: simply not calling it.
        event.preventDefault()
        setOver(index)
      },
      onDragLeave: () => setOver((current) => (current === index ? null : current)),
      onDrop: (event: React.DragEvent) => {
        event.preventDefault()
        const from = dragging
        setDragging(null)
        setOver(null)
        if (from !== null && allowed(from, index)) move(from, index)
      },
    }),

    /** Spread onto the grip: what you pick up, and what the arrows act on. */
    handleProps: (index: number) => ({
      draggable: true,
      onDragStart: (event: React.DragEvent) => {
        event.dataTransfer.effectAllowed = 'move'
        // Firefox starts no drag at all unless some data is set.
        event.dataTransfer.setData('text/plain', String(index))
        setDragging(index)
      },
      onDragEnd: () => { setDragging(null); setOver(null) },
      onKeyDown: (event: React.KeyboardEvent) => {
        const to = event.key === 'ArrowUp' ? index - 1
          : event.key === 'ArrowDown' ? index + 1
          : null
        if (to === null) return
        event.preventDefault()
        if (allowed(index, to)) move(index, to)
      },
    }),
  }
}

/** `move(from, to)` over any array: lift the row out, put it back at `to`. */
export function reordered<T>(items: T[], from: number, to: number): T[] {
  if (from === to || from < 0 || to < 0 || from >= items.length || to >= items.length) return items
  const next = [...items]
  const [moved] = next.splice(from, 1)
  next.splice(to, 0, moved)
  return next
}
