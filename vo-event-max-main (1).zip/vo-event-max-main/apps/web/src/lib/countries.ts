/**
 * Country reference data, used by the public registration form for the
 * nationality autocomplete and the mandatory phone country-code selector.
 *
 * Two names are stored, not one:
 *
 *   `name` — French, the language the list was written in.
 *   `en`   — English, and the ONLY value this app ever writes to the
 *            database. It is frozen here rather than read from
 *            `Intl.DisplayNames` at runtime, because ICU renames countries
 *            between versions: "Czech Republic" became "Czechia", "Turkey"
 *            became "Türkiye", "Congo (Kinshasa)" became "Congo - Kinshasa".
 *            Deriving it in the browser would mean two participants on two
 *            browser versions storing two different strings for one country
 *            — which is the very split this exists to prevent.
 *
 * Dutch, and any other reading language, come from `Intl.DisplayNames`: a
 * label that shifts wording between browsers is harmless, a stored value is
 * not.
 */
export interface Country {
  name: string
  en: string
  iso2: string
  dialCode: string
}

export const COUNTRIES: Country[] = [
  { name: 'Afghanistan', en: 'Afghanistan', iso2: 'AF', dialCode: '+93' },
  { name: 'Afrique du Sud', en: 'South Africa', iso2: 'ZA', dialCode: '+27' },
  { name: 'Albanie', en: 'Albania', iso2: 'AL', dialCode: '+355' },
  { name: 'Algérie', en: 'Algeria', iso2: 'DZ', dialCode: '+213' },
  { name: 'Allemagne', en: 'Germany', iso2: 'DE', dialCode: '+49' },
  { name: 'Andorre', en: 'Andorra', iso2: 'AD', dialCode: '+376' },
  { name: 'Angola', en: 'Angola', iso2: 'AO', dialCode: '+244' },
  { name: 'Arabie Saoudite', en: 'Saudi Arabia', iso2: 'SA', dialCode: '+966' },
  { name: 'Argentine', en: 'Argentina', iso2: 'AR', dialCode: '+54' },
  { name: 'Arménie', en: 'Armenia', iso2: 'AM', dialCode: '+374' },
  { name: 'Australie', en: 'Australia', iso2: 'AU', dialCode: '+61' },
  { name: 'Autriche', en: 'Austria', iso2: 'AT', dialCode: '+43' },
  { name: 'Azerbaïdjan', en: 'Azerbaijan', iso2: 'AZ', dialCode: '+994' },
  { name: 'Bahreïn', en: 'Bahrain', iso2: 'BH', dialCode: '+973' },
  { name: 'Bangladesh', en: 'Bangladesh', iso2: 'BD', dialCode: '+880' },
  { name: 'Belgique', en: 'Belgium', iso2: 'BE', dialCode: '+32' },
  { name: 'Bénin', en: 'Benin', iso2: 'BJ', dialCode: '+229' },
  { name: 'Biélorussie', en: 'Belarus', iso2: 'BY', dialCode: '+375' },
  { name: 'Birmanie (Myanmar)', en: 'Myanmar', iso2: 'MM', dialCode: '+95' },
  { name: 'Bolivie', en: 'Bolivia', iso2: 'BO', dialCode: '+591' },
  { name: 'Bosnie-Herzégovine', en: 'Bosnia and Herzegovina', iso2: 'BA', dialCode: '+387' },
  { name: 'Botswana', en: 'Botswana', iso2: 'BW', dialCode: '+267' },
  { name: 'Brésil', en: 'Brazil', iso2: 'BR', dialCode: '+55' },
  { name: 'Brunei', en: 'Brunei', iso2: 'BN', dialCode: '+673' },
  { name: 'Bulgarie', en: 'Bulgaria', iso2: 'BG', dialCode: '+359' },
  { name: 'Burkina Faso', en: 'Burkina Faso', iso2: 'BF', dialCode: '+226' },
  { name: 'Burundi', en: 'Burundi', iso2: 'BI', dialCode: '+257' },
  { name: 'Cambodge', en: 'Cambodia', iso2: 'KH', dialCode: '+855' },
  { name: 'Cameroun', en: 'Cameroon', iso2: 'CM', dialCode: '+237' },
  { name: 'Canada', en: 'Canada', iso2: 'CA', dialCode: '+1' },
  { name: 'Cap-Vert', en: 'Cape Verde', iso2: 'CV', dialCode: '+238' },
  { name: 'Chili', en: 'Chile', iso2: 'CL', dialCode: '+56' },
  { name: 'Chine', en: 'China', iso2: 'CN', dialCode: '+86' },
  { name: 'Chypre', en: 'Cyprus', iso2: 'CY', dialCode: '+357' },
  { name: 'Colombie', en: 'Colombia', iso2: 'CO', dialCode: '+57' },
  { name: 'Comores', en: 'Comoros', iso2: 'KM', dialCode: '+269' },
  { name: 'Congo (Brazzaville)', en: 'Congo (Brazzaville)', iso2: 'CG', dialCode: '+242' },
  { name: 'Congo (RDC)', en: 'Congo (Kinshasa)', iso2: 'CD', dialCode: '+243' },
  { name: 'Corée du Nord', en: 'North Korea', iso2: 'KP', dialCode: '+850' },
  { name: 'Corée du Sud', en: 'South Korea', iso2: 'KR', dialCode: '+82' },
  { name: 'Costa Rica', en: 'Costa Rica', iso2: 'CR', dialCode: '+506' },
  { name: 'Côte d\'Ivoire', en: 'Côte d’Ivoire', iso2: 'CI', dialCode: '+225' },
  { name: 'Croatie', en: 'Croatia', iso2: 'HR', dialCode: '+385' },
  { name: 'Cuba', en: 'Cuba', iso2: 'CU', dialCode: '+53' },
  { name: 'Danemark', en: 'Denmark', iso2: 'DK', dialCode: '+45' },
  { name: 'Djibouti', en: 'Djibouti', iso2: 'DJ', dialCode: '+253' },
  { name: 'Égypte', en: 'Egypt', iso2: 'EG', dialCode: '+20' },
  { name: 'Émirats Arabes Unis', en: 'United Arab Emirates', iso2: 'AE', dialCode: '+971' },
  { name: 'Équateur', en: 'Ecuador', iso2: 'EC', dialCode: '+593' },
  { name: 'Érythrée', en: 'Eritrea', iso2: 'ER', dialCode: '+291' },
  { name: 'Espagne', en: 'Spain', iso2: 'ES', dialCode: '+34' },
  { name: 'Estonie', en: 'Estonia', iso2: 'EE', dialCode: '+372' },
  { name: 'Eswatini', en: 'Eswatini', iso2: 'SZ', dialCode: '+268' },
  { name: 'États-Unis', en: 'United States', iso2: 'US', dialCode: '+1' },
  { name: 'Éthiopie', en: 'Ethiopia', iso2: 'ET', dialCode: '+251' },
  { name: 'Fidji', en: 'Fiji', iso2: 'FJ', dialCode: '+679' },
  { name: 'Finlande', en: 'Finland', iso2: 'FI', dialCode: '+358' },
  { name: 'France', en: 'France', iso2: 'FR', dialCode: '+33' },
  { name: 'Gabon', en: 'Gabon', iso2: 'GA', dialCode: '+241' },
  { name: 'Gambie', en: 'Gambia', iso2: 'GM', dialCode: '+220' },
  { name: 'Géorgie', en: 'Georgia', iso2: 'GE', dialCode: '+995' },
  { name: 'Ghana', en: 'Ghana', iso2: 'GH', dialCode: '+233' },
  { name: 'Grèce', en: 'Greece', iso2: 'GR', dialCode: '+30' },
  { name: 'Guatemala', en: 'Guatemala', iso2: 'GT', dialCode: '+502' },
  { name: 'Guinée', en: 'Guinea', iso2: 'GN', dialCode: '+224' },
  { name: 'Guinée équatoriale', en: 'Equatorial Guinea', iso2: 'GQ', dialCode: '+240' },
  { name: 'Guinée-Bissau', en: 'Guinea-Bissau', iso2: 'GW', dialCode: '+245' },
  { name: 'Haïti', en: 'Haiti', iso2: 'HT', dialCode: '+509' },
  { name: 'Honduras', en: 'Honduras', iso2: 'HN', dialCode: '+504' },
  { name: 'Hongrie', en: 'Hungary', iso2: 'HU', dialCode: '+36' },
  { name: 'Inde', en: 'India', iso2: 'IN', dialCode: '+91' },
  { name: 'Indonésie', en: 'Indonesia', iso2: 'ID', dialCode: '+62' },
  { name: 'Irak', en: 'Iraq', iso2: 'IQ', dialCode: '+964' },
  { name: 'Iran', en: 'Iran', iso2: 'IR', dialCode: '+98' },
  { name: 'Irlande', en: 'Ireland', iso2: 'IE', dialCode: '+353' },
  { name: 'Islande', en: 'Iceland', iso2: 'IS', dialCode: '+354' },
  { name: 'Israël', en: 'Israel', iso2: 'IL', dialCode: '+972' },
  { name: 'Italie', en: 'Italy', iso2: 'IT', dialCode: '+39' },
  { name: 'Jamaïque', en: 'Jamaica', iso2: 'JM', dialCode: '+1876' },
  { name: 'Japon', en: 'Japan', iso2: 'JP', dialCode: '+81' },
  { name: 'Jordanie', en: 'Jordan', iso2: 'JO', dialCode: '+962' },
  { name: 'Kazakhstan', en: 'Kazakhstan', iso2: 'KZ', dialCode: '+7' },
  { name: 'Kenya', en: 'Kenya', iso2: 'KE', dialCode: '+254' },
  { name: 'Kirghizistan', en: 'Kyrgyzstan', iso2: 'KG', dialCode: '+996' },
  { name: 'Kosovo', en: 'Kosovo', iso2: 'XK', dialCode: '+383' },
  { name: 'Koweït', en: 'Kuwait', iso2: 'KW', dialCode: '+965' },
  { name: 'Laos', en: 'Laos', iso2: 'LA', dialCode: '+856' },
  { name: 'Lesotho', en: 'Lesotho', iso2: 'LS', dialCode: '+266' },
  { name: 'Lettonie', en: 'Latvia', iso2: 'LV', dialCode: '+371' },
  { name: 'Liban', en: 'Lebanon', iso2: 'LB', dialCode: '+961' },
  { name: 'Liberia', en: 'Liberia', iso2: 'LR', dialCode: '+231' },
  { name: 'Libye', en: 'Libya', iso2: 'LY', dialCode: '+218' },
  { name: 'Liechtenstein', en: 'Liechtenstein', iso2: 'LI', dialCode: '+423' },
  { name: 'Lituanie', en: 'Lithuania', iso2: 'LT', dialCode: '+370' },
  { name: 'Luxembourg', en: 'Luxembourg', iso2: 'LU', dialCode: '+352' },
  { name: 'Macédoine du Nord', en: 'North Macedonia', iso2: 'MK', dialCode: '+389' },
  { name: 'Madagascar', en: 'Madagascar', iso2: 'MG', dialCode: '+261' },
  { name: 'Malaisie', en: 'Malaysia', iso2: 'MY', dialCode: '+60' },
  { name: 'Malawi', en: 'Malawi', iso2: 'MW', dialCode: '+265' },
  { name: 'Maldives', en: 'Maldives', iso2: 'MV', dialCode: '+960' },
  { name: 'Mali', en: 'Mali', iso2: 'ML', dialCode: '+223' },
  { name: 'Malte', en: 'Malta', iso2: 'MT', dialCode: '+356' },
  { name: 'Maroc', en: 'Morocco', iso2: 'MA', dialCode: '+212' },
  { name: 'Maurice', en: 'Mauritius', iso2: 'MU', dialCode: '+230' },
  { name: 'Mauritanie', en: 'Mauritania', iso2: 'MR', dialCode: '+222' },
  { name: 'Mexique', en: 'Mexico', iso2: 'MX', dialCode: '+52' },
  { name: 'Moldavie', en: 'Moldova', iso2: 'MD', dialCode: '+373' },
  { name: 'Monaco', en: 'Monaco', iso2: 'MC', dialCode: '+377' },
  { name: 'Mongolie', en: 'Mongolia', iso2: 'MN', dialCode: '+976' },
  { name: 'Monténégro', en: 'Montenegro', iso2: 'ME', dialCode: '+382' },
  { name: 'Mozambique', en: 'Mozambique', iso2: 'MZ', dialCode: '+258' },
  { name: 'Namibie', en: 'Namibia', iso2: 'NA', dialCode: '+264' },
  { name: 'Népal', en: 'Nepal', iso2: 'NP', dialCode: '+977' },
  { name: 'Nicaragua', en: 'Nicaragua', iso2: 'NI', dialCode: '+505' },
  { name: 'Niger', en: 'Niger', iso2: 'NE', dialCode: '+227' },
  { name: 'Nigeria', en: 'Nigeria', iso2: 'NG', dialCode: '+234' },
  { name: 'Norvège', en: 'Norway', iso2: 'NO', dialCode: '+47' },
  { name: 'Nouvelle-Zélande', en: 'New Zealand', iso2: 'NZ', dialCode: '+64' },
  { name: 'Oman', en: 'Oman', iso2: 'OM', dialCode: '+968' },
  { name: 'Ouganda', en: 'Uganda', iso2: 'UG', dialCode: '+256' },
  { name: 'Ouzbékistan', en: 'Uzbekistan', iso2: 'UZ', dialCode: '+998' },
  { name: 'Pakistan', en: 'Pakistan', iso2: 'PK', dialCode: '+92' },
  { name: 'Panama', en: 'Panama', iso2: 'PA', dialCode: '+507' },
  { name: 'Papouasie-Nouvelle-Guinée', en: 'Papua New Guinea', iso2: 'PG', dialCode: '+675' },
  { name: 'Paraguay', en: 'Paraguay', iso2: 'PY', dialCode: '+595' },
  { name: 'Pays-Bas', en: 'Netherlands', iso2: 'NL', dialCode: '+31' },
  { name: 'Pérou', en: 'Peru', iso2: 'PE', dialCode: '+51' },
  { name: 'Philippines', en: 'Philippines', iso2: 'PH', dialCode: '+63' },
  { name: 'Pologne', en: 'Poland', iso2: 'PL', dialCode: '+48' },
  { name: 'Portugal', en: 'Portugal', iso2: 'PT', dialCode: '+351' },
  { name: 'Qatar', en: 'Qatar', iso2: 'QA', dialCode: '+974' },
  { name: 'République Centrafricaine', en: 'Central African Republic', iso2: 'CF', dialCode: '+236' },
  { name: 'République Dominicaine', en: 'Dominican Republic', iso2: 'DO', dialCode: '+1809' },
  { name: 'République Tchèque', en: 'Czechia', iso2: 'CZ', dialCode: '+420' },
  { name: 'Roumanie', en: 'Romania', iso2: 'RO', dialCode: '+40' },
  { name: 'Royaume-Uni', en: 'United Kingdom', iso2: 'GB', dialCode: '+44' },
  { name: 'Russie', en: 'Russia', iso2: 'RU', dialCode: '+7' },
  { name: 'Rwanda', en: 'Rwanda', iso2: 'RW', dialCode: '+250' },
  { name: 'Salvador', en: 'El Salvador', iso2: 'SV', dialCode: '+503' },
  { name: 'Samoa', en: 'Samoa', iso2: 'WS', dialCode: '+685' },
  { name: 'Sénégal', en: 'Senegal', iso2: 'SN', dialCode: '+221' },
  { name: 'Serbie', en: 'Serbia', iso2: 'RS', dialCode: '+381' },
  { name: 'Seychelles', en: 'Seychelles', iso2: 'SC', dialCode: '+248' },
  { name: 'Sierra Leone', en: 'Sierra Leone', iso2: 'SL', dialCode: '+232' },
  { name: 'Singapour', en: 'Singapore', iso2: 'SG', dialCode: '+65' },
  { name: 'Slovaquie', en: 'Slovakia', iso2: 'SK', dialCode: '+421' },
  { name: 'Slovénie', en: 'Slovenia', iso2: 'SI', dialCode: '+386' },
  { name: 'Somalie', en: 'Somalia', iso2: 'SO', dialCode: '+252' },
  { name: 'Soudan', en: 'Sudan', iso2: 'SD', dialCode: '+249' },
  { name: 'Soudan du Sud', en: 'South Sudan', iso2: 'SS', dialCode: '+211' },
  { name: 'Sri Lanka', en: 'Sri Lanka', iso2: 'LK', dialCode: '+94' },
  { name: 'Suède', en: 'Sweden', iso2: 'SE', dialCode: '+46' },
  { name: 'Suisse', en: 'Switzerland', iso2: 'CH', dialCode: '+41' },
  { name: 'Suriname', en: 'Suriname', iso2: 'SR', dialCode: '+597' },
  { name: 'Syrie', en: 'Syria', iso2: 'SY', dialCode: '+963' },
  { name: 'Tadjikistan', en: 'Tajikistan', iso2: 'TJ', dialCode: '+992' },
  { name: 'Tanzanie', en: 'Tanzania', iso2: 'TZ', dialCode: '+255' },
  { name: 'Tchad', en: 'Chad', iso2: 'TD', dialCode: '+235' },
  { name: 'Thaïlande', en: 'Thailand', iso2: 'TH', dialCode: '+66' },
  { name: 'Timor Oriental', en: 'Timor-Leste', iso2: 'TL', dialCode: '+670' },
  { name: 'Togo', en: 'Togo', iso2: 'TG', dialCode: '+228' },
  { name: 'Tonga', en: 'Tonga', iso2: 'TO', dialCode: '+676' },
  { name: 'Trinité-et-Tobago', en: 'Trinidad and Tobago', iso2: 'TT', dialCode: '+1868' },
  { name: 'Tunisie', en: 'Tunisia', iso2: 'TN', dialCode: '+216' },
  { name: 'Turkménistan', en: 'Turkmenistan', iso2: 'TM', dialCode: '+993' },
  { name: 'Turquie', en: 'Türkiye', iso2: 'TR', dialCode: '+90' },
  { name: 'Ukraine', en: 'Ukraine', iso2: 'UA', dialCode: '+380' },
  { name: 'Uruguay', en: 'Uruguay', iso2: 'UY', dialCode: '+598' },
  { name: 'Vanuatu', en: 'Vanuatu', iso2: 'VU', dialCode: '+678' },
  { name: 'Vatican', en: 'Vatican City', iso2: 'VA', dialCode: '+379' },
  { name: 'Venezuela', en: 'Venezuela', iso2: 'VE', dialCode: '+58' },
  { name: 'Vietnam', en: 'Vietnam', iso2: 'VN', dialCode: '+84' },
  { name: 'Yémen', en: 'Yemen', iso2: 'YE', dialCode: '+967' },
  { name: 'Zambie', en: 'Zambia', iso2: 'ZM', dialCode: '+260' },
  { name: 'Zimbabwe', en: 'Zimbabwe', iso2: 'ZW', dialCode: '+263' },
]

function normalize(s: string): string {
  return s
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .trim()
}

/** Cheap Levenshtein distance — good enough for short country names, no dependency needed. */
function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length
  if (m === 0) return n
  if (n === 0) return m
  const dp: number[] = Array.from({ length: n + 1 }, (_, j) => j)
  for (let i = 1; i <= m; i++) {
    let prev = dp[0]
    dp[0] = i
    for (let j = 1; j <= n; j++) {
      const tmp = dp[j]
      dp[j] = a[i - 1] === b[j - 1] ? prev : 1 + Math.min(prev, dp[j], dp[j - 1])
      prev = tmp
    }
  }
  return dp[n]
}

/**
 * The country's name in the reader's language.
 *
 * The table above is the French reference — it is what the list was written
 * in, and what a French participant still sees. Every other language comes
 * from the ISO code via `Intl.DisplayNames`, which every browser we support
 * ships. If it is unavailable, or does not know the code, the French name is
 * returned rather than nothing.
 */
const NAMES_BY_LANG = new Map<string, Intl.DisplayNames | null>()

export function countryLabel(country: Country, lang: string): string {
  if (!lang || lang === 'fr') return country.name
  // English comes from the table, not from ICU: it is the value this app
  // stores, and a reader in English must see exactly what is in the column.
  // ICU would say "Myanmar (Burma)" where the column says "Myanmar".
  if (lang === 'en') return country.en
  if (!NAMES_BY_LANG.has(lang)) {
    try {
      NAMES_BY_LANG.set(lang, new Intl.DisplayNames([lang], { type: 'region' }))
    } catch {
      NAMES_BY_LANG.set(lang, null)
    }
  }
  const names = NAMES_BY_LANG.get(lang)
  if (!names) return country.name
  try {
    return names.of(country.iso2) || country.name
  } catch {
    return country.name
  }
}

/** Every spelling we can recognise -> the country, built once. */
const BY_NAME: Map<string, Country> = (() => {
  const index = new Map<string, Country>()
  for (const country of COUNTRIES) {
    index.set(normalize(country.name), country)
    index.set(normalize(country.en), country)
    index.set(normalize(country.iso2), country)
    for (const lang of ['nl', 'en', 'fr']) {
      const label = countryLabel(country, lang)
      if (label) index.set(normalize(label), country)
    }
  }
  return index
})()

/**
 * What to WRITE: the country's English name, whatever language it was typed
 * in — French, Dutch, English, or its ISO code.
 *
 * Returns null when the text matches no country. The caller keeps what the
 * participant actually wrote in that case: a nationality this table has never
 * heard of ("Kosovar", a dual nationality, a typo) is worth storing verbatim,
 * and is never worth losing.
 */
export function toEnglishCountry(text: string): string | null {
  const hit = BY_NAME.get(normalize(text || ''))
  return hit ? hit.en : null
}

/**
 * What to SHOW: a stored value in the reader's language.
 *
 * Deliberately tolerant of what is already in the column. Rows written before
 * this change hold French names, and they resolve here exactly as English
 * ones do — so a French organizer keeps reading "Belgique" whether the row
 * was written last year or this morning, with no migration in between.
 */
export function displayCountry(stored: string | null | undefined, lang: string): string {
  if (!stored) return ''
  const hit = BY_NAME.get(normalize(stored))
  return hit ? countryLabel(hit, lang) : stored
}

/**
 * Country name suggestions "closest to" the query: exact/prefix/substring
 * matches first (handles normal typing), falling back to edit-distance when
 * nothing contains the query at all (handles typos like "Belgik").
 *
 * Both names are matched — the French one and the reader's — so somebody
 * typing "Belgie" on a Dutch form finds Belgium, and somebody who typed
 * "Belgique" into a Dutch form still does.
 */
export function suggestCountries(query: string, lang = 'fr', limit = 8): Country[] {
  const q = normalize(query)
  if (!q) return COUNTRIES.slice(0, limit)

  const rank = (name: string): number => {
    const n = normalize(name)
    if (n === q) return 100
    if (n.startsWith(q)) return 90
    if (n.includes(q)) return 70
    if (n.split(/[\s'-]+/).some((w) => w.startsWith(q))) return 60
    return 0
  }

  const scored = COUNTRIES.map((c) => ({
    c,
    score: Math.max(rank(c.name), rank(countryLabel(c, lang))),
  }))

  const direct = scored.filter((s) => s.score > 0).sort((a, b) => b.score - a.score)
  if (direct.length > 0) return direct.slice(0, limit).map((s) => s.c)

  // Nothing matched directly (likely a typo) — rank by edit distance instead.
  return COUNTRIES
    .map((c) => ({
      c,
      dist: Math.min(
        levenshtein(q, normalize(c.name).slice(0, q.length + 3)),
        levenshtein(q, normalize(countryLabel(c, lang)).slice(0, q.length + 3)),
      ),
    }))
    .sort((a, b) => a.dist - b.dist)
    .slice(0, limit)
    .map((s) => s.c)
}
