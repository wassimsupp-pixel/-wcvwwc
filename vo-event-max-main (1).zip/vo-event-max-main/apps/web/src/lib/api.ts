/**
 * API client for VO Event Max backend.
 * All endpoints target NEXT_PUBLIC_API_URL (Railway deployment).
 */

import type { RegistrationTheme } from '@/lib/registrationTheme'

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'https://vo-event-max-api-production.up.railway.app'

// ─── Types ────────────────────────────────────────────────────────────────────

export type ParticipantStatus = 'complete' | 'incomplete' | 'conflict'
export type ConfidenceLevel = 'certain' | 'probable' | 'to_verify' | 'not_found'

export interface Participant {
  id: string
  event_id: string
  first_name: string
  last_name: string
  email: string
  company?: string
  phone?: string
  nationality?: string
  dietary_requirements?: string
  completeness_status: ParticipantStatus
  confidence: ConfidenceLevel
  has_flight: boolean
  has_hotel: boolean
  has_transfer: boolean
  has_activities: boolean
  locked_fields: string[]
  sources: string[]
  match_score?: number
  // A personal extension at the registrant's own expense (§3) — their own
  // words from the form, absent entirely on a deployment without migration
  // 022 rather than present-but-empty.
  extension_requested?: string
  extension_start?: string
  extension_end?: string
  extension_hotel?: string
  created_at: string
  updated_at: string
}

export interface ProjectMember {
  id: string
  user_id: string
  access_level: 'viewer' | 'editor'
  event_ids: string[] | null
  email?: string
  full_name?: string
  user_role?: string
  created_at?: string
}

export interface ParticipantLookupItem {
  id: string
  first_name: string
  last_name: string
  completeness_status: string
}

export interface ParticipantListParams {
  page?: number
  page_size?: number
  search?: string
  status?: ParticipantStatus
  confidence?: ConfidenceLevel
  has_flight?: boolean
  has_hotel?: boolean
  has_transfer?: boolean
}

export interface PaginatedParticipants {
  items: Participant[]
  total: number
  page: number
  page_size: number
  total_pages: number
}

export interface ParticipantFieldUpdate {
  field: string
  value: string | null
  reason: string
  lock?: boolean
}

export interface ColumnMappingSuggestion {
  suggested_field: string | null
  confidence: number
  alternatives: string[]
}

export interface FileUploadResponse {
  file_id: string
  filename: string
  row_count: number
  columns: string[]
  uploaded_at: string
  import_status?: string
  mapping_suggestions: Record<string, ColumnMappingSuggestion>
  canonical_fields: string[]
  /** Points 5+6: true when this project has already confirmed a mapping for
   *  a layout shaped exactly like this one — the mapping shown is a
   *  remembered answer to verify, not a fresh guess to build from scratch. */
  remembered?: boolean
}

export interface MappingReportEntry {
  field: string | null
  confidence: number
  source: 'heuristic' | 'ai' | 'custom'
  needs_split: boolean
}

export interface FilePreviewResponse {
  columns: string[]
  rows: Record<string, string>[]
  total_rows: number
  mapping_suggestions: Record<string, ColumnMappingSuggestion>
  canonical_fields: string[]
  column_mapping?: Record<string, string> | null
  mapping_report?: Record<string, MappingReportEntry> | null
  remembered?: boolean
}

export interface UploadedFile {
  id: string
  event_id: string
  filename: string
  source_type: string
  row_count: number
  status: 'imported' | 'pending' | 'error' | 'mapped' | 'review'
  uploaded_at: string
}

export interface EventMergeEvent {
  id: string
  name: string
  start_date?: string | null
  location_city?: string | null
  participant_count: number
}

export interface EventMergeSuggestion {
  canonical_event_id: string
  events: EventMergeEvent[]
  ai_confirmed?: boolean | null
  min_similarity: number
}

export interface MatchCandidateParty {
  nom?: string
  email?: string | null
  telephone?: string | null
  societe?: string | null
  nationalite?: string | null
}

export interface MatchCandidate {
  id: string
  event_id: string
  participant_a_id?: string | null
  participant_b_id?: string | null
  name_a?: string | null
  name_b?: string | null
  details_a?: MatchCandidateParty | null
  details_b?: MatchCandidateParty | null
  deterministic_score?: number | null
  ai_recommendation?: 'fusionner' | 'separer' | 'incertain' | null
  ai_justification?: string | null
  ai_confidence?: number | null
  human_decision?: string | null
  status: string
  created_at?: string | null
}

export interface ConsolidationRun {
  id: string
  event_id: string
  // Matches the Postgres `consolidation_runs.status` CHECK constraint and
  // the two branches consolidation_service.py actually writes on completion
  // (docs/schema.sql; never "pending" or "done" -- those never occur).
  status: 'running' | 'completed' | 'failed'
  started_at: string
  finished_at?: string
  // Matches the runtime `stats` dict built in consolidation_service.py's
  // run_consolidation (not the narrower Pydantic ConsolidationStats model,
  // which is itself out of sync with it) -- every key is optional since
  // several are only added conditionally during a run.
  stats?: {
    total_source_records?: number
    matched_certain?: number
    matched_probable?: number
    to_verify?: number
    not_found?: number
    participants_created?: number
    participants_updated?: number
    exceptions_count?: number
    mappings_repaired?: number
    /** Running TOTAL after the run — the only participant figure here that is
     *  a state rather than a per-run counter, and the one the trend line and
     *  the "since yesterday" delta read. */
    participants_total?: number
  }
}

export interface Export {
  id: string
  event_id: string
  run_id: string
  format: string
  status: 'pending' | 'ready' | 'error'
  created_at: string
}

export interface Exception {
  id: string
  event_id: string
  type: 'conflict' | 'duplicate' | 'not_found' | 'to_verify' | 'coverage' | 'missing_field' | 'mapping_health' | 'flight' | 'transfer'
  exception_type?: string
  severity: 'critical' | 'warning' | 'info'
  participant_id?: string
  participant_name?: string
  message: string
  field?: string
  value_a?: string
  value_b?: string
  source_a?: string
  source_b?: string
  resolved: boolean
  created_at: string
  context_data?: Record<string, unknown>
}

export interface CoverageStat {
  with: number
  without: number
  pct: number
}

export interface DashboardData {
  event: {
    name: string | null
    start_date: string | null
    end_date: string | null
    location_city: string | null
    /** Negative once the event has started. null when no date is set. */
    days_until_start: number | null
    generated_on: string
  }
  participants: { total: number; complete: number; completeness_pct: number }
  coverage: Record<'has_flight' | 'has_hotel' | 'has_transfer' | 'has_activities', CoverageStat>
  /** null when the communications table is not deployed — the chart drops the
   *  slice instead of showing a number nobody computed. */
  communications: { participants_contacted: number | null; pct: number | null }
  registrations: { submissions: number | null }
  alerts: {
    open: number | null
    overdue: number | null
    critical: number | null
    oldest_age_hours: number | null
  }
  trend: {
    points: { at: string | null; stats: Record<string, number> }[]
    delta: { since: string | null; changes: Record<string, number> } | null
  }
  priorities: { point: string; nombre: number; où: string }[]
  companies: {
    company: string
    participants: number
    without_flight: number
    without_hotel: number
    without_transfer: number
    incomplete: number
  }[]
}

/** One question of the public registration form, as configured for an event.
 *  `locked` marks the fields the consolidation engine matches people on
 *  (first/last name, email): they cannot be switched off. */
export interface RegistrationFieldState {
  key: string
  label: string
  group: string
  locked: boolean
  enabled: boolean
  required: boolean
  /** Point 13 (v1): which badges may see this field. Empty means every
   *  badge — a field nobody restricted stays visible to all of them. */
  badges: string[]
}

/** A whole form configuration proposed from a plain-language brief.
 *  Nothing is saved until the organizer applies it — the fields and theme
 *  here go back through the ordinary save endpoints, which sanitize again. */
export interface RegistrationProposal {
  fields: Record<string, { enabled: boolean; required: boolean; badges: string[] }>
  order: string[]
  custom_fields: { label: string; type: string }[]
  theme: RegistrationTheme
  summary: string
  description: string
  asked_count: number
  /** 'ai' when a model read the brief, 'keywords' when it fell back — the
   *  editor says which, because the two deserve different amounts of trust
   *  from somebody about to click Apply. */
  source: 'ai' | 'keywords'
}

/** A named audience for the form (point 13, v1) — selected by `?badge=` on
 *  the link, never by the registrant themselves. */
export interface RegistrationBadge {
  id: string
  name: string
}

/** A question the organizer wrote themselves. The catalogue can never hold
 *  "favourite sweet", and the reference form MAX runs today asks exactly
 *  that — so the event defines its own. */
export interface RegistrationCustomField {
  key: string
  label: string
  type: 'text' | 'textarea' | 'select' | 'date' | 'boolean'
  required: boolean
  options: string[]
}

/** A tick-box with contractual weight (cancellation policy, role
 *  confirmation), worded per trip. All of them are mandatory. */
export interface RegistrationConfirmation {
  key: string
  label: string
  text: string
}

/** Which participant fields this event tracks, and how strictly. Only
 *  `required` ones raise alerts or weigh on the completeness score. */
export type FieldState = 'required' | 'optional' | 'not_used'

export interface FieldPolicyEntry {
  key: string
  label: string
  group: string
  default: FieldState
}

export interface TransferVehicle {
  name: string
  capacity: number
}

export interface TransferSettings {
  vehicles: TransferVehicle[]
  min_hours_before_flight: number
  grouping_window_minutes: number
  /** Where arrivals are dropped and departures collected. The one location
   *  no file carries, so the organizer writes it once and every group uses
   *  it; the airports come from each participant own flight. */
  hotel_name: string
}

/** One booked, already-persisted transfer — a row in the `transfers` table,
 *  one per participant. There is no group table: two rows that happen to
 *  share the same time, vehicle and route ARE a group, purely by matching. */
export interface Transfer {
  id: string
  transfer_type: 'arrival' | 'departure' | string
  pickup_location: string
  dropoff_location: string
  pickup_time: string
  vehicle_type?: string | null
  status: string
  participant_id?: string
  participant_name?: string
  flight_number?: string
}

/** Only what update() may change.
 *
 *  transfer_type used to be deliberately absent here, on the reasoning that an
 *  arrival does not become a departure by editing a field. Dragging somebody
 *  into another vehicle changed that: the gesture moves every field that
 *  defines the destination vehicle, and direction is one of them. Leaving it
 *  out produced a passenger listed as arriving in a van going to the airport.
 *  The server still refuses any value other than 'arrival' or 'departure'. */
export interface TransferPatch {
  pickup_location?: string
  dropoff_location?: string
  pickup_time?: string
  vehicle_type?: string
  status?: string
  /** 'arrival' | 'departure'. Set when a person is dropped into another
   *  vehicle: direction is part of what defines that vehicle. */
  transfer_type?: string
}

/** One proposed vehicle: when it leaves, who is in it, and what it is.
 *  `needs_attention` marks a group the planner could not schedule — a return
 *  flight with no time on it — which still needs somebody to arrange a car. */
export interface TransferGroup {
  direction: 'arrival' | 'departure'
  pickup_time: string | null
  pickup_location: string
  dropoff_location: string
  flight_numbers: string[]
  participant_ids: string[]
  /** Names alongside the ids the group is actually keyed by — resolved
   *  server-side, in the same order as `participant_ids`. Absent on a group
   *  built purely on the client (e.g. a fresh split), never sent to `apply`:
   *  only `participant_ids` is what gets written. */
  participants?: { id: string; name: string }[]
  passengers: number
  vehicle: TransferVehicle | null
  sequence: number
  needs_attention?: string
}

export interface TransferPlan {
  settings: TransferSettings
  groups: TransferGroup[]
  summary: {
    groups: number; participants: number
    arrivals: number; departures: number; needs_attention: number
  }
}

export interface RoomOccupant {
  participant_id: string
  name: string
}

export interface Room {
  room_number: string
  room_type: string
  occupants: RoomOccupant[]
  occupancy: number
  hotel_name: string
  check_in: string
  check_out: string
  nights: number
  conflict?: string
  room_numbers?: string[]
  /** Who owns this number. 'hotel' numbers are facts about physical rooms and
   *  are never reassigned; 'generated' ones are ours to lay out again. */
  origin?: 'hotel' | 'generated'
}

export interface RoomingParticipantLine {
  participant_id: string
  name: string
  room_number: string
  room_type: string
  roommate: string
  hotel_name: string
  check_in: string
  check_out: string
  nights: number
}

export interface RoomingSummary {
  rooms: number; participants: number
  unassigned: number; conflicts: number
  by_type: Record<string, number>
  /** Present once a list has been generated: ours vs the hotel's numbers. */
  generated_numbers?: number
  hotel_numbers?: number
}

/** One person the next generation would move, add, or drop. */
export interface RoomingChange {
  participant_id: string
  name: string
  kind: 'added' | 'removed' | 'moved' | 'roommate_changed' | 'hotel_changed' | 'type_changed'
  from: string
  to: string
}

export interface RoomingList {
  view: string
  rooms: Room[]
  participants: RoomingParticipantLine[]
  summary: RoomingSummary
  available: boolean
  /** False before migration 013: the screen falls back to a live derivation
   *  and the Generate button explains why it is disabled. */
  storage_available: boolean
  /** A rooming list is a document somebody made, not a view that appears.
   *  Until this is true there is deliberately nothing to show. */
  generated: boolean
  version: number
  generated_at: string | null
  note?: string
  /** The stored list no longer matches the data. Reported, never resolved. */
  stale: boolean
  changes: RoomingChange[]
  /** Shared rooms with nobody confirmed on the other side (§4). Generation
   *  refuses while this is non-empty, unless force is passed. */
  roommate_gaps?: RoommateGap[]
  /** The default room type THIS version was generated with, so the options
   *  panel reopens on the answer that produced the list on screen. */
  default_room_type?: RoomTypeDefault
}

/** One person who asked for a shared room and has no confirmed partner. */
export interface RoommateGap {
  participant_id: string
  name: string
  room_type: string
  written_name: string
  reason: 'no_name' | 'unknown_name' | 'ambiguous_name' | 'contradicted'
  label: string
}

export interface RoomingPreview {
  rooms: Room[]
  participants: RoomingParticipantLine[]
  summary: RoomingSummary
  changes: RoomingChange[]
  summary_line: string
  available: boolean
  current_version: number
}

export interface RoomingGeneration {
  version: number
  id: string
  summary: RoomingSummary
  rooms: Room[]
  participants: RoomingParticipantLine[]
  changes: RoomingChange[]
  summary_line: string
  numbers_written: number
}

export interface RoomingVersion {
  id: string
  version: number
  summary: RoomingSummary
  note: string | null
  generated_at: string
  generated_by: string | null
}

export interface RoomingOptions {
  start_number?: number
  prefix?: string
  renumber?: boolean
  note?: string
  /** What somebody who never answered the room-type question is booked as.
   *  The one option on this screen with an invoice attached, which is why it
   *  replaced the starting number: ninety singles and ninety doubles are not
   *  the same hotel bill. A declared type still wins over it. */
  default_room_type?: RoomTypeDefault
  /** Generate despite unpaired shared rooms (§4). Never the default. */
  force?: boolean
}

export type RoomTypeDefault = 'single' | 'double'

/** A saved numbering convention (point 4), managed by the team itself from
 *  the rooming page — not a fixed list, not admin-only. */
export interface RoomingPreset {
  id: string
  name: string
  start_number: number
  prefix: string
  /** Presets saved before this field existed come back as 'single', which is
   *  what they meant — the default was the only behaviour available. */
  room_type: RoomTypeDefault
}

/** One line of the hotel's own file, and what it would do to a fiche.
 *
 *  'matched' is the only status Apply writes. The other five are reported so
 *  that four unmatched names read as "these four cancelled" rather than
 *  disappearing silently into a success message. */
export interface RoomingImportLine {
  /** 1-based position in the file, so "ligne 47" can be opened and looked at. */
  row: number
  name: string
  email: string
  room_number: string
  room_type: string
  status: 'matched' | 'unchanged' | 'ambiguous' | 'duplicate' | 'unknown' | 'invalid'
  participant_id: string
  participant_name: string
  current_number: string
}

export interface RoomingImportPreview {
  filename: string
  /** Which column of their file we read as what. Shown, because a "Room"
   *  column that turned out to be room service must be visible as a wrong
   *  guess BEFORE anything is written. */
  columns: Record<string, string>
  lines: RoomingImportLine[]
  summary: Record<string, number>
  summary_line: string
}

export interface RoomingImportResult {
  updated: number
  skipped: number
  failed: number
  failures: { participant_id: string; error: string }[]
}

export interface OwnExpenseNoticeOptions {
  participant_ids?: string[]
  /** A single night outside the dates is usually a late flight rather than an
   *  extension; the organizer can raise the bar before writing to anybody. */
  min_nights?: number
  sender?: string
}

export interface OwnExpenseNoticeDraft {
  participant_id: string
  name: string
  email: string
  language: string
  nights: number
  arrives_early_days: number
  stays_late_days: number
  first_departure: string
  last_departure: string
  subject: string
  body: string
}

export interface OwnExpenseNoticePlan {
  drafts: OwnExpenseNoticeDraft[]
  skipped: { participant_id: string; name?: string; reason: string; nights?: number }[]
  summary: {
    notices: number
    nights: number
    by_language: Record<string, number>
    skipped: number
    skipped_reasons: Record<string, number>
  }
  event_name: string
  event_start: string
  event_end: string
}

export interface OwnExpenseNoticeResult {
  count: number
  skipped: OwnExpenseNoticePlan['skipped']
  summary: OwnExpenseNoticePlan['summary']
}

/** §14 — Request Missing Information. */
export interface InformationRequestField {
  key: string
  /** 'missing' = empty; 'uninformative' = answered "yes" and nothing else. */
  reason: 'missing' | 'uninformative' | string
}

export interface InformationRequestDraft {
  participant_id: string
  name: string
  email: string
  language: string
  fields: InformationRequestField[]
  exception_ids: string[]
  subject: string
  body: string
}

export interface InformationRequestSkip {
  participant_id: string
  name?: string
  reason: 'no_email' | 'nothing_left_to_ask' | 'unknown_participant' | string
}

export interface InformationRequestSummary {
  recipients: number
  questions: number
  by_field: Record<string, number>
  by_language: Record<string, number>
  skipped: number
  skipped_reasons: Record<string, number>
}

export interface InformationRequestPlan {
  drafts: InformationRequestDraft[]
  skipped: InformationRequestSkip[]
  summary: InformationRequestSummary
  event_name: string
}

export interface InformationRequestResult {
  created: unknown[]
  count: number
  skipped: InformationRequestSkip[]
  summary: InformationRequestSummary
  /** False when migration 014 is absent: the drafts exist and are sendable,
   *  but nothing records which fields they asked about. */
  tracked: boolean
}

export interface InformationRequestOptions {
  exception_ids?: string[]
  participant_ids?: string[]
  deadline?: string
  sender?: string
}

/** Empty selection = every unresolved exception, every participant. */
const EMPTY_SELECTION = { exception_ids: [] as string[], participant_ids: [] as string[] }

/** §11 — one section of the mini event site, already resolved to one language
 *  by the server and stripped of markup before it was ever stored. */
export interface EventSiteSection {
  slug: string
  title: string
  paragraphs: string[]
  image_url: string
  /** Point 13: where the photo sits relative to the text. */
  image_position?: 'above' | 'below'
  position?: number
}

/** The same section as the editor holds it: every language, nothing dropped. */
export interface EventSiteSectionDraft {
  slug: string
  position?: number
  title: Record<string, string>
  body: Record<string, string>
  image_url: string
  /** Point 13: 'above' (default) or 'below' the text. */
  image_position?: 'above' | 'below'
  visible: boolean
}

export interface EventSiteConfig {
  sections: EventSiteSectionDraft[]
  catalogue: { slug: string; label: string }[]
  summary: {
    sections?: number
    with_image?: number
    written?: Record<string, number>
    rendered?: Record<string, number>
  }
  available: boolean
}

/** §20 — Add/Update Source vs Replace Source. */
export interface SourceFileVersion {
  id: string
  filename: string
  source_type: string
  row_count: number
  imported_at: string
  import_status: string
  superseded_at: string | null
  superseded_by: string | null
  /** Earlier live files of the same kind this one could replace. */
  replaceable: { id: string; filename: string; imported_at: string; row_count: number }[]
}

export interface ReplacementImpact {
  added: { key: string; name: string }[]
  removed: { key: string; name: string }[]
  changed: { key: string; name: string; fields: { field: string; old: string; new: string }[] }[]
  unchanged: number
  old_rows: number
  new_rows: number
  untracked: number
  summary_line: string
  /** People the replaced file is the only live source for. Never deleted —
   *  a booked room is not a spreadsheet row. */
  orphaned: { participant_id: string; name: string; has_hotel: boolean; has_transfer: boolean }[]
  old_file: { id: string; filename: string }
  new_file: { id: string; filename: string }
}

/** §19 — one line of the change log, in the seven columns the feedback asks for. */
export interface HistoryLine {
  id: string
  at: string
  user_id: string
  user: string
  entity_type: string
  entity_id: string
  participant: string
  field: string
  field_label: string
  old_value: string
  new_value: string
  /** True for sensitive fields: the change is reported, the value is not. */
  masked: boolean
  source: string
  source_label: string
  /** True when the origin was reconstructed from the reason code rather than
   *  recorded — only a recorded origin settles an argument. */
  source_inferred: boolean
  reason: string
}

export interface HistorySummary {
  changes: number
  inferred: number
  by_source: Record<string, number>
  by_field: Record<string, number>
  people: number
}

export interface HistoryPage {
  lines: HistoryLine[]
  summary: HistorySummary
  sources: { key: string; label: string }[]
  available: boolean
  has_more: boolean
  offset?: number
}

export interface HistoryFilters {
  participant_id?: string
  field?: string
  source?: string
  since?: string
  limit?: number
  offset?: number
}

/** One row of the assistant's conversation list. */
export interface ChatConversationSummary {
  id: string
  title: string
  created_at: string | null
  updated_at: string | null
  questions: number
  /** How many answers were refusals — a thread full of them means somebody
   *  kept asking something the data cannot support. */
  unanswered: number
}

export interface ChatStoredMessage {
  role: 'user' | 'assistant'
  content: string
  intent: string | null
  answered: boolean | null
  /** The rows themselves are never stored: they are participant data, and a
   *  transcript is not a place to keep it. Only how many there were. */
  row_count: number
  created_at: string | null
}

export interface ChatTranscript {
  conversation: ChatConversationSummary
  messages: ChatStoredMessage[]
}

/** §9 — a document the event asks the participant to upload. */
export interface RegistrationAttachmentRequest {
  kind: 'passport_scan' | 'photo' | string
  label: string
  required: boolean
  accept: string[]
  max_bytes: number
}

export interface UploadedAttachment {
  id: string
  kind: string
  filename: string
  byte_size: number
}

/** §9 — a second person registered in the same submission. Only the fields
 *  they alone can answer; everything else is inherited from the registrant. */
export interface RegistrationCompanion {
  first_name: string
  last_name: string
  email?: string
  phone?: string
  date_of_birth?: string
  nationality?: string
  passport_number?: string
  dietary_requirements?: string
  pmr_needs?: string
  shirt_size?: string
  remarks?: string
  shares_room: boolean
}

export interface SupplierProfile {
  profile: string
  label: string
  columns: string[]
  choices?: { key: string; label: string }[]
}

export interface ExportChange {
  status: 'NEW' | 'UPDATED' | 'CANCELLED'
  participant_id: string
  participant_name: string
  field: string
  label: string
  old: string
  new: string
}

export interface ExportChangeSummary {
  new: number
  updated: number
  cancelled: number
  changes: number
}

export interface ParticipantNote {
  id: string
  category: string
  body: string
  include_in_export: boolean
  author_id: string | null
  created_at: string
  /** Which preset this note came from, if any. Absent before migration 028. */
  preset_id?: string | null
}

/** A named, reusable internal note with its own colour ("Super VIP"). Applying
 *  one writes a normal note and colours that person's master-list row. */
export interface NotePreset {
  id: string
  name: string
  body: string
  color: string
  category: string
}

export interface ParticipantNotes {
  notes: ParticipantNote[]
  categories: { key: string; label: string; exportable_to: string | null }[]
  presets?: NotePreset[]
  available: boolean
}

export interface ChatAnswer {
  answer: string
  rows: Record<string, unknown>[]
  references: string[]
  intent: string | null
  /** False when the assistant declined (out of scope, unknown participant, or
   *  a data source it could not read). The UI shows `answer` verbatim. */
  answered: boolean
  generated_on?: string
  /** The thread this answer belongs to. Null when migration 019 is absent —
   *  the browser then keeps carrying the history itself, as it always did. */
  conversation_id?: string | null
}

export interface EmailProposal {
  id: string
  event_id: string
  sender: string
  subject: string
  body: string
  received_at: string
  participant_id?: string
  status: 'pending' | 'applied' | 'rejected'
  proposed_changes: Record<string, string>
  ai_explanation?: string
  created_at: string
  participant_name?: string
}

export type MailProvider = 'gmail' | 'outlook'

export interface MailProviderStatus {
  provider: MailProvider
  configured: boolean
  connected: boolean
}

export interface MailStatus {
  providers: MailProviderStatus[]
}

import { createClient } from './supabase'

const supabase = createClient()


function mapParticipant(p: any): Participant {
  if (!p) return p
  
  let lockedFieldsArray: string[] = []
  if (p.locked_fields) {
    if (Array.isArray(p.locked_fields)) {
      lockedFieldsArray = p.locked_fields
    } else if (typeof p.locked_fields === 'object') {
      lockedFieldsArray = Object.keys(p.locked_fields).filter(k => p.locked_fields[k] === true)
    }
  }

  let sourcesArray: string[] = []
  if (p.sources) {
    sourcesArray = p.sources
  } else {
    if (p.registration_source_id) sourcesArray.push('registration')
    if (p.fcm_source_id) sourcesArray.push('fcm')
  }

  return {
    ...p,
    completeness_status: p.completeness_status || p.status || 'incomplete',
    has_activities: p.has_activities !== undefined ? p.has_activities : (p.has_activity !== undefined ? p.has_activity : false),
    locked_fields: lockedFieldsArray,
    sources: sourcesArray,
    confidence: p.confidence || 'certain',
  }
}

function mapException(exc: any): Exception {
  if (!exc) return exc
  const ctx = exc.context_data || {}
  let value_a: string | undefined = undefined
  let value_b: string | undefined = undefined
  let source_a: string | undefined = undefined
  let source_b: string | undefined = undefined
  let participant_name: string | undefined = exc.participant_name

  if (exc.exception_type === 'conflict' || exc.exception_type === 'DATA_CONFLICT') {
    if (ctx.conflicts && ctx.conflicts.length > 0) {
      const c = ctx.conflicts[0]
      value_a = c.registration_value
      value_b = c.fcm_value
      source_a = say({ fr: 'Fiche inscription', nl: 'Inschrijvingsfiche', en: 'Registration record' })
      source_b = say({ fr: 'Import FCM (vols)', nl: 'FCM-import (vluchten)', en: 'FCM import (flights)' })
      if (!participant_name) {
        participant_name = c.participant_name
      }
    } else {
      value_a = ctx.value_a
      value_b = ctx.value_b
      source_a = ctx.source_a
      source_b = ctx.source_b
    }
  }

  if (!participant_name && ctx.participant_name) {
    participant_name = ctx.participant_name
  }

  // Every backend type falls into ONE of the filter categories so the chips
  // actually sort the page (coverage = aggregated "X participants without…").
  const EXC_CATEGORY: Record<string, Exception['type']> = {
    DATA_CONFLICT: 'conflict', NAME_DIVERGENCE: 'conflict', conflict: 'conflict',
    POSSIBLE_DUPLICATE: 'duplicate', DUPLICATE_EMAIL: 'duplicate', duplicate: 'duplicate',
    FLIGHT_NO_PARTICIPANT: 'not_found', not_found: 'not_found',
    PROBABLE_MATCH: 'to_verify', MISSING_REQUIRED_FIELD: 'to_verify', INVALID_FORMAT: 'to_verify',
    DATE_INCOHERENCE: 'to_verify', MISSING_CONTACT: 'to_verify', to_verify: 'to_verify',
    PARTICIPANT_NO_FLIGHT: 'coverage', PARTICIPANT_NO_HOTEL: 'coverage',
    PARTICIPANT_NO_TRANSFER: 'coverage', PARTICIPANT_NO_DIETARY: 'coverage',
  }
  // The §18 operational alerts. They arrive as DATA_CONFLICT and
  // MISSING_REQUIRED_FIELD because those are the ENUM values the table
  // accepts, so their real subject lives in context_data.category — and
  // without this they would scatter across "Conflit" and "À vérifier", which
  // is exactly the mixed-up list §18 asks us to sort out.
  const FLIGHT_CATEGORIES = new Set([
    'flight_conflict', 'flight_reversed', 'flight_changed', 'missing_return_flight',
    // Flights that fall outside the programme dates — a billing question,
    // but it is the flight file that raises it, so it belongs on this chip.
    'staying_own_expense',
  ])
  const TRANSFER_CATEGORIES = new Set([
    'transfer_not_assigned', 'flight_without_transfer', 'capacity_exceeded',
  ])

  // systemic_anomaly outranks everything: a gap covering ~all participants is
  // a suspected mapping failure (backend exception_service._is_systemic), not
  // an ordinary coverage/missing-field card — it gets its own filter chip.
  const category: Exception['type'] = ctx.systemic_anomaly
    ? 'mapping_health'
    : FLIGHT_CATEGORIES.has(ctx.category as string)
    ? 'flight'
    : TRANSFER_CATEGORIES.has(ctx.category as string)
    ? 'transfer'
    : ctx.category === 'missing_field'
    ? 'missing_field'
    : ctx.aggregate
    ? 'coverage'
    : (EXC_CATEGORY[exc.exception_type as string] || EXC_CATEGORY[exc.type as string] || 'to_verify')

  return {
    ...exc,
    type: category,
    exception_type: exc.exception_type,
    participant_name,
    value_a,
    value_b,
    source_a,
    source_b,
  }
}


// ─── HTTP helpers ──────────────────────────────────────────────────────────────

/** An HTTP error from the API, carrying the backend's own message and status.
 *  `status` lets callers tell an expected conflict (409) apart from a real
 *  failure without string-matching the message. */
export class ApiError extends Error {
  readonly status: number
  /** The backend's `detail` when it is an object rather than a string — a
   *  refusal that carries WHICH rows caused it, so the screen can list them
   *  instead of only repeating the sentence. */
  readonly detail?: Record<string, unknown>
  constructor(message: string, status: number, detail?: Record<string, unknown>) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.detail = detail
  }
}

/**
 * The caller's access token, or a thrown 401 — never a request without one.
 *
 * The session lives in a cookie that the auth client reads asynchronously, so
 * the components mounted first (the event selector, the sidebar) could call
 * before it resolved. The old code simply omitted the Authorization header in
 * that case and fired anyway: the API answered 422 "Field required", the
 * selector could not tell that from a malformed request, gave up, and the
 * event dropdown stayed empty on every cold load (production, 2026-08-12).
 *
 * One short retry covers the startup race; past that the caller is genuinely
 * signed out and gets a 401 it can act on.
 */
/**
 * The interface language, read from the URL.
 *
 * This module is not a component, so it cannot ask next-intl — but next-intl
 * itself takes the locale from the first path segment, so reading it here
 * gives the same answer. Only the few sentences api.ts owns need it; every
 * other message on screen goes through a real translator.
 */
type UiLang = 'fr' | 'nl' | 'en'

function uiLang(): UiLang {
  if (typeof window === 'undefined') return 'fr'
  const segment = window.location.pathname.split('/')[1]
  return segment === 'nl' || segment === 'en' ? segment : 'fr'
}

function say(table: Record<UiLang, string>): string {
  return table[uiLang()]
}

async function accessToken(): Promise<string> {
  for (const waitMs of [0, 120, 360]) {
    if (waitMs) await new Promise((r) => setTimeout(r, waitMs))
    const { data: { session } } = await supabase.auth.getSession()
    if (session?.access_token) return session.access_token
  }
  throw new ApiError(say({
    fr: 'Session expirée — reconnectez-vous.',
    nl: 'Sessie verlopen — meld u opnieuw aan.',
    en: 'Session expired — please sign in again.',
  }), 401)
}

/** The backend's own explanation when there is one, else `fallback`.
 *
 *  Use this in a catch instead of a hardcoded string whenever the user could
 *  act on the reason. The API answers with an actionable French message —
 *  "une consolidation est déjà en cours, patientez", "aucun fichier mappé" —
 *  and replacing it with a generic line is precisely how a perfectly clear
 *  409 reached the user as an unexplained "Erreur lors de la suppression". */
export function errorMessage(err: unknown, fallback: string): string {
  return err instanceof Error && err.message ? err.message : fallback
}

// ─── Short-lived GET cache ────────────────────────────────────────────────
//
// Every page mounts fresh on navigation and refetches everything it needs, so
// going Vols → Hébergements → Vols paid for the same three calls twice. This
// keeps GET responses for a few seconds, which is the window in which someone
// actually navigates back and forth; anything older is refetched.
//
// Three rules keep it from ever serving something wrong:
//   * ANY mutation empties the whole cache. A PATCH on a participant changes
//     the master list, the coverage counts and the exception list at once, and
//     guessing which keys to drop is how a cache starts lying.
//   * Endpoints that are polled or must be live are never cached.
//   * A caller that means "now" passes { noCache: true } (the refresh button
//     on the registration page does).
// Concurrent callers of the same URL share one request instead of racing.
const CACHE_TTL_MS = 15_000
// Live endpoints. `/runs` is the one that matters: the dashboard and the master
// list poll a consolidation's status every 3s through /api/events/{id}/runs/…,
// and a 15s cache there would freeze a finished run as "en cours" for five
// polls. Export/download URLs are signed and single-use; mail status reflects
// an OAuth connection that changes out of band.
const NEVER_CACHE = [/\/runs(\/|$|\?)/, /\/consolidate/, /\/exports?(\/|$)/, /\/download/, /\/mail\//]
const responseCache = new Map<string, { at: number; value: unknown }>()
const inFlight = new Map<string, Promise<unknown>>()

/** Drop everything cached. Called on every mutation; exported for the rare
 *  caller that knows the server changed behind its back. */
export function clearApiCache(): void {
  responseCache.clear()
  inFlight.clear()
}

type RequestOptions = RequestInit & {
  noCache?: boolean
  /** Skip authentication entirely. For the endpoints under /api/public/,
   *  reached by participants who have no account and never will. */
  anonymous?: boolean
}

/**
 * Turn a failed response into an ApiError carrying what the backend said.
 *
 * FastAPI reports errors as {"detail": ...} and NEVER as {"message": ...}
 * (HTTPException, the global handler in main.py, and 422 validation all use
 * `detail`). Reading `message` meant every backend error message was dropped on
 * the floor and rethrown as a bare "HTTP 409" — which callers then replaced
 * with a generic "check your API connection", sending users hunting a network
 * problem while the API had explained itself perfectly ("une consolidation est
 * déjà en cours", "aucun fichier mappé"...).
 *
 * One function rather than one per caller: a JSON call and a file download must
 * not report the same failure differently.
 */
async function apiErrorFrom(res: Response): Promise<ApiError> {
  if (!res.ok) {
    const body = await res.json().catch(() => null)
    const detail = body?.detail
    let text: string | undefined
    let structured: Record<string, unknown> | undefined
    if (typeof detail === 'string') {
      text = detail
    } else if (Array.isArray(detail)) {
      text = detail[0]?.msg              // 422: Pydantic validation errors
    } else if (detail && typeof detail === 'object') {
      // A refusal that names its rows (e.g. rooming gaps): keep the sentence
      // AND the payload, so the screen can list what has to be fixed.
      structured = detail as Record<string, unknown>
      if (typeof structured.message === 'string') text = structured.message
    } else if (typeof body?.message === 'string') {
      text = body.message               // non-FastAPI producers (proxies, etc.)
    }
    return new ApiError(text || res.statusText || `HTTP ${res.status}`, res.status, structured)
  }
  return new ApiError(res.statusText || `HTTP ${res.status}`, res.status)
}

/**
 * Fetch a file endpoint and hand the bytes to the browser.
 *
 * Separate from `request` because that one ends in `res.json()`, and a PDF is
 * not JSON — but it fails identically, so a missing download always says why.
 */
export async function downloadFile(path: string, fallbackName: string): Promise<void> {
  const headers = new Headers({ Authorization: `Bearer ${await accessToken()}` })
  const res = await fetch(`${BASE_URL}${path}`, { headers })

  if (!res.ok) throw await apiErrorFrom(res)

  // The server names the file; the caller's name is only a fallback, so a
  // rename on the backend does not need a matching change here.
  const disposition = res.headers.get('Content-Disposition') || ''
  const match = /filename="?([^"]+)"?/.exec(disposition)
  const name = match?.[1] || fallbackName

  const url = URL.createObjectURL(await res.blob())
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = name
  document.body.appendChild(anchor)
  anchor.click()
  anchor.remove()
  URL.revokeObjectURL(url)
}

async function request<T>(
  path: string,
  options: RequestOptions = {}
): Promise<T> {
  const method = (options.method ?? 'GET').toUpperCase()
  const cacheable =
    method === 'GET' && !options.noCache && !NEVER_CACHE.some((re) => re.test(path))

  if (cacheable) {
    const hit = responseCache.get(path)
    if (hit && Date.now() - hit.at < CACHE_TTL_MS) {
      // Cloned so a caller that sorts or mutates the result in place cannot
      // corrupt what the next caller receives.
      return structuredClone(hit.value) as T
    }
    const pending = inFlight.get(path)
    if (pending) return structuredClone(await pending) as T
  }

  const run = async (): Promise<T> => {
  const isFormData = options.body instanceof FormData
  const headers = new Headers(options.headers)

  // A public endpoint must never demand a session: the visitor filling in
  // the registration form has no account and never will. Requiring one
  // made accessToken() throw a 401 and the form render "lien invalide".
  if (!options.anonymous) {
    headers.set('Authorization', `Bearer ${await accessToken()}`)
  }

  if (!isFormData && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json')
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars -- intentional: strip `headers`/`noCache` out of restOptions
  const { headers: _, noCache: __, anonymous: ___, ...restOptions } = options

  // Per-endpoint timing to profile slow calls (dev only — see feedback P1.6).
  const startedAt = typeof performance !== 'undefined' ? performance.now() : Date.now()
  const res = await fetch(`${BASE_URL}${path}`, {
    headers,
    ...restOptions,
  })
  if (process.env.NODE_ENV !== 'production') {
    const now = typeof performance !== 'undefined' ? performance.now() : Date.now()
    console.debug(`[api] ${method} ${path} → ${res.status} in ${Math.round(now - startedAt)}ms`)
  }

  // See apiErrorFrom above: `detail` is the field FastAPI populates, it may
  // arrive as a string or as a list of Pydantic validation errors, and both
  // shapes must reach the user rather than a bare "HTTP 409".
  if (!res.ok) throw await apiErrorFrom(res)

  return res.json()
  }

  // A mutation can change anything anywhere: start from a clean slate rather
  // than trying to work out which lists it invalidated.
  if (method !== 'GET') {
    const result = await run()
    clearApiCache()
    return result
  }

  if (!cacheable) return run()

  const promise = run()
  inFlight.set(path, promise)
  try {
    const value = await promise
    responseCache.set(path, { at: Date.now(), value })
    return structuredClone(value) as T
  } finally {
    inFlight.delete(path)
  }
}

function qs(params: Record<string, string | number | boolean | undefined>): string {
  const q = Object.entries(params)
    .filter(([, v]) => v !== undefined)
    .map(([k, v]) => `${k}=${encodeURIComponent(String(v))}`)
    .join('&')
  return q ? `?${q}` : ''
}

// ─── API client ───────────────────────────────────────────────────────────────

/** §9 — one collected document, as a screen needs it.
 *  No storage path: every read goes back through an access check. */
export interface RegistrationAttachment {
  id: string
  kind: string
  participant_id: string | null
  original_name: string | null
  content_type: string | null
  byte_size: number
  created_at: string | null
  claimed_at: string | null
}

export interface AttachmentList {
  attachments: RegistrationAttachment[]
  total: number
}

export const api = {
  files: {
    /** §20 — per file, the earlier files of the same kind it could replace. */
    async versions(eventId: string): Promise<{ available: boolean; files: SourceFileVersion[] }> {
      return request<{ available: boolean; files: SourceFileVersion[] }>(
        `/api/events/${eventId}/sources/versions`
      )
    },
    /** What retiring the earlier file would change — read-only. */
    async replacementImpact(fileId: string, replaces: string): Promise<ReplacementImpact> {
      return request<ReplacementImpact>(
        `/api/files/${fileId}/replacement-impact?replaces=${encodeURIComponent(replaces)}`
      )
    },
    /** Retire the earlier file. Reversible, and nobody is deleted. */
    async replace(fileId: string, oldFileId: string): Promise<{
      superseded: string; by: string; rows_unlinked: number
      orphaned: ReplacementImpact['orphaned']; next_step: string
    }> {
      return request(`/api/files/${fileId}/replaces/${oldFileId}`, { method: 'POST' })
    },
    async restore(fileId: string): Promise<{ restored: string; next_step: string }> {
      return request(`/api/files/${fileId}/restore`, { method: 'POST' })
    },
    async upload(eventId: string, file: File, sourceType: string): Promise<FileUploadResponse> {
      const form = new FormData()
      form.append('file', file)
      form.append('source_type', sourceType)
      form.append('event_id', eventId)
      return request<FileUploadResponse>('/api/files/upload', {
        method: 'POST',
        body: form,
        headers: {}, // let browser set Content-Type with boundary
      })
    },

    async preview(fileId: string): Promise<FilePreviewResponse> {
      return request<FilePreviewResponse>(`/api/files/${fileId}/preview`)
    },

    async mapColumns(fileId: string, mapping: Record<string, string>): Promise<void> {
      await request(`/api/files/${fileId}/map-columns`, {
        method: 'POST',
        body: JSON.stringify({ mapping, confirmed: true }),
      })
    },

    async list(eventId: string): Promise<UploadedFile[]> {
      const files = await request<any[]>(`/api/events/${eventId}/files`)
      return files.map(file => ({
        id: file.id,
        event_id: file.event_id || eventId,
        filename: file.original_filename || '',
        source_type: file.source_type,
        row_count: file.row_count,
        status: file.import_status === 'processed' || file.import_status === 'mapped' ? 'mapped' : file.import_status,
        uploaded_at: file.imported_at,
      }))
    },

    async delete(fileId: string): Promise<void> {
      await request(`/api/files/${fileId}`, {
        method: 'DELETE',
      })
    },
  },

  consolidation: {
    async run(eventId: string): Promise<ConsolidationRun> {
      const run = await request<any>(`/api/events/${eventId}/consolidate`, {
        method: 'POST',
      })
      return {
        id: run.id,
        event_id: run.event_id,
        status: run.status,
        started_at: run.started_at,
        finished_at: run.completed_at,
        stats: run.stats,
      }
    },

    async list(eventId: string): Promise<ConsolidationRun[]> {
      const list = await request<any[]>(`/api/events/${eventId}/runs`)
      return list.map(run => ({
        id: run.id,
        event_id: run.event_id,
        status: run.status,
        started_at: run.started_at,
        finished_at: run.completed_at,
        stats: run.stats,
      }))
    },

    // Bug found in the 2026-07-21/22 audit and only half-fixed at the time:
    // this used to translate the backend's real status ('completed'/'failed')
    // back into old, no-longer-written values ('done'/'error') before handing
    // it to the caller. dashboard/page.tsx and master-list/page.tsx were
    // fixed to compare against 'completed'/'failed' directly, but this
    // function kept producing 'done'/'error' underneath them -- so neither
    // comparison could ever match, every consolidation showed a false
    // "échec" banner regardless of outcome, and master-list's poll loop
    // never broke on completion (2026-07-22, found while chasing a report
    // of a run that completed successfully on the backend but showed as
    // failed on the dashboard). Pass the real backend shape straight through.
    async get(eventId: string, runId: string): Promise<ConsolidationRun> {
      const resp = await request<{ run: any; exceptions: any[]; exception_count: number }>(
        `/api/events/${eventId}/runs/${runId}`
      )
      const run = resp.run || {}
      return {
        id: run.id,
        event_id: run.event_id,
        status: run.status,
        started_at: run.started_at,
        finished_at: run.completed_at,
        stats: run.stats,
      }
    },
  },

  participants: {
    async list(eventId: string, params?: ParticipantListParams): Promise<PaginatedParticipants> {
      const query = qs({
        page: params?.page,
        page_size: params?.page_size,
        search: params?.search,
        status: params?.status,
        confidence: params?.confidence,
        has_flight: params?.has_flight,
        has_hotel: params?.has_hotel,
        has_transfer: params?.has_transfer,
      })
      const resp = await request<{
        items: any[]
        total: number
        page: number
        page_size: number
        total_pages: number
      }>(`/api/events/${eventId}/participants${query}`)
      
      return {
        items: (resp.items || []).map(mapParticipant),
        total: resp.total || 0,
        page: resp.page || 1,
        page_size: resp.page_size || 50,
        total_pages: resp.total_pages || 1
      }
    },

    /** Identity + coverage flags only. Use this — not the master list — to
     *  answer "who has no flight/hotel/transfert": it reads one table instead
     *  of merging ten, and returns the columns those pages actually show. */
    async coverage(eventId: string): Promise<{ items: any[]; total: number }> {
      return request<{ items: any[]; total: number }>(
        `/api/events/${eventId}/participants/coverage`
      )
    },

    async lookup(eventId: string): Promise<ParticipantLookupItem[]> {
      return request<ParticipantLookupItem[]>(`/api/events/${eventId}/participants/lookup`)
    },

    async get(participantId: string): Promise<Participant> {
      const p = await request<any>(`/api/participants/${participantId}`)
      return mapParticipant(p)
    },

    async getConsolidated(participantId: string): Promise<{
      flights: any[]
      transfers: any[]
      hotel_nights: any[]
      activities: any[]
      source_records: any[]
    }> {
      return request(`/api/participants/${participantId}/consolidated`)
    },

    async update(participantId: string, update: ParticipantFieldUpdate): Promise<Participant> {
      const p = await request<any>(`/api/participants/${participantId}`, {
        method: 'PATCH',
        body: JSON.stringify(update),
      })
      return mapParticipant(p)
    },

    async lockField(participantId: string, field: string): Promise<void> {
      await request(`/api/participants/${participantId}/lock/${field}`, { method: 'POST' })
    },

    async unlockField(participantId: string, field: string): Promise<void> {
      await request(`/api/participants/${participantId}/unlock/${field}`, { method: 'POST' })
    },
  },
  events: {
    /** §11 — the sections shown above the public form. Raw, all languages:
     *  the public endpoint resolves one and drops the empties, which is the
     *  wrong shape for editing. */
    async getSite(eventId: string): Promise<EventSiteConfig> {
      return request<EventSiteConfig>(`/api/events/${eventId}/site`)
    },
    /** Replaces the whole site — an omitted section is deleted. */
    async setSite(eventId: string, sections: EventSiteSectionDraft[]): Promise<EventSiteConfig> {
      return request<EventSiteConfig>(`/api/events/${eventId}/site`, {
        method: 'PUT',
        body: JSON.stringify({ sections }),
      })
    },
    /** A photo for a mini-site section, instead of pasting a link (point 9).
     *  Returns the URL to put straight into that section's image_url —
     *  nothing about how a section stores its image changes. */
    async uploadSiteImage(eventId: string, file: File): Promise<{ url: string }> {
      const form = new FormData()
      form.append('file', file)
      return request<{ url: string }>(`/api/events/${eventId}/site/image`, {
        method: 'POST',
        body: form,
        headers: {}, // let browser set Content-Type with boundary
      })
    },
    async list(): Promise<any[]> {
      return request<any[]>('/api/events')
    },
    async create(name: string, projectId: string): Promise<any> {
      if (!projectId) {
        throw new Error(say({
          fr: 'Sélectionnez un projet avant de créer un événement.',
          nl: 'Kies een project voor u een evenement aanmaakt.',
          en: 'Pick a project before creating an event.',
        }))
      }
      return request<any>('/api/events', {
        method: 'POST',
        body: JSON.stringify({
          project_id: projectId,
          name,
        }),
      })
    },
    async delete(eventId: string): Promise<void> {
      await request(`/api/events/${eventId}`, { method: 'DELETE' })
    },
    /** Event metadata. The dates drive the countdown AND the coverage
     *  thresholds (64 % of transfers booked is comfortable at D-90 and an
     *  emergency at D-5), and the city is the fallback arrival airport when a
     *  flight file states none. The API has always accepted them; nothing in
     *  the app could set them, so they stayed null on every event. */
    async get(eventId: string): Promise<{
      id: string; name: string; logo_url?: string | null
      start_date?: string | null; end_date?: string | null
    }> {
      return request<{
        id: string; name: string; logo_url?: string | null
        start_date?: string | null; end_date?: string | null
      }>(`/api/events/${eventId}`)
    },
    async update(
      eventId: string,
      patch: {
        name?: string; start_date?: string; end_date?: string; location_city?: string
        logo_url?: string
      },
    ): Promise<any> {
      return request<any>(`/api/events/${eventId}`, {
        method: 'PATCH',
        body: JSON.stringify(patch),
      })
    },
    /** Point 11 — returns a URL, does not save it. The caller PATCHes
     *  logo_url onto the event with it (see update() above), so a preview
     *  can be shown before it is confirmed. */
    async uploadLogo(eventId: string, file: File): Promise<{ url: string }> {
      const form = new FormData()
      form.append('file', file)
      return request<{ url: string }>(`/api/events/${eventId}/logo`, {
        method: 'POST',
        body: form,
        headers: {},
      })
    },
    /** `submissions` counts source_records under the event's public-form file —
     *  the only place that knows how many people actually filled it in.
     *  null when the count could not be read (never blocks the link itself). */
    async getRegistrationLink(
      eventId: string,
      opts?: { fresh?: boolean },
    ): Promise<{ token: string; url: string; is_open: boolean; submissions: number | null }> {
      // The refresh button next to the response counter means "now": it must
      // bypass the GET cache, or a click within 15s would hand back the very
      // number the user is trying to update and look broken.
      return request<{ token: string; url: string; is_open: boolean; submissions: number | null }>(
        `/api/events/${eventId}/registration-link`,
        { noCache: opts?.fresh }
      )
    },
    async setRegistrationOpen(eventId: string, isOpen: boolean): Promise<{ is_open: boolean }> {
      return request<{ is_open: boolean }>(`/api/events/${eventId}/registration-open`, {
        method: 'PATCH',
        body: JSON.stringify({ is_open: isOpen }),
      })
    },
    /** Which questions this event's public form asks. Always comes back
     *  resolved — an event that was never configured returns the defaults. */
    async getRegistrationFields(eventId: string): Promise<{ fields: RegistrationFieldState[] }> {
      return request<{ fields: RegistrationFieldState[] }>(`/api/events/${eventId}/registration-fields`)
    },
    async setRegistrationFields(
      eventId: string,
      fields: Record<string, { enabled: boolean; required: boolean; badges: string[] }>,
      order?: string[],
    ): Promise<{ fields: RegistrationFieldState[] }> {
      return request<{ fields: RegistrationFieldState[] }>(`/api/events/${eventId}/registration-fields`, {
        method: 'PUT',
        body: JSON.stringify({ fields, order: order ?? [] }),
      })
    },
    /** How this event's public form looks. Always complete: an event that
     *  was never styled comes back with the defaults resolved. */
    async getRegistrationTheme(eventId: string): Promise<{ theme: RegistrationTheme }> {
      return request<{ theme: RegistrationTheme }>(`/api/events/${eventId}/registration-theme`)
    },
    async setRegistrationTheme(
      eventId: string,
      theme: RegistrationTheme,
    ): Promise<{ theme: RegistrationTheme }> {
      return request<{ theme: RegistrationTheme }>(`/api/events/${eventId}/registration-theme`, {
        method: 'PUT',
        body: JSON.stringify(theme),
      })
    },
    /** How this event's pages are laid out in blocks (migration 032). A map of
     *  page -> blocks: "home" is the registration page, other keys are mini-site
     *  section slugs. `active` is false when the event never opted in: the map
     *  returned is then a starting point, not what visitors see — each page
     *  renders the classic layout until this is saved. */
    async getRegistrationLayout(
      eventId: string,
    ): Promise<{ layout: Record<string, unknown[]>; active: boolean }> {
      return request<{ layout: Record<string, unknown[]>; active: boolean }>(
        `/api/events/${eventId}/registration-layout`,
      )
    },
    /** Store the arrangement of every page. The server rebuilds each block from
     *  its closed sets before saving, so the returned map is the sanitized truth. */
    async setRegistrationLayout(
      eventId: string,
      pages: Record<string, unknown[]>,
    ): Promise<{ layout: Record<string, unknown[]>; active: boolean }> {
      return request<{ layout: Record<string, unknown[]>; active: boolean }>(
        `/api/events/${eventId}/registration-layout`,
        { method: 'PUT', body: JSON.stringify({ pages }) },
      )
    },
    /** Propose a whole configuration from a description of the event. Writes
     *  nothing — the answer is a draft the organizer applies or discards. */
    async suggestRegistrationForm(
      eventId: string,
      description: string,
    ): Promise<RegistrationProposal> {
      return request<RegistrationProposal>(`/api/events/${eventId}/registration-form/suggest`, {
        method: 'POST',
        body: JSON.stringify({ description }),
      })
    },
    /** This event's named audiences (point 13, v1). Empty on any deployment
     *  that never used badges — same shape either way. */
    async getRegistrationBadges(eventId: string): Promise<{ badges: RegistrationBadge[] }> {
      return request<{ badges: RegistrationBadge[] }>(`/api/events/${eventId}/registration-badges`)
    },
    /** Replaces the whole set — same contract as rooming presets. */
    async setRegistrationBadges(
      eventId: string,
      badges: { id?: string; name: string }[],
    ): Promise<{ badges: RegistrationBadge[] }> {
      return request<{ badges: RegistrationBadge[] }>(`/api/events/${eventId}/registration-badges`, {
        method: 'PUT',
        body: JSON.stringify({ badges }),
      })
    },
    /** What this event needs to know about its participants. Comes back with
     *  the catalogue so the screen never hardcodes labels or sections. */
    async getFieldPolicy(eventId: string): Promise<{
      policy: Record<string, FieldState>; catalogue: FieldPolicyEntry[]
    }> {
      return request<{ policy: Record<string, FieldState>; catalogue: FieldPolicyEntry[] }>(
        `/api/events/${eventId}/field-policy`
      )
    },
    async setFieldPolicy(eventId: string, policy: Record<string, FieldState>): Promise<{
      policy: Record<string, FieldState>; catalogue: FieldPolicyEntry[]
    }> {
      return request<{ policy: Record<string, FieldState>; catalogue: FieldPolicyEntry[] }>(
        `/api/events/${eventId}/field-policy`,
        { method: 'PUT', body: JSON.stringify({ policy }) }
      )
    },
    async getRegistrationExtras(eventId: string): Promise<{
      custom_fields: RegistrationCustomField[]; confirmations: RegistrationConfirmation[]
    }> {
      return request<{
        custom_fields: RegistrationCustomField[]; confirmations: RegistrationConfirmation[]
      }>(`/api/events/${eventId}/registration-extras`)
    },
    async setRegistrationExtras(eventId: string, payload: {
      custom_fields: RegistrationCustomField[]; confirmations: RegistrationConfirmation[]
    }): Promise<{ custom_fields: RegistrationCustomField[]; confirmations: RegistrationConfirmation[] }> {
      return request<{
        custom_fields: RegistrationCustomField[]; confirmations: RegistrationConfirmation[]
      }>(`/api/events/${eventId}/registration-extras`, {
        method: 'PUT',
        body: JSON.stringify(payload),
      })
    },
  },
  // Public, unauthenticated registration form (routers/public_registration.py).
  // These two calls MUST pass `anonymous: true`: every other call now
  // refuses to fire without a session, and a participant filling in this
  // form has no account at all.
  publicRegistration: {
    /** `custom_fields` and `confirmations` come back empty on a deployment
     *  without migration 010, which is also what an event that defined none
     *  looks like — the page renders the catalogue and nothing else. */
    async getInfo(token: string, lang = 'fr', badge?: string | null): Promise<{
      event_id: string; event_name: string; is_open: boolean
      fields: RegistrationFieldState[]
      custom_fields?: RegistrationCustomField[]
      confirmations?: RegistrationConfirmation[]
      locale?: string
      supported_locales?: string[]
      sections?: EventSiteSection[]
      attachments?: RegistrationAttachmentRequest[]
      logo_url?: string | null
      theme?: RegistrationTheme
      layout?: Record<string, unknown[]>
    }> {
      const badgeParam = badge ? `&badge=${encodeURIComponent(badge)}` : ''
      return request<{
        event_id: string; event_name: string; is_open: boolean
        fields: RegistrationFieldState[]
        custom_fields?: RegistrationCustomField[]
        confirmations?: RegistrationConfirmation[]
        locale?: string
        supported_locales?: string[]
        sections?: EventSiteSection[]
        attachments?: RegistrationAttachmentRequest[]
        logo_url?: string | null
        theme?: RegistrationTheme
        layout?: Record<string, unknown[]>
      }>(`/api/public/register/${token}?lang=${encodeURIComponent(lang)}${badgeParam}`, { anonymous: true })
    },
    /** Upload before submitting: the participant does not exist yet, so the
     *  file is stored unclaimed and bound to the registration that references
     *  it. An upload nobody completed is a row to sweep, not a document. */
    async uploadAttachment(
      token: string, kind: string, file: File, lang = 'fr',
    ): Promise<UploadedAttachment> {
      const form = new FormData()
      form.append('kind', kind)
      form.append('file', file)
      return request<UploadedAttachment>(
        `/api/public/register/${token}/attachment?lang=${encodeURIComponent(lang)}`,
        { method: 'POST', anonymous: true, body: form },
      )
    },
    async submit(
      token: string, payload: Record<string, unknown>, lang = 'fr', badge?: string | null,
    ): Promise<{ status: string; message: string }> {
      const badgeParam = badge ? `&badge=${encodeURIComponent(badge)}` : ''
      return request<{ status: string; message: string }>(
        `/api/public/register/${token}?lang=${encodeURIComponent(lang)}${badgeParam}`,
        { method: 'POST', anonymous: true, body: JSON.stringify(payload) }
      )
    },
  },
  exports: {
    async create(eventId: string, runId?: string): Promise<Export> {
      return request<Export>(`/api/events/${eventId}/exports`, {
        method: 'POST',
        body: JSON.stringify({ run_id: runId || null }),
      })
    },

    async getDownloadUrl(exportId: string): Promise<{ signed_url: string; expires_at: string; filename: string }> {
      return request<{ signed_url: string; expires_at: string; filename: string }>(
        `/api/exports/${exportId}/download`
      )
    },

    /** Generate the signed URL and actually put the file on disk.
     *
     *  `?download=` is what makes Storage answer with an attachment header —
     *  without it the browser navigates to the URL and an .xlsx either opens
     *  in a tab or silently does nothing, which is exactly what "l'export est
     *  généré mais rien ne se télécharge" looks like from the outside. */
    async saveToDisk(exportId: string): Promise<string> {
      const { signed_url, filename } = await api.exports.getDownloadUrl(exportId)
      const separator = signed_url.includes('?') ? '&' : '?'
      const url = `${signed_url}${separator}download=${encodeURIComponent(filename)}`

      const anchor = document.createElement('a')
      anchor.href = url
      anchor.rel = 'noopener'
      document.body.appendChild(anchor)
      anchor.click()
      anchor.remove()
      return filename
    },
  },

  // Project-scoped assistant (Feedback V1 §7). `answered: false` means the
  // assistant declined — show `answer` as-is, never retry with a looser
  // prompt: refusing to guess is the feature, not a failure.
  chat: {
    /** `history` lets follow-ups resolve ("et parmi eux, combien sont
     *  français ?"). It only steers which query is composed — the figures in
     *  the answer always come from a fresh read. */
    async ask(
      eventId: string,
      question: string,
      history: { question: string }[] = [],
      conversationId?: string | null,
    ): Promise<ChatAnswer> {
      return request<ChatAnswer>(`/api/events/${eventId}/chat`, {
        method: 'POST',
        // `history` is still sent so a deployment without migration 019 keeps
        // resolving follow-ups. Once conversation_id names a stored thread the
        // server ignores it and reads its own record instead.
        body: JSON.stringify({ question, history, conversation_id: conversationId ?? null }),
      })
    },

    /** My threads on this event — mine, not the team's. */
    async conversations(eventId: string): Promise<ChatConversationSummary[]> {
      return request<ChatConversationSummary[]>(`/api/events/${eventId}/chat/conversations`)
    },
    async transcript(conversationId: string): Promise<ChatTranscript> {
      return request<ChatTranscript>(`/api/chat/conversations/${conversationId}`)
    },
    async forget(conversationId: string): Promise<void> {
      await request(`/api/chat/conversations/${conversationId}`, { method: 'DELETE' })
    },
    async suggestions(eventId: string): Promise<{ questions: string[]; capabilities: string[] }> {
      return request<{ questions: string[]; capabilities: string[] }>(
        `/api/events/${eventId}/chat/suggestions`
      )
    },
  },

  exceptions: {
    async list(eventId: string): Promise<Exception[]> {
      const list = await request<any[]>(`/api/events/${eventId}/exceptions`)
      return list.map(mapException)
    },

    /** Just the two numbers the sidebar badge needs.
     *
     *  Counted server-side because "open" is a server-side rule: exceptions
     *  carry whatever the consolidation that wrote them considered a gap, and
     *  the field policy is applied again on read. A browser counting rows
     *  straight out of the table cannot see that rule, which is how the badge
     *  came to read 77 next to a page listing 14. */
    async count(eventId: string): Promise<{ open: number; overdue: number }> {
      return request<{ open: number; overdue: number }>(
        `/api/events/${eventId}/exceptions/count`
      )
    },

    async resolve(exceptionId: string, resolution: string): Promise<void> {
      await request(`/api/exceptions/${exceptionId}/resolve`, {
        method: 'POST',
        body: JSON.stringify({ resolution }),
      })
    },
  },

  flights: {
    async list(eventId: string): Promise<any[]> {
      return request<any[]>(`/api/events/${eventId}/flights`)
    },
    async create(eventId: string, payload: {
      participant_id: string
      flight_number: string
      departure_airport: string
      arrival_airport: string
      departure_time: string
      arrival_time: string
      airline?: string
      pnr_code?: string
      baggage_info?: string
      status?: string
    }): Promise<any> {
      return request<any>(`/api/events/${eventId}/flights`, {
        method: 'POST',
        body: JSON.stringify(payload),
      })
    },
    async extract(eventId: string): Promise<any> {
      return request<any>(`/api/events/${eventId}/flights/extract`, {
        method: 'POST',
      })
    },
  },

  hotels: {
    async list(eventId: string): Promise<any[]> {
      return request<any[]>(`/api/events/${eventId}/hotels`)
    },
    async create(eventId: string, payload: any): Promise<any> {
      return request<any>(`/api/events/${eventId}/hotels`, {
        method: 'POST',
        body: JSON.stringify(payload),
      })
    },
    async listRooming(eventId: string): Promise<any[]> {
      return request<any[]>(`/api/events/${eventId}/hotels/rooming`)
    },
    async assignRooming(eventId: string, payload: any): Promise<any> {
      return request<any>(`/api/events/${eventId}/hotels/rooming`, {
        method: 'POST',
        body: JSON.stringify(payload),
      })
    },
    async assignRoomingBulk(eventId: string, payload: any): Promise<any> {
      return request<any>(`/api/events/${eventId}/hotels/rooming/bulk`, {
        method: 'POST',
        body: JSON.stringify(payload),
      })
    },
    async deleteRooming(roomingId: string): Promise<any> {
      return request<any>(`/api/hotels/rooming/${roomingId}`, {
        method: 'DELETE',
      })
    },
    /** hotel_id / room_type / status only — a night's DATE and its
     *  participant are not patchable fields, because a stay is really a range
     *  of these rows. Changing either is a create-here/delete-there, which
     *  the editor does by composing this with assignRooming/deleteRooming. */
    async updateRoomingNight(
      roomingId: string,
      patch: { hotel_id?: string; room_type?: string; status?: string }
    ): Promise<any> {
      return request<any>(`/api/hotels/rooming/${roomingId}`, {
        method: 'PATCH',
        body: JSON.stringify(patch),
      })
    },
  },

  transfers: {
    async list(eventId: string): Promise<Transfer[]> {
      return request<Transfer[]>(`/api/events/${eventId}/transfers`)
    },
    async update(transferId: string, patch: TransferPatch): Promise<Transfer> {
      return request<Transfer>(`/api/transfers/${transferId}`, {
        method: 'PATCH',
        body: JSON.stringify(patch),
      })
    },
    async remove(transferId: string): Promise<void> {
      await request(`/api/transfers/${transferId}`, { method: 'DELETE' })
    },
    /** The same edit on many transfers, in ONE request.
     *
     *  Replaces a Promise.all over update(): a few hundred parallel PATCHes
     *  is a few hundred access checks, and the first rejection abandoned the
     *  batch on the client while the rest carried on — leaving some rows
     *  changed, some not, and nothing on screen saying which.
     *
     *  `skipped` lists ids the server would not touch (another event, or
     *  already deleted), so a stale tab reports instead of pretending. */
    async bulkUpdate(
      eventId: string,
      transferIds: string[],
      patch: TransferPatch,
    ): Promise<{ updated: number; skipped: string[] }> {
      return request(`/api/events/${eventId}/transfers/bulk-update`, {
        method: 'POST',
        body: JSON.stringify({ transfer_ids: transferIds, patch }),
      })
    },
    /** The plan the flights imply. Writes nothing — `apply` does that, and
     *  only with the groups the organizer kept. */
    async propose(eventId: string): Promise<TransferPlan> {
      return request<TransferPlan>(`/api/events/${eventId}/transfers/propose`, { method: 'POST' })
    },
    async apply(eventId: string, groups: TransferGroup[]): Promise<{ written: number; skipped: number }> {
      return request<{ written: number; skipped: number }>(`/api/events/${eventId}/transfers/apply`, {
        method: 'POST',
        body: JSON.stringify({ groups }),
      })
    },
    async getSettings(eventId: string): Promise<TransferSettings> {
      return request<TransferSettings>(`/api/events/${eventId}/transfer-settings`)
    },
    async setSettings(eventId: string, settings: TransferSettings): Promise<TransferSettings> {
      return request<TransferSettings>(`/api/events/${eventId}/transfer-settings`, {
        method: 'PUT',
        body: JSON.stringify(settings),
      })
    },
  },

  rooming: {
    /** The list as it was GENERATED — not as the data reads today. Comes back
     *  with `stale` and the diff, so the screen can say what has moved without
     *  quietly showing a newer list under an older version number. */
    async list(eventId: string): Promise<RoomingList> {
      return request<RoomingList>(`/api/events/${eventId}/rooming-list`)
    },

    /** What generating would produce right now. Reads only — this is what
     *  turns "Regenerate" from a leap into a decision. */
    async preview(eventId: string, options: RoomingOptions = {}): Promise<RoomingPreview> {
      const query = new URLSearchParams()
      if (options.start_number !== undefined) query.set('start_number', String(options.start_number))
      if (options.prefix) query.set('prefix', options.prefix)
      if (options.renumber) query.set('renumber', 'true')
      if (options.default_room_type) query.set('default_room_type', options.default_room_type)
      const suffix = query.toString() ? `?${query}` : ''
      return request<RoomingPreview>(`/api/events/${eventId}/rooming-list/preview${suffix}`)
    },

    /** Make the list. The only thing in the system that does. */
    async generate(eventId: string, options: RoomingOptions = {}): Promise<RoomingGeneration> {
      return request<RoomingGeneration>(`/api/events/${eventId}/rooming-list/generate`, {
        method: 'POST',
        body: JSON.stringify(options),
      })
    },

    /** Kept, not overwritten: a hotel holding version 3 must still be
     *  answerable when the office is looking at version 5. */
    async versions(eventId: string): Promise<{ versions: RoomingVersion[]; available: boolean }> {
      return request<{ versions: RoomingVersion[]; available: boolean }>(
        `/api/events/${eventId}/rooming-list/versions`
      )
    },

    /** Saved numbering conventions (point 4) — 'start at 301, prefix B-' kept
     *  once per event instead of retyped on every visit to this page. */
    async getPresets(eventId: string): Promise<{ presets: RoomingPreset[] }> {
      return request<{ presets: RoomingPreset[] }>(`/api/events/${eventId}/rooming-presets`)
    },
    /** Replaces the whole set — deleting one on screen and saving deletes it
     *  here too, the same contract transfer-settings already uses. */
    async setPresets(eventId: string, presets: RoomingPreset[]): Promise<{ presets: RoomingPreset[] }> {
      return request<{ presets: RoomingPreset[] }>(`/api/events/${eventId}/rooming-presets`, {
        method: 'PUT',
        body: JSON.stringify({ presets }),
      })
    },

    /** Read the hotel's own file. Writes nothing: the numbers they send back
     *  are theirs, and a file with a shifted header row would otherwise move
     *  ninety people into the wrong rooms before anybody saw it. */
    async importPreview(eventId: string, file: File): Promise<RoomingImportPreview> {
      const form = new FormData()
      form.append('file', file)
      return request<RoomingImportPreview>(`/api/events/${eventId}/rooming-list/import/preview`, {
        method: 'POST',
        body: form,
        headers: {}, // let browser set Content-Type with boundary
      })
    },

    /** Write the lines somebody looked at and accepted. Sends back what was
     *  shown rather than the file, so a second upload in between cannot change
     *  what gets saved. */
    async importApply(
      eventId: string,
      lines: { participant_id: string; room_number: string; room_type?: string }[],
    ): Promise<RoomingImportResult> {
      return request<RoomingImportResult>(`/api/events/${eventId}/rooming-list/import`, {
        method: 'POST',
        body: JSON.stringify({ lines, lock: true }),
      })
    },
  },

  supplierExports: {
    /** The profiles come back WITH their columns: somebody about to email a
     *  file to an outside company should see what is in it beforehand. */
    async profiles(eventId: string): Promise<{ profiles: SupplierProfile[] }> {
      return request<{ profiles: SupplierProfile[] }>(`/api/events/${eventId}/exports/suppliers`)
    },
    async create(eventId: string, profile: string, columns: string[] = []): Promise<Export> {
      return request<Export>(`/api/events/${eventId}/exports/supplier`, {
        method: 'POST',
        body: JSON.stringify({ profile, columns }),
      })
    },
    async updates(eventId: string): Promise<{ changes: ExportChange[]; summary: ExportChangeSummary }> {
      return request<{ changes: ExportChange[]; summary: ExportChangeSummary }>(
        `/api/events/${eventId}/exports/updates`
      )
    },
  },

  notes: {
    async list(eventId: string, participantId: string): Promise<ParticipantNotes> {
      return request<ParticipantNotes>(`/api/events/${eventId}/participants/${participantId}/notes`)
    },
    async add(eventId: string, participantId: string, payload: {
      body: string; category: string; include_in_export: boolean; preset_id?: string | null
    }): Promise<ParticipantNote> {
      return request<ParticipantNote>(`/api/events/${eventId}/participants/${participantId}/notes`, {
        method: 'POST',
        body: JSON.stringify(payload),
      })
    },
    async remove(eventId: string, participantId: string, noteId: string): Promise<{ message: string }> {
      return request<{ message: string }>(
        `/api/events/${eventId}/participants/${participantId}/notes/${noteId}`,
        { method: 'DELETE' }
      )
    },
    /** The event's named notes. Empty on any deployment without migration 028. */
    async getPresets(eventId: string): Promise<{ presets: NotePreset[] }> {
      return request<{ presets: NotePreset[] }>(`/api/events/${eventId}/note-presets`)
    },
    /** Replaces the whole set — same contract as rooming presets. */
    async setPresets(
      eventId: string,
      presets: { id?: string; name: string; body?: string; color?: string; category?: string }[],
    ): Promise<{ presets: NotePreset[] }> {
      return request<{ presets: NotePreset[] }>(`/api/events/${eventId}/note-presets`, {
        method: 'PUT',
        body: JSON.stringify({ presets }),
      })
    },
  },

  activities: {
    async list(eventId: string): Promise<any[]> {
      return request<any[]>(`/api/events/${eventId}/activities`)
    },
    async create(eventId: string, payload: any): Promise<any> {
      return request<any>(`/api/events/${eventId}/activities`, {
        method: 'POST',
        body: JSON.stringify(payload),
      })
    },
    async listParticipants(activityId: string): Promise<any[]> {
      return request<any[]>(`/api/activities/${activityId}/participants`)
    },
    async register(activityId: string, participantId: string): Promise<any> {
      return request<any>(`/api/activities/${activityId}/register?participant_id=${participantId}`, {
        method: 'POST',
      })
    },
    async unregister(activityId: string, participantId: string): Promise<any> {
      return request<any>(`/api/activities/${activityId}/unregister/${participantId}`, {
        method: 'DELETE',
      })
    },
  },

  reports: {
    async getSummary(eventId: string): Promise<any> {
      return request<any>(`/api/events/${eventId}/reports/summary`)
    },
    async getHotelNights(eventId: string): Promise<any[]> {
      return request<any[]>(`/api/events/${eventId}/reports/hotel-nights`)
    },
    async getAnalysis(eventId: string, aiSummary = false): Promise<any> {
      return request<any>(`/api/events/${eventId}/reports/analysis${aiSummary ? '?ai_summary=true' : ''}`)
    },
  },

  /** Everything the dashboard shows, computed server-side in one place.
   *  A figure that could not be computed comes back null — the page omits it
   *  rather than displaying a placeholder as data. */
  dashboard: {
    async get(eventId: string): Promise<DashboardData> {
      return request<DashboardData>(`/api/events/${eventId}/dashboard`)
    },
  },

  masterList: {
    async get(eventId: string): Promise<{ items: any[]; total: number }> {
      return request<{ items: any[]; total: number }>(`/api/events/${eventId}/master-list`)
    },
  },

  posters: {
    async analyze(eventId: string, file: File): Promise<{ fields?: Record<string, any>; error?: string }> {
      const form = new FormData()
      form.append('file', file)
      return request(`/api/events/${eventId}/posters/analyze`, { method: 'POST', body: form, headers: {} })
    },
  },

  campaigns: {
    /** `participant_ids` empty (or absent) addresses every participant of the
     *  event; naming one is the individual letter. Both go through the same
     *  personalisation and land in the same tracking table. */
    async preview(eventId: string, payload: { mode: string; subject: string; body: string; instructions: string; participant_ids?: string[] }): Promise<{
      recipient_count: number; without_email: number; samples: { to: string; name: string; subject: string; body: string }[]
    }> {
      return request(`/api/events/${eventId}/campaigns/preview`, { method: 'POST', body: JSON.stringify(payload) })
    },
    async send(eventId: string, payload: { mode: string; subject: string; body: string; instructions: string; send: boolean; participant_ids?: string[] }): Promise<{
      generated: number; sent: number; skipped_no_email: number; errors: number; provider: string | null; delivered: boolean
    }> {
      return request(`/api/events/${eventId}/campaigns/send`, { method: 'POST', body: JSON.stringify(payload) })
    },
  },

  globalParticipants: {
    async getHistory(email: string): Promise<any[]> {
      return request<any[]>(`/api/global-participants/history?email=${encodeURIComponent(email)}`)
    },
  },

  emailAgent: {
    async list(eventId: string): Promise<EmailProposal[]> {
      return request<EmailProposal[]>(`/api/events/${eventId}/email-agent`)
    },
    async analyze(eventId: string, sender: string, subject: string, body: string): Promise<EmailProposal> {
      return request<EmailProposal>(`/api/events/${eventId}/email-agent/analyze`, {
        method: 'POST',
        body: JSON.stringify({ sender, subject, body }),
      })
    },
    async apply(proposalId: string): Promise<void> {
      await request(`/api/email-agent/${proposalId}/apply`, {
        method: 'POST',
      })
    },
    async reject(proposalId: string): Promise<void> {
      await request(`/api/email-agent/${proposalId}/reject`, {
        method: 'POST',
      })
    },
  },

  communications: {
    async generateConfirmation(eventId: string, participantId: string): Promise<{
      communication: any | null
      persisted: boolean
      subject: string
      body: string
      facts: Record<string, any>
      missing: string[]
      source: string
    }> {
      return request(`/api/events/${eventId}/participants/${participantId}/confirmation/generate`, { method: 'POST' })
    },
    /** §16 — the participant's own copy. A functional document: the design
     *  work comes later, and nothing on it is invented.
     *
     *  `name` is the fallback filename, built here from the fiche the caller
     *  already has on screen. The server sends the authoritative one in
     *  Content-Disposition, but that header is only readable cross-origin when
     *  the API exposes it — and forty files called "confirmation.pdf" in one
     *  downloads folder is not a recoverable situation for the person sorting
     *  them. */
    async downloadConfirmationPdf(
      eventId: string, participantId: string, lang = 'fr', name = ''
    ): Promise<void> {
      const slug = name.trim()
        .normalize('NFKD').replace(/[̀-ͯ]/g, '')   // fold the accents
        .replace(/[^A-Za-z0-9]+/g, '_').replace(/^_|_$/g, '')
      return downloadFile(
        `/api/events/${eventId}/participants/${participantId}/confirmation/pdf?lang=${lang}`,
        slug ? `Confirmation_${slug}.pdf` : 'Confirmation.pdf'
      )
    },
    async list(eventId: string): Promise<any[]> {
      return request<any[]>(`/api/events/${eventId}/communications`)
    },
    async update(id: string, payload: { subject?: string; body?: string; status?: string }): Promise<any> {
      return request(`/api/communications/${id}`, { method: 'PATCH', body: JSON.stringify(payload) })
    },
    async send(id: string): Promise<any> {
      return request(`/api/communications/${id}/send`, { method: 'POST' })
    },
  },

  /** §19 — who changed what, when, and where the new value came from. */
  history: {
    async list(eventId: string, filters: HistoryFilters = {}): Promise<HistoryPage> {
      const query = new URLSearchParams()
      for (const [key, value] of Object.entries(filters)) {
        if (value !== undefined && value !== '') query.set(key, String(value))
      }
      const suffix = query.toString() ? `?${query}` : ''
      return request<HistoryPage>(`/api/events/${eventId}/history${suffix}`)
    },
  },

  /** §9 — the passport copies and photos the form collected.
   *
   *  The bytes are streamed through the API rather than served from a signed
   *  URL: a URL outlives the check that produced it and travels into browser
   *  history and pasted messages, which is the wrong property for an identity
   *  document. */
  attachments: {
    async list(eventId: string, participantId?: string): Promise<AttachmentList> {
      const suffix = participantId ? `?participant_id=${encodeURIComponent(participantId)}` : ''
      return request<AttachmentList>(`/api/events/${eventId}/attachments${suffix}`)
    },
    async download(eventId: string, attachmentId: string, fallbackName: string): Promise<void> {
      await downloadFile(
        `/api/events/${eventId}/attachments/${attachmentId}/download`,
        fallbackName
      )
    },
    async remove(eventId: string, attachmentId: string): Promise<void> {
      await request(`/api/events/${eventId}/attachments/${attachmentId}`, { method: 'DELETE' })
    },
  },

  /** §14 — turning an exception into a question. Prepares drafts; never sends.
   *  Delivery goes through communications.send, like everything else. */
  /** Nights outside the programme's dates, told to each person individually.
   *
   *  A grouped send of individual letters: one email each, in their own
   *  language, carrying their own flight dates and their own night count.
   *  Never a mail-merge with a shared list — a delegate reading that
   *  thirty-five colleagues are also extending learns nothing they need. */
  ownExpenseNotices: {
    async preview(eventId: string, options: OwnExpenseNoticeOptions = {}): Promise<OwnExpenseNoticePlan> {
      return request<OwnExpenseNoticePlan>(`/api/events/${eventId}/own-expense-notices/preview`, {
        method: 'POST',
        body: JSON.stringify({ participant_ids: [], ...options }),
      })
    },
    /** Stores the letters as drafts. Sending stays a separate, deliberate act
     *  from the Communications list, exactly like an information request. */
    async create(eventId: string, options: OwnExpenseNoticeOptions = {}): Promise<OwnExpenseNoticeResult> {
      return request<OwnExpenseNoticeResult>(`/api/events/${eventId}/own-expense-notices`, {
        method: 'POST',
        body: JSON.stringify({ participant_ids: [], ...options }),
      })
    },
  },

  informationRequests: {
    async preview(eventId: string, options: InformationRequestOptions = {}): Promise<InformationRequestPlan> {
      return request<InformationRequestPlan>(`/api/events/${eventId}/information-requests/preview`, {
        method: 'POST',
        body: JSON.stringify({ ...EMPTY_SELECTION, ...options }),
      })
    },
    async create(eventId: string, options: InformationRequestOptions = {}): Promise<InformationRequestResult> {
      return request<InformationRequestResult>(`/api/events/${eventId}/information-requests`, {
        method: 'POST',
        body: JSON.stringify({ ...EMPTY_SELECTION, ...options }),
      })
    },
  },

  projects: {
    async list(): Promise<any[]> {
      return request<any[]>('/api/projects')
    },
    async create(payload: { name: string; client_name: string }): Promise<any> {
      return request<any>('/api/projects', {
        method: 'POST',
        body: JSON.stringify(payload),
      })
    },
    async delete(projectId: string): Promise<void> {
      await request(`/api/projects/${projectId}`, { method: 'DELETE' })
    },
  },

  sharing: {
    async listMembers(projectId: string): Promise<ProjectMember[]> {
      return request<ProjectMember[]>(`/api/projects/${projectId}/members`)
    },
    async addMember(
      projectId: string,
      payload: { email: string; access_level: 'viewer' | 'editor'; event_ids?: string[] | null }
    ): Promise<ProjectMember> {
      return request<ProjectMember>(`/api/projects/${projectId}/members`, {
        method: 'POST',
        body: JSON.stringify(payload),
      })
    },
    async updateMember(
      projectId: string,
      memberId: string,
      patch: { access_level?: 'viewer' | 'editor'; event_ids?: string[] }
    ): Promise<ProjectMember> {
      return request<ProjectMember>(`/api/projects/${projectId}/members/${memberId}`, {
        method: 'PATCH',
        body: JSON.stringify(patch),
      })
    },
    async removeMember(projectId: string, memberId: string): Promise<void> {
      await request(`/api/projects/${projectId}/members/${memberId}`, { method: 'DELETE' })
    },
  },

  mail: {
    async status(eventId: string): Promise<MailStatus> {
      return request<MailStatus>(`/api/events/${eventId}/mail/status`)
    },
    async authorize(eventId: string, provider: MailProvider, locale: string): Promise<{ authorization_url: string }> {
      return request<{ authorization_url: string }>(
        `/api/events/${eventId}/mail/authorize${qs({ provider, locale })}`
      )
    },
    async sync(eventId: string, provider: MailProvider): Promise<{ synced: number; provider: string }> {
      return request<{ synced: number; provider: string }>(
        `/api/events/${eventId}/mail/sync${qs({ provider })}`,
        { method: 'POST' }
      )
    },
    async disconnect(eventId: string, provider: MailProvider): Promise<void> {
      await request(`/api/events/${eventId}/mail/disconnect${qs({ provider })}`, { method: 'POST' })
    },
  },

  eventGrouping: {
    async suggestions(): Promise<EventMergeSuggestion[]> {
      return request<EventMergeSuggestion[]>(`/api/org/event-merge-suggestions`)
    },
    async merge(canonicalEventId: string, mergeEventIds: string[]): Promise<{ merged: number; message: string }> {
      return request<{ merged: number; message: string }>(`/api/events/merge`, {
        method: 'POST',
        body: JSON.stringify({ canonical_event_id: canonicalEventId, merge_event_ids: mergeEventIds }),
      })
    },
  },

  matching: {
    async candidates(eventId: string, includeResolved = false): Promise<MatchCandidate[]> {
      return request<MatchCandidate[]>(
        `/api/events/${eventId}/match-candidates${qs({ include_resolved: includeResolved })}`
      )
    },
    async resolve(
      candidateId: string,
      decision: 'fusionner' | 'separer',
      keep?: Record<string, string>
    ): Promise<{ status: string; message: string }> {
      return request<{ status: string; message: string }>(`/api/match-candidates/${candidateId}`, {
        method: 'PUT',
        body: JSON.stringify(keep ? { decision, keep } : { decision }),
      })
    },
  },
}
