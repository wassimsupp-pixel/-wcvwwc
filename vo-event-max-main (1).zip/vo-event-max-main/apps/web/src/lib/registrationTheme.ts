/**
 * How a public registration form looks — the one description of it, shared by
 * the page that renders it and the editor that previews it.
 *
 * There are two renderers for this data: the real form at /register/[token],
 * and the live preview inside the organizer's editor. The whole value of a
 * preview is that it is trustworthy, so the two must never be able to disagree
 * — which they would within a week if each mapped `font: 'slab'` to a stack of
 * its own. Every mapping lives here and both call the same function.
 *
 * ## Why this overrides the app's own variables
 *
 * The form page was already written entirely in terms of `--color-accent`,
 * `--color-text-primary`, `--color-border` and nine others. So theming it does
 * not mean rewriting a thousand lines of className — it means redefining those
 * twelve variables on one wrapper. A custom property set on an element cascades
 * to its whole subtree, so the form re-themes itself and every control added to
 * it later is themed by default, with nobody having to remember to use a
 * different variable name.
 *
 * That also keeps the blast radius exact: the variables are redefined on the
 * registration wrapper, never on `:root`, so nothing else in the app can be
 * repainted by an organizer's colour choice.
 *
 * The API sanitizes on the way in and resolves on the way out
 * (services/registration_theme.py), so what arrives is always complete and
 * always a key from a closed set. `resolveTheme` still defaults every lookup,
 * for the one case the API cannot cover: a tab held open across a deploy that
 * added a key.
 */

export interface RegistrationThemeHeader {
  style: 'title' | 'image' | 'banner'
  image_url: string
  title: string
  subtitle: string
  align: 'left' | 'center'
  height: 'compact' | 'tall'
}

export interface RegistrationTheme {
  font: 'sans' | 'grotesk' | 'serif' | 'slab' | 'rounded'
  accent: string
  surface: 'light' | 'soft' | 'dark'
  corners: 'sharp' | 'soft' | 'round'
  /** A photo behind the whole page. Empty = the surface's plain gradient. */
  background_image: string
  header: RegistrationThemeHeader
}

export const FONTS = ['sans', 'grotesk', 'serif', 'slab', 'rounded'] as const
export const SURFACE_NAMES = ['light', 'soft', 'dark'] as const
export const CORNER_NAMES = ['sharp', 'soft', 'round'] as const
export const HEADER_STYLES = ['title', 'image', 'banner'] as const

export const DEFAULT_THEME: RegistrationTheme = {
  font: 'sans',
  accent: '#2563eb',
  surface: 'light',
  corners: 'soft',
  background_image: '',
  header: { style: 'title', image_url: '', title: '', subtitle: '', align: 'center', height: 'compact' },
}

/** The five typefaces, as the CSS variables `[locale]/layout.tsx` declares.
 *  Each falls back to something already on the machine, so a font that fails
 *  to load costs the page its personality and not its legibility. */
export const FONT_STACKS: Record<RegistrationTheme['font'], string> = {
  sans: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  grotesk: "var(--font-grotesk), 'Inter', sans-serif",
  serif: "var(--font-serif), Georgia, 'Times New Roman', serif",
  slab: "var(--font-slab), Georgia, serif",
  rounded: "var(--font-rounded), 'Inter', sans-serif",
}

export const RADII: Record<RegistrationTheme['corners'], string> = {
  sharp: '2px',
  soft: '14px',
  round: '26px',
}

/**
 * An sRGB blend of two hex colours, `ratio` of the first.
 *
 * This is `color-mix(in srgb, a ratio%, b)` done in JavaScript, and it is done
 * here for one reason: `color-mix` only reached Chrome 111 / Safari 16.2 in
 * 2023, and an unsupported CSS function does not degrade politely. The whole
 * declaration is dropped — so a page whose background is a gradient between two
 * mixed colours loses its background, on the one page in this product that a
 * member of the public opens on whatever phone they own.
 */
const HEX = /^#[0-9a-f]{6}$/i

/** A usable `#rrggbb`, or the default. Anything half-typed resolves here. */
function usableAccent(value: string | undefined): string {
  return HEX.test(value ?? '') ? (value as string).toLowerCase() : DEFAULT_THEME.accent
}

export function mix(a: string, b: string, ratio: number): string {
  const channel = (hex: string, at: number) => parseInt(hex.slice(at, at + 2), 16)
  const blend = (at: number) =>
    Math.round(channel(a, at) * ratio + channel(b, at) * (1 - ratio))
      .toString(16)
      .padStart(2, '0')
  return '#' + blend(1) + blend(3) + blend(5)
}

const WHITE = '#ffffff'
const NIGHT = '#0b1120'
const NIGHT_CARD = '#16203a'

/**
 * The page behind the form.
 *
 * `soft` and `dark` mix their tints FROM the accent rather than holding
 * colours of their own, which is what makes one colour picker restyle a whole
 * page: an organizer who pastes their client's blue gets a faintly blue page,
 * not a blue button sitting on grey.
 */
function surfaceVariables(
  surface: RegistrationTheme['surface'],
  accent: string,
): Record<string, string> {
  if (surface === 'dark') {
    return {
      // The two accent tints are mixed toward white by default, which is right
      // on a white page and wrong here: it produced a pale header band carrying
      // white text on an otherwise dark card. A dark page tints its own accents
      // toward its own background.
      '--color-accent-light': mix(accent, NIGHT_CARD, 0.3),
      '--color-cta-light': mix(accent, NIGHT, 0.14),
      '--color-page-from': mix(accent, NIGHT, 0.22),
      '--color-page-to': NIGHT,
      '--color-surface': '#151f35',
      '--color-input': '#1b2740',
      '--color-text-primary': '#e8edf7',
      '--color-text-secondary': '#93a3bd',
      '--color-border': '#25324c',
      '--color-bg-subtle': '#101a2e',
    }
  }
  if (surface === 'soft') {
    return {
      '--color-page-from': mix(accent, WHITE, 0.26),
      '--color-page-to': mix(accent, WHITE, 0.06),
      '--color-surface': WHITE,
      '--color-input': mix(accent, WHITE, 0.04),
      '--color-text-primary': '#101a2b',
      '--color-text-secondary': '#5b6b82',
      '--color-border': mix(accent, WHITE, 0.2),
      '--color-bg-subtle': mix(accent, WHITE, 0.07),
    }
  }
  return {
    '--color-page-from': mix(accent, WHITE, 0.12),
    '--color-page-to': WHITE,
    '--color-surface': WHITE,
    '--color-input': WHITE,
    '--color-text-primary': '#0f172a',
    '--color-text-secondary': '#64748b',
    '--color-border': '#e2e8f0',
    '--color-bg-subtle': '#f8fafc',
  }
}

/** The two inks the accent's text is ever set in. Near-black rather than pure
 *  black, which reads as ink instead of as a hole. */
const DARK_INK = '#111827'
const LIGHT_INK = '#ffffff'

/** WCAG relative luminance of an `#rrggbb`. */
function luminanceOf(hex: string): number {
  const channel = (at: number) => {
    const srgb = parseInt(hex.slice(at, at + 2), 16) / 255
    return srgb <= 0.03928 ? srgb / 12.92 : Math.pow((srgb + 0.055) / 1.055, 2.4)
  }
  return 0.2126 * channel(1) + 0.7152 * channel(3) + 0.0722 * channel(5)
}

/** WCAG contrast ratio between two luminances. */
function contrastBetween(a: number, b: number): number {
  const [hi, lo] = a > b ? [a, b] : [b, a]
  return (hi + 0.05) / (lo + 0.05)
}

/**
 * Dark ink or light, whichever actually reads ON the accent colour.
 *
 * Without this, a pale brand yellow gets white text and the submit button —
 * the one control the whole page exists to get clicked — becomes unreadable.
 *
 * The two ratios are computed and compared rather than thresholded on
 * "is this colour light?". Luminance is not linear in brightness: the point
 * where white and black read equally well sits near 0.18, nowhere near the
 * middle, so any eyeballed threshold puts white text on a whole band of
 * mid-tone colours where dark ink reads more than twice as well.
 */
export function onAccent(hex: string): string {
  const value = usableAccent(hex)
  const background = luminanceOf(value)
  return contrastBetween(background, luminanceOf(DARK_INK)) >=
    contrastBetween(background, luminanceOf(LIGHT_INK))
    ? DARK_INK
    : LIGHT_INK
}

/** WCAG AA for text this size. Below it, a label is legible to somebody with
 *  good eyesight on a good screen and to nobody else. */
export const AA_CONTRAST = 4.5

/**
 * How well the submit button's label reads on the chosen accent.
 *
 * Worth exposing because no ink can rescue every colour: two inks at the
 * extremes of the scale still leave a band of mid-tones — around luminance
 * 0.18 — where the best available contrast is about 4.48:1, just under AA.
 * Picking the better ink is all the code can do; telling the organizer their
 * brand colour lands in that band is the part that actually helps, because
 * they are the only one who can decide to darken it.
 */
export function accentContrast(hex: string): number {
  const value = usableAccent(hex)
  return contrastBetween(luminanceOf(value), luminanceOf(onAccent(value)))
}

/**
 * The ink, once a photo is behind the page.
 *
 * `pageBackground` veils the photo into a known range — whatever the picture,
 * nothing below 0.48 relative luminance on a light surface and nothing above
 * 0.07 on a dark one — and these inks are the ones that clear AA against the
 * WORST end of that range: 9.4:1 and 5.2:1 for a light page, measured against
 * an all-black photo, and 6.0:1 for a dark page against an all-white one.
 *
 * The theme's ordinary inks do not, which is the whole report. Measured on the
 * form this came from: #0f172a over a dark photo under the old scrim read
 * 1.16:1 — the page was there and the words were not. Nor can veiling alone
 * rescue the ordinary secondary grey: holding AA for #64748b needs a 97% veil,
 * which is not a background photo any more. The ink has to move with it.
 *
 * Borders and the subtle band go translucent for the opposite reason: at full
 * opacity they paint flat panels over the photo somebody just uploaded.
 */
function photoVariables(surface: RegistrationTheme['surface']): Record<string, string> {
  if (surface === 'dark') {
    return {
      '--color-text-primary': '#f2f6ff',
      '--color-text-secondary': '#cbd6e8',
      '--color-border': 'rgba(226,236,255,0.26)',
      '--color-bg-subtle': 'rgba(8,13,28,0.55)',
    }
  }
  return {
    '--color-text-primary': '#0b1220',
    '--color-text-secondary': '#33405a',
    '--color-border': 'rgba(15,23,42,0.20)',
    '--color-bg-subtle': 'rgba(255,255,255,0.62)',
  }
}

/** A theme with any part of it missing — which is what a tab held open across
 *  a deploy, or an older stored row, actually looks like. */
type PartialTheme = Partial<Omit<RegistrationTheme, 'header'>> & {
  header?: Partial<RegistrationThemeHeader>
}

/** Fill in whatever a payload is missing, so a renderer never sees a hole. */
export function resolveTheme(raw: PartialTheme | null | undefined): RegistrationTheme {
  const theme = raw ?? {}
  const header: Partial<RegistrationThemeHeader> = theme.header ?? {}
  const pick = <T extends string>(value: unknown, allowed: readonly T[], fallback: T): T =>
    allowed.includes(value as T) ? (value as T) : fallback

  return {
    font: pick(theme.font, FONTS, 'sans'),
    accent: usableAccent(theme.accent),
    surface: pick(theme.surface, SURFACE_NAMES, 'light'),
    corners: pick(theme.corners, CORNER_NAMES, 'soft'),
    background_image: typeof theme.background_image === 'string' ? theme.background_image : '',
    header: {
      style: pick(header.style, HEADER_STYLES, 'title'),
      image_url: header.image_url ?? '',
      title: header.title ?? '',
      subtitle: header.subtitle ?? '',
      align: pick(header.align, ['left', 'center'] as const, 'center'),
      height: pick(header.height, ['compact', 'tall'] as const, 'compact'),
    },
  }
}

/**
 * The theme as CSS custom properties, to spread onto a wrapper's `style`.
 *
 * These are the app's OWN variable names, redefined for this subtree — see the
 * note at the top of the file. The surface's entries are spread LAST, so a
 * surface that needs a different tint than the generic mix-with-white (dark
 * does) can simply state it and win.
 *
 * Every value is a literal colour. Nothing here relies on a CSS function the
 * visitor's browser might not know — see `mix` above for why that matters on
 * this particular page.
 */
export function themeVariables(theme: RegistrationTheme): React.CSSProperties {
  // Resolved once, here, because the editor hands this function whatever is in
  // the hex field at the moment — including "#", "#2", "#25". Mixing with a
  // half-typed value produced `#NaNNaNNaN` (the background vanishes mid-typing)
  // and, for a five-digit value, a plausible colour that was not the one being
  // typed. Neither looks like an error, which is what makes them worth closing.
  const accent = usableAccent(theme.accent)
  return {
    '--color-accent': accent,
    '--color-on-accent': onAccent(accent),
    '--color-accent-light': mix(accent, WHITE, 0.16),
    '--color-cta-light': mix(accent, WHITE, 0.08),
    '--radius-card': RADII[theme.corners] ?? RADII.soft,
    fontFamily: FONT_STACKS[theme.font] ?? FONT_STACKS.sans,
    ...surfaceVariables(theme.surface, accent),
    // Last, and only when there is a photo: the surface's ink is chosen for a
    // flat colour, and a photo is not one.
    ...(theme.background_image ? photoVariables(theme.surface) : {}),
  } as React.CSSProperties
}

/**
 * The shape of a full-width photo band.
 *
 * Sized by RATIO, not by a pixel height, and this is the whole fix for photos
 * that arrived letterboxed. A 190px band read well across a 560px card; the
 * page now runs edge to edge, so the same 190px across 1900px is a 10:1 slot
 * that crops the subject out of every picture put in it. `aspect-ratio` is
 * resolved against the element's own width, which means one rule is right
 * full-bleed, right in a half-width column, and right inside the editor's
 * narrow preview — where a `vw` unit was measuring the browser window instead
 * of the box the photo is actually in.
 *
 * `minHeight` is the floor, for the opposite case: at 375px the true ratio is
 * a 75px sliver. `maxHeight` keeps an ultrawide monitor from handing a banner
 * most of the screen.
 */
export function photoBand(tall: boolean): React.CSSProperties {
  return tall
    ? { aspectRatio: '12 / 5', minHeight: 280, maxHeight: '78vh' }
    : { aspectRatio: '5 / 1', minHeight: 168, maxHeight: '46vh' }
}

/** How the header band stands. Two steps rather than a slider, which produces
 *  a band that looks accidental at every value between them. */
export function headerBand(theme: RegistrationTheme): React.CSSProperties {
  return photoBand(theme.header.height === 'tall')
}

/**
 * The page's own background: the organizer's photo behind a scrim, or the
 * surface's gradient when there is no photo.
 *
 * The scrim is not decoration. Labels, help text and the organizer's own
 * paragraphs sit directly ON that photo now that the form runs edge to edge,
 * and a photo is whatever somebody uploaded — a night shot of a venue one
 * week, a white conference hall the next. Nothing can be known about it, so
 * the contrast is made a property of the page instead, the same way the header
 * band already handles its own photo: veil it toward the surface's colour
 * until the theme's ink is guaranteed to read, whatever lies underneath.
 *
 * `scroll` rather than `fixed`, which iOS mishandles on scroll.
 */
export function pageBackground(theme: RegistrationTheme): string {
  if (!theme.background_image) {
    return 'linear-gradient(to bottom right, var(--color-page-from), var(--color-page-to))'
  }
  const scrim = theme.surface === 'dark' ? 'rgba(6,11,24,0.72)' : 'rgba(255,255,255,0.72)'
  return `linear-gradient(${scrim}, ${scrim}), url("${theme.background_image}") center / cover no-repeat`
}
