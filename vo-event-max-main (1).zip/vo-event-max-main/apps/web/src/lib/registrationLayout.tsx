/**
 * How a block-arranged registration form renders — the one description of it,
 * shared by the public page at /register/[token] and the live preview inside
 * the organizer's editor, for the same reason the theme is shared: a preview
 * is only worth having if it cannot disagree with the real thing.
 *
 * The server (services/registration_layout.py) is the authority. It sanitizes
 * on save and resolves on read, so what arrives here is already a closed set of
 * keys, validated hexes, bounded text and https URLs — never CSS or markup.
 * `resolveLayout` still fills any gap, for the one case the server cannot cover:
 * a tab held open across a deploy that added a key.
 *
 * Nothing here injects HTML. Text is rendered as React children (escaped), and
 * the only place an organizer value becomes CSS is a colour that has already
 * passed the hex test and a background-image URL the server already stripped of
 * quotes and brackets.
 */

import React from 'react'
import { FONT_STACKS, RADII, onAccent, photoBand, type RegistrationTheme } from './registrationTheme'

type Font = RegistrationTheme['font']
type Align = 'left' | 'center' | 'right'
type Column = 'full' | 'left' | 'right'

/** The page runs edge to edge, so content needs a gutter that grows with the
 *  screen rather than a fixed 28px that leaves text glued to the glass. One
 *  value, shared by every block and by the form, so everything lines up down
 *  the page — full-bleed photos still bleed, only their text is inset. */
export const GUTTER = 'clamp(1.25rem, 6vw, 7rem)'

/** A text field, in each language it was written. The renderer falls back
 *  across languages, so a block translated in only one still shows to everyone. */
export type I18n = Record<string, string>
export const LANGS = ['fr', 'nl', 'en'] as const
export const DEFAULT_LANG = 'fr'

/** The text of an i18n field for a given locale: the locale, else the default
 *  language, else the first language that has any, else empty. */
export function pick(value: I18n | undefined, locale: string): string {
  if (!value) return ''
  return value[locale] || value[DEFAULT_LANG] || Object.values(value).find(Boolean) || ''
}

export interface BaseBlock {
  id: string
  type: string
  col: Column
}
export interface ImageBlock extends BaseBlock {
  type: 'image'
  variant: 'banner' | 'background'
  image_url: string
  preset: '' | 'dusk' | 'sunrise' | 'rose' | 'violet' | 'forest'
  heading: I18n
  subheading: I18n
  overlay_color: string
  overlay_align: Align
  overlay_pos: 'start' | 'center' | 'end'
  heading_font: Font
  heading_size: 'm' | 'l' | 'xl'
}
export interface TitleBlock extends BaseBlock {
  type: 'title'
  text: I18n
  font: Font
  size: 's' | 'm' | 'l' | 'xl'
  align: Align
  color: string
}
export interface TextBlock extends BaseBlock {
  type: 'text'
  text: I18n
  font: Font
  size: 's' | 'm' | 'l'
  align: Align
  width: 'narrow' | 'full'
  color: string
}
export interface ButtonBlock extends BaseBlock {
  type: 'button'
  label: I18n
  href: string
  bg: string
  fg: string
  corners: 'sharp' | 'soft' | 'round'
  align: Align
  full: boolean
}
export interface DividerBlock extends BaseBlock {
  type: 'divider'
  color: string
  thickness: number
}
export interface FormBlock extends BaseBlock {
  type: 'form'
  accent: string
  corners: 'sharp' | 'soft' | 'round'
  style: 'outline' | 'fill'
  button: I18n
}
export type LayoutBlock =
  | ImageBlock | TitleBlock | TextBlock | ButtonBlock | DividerBlock | FormBlock

/** The named background gradients, matching the keys in registration_layout.py.
 *  Offered when no photo is uploaded, so a block is never a blank grey box. */
export const PRESET_BACKGROUNDS: Record<string, string> = {
  dusk: 'linear-gradient(135deg,#0f2027,#203a43 55%,#2c5364)',
  sunrise: 'linear-gradient(135deg,#f6d365,#fda085)',
  rose: 'radial-gradient(130% 130% at 18% 15%,#ff9a9e,#fad0c4 42%,#a18cd1)',
  violet: 'linear-gradient(135deg,#5b247a,#1bcedf)',
  forest: 'linear-gradient(135deg,#134e5e,#71b280)',
}

const TITLE_SIZE = { s: '1.5rem', m: '2.15rem', l: '2.9rem', xl: '3.7rem' } as const
const TEXT_SIZE = { s: '0.92rem', m: '1.05rem', l: '1.25rem' } as const
const HEAD_SIZE = { m: '2.15rem', l: '2.9rem', xl: '3.7rem' } as const

const ALIGN_FLEX: Record<Align, string> = { left: 'flex-start', center: 'center', right: 'flex-end' }

function font(f: Font): string {
  return FONT_STACKS[f] ?? FONT_STACKS.sans
}

/** The background of an image block: a real photo if one was uploaded, else the
 *  chosen preset gradient, else a neutral placeholder. */
function imageBackground(b: ImageBlock): string {
  if (b.image_url) return `center / cover no-repeat url("${b.image_url}")`
  if (b.preset && PRESET_BACKGROUNDS[b.preset]) return PRESET_BACKGROUNDS[b.preset]
  return 'linear-gradient(135deg,#e2e8f0,#cbd5e1)'
}

/** One block to a React node. `renderForm` slots the real form in the form
 *  block's place — the layout decides WHERE and how the form is styled; it
 *  never decides its questions, which stay with registration_form. */
function renderBlock(b: LayoutBlock, locale: string, renderForm: (b: FormBlock) => React.ReactNode): React.ReactNode {
  switch (b.type) {
    case 'image': {
      const tall = b.variant === 'background'
      const justify = b.overlay_pos === 'start' ? 'flex-start' : b.overlay_pos === 'center' ? 'center' : 'flex-end'
      const align = ALIGN_FLEX[b.overlay_align]
      const heading = pick(b.heading, locale)
      const subheading = pick(b.subheading, locale)
      return (
        <div
          style={{
            // Sized by ratio rather than by a pixel height — see photoBand.
            // The old clamp was a card's height applied to a full-width page,
            // which letterboxed every photo put in it.
            ...photoBand(tall),
            background: imageBackground(b),
            display: 'flex',
            flexDirection: 'column',
            justifyContent: justify,
            alignItems: align,
            padding: `clamp(1.75rem, 5vw, 3.5rem) ${GUTTER}`,
          }}
        >
          {heading || subheading ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, alignItems: align, textAlign: b.overlay_align, maxWidth: '82%' }}>
              {heading ? (
                <div style={{ fontFamily: font(b.heading_font), fontWeight: 800, lineHeight: 1.05, fontSize: HEAD_SIZE[b.heading_size], color: b.overlay_color, textShadow: '0 2px 18px rgba(0,0,0,.4)' }}>
                  {heading}
                </div>
              ) : null}
              {subheading ? (
                <div style={{ fontFamily: font('sans'), fontWeight: 600, fontSize: '1rem', letterSpacing: '.02em', color: b.overlay_color, opacity: 0.94, textShadow: '0 1px 10px rgba(0,0,0,.4)' }}>
                  {subheading}
                </div>
              ) : null}
            </div>
          ) : null}
        </div>
      )
    }
    case 'title':
      return (
        <div style={{ fontFamily: font(b.font), fontWeight: 800, letterSpacing: '-.02em', lineHeight: 1.1, fontSize: TITLE_SIZE[b.size], color: b.color || 'var(--color-text-primary)', textAlign: b.align, padding: `2.25rem ${GUTTER} 0.5rem` }}>
          {pick(b.text, locale)}
        </div>
      )
    case 'text': {
      const maxWidth = b.width === 'narrow' ? '62ch' : 'none'
      const margin = b.align === 'center' ? '0 auto' : b.align === 'right' ? '0 0 0 auto' : '0'
      return (
        <div style={{ padding: `1rem ${GUTTER}` }}>
          <div style={{ fontFamily: font(b.font), fontSize: TEXT_SIZE[b.size], lineHeight: 1.7, color: b.color || 'var(--color-text-secondary)', textAlign: b.align, maxWidth, margin, whiteSpace: 'pre-wrap' }}>
            {pick(b.text, locale)}
          </div>
        </div>
      )
    }
    case 'button': {
      const justify = ALIGN_FLEX[b.align]
      const inner = (
        <span style={{ display: 'inline-flex', justifyContent: 'center', width: b.full ? '100%' : 'auto', background: b.bg, color: b.fg, fontFamily: font('sans'), fontWeight: 700, fontSize: '.98rem', padding: '13px 26px', borderRadius: RADII[b.corners] }}>
          {pick(b.label, locale)}
        </span>
      )
      return (
        <div style={{ padding: `1.25rem ${GUTTER}`, display: 'flex', justifyContent: justify }}>
          {b.href ? <a href={b.href} target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'none', width: b.full ? '100%' : 'auto' }}>{inner}</a> : inner}
        </div>
      )
    }
    case 'divider':
      return (
        <div style={{ padding: `1.25rem ${GUTTER}` }}>
          <div style={{ height: b.thickness || 1, background: b.color || 'var(--color-border)', borderRadius: 2 }} />
        </div>
      )
    case 'form':
      // The form block styles and positions the real form. Its accent may
      // differ from the page theme's, so it redefines the accent variables on
      // its own subtree; `outline` clears the input fill so the border carries
      // the field, `fill` leaves the theme's input colour in place.
      return (
        <div
          style={{
            '--color-accent': b.accent,
            '--color-on-accent': onAccent(b.accent),
            '--radius-card': RADII[b.corners],
            ...(b.style === 'outline' ? { '--color-input': 'transparent' } : {}),
          } as React.CSSProperties}
        >
          {renderForm(b)}
        </div>
      )
    default:
      return null
  }
}

/**
 * The whole block-arranged body of the form card.
 *
 * Blocks marked `left` immediately followed by `right` share a row; the row is
 * an auto-fit grid, so it is two columns where the card is wide enough and one
 * where it is not — a phone stacks them with no media query, which is the whole
 * reason placement is a column key and not an (x, y).
 */
export function LayoutCanvas({
  blocks,
  renderForm,
  locale = DEFAULT_LANG,
}: {
  blocks: LayoutBlock[]
  renderForm: (b: FormBlock) => React.ReactNode
  /** The visitor's language; text blocks render this language, falling back. */
  locale?: string
}) {
  const rows: React.ReactNode[] = []
  let i = 0
  while (i < blocks.length) {
    const b = blocks[i]
    const next = blocks[i + 1]
    if (b.col === 'left' && next && next.col === 'right') {
      rows.push(
        <div key={b.id} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))' }}>
          <div>{renderBlock(b, locale, renderForm)}</div>
          <div>{renderBlock(next, locale, renderForm)}</div>
        </div>
      )
      i += 2
    } else {
      rows.push(<div key={b.id}>{renderBlock(b, locale, renderForm)}</div>)
      i += 1
    }
  }
  return <>{rows}</>
}

// ---------------------------------------------------------------------------
// Defensive resolve — the server already sanitizes; this only fills a gap a
// tab held open across a deploy might see, and narrows `any` to typed blocks.
// ---------------------------------------------------------------------------

const FONTS: Font[] = ['sans', 'grotesk', 'serif', 'slab', 'rounded']
const ALIGNS: Align[] = ['left', 'center', 'right']
const oneOf = <T,>(v: unknown, allowed: readonly T[], fb: T): T => (allowed.includes(v as T) ? (v as T) : fb)
const str = (v: unknown, fb = ''): string => (typeof v === 'string' ? v : fb)

/** Coerce a text field to an i18n map. A bare string (older block, or one
 *  language) becomes the default language; a map is filtered to string values. */
function i18n(v: unknown): I18n {
  if (typeof v === 'string') return v ? { [DEFAULT_LANG]: v } : {}
  if (v && typeof v === 'object') {
    const out: I18n = {}
    for (const [k, val] of Object.entries(v as Record<string, unknown>)) {
      if (typeof val === 'string' && val) out[k] = val
    }
    return out
  }
  return {}
}

/** The whole layout: a map of page -> blocks. A bare list (a row written
 *  before the multi-page change) is read as the registration page alone. Pages
 *  with no blocks are dropped, so an absent key means "render this page classic". */
export function resolveLayoutPages(raw: unknown): Record<string, LayoutBlock[]> {
  if (Array.isArray(raw)) {
    const homeBlocks = resolveLayout(raw)
    return homeBlocks.length ? { home: homeBlocks } : {}
  }
  if (raw && typeof raw === 'object') {
    const out: Record<string, LayoutBlock[]> = {}
    for (const [key, blocks] of Object.entries(raw as Record<string, unknown>)) {
      const page = resolveLayout(blocks)
      if (page.length) out[key] = page
    }
    return out
  }
  return {}
}

export function resolveLayout(raw: unknown): LayoutBlock[] {
  if (!Array.isArray(raw)) return []
  const out: LayoutBlock[] = []
  for (const item of raw) {
    if (!item || typeof item !== 'object') continue
    const b = item as Record<string, unknown>
    const id = str(b.id) || 'b' + Math.random().toString(36).slice(2, 10)
    const col = oneOf<Column>(b.col, ['full', 'left', 'right'], 'full')
    switch (b.type) {
      case 'image':
        out.push({ id, col, type: 'image',
          variant: oneOf(b.variant, ['banner', 'background'] as const, 'banner'),
          image_url: str(b.image_url), preset: oneOf(b.preset, ['', 'dusk', 'sunrise', 'rose', 'violet', 'forest'] as const, ''),
          heading: i18n(b.heading), subheading: i18n(b.subheading),
          overlay_color: str(b.overlay_color, '#ffffff'),
          overlay_align: oneOf(b.overlay_align, ALIGNS, 'left'),
          overlay_pos: oneOf(b.overlay_pos, ['start', 'center', 'end'] as const, 'end'),
          heading_font: oneOf(b.heading_font, FONTS, 'serif'),
          heading_size: oneOf(b.heading_size, ['m', 'l', 'xl'] as const, 'xl') })
        break
      case 'title':
        out.push({ id, col, type: 'title', text: i18n(b.text),
          font: oneOf(b.font, FONTS, 'grotesk'), size: oneOf(b.size, ['s', 'm', 'l', 'xl'] as const, 'l'),
          align: oneOf(b.align, ALIGNS, 'left'), color: str(b.color) })
        break
      case 'text':
        out.push({ id, col, type: 'text', text: i18n(b.text),
          font: oneOf(b.font, FONTS, 'sans'), size: oneOf(b.size, ['s', 'm', 'l'] as const, 'm'),
          align: oneOf(b.align, ALIGNS, 'left'), width: oneOf(b.width, ['narrow', 'full'] as const, 'narrow'),
          color: str(b.color) })
        break
      case 'button':
        out.push({ id, col, type: 'button', label: i18n(b.label), href: str(b.href),
          bg: str(b.bg, '#2563eb'), fg: str(b.fg, '#ffffff'),
          corners: oneOf(b.corners, ['sharp', 'soft', 'round'] as const, 'soft'),
          align: oneOf(b.align, ALIGNS, 'center'), full: Boolean(b.full) })
        break
      case 'divider':
        out.push({ id, col, type: 'divider', color: str(b.color),
          thickness: [1, 2, 4].includes(b.thickness as number) ? (b.thickness as number) : 1 })
        break
      case 'form':
        out.push({ id, col, type: 'form', accent: str(b.accent, '#2563eb'),
          corners: oneOf(b.corners, ['sharp', 'soft', 'round'] as const, 'soft'),
          style: oneOf(b.style, ['outline', 'fill'] as const, 'outline'),
          button: i18n(b.button) })
        break
    }
  }
  return out
}
