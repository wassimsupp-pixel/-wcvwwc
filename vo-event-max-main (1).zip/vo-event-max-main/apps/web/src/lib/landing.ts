import { api } from './api'

/**
 * Where a signed-in user should land.
 *
 * Signing in used to compute this inline and fall back to `/${locale}` when
 * the account had no event — and `/${locale}` redirects to the login page.
 * So a working account with an empty project list was bounced straight back
 * to the form it had just filled in, looking exactly like a failed login
 * (2026-08-07, after the database was emptied).
 *
 * There is always somewhere to go: the first event's dashboard when one
 * exists, otherwise the global page, which renders the full shell — sidebar
 * and event selector included — so the user can create their first event
 * instead of staring at a login form that already accepted them.
 */
export async function landingPath(locale: string): Promise<string> {
  try {
    const events = await api.events.list()
    if (Array.isArray(events) && events.length > 0) {
      return `/${locale}/events/${events[0].id}/dashboard`
    }
  } catch {
    // API unreachable: the shell still loads and shows its own error, which
    // is far more useful than a silent bounce to the login page.
  }
  return `/${locale}/participants`
}
