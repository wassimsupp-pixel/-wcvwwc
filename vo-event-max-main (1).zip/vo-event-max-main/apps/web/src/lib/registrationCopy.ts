/**
 * registrationCopy.ts — the public form's own words, in the participant's language.
 *
 * Deliberately NOT next-intl. next-intl's locale comes from the URL prefix, and
 * the participant's language comes from the picker at the top of the form: a
 * Dutch speaker opening `/fr/register/<token>` and clicking "Nederlands" never
 * changes the URL, so `useTranslations` would keep answering in French. The
 * language the form speaks has to follow the button, not the address bar.
 *
 * Split of responsibilities, matching services/registration_i18n.py:
 *   - field labels, section groups and the server's refusals → the API, which
 *     already receives `lang` on every call;
 *   - this page's own chrome (headings, buttons, errors it raises itself,
 *     placeholders) → here.
 *
 * An untranslated key falls back to French, never to the key itself. A
 * participant seeing "Prénom" on a Dutch form is mildly untidy; one seeing
 * `submitButton` is looking at a broken page.
 */

/** French is the source of truth: every key exists here, so `copy()` can never
 *  return undefined and the type below is derived from it rather than declared
 *  twice. */
const fr = {
  // Status pages
  loading: 'Chargement du formulaire…',
  invalidTitle: 'Formulaire introuvable',
  invalidBody: 'Ce lien n’est plus valide. Contactez l’organisateur.',
  closedTitle: 'Inscriptions fermées',
  closedBody: 'Les inscriptions pour {event} sont fermées. Contactez l’organisateur en cas d’erreur.',
  submittedTitle: 'Inscription bien reçue !',
  submittedBody: 'Vos informations ont été transmises. Vous pouvez fermer cette page.',

  // Form chrome
  intro: 'Merci de compléter vos informations pour cet événement.',
  navRegistration: 'Inscription',
  honeypot: 'Ne pas remplir ce champ',
  submit: 'Envoyer mon inscription',
  submitting: 'Envoi en cours…',

  // Errors this page raises before anything reaches the server
  errConsent: 'Merci de cocher la case de consentement pour continuer.',
  errConfirm: 'Merci de confirmer : {fields}.',
  errPhone: 'Merci de renseigner votre numéro de téléphone.',
  errEmergencyPhone: 'Merci de renseigner le téléphone du contact d’urgence.',
  errDialCode: 'Sélectionnez l’indicatif de votre numéro (ex. +32 Belgique, +213 Algérie).',
  errEmergencyDialCode: 'Sélectionnez l’indicatif du contact d’urgence (ex. +32 Belgique, +213 Algérie).',
  errGeneric: 'Une erreur est survenue. Merci de réessayer.',

  // Section headings this page owns
  extraInfo: 'Informations complémentaires',
  emergencyHeading: 'Contact d’urgence',
  documents: 'Documents',
  companionHeading: 'Accompagnant',

  // Inputs
  dialCode: 'Indicatif',
  dialCodeHint: 'Indicatif requis si vous renseignez un numéro.',
  selectPlaceholder: 'Sélectionner…',
  choosePlaceholder: 'Choisissez…',
  yes: 'Oui',
  phBadgeName: 'Ex. Ana',
  phDiet: 'Ex. Végétarien, halal, sans gluten…',
  phAllergy: 'Ex. Arachides, fruits de mer…',
  phRoomPreference: 'Ex. Lit double, chambre non-fumeur…',
  phPmr: 'Ex. Accès fauteuil roulant, chambre accessible…',
  phRoommate: 'Prénom et nom de la personne',

  // Room type — a choice, not free text, so the three options are page copy
  roomSingle: 'Single (chambre individuelle)',
  roomTwin: 'Twin (deux lits séparés)',
  roomDouble: 'Double (un grand lit)',

  // Attachments
  uploading: 'Envoi…',
  errUpload: 'Envoi impossible.',
  fileLimit: '{types} — {mb} Mo max.',

  // Companion (§9)
  companionAdd: 'J’inscris une deuxième personne',
  companionNote: 'Uniquement ses informations personnelles. Société, adresse et vols sont repris de votre inscription.',
  companionSharesRoom: 'Nous partageons la même chambre',
  companionFirstName: 'Prénom',
  companionLastName: 'Nom',
  companionEmail: 'Adresse email (facultatif)',
  companionDiet: 'Régime alimentaire (facultatif)',

  // Consent. Enumerates what is being consented to rather than saying "your
  // data": a participant ticking this box should know it covers their passport.
  consent:
    'J’accepte que les informations transmises ci-dessus, y compris mes préférences alimentaires, mes besoins d’accessibilité, mes données de passeport et mon contact d’urgence le cas échéant, soient utilisées par l’organisateur dans le seul cadre de la préparation de cet événement.',
} as const

export type RegistrationCopyKey = keyof typeof fr

/**
 * Complete, not Partial — deliberately.
 *
 * A missing key would fall back to French at runtime, which is precisely the
 * bug this file exists to end: a form that is Dutch above the fold and French
 * further down. Typing these as complete records turns "somebody added a key
 * and only wrote the French" into a compile error, on the machine of whoever
 * added it, instead of a half-translated form in a participant's browser. The
 * runtime fallback below stays anyway, for a locale that is not in the table
 * at all.
 */
const nl: Record<RegistrationCopyKey, string> = {
  loading: 'Formulier laden…',
  invalidTitle: 'Formulier niet gevonden',
  invalidBody: 'Deze link is niet meer geldig. Neem contact op met de organisator.',
  closedTitle: 'Inschrijvingen gesloten',
  closedBody: 'De inschrijvingen voor {event} zijn gesloten. Neem contact op met de organisator als dit een vergissing is.',
  submittedTitle: 'Inschrijving goed ontvangen!',
  submittedBody: 'Uw gegevens zijn doorgestuurd. U kunt deze pagina sluiten.',

  intro: 'Gelieve uw gegevens voor dit evenement aan te vullen.',
  navRegistration: 'Inschrijving',
  honeypot: 'Dit veld niet invullen',
  submit: 'Mijn inschrijving versturen',
  submitting: 'Bezig met verzenden…',

  errConsent: 'Vink het toestemmingsvakje aan om verder te gaan.',
  errConfirm: 'Gelieve te bevestigen: {fields}.',
  errPhone: 'Gelieve uw telefoonnummer in te vullen.',
  errEmergencyPhone: 'Gelieve het telefoonnummer van de noodcontactpersoon in te vullen.',
  errDialCode: 'Kies de landcode van uw nummer (bv. +32 België, +213 Algerije).',
  errEmergencyDialCode: 'Kies de landcode van de noodcontactpersoon (bv. +32 België, +213 Algerije).',
  errGeneric: 'Er is iets misgelopen. Probeer het opnieuw.',

  extraInfo: 'Aanvullende informatie',
  emergencyHeading: 'Noodcontact',
  documents: 'Documenten',
  companionHeading: 'Begeleider',

  dialCode: 'Landcode',
  dialCodeHint: 'Landcode verplicht als u een nummer invult.',
  selectPlaceholder: 'Kiezen…',
  choosePlaceholder: 'Kies…',
  yes: 'Ja',
  phBadgeName: 'Bv. Ana',
  phDiet: 'Bv. vegetarisch, halal, glutenvrij…',
  phAllergy: 'Bv. pinda’s, schaaldieren…',
  phRoomPreference: 'Bv. tweepersoonsbed, rookvrije kamer…',
  phPmr: 'Bv. rolstoeltoegankelijk, aangepaste kamer…',
  phRoommate: 'Voor- en achternaam van de persoon',

  roomSingle: 'Single (eenpersoonskamer)',
  roomTwin: 'Twin (twee aparte bedden)',
  roomDouble: 'Double (één groot bed)',

  uploading: 'Bezig…',
  errUpload: 'Verzenden mislukt.',
  fileLimit: '{types} — max. {mb} MB.',

  companionAdd: 'Ik schrijf een tweede persoon in',
  companionNote: 'Enkel de persoonlijke gegevens. Bedrijf, adres en vluchten worden overgenomen uit uw eigen inschrijving.',
  companionSharesRoom: 'Wij delen dezelfde kamer',
  companionFirstName: 'Voornaam',
  companionLastName: 'Achternaam',
  companionEmail: 'E-mailadres (optioneel)',
  companionDiet: 'Dieetwensen (optioneel)',

  consent:
    'Ik ga ermee akkoord dat de hierboven verstrekte gegevens, met inbegrip van mijn dieetwensen, mijn toegankelijkheidsbehoeften, mijn paspoortgegevens en mijn noodcontact indien van toepassing, door de organisator uitsluitend gebruikt worden voor de voorbereiding van dit evenement.',
}

const en: Record<RegistrationCopyKey, string> = {
  loading: 'Loading the form…',
  invalidTitle: 'Form not found',
  invalidBody: 'This link is no longer valid. Please contact the organiser.',
  closedTitle: 'Registration closed',
  closedBody: 'Registration for {event} is closed. Please contact the organiser if this is a mistake.',
  submittedTitle: 'Registration received!',
  submittedBody: 'Your details have been sent. You can close this page.',

  intro: 'Please complete your details for this event.',
  navRegistration: 'Registration',
  honeypot: 'Do not fill in this field',
  submit: 'Send my registration',
  submitting: 'Sending…',

  errConsent: 'Please tick the consent box to continue.',
  errConfirm: 'Please confirm: {fields}.',
  errPhone: 'Please enter your phone number.',
  errEmergencyPhone: 'Please enter the emergency contact’s phone number.',
  errDialCode: 'Select the dialling code for your number (e.g. +32 Belgium, +213 Algeria).',
  errEmergencyDialCode: 'Select the emergency contact’s dialling code (e.g. +32 Belgium, +213 Algeria).',
  errGeneric: 'Something went wrong. Please try again.',

  extraInfo: 'Additional information',
  emergencyHeading: 'Emergency contact',
  documents: 'Documents',
  companionHeading: 'Companion',

  dialCode: 'Code',
  dialCodeHint: 'A dialling code is required if you enter a number.',
  selectPlaceholder: 'Select…',
  choosePlaceholder: 'Choose…',
  yes: 'Yes',
  phBadgeName: 'E.g. Ana',
  phDiet: 'E.g. vegetarian, halal, gluten-free…',
  phAllergy: 'E.g. peanuts, shellfish…',
  phRoomPreference: 'E.g. double bed, non-smoking room…',
  phPmr: 'E.g. wheelchair access, accessible room…',
  phRoommate: 'The person’s first and last name',

  roomSingle: 'Single (one person)',
  roomTwin: 'Twin (two separate beds)',
  roomDouble: 'Double (one large bed)',

  uploading: 'Uploading…',
  errUpload: 'Upload failed.',
  fileLimit: '{types} — {mb} MB max.',

  companionAdd: 'I am registering a second person',
  companionNote: 'Personal details only. Company, address and flights are taken from your own registration.',
  companionSharesRoom: 'We are sharing the same room',
  companionFirstName: 'First name',
  companionLastName: 'Last name',
  companionEmail: 'Email address (optional)',
  companionDiet: 'Dietary requirements (optional)',

  consent:
    'I agree that the information provided above, including my dietary requirements, my accessibility needs, my passport details and my emergency contact where applicable, may be used by the organiser solely to prepare this event.',
}

const DICTIONARIES: Record<string, Record<RegistrationCopyKey, string> | undefined> = { nl, en }

/**
 * The form's words in `lang`, with `{placeholder}` substitution.
 *
 * Returns a function rather than an object so calls read as `t('submit')` and
 * a missing key is a compile error, not a blank on a live form.
 */
export function registrationCopy(lang: string) {
  const dict = DICTIONARIES[lang]
  return (key: RegistrationCopyKey, params?: Record<string, string | number>): string => {
    let text: string = dict?.[key] ?? fr[key]
    if (params) {
      for (const [name, value] of Object.entries(params)) {
        text = text.split(`{${name}}`).join(String(value))
      }
    }
    return text
  }
}

export type RegistrationCopy = ReturnType<typeof registrationCopy>
