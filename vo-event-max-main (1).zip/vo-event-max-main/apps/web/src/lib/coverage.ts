/**
 * What "good coverage" means, in one place.
 *
 * A rate alone says nothing: 64 % of transfers booked is comfortable at D-90
 * and an emergency at D-5. These thresholds are what turns a percentage into a
 * verdict — and they are a guess at how VO actually works, not a measurement.
 * They belong here, on their own, so that correcting them is a one-line edit
 * rather than an archaeology exercise across the dashboard.
 *
 * Per-event thresholds would need a column on `events` (the same shape as
 * migration 007's registration_fields) — worth doing once these numbers have
 * been checked against a real event or two.
 */
export const COVERAGE_TARGETS: { withinDays: number; expectedPct: number }[] = [
  { withinDays: 7, expectedPct: 95 },    // final week: everything but the strays
  { withinDays: 30, expectedPct: 80 },   // final month: the bulk is locked in
  { withinDays: Infinity, expectedPct: 50 },
]

/** With no date on the event there is no deadline to judge against, so only
 *  full coverage counts as done. */
const NO_DEADLINE_TARGET = 100

export function expectedCoverage(daysUntilStart: number | null): number {
  if (daysUntilStart === null) return NO_DEADLINE_TARGET
  // Past the start date, everything should have been settled long ago.
  if (daysUntilStart < 0) return 100
  return (
    COVERAGE_TARGETS.find((t) => daysUntilStart <= t.withinDays)?.expectedPct ??
    NO_DEADLINE_TARGET
  )
}

export interface CoverageVerdict {
  pct: number
  label: string
  /** True when the rate is where it should be for the time remaining. */
  ok: boolean
}

export function coverageVerdict(
  covered: number,
  total: number,
  daysUntilStart: number | null,
): CoverageVerdict {
  if (total === 0) return { pct: 0, label: '', ok: false }
  const pct = Math.round((covered / total) * 100)
  return { pct, label: `${pct} % couverts`, ok: pct >= expectedCoverage(daysUntilStart) }
}
