import type { Exception } from './api'

/**
 * An alert nobody has touched for a day has stopped being a notification and
 * become a habit. Past this age it is surfaced on its own, away from the
 * running total, because "12 alertes" reads the same on day one and day five —
 * and the ones that matter are exactly the ones that stopped moving.
 */
export const OVERDUE_AFTER_MS = 24 * 60 * 60 * 1000

export interface OverdueAlerts {
  items: Exception[]
  /** Age of the oldest one, in ms. 0 when there are none. */
  oldestAgeMs: number
}

/**
 * Unresolved alerts older than 24 h.
 *
 * `now` is a parameter rather than a Date.now() call inside: this runs from a
 * data loader, and reading the clock during a React render is impure (the
 * compiler's react-hooks/purity rule rejects it, rightly — two renders would
 * disagree).
 */
export function overdueAlerts(exceptions: Exception[], now: number): OverdueAlerts {
  let oldestAgeMs = 0
  const items = exceptions.filter((e) => {
    if (e.resolved) return false
    const created = Date.parse(e.created_at)
    if (Number.isNaN(created)) return false      // never guess an age
    const age = now - created
    if (age < OVERDUE_AFTER_MS) return false
    if (age > oldestAgeMs) oldestAgeMs = age
    return true
  })
  return { items, oldestAgeMs }
}

/** "26 heures", "3 jours" — a duration, in the reader's language. */
export function ageLabel(ms: number, locale: string): string {
  const hours = Math.floor(ms / 3_600_000)
  const [value, unit] = hours < 48 ? [hours, 'hour'] : [Math.floor(hours / 24), 'day']
  try {
    return new Intl.NumberFormat(locale, {
      style: 'unit', unit, unitDisplay: 'long',
    }).format(value)
  } catch {
    return unit === 'hour' ? `${value} h` : `${value} j`
  }
}

/** True when this alert has been waiting more than 24 h. */
export function isOverdue(exc: Exception, now: number): boolean {
  if (exc.resolved) return false
  const created = Date.parse(exc.created_at)
  return !Number.isNaN(created) && now - created >= OVERDUE_AFTER_MS
}
