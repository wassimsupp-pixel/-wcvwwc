/**
 * Where the "Powered by" badge leads.
 *
 * One constant rather than two hrefs, because the badge appears in two places
 * (the sidebar and the login card) and a white-label attribution that points
 * somewhere different depending on which screen you clicked it from is worse
 * than no link at all.
 *
 * Note for the hand-over: this is the agency's own marketing site, and the
 * same domain is registered as an alias of this application in Vercel. The
 * day its DNS is pointed at Vercel, this link starts leading back into the
 * app — so whoever switches the DNS has to change this line with it, or move
 * the app to a subdomain.
 */
export const VO_SITE_URL = 'https://www.vo-event-max.be'
