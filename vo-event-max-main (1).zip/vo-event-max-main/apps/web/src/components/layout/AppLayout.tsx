'use client'

import { useState } from 'react'
import { useTranslations } from 'next-intl'
import { Sidebar } from '@/components/layout/Sidebar'
import { EventSelector } from '@/components/layout/EventSelector'
import { HelpCircle, Menu } from 'lucide-react'

interface AppLayoutProps {
  children: React.ReactNode
  eventId: string
  locale: string
  pageTitle?: string
  pageSubtitle?: string
  headerExtra?: React.ReactNode
}

/**
 * The application shell.
 *
 * It used to hard-code `ml-[240px]` against a permanently visible 240px
 * sidebar, with no breakpoint anywhere: on a 375px phone two thirds of the
 * screen were the navigation and the page itself was pushed out of view. That
 * made the app unusable in the one situation where it matters most — on site,
 * on the day, from a phone. Below `lg` the sidebar is now a drawer and the
 * content takes the full width.
 */
export function AppLayout({
  children,
  eventId,
  locale,
  pageTitle,
  pageSubtitle,
  headerExtra,
}: AppLayoutProps) {
  const tLayout = useTranslations('appLayout')
  const [navOpen, setNavOpen] = useState(false)

  return (
    <div className="min-h-screen bg-[var(--color-bg-subtle)]">
      <Sidebar
        eventId={eventId}
        locale={locale}
        open={navOpen}
        onClose={() => setNavOpen(false)}
      />

      {/* Main content area */}
      <div className="flex min-h-screen flex-col lg:ml-[240px]">
        {/* Top header bar */}
        <header className="sticky top-0 z-30 flex h-[60px] flex-shrink-0 items-center gap-3 border-b border-[var(--color-border)] bg-white px-4 sm:gap-4 sm:px-6">
          <button
            type="button"
            onClick={() => setNavOpen(true)}
            aria-label={tLayout('openNav')}
            className="-ml-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-[var(--color-text-secondary)] transition-colors hover:bg-gray-100 hover:text-[var(--color-text-primary)] lg:hidden"
          >
            <Menu className="h-5 w-5" />
          </button>

          {/* Event selector */}
          <EventSelector currentEventId={eventId} />

          {/* Page title in header (optional) */}
          {pageTitle && (
            <div className="hidden border-l border-[var(--color-border)] pl-4 sm:block">
              <h1 className="text-sm font-semibold text-[var(--color-text-primary)]">
                {pageTitle}
              </h1>
              {pageSubtitle && (
                <p className="text-xs text-[var(--color-text-secondary)]">{pageSubtitle}</p>
              )}
            </div>
          )}

          {/* Spacer */}
          <div className="flex-1" />

          {/* Header actions */}
          {headerExtra}

          {/* Help */}
          <button className="hidden h-8 w-8 items-center justify-center rounded-lg text-[var(--color-text-secondary)] transition-colors hover:bg-gray-100 hover:text-[var(--color-text-primary)] sm:flex">
            <HelpCircle className="h-4 w-4" />
          </button>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 sm:p-6">{children}</main>
      </div>
    </div>
  )
}
