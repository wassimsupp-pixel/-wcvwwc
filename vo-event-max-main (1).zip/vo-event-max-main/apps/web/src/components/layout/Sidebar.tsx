'use client'

import { useState, useEffect } from 'react'
import { useTranslations } from 'next-intl'
import { usePathname, useRouter } from 'next/navigation'
import Link from 'next/link'
import { VO_SITE_URL } from '@/lib/brand'
import {
  LayoutDashboard,
  ListChecks,
  Database,
  Link2,
  Users,
  Plane,
  Hotel,
  BedDouble,
  Sparkles,
  Bus,
  Mail,
  AlertTriangle,
  GitMerge,
  Clock,
  BarChart3,
  MessageSquare,
  Settings,
  LogOut, PartyPopper } from 'lucide-react'
import { cn } from '@/lib/utils'
import { createClient } from '@/lib/supabase'
import { api, clearApiCache } from '@/lib/api'
import { EventMaxLogo } from '@/components/ui/EventMaxLogo'

interface NavItem {
  key: string
  href: string | null
  icon: React.ElementType
  disabled?: boolean
  badge?: string
}

function getNavItems(eventId: string, locale: string, userRole: string, exceptionCount: number): NavItem[] {
  const base = `/${locale}/events/${eventId}`
  const items = [
    { key: 'dashboard', href: `${base}/dashboard`, icon: LayoutDashboard },
    { key: 'assistant', href: `${base}/assistant`, icon: MessageSquare },
    { key: 'masterList', href: `${base}/master-list`, icon: ListChecks },
    { key: 'sources', href: `${base}/sources`, icon: Database },
    { key: 'registrationForm', href: `${base}/registration-form`, icon: Link2 },
    { key: 'participants', href: `${base}/participants`, icon: Users },
    { key: 'flights', href: `${base}/flights`, icon: Plane },
    { key: 'hotels', href: `${base}/hotels`, icon: Hotel },
    { key: 'rooming', href: `${base}/rooming`, icon: BedDouble },
    { key: 'activities', href: `${base}/activities`, icon: PartyPopper },
    { key: 'transfers', href: `${base}/transfers`, icon: Bus },
    { key: 'communications', href: `${base}/communications`, icon: Mail },
    { key: 'exceptions', href: `${base}/exceptions`, icon: AlertTriangle, badge: exceptionCount > 0 ? String(exceptionCount) : undefined },
    { key: 'matchReview', href: `${base}/match-review`, icon: GitMerge },
    { key: 'history', href: `${base}/history`, icon: Clock },
    { key: 'reports', href: `${base}/reports`, icon: BarChart3 },
    { key: 'settings', href: `/${locale}/settings`, icon: Settings },
  ]

  if (userRole.toLowerCase() === 'client') {
    // Hide sources, exceptions, settings, reports, and communications
    return items.filter(item => !['sources', 'exceptions', 'matchReview', 'settings', 'reports', 'communications'].includes(item.key))
  }
  return items
}

interface SidebarProps {
  eventId: string
  locale: string
  /** Below lg the sidebar is an off-canvas drawer; AppLayout owns the state
   *  because the button that opens it lives in the header. */
  open?: boolean
  onClose?: () => void
}

// Every page renders its own <AppLayout>, so navigating unmounts and remounts
// this sidebar — and with it re-ran an auth call, a role lookup and an
// exception count on EVERY page change, three round-trips before the page
// itself had asked for anything. The identity cannot change mid-session and
// the badge already tolerates being 30s stale (it polls), so both are kept
// here across mounts. Module scope, not React state: that is the point.
let cachedProfile: { name: string; initials: string; role: string } | null = null
const cachedCounts = new Map<string, { at: number; value: number; overdue: number }>()
const COUNT_TTL_MS = 15_000

export function Sidebar({ eventId, locale, open = false, onClose }: SidebarProps) {
  const t = useTranslations('nav')
  const tBrand = useTranslations('branding')
  const tSide = useTranslations('sidebar')
  const pathname = usePathname()
  const router = useRouter()

  // Empty until the real session answers. These used to be seeded with a
  // scaffolding persona ("Marie Dubois", "Event Manager", "MD") that no
  // account has ever matched: every page load flashed a stranger's identity in
  // the sidebar, and if getUser() failed or the session had expired, that
  // stranger simply stayed on screen — the app claiming you were signed in as
  // someone who does not exist.
  const [userName, setUserName] = useState(cachedProfile?.name ?? '')
  const [userRole, setUserRole] = useState(cachedProfile?.role ?? '')
  const [userInitials, setUserInitials] = useState(cachedProfile?.initials ?? '')
  const [exceptionCount, setExceptionCount] = useState<number>(
    cachedCounts.get(eventId)?.value ?? 0
  )
  // How many of those have been waiting more than 24 h. The badge turns from
  // a count into a warning when any of them has: a number alone never tells
  // you whether anyone is actually dealing with them.
  const [overdueCount, setOverdueCount] = useState<number>(
    cachedCounts.get(eventId)?.overdue ?? 0
  )
  const [showUserMenu, setShowUserMenu] = useState(false)

  // 1. Fetch user profile (once per session — see cachedProfile above)
  useEffect(() => {
    if (cachedProfile) return
    async function getUser() {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        const name = user.user_metadata?.full_name || user.email?.split('@')[0] || 'Utilisateur VO'
        const parts = name.trim().split(/\s+/)
        const initials = parts.map((p: string) => p[0]).join('').toUpperCase().substring(0, 2) || 'VO'
        let role = ''
        try {
          const { data: profile } = await supabase.from('users').select('role').eq('id', user.id).single()
          if (profile) {
            role = profile.role
          }
        } catch {
          // ignore — the name alone is enough to stop showing a placeholder
        }
        cachedProfile = { name, initials, role }
        setUserName(name)
        setUserInitials(initials)
        if (role) setUserRole(role)
      }
    }
    getUser()
  }, [])

  // 2. Fetch exceptions count in real-time
  useEffect(() => {
    async function loadExceptionCount(force = false) {
      if (!eventId || eventId === 'global') {
        setExceptionCount(0)
        return
      }
      // A remount within the TTL reuses the last count instead of re-querying;
      // the 30s poll below always forces a real read.
      const cached = cachedCounts.get(eventId)
      if (!force && cached && Date.now() - cached.at < COUNT_TTL_MS) {
        setExceptionCount(cached.value)
        setOverdueCount(cached.overdue)
        return
      }
      try {
        const startedAt = typeof performance !== 'undefined' ? performance.now() : Date.now()
        // Counted by the API, not by two head-only queries against the table.
        //
        // Whether a row is still an exception is a server-side rule: a run
        // from before a field was made optional still holds its cards, and
        // the field policy is applied again on read. A browser counting rows
        // cannot see that rule, which is exactly how this badge came to read
        // 77 beside a page listing 14 — and a navigation that contradicts the
        // page it links to is worse than a wrong number, because the reader
        // cannot tell which one to believe.
        //
        // One round trip now instead of two, so it is also cheaper.
        const { open, overdue } = await api.exceptions.count(eventId)

        if (process.env.NODE_ENV !== 'production') {
          const now = typeof performance !== 'undefined' ? performance.now() : Date.now()
          console.debug(`[sidebar] exception count → ${Math.round(now - startedAt)}ms`)
        }

        cachedCounts.set(eventId, { at: Date.now(), value: open, overdue })
        setExceptionCount(open)
        setOverdueCount(overdue)
      } catch (err) {
        console.error('Exception count query error:', err)
      }
    }
    loadExceptionCount()

    // Poll to keep the badge synced. 30s (was 5s) to cut idle DB load on every
    // page; can be replaced by a Supabase Realtime subscription later (P1.6).
    const timer = setInterval(() => loadExceptionCount(true), 30_000)
    return () => clearInterval(timer)
  }, [eventId])

  const navItems = getNavItems(eventId, locale, userRole, exceptionCount)

  return (
    <>
      {/* Scrim — tapping outside closes the drawer. Only exists below lg. */}
      {open && (
        <div
          onClick={onClose}
          aria-hidden="true"
          className="fixed inset-0 z-30 bg-black/30 lg:hidden"
        />
      )}
    <aside
      className={cn(
        'fixed top-0 z-40 flex h-screen w-[240px] flex-col bg-[var(--color-surface)]',
        // 240px of a 375px phone was permanently occupied by this element and
        // the content was pushed off-screen — the app was unusable exactly
        // where a dashboard matters most: on site, on the day.
        //
        // Slid with `left`, not with a translate utility: Tailwind v4 drives
        // those through the CSS `translate` property via a custom property,
        // and on the deployed build the element kept a computed
        // `translate: -100%` while its class said `translate-x-0` — the drawer
        // never came out. `left` is a plain property with no indirection, it
        // transitions cleanly, and `lg:left-0` wins on desktop.
        'transition-[left] duration-200 lg:left-0',
        open ? 'left-0' : 'left-[-240px]'
      )}
      style={{ boxShadow: 'var(--shadow-sidebar)' }}
    >
      {/* Logo — Event MAX (primary brand) */}
      <div className="flex items-center border-b border-[var(--color-border)] px-6 py-6 select-none text-[var(--color-text-primary)]">
        <EventMaxLogo className="h-9 w-auto" />
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-3 py-4">
        <ul className="space-y-0.5">
          {navItems.map((item) => {
            const isActive = item.href ? pathname.startsWith(item.href) : false
            const Icon = item.icon

            if (item.disabled) {
              return (
                <li key={item.key}>
                  <div
                    className="group flex cursor-not-allowed items-center gap-3 rounded-lg px-3 py-2 opacity-40"
                    title={tSide('phase2')}
                  >
                    <Icon className="h-4 w-4 text-[var(--color-text-secondary)]" />
                    <span className="text-sm text-[var(--color-text-secondary)]">
                      {t(item.key as any)}
                    </span>
                    <span className="ml-auto rounded-sm bg-gray-100 px-1 py-0.5 text-[9px] font-medium uppercase tracking-wider text-gray-400">
                      P2
                    </span>
                  </div>
                </li>
              )
            }

            return (
              <li key={item.key}>
                <Link
                  href={item.href!}
                  // On a phone the drawer covers the page it just navigated to.
                  onClick={onClose}
                  className={cn(
                    'group flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors',
                    isActive
                      ? 'bg-[var(--color-accent-light)] font-semibold text-[var(--color-accent)]'
                      : 'font-medium text-[var(--color-text-secondary)] hover:bg-gray-50 hover:text-[var(--color-text-primary)]'
                  )}
                >
                  <Icon
                    className={cn(
                      'h-4 w-4 flex-shrink-0 transition-colors',
                      isActive
                        ? 'text-[var(--color-accent)]'
                        : 'text-[var(--color-text-secondary)] group-hover:text-[var(--color-text-primary)]'
                    )}
                  />
                  <span className="flex-1">
                    {t(item.key as any)}
                  </span>
                  {item.badge && (
                    <span
                      title={
                        item.key === 'exceptions' && overdueCount > 0
                          ? tSide('overdueAlerts', { count: overdueCount })
                          : undefined
                      }
                      className={cn(
                        'flex-shrink-0 rounded-full px-1.5 py-0.5 text-[10px] font-bold text-white',
                        item.key === 'exceptions' && overdueCount > 0
                          ? 'bg-[var(--color-warning)] ring-2 ring-[var(--color-warning)]/30'
                          : 'bg-[var(--color-danger)]'
                      )}
                    >
                      {item.badge}
                    </span>
                  )}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* User section */}
      <div className="flex-shrink-0 border-t border-[var(--color-border)] p-4 relative">
        {showUserMenu && (
          <div className="absolute bottom-[60px] left-4 right-4 bg-white border border-[var(--color-border)] rounded-lg shadow-lg p-1.5 z-50">
            <button
              onClick={async () => {
                const supabase = createClient()
                await supabase.auth.signOut()
                // Module-level caches outlive a logout — without this, the next
                // person to sign in on this tab would be greeted by the
                // previous user's name, role and event data.
                cachedProfile = null
                cachedCounts.clear()
                clearApiCache()
                router.push(`/${locale}/login`)
              }}
              className="w-full text-left px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-md transition-colors flex items-center gap-2"
            >
              <LogOut className="h-4 w-4" />
              {t('logout')}
            </button>
          </div>
        )}
        <div
          className="flex items-center gap-3 cursor-pointer p-1.5 -m-1.5 rounded-lg hover:bg-slate-50 transition-colors"
          onClick={() => setShowUserMenu(!showUserMenu)}
        >
          <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-[var(--color-accent)] text-xs font-bold text-white">
            {userInitials || '·'}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-[var(--color-text-primary)]">
              {userName || tSide('loadingUser')}
            </p>
            <p className="truncate text-xs text-[var(--color-text-secondary)]">
              {userRole ? tSide('role.' + userRole) : ' '}
            </p>
          </div>
        </div>
      </div>

      {/* Powered by VO Communication Group (white-label attribution), and the
          one thing on this screen that is about who built the product rather
          than about the event — so it leads to them. A new tab: somebody
          halfway through a rooming list should not lose it to a curiosity
          click. */}
      <a
        href={VO_SITE_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="group flex flex-shrink-0 select-none items-center gap-2.5 border-t border-[var(--color-border)] px-4 py-3 transition-colors hover:bg-[var(--color-bg-subtle)]"
      >
        <div className="h-[34px] w-[46px] flex-shrink-0 text-[var(--color-text-secondary)] transition-colors group-hover:text-[var(--color-text-primary)]" aria-hidden>
          <svg className="h-full w-full" viewBox="0 0 60 40">
            <text x="0" y="27" fontFamily="system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" fontWeight="900" fontSize="30" letterSpacing="-1.5" fill="currentColor">VO</text>
            <line x1="1" y1="34" x2="44" y2="34" stroke="currentColor" strokeWidth="4" />
          </svg>
        </div>
        <div className="min-w-0 leading-tight">
          <span className="block text-[10px] text-[var(--color-text-secondary)]">{tBrand('poweredBy')}</span>
          <span className="block truncate text-[11px] font-semibold text-[var(--color-text-primary)] group-hover:underline">
            VO Communication Group
          </span>
        </div>
      </a>
    </aside>
    </>
  )
}
