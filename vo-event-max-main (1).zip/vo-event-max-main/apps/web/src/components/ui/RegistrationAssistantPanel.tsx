'use client'

import { useState } from 'react'
import { useTranslations } from 'next-intl'
import { Loader2, Sparkles, Wand2, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { api, errorMessage, type RegistrationProposal } from '@/lib/api'

/**
 * Describe the event; get a form.
 *
 * Configuring this page by hand is forty-six on/off switches, forty-six
 * "required" switches, an order and an appearance — every one of them obvious
 * once you know what the event is, and tedious to click one at a time. So the
 * organizer writes two sentences instead.
 *
 * Two properties matter more than the answer's quality:
 *
 *   **Nothing is applied until it is read.** The proposal is rendered as a
 *   list of what would change, with a count, and applying it is a separate
 *   click. A wrong answer costs a glance, not a form three hundred people have
 *   already filled in.
 *
 *   **It always answers.** With no AI provider configured, or an unreachable
 *   one, the API falls back to reading the same brief with keywords and says
 *   so. A rough proposal an organizer edits beats a spinner that ends in an
 *   error, and the badge tells them which of the two they are looking at.
 */
export function RegistrationAssistantPanel({
  eventId,
  onApply,
}: {
  eventId: string
  /** Applies to the editor's local state only. The organizer still saves —
   *  which keeps "the assistant proposed it" and "I published it" as two
   *  separate decisions. */
  onApply: (proposal: RegistrationProposal) => void
}) {
  const t = useTranslations('registrationAssistant')
  const [description, setDescription] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [proposal, setProposal] = useState<RegistrationProposal | null>(null)

  const ask = async () => {
    if (busy || !description.trim()) return
    setBusy(true)
    setError(null)
    setProposal(null)
    try {
      setProposal(await api.events.suggestRegistrationForm(eventId, description))
    } catch (err) {
      setError(errorMessage(err, t('failed')))
    } finally {
      setBusy(false)
    }
  }

  return (
    <Card className="p-6">
      <div className="flex items-start gap-3">
        <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-[var(--color-accent)]" />
        <div className="min-w-0 flex-1">
          <h2 className="text-sm font-semibold text-[var(--color-text-primary)]">{t('title')}</h2>
          <p className="mt-1 text-xs text-[var(--color-text-secondary)]">{t('subtitle')}</p>
        </div>
      </div>

      <textarea
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder={t('placeholder')}
        rows={3}
        maxLength={2000}
        disabled={busy}
        className="mt-4 w-full resize-y rounded-lg border border-[var(--color-border)] px-3 py-2 text-sm text-[var(--color-text-primary)] outline-none focus:border-[var(--color-accent)]"
      />

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Button
          type="button"
          onClick={ask}
          disabled={busy || !description.trim()}
          className="flex items-center gap-1.5"
        >
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Wand2 className="h-3.5 w-3.5" />}
          {busy ? t('working') : t('propose')}
        </Button>
        <p className="text-xs text-[var(--color-text-secondary)]">{t('nothingSavedYet')}</p>
      </div>

      {error && (
        <p className="mt-3 rounded-md border border-[var(--color-danger)] bg-[var(--color-danger-light)] px-3 py-2 text-xs text-[var(--color-danger)]">
          {error}
        </p>
      )}

      {proposal && (
        <div className="mt-4 rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-4">
          <div className="flex flex-wrap items-start justify-between gap-2">
            <span
              className={
                proposal.source === 'ai'
                  ? 'rounded-full bg-[var(--color-accent-light)] px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--color-accent)]'
                  : 'rounded-full bg-[var(--color-warning-light)] px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--color-warning)]'
              }
            >
              {proposal.source === 'ai' ? t('byModel') : t('byKeywords')}
            </span>
            <button
              type="button"
              onClick={() => setProposal(null)}
              aria-label={t('discard')}
              className="text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {proposal.summary && (
            <p className="mt-2 text-sm text-[var(--color-text-primary)]">{proposal.summary}</p>
          )}

          <p className="mt-2 text-xs text-[var(--color-text-secondary)]">
            {t('wouldAsk', { count: proposal.asked_count })}
            {proposal.custom_fields.length > 0 && ` · ${t('plusOwn', { count: proposal.custom_fields.length })}`}
          </p>

          {proposal.custom_fields.length > 0 && (
            <ul className="mt-2 flex flex-wrap gap-1.5">
              {proposal.custom_fields.map((field) => (
                <li
                  key={field.label}
                  className="rounded-full border border-[var(--color-border)] px-2 py-0.5 text-[11px] text-[var(--color-text-secondary)]"
                >
                  {field.label}
                </li>
              ))}
            </ul>
          )}

          <div className="mt-3 flex flex-wrap gap-2">
            <Button
              type="button"
              onClick={() => { onApply(proposal); setProposal(null) }}
              className="flex items-center gap-1.5"
            >
              {t('apply')}
            </Button>
            <Button type="button" variant="outline" onClick={() => setProposal(null)}>
              {t('discard')}
            </Button>
          </div>
          <p className="mt-2 text-[11px] text-[var(--color-text-secondary)]">{t('applyHint')}</p>
        </div>
      )}
    </Card>
  )
}
