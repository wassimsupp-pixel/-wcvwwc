'use client'

import React, { useState } from 'react'
import { useTranslations } from 'next-intl'
import { Wallet, Loader2, Mail, ChevronDown, ChevronRight } from 'lucide-react'
import { api, errorMessage, type OwnExpenseNoticePlan } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * A grouped send of individual letters.
 *
 * Thirty-six people on the live event travel outside the programme's dates —
 * 141 nights nobody has agreed to pay for. Telling them is one action, but it
 * is thirty-six separate letters: each carries that person's own flight dates
 * and their own night count, in their own language, and mentions nobody else.
 *
 * Nothing is written until the drafts have been read. A message telling
 * somebody that nights they have already booked are at their own expense gets
 * read twice and forwarded to a manager, so the whole text is shown first —
 * not a count, not a template, the actual letters.
 */
export function OwnExpenseCampaign({ eventId }: { eventId: string }) {
  const t = useTranslations('ownExpenseMail')
  const [plan, setPlan] = useState<OwnExpenseNoticePlan | null>(null)
  const [busy, setBusy] = useState<'' | 'preview' | 'create'>('')
  const [error, setError] = useState('')
  const [done, setDone] = useState('')
  const [minNights, setMinNights] = useState(1)
  const [sender, setSender] = useState('')
  const [openDraft, setOpenDraft] = useState<string | null>(null)

  async function preview() {
    setBusy('preview'); setError(''); setDone('')
    try {
      setPlan(await api.ownExpenseNotices.preview(eventId, { min_nights: minNights, sender }))
    } catch (err) {
      setError(errorMessage(err, t('errPreview')))
      setPlan(null)
    } finally {
      setBusy('')
    }
  }

  async function create() {
    if (!plan || plan.drafts.length === 0) return
    setBusy('create'); setError('')
    try {
      const res = await api.ownExpenseNotices.create(eventId, { min_nights: minNights, sender })
      setDone(t('created', { count: res.count }))
      setPlan(null)
    } catch (err) {
      setError(errorMessage(err, t('errCreate')))
    } finally {
      setBusy('')
    }
  }

  return (
    <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white p-5 shadow-sm">
      <p className="flex items-center gap-2 text-sm font-semibold text-[var(--color-text-primary)]">
        <Wallet className="h-4 w-4 text-[var(--color-accent)]" />
        {t('title')}
      </p>
      <p className="mt-1 text-xs text-[var(--color-text-secondary)]">{t('subtitle')}</p>

      <div className="mt-3 flex flex-wrap items-end gap-3">
        <label className="flex flex-col gap-1 text-xs text-[var(--color-text-secondary)]">
          {t('minNights')}
          <input
            type="number" min={1} max={60} value={minNights}
            onChange={(e) => setMinNights(Math.max(1, Number(e.target.value) || 1))}
            className="w-24 rounded-md border border-[var(--color-border)] px-2 py-1.5 text-sm"
          />
        </label>
        <label className="flex flex-1 flex-col gap-1 text-xs text-[var(--color-text-secondary)] sm:max-w-xs">
          {t('sender')}
          <input
            type="text" maxLength={80} value={sender}
            onChange={(e) => setSender(e.target.value)}
            placeholder={t('senderPlaceholder')}
            className="rounded-md border border-[var(--color-border)] px-2 py-1.5 text-sm"
          />
        </label>
        <button
          onClick={preview}
          disabled={busy !== ''}
          className="flex items-center gap-2 rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-3 py-2 text-sm font-medium text-[var(--color-text-primary)] disabled:opacity-50"
        >
          {busy === 'preview' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Mail className="h-4 w-4" />}
          {t('preview')}
        </button>
      </div>

      {error && (
        <p className="mt-3 rounded-md border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/5 px-3 py-2 text-xs text-[var(--color-danger)]">
          {error}
        </p>
      )}
      {done && (
        <p className="mt-3 rounded-md border border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-3 py-2 text-xs text-[var(--color-text-primary)]">
          {done}
        </p>
      )}

      {plan && (
        <div className="mt-4">
          <p className="text-sm font-semibold text-[var(--color-text-primary)]">
            {t('summary', { count: plan.summary.notices, nights: plan.summary.nights })}
          </p>
          <p className="mt-0.5 text-xs text-[var(--color-text-secondary)]">
            {Object.entries(plan.summary.by_language)
              .map(([lang, n]) => `${n} × ${lang.toUpperCase()}`)
              .join(' · ')}
          </p>

          {/* Named, not counted: the usual reason is that we have no address
              for them, and no amount of emailing will fix that. */}
          {plan.skipped.length > 0 && (
            <p className="mt-2 rounded-md bg-[var(--color-warning)]/10 px-3 py-2 text-xs text-[var(--color-text-primary)]">
              {t('skipped', { count: plan.skipped.length })}{' '}
              {plan.skipped.slice(0, 6).map((s) => s.name || s.participant_id).join(', ')}
              {plan.skipped.length > 6 && ` … +${plan.skipped.length - 6}`}
            </p>
          )}

          {plan.drafts.length > 0 && (
            <div className="mt-3 max-h-96 overflow-auto rounded-lg border border-[var(--color-border)]">
              <ul className="divide-y divide-[var(--color-border)]">
                {plan.drafts.map((d) => (
                  <li key={d.participant_id}>
                    <button
                      type="button"
                      onClick={() => setOpenDraft(openDraft === d.participant_id ? null : d.participant_id)}
                      className="flex w-full flex-wrap items-center gap-x-3 gap-y-1 px-3 py-2 text-left text-xs hover:bg-[var(--color-bg-subtle)]"
                    >
                      {openDraft === d.participant_id
                        ? <ChevronDown className="h-3.5 w-3.5 shrink-0" />
                        : <ChevronRight className="h-3.5 w-3.5 shrink-0" />}
                      <span className="font-medium text-[var(--color-text-primary)]">{d.name}</span>
                      <span className="rounded-full bg-[var(--color-accent)]/10 px-2 py-0.5 font-semibold text-[var(--color-accent)]">
                        {t('nights', { count: d.nights })}
                      </span>
                      <span className="text-[var(--color-text-secondary)]">{d.email}</span>
                      <span className="ml-auto rounded border border-[var(--color-border)] px-1.5 text-[10px] uppercase text-[var(--color-text-secondary)]">
                        {d.language}
                      </span>
                    </button>
                    {openDraft === d.participant_id && (
                      <div className="border-t border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-3 py-3">
                        <p className="mb-2 text-xs font-semibold text-[var(--color-text-primary)]">
                          {d.subject}
                        </p>
                        <pre className="whitespace-pre-wrap font-sans text-xs leading-relaxed text-[var(--color-text-secondary)]">
                          {d.body}
                        </pre>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <button
              onClick={create}
              disabled={busy !== '' || plan.drafts.length === 0}
              className={cn(
                'flex items-center gap-2 rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white disabled:opacity-60'
              )}
            >
              {busy === 'create' && <Loader2 className="h-4 w-4 animate-spin" />}
              {t('create', { count: plan.drafts.length })}
            </button>
            <button
              onClick={() => setPlan(null)}
              className="rounded-lg border border-[var(--color-border)] bg-white px-3 py-2 text-sm text-[var(--color-text-secondary)]"
            >
              {t('cancel')}
            </button>
            <span className="text-xs text-[var(--color-text-secondary)]">{t('draftHint')}</span>
          </div>
        </div>
      )}
    </div>
  )
}
