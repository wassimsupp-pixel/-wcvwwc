'use client'

import React, { useEffect, useState } from 'react'
import { useTranslations } from 'next-intl'
import { Download, ShieldCheck, ArrowRight, Plus, Minus } from 'lucide-react'
import { api, type ExportChange, type ExportChangeSummary, type SupplierProfile } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * Supplier exports (§6) and the UPDATES preview (§7).
 *
 * The columns are shown BEFORE the file is generated, on purpose: somebody
 * about to email a spreadsheet to an outside company should be able to see
 * exactly what is in it beforehand, not after. The server enforces the same
 * list — this display is a courtesy, never the guarantee.
 */
export function SupplierExports({ eventId }: { eventId: string }) {
  const t = useTranslations('supplierExports')
  const [profiles, setProfiles] = useState<SupplierProfile[]>([])
  const [selected, setSelected] = useState<string>('')
  const [chosen, setChosen] = useState<string[]>([])
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')

  const [changes, setChanges] = useState<ExportChange[]>([])
  const [summary, setSummary] = useState<ExportChangeSummary | null>(null)

  useEffect(() => {
    let cancelled = false
    api.supplierExports.profiles(eventId)
      .then((res) => {
        if (cancelled) return
        setProfiles(res.profiles)
        setSelected(res.profiles[0]?.profile || '')
      })
      .catch(() => { /* the section simply stays empty */ })
    api.supplierExports.updates(eventId)
      .then((res) => {
        if (cancelled) return
        setChanges(res.changes)
        setSummary(res.summary)
      })
      .catch(() => { /* no snapshot yet — nothing to compare */ })
    return () => { cancelled = true }
  }, [eventId])

  const profile = profiles.find((p) => p.profile === selected)
  const columns = profile?.profile === 'custom'
    ? chosen.map((key) => profile.choices?.find((c) => c.key === key)?.label || key)
    : profile?.columns ?? []

  async function generate() {
    if (!profile) return
    setBusy(true)
    setMessage('')
    try {
      const created = await api.supplierExports.create(eventId, profile.profile, chosen)
      // Generating without handing the file over left somebody staring at a
      // success message with an empty Downloads folder.
      const filename = await api.exports.saveToDisk(String(created.id))
      setMessage(t('downloaded', { label: filename }))
    } catch (err) {
      setMessage(err instanceof Error ? err.message : t('errExport'))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-6">
      <section className="rounded-lg border border-[var(--color-border)] bg-white p-5">
        <h2 className="text-base font-semibold text-[var(--color-text-primary)]">
          {t('title')}
        </h2>
        <p className="mt-1 flex items-start gap-1.5 text-sm text-[var(--color-text-secondary)]">
          <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[var(--color-accent)]" />
          {t('privacyHint')}
        </p>

        <div className="mt-4 flex flex-wrap gap-2">
          {profiles.map((p) => (
            <button
              key={p.profile}
              onClick={() => { setSelected(p.profile); setChosen([]); setMessage('') }}
              className={cn(
                'rounded-lg border px-3 py-1.5 text-sm font-medium transition-colors',
                selected === p.profile
                  ? 'border-[var(--color-accent)] bg-[var(--color-accent)] text-white'
                  : 'border-[var(--color-border)] text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]'
              )}
            >
              {p.label}
            </button>
          ))}
        </div>

        {profile?.profile === 'custom' && (
          <div className="mt-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-[var(--color-text-secondary)]">
              {t('columns')}
            </p>
            <div className="flex flex-wrap gap-1.5">
              {(profile.choices || []).map((c) => {
                const on = chosen.includes(c.key)
                return (
                  <button
                    key={c.key}
                    onClick={() => setChosen((ks) =>
                      on ? ks.filter((k) => k !== c.key) : [...ks, c.key]
                    )}
                    className={cn(
                      'flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs transition-colors',
                      on
                        ? 'border-[var(--color-accent)] bg-[var(--color-accent)]/10 text-[var(--color-accent)]'
                        : 'border-[var(--color-border)] text-[var(--color-text-secondary)]'
                    )}
                  >
                    {on ? <Minus className="h-3 w-3" /> : <Plus className="h-3 w-3" />}
                    {c.label}
                  </button>
                )
              })}
            </div>
          </div>
        )}

        {columns.length > 0 && (
          <div className="mt-4 rounded-lg bg-[var(--color-bg-subtle)] p-3">
            <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-[var(--color-text-secondary)]">
              {t('preview')}
            </p>
            <p className="text-sm text-[var(--color-text-primary)]">{columns.join(' · ')}</p>
          </div>
        )}

        <button
          onClick={generate}
          disabled={busy || !profile}
          className="mt-4 flex items-center gap-2 rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
        >
          <Download className="h-4 w-4" />
          {busy ? t('generating') : t('generate')}
        </button>

        {message && <p className="mt-3 text-sm text-[var(--color-text-secondary)]">{message}</p>}
      </section>

      <section className="rounded-lg border border-[var(--color-border)] bg-white p-5">
        <h2 className="text-base font-semibold text-[var(--color-text-primary)]">
          {t('changesSince')}
        </h2>
        {!summary || summary.changes === 0 ? (
          <p className="mt-2 text-sm text-[var(--color-text-secondary)]">
            {t('firstExport')}
          </p>
        ) : (
          <>
            <div className="mt-3 flex flex-wrap gap-2 text-xs">
              <Badge tone="new">{summary.new} nouveau(x)</Badge>
              <Badge tone="upd">{t('changedCount', { count: summary.updated })}</Badge>
              <Badge tone="del">{t('cancelledCount', { count: summary.cancelled })}</Badge>
            </div>
            <div className="mt-4 max-h-80 overflow-y-auto rounded-lg border border-[var(--color-border)]">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-[var(--color-bg-subtle)]">
                  <tr>
                    <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-[var(--color-text-secondary)]">{t('thStatus')}</th>
                    <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-[var(--color-text-secondary)]">{t('thParticipant')}</th>
                    <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-[var(--color-text-secondary)]">{t('thInfo')}</th>
                    <th className="px-3 py-2 text-left text-xs font-semibold uppercase text-[var(--color-text-secondary)]">{t('thChange')}</th>
                  </tr>
                </thead>
                <tbody>
                  {changes.map((c, i) => (
                    <tr key={i} className="border-t border-[var(--color-border)]">
                      <td className="px-3 py-2">
                        <Badge tone={c.status === 'NEW' ? 'new' : c.status === 'UPDATED' ? 'upd' : 'del'}>
                          {c.status}
                        </Badge>
                      </td>
                      <td className="px-3 py-2 text-[var(--color-text-primary)]">{c.participant_name}</td>
                      <td className="px-3 py-2 text-[var(--color-text-secondary)]">{c.label || '—'}</td>
                      <td className="px-3 py-2">
                        {c.status === 'UPDATED' ? (
                          <span className="flex items-center gap-1.5 text-[var(--color-text-primary)]">
                            <span className="text-[var(--color-text-secondary)] line-through">{c.old || '—'}</span>
                            <ArrowRight className="h-3 w-3 shrink-0 text-[var(--color-text-secondary)]" />
                            <span>{c.new || '—'}</span>
                          </span>
                        ) : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </section>
    </div>
  )
}

function Badge({ children, tone }: { children: React.ReactNode; tone: 'new' | 'upd' | 'del' }) {
  const tones = {
    new: 'bg-emerald-50 text-emerald-700',
    upd: 'bg-amber-50 text-amber-700',
    del: 'bg-red-50 text-red-700',
  }
  return (
    <span className={cn('rounded-full px-2 py-0.5 text-xs font-medium', tones[tone])}>
      {children}
    </span>
  )
}
