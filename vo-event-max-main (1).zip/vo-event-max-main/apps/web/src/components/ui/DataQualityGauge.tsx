'use client'

import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts'
import { useTranslations } from 'next-intl'
import { cn } from '@/lib/utils'

interface DataQualityGaugeProps {
  percentage: number
  label?: string
  size?: number
  className?: string
  /** When provided, the gauge becomes clickable and calls this on click. */
  onClick?: () => void
}

export function DataQualityGauge({
  percentage,
  label,
  size = 140,
  className,
  onClick,
}: DataQualityGaugeProps) {
  const t = useTranslations('gauge')
  // Defaulted in the body, not in the signature: a parameter default cannot
  // call a hook.
  const caption = label ?? t('overall')
  const clampedPct = Math.min(100, Math.max(0, percentage))

  const color =
    clampedPct >= 80
      ? 'var(--color-success)'
      : clampedPct >= 60
        ? 'var(--color-warning)'
        : 'var(--color-danger)'

  const trackColor = 'var(--color-border)'

  const data = [
    { value: clampedPct },
    { value: 100 - clampedPct },
  ]

  const textColor =
    clampedPct >= 80
      ? '#47AB75'
      : clampedPct >= 60
        ? '#F99A4C'
        : '#D9534F'

  return (
    <div
      className={cn(
        'flex flex-col items-center',
        onClick && 'cursor-pointer rounded-lg transition-colors hover:bg-[var(--color-bg-subtle)]',
        className
      )}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={onClick ? (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onClick() } } : undefined}
    >
      <div style={{ width: size, height: size }} className="relative">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={size * 0.32}
              outerRadius={size * 0.46}
              startAngle={90}
              endAngle={-270}
              dataKey="value"
              strokeWidth={0}
            >
              <Cell fill={color} />
              <Cell fill={trackColor} />
            </Pie>
          </PieChart>
        </ResponsiveContainer>

        {/* Center text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span
            className="text-2xl font-bold leading-none tabular-nums"
            style={{ color: textColor }}
          >
            {clampedPct}%
          </span>
        </div>
      </div>

      {label && (
        <p className="mt-2 text-center text-xs font-medium text-[var(--color-text-secondary)]">
          {caption}
        </p>
      )}
    </div>
  )
}
