'use client'

import { useCallback, useEffect, useState } from 'react'
import { useTranslations } from 'next-intl'
import { localeTag } from '@/lib/dates'
import Link from 'next/link'
import { AlertTriangle, CheckCircle2, Loader2, Send, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { api } from '@/lib/api'

interface ConsolidationGateDialogProps {
  eventId: string
  locale: string
  /** How many participants the campaign will reach, when a preview ran. */
  recipientCount?: number | null
  onCancel: () => void
  onConfirm: () => void
}

type Freshness = 'loading' | 'never' | 'stale' | 'fresh' | 'unknown'

/**
 * The question asked before a mass send: has the consolidation been run?
 *
 * A campaign is written from the master list, and the master list is only as
 * current as the last consolidation. Sending before it has run means four
 * hundred people receive yesterday's data — and unlike a wrong export, an
 * e-mail cannot be taken back. So the dialog states what it can actually
 * verify (when the last run finished, whether a file arrived after it) and
 * still makes the human tick the box, because only they know whether the file
 * on their desk has been imported at all.
 */
export function ConsolidationGateDialog({
  eventId,
  locale,
  recipientCount,
  onCancel,
  onConfirm,
}: ConsolidationGateDialogProps) {
  const t = useTranslations('sendGate')
  const [state, setState] = useState<Freshness>('loading')
  const [lastRunAt, setLastRunAt] = useState<string | null>(null)
  const [staleFile, setStaleFile] = useState<string | null>(null)
  const [acknowledged, setAcknowledged] = useState(false)

  const load = useCallback(async () => {
    try {
      const runs = await api.consolidation.list(eventId)
      const done = runs.find((r) => r.status === 'completed' && r.finished_at)
      if (!done?.finished_at) {
        setState('never')
        return
      }
      setLastRunAt(done.finished_at)

      // A file imported after the run is the one case we can prove is stale.
      let files: Awaited<ReturnType<typeof api.files.list>> = []
      try {
        files = await api.files.list(eventId)
      } catch {
        // File history is a bonus here, not a prerequisite: without it we can
        // still report when the last run finished.
        setState('fresh')
        return
      }
      const runAt = new Date(done.finished_at).getTime()
      const later = files
        .filter((f) => f.uploaded_at && new Date(f.uploaded_at).getTime() > runAt)
        .sort((a, b) => (a.uploaded_at < b.uploaded_at ? 1 : -1))[0]
      if (later) {
        setStaleFile(later.filename || t('someFile'))
        setState('stale')
      } else {
        setState('fresh')
      }
    } catch {
      setState('unknown')
    }
  }, [eventId])

  useEffect(() => { load() }, [load])

  const fmt = (d: string | null) =>
    d
      ? new Date(d).toLocaleString(localeTag(locale), {
          dateStyle: 'long',
          timeStyle: 'short',
        })
      : '—'

  const banner = {
    loading: null,
    never: {
      tone: 'danger' as const,
      title: t('neverTitle'),
      detail: t('neverDetail'),
    },
    stale: {
      tone: 'warning' as const,
      title: staleFile
        ? t('staleTitleNamed', { file: staleFile })
        : t('staleTitle'),
      detail: t('staleDetail', { date: fmt(lastRunAt) }),
    },
    fresh: {
      tone: 'success' as const,
      title: t('freshTitle', { date: fmt(lastRunAt) }),
      detail: t('freshDetail'),
    },
    unknown: {
      tone: 'warning' as const,
      title: t('unknownTitle'),
      detail: t('unknownDetail'),
    },
  }[state]

  const toneClass = {
    danger: 'bg-[var(--color-danger-light)] text-[var(--color-danger)]',
    warning: 'bg-[var(--color-warning-light)] text-[var(--color-text-primary)]',
    success: 'bg-[var(--color-success-light)] text-[var(--color-success)]',
  }

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 p-4"
      onClick={onCancel}
      role="dialog"
      aria-modal="true"
      aria-label={t('dialogLabel')}
    >
      <div className="w-full max-w-lg rounded-xl bg-white shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b px-5 py-4">
          <h3 className="text-sm font-bold text-[var(--color-text-primary)]">
            {t('title')}
          </h3>
          <button
            type="button"
            onClick={onCancel}
            aria-label={t('close')}
            className="rounded-full p-1 text-[var(--color-text-secondary)] hover:bg-slate-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-4 px-5 py-4">
          <p className="text-sm text-[var(--color-text-primary)]">
            {recipientCount
              ? t('recipientsKnown', { count: recipientCount })
              : t('recipientsAll')}{' '}
            <span className="font-semibold">{t('irreversible')}</span>
          </p>

          {state === 'loading' ? (
            <div className="flex items-center gap-2 rounded-lg bg-slate-50 px-3 py-2 text-xs text-[var(--color-text-secondary)]">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>{t('checking')}</span>
            </div>
          ) : banner ? (
            <div className={`flex items-start gap-2 rounded-lg px-3 py-2 text-xs ${toneClass[banner.tone]}`}>
              {banner.tone === 'success'
                ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
                : <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />}
              <span>
                <span className="font-semibold">{banner.title}</span>
                <br />
                {banner.detail}
              </span>
            </div>
          ) : null}

          {(state === 'never' || state === 'stale') && (
            <Link
              href={`/${locale}/events/${eventId}/master-list`}
              className="inline-block text-xs font-semibold text-[var(--color-accent)] underline"
            >
              {t('runFirst')}
            </Link>
          )}

          <label className="flex cursor-pointer items-start gap-2 rounded-lg border border-[var(--color-border)] p-3 text-xs text-[var(--color-text-primary)]">
            <input
              type="checkbox"
              checked={acknowledged}
              onChange={(e) => setAcknowledged(e.target.checked)}
              className="mt-0.5 h-4 w-4 accent-[var(--color-accent)]"
            />
            <span>
              {t('acknowledge')}
            </span>
          </label>
        </div>

        <div className="flex items-center justify-end gap-2 border-t px-5 py-4">
          <Button variant="outline" onClick={onCancel}>{t('cancel')}</Button>
          <Button
            onClick={onConfirm}
            disabled={!acknowledged || state === 'loading'}
            className="flex items-center gap-2 bg-[var(--color-accent)] text-white"
          >
            <Send className="h-4 w-4" />
            {t('send')}
          </Button>
        </div>
      </div>
    </div>
  )
}
