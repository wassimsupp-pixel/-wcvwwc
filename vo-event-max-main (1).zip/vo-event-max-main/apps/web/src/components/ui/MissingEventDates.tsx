'use client'

import { useEffect, useState } from 'react'
import { useTranslations } from 'next-intl'
import Link from 'next/link'
import { CalendarX, ArrowRight } from 'lucide-react'
import { api } from '@/lib/api'

/**
 * Several checks need the programme's own dates and can only stay silent
 * without them — they cannot report a stay "after the event" when nothing
 * says when the event ends.
 *
 * Staying silent is the right behaviour (announcing that everybody is on a
 * private holiday because a field is blank would be worse), but saying
 * nothing about WHY is not: the screen then looks like it found nothing,
 * which is indistinguishable from everything being fine.
 *
 * Renders nothing at all once the dates are set, and nothing while loading —
 * a banner that flashes on every page load is its own kind of noise.
 */
export function MissingEventDates({ eventId, locale }: { eventId: string; locale: string }) {
  const t = useTranslations('missingDates')
  const [missing, setMissing] = useState(false)

  useEffect(() => {
    let cancelled = false
    api.events.get(eventId)
      .then((ev) => {
        if (!cancelled) setMissing(!ev.start_date || !ev.end_date)
      })
      .catch(() => { /* the banner is a courtesy; never break the page for it */ })
    return () => { cancelled = true }
  }, [eventId])

  if (!missing) return null

  return (
    <div className="mb-6 rounded-lg border border-[var(--color-warning)]/40 bg-[var(--color-warning)]/5 p-4">
      <p className="flex items-center gap-2 text-sm font-semibold text-[var(--color-text-primary)]">
        <CalendarX className="h-4 w-4 shrink-0 text-[var(--color-warning)]" />
        {t('title')}
      </p>
      <p className="mt-1 text-xs text-[var(--color-text-secondary)]">
        {t('intro')}
      </p>
      <ul className="mt-2 space-y-0.5 text-xs text-[var(--color-text-secondary)]">
        <li>{t('item1')}</li>
        <li>{t('item2')}</li>
        <li>{t('item3')}</li>
      </ul>
      <Link
        href={`/${locale}/events/${eventId}/dashboard`}
        className="mt-3 inline-flex items-center gap-1.5 rounded-lg border border-[var(--color-border)] bg-white px-3 py-1.5 text-xs font-medium text-[var(--color-text-primary)]"
      >
        {t('cta')} <ArrowRight className="h-3.5 w-3.5" />
      </Link>
    </div>
  )
}
