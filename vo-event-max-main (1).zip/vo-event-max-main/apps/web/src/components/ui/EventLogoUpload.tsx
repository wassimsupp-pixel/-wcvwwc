'use client'

import { useCallback, useEffect, useState } from 'react'
import { useTranslations } from 'next-intl'
import { ImageIcon, Loader2 } from 'lucide-react'
import { api } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * This event's own logo on the public registration form (point 11), instead
 * of the default MAX mark every event showed before.
 *
 * Two steps, deliberately not one: upload returns a URL and previews it here
 * first, PATCHing the event only happens once the preview looks right. The
 * mini-site image editor next to this on the page works the same way for the
 * same reason — an upload that immediately went live would show a bad crop
 * or a wrong file to every visitor before anyone caught it.
 */
export function EventLogoUpload({ eventId }: { eventId: string }) {
  const t = useTranslations('logoUpload')
  const [logoUrl, setLogoUrl] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    try {
      const event = await api.events.get(eventId)
      setLogoUrl(event.logo_url || null)
    } catch {
      setLogoUrl(null)
    }
  }, [eventId])

  useEffect(() => { load() }, [load])

  async function handleFile(file: File) {
    setUploading(true)
    setError('')
    setMessage('')
    try {
      const { url } = await api.events.uploadLogo(eventId, file)
      await api.events.update(eventId, { logo_url: url })
      setLogoUrl(url)
      setMessage(t('saved'))
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errUpload'))
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="rounded-lg border border-[var(--color-border)] bg-white p-5">
      <h2 className="text-base font-semibold text-[var(--color-text-primary)]">
        {t('title')}
      </h2>
      <p className="mt-1 text-sm text-[var(--color-text-secondary)]">
        {t('hint')}
      </p>

      <div className="mt-4 flex items-center gap-4">
        <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-lg border border-dashed border-[var(--color-border)] bg-[var(--color-bg-subtle)]">
          {logoUrl ? (
            // A remote, per-event logo isn't a build-time-known asset.
            // eslint-disable-next-line @next/next/no-img-element
            <img src={logoUrl} alt={t('current')} className="h-full w-full rounded-lg object-contain p-1" />
          ) : (
            <ImageIcon className="h-6 w-6 text-[var(--color-text-secondary)]" />
          )}
        </div>

        <input
          type="file"
          accept="image/jpeg,image/png"
          id="event-logo-upload"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0]
            e.target.value = ''
            if (file) handleFile(file)
          }}
        />
        <label
          htmlFor="event-logo-upload"
          className={cn(
            'flex cursor-pointer items-center gap-2 rounded-lg border border-[var(--color-border)] px-4 py-2 text-sm font-medium text-[var(--color-text-primary)] hover:bg-[var(--color-bg-subtle)]',
            uploading && 'pointer-events-none opacity-60'
          )}
        >
          {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImageIcon className="h-4 w-4" />}
          {logoUrl ? t('replace') : t('upload')}
        </label>
      </div>

      {message && <p className="mt-3 text-xs text-[var(--color-success)]">{message}</p>}
      {error && <p className="mt-3 text-xs text-[var(--color-danger)]">{error}</p>}
    </div>
  )
}
