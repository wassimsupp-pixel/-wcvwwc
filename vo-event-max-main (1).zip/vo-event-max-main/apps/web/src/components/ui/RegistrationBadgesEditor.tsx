'use client'

import { useState } from 'react'
import { useTranslations } from 'next-intl'
import { Loader2, Check, Plus, Trash2, Tag } from 'lucide-react'
import { api, errorMessage, type RegistrationBadge } from '@/lib/api'

/**
 * Named audiences for the registration form (point 13, v1) — VIP, Speaker,
 * Staff, whatever the event calls them. A badge is never chosen by the
 * registrant: it comes from which link they were sent (?badge=slug on the
 * same registration token), the way a real event sends the VIP list a
 * different link from the general one.
 *
 * Deleting a badge here does not touch any field's own badges list
 * elsewhere — a field naming a badge that no longer exists simply stops
 * matching it, same as a rooming preset referenced after being deleted.
 */
export function RegistrationBadgesEditor({
  eventId, badges, onSaved,
}: {
  eventId: string
  badges: RegistrationBadge[] | null
  onSaved: (badges: RegistrationBadge[]) => void
}) {
  const t = useTranslations('badgesEditor')
  const tAct = useTranslations('actions')
  const [draft, setDraft] = useState('')
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function persist(next: { id?: string; name: string }[]) {
    setSaving(true)
    setError(null)
    setSaved(false)
    try {
      const res = await api.events.setRegistrationBadges(eventId, next)
      onSaved(res.badges)
      setSaved(true)
      setTimeout(() => setSaved(false), 2000)
    } catch (err) {
      setError(errorMessage(err, t('errSave')))
    } finally {
      setSaving(false)
    }
  }

  function addBadge() {
    const name = draft.trim()
    if (!name || !badges) return
    setDraft('')
    persist([...badges.map((b) => ({ id: b.id, name: b.name })), { name }])
  }

  function removeBadge(id: string) {
    if (!badges) return
    persist(badges.filter((b) => b.id !== id).map((b) => ({ id: b.id, name: b.name })))
  }

  return (
    <div>
      <div className="flex items-start gap-3">
        <Tag className="mt-0.5 h-5 w-5 shrink-0 text-[var(--color-accent)]" />
        <div>
          <p className="text-sm font-semibold text-[var(--color-text-primary)]">
            {t('title')}
          </p>
          <p className="mt-0.5 max-w-2xl text-xs text-[var(--color-text-secondary)]">
            {t('hint')}
          </p>
        </div>
      </div>

      {error && (
        <p className="mt-3 rounded-lg border border-[var(--color-danger)] bg-[var(--color-danger-light)] px-3 py-2 text-xs text-[var(--color-danger)]">
          {error}
        </p>
      )}

      {!badges ? (
        <p className="mt-3 flex items-center gap-2 text-sm text-[var(--color-text-secondary)]">
          <Loader2 className="h-4 w-4 animate-spin" /> {tAct('loading')}
        </p>
      ) : (
        <>
          <div className="mt-3 flex flex-wrap gap-2">
            {badges.map((b) => (
              <span
                key={b.id}
                className="inline-flex items-center gap-1.5 rounded-full border border-[var(--color-border)] bg-[var(--color-bg-subtle)] py-1 pl-3 pr-1.5 text-xs font-medium text-[var(--color-text-primary)]"
              >
                {b.name}
                <button
                  type="button"
                  onClick={() => removeBadge(b.id)}
                  disabled={saving}
                  title={t('deleteBadge')}
                  className="rounded-full p-0.5 text-[var(--color-text-secondary)] hover:bg-[var(--color-danger-light)] hover:text-[var(--color-danger)] disabled:opacity-40"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </span>
            ))}
            {badges.length === 0 && (
              <span className="text-xs text-[var(--color-text-secondary)]">
                {t('empty')}
              </span>
            )}
          </div>

          <div className="mt-3 flex items-center gap-2">
            <input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addBadge() } }}
              placeholder={t('namePlaceholder')}
              maxLength={40}
              className="w-full max-w-xs rounded-lg border border-[var(--color-border)] px-3 py-1.5 text-sm outline-none focus:border-[var(--color-accent)]"
            />
            <button
              type="button"
              onClick={addBadge}
              disabled={saving || !draft.trim()}
              className="flex items-center gap-1.5 whitespace-nowrap rounded-lg border border-[var(--color-border)] px-3 py-1.5 text-sm font-medium text-[var(--color-text-primary)] hover:bg-[var(--color-bg-subtle)] disabled:opacity-50"
            >
              <Plus className="h-3.5 w-3.5" /> {t('add')}
            </button>
            {saving && <Loader2 className="h-4 w-4 animate-spin text-[var(--color-text-secondary)]" />}
            {saved && !saving && (
              <span className="flex items-center gap-1 text-xs font-medium text-[var(--color-success)]">
                <Check className="h-3.5 w-3.5" /> {t('saved')}
              </span>
            )}
          </div>
        </>
      )}
    </div>
  )
}
