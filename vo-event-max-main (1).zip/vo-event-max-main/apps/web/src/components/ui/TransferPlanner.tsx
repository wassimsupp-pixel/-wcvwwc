'use client'

import React, { useEffect, useState } from 'react'
import { useTranslations } from 'next-intl'
import { Bus, AlertTriangle, Wand2, Check, X, Split, ArrowRightLeft, GripVertical } from 'lucide-react'
import { api, type TransferGroup, type TransferPlan } from '@/lib/api'
import { cn } from '@/lib/utils'

const NEW_GROUP = '__new__'

/** What a dragged passenger carries: which group they are leaving and who they
 *  are. A custom MIME type rather than text/plain, so dropping a text
 *  selection onto a vehicle moves nobody. */
const DRAG_TYPE = 'application/x-vo-plan-passenger'

/**
 * The transfer plan the flights imply (feedback §1).
 *
 * The whole point of this component is that it stands between the proposal and
 * the database. `propose` writes nothing; the organizer removes a group,
 * swaps a vehicle, moves an hour, moves one person into another van or takes
 * them out of the plan entirely — and only what survives on screen is sent to
 * `apply`. A planner that booked what it computed would be exactly what the
 * feedback asks us not to build.
 *
 * Arrivals and departures are shown as two separate sections rather than one
 * interleaved list: nobody reassigns a person arriving on Monday into a group
 * leaving on Thursday, so there is no reason the two should ever compete for
 * the same visual space.
 */
export function TransferPlanner({
  eventId, vehicles, onApplied,
}: {
  eventId: string
  vehicles: { name: string; capacity: number }[]
  onApplied?: () => void
}) {
  const t = useTranslations('transferPlanner')
  const [plan, setPlan] = useState<TransferPlan | null>(null)
  const [groups, setGroups] = useState<TransferGroup[]>([])
  const [loading, setLoading] = useState(false)
  const [applying, setApplying] = useState(false)
  const [message, setMessage] = useState('')
  // The one thing the flight file cannot tell us. Everything else on a
  // transfer sheet is derived — the airports come from each person's own
  // flight — so this is the single field an organizer fills in.
  const [hotel, setHotel] = useState('')
  const [hotelLoaded, setHotelLoaded] = useState(false)

  useEffect(() => {
    let cancelled = false
    api.transfers.getSettings(eventId)
      .then((s) => { if (!cancelled) { setHotel(s.hotel_name || ''); setHotelLoaded(true) } })
      .catch(() => { if (!cancelled) setHotelLoaded(true) })
    return () => { cancelled = true }
  }, [eventId])

  async function propose() {
    setLoading(true)
    setMessage('')
    try {
      // Saved before the plan is computed, not after: the server reads the
      // hotel from the settings, so a name typed and not stored would produce
      // a plan that says "Hôtel" and an organizer who thinks they typed it.
      const current = await api.transfers.getSettings(eventId)
      if ((current.hotel_name || '') !== hotel.trim()) {
        await api.transfers.setSettings(eventId, { ...current, hotel_name: hotel.trim() })
      }
      const res = await api.transfers.propose(eventId)
      setPlan(res)
      setGroups(res.groups)
      if (res.groups.length === 0) {
        setMessage(t('noUsableFlights'))
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : t('errPropose'))
    } finally {
      setLoading(false)
    }
  }

  async function apply() {
    setApplying(true)
    setMessage('')
    try {
      const res = await api.transfers.apply(eventId, groups)
      setMessage(
        t('applied', { count: res.written })
        + (res.skipped ? ' ' + t('appliedSkipped', { count: res.skipped }) : '')
      )
      setPlan(null)
      setGroups([])
      onApplied?.()
    } catch (err) {
      setMessage(err instanceof Error ? err.message : t('errApply'))
    } finally {
      setApplying(false)
    }
  }

  function updateGroup(index: number, patch: Partial<TransferGroup>) {
    setGroups((gs) => gs.map((g, i) => (i === index ? { ...g, ...patch } : g)))
  }

  function removeGroup(index: number) {
    setGroups((gs) => gs.filter((_, i) => i !== index))
  }

  /** Split a group in two. The seat count is deliberately NOT recomputed from
   *  the fleet: somebody splitting a group by hand has a reason the planner
   *  does not know about, and silently re-merging them would undo it. */
  function splitGroup(index: number) {
    setGroups((gs) => {
      const group = gs[index]
      if (group.participant_ids.length < 2) return gs
      const half = Math.ceil(group.participant_ids.length / 2)
      const names = group.participants ?? []
      const first = {
        ...group,
        participant_ids: group.participant_ids.slice(0, half),
        participants: names.slice(0, half),
      }
      const second = {
        ...group,
        participant_ids: group.participant_ids.slice(half),
        participants: names.slice(half),
        sequence: group.sequence + 1,
      }
      first.passengers = first.participant_ids.length
      second.passengers = second.participant_ids.length
      return [...gs.slice(0, index), first, second, ...gs.slice(index + 1)]
    })
  }

  /** Take one person out of a group entirely — they arranged their own way,
   *  or simply should not be on this sheet. A group left with nobody in it
   *  disappears rather than sitting there empty. */
  function removeParticipant(groupIndex: number, participantId: string) {
    setGroups((gs) => {
      const group = gs[groupIndex]
      const ids = group.participant_ids.filter((id) => id !== participantId)
      if (ids.length === 0) return gs.filter((_, i) => i !== groupIndex)
      const updated: TransferGroup = {
        ...group,
        participant_ids: ids,
        participants: (group.participants ?? []).filter((p) => p.id !== participantId),
        passengers: ids.length,
      }
      return gs.map((g, i) => (i === groupIndex ? updated : g))
    })
  }

  /** Move one person from their current group into another — any existing
   *  group, identified by its index in `groups`, or a brand-new group of their
   *  own.
   *
   *  Any group, including one going the other way: the person takes on the
   *  target group's direction along with its time and route, so an arrival
   *  dropped into a departure becomes a departure rather than a passenger in a
   *  van pointing at the wrong endpoint. The two lists were merged precisely
   *  so this move is possible. */
  function moveParticipant(groupIndex: number, participantId: string, target: string) {
    setGroups((gs) => {
      const source = gs[groupIndex]
      const person = (source.participants ?? []).find((p) => p.id === participantId)
        ?? { id: participantId, name: participantId }

      const withoutSource = source.participant_ids.filter((id) => id !== participantId)
      const sourceEmptied = withoutSource.length === 0
      const sourceUpdated: TransferGroup = {
        ...source,
        participant_ids: withoutSource,
        participants: (source.participants ?? []).filter((p) => p.id !== participantId),
        passengers: withoutSource.length,
      }

      if (target === NEW_GROUP) {
        const maxSequence = gs
          .filter((g) => g.direction === source.direction)
          .reduce((m, g) => Math.max(m, g.sequence), 0)
        const fresh: TransferGroup = {
          direction: source.direction,
          pickup_time: source.pickup_time,
          pickup_location: source.pickup_location,
          dropoff_location: source.dropoff_location,
          flight_numbers: source.flight_numbers,
          participant_ids: [participantId],
          participants: [person],
          passengers: 1,
          vehicle: null,
          sequence: maxSequence + 1,
        }
        const withoutEmptySource = sourceEmptied
          ? gs.filter((_, i) => i !== groupIndex)
          : gs.map((g, i) => (i === groupIndex ? sourceUpdated : g))
        return [...withoutEmptySource, fresh]
      }

      const targetIndex = Number(target)
      if (!Number.isInteger(targetIndex) || targetIndex === groupIndex) return gs
      return gs.map((g, i) => {
        if (i === groupIndex) return sourceUpdated
        if (i === targetIndex) {
          return {
            ...g,
            participant_ids: [...g.participant_ids, participantId],
            participants: [...(g.participants ?? []), person],
            passengers: g.participant_ids.length + 1,
          }
        }
        return g
      }).filter((g, i) => !(sourceEmptied && i === groupIndex))
    })
  }

  /** A drop names the destination and the person, never the origin — so the
   *  origin is looked up here. Reusing moveParticipant keeps one set of rules
   *  for both gestures: the dropdown and the drag do exactly the same thing. */
  function dropPassengerInto(targetIndex: number, participantId: string) {
    const from = groups.findIndex((g) => g.participant_ids.includes(participantId))
    if (from < 0 || from === targetIndex) return
    moveParticipant(from, participantId, String(targetIndex))
  }

  const indexed = groups.map((group, index) => ({ group, index }))
  const arrivals = indexed.filter((x) => x.group.direction === 'arrival')
  const departures = indexed.filter((x) => x.group.direction === 'departure')
  // Shown as one list in time order. A dispatcher reads their day forwards,
  // not once for the airport runs and again for the hotel runs; and a group
  // with no time on it belongs at the end, where it is still visible.
  const chronological = [...indexed].sort((a, b) => {
    const at = a.group.pickup_time ?? ''
    const bt = b.group.pickup_time ?? ''
    if (!at) return 1
    if (!bt) return -1
    return at.localeCompare(bt)
  })

  return (
    <div className="rounded-lg border border-[var(--color-border)] bg-white p-5">
      <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold text-[var(--color-text-primary)]">
            {t('title')}
          </h2>
          <p className="mt-1 text-sm text-[var(--color-text-secondary)]">
            {t('planHint')}
          </p>
        </div>
        <div className="flex flex-wrap items-end gap-2">
          <label className="flex flex-col gap-1">
            <span className="text-xs font-medium text-[var(--color-text-secondary)]">{t('hotel')}</span>
            <input
              value={hotel}
              onChange={(e) => setHotel(e.target.value)}
              disabled={!hotelLoaded}
              placeholder={t('hotelPlaceholder')}
              className="w-56 rounded-lg border border-[var(--color-border)] px-3 py-2 text-sm"
            />
          </label>
          <button
            onClick={propose}
            disabled={loading}
            className="flex items-center gap-2 rounded-lg border border-[var(--color-border)] px-4 py-2 text-sm font-medium disabled:opacity-60"
          >
            <Wand2 className="h-4 w-4" />
            {loading ? 'Calcul…' : plan ? 'Recalculer' : t('propose')}
          </button>
        </div>
      </div>

      {message && (
        <p className="mb-4 rounded-lg bg-[var(--color-bg-subtle)] px-3 py-2 text-sm">{message}</p>
      )}

      {plan && groups.length > 0 && (
        <>
          <div className="mb-4 flex flex-wrap gap-2 text-xs">
            <Pill>{t('vehicles', { count: groups.length })}</Pill>
            <Pill>{t('arrivals', { count: arrivals.length })}</Pill>
            <Pill>{t('departures', { count: departures.length })}</Pill>
            {plan.summary.needs_attention > 0 && (
              <Pill tone="warn">{t('toHandle', { count: plan.summary.needs_attention })}</Pill>
            )}
          </div>

          <MovementSection
            title={t('dayPlan')}
            icon={<Bus className="h-4 w-4 text-[var(--color-accent)]" />}
            items={chronological}
            vehicles={vehicles}
            onUpdate={updateGroup}
            onRemoveGroup={removeGroup}
            onSplit={splitGroup}
            onRemoveParticipant={removeParticipant}
            onMoveParticipant={moveParticipant}
            onDropPassengerInto={dropPassengerInto}
          />

          <button
            onClick={apply}
            disabled={applying}
            className="mt-4 flex items-center gap-2 rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
          >
            <Check className="h-4 w-4" />
            {applying ? 'Enregistrement…' : `Valider ${groups.length} transfert(s)`}
          </button>
        </>
      )}
    </div>
  )
}

interface IndexedGroup {
  group: TransferGroup
  index: number
}

function MovementSection({
  title, icon, items, vehicles,
  onUpdate, onRemoveGroup, onSplit, onRemoveParticipant, onMoveParticipant, onDropPassengerInto,
}: {
  title: string
  icon: React.ReactNode
  items: IndexedGroup[]
  vehicles: { name: string; capacity: number }[]
  onUpdate: (index: number, patch: Partial<TransferGroup>) => void
  onRemoveGroup: (index: number) => void
  onSplit: (index: number) => void
  onRemoveParticipant: (index: number, participantId: string) => void
  onMoveParticipant: (index: number, participantId: string, target: string) => void
  onDropPassengerInto: (targetIndex: number, participantId: string) => void
}) {
  const t = useTranslations('transferPlanner')
  if (items.length === 0) return null

  return (
    <div className="mb-4">
      <div className="mb-2 flex items-center gap-2">
        {icon}
        <h3 className="text-sm font-semibold text-[var(--color-text-primary)]">
          {title} <span className="font-normal text-[var(--color-text-secondary)]">({items.length})</span>
        </h3>
      </div>
      <div className="space-y-2">
        {items.map(({ group, index }) => {
          // Same-direction siblings only: the other candidates a person in
          // this group could be moved into.
          const targets = items.filter((x) => x.index !== index)
          return (
            <GroupCard
              key={index}
              group={group}
              targets={targets}
              vehicles={vehicles}
              onUpdate={(patch) => onUpdate(index, patch)}
              onRemoveGroup={() => onRemoveGroup(index)}
              onSplit={() => onSplit(index)}
              onRemoveParticipant={(pid) => onRemoveParticipant(index, pid)}
              onMoveParticipant={(pid, target) => onMoveParticipant(index, pid, target)}
              onDropPassenger={(pid) => onDropPassengerInto(index, pid)}
            />
          )
        })}
      </div>
    </div>
  )
}

function GroupCard({
  group, targets, vehicles, onUpdate, onRemoveGroup, onSplit, onRemoveParticipant,
  onMoveParticipant, onDropPassenger,
}: {
  group: TransferGroup
  targets: IndexedGroup[]
  vehicles: { name: string; capacity: number }[]
  onUpdate: (patch: Partial<TransferGroup>) => void
  onRemoveGroup: () => void
  onSplit: () => void
  onRemoveParticipant: (participantId: string) => void
  onMoveParticipant: (participantId: string, target: string) => void
  onDropPassenger: (participantId: string) => void
}) {
  const t = useTranslations('transferPlanner')
  const people = group.participants ?? group.participant_ids.map((id) => ({ id, name: id }))
  const [dragOver, setDragOver] = useState(false)
  const seats = group.vehicle?.capacity ?? null

  /** Somebody dropped here. `onDropPassenger` knows which group they came
   *  from — this card only knows it is the destination. A drop onto the group
   *  the person is already in is a no-op rather than a duplicate. */
  function acceptDrop(event: React.DragEvent) {
    event.preventDefault()
    setDragOver(false)
    const participantId = event.dataTransfer.getData(DRAG_TYPE)
    if (!participantId || people.some((p) => p.id === participantId)) return
    if (seats !== null && people.length + 1 > seats) {
      const ok = window.confirm(
        t('overCapacityConfirm', { seats, taken: people.length + 1 })
      )
      if (!ok) return
    }
    onDropPassenger(participantId)
  }

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
      onDragLeave={() => setDragOver(false)}
      onDrop={acceptDrop}
      className={cn(
        'rounded-lg border p-3 transition-colors',
        dragOver
          ? 'border-[var(--color-accent)] bg-[var(--color-accent-light)]'
          : group.needs_attention
          ? 'border-[var(--color-danger)]/40 bg-[var(--color-danger)]/5'
          : 'border-[var(--color-border)]'
      )}
    >
      <div className="flex flex-wrap items-center gap-3">
        <input
          type="datetime-local"
          value={toLocalInput(group.pickup_time)}
          onChange={(e) => onUpdate({ pickup_time: fromLocalInput(e.target.value) })}
          className="rounded border border-[var(--color-border)] px-2 py-1 text-sm"
        />

        <select
          value={group.vehicle?.name || ''}
          onChange={(e) => {
            const chosen = vehicles.find((v) => v.name === e.target.value)
            onUpdate({ vehicle: chosen ? { ...chosen } : null })
          }}
          className="rounded border border-[var(--color-border)] bg-white px-2 py-1 text-sm"
        >
          <option value="">{t('vehiclePlaceholder')}</option>
          {vehicles.map((v) => (
            <option key={v.name} value={v.name}>
              {v.name} ({v.capacity} pax)
            </option>
          ))}
        </select>

        <span
          className={cn(
            'rounded-full px-2 py-0.5 text-xs',
            group.vehicle && group.participant_ids.length > group.vehicle.capacity
              ? 'bg-[var(--color-danger)]/10 text-[var(--color-danger)]'
              : 'bg-[var(--color-bg-subtle)] text-[var(--color-text-secondary)]'
          )}
        >
          {group.participant_ids.length} pax
          {group.vehicle && group.participant_ids.length > group.vehicle.capacity
            ? ' ' + t('overCapacity')
            : ''}
        </span>

        {group.flight_numbers.length > 0 && (
          <span className="font-mono text-xs text-[var(--color-text-secondary)]">
            {group.flight_numbers.join(' · ')}
          </span>
        )}

        <div className="ml-auto flex gap-1">
          <IconButton title={t('split')} onClick={onSplit}>
            <Split className="h-4 w-4" />
          </IconButton>
          <IconButton title={t('removeGroup')} onClick={onRemoveGroup}>
            <X className="h-4 w-4" />
          </IconButton>
        </div>
      </div>

      {group.needs_attention === 'no_flight_time' && (
        <p className="mt-2 flex items-center gap-1.5 text-xs text-[var(--color-danger)]">
          <AlertTriangle className="h-3.5 w-3.5" />
          {t('returnNoTime')}
        </p>
      )}

      <ul className="mt-3 flex flex-wrap gap-1.5">
        {people.map((person) => (
          <li
            key={person.id}
            draggable
            onDragStart={(e) => {
              e.dataTransfer.setData(DRAG_TYPE, person.id)
              e.dataTransfer.effectAllowed = 'move'
            }}
            className="flex cursor-grab items-center gap-1 rounded-full border border-[var(--color-border)] bg-[var(--color-bg-subtle)] py-0.5 pl-2.5 pr-1 text-xs text-[var(--color-text-primary)] active:cursor-grabbing"
          >
            <GripVertical className="h-3 w-3 shrink-0 text-[var(--color-text-secondary)]" />
            <span>{person.name}</span>
            {targets.length > 0 && (
              <label className="relative">
                <span className="sr-only">{t('movePerson', { name: person.name })}</span>
                <select
                  value=""
                  onChange={(e) => {
                    if (e.target.value) onMoveParticipant(person.id, e.target.value)
                    e.target.value = ''
                  }}
                  title={t('moveToOther')}
                  className="cursor-pointer appearance-none rounded p-0.5 pr-3 text-[var(--color-text-secondary)] hover:bg-white"
                >
                  <option value="" />
                  <optgroup label={t('moveTo')}>
                    {/* `target`, not `t`: the translator is already called t
                        in this scope, and the shorter name shadowed it. */}
                    {targets.map((target) => (
                      <option key={target.index} value={target.index}>
                        {groupLabel(target.group, t)}
                      </option>
                    ))}
                    <option value={NEW_GROUP}>{t('newGroup')}</option>
                  </optgroup>
                </select>
                <ArrowRightLeft className="pointer-events-none absolute right-0.5 top-1/2 h-3 w-3 -translate-y-1/2" />
              </label>
            )}
            <button
              type="button"
              title={`Retirer ${person.name} du plan`}
              onClick={() => onRemoveParticipant(person.id)}
              className="rounded-full p-0.5 text-[var(--color-text-secondary)] hover:bg-white hover:text-[var(--color-danger)]"
            >
              <X className="h-3 w-3" />
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}

/** A helper, not a component — so the translator is passed in rather than
 *  read from a hook it is not allowed to call. */
function groupLabel(group: TransferGroup, t: ReturnType<typeof useTranslations>): string {
  const time = group.pickup_time ? toLocalInput(group.pickup_time).slice(11, 16) : t('noTime')
  const vehicle = group.vehicle?.name || t('noVehicle')
  return `${time} · ${vehicle} (${group.participant_ids.length} pax)`
}

function Pill({ children, tone }: { children: React.ReactNode; tone?: 'warn' }) {
  const t = useTranslations('transferPlanner')
  return (
    <span
      className={cn(
        'rounded-full px-2.5 py-1',
        tone === 'warn'
          ? 'bg-[var(--color-danger)]/10 text-[var(--color-danger)]'
          : 'bg-[var(--color-bg-subtle)] text-[var(--color-text-secondary)]'
      )}
    >
      {children}
    </span>
  )
}

function IconButton({
  children, title, onClick,
}: { children: React.ReactNode; title: string; onClick: () => void }) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      className="rounded p-1.5 text-[var(--color-text-secondary)] transition-colors hover:bg-[var(--color-bg-subtle)] hover:text-[var(--color-text-primary)]"
    >
      {children}
    </button>
  )
}

/** The API speaks ISO; <input type="datetime-local"> speaks "YYYY-MM-DDTHH:mm"
 *  with no zone. Truncating rather than converting keeps the wall-clock time
 *  the planner computed — a pickup at 15:00 must not become 17:00 because the
 *  browser sits in another timezone. */
function toLocalInput(iso: string | null): string {
  return iso ? iso.slice(0, 16) : ''
}

function fromLocalInput(value: string): string | null {
  return value ? `${value}:00` : null
}
