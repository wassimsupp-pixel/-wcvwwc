'use client'

import React, { useEffect, useState } from 'react'
import { useTranslations } from 'next-intl'
import { Loader2, Plus, Trash2, EyeOff, Share2, Settings2, X } from 'lucide-react'
import { api, errorMessage, type NotePreset, type ParticipantNote } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * Operational remarks on a participant (feedback §8).
 *
 * "Super VIP", "cadeau dans la chambre", "appeler personnellement". The team
 * writes these constantly and had one free-text field for them.
 *
 * Two things this screen has to make obvious, because getting either wrong is
 * expensive:
 *
 *   - a note is INTERNAL unless somebody says otherwise, note by note;
 *   - sharing is only possible at all for a category that has a supplier, and
 *     the note then reaches that supplier and nobody else. A flight remark
 *     cannot end up on a rooming list.
 *
 * So the sharing control disappears entirely for a general note rather than
 * being shown and quietly ignored — a toggle that looks active and does
 * nothing is worse than no toggle.
 */
/** Built per render, not at module scope: a constant cannot read the locale. */
function supplierLabels(t: ReturnType<typeof useTranslations>): Record<string, string> {
  return {
    hotel: t('supplierHotel'),
    transfer: t('supplierTransfer'),
    flight: t('supplierFlight'),
    activity: t('supplierActivity'),
  }
}

export function ParticipantNotes({
  eventId, participantId,
}: { eventId: string; participantId: string }) {
  const t = useTranslations('notes')
  const tAct = useTranslations('actions')
  const [notes, setNotes] = useState<ParticipantNote[] | null>(null)
  const [categories, setCategories] = useState<
    { key: string; label: string; exportable_to: string | null }[]
  >([])
  const [available, setAvailable] = useState(true)
  const [body, setBody] = useState('')
  const [category, setCategory] = useState('general')
  const [share, setShare] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  // Named notes (presets). `presetId` is the one currently armed: applying it
  // writes a normal note and stamps where it came from, which is what colours
  // this person's row in the master list.
  const [presets, setPresets] = useState<NotePreset[]>([])
  const [presetId, setPresetId] = useState<string | null>(null)
  const [managing, setManaging] = useState(false)

  const load = React.useCallback(async () => {
    try {
      const res = await api.notes.list(eventId, participantId)
      setNotes(res.notes)
      setCategories(res.categories)
      setPresets(res.presets || [])
      setAvailable(res.available)
    } catch {
      setNotes([])
      setAvailable(false)
    }
  }, [eventId, participantId])

  useEffect(() => { load() }, [load])

  const selected = categories.find((c) => c.key === category)
  const canShare = Boolean(selected?.exportable_to)

  async function add() {
    if (!body.trim()) return
    setBusy(true)
    setError(null)
    try {
      await api.notes.add(eventId, participantId, {
        body, category, include_in_export: canShare && share, preset_id: presetId,
      })
      setBody('')
      setShare(false)
      setPresetId(null)
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errSave'))
    } finally {
      setBusy(false)
    }
  }

  /** Arm a preset: fill the box with its wording and remember which one it
   *  was. Still one explicit "Ajouter" click after that — a note that posts
   *  itself the moment somebody brushes a chip is a note nobody meant. */
  function pick(preset: NotePreset) {
    setPresetId(preset.id)
    setBody(preset.body)
    setCategory(preset.category)
    setShare(false)
  }

  async function remove(noteId: string) {
    try {
      await api.notes.remove(eventId, participantId, noteId)
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Suppression impossible.')
    }
  }

  if (!available) {
    return (
      <p className="text-sm text-[var(--color-text-secondary)]">
        {t('needsMigration')}
      </p>
    )
  }

  return (
    <div>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h2 className="text-base font-semibold text-[var(--color-text-primary)]">{t('title')}</h2>
          <p className="mt-1 text-sm text-[var(--color-text-secondary)]">
            {t('subtitle')}
          </p>
        </div>
        <button
          type="button"
          onClick={() => setManaging((v) => !v)}
          className="flex items-center gap-1.5 rounded-lg border border-[var(--color-border)] px-3 py-1.5 text-sm text-[var(--color-text-primary)] hover:bg-[var(--color-bg-subtle)]"
        >
          <Settings2 className="h-4 w-4" />
          {t('presets')}
        </button>
      </div>

      {managing && (
        <PresetManager
          eventId={eventId}
          presets={presets}
          categories={categories}
          onSaved={setPresets}
          onClose={() => setManaging(false)}
        />
      )}

      {presets.length > 0 && (
        <div className="mt-4 flex flex-wrap items-center gap-1.5">
          {presets.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => pick(p)}
              title={p.body}
              className={cn(
                'flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium transition-colors',
                presetId === p.id
                  ? 'border-transparent text-white'
                  : 'border-[var(--color-border)] text-[var(--color-text-primary)] hover:bg-[var(--color-bg-subtle)]'
              )}
              style={presetId === p.id ? { backgroundColor: p.color } : undefined}
            >
              <span
                className="h-2.5 w-2.5 shrink-0 rounded-full"
                style={{ backgroundColor: presetId === p.id ? '#FFFFFF' : p.color }}
              />
              {p.name}
            </button>
          ))}
          {presetId && (
            <button
              type="button"
              onClick={() => { setPresetId(null); setBody('') }}
              className="flex items-center gap-1 rounded-full px-2 py-1 text-xs text-[var(--color-text-secondary)] hover:text-[var(--color-danger)]"
            >
              <X className="h-3 w-3" /> {t('remove')}
            </button>
          )}
        </div>
      )}

      <div className="mt-4 rounded-lg border border-[var(--color-border)] p-3">
        <textarea
          value={body}
          onChange={(e) => { setBody(e.target.value); setPresetId(null) }}
          rows={2}
          placeholder={t('bodyPlaceholder')}
          className="w-full rounded-lg border border-[var(--color-border)] px-3 py-2 text-sm outline-none focus:border-[var(--color-accent)]"
        />
        <div className="mt-2 flex flex-wrap items-center gap-3">
          <select
            value={category}
            onChange={(e) => { setCategory(e.target.value); setShare(false) }}
            className="rounded-lg border border-[var(--color-border)] bg-white px-3 py-1.5 text-sm"
          >
            {categories.map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}
          </select>

          {canShare ? (
            <label className="flex items-center gap-1.5 text-xs text-[var(--color-text-secondary)]">
              <input
                type="checkbox"
                checked={share}
                onChange={(e) => setShare(e.target.checked)}
                className="h-4 w-4 rounded border-[var(--color-border)]"
              />
              {t('shareWith', { who: supplierLabels(t)[selected!.exportable_to!] ?? t('thisSupplier') })}
            </label>
          ) : (
            <span className="flex items-center gap-1.5 text-xs text-[var(--color-text-secondary)]">
              <EyeOff className="h-3.5 w-3.5" />
              {t('generalStaysInternal')}
            </span>
          )}

          <button
            onClick={add}
            disabled={busy || !body.trim()}
            className="ml-auto flex items-center gap-1.5 rounded-lg bg-[var(--color-accent)] px-3 py-1.5 text-sm font-semibold text-white disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            {t('add')}
          </button>
        </div>
      </div>

      {error && <p className="mt-3 text-xs text-[var(--color-danger)]">{error}</p>}

      <div className="mt-4 space-y-2">
        {notes === null ? (
          <p className="flex items-center gap-2 text-sm text-[var(--color-text-secondary)]">
            <Loader2 className="h-4 w-4 animate-spin" /> {tAct('loading')}
          </p>
        ) : notes.length === 0 ? (
          <p className="text-sm text-[var(--color-text-secondary)]">{t('empty')}</p>
        ) : (
          notes.map((note) => {
            const cat = categories.find((c) => c.key === note.category)
            const fromPreset = presets.find((p) => p.id === note.preset_id)
            return (
              <div
                key={note.id}
                className="flex items-start gap-3 rounded-lg border border-[var(--color-border)] px-3 py-2.5"
                style={fromPreset ? { borderLeft: `4px solid ${fromPreset.color}` } : undefined}
              >
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-[var(--color-text-primary)]">{note.body}</p>
                  <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-[var(--color-text-secondary)]">
                    {fromPreset && (
                      <span
                        className="rounded-full px-2 py-0.5 font-medium text-white"
                        style={{ backgroundColor: fromPreset.color }}
                      >
                        {fromPreset.name}
                      </span>
                    )}
                    <span className="rounded-full bg-[var(--color-bg-subtle)] px-2 py-0.5">
                      {cat?.label ?? note.category}
                    </span>
                    <span
                      className={cn(
                        'flex items-center gap-1',
                        note.include_in_export && 'text-[var(--color-accent)]'
                      )}
                    >
                      {note.include_in_export ? (
                        <>
                          <Share2 className="h-3 w-3" />
                          {t('sharedWith', { who: supplierLabels(t)[cat?.exportable_to ?? ''] ?? t('aSupplier') })}
                        </>
                      ) : (
                        <><EyeOff className="h-3 w-3" /> {t('internal')}</>
                      )}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => remove(note.id)}
                  className="rounded p-1.5 text-[var(--color-text-secondary)] hover:text-[var(--color-danger)]"
                  title={t('delete')}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            )
          })
        )}
      </div>
    </div>
  )
}

/** The palette offered when creating a preset. Deliberately a short, fixed
 *  list rather than a colour picker: eight distinguishable colours is what a
 *  master list can actually be read by — thirty shades of blue is not a code,
 *  it is decoration. */
const PALETTE = [
  '#DC2626', // red
  '#EA580C', // orange
  '#CA8A04', // gold
  '#16A34A', // green
  '#0891B2', // teal
  '#2563EB', // blue
  '#7C3AED', // violet
  '#64748B', // slate
]

function PresetManager({
  eventId, presets, categories, onSaved, onClose,
}: {
  eventId: string
  presets: NotePreset[]
  categories: { key: string; label: string; exportable_to: string | null }[]
  onSaved: (presets: NotePreset[]) => void
  onClose: () => void
}) {
  const t = useTranslations('notes')
  const [name, setName] = useState('')
  const [color, setColor] = useState(PALETTE[0])
  const [category, setCategory] = useState('general')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function persist(next: { id?: string; name: string; body?: string; color?: string; category?: string }[]) {
    setSaving(true)
    setError(null)
    try {
      const res = await api.notes.setPresets(eventId, next)
      onSaved(res.presets)
    } catch (err) {
      setError(errorMessage(err, t('errPresetSave')))
    } finally {
      setSaving(false)
    }
  }

  function addPreset() {
    const label = name.trim()
    if (!label) return
    setName('')
    persist([
      ...presets.map((p) => ({ id: p.id, name: p.name, body: p.body, color: p.color, category: p.category })),
      { name: label, body: label, color, category },
    ])
  }

  function removePreset(id: string) {
    persist(
      presets
        .filter((p) => p.id !== id)
        .map((p) => ({ id: p.id, name: p.name, body: p.body, color: p.color, category: p.category }))
    )
  }

  return (
    <div className="mt-3 rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-3">
      <div className="flex items-center justify-between gap-2">
        <p className="text-sm font-semibold text-[var(--color-text-primary)]">{t('presetsTitle')}</p>
        <button
          type="button"
          onClick={onClose}
          className="rounded p-1 text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]"
          title={t('close')}
        >
          <X className="h-4 w-4" />
        </button>
      </div>
      <p className="mt-1 text-xs text-[var(--color-text-secondary)]">
        {t('presetsHint')}
      </p>

      {presets.length > 0 && (
        <ul className="mt-3 space-y-1.5">
          {presets.map((p) => (
            <li key={p.id} className="flex items-center gap-2 rounded border border-[var(--color-border)] bg-white px-2 py-1.5">
              <span className="h-3 w-3 shrink-0 rounded-full" style={{ backgroundColor: p.color }} />
              <span className="text-sm text-[var(--color-text-primary)]">{p.name}</span>
              <button
                type="button"
                onClick={() => removePreset(p.id)}
                disabled={saving}
                title={t('delete')}
                className="ml-auto rounded p-1 text-[var(--color-text-secondary)] hover:text-[var(--color-danger)] disabled:opacity-40"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </li>
          ))}
        </ul>
      )}

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addPreset() } }}
          placeholder={t('presetNamePlaceholder')}
          maxLength={60}
          className="w-48 rounded-lg border border-[var(--color-border)] px-3 py-1.5 text-sm outline-none focus:border-[var(--color-accent)]"
        />
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="rounded-lg border border-[var(--color-border)] bg-white px-2 py-1.5 text-sm"
        >
          {categories.map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}
        </select>
        <div className="flex items-center gap-1">
          {PALETTE.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setColor(c)}
              title={c}
              aria-label={`Couleur ${c}`}
              className={cn(
                'h-6 w-6 rounded-full border-2 transition-transform',
                color === c ? 'scale-110 border-[var(--color-text-primary)]' : 'border-transparent'
              )}
              style={{ backgroundColor: c }}
            />
          ))}
        </div>
        <button
          type="button"
          onClick={addPreset}
          disabled={saving || !name.trim()}
          className="flex items-center gap-1.5 rounded-lg bg-[var(--color-accent)] px-3 py-1.5 text-sm font-semibold text-white disabled:opacity-50"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          {t('create')}
        </button>
      </div>

      {error && <p className="mt-2 text-xs text-[var(--color-danger)]">{error}</p>}
    </div>
  )
}
