'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useTranslations } from 'next-intl'
import {
  AlertTriangle,
  CheckCircle2,
  Loader2,
  Mail,
  Search,
  Send,
  User,
  X,
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { api, type ParticipantLookupItem } from '@/lib/api'
import { cn } from '@/lib/utils'

interface IndividualEmailCardProps {
  eventId: string
  /** Refresh the tracking table after a send — the row lands there too. */
  onSent?: () => void
  /** False when no mailbox is connected: the message is still written and
   *  stored, it just cannot leave, and the button says so. */
  canDeliver: boolean
}

/**
 * Write to one participant.
 *
 * The same engine as the campaign to everybody, pointed at a single person:
 * the placeholders resolve from that participant's own consolidated fiche, the
 * message is stored in the tracking table, and it leaves through the connected
 * mailbox. What differs is the shape of the task — pick a name, write, send —
 * so it gets its own card instead of a filter buried in the campaign form.
 */
export function IndividualEmailCard({ eventId, onSent, canDeliver }: IndividualEmailCardProps) {
  const t = useTranslations('individualEmail')
  const [people, setPeople] = useState<ParticipantLookupItem[]>([])
  const [query, setQuery] = useState('')
  const [open, setOpen] = useState(false)
  const [picked, setPicked] = useState<ParticipantLookupItem | null>(null)

  const [subject, setSubject] = useState('')
  const [body, setBody] = useState(t('draftBody'))

  const [busy, setBusy] = useState<'preview' | 'send' | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [preview, setPreview] = useState<{ to: string; subject: string; body: string } | null>(null)
  const [noEmail, setNoEmail] = useState(false)
  const [done, setDone] = useState<string | null>(null)

  const boxRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    api.participants.lookup(eventId).then(setPeople).catch(() => setPeople([]))
  }, [eventId])

  // Click-away closes the suggestion list. Without it the list stays open over
  // the fields below it and swallows the first click on the subject line.
  useEffect(() => {
    const onDocClick = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
  }, [])

  const fullName = (p: ParticipantLookupItem) => `${p.first_name ?? ''} ${p.last_name ?? ''}`.trim()

  const matches = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return people.slice(0, 8)
    return people.filter((p) => fullName(p).toLowerCase().includes(q)).slice(0, 8)
  }, [people, query])

  const reset = () => {
    setPreview(null)
    setNoEmail(false)
    setError(null)
    setDone(null)
  }

  const choose = (p: ParticipantLookupItem) => {
    setPicked(p)
    setQuery('')
    setOpen(false)
    reset()
  }

  const payload = () => ({
    mode: 'template',
    subject,
    body,
    instructions: '',
    participant_ids: picked ? [picked.id] : [],
  })

  const handlePreview = async () => {
    if (!picked) return
    setBusy('preview')
    reset()
    try {
      const res = await api.campaigns.preview(eventId, payload())
      // recipient_count is 0 when the fiche carries no address: the message can
      // be written but has nowhere to go, and saying so now beats a silent
      // "0 envoyé" after the fact.
      setNoEmail(res.recipient_count === 0)
      setPreview(res.samples?.[0] ?? null)
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errPreview'))
    } finally {
      setBusy(null)
    }
  }

  const handleSend = async () => {
    if (!picked) return
    const who = fullName(picked)
    if (!window.confirm(t('confirmSend', { who }))) return
    setBusy('send')
    reset()
    try {
      const res = await api.campaigns.send(eventId, { ...payload(), send: true })
      if (res.skipped_no_email) {
        setNoEmail(true)
        setError(t('errNoEmailNamed', { name: who }))
      } else if (res.errors) {
        setError(t('errSendKeptDraft'))
      } else if (res.delivered && res.sent) {
        setDone(t('sentTo', { name: who }))
      } else {
        setDone(t('storedFor', { name: who }))
      }
      onSent?.()
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errSend'))
    } finally {
      setBusy(null)
    }
  }

  const ready = Boolean(picked) && subject.trim().length > 0 && body.trim().length > 0

  return (
    <Card className="p-5 border-[var(--color-border)] shadow-sm bg-white space-y-4">
      <div className="flex items-center gap-2 border-b pb-3">
        <Mail className="h-4.5 w-4.5 text-[var(--color-accent)]" />
        <h3 className="text-sm font-bold text-[var(--color-text-primary)]">{t('title')}</h3>
        <span className="text-xs text-[var(--color-text-secondary)]">{t('subtitle')}</span>
      </div>

      {/* Who */}
      <div ref={boxRef} className="relative">
        {picked ? (
          <div className="flex items-center justify-between gap-2 rounded-lg border border-[var(--color-accent)]/30 bg-[var(--color-accent-light)] px-3 py-2">
            <span className="flex items-center gap-2 text-sm font-semibold text-[var(--color-text-primary)]">
              <User className="h-4 w-4 text-[var(--color-accent)]" />
              {fullName(picked)}
            </span>
            <button
              type="button"
              onClick={() => { setPicked(null); reset() }}
              aria-label={t('changePerson')}
              className="rounded-full p-1 text-[var(--color-text-secondary)] hover:bg-white/70 hover:text-[var(--color-text-primary)]"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <>
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--color-text-secondary)]" />
              <input
                type="text"
                value={query}
                onChange={(e) => { setQuery(e.target.value); setOpen(true) }}
                onFocus={() => setOpen(true)}
                placeholder={t('searchPlaceholder')}
                className="w-full rounded-md border border-[var(--color-border)] bg-white py-2 pl-9 pr-3 text-sm focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
              />
            </div>
            {open && (
              <ul className="absolute z-20 mt-1 max-h-56 w-full overflow-y-auto rounded-md border border-[var(--color-border)] bg-white py-1 shadow-lg">
                {matches.length === 0 ? (
                  <li className="px-3 py-2 text-xs text-[var(--color-text-secondary)]">{t('noMatch')}</li>
                ) : (
                  matches.map((p) => (
                    <li key={p.id}>
                      <button
                        type="button"
                        onClick={() => choose(p)}
                        className="w-full px-3 py-2 text-left text-sm text-[var(--color-text-primary)] hover:bg-[var(--color-accent-light)]"
                      >
                        {fullName(p)}
                      </button>
                    </li>
                  ))
                )}
              </ul>
            )}
          </>
        )}
      </div>

      {/* What */}
      <input
        type="text"
        value={subject}
        onChange={(e) => setSubject(e.target.value)}
        placeholder={t('subject')}
        className="w-full rounded-md border border-[var(--color-border)] bg-white px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
      />
      <textarea
        value={body}
        onChange={(e) => setBody(e.target.value)}
        rows={6}
        placeholder={t('bodyPlaceholder')}
        className="w-full whitespace-pre-wrap rounded-md border border-[var(--color-border)] bg-white px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
      />
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="text-[10px] font-semibold text-[var(--color-text-secondary)]">{t('variables')}</span>
        {['first_name', 'last_name', 'full_name', 'company', 'event_name'].map((ph) => (
          <button
            key={ph}
            type="button"
            onClick={() => setBody((b) => `${b}{${ph}}`)}
            className="rounded-full border border-[var(--color-border)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-accent)] hover:bg-[var(--color-accent-light)]"
          >
            {`{${ph}}`}
          </button>
        ))}
      </div>

      {error && (
        <div className="flex items-center gap-2 rounded-lg bg-[var(--color-danger-light)] px-3 py-2 text-xs text-[var(--color-danger)]">
          <AlertTriangle className="h-4 w-4 shrink-0" /><span>{error}</span>
        </div>
      )}
      {noEmail && !error && (
        <div className="flex items-center gap-2 rounded-lg bg-[var(--color-warning-light)] px-3 py-2 text-xs text-[var(--color-text-primary)]">
          <AlertTriangle className="h-4 w-4 shrink-0 text-[var(--color-warning)]" />
          <span>{t('noEmail')}</span>
        </div>
      )}
      {done && (
        <div className="flex items-center gap-2 rounded-lg bg-[var(--color-success-light)] px-3 py-2 text-xs font-medium text-[var(--color-success)]">
          <CheckCircle2 className="h-4 w-4 shrink-0" /><span>{done}</span>
        </div>
      )}

      {/* Send */}
      <div className="flex flex-wrap items-center gap-2">
        <Button
          variant="outline"
          onClick={handlePreview}
          disabled={!ready || busy !== null}
          className="flex items-center gap-2"
        >
          {busy === 'preview' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          {t('preview')}
        </Button>
        <Button
          onClick={handleSend}
          disabled={!ready || busy !== null}
          className={cn('flex items-center gap-2 bg-[var(--color-accent)] text-white')}
        >
          {busy === 'send' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          {picked ? t('sendToName', { name: picked.first_name || fullName(picked) }) : t('send')}
        </Button>
        {!canDeliver && (
          <span className="text-xs text-[var(--color-text-secondary)]">
            {t('noMailbox')}
          </span>
        )}
      </div>

      {preview && (
        <div className="space-y-1 rounded-lg border border-slate-100 bg-slate-50 p-3">
          <div className="text-[11px] font-semibold text-[var(--color-text-primary)]">{t('to')} {preview.to}</div>
          <div className="text-[11px] text-[var(--color-accent)]">{preview.subject}</div>
          <div className="whitespace-pre-wrap text-xs text-[var(--color-text-secondary)]">{preview.body}</div>
        </div>
      )}
    </Card>
  )
}
