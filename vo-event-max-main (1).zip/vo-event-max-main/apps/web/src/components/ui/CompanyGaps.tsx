'use client'

import { useState } from 'react'
import { useTranslations } from 'next-intl'
import { Building2, ChevronDown } from 'lucide-react'
import type { DashboardData } from '@/lib/api'

const PREVIEW = 6

/**
 * "Which company still hasn't sent its list" is a daily question on a
 * corporate event, and `company` sat in the master list unaggregated. Sorted
 * by how much each one still owes, not alphabetically — the top row is the
 * call to make this morning.
 */
export function CompanyGaps({ companies }: { companies: DashboardData['companies'] }) {
  const t = useTranslations('companyGaps')
  const [expanded, setExpanded] = useState(false)
  if (companies.length === 0) return null

  const withGaps = companies.filter(
    (c) => c.without_flight + c.without_hotel + c.without_transfer + c.incomplete > 0
  )
  const shown = expanded ? companies : companies.slice(0, PREVIEW)

  return (
    <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white p-5 shadow-[var(--shadow-card)]">
      <div className="mb-4 flex items-center gap-2">
        <Building2 className="h-4 w-4 text-[var(--color-text-primary)]" />
        <h3 className="text-sm font-semibold text-[var(--color-text-primary)]">{t('title')}</h3>
        <span className="text-xs text-[var(--color-text-secondary)]">
          {withGaps.length === 0
            ? t('nothingPending')
            : t('companiesWithGaps', { count: withGaps.length })}
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-[var(--color-border)] text-xs font-medium text-[var(--color-text-secondary)]">
              <th className="pb-2 pr-3">{t('thCompany')}</th>
              <th className="pb-2 px-2 text-center">{t('thParticipants')}</th>
              <th className="pb-2 px-2 text-center">{t('thNoFlight')}</th>
              <th className="pb-2 px-2 text-center">{t('thNoHotel')}</th>
              <th className="pb-2 px-2 text-center">{t('thNoTransfer')}</th>
              <th className="pb-2 pl-2 text-center">{t('thIncomplete')}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--color-border)]">
            {shown.map((c) => (
              <tr key={c.company}>
                <td className="py-2 pr-3 font-medium text-[var(--color-text-primary)]">{c.company}</td>
                <td className="px-2 py-2 text-center text-[var(--color-text-secondary)]">{c.participants}</td>
                {([c.without_flight, c.without_hotel, c.without_transfer, c.incomplete]).map((n, i) => (
                  <td key={i} className="px-2 py-2 text-center">
                    <span
                      className={
                        n === 0
                          ? 'text-[var(--color-text-secondary)]'
                          : 'font-semibold text-[var(--color-text-primary)]'
                      }
                    >
                      {n}
                    </span>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {!expanded && companies.length > PREVIEW && (
        <button
          onClick={() => setExpanded(true)}
          className="mt-3 flex items-center gap-1 text-xs font-medium text-[var(--color-text-primary)] hover:underline"
        >
          <ChevronDown className="h-3 w-3" />
          {t('showMore', { count: companies.length - PREVIEW })}
        </button>
      )}
    </div>
  )
}
