'use client'

import React, { useState } from 'react'
import { useTranslations } from 'next-intl'
import { useRouter } from 'next/navigation'
import { Wallet, ChevronDown, ChevronRight, Search } from 'lucide-react'
import type { CohortRow } from '@/components/ui/ConcernedParticipants'
import { cn } from '@/lib/utils'

/**
 * Who is on their own nights, shown wherever those nights cost something.
 *
 * The fact is derived from the participant's own flights: somebody landing
 * three days before the programme starts, or flying home five days after it
 * ends, is sleeping somewhere on nights the client did not book. On the live
 * event that is 36 people and 141 nights — a hotel invoice nobody has agreed
 * to yet.
 *
 * It lives on three pages on purpose, because the question is asked in three
 * different rooms: on Vols by whoever reads the flight that causes it, on
 * Hébergements by whoever counts the nights, and on Participants by whoever
 * has to tell them. One component so the three can never disagree.
 *
 * Deliberately NOT styled as an error. Nothing is broken and nobody has made a
 * mistake — an extension at one's own expense is a normal, expected thing. It
 * is a bill to attribute, and the tone says so.
 */
export function OwnExpenseAlert({
  rows,
  locale,
  eventId,
  context,
}: {
  rows: CohortRow[]
  locale: string
  eventId: string
  /** Which page is asking — only changes the sentence under the count. */
  context: 'flights' | 'hotels' | 'participants'
}) {
  const t = useTranslations('ownExpense')
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')

  const concerned = rows.filter((r) => r.own_expense)
  if (concerned.length === 0) return null

  const nights = concerned.reduce((n, r) => n + (r.nights_outside_programme ?? 0), 0)
  const q = query.trim().toLowerCase()
  const shown = (q
    ? concerned.filter((r) =>
        `${r.first_name ?? ''} ${r.last_name ?? ''}`.toLowerCase().includes(q) ||
        (r.company ?? '').toLowerCase().includes(q))
    : concerned
  )
    // Longest stay first: the biggest bill is the one worth a phone call.
    .slice()
    .sort((a, b) => (b.nights_outside_programme ?? 0) - (a.nights_outside_programme ?? 0))

  return (
    <div className="mb-6 rounded-[var(--radius-card)] border border-[var(--color-accent)]/30 bg-[var(--color-accent)]/5 p-4">
      <p className="flex flex-wrap items-center gap-2 text-sm font-semibold text-[var(--color-text-primary)]">
        <Wallet className="h-4 w-4 shrink-0 text-[var(--color-accent)]" />
        {t('title', { count: concerned.length, nights })}
      </p>
      <p className="mt-1 text-xs text-[var(--color-text-secondary)]">
        {t(`hint.${context}` as 'hint.flights')}
      </p>

      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="mt-2 flex items-center gap-1.5 text-xs font-semibold text-[var(--color-text-primary)] hover:underline"
      >
        {open ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
        {open ? t('hide') : t('show', { count: concerned.length })}
      </button>

      {open && (
        <div className="mt-2 overflow-hidden rounded-lg border border-[var(--color-border)] bg-white">
          {concerned.length > 8 && (
            <div className="flex items-center gap-2 border-b border-[var(--color-border)] px-3 py-2">
              <Search className="h-3.5 w-3.5 shrink-0 text-[var(--color-text-secondary)]" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t('searchPlaceholder')}
                className="w-full bg-transparent text-xs outline-none"
              />
            </div>
          )}
          <ul className="divide-y divide-[var(--color-border)]">
            {shown.map((r) => {
              const bits: string[] = []
              if (r.arrives_early_days) bits.push(t('early', { count: r.arrives_early_days }))
              if (r.stays_late_days) bits.push(t('late', { count: r.stays_late_days }))
              return (
                <li key={r.id}>
                  <button
                    type="button"
                    onClick={() => router.push(`/${locale}/events/${eventId}/participants/${r.id}`)}
                    className="flex w-full flex-wrap items-center gap-x-3 gap-y-1 px-3 py-2 text-left text-xs hover:bg-[var(--color-bg-subtle)]"
                  >
                    <span className="font-medium text-[var(--color-text-primary)]">
                      {`${r.first_name ?? ''} ${r.last_name ?? ''}`.trim() || r.id}
                    </span>
                    <span className={cn(
                      'rounded-full bg-[var(--color-accent)]/10 px-2 py-0.5 font-semibold text-[var(--color-accent)]'
                    )}>
                      {t('nights', { count: r.nights_outside_programme ?? 0 })}
                    </span>
                    <span className="text-[var(--color-text-secondary)]">{bits.join(' · ')}</span>
                  </button>
                </li>
              )
            })}
            {shown.length === 0 && (
              <li className="px-3 py-6 text-center text-xs text-[var(--color-text-secondary)]">
                {t('noMatch')}
              </li>
            )}
          </ul>
        </div>
      )}
    </div>
  )
}
