'use client'

import { useState } from 'react'
import { useTranslations } from 'next-intl'
import { CalendarClock, Inbox, TrendingDown, TrendingUp, Minus } from 'lucide-react'
import { api, type DashboardData } from '@/lib/api'
import { formatDateOnly, localeTag } from '@/lib/dates'

/**
 * Set the event's dates and city, from the card that needs them.
 *
 * The card used to end on "Ajoutez une date de début pour situer la couverture
 * par rapport à l'échéance" — an instruction nobody could follow: the API has
 * always accepted these fields, the creation dialog only ever asked for a name,
 * and no screen could edit them afterwards. So every event had start_date NULL,
 * the countdown never appeared, and the coverage thresholds (95 % expected at
 * D-7, 80 % at D-30) had nothing to read.
 */
function EventDatesForm({ eventId, event, onSaved }: {
  eventId: string
  event: DashboardData['event']
  onSaved: () => void
}) {
  const t = useTranslations('eventPulse')
  const tAct = useTranslations('actions')
  const [open, setOpen] = useState(false)
  const [start, setStart] = useState(event.start_date ?? '')
  const [end, setEnd] = useState(event.end_date ?? '')
  const [city, setCity] = useState(event.location_city ?? '')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="mt-1 text-xs font-semibold text-[var(--color-text-primary)] underline underline-offset-2"
      >
        {event.start_date ? t('editDates') : t('setDates')}
      </button>
    )
  }

  const save = async () => {
    setSaving(true)
    setError(null)
    try {
      // exclude_none on the API side means an empty string would be stored as
      // one; send only what was actually filled in.
      const patch: Record<string, string> = {}
      if (start) patch.start_date = start
      if (end) patch.end_date = end
      if (city.trim()) patch.location_city = city.trim()
      if (Object.keys(patch).length === 0) {
        setError(t('errNeedOneDate'))
        return
      }
      if (patch.start_date && patch.end_date && patch.end_date < patch.start_date) {
        setError(t('errEndBeforeStart'))
        return
      }
      await api.events.update(eventId, patch)
      setOpen(false)
      onSaved()
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Enregistrement impossible.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="mt-2 space-y-2">
      <div className="flex flex-wrap gap-2">
        <label className="flex flex-col text-[10px] text-[var(--color-text-secondary)]">
          {t('start')}
          <input type="date" value={start} onChange={(e) => setStart(e.target.value)}
            className="rounded border border-[var(--color-border)] px-1.5 py-1 text-xs text-[var(--color-text-primary)]" />
        </label>
        <label className="flex flex-col text-[10px] text-[var(--color-text-secondary)]">
          {t('end')}
          <input type="date" value={end} onChange={(e) => setEnd(e.target.value)}
            className="rounded border border-[var(--color-border)] px-1.5 py-1 text-xs text-[var(--color-text-primary)]" />
        </label>
        <label className="flex min-w-[7rem] flex-1 flex-col text-[10px] text-[var(--color-text-secondary)]">
          {t('city')}
          <input type="text" value={city} onChange={(e) => setCity(e.target.value)}
            placeholder={t('cityPlaceholder')}
            className="rounded border border-[var(--color-border)] px-1.5 py-1 text-xs text-[var(--color-text-primary)]" />
        </label>
      </div>
      {error && <p className="text-[10px] font-semibold text-[var(--color-danger)]">{error}</p>}
      <div className="flex gap-2">
        <button onClick={save} disabled={saving}
          className="rounded bg-[var(--color-cta)] px-2.5 py-1 text-[11px] font-semibold text-white disabled:opacity-60">
          {saving ? t('saving') : tAct('save')}
        </button>
        <button onClick={() => { setOpen(false); setError(null) }}
          className="rounded border border-[var(--color-border)] px-2.5 py-1 text-[11px] font-semibold text-[var(--color-text-primary)]">
          {tAct('cancel')}
        </button>
      </div>
    </div>
  )
}

/** Human label for the changes between the last two consolidations. */
// Only metrics that are a running TOTAL appear here. The rest of `stats` are
// per-run counters, and subtracting two of those is meaningless: a run that
// created 13 fiches followed by one that created none announced
// "-13 nouveaux participants" on the dashboard's first card.
/** Fewer alerts is progress; fewer participants is not. */
const LOWER_IS_BETTER = new Set(['exceptions_count'])

function Sparkline({ values }: { values: number[] }) {
  if (values.length < 2) return null
  const max = Math.max(...values)
  const min = Math.min(...values)
  const span = max - min || 1
  const w = 120
  const h = 28
  const points = values
    .map((v, i) => {
      const x = (i / (values.length - 1)) * w
      const y = h - ((v - min) / span) * h
      return `${x.toFixed(1)},${y.toFixed(1)}`
    })
    .join(' ')
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="overflow-visible" aria-hidden="true">
      <polyline
        points={points}
        fill="none"
        stroke="var(--color-text-primary)"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

/**
 * The two things the dashboard never said: WHEN the event is, and whether the
 * numbers are moving.
 *
 * A coverage rate means nothing on its own — 64 % of transfers booked is
 * comfortable at D-90 and an emergency at D-5 — and every consolidation has
 * been writing its stats to the database for months without anything ever
 * reading them back.
 */
export function EventPulse({ data, locale, eventId, onEventUpdated }: {
  data: DashboardData
  locale: string
  eventId: string
  onEventUpdated: () => void
}) {
  const t = useTranslations('eventPulse')
  const days = data.event.days_until_start
  const submissions = data.registrations.submissions
  const delta = data.trend.delta
  const series = data.trend.points
    .map((p) => p.stats.participants_total)
    .filter((v): v is number => typeof v === 'number')

  const countdown =
    days === null ? null
      : days > 1 ? t('inDays', { count: days })
      : days === 1 ? t('tomorrow')
      : days === 0 ? t('today')
      : t('daysAgo', { count: Math.abs(days) })

  // What a movement is called. Only these two are worth a line: a fiche
  // count going up is progress, an alert count going down is too.
  const deltaLabel: Record<string, string> = {
    participants_total: t('deltaParticipants'),
    exceptions_count: t('deltaAlerts'),
  }
  const changes = Object.entries(delta?.changes ?? {})
    .filter(([key]) => key in deltaLabel)
    .slice(0, 3)

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {/* When */}
      <div className="flex items-start gap-3 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white p-4 shadow-[var(--shadow-card)]">
        <CalendarClock className="mt-0.5 h-5 w-5 shrink-0 text-[var(--color-text-primary)]" />
        <div className="min-w-0">
          <p className="text-sm font-semibold text-[var(--color-text-primary)]">
            {countdown
              ? days !== null && days >= 0
                ? t('startsIn', { when: countdown })
                : t('happened', { when: countdown })
              : t('noDate')}
          </p>
          <p className="mt-0.5 truncate text-xs text-[var(--color-text-secondary)]">
            {data.event.start_date
              ? [formatDateOnly(data.event.start_date), data.event.location_city].filter(Boolean).join(' · ')
              : t('noStartHint')}
          </p>
          <EventDatesForm eventId={eventId} event={data.event} onSaved={onEventUpdated} />
        </div>
      </div>

      {/* Form responses — the number an organizer refreshes hourly */}
      <div className="flex items-start gap-3 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white p-4 shadow-[var(--shadow-card)]">
        <Inbox className="mt-0.5 h-5 w-5 shrink-0 text-[var(--color-text-primary)]" />
        <div className="min-w-0">
          <p className="text-sm font-semibold text-[var(--color-text-primary)]">
            {submissions === null
              ? t('repliesUnavailable')
              : t('formReplies', { count: submissions })}
          </p>
          <p className="mt-0.5 text-xs text-[var(--color-text-secondary)]">
            {t('repliesSource')}
          </p>
        </div>
      </div>

      {/* Movement */}
      <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white p-4 shadow-[var(--shadow-card)]">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="text-sm font-semibold text-[var(--color-text-primary)]">
              {t('sinceLastRun')}
            </p>
            {changes.length === 0 ? (
              <p className="mt-0.5 text-xs text-[var(--color-text-secondary)]">
                {delta
                  ? t('noMeasuredChange')
                  : t('needTwoRuns')}
              </p>
            ) : (
              <ul className="mt-1 space-y-0.5">
                {changes.map(([key, value]) => {
                  const better = LOWER_IS_BETTER.has(key) ? value < 0 : value > 0
                  const Icon = value === 0 ? Minus : better ? TrendingUp : TrendingDown
                  return (
                    <li key={key} className="flex items-center gap-1.5 text-xs">
                      <Icon
                        className={
                          'h-3 w-3 shrink-0 ' +
                          (better ? 'text-[var(--color-success)]' : 'text-[var(--color-warning)]')
                        }
                      />
                      <span className="text-[var(--color-text-primary)]">
                        {value > 0 ? '+' : ''}{value}
                      </span>
                      <span className="truncate text-[var(--color-text-secondary)]">
                        {deltaLabel[key]}
                      </span>
                    </li>
                  )
                })}
              </ul>
            )}
          </div>
          <Sparkline values={series} />
        </div>
        {delta?.since && (
          <p className="mt-2 text-[11px] text-[var(--color-text-secondary)]">
            {t('comparedTo', { date: formatDateOnly(delta.since, localeTag(locale)) })}
          </p>
        )}
      </div>
    </div>
  )
}
