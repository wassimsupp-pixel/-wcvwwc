'use client'

import React, { useMemo, useState } from 'react'
import { useTranslations } from 'next-intl'
import { formatScheduleTime, localeTag } from '@/lib/dates'
import { Bus, Plane, Pencil, Check, X, Trash2, GripVertical } from 'lucide-react'
import { api, errorMessage, type Transfer, type TransferPatch } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * The booked transfers, grouped by who is actually travelling together (§1).
 *
 * There is no "group" in the database — a transfer is one row per participant.
 * Two rows sharing the same direction, route, time and vehicle ARE a group,
 * purely because they match; this component computes that clustering for
 * display, the same way the dispatch planner does for a proposal that has not
 * been booked yet.
 *
 * Two levels of editing, because they answer two different situations:
 *
 *   - **The group header** edits every member at once — the flight slipped,
 *     the whole van now leaves later.
 *   - **One person's row** edits just them — moving them into a different
 *     time or vehicle is exactly what pulls them out of this cluster and, on
 *     the next refresh, into (or forms) another one. There is no separate
 *     "move" action: retyping their time to match another visible group's
 *     values IS moving them there.
 *
 * Every change is a real PATCH/DELETE against booked data, not a draft — so
 * unlike the proposal planner, there is nothing to "apply" afterwards.
 */

/** Built per render, not at module scope: a constant cannot read the locale. */
function statusLabels(t: ReturnType<typeof useTranslations>): Record<string, string> {
  return {
    scheduled: t('statusScheduled'),
    completed: t('statusCompleted'),
    cancelled: t('statusCancelled'),
  }
}

interface Clump {
  key: string
  direction: string
  pickup_location: string
  dropoff_location: string
  pickup_time: string
  vehicle_type: string
  members: Transfer[]
}

/** The MIME type the drag carries. A custom type rather than `text/plain`:
 *  dropping a selection of text onto a vehicle must not move anybody. */
const DRAG_TYPE = 'application/x-vo-transfer'

/** What makes two rows the same vehicle. Exported because the KPIs above the
 *  list have to count the same thing the list shows: counting distinct pickup
 *  TIMES instead said that a van leaving Brussels and one leaving Charleroi at
 *  14:15 were one vehicle — which was merely optimistic before the airports
 *  were read per person, and plainly wrong now that they are. */
export function clumpKey(t: Transfer): string {
  return [t.transfer_type, t.pickup_location, t.dropoff_location, t.pickup_time, t.vehicle_type || '']
    .join('|')
}

export function TransferGroupedList({
  eventId, transfers, locale, vehicles, onChanged,
}: {
  eventId: string
  transfers: Transfer[]
  locale: string
  vehicles: { name: string; capacity: number }[]
  onChanged: () => void
}) {
  const t = useTranslations('transferList')
  const clumps = useMemo(() => {
    const byKey = new Map<string, Clump>()
    for (const t of transfers) {
      const key = clumpKey(t)
      const existing = byKey.get(key)
      if (existing) {
        existing.members.push(t)
      } else {
        byKey.set(key, {
          key,
          direction: t.transfer_type,
          pickup_location: t.pickup_location,
          dropoff_location: t.dropoff_location,
          pickup_time: t.pickup_time,
          vehicle_type: t.vehicle_type || '',
          members: [t],
        })
      }
    }
    return [...byKey.values()].sort((a, b) => a.pickup_time.localeCompare(b.pickup_time))
  }, [transfers])

  if (transfers.length === 0) {
    return (
      <p className="p-8 text-center text-sm text-[var(--color-text-secondary)]">
        {t('empty')}
      </p>
    )
  }

  return (
    <div className="divide-y divide-[var(--color-border)]">
      {/* Shared once, by id, rather than once per group: an <option> list an
          input references by `list=` must be document-unique. */}
      <datalist id="transfer-vehicle-options">
        {vehicles.map((v) => <option key={v.name} value={v.name} />)}
      </datalist>
      <ApplyToAll eventId={eventId} clumps={clumps} onChanged={onChanged} />
      {/* One list, in time order, arrivals and departures together.
          A dispatcher's day is chronological: what matters at 14:00 is every
          vehicle moving at 14:00, not whether it happens to be pointing at the
          airport or away from it. Splitting the two also made the one gesture
          this list exists for — dragging somebody into another vehicle —
          impossible across the boundary. */}
      <ClumpSection eventId={eventId} clumps={clumps} locale={locale} vehicles={vehicles} onChanged={onChanged} />
    </div>
  )
}

/**
 * One change across every group at once — the van company changed, or the
 * hotel entrance moved, and re-typing it on eleven groups is eleven chances
 * to typo one of them.
 *
 * Pickup TIME is deliberately absent: each group's time comes from its own
 * flight, so a single value applied to all of them would be wrong for all
 * but one. A field left empty is left alone.
 */
function ApplyToAll({ eventId, clumps, onChanged }: { eventId: string; clumps: Clump[]; onChanged: () => void }) {
  const t = useTranslations('transferList')
  const [vehicle, setVehicle] = useState('')
  const [pickup, setPickup] = useState('')
  const [dropoff, setDropoff] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  const total = clumps.reduce((n, c) => n + c.members.length, 0)
  const filled = Boolean(vehicle.trim() || pickup.trim() || dropoff.trim())

  async function applyAll() {
    if (!filled || saving) return
    const patch: TransferPatch = {}
    if (vehicle.trim()) patch.vehicle_type = vehicle.trim()
    if (pickup.trim()) patch.pickup_location = pickup.trim()
    if (dropoff.trim()) patch.dropoff_location = dropoff.trim()

    const labels: Record<string, string> = {
      vehicle_type: t('colVehicle'),
      pickup_location: t('colPickup'),
      dropoff_location: t('colDropoff'),
    }
    const changes = Object.entries(patch)
      .map(([k, v]) => `${labels[k] || k} : ${v}`)
      .join('\n')
    // Since arrivals and departures share one list, a single pickup or
    // dropoff applied to all of them would put the airport on the hotel
    // runs and the hotel on the airport runs — and overwrite the
    // per-person airports the plan just derived. The vehicle has no such
    // problem, which is why it is the field this control was built for.
    const routeTouched = Boolean(patch.pickup_location || patch.dropoff_location)
    const bothWays =
      clumps.some((c) => c.direction === 'arrival') &&
      clumps.some((c) => c.direction === 'departure')
    const warning = routeTouched && bothWays
      ? '\n\n' + t('mixedDirectionsWarning')
      : ''
    if (!window.confirm(
      t('confirmApplyAll', { groups: clumps.length, transfers: total }) + `\n\n${changes}${warning}`
    )) return

    setSaving(true)
    setError('')
    try {
      const all = clumps.flatMap((c) => c.members)
      const res = await api.transfers.bulkUpdate(eventId, all.map((m) => m.id), patch)
      if (res.skipped.length > 0) {
        // Ids the server refused to touch: a tab left open while somebody
        // else deleted a transfer. Reported rather than swallowed, because
        // "12 sur 14" is the difference between a done job and a surprise.
        setError(t('partiallyApplied', { updated: res.updated, missing: res.skipped.length }))
      } else {
        setVehicle(''); setPickup(''); setDropoff('')
      }
      onChanged()
    } catch (err) {
      setError(errorMessage(err, t('errBulk')))
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="bg-[var(--color-bg-subtle)] p-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm font-semibold text-[var(--color-text-primary)]">
          {t('allGroups')}
        </span>
        <input
          value={vehicle}
          onChange={(e) => setVehicle(e.target.value)}
          list="transfer-vehicle-options"
          placeholder={t('vehicle')}
          className="w-32 rounded border border-[var(--color-border)] bg-white px-2 py-1 text-sm"
        />
        <input
          value={pickup}
          onChange={(e) => setPickup(e.target.value)}
          placeholder={t('pickup')}
          className="w-40 rounded border border-[var(--color-border)] bg-white px-2 py-1 text-sm"
        />
        <span className="text-[var(--color-text-secondary)]">→</span>
        <input
          value={dropoff}
          onChange={(e) => setDropoff(e.target.value)}
          placeholder={t('dropoff')}
          className="w-40 rounded border border-[var(--color-border)] bg-white px-2 py-1 text-sm"
        />
        <button
          type="button"
          onClick={applyAll}
          disabled={!filled || saving}
          className="flex items-center gap-1.5 rounded bg-[var(--color-accent)] px-3 py-1.5 text-sm font-semibold text-white disabled:opacity-40"
        >
          <Check className="h-4 w-4" />
          {saving ? t('applying') : t('applyToGroups', { count: clumps.length })}
        </button>
      </div>
      <p className="mt-2 text-xs text-[var(--color-text-secondary)]">
        {t('emptyFieldsHint')}
      </p>
      {error && <p className="mt-2 text-xs text-[var(--color-danger)]">{error}</p>}
    </div>
  )
}

function ClumpSection({
  eventId, clumps, locale, vehicles, onChanged,
}: {
  eventId: string
  clumps: Clump[]
  locale: string
  vehicles: { name: string; capacity: number }[]
  onChanged: () => void
}) {
  const t = useTranslations('transferList')
  if (clumps.length === 0) return null
  return (
    <div className="p-4">
      <p className="mb-3 text-xs text-[var(--color-text-secondary)]">
        {clumps.length} véhicule(s), dans l&apos;ordre des horaires. Faites glisser une personne
        d&apos;un véhicule à l&apos;autre pour la déplacer.
      </p>
      <div className="space-y-3">
        {clumps.map((clump) => (
          <ClumpCard key={clump.key} eventId={eventId} clump={clump} locale={locale} vehicles={vehicles} onChanged={onChanged} />
        ))}
      </div>
    </div>
  )
}

function ClumpCard({
  eventId, clump, locale, vehicles, onChanged,
}: {
  eventId: string
  clump: Clump
  locale: string
  vehicles: { name: string; capacity: number }[]
  onChanged: () => void
}) {
  const t = useTranslations('transferList')
  // Seats, when the vehicle on this group is one the event actually owns. A
  // free-typed name has no capacity, and inventing one would turn "we do not
  // know" into a confident wrong number.
  const capacity = vehicles.find((v) => v.name === clump.vehicle_type)?.capacity ?? null
  const overCapacity = capacity !== null && clump.members.length > capacity
  const [draft, setDraft] = useState({
    pickup_time: toLocalInput(clump.pickup_time),
    vehicle_type: clump.vehicle_type,
    pickup_location: clump.pickup_location,
    dropoff_location: clump.dropoff_location,
  })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [dragOver, setDragOver] = useState(false)

  /** Somebody dropped into this vehicle: they take on everything that defines
   *  it — route, time, vehicle AND direction. Moving a person without moving
   *  their direction is how a passenger ends up listed as arriving in a van
   *  that is going to the airport. */
  async function acceptDrop(event: React.DragEvent) {
    event.preventDefault()
    setDragOver(false)
    const transferId = event.dataTransfer.getData(DRAG_TYPE)
    if (!transferId || clump.members.some((m) => m.id === transferId)) return
    if (capacity !== null && clump.members.length + 1 > capacity) {
      const ok = window.confirm(
        t('overCapacityConfirm', { seats: capacity, taken: clump.members.length + 1 })
      )
      if (!ok) return
    }
    setSaving(true)
    setError('')
    try {
      await api.transfers.update(transferId, {
        transfer_type: clump.direction,
        pickup_time: clump.pickup_time,
        pickup_location: clump.pickup_location,
        dropoff_location: clump.dropoff_location,
        vehicle_type: clump.vehicle_type,
      })
      onChanged()
    } catch (err) {
      setError(errorMessage(err, t('errMove')))
    } finally {
      setSaving(false)
    }
  }

  const dirty =
    fromLocalInput(draft.pickup_time) !== clump.pickup_time ||
    draft.vehicle_type !== clump.vehicle_type ||
    draft.pickup_location !== clump.pickup_location ||
    draft.dropoff_location !== clump.dropoff_location

  async function saveGroup() {
    setSaving(true)
    setError('')
    const patch: TransferPatch = {
      pickup_time: fromLocalInput(draft.pickup_time) || undefined,
      vehicle_type: draft.vehicle_type,
      pickup_location: draft.pickup_location,
      dropoff_location: draft.dropoff_location,
    }
    try {
      await api.transfers.bulkUpdate(eventId, clump.members.map((m) => m.id), patch)
      onChanged()
    } catch (err) {
      setError(errorMessage(err, t('errGroupSave')))
    } finally {
      setSaving(false)
    }
  }

  async function removeGroup() {
    if (!window.confirm(
      t('confirmRemoveGroup', { count: clump.members.length })
    )) return
    setSaving(true)
    setError('')
    try {
      await Promise.all(clump.members.map((m) => api.transfers.remove(m.id)))
      onChanged()
    } catch (err) {
      setError(errorMessage(err, t('errGroupDelete')))
    } finally {
      setSaving(false)
    }
  }

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
      onDragLeave={() => setDragOver(false)}
      onDrop={acceptDrop}
      className={cn(
        'rounded-lg border p-3 transition-colors',
        dragOver
          ? 'border-[var(--color-accent)] bg-[var(--color-accent-light)]'
          : 'border-[var(--color-border)]'
      )}
    >
      <div className="flex flex-wrap items-center gap-2">
        <span
          className={cn(
            'flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium',
            clump.direction === 'arrival'
              ? 'bg-[var(--color-accent-light)] text-[var(--color-accent)]'
              : 'bg-slate-100 text-[var(--color-text-secondary)]'
          )}
        >
          {clump.direction === 'arrival'
            ? <><Plane className="h-3 w-3" /> {t('arrival')}</>
            : <><Bus className="h-3 w-3" /> {t('departure')}</>}
        </span>
        <input
          type="datetime-local"
          value={draft.pickup_time}
          onChange={(e) => setDraft((d) => ({ ...d, pickup_time: e.target.value }))}
          className="rounded border border-[var(--color-border)] px-2 py-1 text-sm"
        />
        <input
          value={draft.vehicle_type}
          onChange={(e) => setDraft((d) => ({ ...d, vehicle_type: e.target.value }))}
          list="transfer-vehicle-options"
          placeholder={t('vehicle')}
          className="w-32 rounded border border-[var(--color-border)] px-2 py-1 text-sm"
        />
        <input
          value={draft.pickup_location}
          onChange={(e) => setDraft((d) => ({ ...d, pickup_location: e.target.value }))}
          placeholder={t('pickup')}
          className="w-40 rounded border border-[var(--color-border)] px-2 py-1 text-sm"
        />
        <span className="text-[var(--color-text-secondary)]">→</span>
        <input
          value={draft.dropoff_location}
          onChange={(e) => setDraft((d) => ({ ...d, dropoff_location: e.target.value }))}
          placeholder={t('dropoff')}
          className="w-40 rounded border border-[var(--color-border)] px-2 py-1 text-sm"
        />
        <span
          title={overCapacity ? t('overCapacityTitle') : undefined}
          className={cn(
            'rounded-full px-2 py-0.5 text-xs',
            overCapacity
              ? 'bg-[var(--color-danger)]/10 font-semibold text-[var(--color-danger)]'
              : 'bg-[var(--color-bg-subtle)] text-[var(--color-text-secondary)]'
          )}
        >
          {capacity === null
            ? `${clump.members.length} pax`
            : `${clump.members.length}/${capacity} pax`}
        </span>

        <div className="ml-auto flex items-center gap-1">
          {dirty && (
            <button
              type="button"
              onClick={saveGroup}
              disabled={saving}
              title={t('applyToGroupTitle')}
              className="flex items-center gap-1 rounded bg-[var(--color-accent)] px-2 py-1 text-xs font-medium text-white disabled:opacity-60"
            >
              <Check className="h-3.5 w-3.5" />
              {t('applyToGroup')}
            </button>
          )}
          <IconButton title={t('deleteGroup')} onClick={removeGroup} disabled={saving}>
            <Trash2 className="h-4 w-4" />
          </IconButton>
        </div>
      </div>

      {error && <p className="mt-2 text-xs text-[var(--color-danger)]">{error}</p>}

      <ul className="mt-3 divide-y divide-[var(--color-border)]/60">
        {clump.members.map((member) => (
          <MemberRow key={member.id} transfer={member} locale={locale} onChanged={onChanged} />
        ))}
      </ul>
    </div>
  )
}

function MemberRow({
  transfer, locale, onChanged,
}: {
  transfer: Transfer
  locale: string
  onChanged: () => void
}) {
  const t = useTranslations('transferList')
  const [dragging, setDragging] = useState(false)
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState({
    pickup_time: toLocalInput(transfer.pickup_time),
    vehicle_type: transfer.vehicle_type || '',
    pickup_location: transfer.pickup_location,
    dropoff_location: transfer.dropoff_location,
    status: transfer.status,
  })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function save() {
    setSaving(true)
    setError('')
    try {
      await api.transfers.update(transfer.id, {
        pickup_time: fromLocalInput(draft.pickup_time) || undefined,
        vehicle_type: draft.vehicle_type,
        pickup_location: draft.pickup_location,
        dropoff_location: draft.dropoff_location,
        status: draft.status,
      })
      setEditing(false)
      onChanged()
    } catch (err) {
      setError(errorMessage(err, t('errSave')))
    } finally {
      setSaving(false)
    }
  }

  async function remove() {
    if (!window.confirm(t('confirmRemoveOne', { name: transfer.participant_name || t('thisPerson') }))) return
    setSaving(true)
    setError('')
    try {
      await api.transfers.remove(transfer.id)
      onChanged()
    } catch (err) {
      setError(errorMessage(err, t('errDelete')))
      setSaving(false)
    }
  }

  if (editing) {
    return (
      <li className="flex flex-wrap items-center gap-2 py-2">
        <span className="w-40 shrink-0 truncate text-sm font-medium text-[var(--color-text-primary)]">
          {transfer.participant_name || 'N/A'}
        </span>
        <input
          type="datetime-local"
          value={draft.pickup_time}
          onChange={(e) => setDraft((d) => ({ ...d, pickup_time: e.target.value }))}
          className="rounded border border-[var(--color-border)] px-2 py-1 text-xs"
        />
        <input
          value={draft.vehicle_type}
          onChange={(e) => setDraft((d) => ({ ...d, vehicle_type: e.target.value }))}
          list="transfer-vehicle-options"
          placeholder={t('vehicle')}
          className="w-28 rounded border border-[var(--color-border)] px-2 py-1 text-xs"
        />
        <input
          value={draft.pickup_location}
          onChange={(e) => setDraft((d) => ({ ...d, pickup_location: e.target.value }))}
          className="w-32 rounded border border-[var(--color-border)] px-2 py-1 text-xs"
        />
        <input
          value={draft.dropoff_location}
          onChange={(e) => setDraft((d) => ({ ...d, dropoff_location: e.target.value }))}
          className="w-32 rounded border border-[var(--color-border)] px-2 py-1 text-xs"
        />
        <select
          value={draft.status}
          onChange={(e) => setDraft((d) => ({ ...d, status: e.target.value }))}
          className="rounded border border-[var(--color-border)] bg-white px-2 py-1 text-xs"
        >
          {Object.entries(statusLabels(t)).map(([value, label]) => (
            <option key={value} value={value}>{label}</option>
          ))}
        </select>
        <div className="ml-auto flex items-center gap-1">
          <IconButton title={t('save')} onClick={save} disabled={saving}>
            <Check className="h-4 w-4 text-[var(--color-accent)]" />
          </IconButton>
          <IconButton title={t('cancel')} onClick={() => setEditing(false)} disabled={saving}>
            <X className="h-4 w-4" />
          </IconButton>
        </div>
        {error && <p className="w-full text-xs text-[var(--color-danger)]">{error}</p>}
      </li>
    )
  }

  return (
    <li
      draggable
      onDragStart={(e) => {
        e.dataTransfer.setData(DRAG_TYPE, transfer.id)
        e.dataTransfer.effectAllowed = 'move'
        setDragging(true)
      }}
      onDragEnd={() => setDragging(false)}
      className={cn(
        'flex cursor-grab items-center gap-3 py-2 text-sm active:cursor-grabbing',
        dragging && 'opacity-40'
      )}
    >
      <GripVertical className="h-4 w-4 shrink-0 text-[var(--color-text-secondary)]" />
      <span className="w-40 shrink-0 truncate font-medium text-[var(--color-text-primary)]">
        {transfer.participant_name || 'N/A'}
      </span>
      <span className="text-xs text-[var(--color-text-secondary)]">
        {formatScheduleTime(transfer.pickup_time, localeTag(locale))}
      </span>
      {transfer.flight_number && (
        <span className="font-mono text-xs text-[var(--color-text-secondary)]">{transfer.flight_number}</span>
      )}
      <span
        className={cn(
          'rounded-full px-2 py-0.5 text-xs font-medium',
          transfer.status === 'cancelled'
            ? 'bg-[var(--color-danger)]/10 text-[var(--color-danger)]'
            : transfer.status === 'completed'
            ? 'bg-[var(--color-bg-subtle)] text-[var(--color-text-secondary)]'
            : 'bg-emerald-50 text-emerald-700'
        )}
      >
        {statusLabels(t)[transfer.status] || transfer.status}
      </span>
      <div className="ml-auto flex items-center gap-1">
        <IconButton title={t('edit')} onClick={() => setEditing(true)}>
          <Pencil className="h-3.5 w-3.5" />
        </IconButton>
        <IconButton title={t('remove')} onClick={remove} disabled={saving}>
          <Trash2 className="h-3.5 w-3.5" />
        </IconButton>
      </div>
      {error && <p className="w-full text-xs text-[var(--color-danger)]">{error}</p>}
    </li>
  )
}

function IconButton({
  children, title, onClick, disabled,
}: { children: React.ReactNode; title: string; onClick: () => void; disabled?: boolean }) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      disabled={disabled}
      className="rounded p-1.5 text-[var(--color-text-secondary)] transition-colors hover:bg-[var(--color-bg-subtle)] hover:text-[var(--color-text-primary)] disabled:opacity-50"
    >
      {children}
    </button>
  )
}

/** The API speaks ISO; <input type="datetime-local"> speaks "YYYY-MM-DDTHH:mm"
 *  with no zone. Truncating rather than converting keeps the wall-clock time
 *  as computed — a pickup at 15:00 must not become 17:00 because the browser
 *  sits in another timezone. */
function toLocalInput(iso: string | null): string {
  return iso ? iso.slice(0, 16) : ''
}

function fromLocalInput(value: string): string | null {
  return value ? `${value}:00` : null
}
