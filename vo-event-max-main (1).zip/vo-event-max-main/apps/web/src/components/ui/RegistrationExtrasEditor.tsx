'use client'

import React, { useEffect, useState } from 'react'
import { useTranslations } from 'next-intl'
import { Loader2, Check, Plus, Trash2, ShieldAlert, GripVertical } from 'lucide-react'
import {
  api, type RegistrationConfirmation, type RegistrationCustomField,
} from '@/lib/api'
import { cn } from '@/lib/utils'
import { reordered, useReorder } from '@/lib/useReorder'

/**
 * The two things a fixed catalogue structurally cannot provide (feedback §9),
 * both taken from the reference form MAX already runs for Coca-Cola.
 *
 * Its own questions — that form asks for a favourite sweet and a favourite
 * song, and no catalogue will ever hold those.
 *
 * And its contractual tick-boxes — a cancellation policy with a hard date, a
 * confirmation of commercial role. Those are worded per trip and carry real
 * consequences, which is why the wording is entered here and shown to the
 * participant verbatim rather than paraphrased by the app.
 */
/** Built per render, not at module scope: a constant cannot read the locale. */
function types(t: ReturnType<typeof useTranslations>): { value: RegistrationCustomField['type']; label: string }[] {
  return [
    { value: 'text', label: t('typeText') },
    { value: 'textarea', label: t('typeTextarea') },
    { value: 'select', label: t('typeSelect') },
    { value: 'date', label: t('typeDate') },
    { value: 'boolean', label: t('typeBoolean') },
  ]
}

const inputClass =
  'w-full rounded-lg border border-[var(--color-border)] px-3 py-2 text-sm outline-none ' +
  'focus:border-[var(--color-accent)] disabled:opacity-60'

export function RegistrationExtrasEditor({
  eventId, suggestions = [], onSuggestionsUsed,
}: {
  eventId: string
  /** Questions the assistant proposed that the catalogue cannot hold. Shown
   *  as an offer, never applied on arrival: the organizer reads them first,
   *  and rows that appear by themselves in a list somebody is editing are
   *  rows they will save without noticing. */
  suggestions?: { label: string; type: string }[]
  onSuggestionsUsed?: () => void
}) {
  const t = useTranslations('registrationExtras')
  const tAct = useTranslations('actions')
  const [custom, setCustom] = useState<RegistrationCustomField[] | null>(null)
  const [confirmations, setConfirmations] = useState<RegistrationConfirmation[]>([])
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    api.events.getRegistrationExtras(eventId)
      .then((res) => {
        if (cancelled) return
        setCustom(res.custom_fields)
        setConfirmations(res.confirmations)
      })
      .catch(() => {
        if (!cancelled) setError(t('errUnavailable'))
      })
    return () => { cancelled = true }
  }, [eventId])

  async function save() {
    if (!custom) return
    setSaving(true)
    setError(null)
    setSaved(false)
    try {
      // Sent as typed; the server normalises and drops anything malformed
      // rather than rejecting the payload, so one bad row cannot lock the
      // editor. What comes back is the truth.
      const res = await api.events.setRegistrationExtras(eventId, {
        custom_fields: custom, confirmations,
      })
      setCustom(res.custom_fields)
      setConfirmations(res.confirmations)
      setSaved(true)
      setTimeout(() => setSaved(false), 2500)
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errSave'))
    } finally {
      setSaving(false)
    }
  }

  function patchCustom(index: number, patch: Partial<RegistrationCustomField>) {
    setCustom((cs) => (cs ?? []).map((c, i) => (i === index ? { ...c, ...patch } : c)))
  }

  /** The order these are asked in. Not cosmetic: the public form renders
   *  them in stored order, so this is the order three hundred people answer
   *  in — and until now the only way to change it was to retype both rows. */
  const reorder = useReorder(
    custom?.length ?? 0,
    (from, to) => {
      setCustom((cs) => (cs ? reordered(cs, from, to) : cs))
      setSaved(false)
    },
  )

  /** Append the assistant's questions as ordinary rows. Never required by
   *  default — a question the organizer has not read yet must not be one a
   *  participant cannot submit without. Duplicates by label are skipped, so
   *  clicking twice does not double the list. */
  function addSuggestions() {
    const existing = new Set((custom ?? []).map((c) => c.label.trim().toLowerCase()))
    const rows = suggestions
      .filter((sug) => sug.label.trim() && !existing.has(sug.label.trim().toLowerCase()))
      .map((sug) => ({
        // Empty, like the "add a question" button's row: the server derives
        // the key from the label when it saves.
        key: '',
        label: sug.label,
        type: (['text', 'textarea', 'select', 'date', 'boolean'].includes(sug.type)
          ? sug.type
          : 'text') as RegistrationCustomField['type'],
        required: false,
        options: [],
      }))
    setCustom((cs) => [...(cs ?? []), ...rows])
    setSaved(false)
    onSuggestionsUsed?.()
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold text-[var(--color-text-primary)]">
            {t('questionsTitle')}
          </h2>
          <p className="mt-1 max-w-2xl text-sm text-[var(--color-text-secondary)]">
            {t('questionsHint')}
          </p>
        </div>
        <button
          onClick={save}
          disabled={saving || !custom}
          className="flex items-center gap-2 rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : saved ? <Check className="h-4 w-4" /> : null}
          {saving ? t('saving') : saved ? t('saved') : tAct('save')}
        </button>
      </div>

      {error && (
        <p className="mb-4 rounded-lg border border-[var(--color-danger)] bg-[var(--color-danger-light)] px-3 py-2 text-xs text-[var(--color-danger)]">
          {error}
        </p>
      )}

      {custom && suggestions.length > 0 && (
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[var(--color-accent)] bg-[var(--color-accent-light)] px-3 py-2.5">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-[var(--color-text-primary)]">
              {t('suggestedTitle', { count: suggestions.length })}
            </p>
            <p className="mt-1 flex flex-wrap gap-1.5">
              {suggestions.map((sug) => (
                <span
                  key={sug.label}
                  className="rounded-full bg-white/70 px-2 py-0.5 text-[11px] text-[var(--color-text-secondary)]"
                >
                  {sug.label}
                </span>
              ))}
            </p>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={addSuggestions}
              className="rounded-lg bg-[var(--color-accent)] px-3 py-1.5 text-xs font-semibold text-white"
            >
              {t('suggestedAdd')}
            </button>
            <button
              type="button"
              onClick={() => onSuggestionsUsed?.()}
              className="rounded-lg border border-[var(--color-border)] px-3 py-1.5 text-xs font-medium text-[var(--color-text-secondary)]"
            >
              {t('suggestedIgnore')}
            </button>
          </div>
        </div>
      )}

      {!custom ? (
        !error && (
          <p className="flex items-center gap-2 text-sm text-[var(--color-text-secondary)]">
            <Loader2 className="h-4 w-4 animate-spin" /> {tAct('loading')}
          </p>
        )
      ) : (
        <>
          <div className="space-y-3">
            {custom.map((field, index) => (
              <div
                key={index}
                {...reorder.rowProps(index)}
                className={cn(
                  'rounded-lg border p-3 transition-colors',
                  reorder.dragging === index && 'opacity-40',
                  reorder.over === index
                    ? 'border-[var(--color-accent)] bg-[var(--color-accent-light)]'
                    : 'border-[var(--color-border)]'
                )}
              >
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    {...reorder.handleProps(index)}
                    title={t('reorderHint')}
                    aria-label={t('reorderQuestion', { position: index + 1 })}
                    className="cursor-grab rounded p-1 text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-subtle)] active:cursor-grabbing"
                  >
                    <GripVertical className="h-4 w-4" />
                  </button>
                  <input
                    value={field.label}
                    onChange={(e) => patchCustom(index, { label: e.target.value })}
                    placeholder={t('questionPlaceholder')}
                    className={cn(inputClass, 'flex-1 min-w-[200px]')}
                  />
                  <select
                    value={field.type}
                    onChange={(e) => patchCustom(index, { type: e.target.value as RegistrationCustomField['type'] })}
                    className={cn(inputClass, 'w-auto bg-white')}
                  >
                    {types(t).map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                  </select>
                  <label className="flex items-center gap-1.5 text-xs text-[var(--color-text-secondary)]">
                    <input
                      type="checkbox"
                      checked={field.required}
                      onChange={(e) => patchCustom(index, { required: e.target.checked })}
                      className="h-4 w-4 rounded border-[var(--color-border)]"
                    />
                    {t('required')}
                  </label>
                  <button
                    type="button"
                    onClick={() => setCustom((cs) => (cs ?? []).filter((_, i) => i !== index))}
                    className="rounded p-1.5 text-[var(--color-text-secondary)] hover:text-[var(--color-danger)]"
                    title={t('delete')}
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
                {field.type === 'select' && (
                  <input
                    value={field.options.join(', ')}
                    onChange={(e) => patchCustom(index, {
                      options: e.target.value.split(',').map((o) => o.trim()).filter(Boolean),
                    })}
                    placeholder={t('optionsHint')}
                    className={cn(inputClass, 'mt-2')}
                  />
                )}
              </div>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setCustom((cs) => [
              ...(cs ?? []),
              { key: '', label: '', type: 'text', required: false, options: [] },
            ])}
            className="mt-3 flex items-center gap-1.5 rounded-lg border border-[var(--color-border)] px-3 py-1.5 text-sm"
          >
            <Plus className="h-4 w-4" /> {t('addQuestion')}
          </button>

          <div className="mt-8">
            <h2 className="flex items-center gap-2 text-base font-semibold text-[var(--color-text-primary)]">
              <ShieldAlert className="h-4 w-4 text-[var(--color-accent)]" />
              {t('confirmationsTitle')}
            </h2>
            <p className="mt-1 max-w-2xl text-sm text-[var(--color-text-secondary)]">
              {t.rich('confirmationsHint', { b: (chunks) => <strong>{chunks}</strong> })}
            </p>

            <div className="mt-3 space-y-3">
              {confirmations.map((c, index) => (
                <div key={index} className="rounded-lg border border-[var(--color-border)] p-3">
                  <div className="flex items-center gap-2">
                    <input
                      value={c.label}
                      onChange={(e) => setConfirmations((cs) =>
                        cs.map((x, i) => (i === index ? { ...x, label: e.target.value } : x)))}
                      placeholder={t('confirmationPlaceholder')}
                      className={cn(inputClass, 'flex-1')}
                    />
                    <button
                      type="button"
                      onClick={() => setConfirmations((cs) => cs.filter((_, i) => i !== index))}
                      className="rounded p-1.5 text-[var(--color-text-secondary)] hover:text-[var(--color-danger)]"
                      title={t('delete')}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  <textarea
                    value={c.text}
                    onChange={(e) => setConfirmations((cs) =>
                      cs.map((x, i) => (i === index ? { ...x, text: e.target.value } : x)))}
                    rows={2}
                    placeholder={t('confirmationTextPlaceholder')}
                    className={cn(inputClass, 'mt-2')}
                  />
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setConfirmations((cs) => [...cs, { key: '', label: '', text: '' }])}
              className="mt-3 flex items-center gap-1.5 rounded-lg border border-[var(--color-border)] px-3 py-1.5 text-sm"
            >
              <Plus className="h-4 w-4" /> {t('addConfirmation')}
            </button>
          </div>
        </>
      )}
    </div>
  )
}
