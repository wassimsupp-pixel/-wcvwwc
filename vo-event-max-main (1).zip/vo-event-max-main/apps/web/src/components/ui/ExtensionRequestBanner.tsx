'use client'

import React from 'react'
import { useTranslations } from 'next-intl'
import { CalendarPlus } from 'lucide-react'
import type { Participant } from '@/lib/api'

/**
 * A personal extension at the registrant's own expense (§3).
 *
 * The registration form has asked this question — "would you like to extend
 * your stay at your own expense?", with a start date, end date, and hotel —
 * since an earlier pass on §3. Nothing downstream ever showed the answer:
 * migration 022 is what finally gives it a column to land in.
 *
 * Placed directly above the notes section on purpose. Seeing the request is
 * the first half of §3; writing down what the team told the hotel or the
 * participant about it is the second, and that already has a place — the
 * existing per-participant notes, right below this banner.
 *
 * Renders nothing at all when nobody asked, same convention as everywhere
 * else on this page: an empty box asking "why is this here" is worse than no
 * box.
 */
export function ExtensionRequestBanner({ participant }: { participant: Participant }) {
  const t = useTranslations('extensionBanner')
  const requested = (participant.extension_requested || '').trim()
  if (!requested) return null

  const range = [participant.extension_start, participant.extension_end]
    .map((d) => (d || '').trim())
    .filter(Boolean)
    .join(' → ')

  return (
    <div className="rounded-lg border border-amber-200 bg-amber-50 p-5">
      <div className="mb-1 flex items-center gap-2">
        <CalendarPlus className="h-4 w-4 text-amber-700" />
        <h3 className="text-sm font-semibold text-amber-900">
          {t('title')}
        </h3>
      </div>
      <p className="text-sm text-amber-900">{requested}</p>
      {(range || participant.extension_hotel) && (
        <dl className="mt-2 flex flex-wrap gap-x-6 gap-y-1 text-xs text-amber-800">
          {range && (
            <div className="flex gap-1">
              <dt className="font-medium">{t('dates')}</dt>
              <dd>{range}</dd>
            </div>
          )}
          {participant.extension_hotel && (
            <div className="flex gap-1">
              <dt className="font-medium">{t('hotel')}</dt>
              <dd>{participant.extension_hotel}</dd>
            </div>
          )}
        </dl>
      )}
    </div>
  )
}
