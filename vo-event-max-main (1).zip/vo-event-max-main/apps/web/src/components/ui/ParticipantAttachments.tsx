'use client'

import React, { useEffect, useState } from 'react'
import { useTranslations } from 'next-intl'
import { FileText, Image as ImageIcon, Download, Trash2, Loader2, ShieldAlert } from 'lucide-react'
import { api, errorMessage, type RegistrationAttachment } from '@/lib/api'

/**
 * The documents the registration form collected for one participant (§9).
 *
 * The form could already take a passport copy; nothing could look at one
 * afterwards, which is the worst of both worlds — the platform carried the
 * risk of holding identity documents and none of the use.
 *
 * Two deliberate choices here:
 *
 *   - **Nothing is previewed inline.** A passport thumbnail on a page somebody
 *     opens in an open-plan office, or shares over a screen call, is a leak
 *     with no attacker in it. The document is downloaded on purpose, once.
 *   - **Deleting is offered plainly.** A participant asking for their passport
 *     copy to be removed should not need an administrator, and the request is
 *     common enough that hiding it behind support would mean it never happens.
 *
 * Without migration 021 the list is simply empty and the block does not
 * render — the same graceful degradation as everywhere else.
 */

/** Built per render, not at module scope: a constant cannot read the locale. */
function kindLabels(t: ReturnType<typeof useTranslations>): Record<string, string> {
  return {
    passport_scan: t('passportScan'),
    photo: t('photo'),
  }
}

function icon(kind: string) {
  return kind === 'photo' ? ImageIcon : FileText
}

function readableSize(bytes: number): string {
  if (!bytes) return ''
  if (bytes < 1024) return `${bytes} o`
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} Ko`
  return `${(bytes / (1024 * 1024)).toFixed(1)} Mo`
}

export function ParticipantAttachments({
  eventId,
  participantId,
}: {
  eventId: string
  participantId: string
}) {
  const t = useTranslations('attachments')
  const [items, setItems] = useState<RegistrationAttachment[]>([])
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    async function load() {
      try {
        const res = await api.attachments.list(eventId, participantId)
        if (!cancelled) setItems(res.attachments)
      } catch {
        // A deployment without the table is a normal state, not an error the
        // user can act on.
        if (!cancelled) setItems([])
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    load()
    return () => {
      cancelled = true
    }
  }, [eventId, participantId])

  const handleDownload = async (item: RegistrationAttachment) => {
    setBusy(item.id)
    setError(null)
    try {
      await api.attachments.download(eventId, item.id, item.original_name || item.kind)
    } catch (err) {
      setError(errorMessage(err, t('errUnavailable')))
    } finally {
      setBusy(null)
    }
  }

  const handleDelete = async (item: RegistrationAttachment) => {
    const label = kindLabels(t)[item.kind] || item.kind
    if (!window.confirm(t('confirmDelete', { file: label }))) {
      return
    }
    setBusy(item.id)
    setError(null)
    try {
      await api.attachments.remove(eventId, item.id)
      setItems((prev) => prev.filter((a) => a.id !== item.id))
    } catch (err) {
      setError(errorMessage(err, t('errDelete')))
    } finally {
      setBusy(null)
    }
  }

  if (loading) return null
  if (items.length === 0) return null

  return (
    <div className="rounded-lg border border-slate-200 bg-white p-5">
      <div className="mb-1 flex items-center gap-2">
        <ShieldAlert className="h-4 w-4 text-amber-600" />
        <h3 className="text-sm font-semibold text-slate-900">{t('title')}</h3>
      </div>
      <p className="mb-4 text-xs text-slate-500">
        {t('subtitle')}
      </p>

      {error && (
        <p className="mb-3 rounded border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
          {error}
        </p>
      )}

      <ul className="space-y-2">
        {items.map((item) => {
          const Icon = icon(item.kind)
          const size = readableSize(item.byte_size)
          return (
            <li
              key={item.id}
              className="flex items-center justify-between gap-3 rounded border border-slate-200 px-3 py-2"
            >
              <div className="flex min-w-0 items-center gap-3">
                <Icon className="h-4 w-4 shrink-0 text-slate-400" />
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-slate-800">
                    {kindLabels(t)[item.kind] || item.kind}
                  </p>
                  <p className="truncate text-xs text-slate-500">
                    {item.original_name || '—'}
                    {size ? ` · ${size}` : ''}
                  </p>
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-1">
                <button
                  type="button"
                  onClick={() => handleDownload(item)}
                  disabled={busy === item.id}
                  className="rounded p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-800 disabled:opacity-50"
                  title={t('download')}
                >
                  {busy === item.id ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Download className="h-4 w-4" />
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => handleDelete(item)}
                  disabled={busy === item.id}
                  className="rounded p-2 text-slate-400 hover:bg-red-50 hover:text-red-600 disabled:opacity-50"
                  title={t('deleteForever')}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </li>
          )
        })}
      </ul>
    </div>
  )
}
