import { ReactNode } from 'react'
import Link from 'next/link'
import { cn } from '@/lib/utils'
import { TrendingUp, TrendingDown, Minus } from 'lucide-react'

interface KPICardProps {
  label: string
  value: string | number
  delta?: string
  deltaPositive?: boolean
  icon?: ReactNode
  accentColor?: string
  className?: string
  /** When provided, the whole card becomes a link to this route. */
  href?: string
  /** When provided (and no href), the card becomes a clickable filter button. */
  onClick?: () => void
  /** Highlight the card as the currently-active filter. */
  active?: boolean
}

export function KPICard({
  label,
  value,
  delta,
  deltaPositive,
  icon,
  // Monochrome by default, like the dashboard. A page may still pass a colour,
  // but nothing in the app does any more — a KPI is a number, not a status.
  accentColor = 'var(--color-text-primary)',
  className,
  href,
  onClick,
  active,
}: KPICardProps) {
  const DeltaIcon =
    deltaPositive === true
      ? TrendingUp
      : deltaPositive === false
        ? TrendingDown
        : Minus

  const deltaColor =
    deltaPositive === true
      ? 'text-[var(--color-success)]'
      : deltaPositive === false
        ? 'text-[var(--color-danger)]'
        : 'text-[var(--color-text-secondary)]'

  const interactive = !!href || !!onClick

  const content = (
    <div
      className={cn(
        'relative h-full overflow-hidden rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] p-5',
        // Depth is carried by the SHADOW alone. Hover used to recolour the
        // border and the active state drew a ring, and both ran around all
        // four sides -- straight over the accent bar on the left, which is the
        // one piece of colour the card has. Lifting the shadow instead reads
        // as "selected" just as clearly and leaves that bar intact.
        'shadow-[var(--shadow-card)] transition-shadow',
        interactive && 'cursor-pointer hover:shadow-[0_2px_8px_rgba(0,0,0,0.10),0_10px_28px_rgba(0,0,0,0.08)]',
        active && 'shadow-[0_2px_10px_rgba(0,0,0,0.14),0_14px_34px_rgba(0,0,0,0.10)]',
        className
      )}
      style={{ borderLeft: `3px solid ${accentColor}` }}
    >
      {/* Icon */}
      {icon && (
        <div
          className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center rounded-lg opacity-80"
          style={{ background: `${accentColor}18` }}
        >
          <span style={{ color: accentColor }}>{icon}</span>
        </div>
      )}

      {/* Value */}
      <div className="text-[40px] font-bold leading-none tracking-tight text-[var(--color-text-primary)]">
        {value}
      </div>

      {/* Label */}
      <div className="mt-1.5 text-sm font-medium text-[var(--color-text-secondary)]">
        {label}
      </div>

      {/* Delta */}
      {delta && (
        <div className={cn('mt-2 flex items-center gap-1 text-xs font-medium', deltaColor)}>
          <DeltaIcon className="h-3 w-3" />
          {delta}
        </div>
      )}
    </div>
  )

  if (href) {
    return (
      <Link href={href} className="block h-full">
        {content}
      </Link>
    )
  }

  if (onClick) {
    return (
      <button type="button" onClick={onClick} className="block h-full w-full text-left">
        {content}
      </button>
    )
  }

  return content
}
