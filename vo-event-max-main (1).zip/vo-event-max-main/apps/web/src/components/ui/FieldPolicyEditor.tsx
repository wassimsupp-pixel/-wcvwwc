'use client'

import React, { useEffect, useState } from 'react'
import { useTranslations } from 'next-intl'
import { Loader2, Check, Info } from 'lucide-react'
import { api, type FieldPolicyEntry, type FieldState } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * What this event needs to know about its participants (feedback §10).
 *
 * This is the screen that stops an event opening on a hundred and fifty cards
 * saying "Nationality missing" for a question it never asked. Three states,
 * because two booleans could not express the difference that matters:
 *
 *   required   a blank value is a real gap -- it raises an alert and weighs
 *              on the completeness score
 *   optional   collected and displayed, never alerted on, never scored
 *   not_used   this event does not collect it at all
 *
 * The wording under the control says out loud that `not_used` never deletes
 * anything, because that is the fear it has to answer: an organizer switching
 * a field off needs to know they are silencing an alert, not throwing away
 * data that arrives from a file anyway.
 */
/** Built per render, not at module scope: a constant cannot read the locale. */
function states(t: ReturnType<typeof useTranslations>): { value: FieldState; label: string; hint: string }[] {
  return [
    { value: 'required', label: t('required'), hint: t('requiredHint') },
    { value: 'optional', label: t('optional'), hint: t('optionalHint') },
    { value: 'not_used', label: t('notUsed'), hint: t('notUsedHint') },
  ]
}

export function FieldPolicyEditor({ eventId }: { eventId: string }) {
  const t = useTranslations('fieldPolicy')
  const tAct = useTranslations('actions')
  const [catalogue, setCatalogue] = useState<FieldPolicyEntry[] | null>(null)
  const [policy, setPolicy] = useState<Record<string, FieldState>>({})
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    api.events.getFieldPolicy(eventId)
      .then((res) => {
        if (cancelled) return
        setCatalogue(res.catalogue)
        setPolicy(res.policy)
      })
      .catch(() => {
        if (!cancelled) setError(t('errUnavailable'))
      })
    return () => { cancelled = true }
  }, [eventId])

  async function save() {
    setSaving(true)
    setError(null)
    setSaved(false)
    try {
      const res = await api.events.setFieldPolicy(eventId, policy)
      setPolicy(res.policy)
      setSaved(true)
      setTimeout(() => setSaved(false), 2500)
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errSave'))
    } finally {
      setSaving(false)
    }
  }

  const groups = Array.from(new Set((catalogue ?? []).map((f) => f.group)))
  const requiredCount = Object.values(policy).filter((s) => s === 'required').length
  const unusedCount = Object.values(policy).filter((s) => s === 'not_used').length

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold text-[var(--color-text-primary)]">
            {t('title')}
          </h2>
          <p className="mt-1 max-w-2xl text-sm text-[var(--color-text-secondary)]">
            {t.rich('hint', { b: (chunks) => <strong>{chunks}</strong> })}
          </p>
        </div>
        <button
          onClick={save}
          disabled={saving || !catalogue}
          className="flex items-center gap-2 rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : saved ? <Check className="h-4 w-4" /> : null}
          {saving ? 'Enregistrement…' : saved ? t('saved') : 'Enregistrer'}
        </button>
      </div>

      {catalogue && (
        <div className="mb-4 flex flex-wrap gap-2 text-xs">
          <span className="rounded-full bg-[var(--color-bg-subtle)] px-2.5 py-1 text-[var(--color-text-secondary)]">
            {requiredCount} champ(s) requis
          </span>
          {unusedCount > 0 && (
            <span className="rounded-full bg-[var(--color-bg-subtle)] px-2.5 py-1 text-[var(--color-text-secondary)]">
              {unusedCount} {t('notUsedCount')}
            </span>
          )}
        </div>
      )}

      {error && (
        <p className="mb-4 rounded-lg border border-[var(--color-danger)] bg-[var(--color-danger-light)] px-3 py-2 text-xs text-[var(--color-danger)]">
          {error}
        </p>
      )}

      {!catalogue ? (
        !error && (
          <p className="flex items-center gap-2 text-sm text-[var(--color-text-secondary)]">
            <Loader2 className="h-4 w-4 animate-spin" /> {tAct('loading')}
          </p>
        )
      ) : (
        <div className="space-y-5">
          {groups.map((group) => (
            <div key={group}>
              <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-[var(--color-text-secondary)]">
                {group}
              </p>
              <div className="overflow-hidden rounded-lg border border-[var(--color-border)]">
                {catalogue.filter((f) => f.group === group).map((f) => (
                  <div
                    key={f.key}
                    className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--color-border)] px-4 py-2.5 last:border-0"
                  >
                    <span className="text-sm text-[var(--color-text-primary)]">{f.label}</span>
                    <div className="inline-flex overflow-hidden rounded-lg border border-[var(--color-border)]">
                      {states(t).map((state) => (
                        <button
                          key={state.value}
                          type="button"
                          title={state.hint}
                          onClick={() => setPolicy((p) => ({ ...p, [f.key]: state.value }))}
                          className={cn(
                            'px-3 py-1.5 text-xs font-medium transition-colors',
                            (policy[f.key] ?? f.default) === state.value
                              ? 'bg-[var(--color-accent)] text-white'
                              : 'bg-white text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]'
                          )}
                        >
                          {state.label}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}

          <p className="flex items-start gap-1.5 text-xs text-[var(--color-text-secondary)]">
            <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            {t('takesEffect')}
          </p>
        </div>
      )}
    </div>
  )
}
