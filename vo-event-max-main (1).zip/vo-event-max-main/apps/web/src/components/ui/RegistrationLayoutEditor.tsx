'use client'

/**
 * The one editor for every page of the public registration link.
 *
 * A page is either the registration page ("home", the only one that carries the
 * form) or a mini-site section from the event's catalogue (Programme, Infos…).
 * Each is arranged in the same blocks — a photo, a heading, a paragraph, a
 * button, a divider — and previewed live by the very `LayoutCanvas` the public
 * page uses, so the preview cannot drift from what a participant sees.
 *
 * Text is multilingual: every text field holds one value per language, and the
 * language switcher chooses which you edit and preview. Nothing an organizer
 * types becomes CSS or markup — the server re-derives every block, value, page
 * key and language on save (services/registration_layout.py). This editor only
 * has to make choosing the values pleasant. It absorbs the old mini-site editor:
 * page titles and visibility are set here, next to the blocks that fill them.
 */

import { useCallback, useEffect, useMemo, useState } from 'react'
import {
  LayoutCanvas, resolveLayoutPages, PRESET_BACKGROUNDS, pick,
  type LayoutBlock, type FormBlock, type I18n,
} from '@/lib/registrationLayout'
import {
  themeVariables, accentContrast, AA_CONTRAST, resolveTheme, pageBackground, type RegistrationTheme,
} from '@/lib/registrationTheme'
import { api, errorMessage, type EventSiteSectionDraft } from '@/lib/api'
import { cn } from '@/lib/utils'
import {
  Image as ImageIcon, Type, AlignLeft, MousePointerClick, Minus, ListChecks,
  ChevronUp, ChevronDown, Trash2, Loader2, Check, Monitor, Smartphone, Upload,
  GripVertical, Eye, EyeOff, FileText,
} from 'lucide-react'

type Device = 'desktop' | 'mobile'
const HOME = 'home'

// The page-level appearance, folded in from the old "Apparence" card. Font,
// accent, surface and corners are the foundation every block sits on and the
// form inherits; the blocks handle content, this handles the ground.
const FONT_LABELS: [string, string][] = [
  ['sans', 'Neutre'], ['grotesk', 'Moderne'], ['serif', 'Éditoriale'], ['slab', 'Affirmée'], ['rounded', 'Chaleureuse'],
]
const SURFACE_LABELS: [string, string][] = [['light', 'Clair'], ['soft', 'Teinté'], ['dark', 'Sombre']]
const CORNER_LABELS: [string, string][] = [['sharp', 'Droits'], ['soft', 'Adoucis'], ['round', 'Arrondis']]
const LANG_LABEL: Record<string, string> = { fr: 'Français', nl: 'Nederlands', en: 'English' }
const uid = () => 'b' + Math.random().toString(36).slice(2, 10)

const FONT_OPTIONS: [string, string][] = [
  ['sans', 'Sans'], ['grotesk', 'Grotesk'], ['serif', 'Serif'], ['slab', 'Slab'], ['rounded', 'Rond'],
]
const ALIGN_OPTIONS: [string, string][] = [['left', 'Gauche'], ['center', 'Centre'], ['right', 'Droite']]
const PRESET_KEYS = ['dusk', 'sunrise', 'rose', 'violet', 'forest'] as const

const BLOCK_META: Record<string, { label: string; icon: typeof Type }> = {
  image: { label: 'Photo', icon: ImageIcon },
  title: { label: 'Titre', icon: Type },
  text: { label: 'Texte', icon: AlignLeft },
  button: { label: 'Bouton', icon: MousePointerClick },
  divider: { label: 'Séparateur', icon: Minus },
  form: { label: 'Formulaire', icon: ListChecks },
}

const one = (lang: string, value: string): I18n => ({ [lang]: value })

function makeBlock(type: string, lang: string): LayoutBlock {
  const base = { id: uid(), col: 'full' as const }
  switch (type) {
    case 'image':
      return { ...base, type: 'image', variant: 'banner', image_url: '', preset: 'sunrise',
        heading: one(lang, 'Nouveau titre'), subheading: {}, overlay_color: '#ffffff',
        overlay_align: 'left', overlay_pos: 'end', heading_font: 'serif', heading_size: 'l' }
    case 'title':
      return { ...base, type: 'title', text: one(lang, 'Nouveau titre'), font: 'grotesk', size: 'l', align: 'left', color: '' }
    case 'text':
      return { ...base, type: 'text', text: one(lang, 'Votre texte ici. Cliquez pour le modifier.'), font: 'sans', size: 'm', align: 'left', width: 'narrow', color: '' }
    case 'button':
      return { ...base, type: 'button', label: one(lang, 'En savoir plus'), href: '', bg: '#2563eb', fg: '#ffffff', corners: 'soft', align: 'center', full: false }
    case 'divider':
      return { ...base, type: 'divider', color: '', thickness: 1 }
    default:
      return { ...base, type: 'form', accent: '#2563eb', corners: 'soft', style: 'outline', button: one(lang, "Je m'inscris") }
  }
}

function blockName(b: LayoutBlock, lang: string): string {
  if (b.type === 'image') return pick(b.heading, lang) || 'Photo'
  if (b.type === 'title' || b.type === 'text') return pick(b.text, lang).slice(0, 22) || BLOCK_META[b.type].label
  if (b.type === 'button') return pick(b.label, lang) || 'Bouton'
  return BLOCK_META[b.type].label
}

// ---------------------------------------------------------------------------
// small controls
// ---------------------------------------------------------------------------

function Seg({ label, hint, value, options, onChange }: {
  label: string; hint?: string; value: string; options: [string, string][]; onChange: (v: string) => void
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[11px] font-bold uppercase tracking-wide text-[var(--color-text-secondary)]">
        {label}{hint ? <span className="ml-1 font-medium normal-case tracking-normal text-[var(--color-text-secondary)] opacity-70">{hint}</span> : null}
      </label>
      <div className="flex flex-wrap gap-1 rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-1">
        {options.map(([v, t]) => (
          <button key={v} type="button" onClick={() => onChange(v)} aria-pressed={v === value}
            className={cn('flex-1 whitespace-nowrap rounded-md px-2.5 py-1.5 text-xs font-semibold transition-colors',
              v === value ? 'bg-[var(--color-surface)] text-[var(--color-text-primary)] shadow-sm' : 'text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]')}>
            {t}
          </button>
        ))}
      </div>
    </div>
  )
}

const COLOR_PRESETS = ['#111827', '#ffffff', '#d6336c', '#7c3aed', '#0ea5a3', '#e8590c', '#2563eb', '#16a34a']

function Swatches({ label, value, onChange, allowAuto }: {
  label: string; value: string; onChange: (v: string) => void; allowAuto?: boolean
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[11px] font-bold uppercase tracking-wide text-[var(--color-text-secondary)]">{label}</label>
      <div className="flex flex-wrap items-center gap-2">
        {allowAuto && (
          <button type="button" onClick={() => onChange('')} aria-label="Automatique"
            className={cn('h-7 w-7 rounded-lg ring-1 ring-[var(--color-border)]', !value && 'ring-2 ring-[var(--color-accent)]')}
            style={{ background: 'linear-gradient(135deg,#fff 47%,#e11 47%,#e11 53%,#fff 53%)' }} />
        )}
        {COLOR_PRESETS.map((c) => (
          <button key={c} type="button" onClick={() => onChange(c)} aria-label={c}
            className={cn('h-7 w-7 rounded-lg ring-1 ring-[var(--color-border)]', value.toLowerCase() === c && 'ring-2 ring-[var(--color-accent)]')}
            style={{ background: c }} />
        ))}
        <input type="color" value={/^#[0-9a-fA-F]{6}$/.test(value) ? value : '#000000'}
          onChange={(e) => onChange(e.target.value)} aria-label={`${label} personnalisée`}
          className="h-7 w-9 cursor-pointer rounded-lg border border-[var(--color-border)] bg-transparent p-0" />
      </div>
    </div>
  )
}

function TextField({ label, value, onChange, placeholder }: {
  label: string; value: string; onChange: (v: string) => void; placeholder?: string
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[11px] font-bold uppercase tracking-wide text-[var(--color-text-secondary)]">{label}</label>
      <input type="text" value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)}
        className="rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-3 py-2 text-sm text-[var(--color-text-primary)] outline-none focus:border-[var(--color-accent)]" />
    </div>
  )
}

function TextArea({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[11px] font-bold uppercase tracking-wide text-[var(--color-text-secondary)]">{label}</label>
      <textarea value={value} rows={3} onChange={(e) => onChange(e.target.value)}
        className="resize-y rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-3 py-2 text-sm text-[var(--color-text-primary)] outline-none focus:border-[var(--color-accent)]" />
    </div>
  )
}

function Toggle({ label, on, onChange }: { label: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between py-1">
      <span className="text-sm text-[var(--color-text-primary)]">{label}</span>
      <button type="button" role="switch" aria-checked={on} onClick={() => onChange(!on)}
        className={cn('relative h-5 w-9 rounded-full transition-colors', on ? 'bg-[var(--color-accent)]' : 'bg-[var(--color-border)]')}>
        <span className={cn('absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform', on ? 'left-0.5 translate-x-4' : 'left-0.5')} />
      </button>
    </div>
  )
}

function MockForm({ block, lang }: { block: FormBlock; lang: string }) {
  const field = block.style === 'fill'
    ? { background: 'var(--color-input, #f1f5f9)', border: '1px solid transparent' }
    : { background: 'transparent', border: '1.5px solid var(--color-border, #e2e8f0)' }
  return (
    <div className="flex flex-col gap-3 px-7 pb-8 pt-5">
      {['Prénom', 'E-mail professionnel', 'Téléphone'].map((l) => (
        <label key={l} className="block">
          <span className="mb-1 block text-xs font-semibold text-[var(--color-text-secondary)]">{l}</span>
          <span className="block h-10" style={{ ...field, borderRadius: 'var(--radius-card, 12px)' }} />
        </label>
      ))}
      <span className="mt-1 flex items-center justify-center py-3 font-bold text-white"
        style={{ background: 'var(--color-accent)', borderRadius: 'var(--radius-card, 12px)' }}>
        {pick(block.button, lang) || "Je m'inscris"}
      </span>
    </div>
  )
}

// ---------------------------------------------------------------------------
// the editor
// ---------------------------------------------------------------------------

export function RegistrationLayoutEditor({ eventId, theme, onThemeChange }: {
  eventId: string
  /** The page-level appearance, owned by the parent so the AI assistant can
   *  also set it; this editor renders its controls and saves it with the rest. */
  theme: RegistrationTheme
  onThemeChange: (t: RegistrationTheme) => void
}) {
  // The public form is English-only, so there is one language to edit.
  const lang = 'en'
  const [pages, setPages] = useState<Record<string, LayoutBlock[]>>({ home: [] })
  const [sections, setSections] = useState<Record<string, EventSiteSectionDraft>>({})
  const [catalogue, setCatalogue] = useState<{ slug: string; label: string }[]>([])
  const [selectedPage, setSelectedPage] = useState<string>(HOME)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [device, setDevice] = useState<Device>('desktop')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [dirty, setDirty] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [uploadingId, setUploadingId] = useState<string | null>(null)
  const [uploadingBg, setUploadingBg] = useState(false)
  const [dragId, setDragId] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    Promise.all([api.events.getRegistrationLayout(eventId), api.events.getSite(eventId)])
      .then(([layoutRes, site]) => {
        if (cancelled) return
        const resolved = resolveLayoutPages(layoutRes.layout)
        if (!resolved.home) resolved.home = []
        setPages(resolved)
        setSections(Object.fromEntries(site.sections.map((s) => [s.slug, s])))
        setCatalogue(site.catalogue || [])
        setSelectedId((resolved.home ?? [])[0]?.id ?? null)
      })
      .catch((e) => !cancelled && setError(errorMessage(e, 'Chargement impossible.')))
      .finally(() => !cancelled && setLoading(false))
    return () => { cancelled = true }
  }, [eventId])

  const blocks = pages[selectedPage] ?? []
  const selected = useMemo(() => blocks.find((b) => b.id === selectedId) ?? null, [blocks, selectedId])
  const hasForm = blocks.some((b) => b.type === 'form')

  const changeTheme = (change: Partial<RegistrationTheme>) => {
    onThemeChange({ ...theme, ...change }); setDirty(true); setSaved(false)
  }

  const draftFor = useCallback(
    (slug: string): EventSiteSectionDraft => sections[slug] ?? { slug, title: {}, body: {}, image_url: '', visible: true },
    [sections],
  )
  const pageTitle = useCallback((slug: string): string => {
    if (slug === HOME) return 'Inscription'
    return draftFor(slug).title?.[lang] || catalogue.find((c) => c.slug === slug)?.label || slug
  }, [draftFor, lang, catalogue])

  // Registration page first, then the catalogue in the organizer's saved order.
  const pageOrder = useMemo(() => {
    const cat = [...catalogue].sort((a, b) => {
      const pa = sections[a.slug]?.position ?? 99
      const pb = sections[b.slug]?.position ?? 99
      return pa - pb || catalogue.findIndex((c) => c.slug === a.slug) - catalogue.findIndex((c) => c.slug === b.slug)
    })
    return [HOME, ...cat.map((c) => c.slug)]
  }, [catalogue, sections])

  const setPageBlocks = useCallback((next: LayoutBlock[]) => {
    setPages((p) => ({ ...p, [selectedPage]: next })); setDirty(true); setSaved(false)
  }, [selectedPage])

  // Composing a catalogue page implies it should be reachable, so ensure it has
  // a visible section with a title before its blocks can be seen.
  const ensureVisible = useCallback((slug: string) => {
    if (slug === HOME) return
    setSections((s) => {
      if (s[slug]?.visible) return s
      const label = catalogue.find((c) => c.slug === slug)?.label || slug
      const prev = s[slug] ?? { slug, title: {}, body: {}, image_url: '', visible: true }
      const title = Object.keys(prev.title).length ? prev.title : { [lang]: label }
      return { ...s, [slug]: { ...prev, visible: true, title } }
    })
    setDirty(true)
  }, [catalogue, lang])

  const patch = useCallback((id: string, changes: Record<string, unknown>) => {
    setPages((p) => ({ ...p, [selectedPage]: (p[selectedPage] ?? []).map((b) => (b.id === id ? ({ ...b, ...changes } as LayoutBlock) : b)) }))
    setDirty(true); setSaved(false)
  }, [selectedPage])

  const patchText = useCallback((id: string, field: string, value: string) => {
    setPages((p) => ({ ...p, [selectedPage]: (p[selectedPage] ?? []).map((b) => {
      if (b.id !== id) return b
      const current = (b as unknown as Record<string, I18n>)[field] ?? {}
      return { ...b, [field]: { ...current, [lang]: value } } as LayoutBlock
    }) }))
    setDirty(true); setSaved(false)
  }, [selectedPage, lang])

  const add = (type: string) => {
    const block = makeBlock(type, lang)
    setPageBlocks([...blocks, block]); setSelectedId(block.id)
    ensureVisible(selectedPage)
  }
  const remove = (id: string) => {
    const i = blocks.findIndex((b) => b.id === id)
    const next = blocks.filter((b) => b.id !== id)
    setPageBlocks(next)
    if (selectedId === id) setSelectedId(next[Math.max(0, i - 1)]?.id ?? null)
  }
  const move = (id: string, dir: -1 | 1) => {
    const i = blocks.findIndex((b) => b.id === id)
    const j = i + dir
    if (j < 0 || j >= blocks.length) return
    const next = [...blocks]; ;[next[i], next[j]] = [next[j], next[i]]; setPageBlocks(next)
  }
  const reorder = (from: string, toId: string) => {
    const fi = blocks.findIndex((b) => b.id === from)
    const ti = blocks.findIndex((b) => b.id === toId)
    if (fi < 0 || ti < 0 || fi === ti) return
    const next = [...blocks]; const [b] = next.splice(fi, 1); next.splice(ti, 0, b); setPageBlocks(next)
  }

  const setSectionTitle = (slug: string, value: string) => {
    setSections((s) => {
      const prev = s[slug] ?? draftFor(slug)
      return { ...s, [slug]: { ...prev, title: { ...prev.title, [lang]: value } } }
    })
    setDirty(true); setSaved(false)
  }
  const setSectionVisible = (slug: string, visible: boolean) => {
    setSections((s) => ({ ...s, [slug]: { ...(s[slug] ?? draftFor(slug)), visible } }))
    setDirty(true); setSaved(false)
  }
  const movePage = (slug: string, dir: -1 | 1) => {
    // Reorder within the catalogue by rewriting positions.
    const cat = pageOrder.filter((k) => k !== HOME)
    const i = cat.indexOf(slug)
    const j = i + dir
    if (j < 0 || j >= cat.length) return
    ;[cat[i], cat[j]] = [cat[j], cat[i]]
    setSections((s) => {
      const out = { ...s }
      cat.forEach((sl, idx) => { out[sl] = { ...(out[sl] ?? draftFor(sl)), position: idx } })
      return out
    })
    setDirty(true); setSaved(false)
  }

  const onUpload = async (id: string, file: File | null) => {
    if (!file) return
    setUploadingId(id); setError(null)
    try {
      const { url } = await api.events.uploadSiteImage(eventId, file)
      patch(id, { image_url: url, preset: '' })
    } catch (e) {
      setError(errorMessage(e, "L'image n'a pas pu être téléversée."))
    } finally {
      setUploadingId(null)
    }
  }

  const onUploadBg = async (file: File | null) => {
    if (!file) return
    setUploadingBg(true); setError(null)
    try {
      const { url } = await api.events.uploadSiteImage(eventId, file)
      changeTheme({ background_image: url })
    } catch (e) {
      setError(errorMessage(e, "L'image n'a pas pu être téléversée."))
    } finally {
      setUploadingBg(false)
    }
  }

  const save = async () => {
    setSaving(true); setError(null)
    try {
      const res = await api.events.setRegistrationLayout(eventId, pages as unknown as Record<string, unknown[]>)
      if (Object.keys(sections).length) {
        const site = await api.events.setSite(eventId, Object.values(sections))
        setSections(Object.fromEntries(site.sections.map((s) => [s.slug, s])))
      }
      const themeRes = await api.events.setRegistrationTheme(eventId, theme)
      onThemeChange(resolveTheme(themeRes.theme))
      const map = resolveLayoutPages(res.layout)
      if (!map.home) map.home = []
      setPages(map)
      setDirty(false); setSaved(true)
      setTimeout(() => setSaved(false), 2500)
    } catch (e) {
      setError(errorMessage(e, "L'enregistrement a échoué."))
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center gap-2 rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)] p-6 text-sm text-[var(--color-text-secondary)]">
        <Loader2 className="h-4 w-4 animate-spin" /> Chargement des pages…
      </div>
    )
  }

  const selectedIsHome = selectedPage === HOME
  const selectedDraft = draftFor(selectedPage)

  return (
    <div className="overflow-hidden rounded-2xl border border-[var(--color-border)] bg-[var(--color-surface)]">
      {/* header */}
      <div className="flex flex-wrap items-center gap-3 border-b border-[var(--color-border)] px-5 py-4">
        <div className="mr-auto">
          <h3 className="text-base font-bold text-[var(--color-text-primary)]">Pages du formulaire</h3>
          <p className="mt-0.5 text-xs text-[var(--color-text-secondary)]">
            Composez chaque page en blocs. Chaque page se replie sur mobile. Le formulaire public est en anglais.
          </p>
        </div>
        <div className="flex rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-1">
          <button type="button" onClick={() => setDevice('desktop')} aria-pressed={device === 'desktop'} aria-label="Ordinateur"
            className={cn('rounded-md px-2.5 py-1.5', device === 'desktop' ? 'bg-[var(--color-surface)] shadow-sm text-[var(--color-text-primary)]' : 'text-[var(--color-text-secondary)]')}>
            <Monitor className="h-4 w-4" />
          </button>
          <button type="button" onClick={() => setDevice('mobile')} aria-pressed={device === 'mobile'} aria-label="Mobile"
            className={cn('rounded-md px-2.5 py-1.5', device === 'mobile' ? 'bg-[var(--color-surface)] shadow-sm text-[var(--color-text-primary)]' : 'text-[var(--color-text-secondary)]')}>
            <Smartphone className="h-4 w-4" />
          </button>
        </div>
        <button type="button" onClick={save} disabled={saving}
          className="flex items-center gap-2 rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : saved ? <Check className="h-4 w-4" /> : null}
          {saved ? 'Enregistré' : 'Enregistrer'}
        </button>
      </div>

      {error && <div className="border-b border-[var(--color-border)] bg-[var(--color-danger-light)] px-5 py-2 text-sm text-[var(--color-danger)]">{error}</div>}

      <div className="grid lg:grid-cols-[210px_210px_1fr_260px]">
        {/* pages */}
        <div className="border-b border-[var(--color-border)] p-3 lg:border-b-0 lg:border-r">
          {/* Page-level appearance — the foundation every page and the form sit
              on. Folded in from the old standalone "Apparence" card. */}
          <div className="mb-3 flex flex-col gap-2.5 rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-2.5">
            <p className="text-[11px] font-bold uppercase tracking-wide text-[var(--color-text-secondary)]">Apparence — tout le lien</p>
            <Seg label="Police" value={theme.font} options={FONT_LABELS} onChange={(v) => changeTheme({ font: v as RegistrationTheme['font'] })} />
            <Swatches label="Couleur principale" value={theme.accent} onChange={(v) => changeTheme({ accent: v || '#2563eb' })} />
            {accentContrast(theme.accent) < AA_CONTRAST && (
              <p className="text-[10px] leading-tight text-[#b45309]">
                Contraste faible ({accentContrast(theme.accent).toFixed(1)}:1) — le texte du bouton risque d’être peu lisible.
              </p>
            )}
            <Seg label="Fond de page" value={theme.surface} options={SURFACE_LABELS} onChange={(v) => changeTheme({ surface: v as RegistrationTheme['surface'] })} />
            <Seg label="Coins" value={theme.corners} options={CORNER_LABELS} onChange={(v) => changeTheme({ corners: v as RegistrationTheme['corners'] })} />
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wide text-[var(--color-text-secondary)]">Image de fond (toute la page)</label>
              <label className="flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-[var(--color-border)] py-2 text-xs font-semibold text-[var(--color-text-secondary)] hover:border-[var(--color-accent)]">
                {uploadingBg ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                {theme.background_image ? 'Changer la photo de fond' : 'Photo de fond de page'}
                <input type="file" accept="image/*" className="hidden" onChange={(e) => onUploadBg(e.target.files?.[0] ?? null)} />
              </label>
              {theme.background_image && (
                <button type="button" onClick={() => changeTheme({ background_image: '' })}
                  className="self-start text-[11px] text-[var(--color-text-secondary)] underline hover:text-[var(--color-text-primary)]">
                  Retirer la photo de fond
                </button>
              )}
            </div>
          </div>

          <p className="mb-2 px-1 text-[11px] font-bold uppercase tracking-wide text-[var(--color-text-secondary)]">Pages</p>
          <div className="flex flex-col gap-1">
            {pageOrder.map((slug, idx) => {
              const isHome = slug === HOME
              const composed = (pages[slug]?.length ?? 0) > 0
              const visible = isHome || (sections[slug]?.visible ?? false)
              return (
                <button key={slug} type="button" onClick={() => { setSelectedPage(slug); setSelectedId((pages[slug] ?? [])[0]?.id ?? null) }}
                  className={cn('flex items-center gap-2 rounded-lg border p-2 text-left',
                    slug === selectedPage ? 'border-[var(--color-accent)] bg-[var(--color-accent-light)]' : 'border-transparent bg-[var(--color-bg-subtle)] hover:border-[var(--color-border)]')}>
                  {isHome ? <ListChecks className="h-4 w-4 shrink-0 text-[var(--color-accent)]" /> : <FileText className={cn('h-4 w-4 shrink-0', visible ? 'text-[var(--color-text-secondary)]' : 'opacity-40')} />}
                  <span className={cn('flex-1 truncate text-xs font-semibold', visible ? 'text-[var(--color-text-primary)]' : 'text-[var(--color-text-secondary)]')}>
                    {pageTitle(slug)}
                  </span>
                  {composed && <span className="h-1.5 w-1.5 rounded-full bg-[var(--color-accent)]" title="Composée en blocs" />}
                  {!isHome && visible && !composed && (
                    <span className="text-[11px] font-bold leading-none text-[#b45309]" title="Vide — n’apparaîtra pas dans le lien">!</span>
                  )}
                  {!isHome && !visible && <EyeOff className="h-3.5 w-3.5 text-[var(--color-text-secondary)] opacity-50" />}
                </button>
              )
            })}
          </div>
          <p className="mt-3 px-1 text-[10px] leading-relaxed text-[var(--color-text-secondary)] opacity-80">
            Les pages viennent du catalogue du mini-site. Composez-en une pour qu’elle apparaisse dans les onglets du lien.
          </p>
        </div>

        {/* palette + layers for the selected page */}
        <div className="border-b border-[var(--color-border)] p-3 lg:border-b-0 lg:border-r">
          {!selectedIsHome && (
            <div className="mb-3 flex flex-col gap-2 rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-2.5">
              <input type="text" value={selectedDraft.title?.[lang] ?? ''} placeholder={pageTitle(selectedPage)}
                onChange={(e) => setSectionTitle(selectedPage, e.target.value)}
                className="rounded-md border border-[var(--color-border)] bg-[var(--color-surface)] px-2 py-1.5 text-xs font-semibold text-[var(--color-text-primary)] outline-none focus:border-[var(--color-accent)]" />
              <div className="flex items-center justify-between">
                <button type="button" onClick={() => setSectionVisible(selectedPage, !(sections[selectedPage]?.visible ?? false))}
                  className="flex items-center gap-1.5 text-xs font-medium text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]">
                  {(sections[selectedPage]?.visible ?? false) ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
                  {(sections[selectedPage]?.visible ?? false) ? 'Visible' : 'Masquée'}
                </button>
                <span className="flex gap-1">
                  <button type="button" onClick={() => movePage(selectedPage, -1)} aria-label="Monter la page" className="rounded p-0.5 text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]"><ChevronUp className="h-3.5 w-3.5" /></button>
                  <button type="button" onClick={() => movePage(selectedPage, 1)} aria-label="Descendre la page" className="rounded p-0.5 text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]"><ChevronDown className="h-3.5 w-3.5" /></button>
                </span>
              </div>
              {/* Visible is not enough: an empty page would be a tab leading to a
                  blank screen, so the public link leaves it out until it has
                  content. Say so here rather than let it silently not appear. */}
              {blocks.length === 0 && (
                <p className="text-[10px] leading-tight text-[#b45309]">
                  Cette page n’apparaîtra pas dans le lien tant qu’elle est vide.
                  Ajoutez au moins un bloc ci-dessous.
                </p>
              )}
            </div>
          )}

          <p className="mb-2 px-1 text-[11px] font-bold uppercase tracking-wide text-[var(--color-text-secondary)]">Ajouter un bloc</p>
          <div className="grid grid-cols-2 gap-2">
            {['image', 'title', 'text', 'button', 'divider'].map((type) => {
              const M = BLOCK_META[type]
              return (
                <button key={type} type="button" onClick={() => add(type)}
                  className="flex flex-col items-start gap-1.5 rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-2.5 text-left hover:border-[var(--color-accent)]">
                  <M.icon className="h-4 w-4 text-[var(--color-accent)]" />
                  <span className="text-xs font-semibold text-[var(--color-text-primary)]">{M.label}</span>
                </button>
              )
            })}
            {selectedIsHome && !hasForm && (
              <button type="button" onClick={() => add('form')}
                className="flex flex-col items-start gap-1.5 rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-subtle)] p-2.5 text-left hover:border-[var(--color-accent)]">
                <ListChecks className="h-4 w-4 text-[var(--color-accent)]" />
                <span className="text-xs font-semibold text-[var(--color-text-primary)]">Formulaire</span>
              </button>
            )}
          </div>

          <p className="mb-2 mt-4 px-1 text-[11px] font-bold uppercase tracking-wide text-[var(--color-text-secondary)]">Blocs</p>
          <div className="flex flex-col gap-1.5">
            {blocks.map((b, i) => {
              const M = BLOCK_META[b.type]
              return (
                <div key={b.id} draggable
                  onDragStart={() => setDragId(b.id)}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={() => { if (dragId) reorder(dragId, b.id); setDragId(null) }}
                  onClick={() => setSelectedId(b.id)}
                  className={cn('flex cursor-pointer items-center gap-2 rounded-lg border p-2',
                    b.id === selectedId ? 'border-[var(--color-accent)] bg-[var(--color-accent-light)]' : 'border-transparent bg-[var(--color-bg-subtle)] hover:border-[var(--color-border)]')}>
                  <GripVertical className="h-3.5 w-3.5 shrink-0 cursor-grab text-[var(--color-text-secondary)]" />
                  <M.icon className={cn('h-4 w-4 shrink-0', b.id === selectedId ? 'text-[var(--color-accent)]' : 'text-[var(--color-text-secondary)]')} />
                  <span className="flex-1 truncate text-xs font-semibold text-[var(--color-text-primary)]">{blockName(b, lang)}</span>
                  <button type="button" onClick={(e) => { e.stopPropagation(); move(b.id, -1) }} disabled={i === 0} aria-label="Monter" className="rounded p-0.5 text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] disabled:opacity-30"><ChevronUp className="h-3.5 w-3.5" /></button>
                  <button type="button" onClick={(e) => { e.stopPropagation(); move(b.id, 1) }} disabled={i === blocks.length - 1} aria-label="Descendre" className="rounded p-0.5 text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] disabled:opacity-30"><ChevronDown className="h-3.5 w-3.5" /></button>
                </div>
              )
            })}
            {blocks.length === 0 && <p className="px-1 py-3 text-xs text-[var(--color-text-secondary)]">Aucun bloc. Ajoutez-en un ci-dessus.</p>}
          </div>
        </div>

        {/* preview */}
        <div className="flex justify-center overflow-auto bg-[var(--color-bg-subtle)] p-5"
          style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, var(--color-border) 1px, transparent 0)', backgroundSize: '22px 22px' }}>
          {/* A screen, not a strip: the box scrolls its own content and keeps
              its height, so the background photo is sized to what a visitor
              actually sees and stays put underneath — the same thing the page's
              fixed layer does, reached here through `background-attachment:
              scroll`, which pins a background to a scrolling BOX. Without the
              photo at all, as it was, the first person to see it was a
              participant. */}
          <div className="w-full overflow-y-auto overflow-x-hidden rounded-2xl border border-[var(--color-border)] shadow-sm transition-all"
            style={{ maxWidth: device === 'mobile' ? 380 : 620, maxHeight: '72vh', ...themeVariables(theme),
                     background: theme.background_image ? pageBackground(theme) : 'var(--color-surface)' }}>
            {blocks.length > 0
              ? <LayoutCanvas blocks={blocks} locale={lang} renderForm={(b) => <MockForm block={b} lang={lang} />} />
              : <div className="p-10 text-center text-sm text-[var(--color-text-secondary)]">Page vide — elle s’affichera de façon classique tant qu’aucun bloc n’est ajouté.</div>}
          </div>
        </div>

        {/* properties */}
        <div className="border-t border-[var(--color-border)] p-4 lg:border-l lg:border-t-0">
          {!selected ? (
            <p className="py-10 text-center text-sm text-[var(--color-text-secondary)]">Sélectionnez un bloc pour le personnaliser.</p>
          ) : (
            <div className="flex flex-col gap-4">
              <Properties block={selected} lang={lang} patch={patch} patchText={patchText} onUpload={onUpload} uploading={uploadingId === selected.id} />
              <button type="button" onClick={() => remove(selected.id)}
                className="mt-1 flex items-center justify-center gap-2 rounded-lg border border-[var(--color-border)] py-2 text-sm font-semibold text-[var(--color-text-secondary)] hover:border-[var(--color-danger)] hover:text-[var(--color-danger)]">
                <Trash2 className="h-4 w-4" /> Supprimer ce bloc
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
// per-type properties panel
// ---------------------------------------------------------------------------

function Properties({ block, lang, patch, patchText, onUpload, uploading }: {
  block: LayoutBlock
  lang: string
  patch: (id: string, changes: Record<string, unknown>) => void
  patchText: (id: string, field: string, value: string) => void
  onUpload: (id: string, file: File | null) => void
  uploading: boolean
}) {
  const set = (changes: Record<string, unknown>) => patch(block.id, changes)
  const setText = (field: string, value: string) => patchText(block.id, field, value)
  const langNote = <p className="text-[10px] text-[var(--color-text-secondary)] opacity-70">Langue : {LANG_LABEL[lang] ?? lang}</p>
  const placement = (
    <Seg label="Placement" hint="côte à côte possible" value={block.col}
      options={[['full', 'Pleine largeur'], ['left', 'Colonne gauche'], ['right', 'Colonne droite']]}
      onChange={(v) => set({ col: v })} />
  )

  if (block.type === 'image') {
    return (
      <>
        <Seg label="Disposition" value={block.variant} options={[['banner', 'Photo simple'], ['background', 'Photo en fond']]} onChange={(v) => set({ variant: v })} />
        <div className="flex flex-col gap-1.5">
          <label className="text-[11px] font-bold uppercase tracking-wide text-[var(--color-text-secondary)]">Photo</label>
          <label className="flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-[var(--color-border)] py-2.5 text-xs font-semibold text-[var(--color-text-secondary)] hover:border-[var(--color-accent)]">
            {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
            {block.image_url ? 'Changer la photo' : 'Téléverser une photo'}
            <input type="file" accept="image/*" className="hidden" onChange={(e) => onUpload(block.id, e.target.files?.[0] ?? null)} />
          </label>
          {!block.image_url && (
            <div className="mt-1 flex flex-wrap gap-2">
              {PRESET_KEYS.map((p) => (
                <button key={p} type="button" onClick={() => set({ preset: p, image_url: '' })} aria-label={p}
                  className={cn('h-7 w-10 rounded-md ring-1 ring-[var(--color-border)]', block.preset === p && 'ring-2 ring-[var(--color-accent)]')}
                  style={{ background: PRESET_BACKGROUNDS[p], backgroundSize: 'cover' }} />
              ))}
            </div>
          )}
        </div>
        <TextField label="Titre sur la photo" value={pick(block.heading, lang)} onChange={(v) => setText('heading', v)} placeholder="(aucun)" />
        <TextField label="Sous-titre" value={pick(block.subheading, lang)} onChange={(v) => setText('subheading', v)} placeholder="(aucun)" />
        {langNote}
        <Seg label="Position du texte" value={block.overlay_pos} options={[['start', 'Haut'], ['center', 'Milieu'], ['end', 'Bas']]} onChange={(v) => set({ overlay_pos: v })} />
        <Seg label="Alignement" value={block.overlay_align} options={ALIGN_OPTIONS} onChange={(v) => set({ overlay_align: v })} />
        <Seg label="Police du titre" value={block.heading_font} options={FONT_OPTIONS} onChange={(v) => set({ heading_font: v })} />
        <Seg label="Taille du titre" value={block.heading_size} options={[['m', 'M'], ['l', 'L'], ['xl', 'XL']]} onChange={(v) => set({ heading_size: v })} />
        <Swatches label="Couleur du texte" value={block.overlay_color} onChange={(v) => set({ overlay_color: v || '#ffffff' })} />
        {placement}
      </>
    )
  }
  if (block.type === 'title') {
    return (
      <>
        <TextArea label="Texte" value={pick(block.text, lang)} onChange={(v) => setText('text', v)} />
        {langNote}
        <Seg label="Police" value={block.font} options={FONT_OPTIONS} onChange={(v) => set({ font: v })} />
        <Seg label="Taille" value={block.size} options={[['s', 'S'], ['m', 'M'], ['l', 'L'], ['xl', 'XL']]} onChange={(v) => set({ size: v })} />
        <Seg label="Alignement" value={block.align} options={ALIGN_OPTIONS} onChange={(v) => set({ align: v })} />
        <Swatches label="Couleur" value={block.color} onChange={(v) => set({ color: v })} allowAuto />
        {placement}
      </>
    )
  }
  if (block.type === 'text') {
    return (
      <>
        <TextArea label="Texte" value={pick(block.text, lang)} onChange={(v) => setText('text', v)} />
        {langNote}
        <Seg label="Police" value={block.font} options={FONT_OPTIONS} onChange={(v) => set({ font: v })} />
        <Seg label="Taille" value={block.size} options={[['s', 'S'], ['m', 'M'], ['l', 'L']]} onChange={(v) => set({ size: v })} />
        <Seg label="Alignement" value={block.align} options={ALIGN_OPTIONS} onChange={(v) => set({ align: v })} />
        <Seg label="Largeur" value={block.width} options={[['narrow', 'Colonne lisible'], ['full', 'Pleine largeur']]} onChange={(v) => set({ width: v })} />
        <Swatches label="Couleur" value={block.color} onChange={(v) => set({ color: v })} allowAuto />
        {placement}
      </>
    )
  }
  if (block.type === 'button') {
    return (
      <>
        <TextField label="Libellé" value={pick(block.label, lang)} onChange={(v) => setText('label', v)} />
        {langNote}
        <TextField label="Lien (https://…, optionnel)" value={block.href} onChange={(v) => set({ href: v })} placeholder="https://" />
        <Swatches label="Fond du bouton" value={block.bg} onChange={(v) => set({ bg: v || '#2563eb' })} />
        <Swatches label="Couleur du texte" value={block.fg} onChange={(v) => set({ fg: v || '#ffffff' })} />
        <Seg label="Coins" value={block.corners} options={[['sharp', 'Nets'], ['soft', 'Doux'], ['round', 'Ronds']]} onChange={(v) => set({ corners: v })} />
        <Seg label="Alignement" value={block.align} options={ALIGN_OPTIONS} onChange={(v) => set({ align: v })} />
        <Toggle label="Pleine largeur" on={block.full} onChange={(v) => set({ full: v })} />
        {placement}
      </>
    )
  }
  if (block.type === 'divider') {
    return (
      <>
        <Swatches label="Couleur" value={block.color} onChange={(v) => set({ color: v })} allowAuto />
        <Seg label="Épaisseur" value={String(block.thickness)} options={[['1', 'Fin'], ['2', 'Moyen'], ['4', 'Épais']]} onChange={(v) => set({ thickness: Number(v) })} />
        {placement}
      </>
    )
  }
  // form
  return (
    <>
      <Swatches label="Couleur d’accent" value={block.accent} onChange={(v) => set({ accent: v || '#2563eb' })} />
      <Seg label="Style des champs" value={block.style} options={[['outline', 'Contour'], ['fill', 'Rempli']]} onChange={(v) => set({ style: v })} />
      <Seg label="Coins" value={block.corners} options={[['sharp', 'Nets'], ['soft', 'Doux'], ['round', 'Ronds']]} onChange={(v) => set({ corners: v })} />
      <TextField label="Bouton d’envoi" value={pick(block.button, lang)} onChange={(v) => setText('button', v)} />
      {langNote}
      <p className="rounded-lg bg-[var(--color-bg-subtle)] p-2.5 text-xs text-[var(--color-text-secondary)]">
        Les questions posées se règlent plus haut, dans « Questions du formulaire ».
      </p>
      {placement}
    </>
  )
}
