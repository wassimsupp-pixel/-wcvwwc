'use client'

import type { RegistrationTheme } from '@/lib/registrationTheme'
import { headerBand } from '@/lib/registrationTheme'

/**
 * The first thing a participant sees on a registration form.
 *
 * Until now that was a logo centred on white, identically for every event.
 * Three treatments now, and the difference between them is what the organizer
 * wants the page to lead with:
 *
 *   `title`   the event's name set large. No photo needed, which is why it is
 *             the default and the fallback — a header that needs an asset
 *             nobody uploaded is a blank band.
 *   `image`   the photo alone, full-bleed. For a venue or a poster that
 *             already carries the name.
 *   `banner`  the name laid over the photo, behind a scrim.
 *
 * Rendered by both the public form and the editor's preview, from the same
 * theme object, so what an organizer approves is what a participant loads.
 */
export function RegistrationHeader({
  theme,
  eventName,
}: {
  theme: RegistrationTheme
  /** Falls back to the event's real name whenever the organizer has not
   *  written a heading of their own — an untitled header should still say
   *  which event this is. */
  eventName: string
}) {
  const { style, image_url: image, subtitle, align } = theme.header
  const title = theme.header.title.trim() || eventName
  const centred = align === 'center'
  const alignment = centred ? 'items-center text-center' : 'items-start text-left'

  if (style === 'image' && image) {
    return (
      // A per-event photo is not a build-time asset next/image can optimise.
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={image}
        alt=""
        className="w-full object-cover"
        style={headerBand(theme)}
      />
    )
  }

  if (style === 'banner' && image) {
    return (
      <div className="relative w-full overflow-hidden" style={headerBand(theme)}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover" />
        {/* A photo is whatever the organizer uploaded, so the text over it
            cannot rely on the photo being dark. The scrim makes the contrast
            a property of the page rather than of the picture. */}
        <div
          className="absolute inset-0"
          style={{ background: 'linear-gradient(to top, rgba(2,6,23,0.82), rgba(2,6,23,0.15))' }}
        />
        <div className={`absolute inset-0 flex flex-col justify-end gap-1 p-6 ${alignment}`}>
          <h1 className="text-2xl font-bold leading-tight text-white drop-shadow-sm sm:text-3xl">
            {title}
          </h1>
          {subtitle && (
            <p className="max-w-[46ch] text-sm text-white/85">{subtitle}</p>
          )}
        </div>
      </div>
    )
  }

  // `title`, and the fallback for a photo treatment with no photo.
  return (
    <div
      className={`flex flex-col justify-center gap-1.5 px-8 py-7 ${alignment}`}
      // Over a background photo the band steps aside: an opaque gradient at
      // the top of the page hides the very photo the organizer set behind it,
      // and the page scrim already guarantees this title reads on the picture.
      style={{
        background: theme.background_image
          ? 'transparent'
          : 'linear-gradient(160deg, var(--color-accent-light), var(--color-surface))',
        borderBottom: theme.background_image ? 'none' : '1px solid var(--color-border)',
      }}
    >
      <h1 className="text-2xl font-bold leading-tight text-[var(--color-text-primary)] sm:text-3xl">
        {title}
      </h1>
      {subtitle && (
        <p className="max-w-[46ch] text-sm text-[var(--color-text-secondary)]">{subtitle}</p>
      )}
    </div>
  )
}
