'use client'

import { useState } from 'react'
import { useTranslations } from 'next-intl'
import { Mail, Send, Loader2, AlertCircle, ChevronDown, ChevronRight } from 'lucide-react'
import { api, type InformationRequestPlan, type InformationRequestDraft } from '@/lib/api'

/**
 * "Request information" — the button the feedback (§14) asks for.
 *
 * The other seven steps of that loop already existed: the exception engine
 * spots the gap, the email agent reads the reply, extracts the value, proposes
 * it, a human validates, the master list updates. This is step one.
 *
 * Two things it deliberately does not do:
 *
 *   * it never sends — it prepares drafts, which go out through the same
 *     review-then-send screen as every other outbound message;
 *   * it never hides who was left out. "40 drafts prepared" with seven people
 *     silently dropped is a worse answer than naming them, and one of the
 *     reasons is that we have no email address at all — which no amount of
 *     emailing will fix.
 */

/** Built per render, not at module scope: a constant cannot read the locale. */
function reasonLabels(t: ReturnType<typeof useTranslations>): Record<string, string> {
  return {
    missing: t('reasonMissing'),
    uninformative: t('skipUninformative'),
  }
}

function skipLabels(t: ReturnType<typeof useTranslations>): Record<string, string> {
  return {
    no_email: t('skipNoEmail'),
    nothing_left_to_ask: t('skipNothingLeft'),
    unknown_participant: t('skipUnknownParticipant'),
  }
}

export function RequestMissingInfo({
  eventId,
  onCreated,
}: {
  eventId: string
  onCreated?: () => void
}) {
  const t = useTranslations('askMissing')
  const [plan, setPlan] = useState<InformationRequestPlan | null>(null)
  const [expanded, setExpanded] = useState<string | null>(null)
  const [deadline, setDeadline] = useState('')
  const [sender, setSender] = useState('')
  const [busy, setBusy] = useState<'' | 'preview' | 'create'>('')
  const [error, setError] = useState('')
  const [done, setDone] = useState('')

  async function preview() {
    setBusy('preview'); setError(''); setDone('')
    try {
      setPlan(await api.informationRequests.preview(eventId, { deadline, sender }))
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errPreview'))
    } finally {
      setBusy('')
    }
  }

  async function create() {
    setBusy('create'); setError('')
    try {
      const res = await api.informationRequests.create(eventId, { deadline, sender })
      setPlan(null)
      setDone(
        t('draftsCreated', { count: res.count })
        + (res.tracked ? '' : ' ' + t('draftsUntracked'))
      )
      onCreated?.()
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errCreate'))
    } finally {
      setBusy('')
    }
  }

  return (
    <div className="rounded-lg border border-[var(--color-border)] bg-white p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 text-sm font-semibold text-[var(--color-text-primary)]">
            <Mail className="h-4 w-4" />
            {t('title')}
          </h2>
          <p className="mt-1 text-xs text-[var(--color-text-secondary)]">
            {t('subtitle1')}{' '}
            {t('subtitle2')}
          </p>
        </div>
        <button
          onClick={preview}
          disabled={busy !== ''}
          className="flex items-center gap-2 rounded-lg border border-[var(--color-border)] px-3 py-2 text-sm text-[var(--color-text-secondary)] disabled:opacity-50"
        >
          {busy === 'preview' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Mail className="h-4 w-4" />}
          {t('prepare')}
        </button>
      </div>

      {(error || done) && (
        <div
          className={
            'mt-3 flex items-start gap-2 rounded-lg px-3 py-2 text-sm ' +
            (error
              ? 'bg-[var(--color-danger-light)] text-[var(--color-danger)]'
              : 'bg-[var(--color-success-light)] text-[var(--color-success)]')
          }
        >
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{error || done}</span>
        </div>
      )}

      {plan && (
        <div className="mt-4 space-y-4 border-t border-[var(--color-border)] pt-4">
          <div className="flex flex-wrap items-end gap-4">
            <label className="flex flex-col gap-1 text-xs text-[var(--color-text-secondary)]">
              {t('deadlineLabel')}
              <input
                type="text" placeholder="12/03/2027"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-36 rounded-md border border-[var(--color-border)] px-2 py-1.5 text-sm"
              />
            </label>
            <label className="flex flex-col gap-1 text-xs text-[var(--color-text-secondary)]">
              {t('signature')}
              <input
                type="text" placeholder={t('senderPlaceholder')}
                value={sender}
                onChange={(e) => setSender(e.target.value)}
                className="w-52 rounded-md border border-[var(--color-border)] px-2 py-1.5 text-sm"
              />
            </label>
            <button
              onClick={preview}
              disabled={busy !== ''}
              className="rounded-md border border-[var(--color-border)] px-3 py-1.5 text-sm disabled:opacity-50"
            >
              {t('recompute')}
            </button>
          </div>

          <div className="flex flex-wrap gap-2 text-xs">
            <Pill>{plan.summary.recipients} destinataire(s)</Pill>
            <Pill>{plan.summary.questions} question(s)</Pill>
            {Object.entries(plan.summary.by_language).map(([lang, n]) => (
              <Pill key={lang}>{n} × {lang.toUpperCase()}</Pill>
            ))}
            {plan.summary.skipped > 0 && (
              <Pill tone="muted">{t('skipped', { count: plan.summary.skipped })}</Pill>
            )}
          </div>

          {plan.drafts.length === 0 ? (
            <p className="text-sm text-[var(--color-text-secondary)]">
              {t('nothingToAsk')}
            </p>
          ) : (
            <ul className="divide-y divide-[var(--color-border)] rounded-lg border border-[var(--color-border)]">
              {plan.drafts.map((draft) => (
                <DraftRow
                  key={draft.participant_id}
                  draft={draft}
                  open={expanded === draft.participant_id}
                  onToggle={() =>
                    setExpanded(expanded === draft.participant_id ? null : draft.participant_id)
                  }
                />
              ))}
            </ul>
          )}

          {plan.skipped.length > 0 && (
            <details className="text-xs text-[var(--color-text-secondary)]">
              <summary className="cursor-pointer">
                {plan.skipped.length} {t('notContacted')}
              </summary>
              <ul className="mt-2 space-y-1">
                {plan.skipped.map((s, i) => (
                  <li key={i}>
                    {s.name || s.participant_id} — {skipLabels(t)[s.reason] || s.reason}
                  </li>
                ))}
              </ul>
            </details>
          )}

          {plan.drafts.length > 0 && (
            <button
              onClick={create}
              disabled={busy !== ''}
              className="flex items-center gap-2 rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
            >
              {busy === 'create' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              {t('createDrafts', { count: plan.drafts.length })}
            </button>
          )}
        </div>
      )}
    </div>
  )
}

function DraftRow({
  draft, open, onToggle,
}: {
  draft: InformationRequestDraft
  open: boolean
  onToggle: () => void
}) {
  const t = useTranslations('askMissing')
  return (
    <li className="px-3 py-2 text-sm">
      <button onClick={onToggle} className="flex w-full items-center gap-2 text-left">
        {open ? <ChevronDown className="h-4 w-4 shrink-0" /> : <ChevronRight className="h-4 w-4 shrink-0" />}
        <span className="font-medium text-[var(--color-text-primary)]">{draft.name}</span>
        <span className="text-xs text-[var(--color-text-secondary)]">{draft.email}</span>
        <span className="ml-auto flex flex-wrap gap-1">
          {draft.fields.map((f) => (
            <span
              key={f.key}
              title={reasonLabels(t)[f.reason] || f.reason}
              className="rounded bg-[var(--color-bg-subtle)] px-1.5 py-0.5 text-[11px] text-[var(--color-text-secondary)]"
            >
              {f.key}
            </span>
          ))}
          <span className="rounded border border-[var(--color-border)] px-1.5 py-0.5 text-[11px] uppercase text-[var(--color-text-secondary)]">
            {draft.language}
          </span>
        </span>
      </button>
      {open && (
        <div className="mt-2 rounded-md bg-[var(--color-bg-subtle)] p-3">
          <p className="mb-2 text-xs font-semibold text-[var(--color-text-primary)]">{draft.subject}</p>
          <pre className="whitespace-pre-wrap font-sans text-xs text-[var(--color-text-secondary)]">
            {draft.body}
          </pre>
        </div>
      )}
    </li>
  )
}

function Pill({ children, tone }: { children: React.ReactNode; tone?: 'muted' }) {
  return (
    <span
      className={
        'rounded-full border px-2.5 py-1 ' +
        (tone === 'muted'
          ? 'border-[var(--color-border)] text-[var(--color-text-secondary)]'
          : 'border-[var(--color-accent)]/30 bg-[var(--color-accent)]/5 text-[var(--color-text-primary)]')
      }
    >
      {children}
    </span>
  )
}
