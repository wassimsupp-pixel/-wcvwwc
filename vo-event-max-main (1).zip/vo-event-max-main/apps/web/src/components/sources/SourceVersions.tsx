'use client'

import { useCallback, useEffect, useState } from 'react'
import { useLocale, useTranslations } from 'next-intl'
import { localeTag } from '@/lib/dates'
import {
  Layers, ArrowRight, Loader2, AlertTriangle, Undo2, BedDouble, Bus,
} from 'lucide-react'
import { api, type SourceFileVersion, type ReplacementImpact } from '@/lib/api'
import { cn } from '@/lib/utils'

/**
 * Add / Update Source vs Replace Source (§20).
 *
 * FCM Week 1, Week 2, Week 3. Every upload has always been an Add/Update, and
 * that is right for a weekly export: Week 2 does not invalidate Week 1, and
 * somebody who only ever appeared in Week 1 still has a real hotel booking.
 *
 * What was missing is the other intention — a corrected version of a file
 * already imported, where keeping both means the master list is fed by a file
 * somebody explicitly withdrew.
 *
 * The panel exists mainly to show the impact BEFORE anything is retired, and
 * within that impact one number matters more than the rest: how many people
 * would be left with no live source. They are never deleted — they are listed,
 * with their room and their transfer next to their name, because that is what
 * makes deleting them obviously the wrong call.
 */
export function SourceVersions({ eventId }: { eventId: string }) {
  const t = useTranslations('sourceVersions')
  const tAct = useTranslations('actions')
  const locale = useLocale()
  const [data, setData] = useState<{ available: boolean; files: SourceFileVersion[] } | null>(null)
  const [pair, setPair] = useState<{ newId: string; oldId: string } | null>(null)
  const [impact, setImpact] = useState<ReplacementImpact | null>(null)
  const [busy, setBusy] = useState<'' | 'impact' | 'replace' | 'restore'>('')
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    try {
      setData(await api.files.versions(eventId))
    } catch {
      setData(null)
    }
  }, [eventId])

  useEffect(() => { load() }, [load])

  async function preview(newId: string, oldId: string) {
    setBusy('impact'); setError(''); setMessage(''); setPair({ newId, oldId })
    try {
      setImpact(await api.files.replacementImpact(newId, oldId))
    } catch (err) {
      setImpact(null)
      setError(err instanceof Error ? err.message : t('errCompare'))
    } finally {
      setBusy('')
    }
  }

  async function confirm() {
    if (!pair) return
    setBusy('replace'); setError('')
    try {
      const res = await api.files.replace(pair.newId, pair.oldId)
      setImpact(null); setPair(null)
      setMessage(
        t('replaced', { rows: res.rows_unlinked, next: res.next_step })
        + (res.orphaned.length ? ' ' + t('replacedOrphans', { count: res.orphaned.length }) : '')
      )
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errReplace'))
    } finally {
      setBusy('')
    }
  }

  async function restore(fileId: string) {
    setBusy('restore'); setError('')
    try {
      const res = await api.files.restore(fileId)
      setMessage(res.next_step)
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errRestore'))
    } finally {
      setBusy('')
    }
  }

  if (!data) return null

  const withCandidates = data.files.filter((f) => f.replaceable.length > 0 && !f.superseded_at)
  const superseded = data.files.filter((f) => f.superseded_at)

  if (!data.available) {
    return (
      <Panel>
        <p className="text-sm text-[var(--color-text-secondary)]">
          {t.rich('migrationNeeded', { b: (chunks) => <strong>{chunks}</strong> })}
        </p>
      </Panel>
    )
  }

  if (withCandidates.length === 0 && superseded.length === 0) {
    return null
  }

  return (
    <Panel>
      <div className="mb-3">
        <h3 className="flex items-center gap-2 text-base font-semibold text-[var(--color-text-primary)]">
          <Layers className="h-4 w-4" />
          {t('title')}
        </h3>
        <p className="mt-1 text-xs text-[var(--color-text-secondary)]">
          {t.rich('hint', { b: (chunks) => <strong>{chunks}</strong> })}
        </p>
      </div>

      {message && <Note tone="ok">{message}</Note>}
      {error && <Note tone="error">{error}</Note>}

      <ul className="space-y-2">
        {withCandidates.map((file) => (
          <li key={file.id} className="rounded-lg border border-[var(--color-border)] p-3">
            <div className="flex flex-wrap items-center gap-2 text-sm">
              <span className="font-medium text-[var(--color-text-primary)]">{file.filename}</span>
              <span className="text-xs text-[var(--color-text-secondary)]">
                {t('rows', { count: file.row_count })} · {new Date(file.imported_at).toLocaleDateString(localeTag(locale))}
              </span>
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <span className="text-xs text-[var(--color-text-secondary)]">{t('wouldReplace')}</span>
              {file.replaceable.map((old) => (
                <button
                  key={old.id}
                  onClick={() => preview(file.id, old.id)}
                  disabled={busy !== ''}
                  className={cn(
                    'flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs transition-colors disabled:opacity-50',
                    pair?.newId === file.id && pair?.oldId === old.id
                      ? 'border-[var(--color-accent)] bg-[var(--color-accent)]/5'
                      : 'border-[var(--color-border)] hover:bg-[var(--color-bg-subtle)]'
                  )}
                >
                  {busy === 'impact' && pair?.oldId === old.id
                    ? <Loader2 className="h-3 w-3 animate-spin" />
                    : <ArrowRight className="h-3 w-3" />}
                  {old.filename}
                </button>
              ))}
            </div>
          </li>
        ))}
      </ul>

      {impact && (
        <div className="mt-4 rounded-lg border border-[var(--color-accent)]/30 bg-[var(--color-accent)]/5 p-4">
          <p className="text-sm font-semibold text-[var(--color-text-primary)]">
            {impact.old_file.filename} → {impact.new_file.filename}
          </p>
          <p className="mt-1 text-xs text-[var(--color-text-secondary)]">
            {impact.summary_line} ({t('unchanged', { count: impact.unchanged })})
          </p>

          {impact.orphaned.length > 0 && (
            <div className="mt-3 rounded-md border border-[var(--color-warning)]/40 bg-white p-3">
              <p className="flex items-center gap-1.5 text-xs font-semibold text-[var(--color-text-primary)]">
                <AlertTriangle className="h-3.5 w-3.5 text-[var(--color-warning)]" />
                {impact.orphaned.length} {t('orphansCount')}
              </p>
              <p className="mt-1 text-xs text-[var(--color-text-secondary)]">
                {t.rich('orphansKept', { strong: (c) => <strong>{c}</strong> })}
                {t('orphansYourCall')}
              </p>
              <ul className="mt-2 space-y-1 text-xs">
                {impact.orphaned.slice(0, 25).map((p) => (
                  <li key={p.participant_id} className="flex items-center gap-2">
                    <span className="text-[var(--color-text-primary)]">{p.name}</span>
                    {p.has_hotel && (
                      <span title={t('hotelBooked')} className="text-[var(--color-text-secondary)]">
                        <BedDouble className="h-3 w-3" />
                      </span>
                    )}
                    {p.has_transfer && (
                      <span title={t('transferAssigned')} className="text-[var(--color-text-secondary)]">
                        <Bus className="h-3 w-3" />
                      </span>
                    )}
                  </li>
                ))}
                {impact.orphaned.length > 25 && (
                  <li className="text-[var(--color-text-secondary)]">
                    … et {impact.orphaned.length - 25} autre(s).
                  </li>
                )}
              </ul>
            </div>
          )}

          {impact.changed.length > 0 && (
            <details className="mt-3 text-xs">
              <summary className="cursor-pointer text-[var(--color-text-secondary)]">
                {impact.changed.length} {t('changedRecords')}
              </summary>
              <ul className="mt-2 space-y-1">
                {impact.changed.slice(0, 30).map((c) => (
                  <li key={c.key}>
                    <span className="text-[var(--color-text-primary)]">{c.name}</span>{' '}
                    <span className="text-[var(--color-text-secondary)]">
                      {c.fields.map((f) => `${f.field}: ${f.old || '—'} → ${f.new || '—'}`).join(' · ')}
                    </span>
                  </li>
                ))}
              </ul>
            </details>
          )}

          <div className="mt-3 flex gap-2">
            <button
              onClick={confirm}
              disabled={busy !== ''}
              className="rounded-md bg-[var(--color-accent)] px-3 py-1.5 text-sm font-semibold text-white disabled:opacity-60"
            >
              {busy === 'replace' ? 'Remplacement…' : 'Remplacer'}
            </button>
            <button
              onClick={() => { setImpact(null); setPair(null) }}
              className="rounded-md border border-[var(--color-border)] bg-white px-3 py-1.5 text-sm"
            >
              {tAct('cancel')}
            </button>
          </div>
        </div>
      )}

      {superseded.length > 0 && (
        <div className="mt-4 border-t border-[var(--color-border)] pt-3">
          <p className="mb-2 text-xs font-semibold text-[var(--color-text-secondary)]">
            {t('replacedFiles')}
          </p>
          <ul className="space-y-1 text-sm">
            {superseded.map((file) => (
              <li key={file.id} className="flex flex-wrap items-center gap-2">
                <span className="text-[var(--color-text-secondary)] line-through">{file.filename}</span>
                <button
                  onClick={() => restore(file.id)}
                  disabled={busy !== ''}
                  className="flex items-center gap-1 text-xs text-[var(--color-text-secondary)] underline-offset-2 hover:underline disabled:opacity-50"
                >
                  <Undo2 className="h-3 w-3" />
                  {t('restore')}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </Panel>
  )
}

function Panel({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-[var(--color-border)] bg-white p-6 shadow-[var(--shadow-card)]">
      {children}
    </div>
  )
}

function Note({ tone, children }: { tone: 'ok' | 'error'; children: React.ReactNode }) {
  return (
    <div
      className={cn(
        'mb-3 rounded-md px-3 py-2 text-sm',
        tone === 'error'
          ? 'bg-[var(--color-danger-light)] text-[var(--color-danger)]'
          : 'bg-[var(--color-success-light)] text-[var(--color-success)]'
      )}
    >
      {children}
    </div>
  )
}
