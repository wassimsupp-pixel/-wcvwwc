import type { Metadata } from 'next'
import './globals.css'

// The description lives in `[locale]/layout.tsx`, which builds it in the
// reader's language; repeating a French one here would only be a French
// fallback nobody can reach.
export const metadata: Metadata = {
  title: 'VO Event Max',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
