'use client'

import React, { useCallback, useEffect, useState } from 'react'
import { useTranslations } from 'next-intl'
import { localeTag } from '@/lib/dates'
import { useParams } from 'next/navigation'
import { AppLayout } from '@/components/layout/AppLayout'
import { TableSkeleton } from '@/components/ui/TableSkeleton'
import { Clock, Search, ArrowRight, HelpCircle, EyeOff } from 'lucide-react'
import { api, type HistoryPage, type HistoryLine } from '@/lib/api'
import { cn } from '@/lib/utils'

const PAGE = 100

/**
 * The change history, in the seven columns §19 asks for.
 *
 * Everything here was already being recorded. What was missing is the one
 * column that turns a log into an answer: where the new value came from.
 * "Phone changed from X to Y" invites the question; "because Tuesday's FCM
 * export said so" ends it.
 *
 * Two things this screen is careful about:
 *
 *   * a reconstructed origin is marked as reconstructed. Rows written before
 *     migration 015 have no stored source, and presenting a guess as a record
 *     would make the whole trail less trustworthy, not more;
 *   * sensitive values are not reprinted. The change is shown, the content is
 *     masked — an audit trail must not become a second copy of the data.
 */
export default function HistoryPage() {
  const tH = useTranslations('history')
  const tAct = useTranslations('actions')
  const { eventId, locale } = useParams() as { eventId: string; locale: string }
  const [data, setData] = useState<HistoryPage | null>(null)
  const [lines, setLines] = useState<HistoryLine[]>([])
  const [source, setSource] = useState('')
  const [search, setSearch] = useState('')
  const [offset, setOffset] = useState(0)
  const [loading, setLoading] = useState(true)

  const load = useCallback(async (nextOffset: number, replace: boolean) => {
    setLoading(true)
    try {
      const res = await api.history.list(eventId, {
        source: source || undefined,
        limit: PAGE,
        offset: nextOffset,
      })
      setData(res)
      setLines((prev) => (replace ? res.lines : [...prev, ...res.lines]))
      setOffset(nextOffset)
    } catch {
      setData(null)
    } finally {
      setLoading(false)
    }
  }, [eventId, source])

  useEffect(() => { load(0, true) }, [load])

  // Filtering on the name/field happens here: the server pages by time, and
  // asking it to also search would either scan the whole log or silently drop
  // pages. A hundred lines is small enough to filter in the browser.
  const visible = search.trim()
    ? lines.filter((line) =>
        [line.participant, line.user, line.field_label, line.old_value, line.new_value]
          .join(' ').toLowerCase().includes(search.trim().toLowerCase()))
    : lines

  const summary = data?.summary

  return (
    <AppLayout eventId={eventId} locale={locale}>
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text-primary)] flex items-center gap-2">
          <Clock className="h-6 w-6 text-[var(--color-accent)]" />
          {tH('title')}
        </h1>
        <p className="mt-1 text-sm text-[var(--color-text-secondary)]">
          {tH('subtitle')}
        </p>
      </div>

      {summary && summary.changes > 0 && (
        <div className="mb-4 flex flex-wrap items-center gap-2 text-xs">
          <span className="rounded-full border border-[var(--color-border)] bg-white px-3 py-1 text-[var(--color-text-secondary)]">
            {summary.changes} modification(s) · {summary.people} personne(s)
          </span>
          {Object.entries(summary.by_source).map(([key, count]) => (
            <button
              key={key}
              onClick={() => setSource(source === key ? '' : key)}
              className={cn(
                'rounded-full border px-3 py-1 transition-colors',
                source === key
                  ? 'border-[var(--color-accent)] bg-[var(--color-accent)] text-white'
                  : 'border-[var(--color-border)] bg-white text-[var(--color-text-secondary)]'
              )}
            >
              {count} × {data?.sources.find((s) => s.key === key)?.label ?? key}
            </button>
          ))}
          {summary.inferred > 0 && (
            <span
              title={tH('inferredTooltip')}
              className="flex items-center gap-1 rounded-full border border-[var(--color-warning)]/40 bg-[var(--color-warning)]/5 px-3 py-1 text-[var(--color-text-secondary)]"
            >
              <HelpCircle className="h-3 w-3" />
              {summary.inferred} {tH('inferredCount')}
            </span>
          )}
        </div>
      )}

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-[var(--color-text-secondary)]" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={tH('filterPlaceholder')}
            className="w-72 rounded-md border border-[var(--color-border)] py-2 pl-9 pr-3 text-sm"
          />
        </div>
        {source && (
          <button
            onClick={() => setSource('')}
            className="rounded-md border border-[var(--color-border)] bg-white px-3 py-2 text-sm text-[var(--color-text-secondary)]"
          >
            {tH('allSources')}
          </button>
        )}
      </div>

      {loading && lines.length === 0 ? (
        <TableSkeleton cols={6} />
      ) : !data?.available ? (
        <Empty>
          {tH('unreadableBefore')}{' '}
          <code className="mx-1">change_log</code> {tH('unreadableAfter')}
        </Empty>
      ) : visible.length === 0 ? (
        <Empty>
          {source ? tH('noChangesForSource') : tH('noChanges')}{' '}
          {tH('historyFillsUp')}
        </Empty>
      ) : (
        <>
          <div className="overflow-x-auto rounded-lg border border-[var(--color-border)] bg-white">
            <table className="w-full min-w-[900px] text-sm">
              <thead className="border-b border-[var(--color-border)] bg-[var(--color-bg-subtle)]">
                <tr>
                  <Th>{tH('colDate')}</Th><Th>{tH('colUser')}</Th><Th>{tH('colParticipant')}</Th>
                  <Th>{tH('colField')}</Th><Th>{tH('colChange')}</Th><Th>{tH('colOrigin')}</Th>
                </tr>
              </thead>
              <tbody>
                {visible.map((line) => (
                  <tr key={line.id} className="border-b border-[var(--color-border)] last:border-0">
                    <Td className="whitespace-nowrap text-xs">{formatDate(line.at, locale)}</Td>
                    <Td>{line.user}</Td>
                    <Td>{line.participant || '—'}</Td>
                    <Td>{line.field_label}</Td>
                    <Td>
                      <span className="flex flex-wrap items-center gap-1.5">
                        <Value text={line.old_value} />
                        <ArrowRight className="h-3 w-3 shrink-0 text-[var(--color-text-secondary)]" />
                        <Value text={line.new_value} strong />
                        {line.masked && (
                          <EyeOff
                            className="h-3 w-3 text-[var(--color-text-secondary)]"
                            aria-label={tH('maskedValue')}
                          />
                        )}
                      </span>
                    </Td>
                    <Td>
                      <span className="flex items-center gap-1.5">
                        <span
                          className={cn(
                            'rounded px-1.5 py-0.5 text-[11px]',
                            line.source_inferred
                              ? 'border border-dashed border-[var(--color-border)] text-[var(--color-text-secondary)]'
                              : 'bg-[var(--color-bg-subtle)] text-[var(--color-text-primary)]'
                          )}
                        >
                          {line.source_label}
                        </span>
                        {line.source_inferred && (
                          <span
                            title={tH('inferredRow')}
                            className="text-[var(--color-text-secondary)]"
                          >
                            <HelpCircle className="h-3 w-3" />
                          </span>
                        )}
                      </span>
                    </Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {data.has_more && (
            <button
              onClick={() => load(offset + PAGE, false)}
              disabled={loading}
              className="mt-4 rounded-lg border border-[var(--color-border)] bg-white px-4 py-2 text-sm disabled:opacity-50"
            >
              {loading ? tAct('loading') : tH('loadMore')}
            </button>
          )}
        </>
      )}
    </AppLayout>
  )
}

function Value({ text, strong }: { text: string; strong?: boolean }) {
  const tH = useTranslations('history')
  if (!text) {
    return <span className="text-xs italic text-[var(--color-text-secondary)]">{tH('empty')}</span>
  }
  return (
    <span
      className={cn(
        'max-w-[18rem] truncate',
        strong ? 'font-medium text-[var(--color-text-primary)]' : 'text-[var(--color-text-secondary)]'
      )}
      title={text}
    >
      {text}
    </span>
  )
}

function formatDate(value: string, locale: string): string {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleString(localeTag(locale), {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  })
}

function Empty({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-[var(--color-border)] bg-white p-6 text-sm text-[var(--color-text-secondary)]">
      {children}
    </div>
  )
}

function Th({ children }: { children: React.ReactNode }) {
  return (
    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[var(--color-text-secondary)]">
      {children}
    </th>
  )
}

function Td({ children, className }: { children: React.ReactNode; className?: string }) {
  return <td className={cn('px-4 py-3 text-[var(--color-text-primary)]', className)}>{children}</td>
}
