'use client'

import React, { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import { useTranslations } from 'next-intl'
import { AppLayout } from '@/components/layout/AppLayout'
import { KPICard } from '@/components/ui/KPICard'
import { TableSkeleton } from '@/components/ui/TableSkeleton'
import { Hotel, Bed, Calendar, Plus, Search, UserX, AlertTriangle, CheckCircle2, Pencil, Check, X } from 'lucide-react'
import { api, type ParticipantLookupItem } from '@/lib/api'
import { formatDateOnly } from '@/lib/dates'
import { ConcernedParticipants, type CohortRow } from '@/components/ui/ConcernedParticipants'
import { OwnExpenseAlert } from '@/components/ui/OwnExpenseAlert'

interface HotelProperty {
  id: string
  name: string
  address?: string
  city?: string
  contact_info?: string
}

interface RoomingNight {
  id: string
  hotel_id: string
  participant_id: string
  night_date: string
  room_type: string
  status: string
  participant_name?: string
  hotel_name?: string
}

interface Stay {
  key: string
  participant_id: string
  hotel_id: string
  participant_name?: string
  hotel_name?: string
  room_type: string
  status: string
  nightIds: string[]
  /** One date per nightId, same order — needed to diff an edited date range
   *  against what is actually booked (which dates to keep, drop, add). */
  nightDates: string[]
  firstNight: string
  lastNight: string
  nights: number
}

export default function HotelsPage() {
  const { eventId, locale } = useParams() as { eventId: string; locale: string }
  const t = useTranslations('hotels')
  const tAct = useTranslations('actions')
  const [hotels, setHotels] = useState<HotelProperty[]>([])
  const [roomingList, setRoomingList] = useState<RoomingNight[]>([])
  const [participants, setParticipants] = useState<ParticipantLookupItem[]>([])
  const [masterRows, setMasterRows] = useState<CohortRow[]>([])
  const [showMissing, setShowMissing] = useState(false)
  const [loading, setLoading] = useState(true)
  
  // Modals / Form states
  const [newHotelName, setNewHotelName] = useState('')
  const [newHotelCity, setNewHotelCity] = useState('')
  const [assignParticipantId, setAssignParticipantId] = useState('')
  const [participantSearch, setParticipantSearch] = useState('')
  const [showParticipantDropdown, setShowParticipantDropdown] = useState(false)
  const [assignHotelId, setAssignHotelId] = useState('')
  const [assignCheckIn, setAssignCheckIn] = useState('2025-11-10')
  const [assignCheckOut, setAssignCheckOut] = useState('2025-11-11')
  const [assignRoomType, setAssignRoomType] = useState('single')
  const [searchTerm, setSearchTerm] = useState('')

  // In-flight guards + user-visible errors: these actions used to fail
  // silently (console.error only) and had no disabled state, so a double
  // click (e.g. on "Confirmer l'attribution" with "Tous les participants
  // en bloc" selected) could fire the same mutation twice concurrently.
  const [addingHotel, setAddingHotel] = useState(false)
  const [assigningRoom, setAssigningRoom] = useState(false)
  const [deletingStayKey, setDeletingStayKey] = useState<string | null>(null)
  const [editingStayKey, setEditingStayKey] = useState<string | null>(null)
  const [savingStay, setSavingStay] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)
  const [actionSuccess, setActionSuccess] = useState<string | null>(null)

  const fetchData = async () => {
    try {
      setLoading(true)
      const [hotelData, roomingData, partList, master] = await Promise.all([
        api.hotels.list(eventId),
        api.hotels.listRooming(eventId),
        api.participants.lookup(eventId),
        api.participants.coverage(eventId).catch(() => ({ items: [] as CohortRow[] })),
      ])
      setHotels(hotelData)
      setRoomingList(roomingData)
      setParticipants(partList)
      setMasterRows((master.items as CohortRow[]) || [])
    } catch (err) {
      console.error('Failed to fetch hotels data', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [eventId])

  const handleAddHotel = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newHotelName || addingHotel) return
    setAddingHotel(true)
    setActionError(null)
    try {
      await api.hotels.create(eventId, {
        name: newHotelName,
        city: newHotelCity,
      })
      setNewHotelName('')
      setNewHotelCity('')
      await fetchData()
    } catch (err) {
      console.error('Failed to add hotel', err)
      setActionError(err instanceof Error ? t('errAddHotelWhy', { why: err.message }) : t('errAddHotel'))
    } finally {
      setAddingHotel(false)
    }
  }

  // A stay is a check-in/check-out RANGE, but the backend still models one
  // row per NIGHT (HotelNightCreate only takes a single night_date) -- so a
  // 3-night stay needs 3 calls. Standard hotel semantics: nights run from
  // check-in (inclusive) to the day before check-out (the guest leaves that
  // morning), so 21/07 -> 23/07 is 2 nights (21/07, 22/07).
  //
  // Dates must be parsed/stepped in UTC ('T00:00:00Z' + setUTCDate), not
  // local time: 'T00:00:00' (no Z) is local midnight, and toISOString()
  // converts back to UTC — in any timezone ahead of UTC (e.g. CEST, UTC+2)
  // that pushes every date back by a day (15/06 saved as 14/06). Found when
  // a stay entered as 15/06->18/06 came back displayed as 14/06-16/06.
  const nightsInRange = (checkIn: string, checkOut: string): string[] => {
    const nights: string[] = []
    const start = new Date(checkIn + 'T00:00:00Z')
    const end = new Date(checkOut + 'T00:00:00Z')
    for (let d = new Date(start); d < end; d.setUTCDate(d.getUTCDate() + 1)) {
      nights.push(d.toISOString().slice(0, 10))
    }
    return nights
  }

  const handleAssignRoom = async (e: React.FormEvent) => {
    e.preventDefault()
    if (assigningRoom) return
    if (!assignParticipantId) {
      setActionError(t('errPickParticipant'))
      return
    }
    if (!assignHotelId || !assignCheckIn || !assignCheckOut) return
    const nights = nightsInRange(assignCheckIn, assignCheckOut)
    if (nights.length === 0) {
      setActionError(t('errCheckoutBeforeCheckin'))
      return
    }
    setAssigningRoom(true)
    setActionError(null)
    setActionSuccess(null)
    try {
      for (const night_date of nights) {
        if (assignParticipantId === 'all') {
          await api.hotels.assignRoomingBulk(eventId, {
            hotel_id: assignHotelId,
            night_date,
            room_type: assignRoomType,
            status: 'confirmed',
          })
        } else {
          await api.hotels.assignRooming(eventId, {
            participant_id: assignParticipantId,
            hotel_id: assignHotelId,
            night_date,
            room_type: assignRoomType,
          })
        }
      }
      const hotelName = hotels.find(h => h.id === assignHotelId)?.name || t('theChosenHotel')
      const who = assignParticipantId === 'all' ? t('everyone') : (participantSearch || t('theChosenParticipant'))
      setActionSuccess(t('nightsAssigned', { count: nights.length, who, hotel: hotelName }))
      await fetchData()
    } catch (err) {
      console.error('Failed to assign rooming night', err)
      setActionError(err instanceof Error ? t('errAssignWhy', { why: err.message }) : t('errAssign'))
    } finally {
      setAssigningRoom(false)
    }
  }

  // Pre-fills the assign form with a participant clicked from the "Sans
  // hébergement" list and scrolls to it, so the user only needs to pick the
  // hotel + dates and confirm.
  const handleQuickAddHotel = (row: CohortRow) => {
    setAssignParticipantId(row.id)
    setParticipantSearch([row.first_name, row.last_name].filter(Boolean).join(' '))
    document.getElementById('assign-night-form')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }


  const filteredRooming = roomingList.filter(r =>
    (r.participant_name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (r.hotel_name || '').toLowerCase().includes(searchTerm.toLowerCase())
  )

  // Group nights per (participant · hotel · room type) into one stay: instead of
  // one row per night, show the client with the date range and the night count
  // (e.g. 21/07/2026 - 22/07/2026 => 2).
  const fmtDate = (iso: string) => formatDateOnly(iso)
  const stays: Stay[] = Object.values(
    filteredRooming.reduce((acc: Record<string, Stay>, r) => {
      const key = `${r.participant_id}|${r.hotel_id}|${r.room_type}`
      const s = acc[key] || (acc[key] = {
        key,
        participant_id: r.participant_id,
        hotel_id: r.hotel_id,
        participant_name: r.participant_name,
        hotel_name: r.hotel_name,
        room_type: r.room_type,
        status: r.status,
        nightIds: [],
        nightDates: [],
        firstNight: r.night_date,
        lastNight: r.night_date,
        nights: 0,
      })
      s.nightIds.push(r.id)
      s.nightDates.push(r.night_date)
      if (r.night_date < s.firstNight) s.firstNight = r.night_date
      if (r.night_date > s.lastNight) s.lastNight = r.night_date
      s.nights += 1
      return acc
    }, {})
  ).sort((a, b) => (a.participant_name || '').localeCompare(b.participant_name || ''))

  const handleDeleteStay = async (stay: Stay) => {
    if (deletingStayKey) return
    setDeletingStayKey(stay.key)
    setActionError(null)
    try {
      await Promise.all(stay.nightIds.map((id) => api.hotels.deleteRooming(id)))
      await fetchData()
    } catch (err) {
      console.error('Failed to delete stay', err)
      setActionError(err instanceof Error ? t('errDeleteStayWhy', { why: err.message }) : t('errDeleteStay'))
    } finally {
      setDeletingStayKey(null)
    }
  }

  // Editing a stay in place, instead of the only path available until now:
  // delete the whole range and refill the assign form from scratch. Hotel,
  // room type and status are patched on every existing night; a changed date
  // RANGE is diffed against what is actually booked — dates dropped from the
  // range are deleted, dates newly in range are created, dates that survive
  // just get the same patch as everything else. This mirrors exactly how a
  // shifted transfer pickup time is "moved": nothing invents a special
  // reassignment primitive, editing the fields IS the change.
  const handleUpdateStay = async (
    stay: Stay,
    draft: { hotelId: string; roomType: string; status: string; checkIn: string; checkOut: string }
  ) => {
    if (savingStay) return
    setSavingStay(true)
    setActionError(null)
    try {
      const newDates = nightsInRange(draft.checkIn, draft.checkOut)
      if (newDates.length === 0) {
        setActionError(t('errCheckoutBeforeCheckin'))
        return
      }
      const oldByDate = new Map(stay.nightDates.map((date, i) => [date, stay.nightIds[i]]))
      const newDateSet = new Set(newDates)
      const patch = { hotel_id: draft.hotelId, room_type: draft.roomType, status: draft.status }

      const toKeep = stay.nightDates.filter((d) => newDateSet.has(d))
      const toDrop = stay.nightDates.filter((d) => !newDateSet.has(d))
      const toAdd = newDates.filter((d) => !oldByDate.has(d))

      await Promise.all([
        ...toKeep.map((d) => api.hotels.updateRoomingNight(oldByDate.get(d)!, patch)),
        ...toDrop.map((d) => api.hotels.deleteRooming(oldByDate.get(d)!)),
        ...toAdd.map((d) =>
          api.hotels.assignRooming(eventId, {
            participant_id: stay.participant_id,
            hotel_id: draft.hotelId,
            night_date: d,
            room_type: draft.roomType,
            status: draft.status,
          })
        ),
      ])
      setEditingStayKey(null)
      setActionSuccess(t('stayUpdated', { name: stay.participant_name || t('thisParticipant') }))
      await fetchData()
    } catch (err) {
      console.error('Failed to update stay', err)
      setActionError(err instanceof Error ? t('errUpdateStayWhy', { why: err.message }) : t('errUpdateStay'))
    } finally {
      setSavingStay(false)
    }
  }

  const withoutHotel = masterRows.filter(r => !r.has_hotel)

  // Clicking a KPI scrolls to the detailed list of concerned participants (§11)
  const scrollToDetailList = () => {
    document.getElementById('detail-list')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <AppLayout eventId={eventId} locale={locale}>
      <div className="flex flex-col gap-6 p-6">
        {/* Header */}
        <div className="flex justify-between items-center border-b pb-5">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text-primary)] flex items-center gap-2">
              <Hotel className="h-6 w-6 text-[var(--color-accent)]" />
              {t('title')}
            </h1>
            <p className="text-sm text-[var(--color-text-secondary)]">
              {t('subtitle')}
            </p>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <KPICard
            label={t('kpiProperties')}
            value={hotels.length}
            icon={<Hotel className="h-5 w-5" />}
            onClick={scrollToDetailList}
          />
          <KPICard
            label={t('kpiNights')}
            value={roomingList.length}
            icon={<Bed className="h-5 w-5" />}
            onClick={scrollToDetailList}
          />
          <KPICard
            label={t('kpiParticipants')}
            value={new Set(roomingList.map(r => r.participant_id)).size}
            icon={<Calendar className="h-5 w-5" />}
            onClick={scrollToDetailList}
          />
          <KPICard
            label={t('kpiWithout')}
            value={withoutHotel.length}
            icon={<UserX className="h-5 w-5" />}
            onClick={() => setShowMissing(v => !v)}
            active={showMissing}
          />
        </div>

        {/* Nights outside the programme. Here above all: this is the page
            where somebody counts what the hotel will invoice. */}
        <OwnExpenseAlert rows={masterRows} locale={locale} eventId={eventId} context="hotels" />

        {/* Concerned participants: those without any hotel night (§11) */}
        {showMissing && (
          <ConcernedParticipants
            rows={withoutHotel}
            title={t('withoutTitle')}
            action={t('withoutAction')}
            emptyText={t('withoutEmpty')}
            locale={locale}
            eventId={eventId}
            quickActionLabel={t('quickAdd')}
            onQuickAction={handleQuickAddHotel}
          />
        )}

        {/* Form area */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Add Hotel Property */}
          <div className="rounded-[var(--radius-card)] border bg-white p-6 shadow-sm">
            <h2 className="text-lg font-bold text-[var(--color-text-primary)] mb-4 flex items-center gap-2">
              <Plus className="h-5 w-5 text-[var(--color-accent)]" />
              {t('addHotelTitle')}
            </h2>
            <form onSubmit={handleAddHotel} className="flex flex-col gap-4">
              <div>
                <label className="block text-sm font-semibold mb-1 text-[var(--color-text-secondary)]">
                  {t('hotelNameLabel')}
                </label>
                <input
                  type="text"
                  placeholder={t('exHotelName')}
                  value={newHotelName}
                  onChange={(e) => setNewHotelName(e.target.value)}
                  className="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-1 text-[var(--color-text-secondary)]">
                  {t('cityLabel')}
                </label>
                <input
                  type="text"
                  placeholder={t('exCity')}
                  value={newHotelCity}
                  onChange={(e) => setNewHotelCity(e.target.value)}
                  className="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                />
              </div>
              <button
                type="submit"
                disabled={addingHotel}
                className="rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[var(--color-accent)]/90 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {addingHotel ? '…' : t('addHotelButton')}
              </button>
            </form>
          </div>

          {/* Assign Night */}
          <div id="assign-night-form" className="rounded-[var(--radius-card)] border bg-white p-6 shadow-sm scroll-mt-24">
            <h2 className="text-lg font-bold text-[var(--color-text-primary)] mb-4 flex items-center gap-2">
              <Plus className="h-5 w-5 text-[var(--color-accent)]" />
              {t('assignNightTitle')}
            </h2>
            <form onSubmit={handleAssignRoom} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="relative md:col-span-2">
                <label className="block text-sm font-semibold mb-1 text-[var(--color-text-secondary)]">
                  {t('participantLabel')}
                </label>
                <input
                  type="text"
                  value={participantSearch}
                  onChange={(e) => {
                    setParticipantSearch(e.target.value)
                    setAssignParticipantId('')
                    setShowParticipantDropdown(true)
                  }}
                  onFocus={() => setShowParticipantDropdown(true)}
                  onBlur={() => setTimeout(() => setShowParticipantDropdown(false), 150)}
                  placeholder={t('participantSearchPlaceholder')}
                  className="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                />
                {showParticipantDropdown && (
                  <div className="absolute z-10 mt-1 max-h-60 w-full overflow-y-auto rounded-lg border bg-white shadow-lg">
                    <button
                      type="button"
                      onMouseDown={() => {
                        setAssignParticipantId('all')
                        setParticipantSearch(t('everyoneInBulk'))
                        setShowParticipantDropdown(false)
                      }}
                      className="block w-full px-3 py-2 text-left text-sm font-semibold hover:bg-slate-50 border-b"
                    >
                      {t('everyoneInBulk')}
                    </button>
                    {(() => {
                      const q = participantSearch.trim().toLowerCase()
                      const matches = participants.filter(p =>
                        `${p.first_name} ${p.last_name}`.toLowerCase().includes(q)
                      ).slice(0, 50)
                      if (matches.length === 0) {
                        return (
                          <div className="px-3 py-2 text-sm text-[var(--color-text-secondary)]">
                            {t('noParticipantFound')}
                          </div>
                        )
                      }
                      return matches.map(p => (
                        <button
                          key={p.id}
                          type="button"
                          onMouseDown={() => {
                            setAssignParticipantId(p.id)
                            setParticipantSearch(`${p.first_name} ${p.last_name}`)
                            setShowParticipantDropdown(false)
                          }}
                          className="block w-full px-3 py-2 text-left text-sm hover:bg-slate-50"
                        >
                          {p.first_name} {p.last_name}
                        </button>
                      ))
                    })()}
                  </div>
                )}
              </div>
              <div>
                <label className="block text-sm font-semibold mb-1 text-[var(--color-text-secondary)]">
                  {t('hotelLabel')}
                </label>
                <select
                  value={assignHotelId}
                  onChange={(e) => setAssignHotelId(e.target.value)}
                  className="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-[var(--color-accent)] bg-white"
                  required
                >
                  <option value="">{t('selectPlaceholder')}</option>
                  {hotels.map(h => (
                    <option key={h.id} value={h.id}>{h.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold mb-1 text-[var(--color-text-secondary)]">
                  {t('checkInLabel')}
                </label>
                <input
                  type="date"
                  value={assignCheckIn}
                  onChange={(e) => setAssignCheckIn(e.target.value)}
                  className="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-1 text-[var(--color-text-secondary)]">
                  {t('checkOutLabel')}
                </label>
                <input
                  type="date"
                  value={assignCheckOut}
                  min={assignCheckIn}
                  onChange={(e) => setAssignCheckOut(e.target.value)}
                  className="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-1 text-[var(--color-text-secondary)]">
                  {t('roomTypeLabel')}
                </label>
                <select
                  value={assignRoomType}
                  onChange={(e) => setAssignRoomType(e.target.value)}
                  className="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-[var(--color-accent)] bg-white"
                >
                  <option value="single">{t('roomTypeSingle')}</option>
                  <option value="double">{t('roomTypeDouble')}</option>
                  <option value="twin">{t('roomTypeTwin')}</option>
                  <option value="suite">{t('roomTypeSuite')}</option>
                </select>
              </div>
              <div className="col-span-1 md:col-span-2">
                <button
                  type="submit"
                  disabled={assigningRoom}
                  className="w-full rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[var(--color-accent)]/90 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  {assigningRoom ? '…' : t('confirmAssignment')}
                </button>
              </div>
            </form>
          </div>
        </div>

        {actionSuccess && (
          <div className="flex items-center gap-2 rounded-lg border border-[var(--color-success)]/30 bg-[var(--color-success-light)] px-4 py-2.5 text-sm text-[var(--color-success)]">
            <CheckCircle2 className="h-4 w-4 shrink-0" />
            <span>{actionSuccess}</span>
            <button onClick={() => setActionSuccess(null)} className="ml-auto text-xs underline opacity-70 hover:opacity-100">{tAct('close')}</button>
          </div>
        )}

        {actionError && (
          <div className="flex items-center gap-2 rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger-light)] px-4 py-2.5 text-sm text-[var(--color-danger)]">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span>{actionError}</span>
          </div>
        )}

        {/* Rooming list table */}
        <div id="detail-list" className="flex items-center gap-2 max-w-md bg-white border rounded-lg px-3 py-2 shadow-sm scroll-mt-24">
          <Search className="h-4 w-4 text-[var(--color-text-secondary)]" />
          <input
            type="text"
            placeholder={t('searchPlaceholder')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-sm outline-none bg-transparent"
          />
        </div>

        <div className="rounded-[var(--radius-card)] border bg-white shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="border-b bg-[var(--color-bg-subtle)] text-[var(--color-text-secondary)] font-medium">
                  <th className="p-4">{t('tableParticipant')}</th>
                  <th className="p-4">{t('tableHotel')}</th>
                  <th className="p-4">{t('tableStay')}</th>
                  <th className="p-4 text-center">{t('tableNights')}</th>
                  <th className="p-4">{t('tableRoomType')}</th>
                  <th className="p-4">{t('tableStatus')}</th>
                  <th className="p-4 text-right">{t('tableActions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y text-[var(--color-text-primary)]">
                {loading ? (
                  <TableSkeleton cols={7} rows={4} />
                ) : stays.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-[var(--color-text-secondary)]">
                      {t('noAssignments')}
                    </td>
                  </tr>
                ) : (
                  stays.map((stay) => (
                    <StayRow
                      key={stay.key}
                      stay={stay}
                      hotels={hotels}
                      t={t}
                      fmtDate={fmtDate}
                      editing={editingStayKey === stay.key}
                      saving={savingStay}
                      deleting={deletingStayKey === stay.key}
                      anyRowBusy={deletingStayKey !== null || editingStayKey !== null}
                      onEdit={() => setEditingStayKey(stay.key)}
                      onCancelEdit={() => setEditingStayKey(null)}
                      onSave={(draft) => handleUpdateStay(stay, draft)}
                      onDelete={() => handleDeleteStay(stay)}
                    />
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}

function roomTypeLabel(t: ReturnType<typeof useTranslations>, value: string): string {
  switch (value) {
    case 'single': return t('roomTypeSingle')
    case 'double': return t('roomTypeDouble')
    case 'twin': return t('roomTypeTwin')
    case 'suite': return t('roomTypeSuite')
    default: return value
  }
}

interface StayDraft {
  hotelId: string
  roomType: string
  status: string
  checkIn: string
  checkOut: string
}

/** One row of the rooming list, editable in place.
 *
 * Until this, the only way to correct a stay — wrong hotel, wrong room type,
 * dates that slipped — was to delete it and refill the assign form from
 * scratch. That loses nothing technically, but it is the same gap the
 * transfers list had: no editing meant every correction started over.
 */
function StayRow({
  stay, hotels, t, fmtDate, editing, saving, deleting, anyRowBusy,
  onEdit, onCancelEdit, onSave, onDelete,
}: {
  stay: Stay
  hotels: HotelProperty[]
  t: ReturnType<typeof useTranslations>
  fmtDate: (iso: string) => string
  editing: boolean
  saving: boolean
  deleting: boolean
  anyRowBusy: boolean
  onEdit: () => void
  onCancelEdit: () => void
  onSave: (draft: StayDraft) => void
  onDelete: () => void
}) {
  const tAct = useTranslations('actions')
  // checkOut is exclusive (the night AFTER the last night booked) so the
  // range round-trips through nightsInRange the same way the assign form
  // computes it: lastNight + 1 day.
  const [draft, setDraft] = useState<StayDraft>(() => ({
    hotelId: stay.hotel_id,
    roomType: stay.room_type,
    status: stay.status,
    checkIn: stay.firstNight,
    checkOut: addDays(stay.lastNight, 1),
  }))

  if (!editing) {
    return (
      <tr className="hover:bg-slate-50 transition-colors">
        <td className="p-4 font-semibold">{stay.participant_name || 'N/A'}</td>
        <td className="p-4">{stay.hotel_name || 'N/A'}</td>
        <td className="p-4 whitespace-nowrap">
          {stay.nights > 1
            ? `${fmtDate(stay.firstNight)} - ${fmtDate(stay.lastNight)}`
            : fmtDate(stay.firstNight)}
        </td>
        <td className="p-4 text-center">
          <span className="inline-flex items-center justify-center min-w-[1.75rem] rounded-full bg-[var(--color-accent-light)] px-2 py-0.5 text-xs font-bold text-[var(--color-accent)]">
            {stay.nights}
          </span>
        </td>
        <td className="p-4">{roomTypeLabel(t, stay.room_type)}</td>
        <td className="p-4">
          <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold ${
            stay.status === 'confirmed'
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              : 'bg-amber-50 text-amber-700 border border-amber-200'
          }`}>
            {stay.status === 'confirmed' ? t('statusConfirmed') : t('statusRequested')}
          </span>
        </td>
        <td className="p-4 text-right">
          <div className="flex items-center justify-end gap-3">
            <button
              onClick={onEdit}
              disabled={anyRowBusy}
              title={tAct('edit')}
              className="text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
            >
              <Pencil className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={onDelete}
              disabled={anyRowBusy}
              className="text-rose-600 hover:text-rose-900 font-semibold text-xs transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {deleting ? '…' : t('deleteButton')}
            </button>
          </div>
        </td>
      </tr>
    )
  }

  return (
    <tr className="bg-[var(--color-bg-subtle)]">
      <td className="p-4 font-semibold align-top">{stay.participant_name || 'N/A'}</td>
      <td className="p-4 align-top">
        <select
          value={draft.hotelId}
          onChange={(e) => setDraft((d) => ({ ...d, hotelId: e.target.value }))}
          className="w-full rounded border border-[var(--color-border)] bg-white px-2 py-1 text-xs"
        >
          {hotels.map((h) => <option key={h.id} value={h.id}>{h.name}</option>)}
        </select>
      </td>
      <td className="p-4 align-top" colSpan={2}>
        <div className="flex items-center gap-1">
          <input
            type="date"
            value={draft.checkIn}
            onChange={(e) => setDraft((d) => ({ ...d, checkIn: e.target.value }))}
            className="w-full rounded border border-[var(--color-border)] px-2 py-1 text-xs"
          />
          <span className="text-[var(--color-text-secondary)]">→</span>
          <input
            type="date"
            value={draft.checkOut}
            min={draft.checkIn}
            onChange={(e) => setDraft((d) => ({ ...d, checkOut: e.target.value }))}
            className="w-full rounded border border-[var(--color-border)] px-2 py-1 text-xs"
          />
        </div>
      </td>
      <td className="p-4 align-top">
        <select
          value={draft.roomType}
          onChange={(e) => setDraft((d) => ({ ...d, roomType: e.target.value }))}
          className="w-full rounded border border-[var(--color-border)] bg-white px-2 py-1 text-xs"
        >
          <option value="single">{t('roomTypeSingle')}</option>
          <option value="double">{t('roomTypeDouble')}</option>
          <option value="twin">{t('roomTypeTwin')}</option>
          <option value="suite">{t('roomTypeSuite')}</option>
        </select>
      </td>
      <td className="p-4 align-top">
        <select
          value={draft.status}
          onChange={(e) => setDraft((d) => ({ ...d, status: e.target.value }))}
          className="w-full rounded border border-[var(--color-border)] bg-white px-2 py-1 text-xs"
        >
          <option value="confirmed">{t('statusConfirmed')}</option>
          <option value="requested">{t('statusRequested')}</option>
        </select>
      </td>
      <td className="p-4 text-right align-top">
        <div className="flex items-center justify-end gap-2">
          <button
            onClick={() => onSave(draft)}
            disabled={saving}
            title={tAct('save')}
            className="rounded p-1 text-[var(--color-accent)] hover:bg-white disabled:opacity-60"
          >
            <Check className="h-4 w-4" />
          </button>
          <button
            onClick={onCancelEdit}
            disabled={saving}
            title={tAct('cancel')}
            className="rounded p-1 text-[var(--color-text-secondary)] hover:bg-white disabled:opacity-60"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </td>
    </tr>
  )
}

/** UTC-stepped, same reasoning as nightsInRange: local-midnight arithmetic
 *  drifts a day in any timezone ahead of UTC. */
function addDays(iso: string, days: number): string {
  const d = new Date(iso + 'T00:00:00Z')
  d.setUTCDate(d.getUTCDate() + days)
  return d.toISOString().slice(0, 10)
}
