'use client'

import React, { useCallback, useEffect, useRef, useState } from 'react'
import { useParams } from 'next/navigation'
import { AppLayout } from '@/components/layout/AppLayout'
import { KPICard } from '@/components/ui/KPICard'
import { TableSkeleton } from '@/components/ui/TableSkeleton'
import {
  BedDouble, Users, AlertTriangle, Hash, Download, Play, RefreshCw,
  Eye, Settings2, History, ArrowRight, Upload, Search, Building2,
} from 'lucide-react'
import {
  api, ApiError,
  type RoomingList, type RoomingPreview, type RoomingChange,
  type RoomingOptions, type RoomingVersion, type RoomingPreset,
  type RoommateGap, type RoomingImportPreview, type RoomingImportLine,
} from '@/lib/api'
import { useTranslations } from 'next-intl'
import { localeTag } from '@/lib/dates'
import { cn } from '@/lib/utils'
import { MissingEventDates } from '@/components/ui/MissingEventDates'

/**
 * The rooming list — a document somebody makes, not a view that appears.
 *
 * The two tabs (§5) still read one payload, so they cannot tell two different
 * stories about who is sharing with whom. What changed is where that payload
 * comes from: it is the last GENERATION, stored and versioned, rather than a
 * derivation recomputed on every page load. A list that renumbers itself
 * between two loads because somebody cancelled on Tuesday cannot be sent to a
 * hotel.
 *
 * So this screen has three states, and the distinction between them is the
 * feature:
 *
 *   nothing generated  — an empty screen ON PURPOSE, with one button
 *   generated & fresh  — the document, with its version and its date
 *   generated & stale  — the document unchanged, plus what has moved since
 *
 * Regenerating is never automatic and never silent: the diff is shown first.
 */
export default function RoomingPage() {
  const t = useTranslations('rooming')
  const { eventId, locale } = useParams() as { eventId: string; locale: string }
  const [data, setData] = useState<RoomingList | null>(null)
  const [preview, setPreview] = useState<RoomingPreview | null>(null)
  const [versions, setVersions] = useState<RoomingVersion[]>([])
  const [view, setView] = useState<'rooms' | 'participants'>('rooms')
  // No starting number here any more: the numbers that matter come back from
  // the hotel's own file, and asking somebody to pick an integer before
  // generating was asking the wrong question. It is still sent — the planner
  // has to number the rooms the hotel has not — it is just no longer a
  // decision anybody is made to take.
  const [options, setOptions] = useState<RoomingOptions>({
    start_number: 101, prefix: '', renumber: false, default_room_type: 'single',
  })
  const [showOptions, setShowOptions] = useState(false)
  // Numbering presets (point 4) — saved once per event so a collaborator
  // stops retyping "start at 301, prefix B-" on every visit to this page.
  const [presets, setPresets] = useState<RoomingPreset[]>([])
  const [newPresetName, setNewPresetName] = useState('')
  const [presetBusy, setPresetBusy] = useState(false)
  const [showVersions, setShowVersions] = useState(false)
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState<'' | 'preview' | 'generate' | 'export' | 'import' | 'apply'>('')
  // The hotel's file, read and matched but not yet written. Held in state
  // rather than applied on upload: a file whose header row is one line off
  // would otherwise move ninety people before anybody saw it.
  const [imported, setImported] = useState<RoomingImportPreview | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const [message, setMessage] = useState('')
  // Shared rooms with nobody on the other side, as returned by a refused
  // generation. Kept apart from the error banner: this is a to-do list, not
  // a failure.
  const [blocked, setBlocked] = useState<RoommateGap[] | null>(null)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    try {
      const res = await api.rooming.list(eventId)
      setData(res)
      // The options panel reopens on what THIS version was generated with,
      // not on the default — otherwise it invites a regeneration that would
      // silently change every room type.
      if (res.default_room_type) {
        setOptions((o) => ({ ...o, default_room_type: res.default_room_type }))
      }
    } catch {
      setData(null)
    } finally {
      setLoading(false)
    }
  }, [eventId])

  useEffect(() => { load() }, [load])

  useEffect(() => {
    let cancelled = false
    api.rooming.getPresets(eventId)
      .then((res) => { if (!cancelled) setPresets(res.presets) })
      .catch(() => { /* no migration 023 yet — the panel just shows none saved */ })
    return () => { cancelled = true }
  }, [eventId])

  async function applyPreset(preset: RoomingPreset) {
    setOptions((o) => ({
      ...o,
      start_number: preset.start_number,
      prefix: preset.prefix,
      default_room_type: preset.room_type ?? 'single',
    }))
  }

  async function savePreset() {
    const name = newPresetName.trim()
    if (!name || presetBusy) return
    setPresetBusy(true)
    setError('')
    try {
      const next = [...presets, {
        id: '', name,
        start_number: options.start_number ?? 101,
        prefix: options.prefix ?? '',
        room_type: options.default_room_type ?? 'single',
      }]
      const res = await api.rooming.setPresets(eventId, next)
      setPresets(res.presets)
      setNewPresetName('')
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errPresetSave'))
    } finally {
      setPresetBusy(false)
    }
  }

  async function deletePreset(id: string) {
    if (presetBusy) return
    setPresetBusy(true)
    setError('')
    try {
      const next = presets.filter((p) => p.id !== id)
      const res = await api.rooming.setPresets(eventId, next)
      setPresets(res.presets)
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errPresetDelete'))
    } finally {
      setPresetBusy(false)
    }
  }

  async function runPreview() {
    setBusy('preview'); setError(''); setMessage('')
    try {
      setPreview(await api.rooming.preview(eventId, options))
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errPreview'))
    } finally {
      setBusy('')
    }
  }

  async function generate(force = false) {
    setBusy('generate'); setError(''); setMessage(''); setBlocked(null)
    try {
      const res = await api.rooming.generate(eventId, { ...options, force })
      setPreview(null)
      setMessage(
        t('generatedMessage', {
          version: res.version, rooms: res.summary.rooms,
          numbers: res.numbers_written, summary: res.summary_line,
        })
      )
      await load()
      if (showVersions) await loadVersions()
    } catch (err) {
      // A refusal that names the unpaired people is not an error message, it
      // is a to-do list — so it gets its own panel rather than the red banner.
      const gaps = err instanceof ApiError && err.detail?.code === 'roommate_gaps'
        ? (err.detail.gaps as RoommateGap[])
        : null
      if (gaps) setBlocked(gaps)
      else setError(err instanceof Error ? err.message : t('errGenerate'))
    } finally {
      setBusy('')
    }
  }

  /** Read the hotel's file. Writes nothing — this is the looking step. */
  async function readHotelFile(file: File) {
    setBusy('import'); setError(''); setMessage(''); setImported(null)
    try {
      setImported(await api.rooming.importPreview(eventId, file))
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errImport'))
    } finally {
      setBusy('')
      // Cleared so re-picking the same file fires onChange again: somebody who
      // fixed a column header and re-exported wants to retry the same name.
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  /** Write the matched lines. Only 'matched' — the rest are reported, and a
   *  status somebody has not resolved is not a number to put on a door. */
  async function applyHotelFile() {
    if (!imported) return
    const lines = imported.lines
      .filter((l) => l.status === 'matched')
      .map((l) => ({
        participant_id: l.participant_id,
        room_number: l.room_number,
        room_type: l.room_type,
      }))
    if (lines.length === 0) return
    setBusy('apply'); setError(''); setMessage('')
    try {
      const res = await api.rooming.importApply(eventId, lines)
      setImported(null)
      setMessage(
        res.failed > 0
          ? t('importDoneFailed', { updated: res.updated, failed: res.failed })
          : t('importDone', { updated: res.updated, skipped: res.skipped })
      )
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errImport'))
    } finally {
      setBusy('')
    }
  }

  const loadVersions = useCallback(async () => {
    try {
      setVersions((await api.rooming.versions(eventId)).versions)
    } catch {
      setVersions([])
    }
  }, [eventId])

  async function toggleVersions() {
    const next = !showVersions
    setShowVersions(next)
    if (next) await loadVersions()
  }

  async function exportForHotel() {
    setBusy('export'); setError(''); setMessage('')
    try {
      await api.supplierExports.create(eventId, 'hotel')
      setMessage(t('exportDone'))
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errExport'))
    } finally {
      setBusy('')
    }
  }

  const summary = data?.summary
  const conflicts = data?.rooms.filter((r) => r.conflict) ?? []
  const canGenerate = Boolean(data?.available && data?.storage_available)
  const generated = Boolean(data?.generated)

  return (
    <AppLayout eventId={eventId} locale={locale}>
      <MissingEventDates eventId={eventId} locale={locale} />
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text-primary)] flex items-center gap-2">
            <BedDouble className="h-6 w-6 text-[var(--color-accent)]" />
            {t('title')}
          </h1>
          <p className="mt-1 text-sm text-[var(--color-text-secondary)]">
            {generated
              ? t('subtitleGenerated', { version: data?.version ?? '', date: formatDate(data?.generated_at, locale) })
              : t('subtitleDraft')}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setShowOptions((v) => !v)}
            disabled={!canGenerate}
            className="flex items-center gap-2 rounded-lg border border-[var(--color-border)] bg-white px-3 py-2 text-sm text-[var(--color-text-secondary)] disabled:opacity-50"
          >
            <Settings2 className="h-4 w-4" />
            {t('options')}
          </button>
          <button
            onClick={runPreview}
            disabled={!canGenerate || busy !== ''}
            className="flex items-center gap-2 rounded-lg border border-[var(--color-border)] bg-white px-3 py-2 text-sm text-[var(--color-text-secondary)] disabled:opacity-50"
          >
            <Eye className="h-4 w-4" />
            {busy === 'preview' ? t('computing') : t('previewAction')}
          </button>
          <button
            onClick={() => generate()}
            disabled={!canGenerate || busy !== ''}
            className="flex items-center gap-2 rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
          >
            {generated ? <RefreshCw className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            {busy === 'generate'
              ? t('generating')
              : generated ? t('regenerate') : t('generate')}
          </button>
          <button
            onClick={exportForHotel}
            disabled={busy !== '' || !generated}
            title={generated ? '' : t('generateFirst')}
            className="flex items-center gap-2 rounded-lg border border-[var(--color-border)] bg-white px-3 py-2 text-sm text-[var(--color-text-secondary)] disabled:opacity-50"
          >
            <Download className="h-4 w-4" />
            {busy === 'export' ? t('generating') : t('exportHotel')}
          </button>
          {/* The other direction: their file, with their numbers, coming back
              in. Enabled whether or not we have generated — a hotel that
              allocated the rooms itself never waited for our list. */}
          <button
            onClick={() => fileRef.current?.click()}
            disabled={busy !== '' || !data?.available}
            className="flex items-center gap-2 rounded-lg border border-[var(--color-border)] bg-white px-3 py-2 text-sm text-[var(--color-text-secondary)] disabled:opacity-50"
          >
            <Upload className="h-4 w-4" />
            {busy === 'import' ? t('importReading') : t('importHotel')}
          </button>
          <input
            ref={fileRef}
            type="file"
            accept=".xlsx,.xls,.csv"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0]
              if (file) readHotelFile(file)
            }}
          />
        </div>
      </div>

      {showOptions && canGenerate && (
        <div className="mb-4 rounded-lg border border-[var(--color-border)] bg-white p-4">
          {/* Presets (point 4): saved once per event so nobody retypes the
              same numbers on every visit. Managed here, by whoever is using
              the page — not a fixed list, not admin-only. */}
          {presets.length === 0 && (
            <p className="mb-3 text-xs text-[var(--color-text-secondary)]">
              {t('noPreset')}
            </p>
          )}
          {presets.length > 0 && (
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <span className="text-xs font-medium text-[var(--color-text-secondary)]">{t('presetsLabel')}</span>
              {presets.map((p) => (
                <span
                  key={p.id}
                  className="flex items-center gap-1 rounded-full border border-[var(--color-border)] bg-[var(--color-bg-subtle)] py-1 pl-3 pr-1 text-xs"
                >
                  <button
                    type="button"
                    onClick={() => applyPreset(p)}
                    className="font-medium text-[var(--color-text-primary)] hover:text-[var(--color-accent)]"
                    title={t('applyPresetTitle', { label: presetLabel(t, p.room_type, p.prefix) })}
                  >
                    {p.name}
                  </button>
                  <button
                    type="button"
                    onClick={() => deletePreset(p.id)}
                    disabled={presetBusy}
                    title={t('deletePreset')}
                    className="rounded-full px-1 text-[var(--color-text-secondary)] hover:bg-white hover:text-[var(--color-danger)] disabled:opacity-50"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          )}
          <div className="mb-3 flex flex-wrap items-end gap-4">
            {/* The one option here with an invoice attached: ninety singles
                and ninety doubles are not the same hotel bill. */}
            <Field label={t('defaultRoomType')}>
              <select
                value={options.default_room_type ?? 'single'}
                onChange={(e) => setOptions((o) => ({
                  ...o, default_room_type: e.target.value as 'single' | 'double',
                }))}
                className="w-36 rounded-md border border-[var(--color-border)] bg-white px-2 py-1.5 text-sm"
              >
                <option value="single">{t('roomTypeSingle')}</option>
                <option value="double">{t('roomTypeDouble')}</option>
              </select>
            </Field>
            <Field label={t('prefix')}>
              <input
                type="text" maxLength={8} placeholder="ex. A-"
                value={options.prefix ?? ''}
                onChange={(e) => setOptions((o) => ({ ...o, prefix: e.target.value }))}
                className="w-28 rounded-md border border-[var(--color-border)] px-2 py-1.5 text-sm"
              />
            </Field>
            <label className="flex items-center gap-2 pb-1.5 text-sm text-[var(--color-text-primary)]">
              <input
                type="checkbox"
                checked={options.renumber ?? false}
                onChange={(e) => setOptions((o) => ({ ...o, renumber: e.target.checked }))}
              />
              {t('renumberAll')}
            </label>
          </div>
          <div className="flex items-center gap-2 border-t border-[var(--color-border)] pt-3">
            <input
              type="text" maxLength={60}
              placeholder={t('presetNamePlaceholder')}
              value={newPresetName}
              onChange={(e) => setNewPresetName(e.target.value)}
              className="w-64 rounded-md border border-[var(--color-border)] px-2 py-1.5 text-sm"
            />
            <button
              type="button"
              onClick={savePreset}
              disabled={!newPresetName.trim() || presetBusy}
              className="rounded-md border border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-3 py-1.5 text-xs font-medium text-[var(--color-text-primary)] disabled:opacity-50"
            >
              {t('savePresetAs', {
                label: presetLabel(t, options.default_room_type ?? 'single', options.prefix),
              })}
            </button>
          </div>
          <p className="mt-3 text-xs text-[var(--color-text-secondary)]">
            {t('defaultRoomTypeHint')}
          </p>
          <p className="mt-1 text-xs text-[var(--color-text-secondary)]">
            {t('renumberHint')}
          </p>
        </div>
      )}

      {/* Same gaps, before anybody presses Generate — a warning that only
          appears after a refusal arrives one click too late. */}
      {!blocked && (data?.roommate_gaps?.length ?? 0) > 0 && (
        <div className="mb-6 flex flex-wrap items-center gap-2 rounded-lg border border-[var(--color-warning)]/40 bg-[var(--color-warning)]/5 px-4 py-2.5 text-xs">
          <AlertTriangle className="h-4 w-4 shrink-0 text-[var(--color-warning)]" />
          <span className="text-[var(--color-text-primary)]">
            {t.rich('gapsWarning', {
              count: data!.roommate_gaps!.length,
              strong: (chunks) => <strong>{chunks}</strong>,
            })}
          </span>
          <button
            onClick={() => setBlocked(data!.roommate_gaps!)}
            className="ml-auto rounded border border-[var(--color-border)] bg-white px-2 py-1 font-medium text-[var(--color-text-primary)]"
          >
            {t('seeWhich')}
          </button>
        </div>
      )}

      {/* Shared rooms with nobody confirmed on the other side (§4). Named,
          because "go fix these four" is actionable and "something is wrong"
          is not. Generating anyway stays possible, deliberately. */}
      {blocked && blocked.length > 0 && (
        <div className="mb-6 rounded-lg border border-[var(--color-warning)]/50 bg-[var(--color-warning)]/5 p-4">
          <p className="flex items-center gap-2 text-sm font-semibold text-[var(--color-text-primary)]">
            <AlertTriangle className="h-4 w-4 text-[var(--color-warning)]" />
            {t('gapsTitle', { count: blocked.length })}
          </p>
          <p className="mt-1 text-xs text-[var(--color-text-secondary)]">
            {t('gapsBody')}
          </p>
          <ul className="mt-3 space-y-1">
            {blocked.slice(0, 12).map((g) => (
              <li key={g.participant_id} className="flex flex-wrap items-baseline gap-x-2 text-xs">
                <span className="font-medium text-[var(--color-text-primary)]">{g.name}</span>
                {g.room_type && (
                  <span className="rounded bg-white px-1.5 py-0.5 text-[10px] text-[var(--color-text-secondary)]">
                    {g.room_type}
                  </span>
                )}
                <span className="text-[var(--color-text-secondary)]">{g.label}</span>
                {g.written_name && (
                  <span className="text-[var(--color-text-secondary)]">« {g.written_name} »</span>
                )}
              </li>
            ))}
            {blocked.length > 12 && (
              <li className="text-xs text-[var(--color-text-secondary)]">
                {t('andMore', { count: blocked.length - 12 })}
              </li>
            )}
          </ul>
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              onClick={() => generate(true)}
              disabled={busy !== ''}
              className="rounded-lg border border-[var(--color-border)] bg-white px-3 py-1.5 text-xs font-medium text-[var(--color-text-primary)] disabled:opacity-50"
            >
              {t('generateAnyway')}
            </button>
            <button
              onClick={() => setBlocked(null)}
              className="rounded-lg px-3 py-1.5 text-xs text-[var(--color-text-secondary)]"
            >
              {t('close')}
            </button>
          </div>
        </div>
      )}

      {message && <Banner tone="ok">{message}</Banner>}
      {error && <Banner tone="error">{error}</Banner>}

      {imported && (
        <ImportPanel
          preview={imported}
          busy={busy === 'apply'}
          onApply={applyHotelFile}
          onCancel={() => setImported(null)}
        />
      )}

      {preview && (
        <div className="mb-6 rounded-lg border border-[var(--color-accent)]/30 bg-[var(--color-accent)]/5 p-4">
          <p className="mb-1 flex items-center gap-2 text-sm font-semibold text-[var(--color-text-primary)]">
            <Eye className="h-4 w-4" />
            {t('previewSummary', { rooms: preview.summary.rooms, participants: preview.summary.participants })}
          </p>
          <p className="mb-3 text-xs text-[var(--color-text-secondary)]">
            {preview.current_version > 0
              ? t('previewDiff', { version: preview.current_version, summary: preview.summary_line })
              : t('previewFirst')}
          </p>
          <ChangeList changes={preview.changes} />
          <div className="mt-3 flex gap-2">
            <button
              onClick={() => generate()}
              disabled={busy !== ''}
              className="rounded-md bg-[var(--color-accent)] px-3 py-1.5 text-sm font-semibold text-white disabled:opacity-60"
            >
              {t('confirmGenerate')}
            </button>
            <button
              onClick={() => setPreview(null)}
              className="rounded-md border border-[var(--color-border)] bg-white px-3 py-1.5 text-sm"
            >
              {t('cancel')}
            </button>
          </div>
        </div>
      )}

      {loading ? (
        <TableSkeleton cols={7} />
      ) : !data?.available ? (
        <Empty>
          {t('needsMigration012')}
        </Empty>
      ) : !data.storage_available ? (
        <>
          <Empty>
            {t.rich('needsMigration013', { strong: (c) => <strong>{c}</strong> })}
          </Empty>
          <RoomTables data={data} view={view} setView={setView} />
        </>
      ) : !data.generated ? (
        <Empty>
          {t.rich('emptyState', {
            strong: (c) => <strong>{c}</strong>,
            em: (c) => <em>{c}</em>,
          })}
        </Empty>
      ) : (
        <>
          {data.stale && (
            <div className="mb-6 rounded-lg border border-[var(--color-warning)]/40 bg-[var(--color-warning)]/5 p-4">
              <p className="mb-1 flex items-center gap-2 text-sm font-semibold text-[var(--color-text-primary)]">
                <AlertTriangle className="h-4 w-4 text-[var(--color-warning)]" />
                {t('staleSince', { version: data.version })}
              </p>
              <p className="mb-3 text-xs text-[var(--color-text-secondary)]">
                {t('staleBody')}
              </p>
              <ChangeList changes={data.changes} />
            </div>
          )}

          <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
            <KPICard label={t('kpiRooms')} value={summary?.rooms ?? 0} icon={<BedDouble className="h-5 w-5" />} />
            <KPICard label={t('kpiHoused')} value={summary?.participants ?? 0} icon={<Users className="h-5 w-5" />} />
            <KPICard label={t('kpiHotelNumbers')} value={summary?.hotel_numbers ?? 0} icon={<Hash className="h-5 w-5" />} />
            <KPICard label={t('kpiToDecide')} value={summary?.conflicts ?? 0} icon={<AlertTriangle className="h-5 w-5" />} />
          </div>

          {conflicts.length > 0 && (
            <div className="mb-6 rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger)]/5 p-4">
              <p className="mb-2 flex items-center gap-2 text-sm font-semibold text-[var(--color-danger)]">
                <AlertTriangle className="h-4 w-4" />
                {t('conflictTitle', { count: conflicts.length })}
              </p>
              <p className="mb-3 text-xs text-[var(--color-text-secondary)]">
                {t('conflictBody')}
              </p>
              <ul className="space-y-1 text-sm">
                {conflicts.map((room, i) => (
                  <li key={i} className="text-[var(--color-text-primary)]">
                    {room.occupants.map((o) => o.name).join(' + ')} —{' '}
                    <span className="font-mono">{room.room_numbers?.join(' / ')}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="mb-6 flex flex-wrap items-center gap-2">
            {summary && Object.entries(summary.by_type).map(([type, count]) => (
              <span
                key={type}
                className="inline-flex items-center gap-1.5 rounded-full border border-[var(--color-border)] bg-white px-3 py-1 text-xs text-[var(--color-text-secondary)]"
              >
                <BedDouble className="h-3.5 w-3.5" />
                <strong className="font-semibold text-[var(--color-text-primary)]">{count}</strong>
                {roomTypeLabel(t, type)}
              </span>
            ))}
            <button
              onClick={toggleVersions}
              className="ml-auto flex items-center gap-1.5 text-xs text-[var(--color-text-secondary)] underline-offset-2 hover:underline"
            >
              <History className="h-3.5 w-3.5" />
              {showVersions ? 'Masquer' : 'Voir'} {t('versionHistory')}
            </button>
          </div>

          {showVersions && (
            <div className="mb-6 rounded-lg border border-[var(--color-border)] bg-white p-4">
              <ul className="space-y-2 text-sm">
                {versions.map((v) => (
                  <li key={v.id} className="flex flex-wrap items-baseline gap-2">
                    <span className="font-semibold text-[var(--color-text-primary)]">v{v.version}</span>
                    <span className="text-[var(--color-text-secondary)]">{formatDate(v.generated_at, locale)}</span>
                    <span className="text-[var(--color-text-secondary)]">
                      {t('versionRooms', { count: v.summary?.rooms ?? 0 })}
                    </span>
                    {v.note && <span className="italic text-[var(--color-text-secondary)]">{v.note}</span>}
                  </li>
                ))}
                {versions.length === 0 && (
                  <li className="text-[var(--color-text-secondary)]">{t('noVersion')}</li>
                )}
              </ul>
            </div>
          )}

          <RoomTables data={data} view={view} setView={setView} />
        </>
      )}
    </AppLayout>
  )
}

/** What the hotel calls a room, in the reader's language.
 *
 *  The API stores the vocabulary the files use — "single", "twin", "dbl" — and
 *  printing that verbatim put English on a French screen for eighty-one rows.
 *  A word we do not recognise is shown as it came rather than dropped: "Deluxe
 *  King" means something to the hotel. */
function roomTypeLabel(t: ReturnType<typeof useTranslations>, raw: string | undefined): string {
  const key = String(raw || '').trim().toLowerCase()
  if (!key) return '—'
  if (key === 'single') return t('roomTypeSingle')
  if (key === 'double') return t('roomTypeDouble')
  if (key === 'twin') return t('roomTypeTwin')
  if (key === 'triple') return t('roomTypeTriple')
  if (key === 'suite') return t('roomTypeSuite')
  return raw as string
}

/** A date a person reads, not one a database stores. */
function shortDate(value: string | undefined): string {
  if (!value) return '—'
  const [y, m, d] = String(value).split('-')
  return y && m && d ? `${d}/${m}` : String(value)
}

/** Two letters for a face. Enough to scan a column of eighty-one rooms and
 *  see at a glance which ones hold two people. */
function initials(name: string): string {
  const parts = String(name || '').trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '?'
  const first = parts[0][0] ?? ''
  const last = parts.length > 1 ? parts[parts.length - 1][0] ?? '' : ''
  return (first + last).toUpperCase()
}

function Occupant({ name }: { name: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--color-bg-subtle)] py-0.5 pl-0.5 pr-2.5 text-xs">
      <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[var(--color-accent)] text-[9px] font-semibold text-white">
        {initials(name)}
      </span>
      <span className="text-[var(--color-text-primary)]">{name}</span>
    </span>
  )
}

/** The room number, as the thing the whole document is organised around. */
function RoomNumber({ value, origin, t }: {
  value: string
  origin?: 'hotel' | 'generated'
  t: ReturnType<typeof useTranslations>
}) {
  if (!value) return <span className="text-[var(--color-text-secondary)]">—</span>
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="rounded-md border border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-2 py-0.5 font-mono text-[13px] font-semibold text-[var(--color-text-primary)]">
        {value}
      </span>
      {origin === 'hotel' && (
        <span
          title={t('hotelProvidedNumber')}
          className="rounded bg-[var(--color-accent)]/10 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-[var(--color-accent)]"
        >
          {t('hotelTag')}
        </span>
      )}
    </span>
  )
}

function RoomTables({
  data, view, setView,
}: {
  data: RoomingList
  view: 'rooms' | 'participants'
  setView: (v: 'rooms' | 'participants') => void
}) {
  const t = useTranslations('rooming')
  // Eighty-one rooms is past the point where scrolling is a way to find
  // somebody. One box over both views, because "where is Tina" is the same
  // question whichever way the list happens to be turned.
  const [query, setQuery] = useState('')
  const needle = query.trim().toLowerCase()
  const hit = (...fields: (string | undefined)[]) =>
    !needle || fields.some((f) => String(f || '').toLowerCase().includes(needle))

  const rooms = data.rooms.filter((r) =>
    hit(r.room_number, r.hotel_name, ...r.occupants.map((o) => o.name))
  )
  const lines = data.participants.filter((p) =>
    hit(p.name, p.room_number, p.roommate, p.hotel_name)
  )
  const shown = view === 'rooms' ? rooms.length : lines.length
  const total = view === 'rooms' ? data.rooms.length : data.participants.length

  return (
    <>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="inline-flex rounded-lg border border-[var(--color-border)] bg-white p-1">
          {(['rooms', 'participants'] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => setView(mode)}
              className={cn(
                'rounded-md px-4 py-1.5 text-sm font-medium transition-colors',
                view === mode
                  ? 'bg-[var(--color-accent)] text-white'
                  : 'text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]'
              )}
            >
              {mode === 'rooms' ? t('viewRooms') : t('viewParticipants')}
            </button>
          ))}
        </div>

        <div className="relative min-w-[240px] flex-1 sm:max-w-xs">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--color-text-secondary)]" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('searchPlaceholder')}
            className="w-full rounded-lg border border-[var(--color-border)] bg-white py-2 pl-9 pr-3 text-sm"
          />
        </div>

        {needle && (
          <span className="text-xs text-[var(--color-text-secondary)]">
            {t('searchCount', { shown, total })}
          </span>
        )}
      </div>

      <div className="overflow-x-auto rounded-lg border border-[var(--color-border)] bg-white">
        {view === 'rooms' ? (
          <table className="w-full min-w-[760px] text-sm">
            <thead className="sticky top-0 z-10 border-b border-[var(--color-border)] bg-[var(--color-bg-subtle)]">
              <tr>
                <Th>{t('thRoom')}</Th><Th>{t('thType')}</Th><Th>{t('thOccupants')}</Th>
                <Th>{t('thHotel')}</Th><Th>{t('arrival')}</Th><Th>{t('departure')}</Th><Th>{t('thNights')}</Th>
              </tr>
            </thead>
            <tbody>
              {rooms.map((room, i) => (
                <tr
                  key={i}
                  className={cn(
                    'border-b border-[var(--color-border)] last:border-0 hover:bg-[var(--color-bg-subtle)]/60',
                    room.conflict && 'bg-[var(--color-danger)]/5'
                  )}
                >
                  <Td><RoomNumber value={room.room_number} origin={room.origin} t={t} /></Td>
                  <Td className="text-[var(--color-text-secondary)]">{roomTypeLabel(t, room.room_type)}</Td>
                  <Td>
                    <span className="flex flex-wrap gap-1.5">
                      {room.occupants.map((o) => <Occupant key={o.participant_id} name={o.name} />)}
                    </span>
                  </Td>
                  <Td className="text-[var(--color-text-secondary)]">
                    {room.hotel_name ? (
                      <span className="inline-flex items-center gap-1.5">
                        <Building2 className="h-3.5 w-3.5 shrink-0" />
                        {room.hotel_name}
                      </span>
                    ) : '—'}
                  </Td>
                  <Td className="whitespace-nowrap">{shortDate(room.check_in)}</Td>
                  <Td className="whitespace-nowrap">{shortDate(room.check_out)}</Td>
                  <Td className="tabular-nums">{room.nights || '—'}</Td>
                </tr>
              ))}
              {rooms.length === 0 && <EmptyRow cols={7} label={t('noMatch')} />}
            </tbody>
          </table>
        ) : (
          <table className="w-full min-w-[760px] text-sm">
            <thead className="sticky top-0 z-10 border-b border-[var(--color-border)] bg-[var(--color-bg-subtle)]">
              <tr>
                <Th>{t('thParticipant')}</Th><Th>{t('thRoom')}</Th><Th>{t('thType')}</Th>
                <Th>{t('thSharesWith')}</Th><Th>{t('arrival')}</Th><Th>{t('departure')}</Th><Th>{t('thNights')}</Th>
              </tr>
            </thead>
            <tbody>
              {lines.map((line) => (
                <tr
                  key={line.participant_id}
                  className="border-b border-[var(--color-border)] last:border-0 hover:bg-[var(--color-bg-subtle)]/60"
                >
                  <Td><Occupant name={line.name} /></Td>
                  <Td><RoomNumber value={line.room_number} t={t} /></Td>
                  <Td className="text-[var(--color-text-secondary)]">{roomTypeLabel(t, line.room_type)}</Td>
                  <Td className="text-[var(--color-text-secondary)]">{line.roommate || '—'}</Td>
                  <Td className="whitespace-nowrap">{shortDate(line.check_in)}</Td>
                  <Td className="whitespace-nowrap">{shortDate(line.check_out)}</Td>
                  <Td className="tabular-nums">{line.nights || '—'}</Td>
                </tr>
              ))}
              {lines.length === 0 && <EmptyRow cols={7} label={t('noMatch')} />}
            </tbody>
          </table>
        )}
      </div>
    </>
  )
}

function EmptyRow({ cols, label }: { cols: number; label: string }) {
  return (
    <tr>
      <td colSpan={cols} className="px-4 py-10 text-center text-sm text-[var(--color-text-secondary)]">
        {label}
      </td>
    </tr>
  )
}

/** What a preset is, in one phrase: "Double / B-". Built per render — a
 *  module constant cannot call a hook. */
function presetLabel(
  t: ReturnType<typeof useTranslations>,
  roomType: string | undefined,
  prefix: string | undefined,
): string {
  const type = roomType === 'double' ? t('roomTypeDouble') : t('roomTypeSingle')
  return prefix ? `${type} / ${prefix}` : type
}

/** The hotel's file, matched and not yet written.
 *
 *  Every line is shown with its status, including the ones that will not be
 *  written. Four names the file could not match are four people who cancelled
 *  or four people whose name is spelled differently, and both are worth seeing
 *  — a success message reading "86 chambres écrites" hides them equally well.
 */
function ImportPanel({
  preview, busy, onApply, onCancel,
}: {
  preview: RoomingImportPreview
  busy: boolean
  onApply: () => void
  onCancel: () => void
}) {
  const t = useTranslations('rooming')
  const writable = preview.lines.filter((l) => l.status === 'matched')
  // Longest first: the lines somebody has to do something about are the ones
  // worth putting at the top, not the eighty that are already correct.
  const order: RoomingImportLine['status'][] = [
    'matched', 'ambiguous', 'duplicate', 'unknown', 'invalid', 'unchanged',
  ]
  const shown = [...preview.lines]
    .sort((a, b) => order.indexOf(a.status) - order.indexOf(b.status) || a.row - b.row)
    .slice(0, 200)

  return (
    <div className="mb-6 rounded-lg border border-[var(--color-accent)]/30 bg-[var(--color-accent)]/5 p-4">
      <p className="mb-1 flex items-center gap-2 text-sm font-semibold text-[var(--color-text-primary)]">
        <Upload className="h-4 w-4" />
        {preview.filename || t('importHotel')}
      </p>
      <p className="mb-2 text-xs text-[var(--color-text-secondary)]">{preview.summary_line}</p>
      {/* Which column we read as what: a "Room" column that turned out to be
          room service has to be visible as a wrong guess before anything is
          written, not discovered afterwards in the numbers. */}
      <p className="mb-3 flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-[var(--color-text-secondary)]">
        <span className="font-medium">{t('importColumns')}</span>
        {Object.entries(preview.columns).map(([target, column]) => (
          <span key={target} className="rounded bg-white px-1.5 py-0.5 font-mono">
            {target} ← {column}
          </span>
        ))}
      </p>

      <div className="max-h-80 overflow-auto rounded-md border border-[var(--color-border)] bg-white">
        <table className="w-full text-xs">
          <thead className="sticky top-0 bg-[var(--color-bg-subtle)]">
            <tr>
              <Th>{t('thRow')}</Th>
              <Th>{t('thFile')}</Th>
              <Th>{t('thFiche')}</Th>
              <Th>{t('thRoom')}</Th>
              <Th>{t('thStatus')}</Th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--color-border)]">
            {shown.map((line) => (
              <tr key={`${line.row}-${line.participant_id}`}>
                <Td className="font-mono text-[var(--color-text-secondary)]">{line.row}</Td>
                <Td>{line.name || line.email || '—'}</Td>
                <Td className="text-[var(--color-text-secondary)]">{line.participant_name || '—'}</Td>
                <Td className="font-mono">
                  {line.current_number && line.current_number !== line.room_number ? (
                    <span className="flex items-center gap-1">
                      <span className="text-[var(--color-text-secondary)] line-through">{line.current_number}</span>
                      <ArrowRight className="h-3 w-3" />
                      <span>{line.room_number || '—'}</span>
                    </span>
                  ) : (
                    line.room_number || '—'
                  )}
                </Td>
                <Td>
                  <StatusTag status={line.status} />
                </Td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {preview.lines.length > shown.length && (
        <p className="mt-2 text-[11px] text-[var(--color-text-secondary)]">
          {t('importShowing', { shown: shown.length, total: preview.lines.length })}
        </p>
      )}

      <p className="mt-3 text-xs text-[var(--color-text-secondary)]">{t('importHint')}</p>
      <div className="mt-3 flex gap-2">
        <button
          onClick={onApply}
          disabled={busy || writable.length === 0}
          className="rounded-md bg-[var(--color-accent)] px-3 py-1.5 text-sm font-semibold text-white disabled:opacity-60"
        >
          {busy
            ? t('importApplying')
            : writable.length === 0
            ? t('importNothing')
            : t('importApply', { count: writable.length })}
        </button>
        <button
          onClick={onCancel}
          disabled={busy}
          className="rounded-md border border-[var(--color-border)] bg-white px-3 py-1.5 text-sm disabled:opacity-50"
        >
          {t('cancel')}
        </button>
      </div>
    </div>
  )
}

function StatusTag({ status }: { status: RoomingImportLine['status'] }) {
  const t = useTranslations('rooming')
  const labels: Record<RoomingImportLine['status'], string> = {
    matched: t('statusMatched'),
    unchanged: t('statusUnchanged'),
    ambiguous: t('statusAmbiguous'),
    duplicate: t('statusDuplicate'),
    unknown: t('statusUnknown'),
    invalid: t('statusInvalid'),
  }
  const tone =
    status === 'matched'
      ? 'border-[var(--color-accent)]/40 bg-[var(--color-accent)]/10 text-[var(--color-accent)]'
      : status === 'unchanged'
      ? 'border-[var(--color-border)] bg-[var(--color-bg-subtle)] text-[var(--color-text-secondary)]'
      : 'border-[var(--color-warning)]/40 bg-[var(--color-warning)]/10 text-[var(--color-text-primary)]'
  return (
    <span className={cn('rounded border px-1.5 py-0.5 text-[10px] font-medium', tone)}>
      {labels[status]}
    </span>
  )
}

/** A module constant cannot call a hook, so the labels are built per render
 *  from the namespace the component already holds. */
function changeLabels(t: ReturnType<typeof useTranslations>): Record<RoomingChange['kind'], string> {
  return {
    added: t('arrival'),
    removed: t('departure'),
    moved: t('movedRoom'),
    roommate_changed: t('changedRoommate'),
    hotel_changed: t('changedHotel'),
    type_changed: t('changedType'),
  }
}

/** What regenerating would change, grouped by KIND rather than listed flat.
 *
 *  Flat, it was unreadable the moment one kind dominated: forty consecutive
 *  lines reading "CHANGE D'HÔTEL — → Hébergement" pushed the list itself off
 *  the screen, and the reader had to count them to learn the one thing that
 *  mattered, which was "forty". Grouped, the count comes first and the names
 *  are there for whoever wants them.
 */
function ChangeList({ changes }: { changes: RoomingChange[] }) {
  const t = useTranslations('rooming')
  if (changes.length === 0) {
    return <p className="text-sm text-[var(--color-text-secondary)]">{t('noChange')}</p>
  }

  const labels = changeLabels(t)
  const order: RoomingChange['kind'][] = [
    'removed', 'moved', 'roommate_changed', 'added', 'hotel_changed', 'type_changed',
  ]
  const byKind = order
    .map((kind) => ({ kind, items: changes.filter((c) => c.kind === kind) }))
    .filter((g) => g.items.length > 0)

  return (
    <div className="space-y-3">
      {byKind.map(({ kind, items }) => (
        <div key={kind}>
          <p className="mb-1 flex items-center gap-2 text-xs font-semibold text-[var(--color-text-primary)]">
            <span className="rounded bg-white px-1.5 py-0.5 text-[10px] uppercase tracking-wide text-[var(--color-text-secondary)]">
              {labels[kind]}
            </span>
            <span className="tabular-nums">{items.length}</span>
          </p>
          <ul className="space-y-0.5 pl-1 text-sm">
            {items.slice(0, 6).map((c) => (
              <li key={`${c.participant_id}-${c.kind}`} className="flex flex-wrap items-center gap-2">
                <span className="text-[var(--color-text-primary)]">{c.name}</span>
                {(c.from || c.to) && (
                  <span className="flex items-center gap-1 font-mono text-xs text-[var(--color-text-secondary)]">
                    {c.from || '—'} <ArrowRight className="h-3 w-3 shrink-0" /> {c.to || '—'}
                  </span>
                )}
              </li>
            ))}
            {items.length > 6 && (
              <li className="text-xs text-[var(--color-text-secondary)]">
                {t('andMoreEllipsis', { count: items.length - 6 })}
              </li>
            )}
          </ul>
        </div>
      ))}
    </div>
  )
}

function formatDate(value: string | null | undefined, locale: string): string {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleString(localeTag(locale), {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  })
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-1 text-xs text-[var(--color-text-secondary)]">
      {label}
      {children}
    </label>
  )
}

function Banner({ tone, children }: { tone: 'ok' | 'error'; children: React.ReactNode }) {
  return (
    <div
      className={cn(
        'mb-4 rounded-lg border px-4 py-3 text-sm',
        tone === 'error'
          ? 'border-[var(--color-danger)]/30 bg-[var(--color-danger)]/5 text-[var(--color-danger)]'
          : 'border-[var(--color-border)] bg-white text-[var(--color-text-primary)]'
      )}
    >
      {children}
    </div>
  )
}

function Empty({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-6 rounded-lg border border-[var(--color-border)] bg-white p-6 text-sm text-[var(--color-text-secondary)]">
      {children}
    </div>
  )
}

function Th({ children }: { children: React.ReactNode }) {
  return (
    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[var(--color-text-secondary)]">
      {children}
    </th>
  )
}

function Td({ children, className }: { children: React.ReactNode; className?: string }) {
  return <td className={cn('px-4 py-3 text-[var(--color-text-primary)]', className)}>{children}</td>
}
