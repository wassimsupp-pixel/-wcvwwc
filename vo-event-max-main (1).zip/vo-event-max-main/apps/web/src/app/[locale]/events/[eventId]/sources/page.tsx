'use client'

import { useState, useEffect, useCallback, useMemo } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useTranslations } from 'next-intl'
import { AppLayout } from '@/components/layout/AppLayout'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Upload, CheckCircle2, AlertTriangle, ArrowRight, Loader2, Trash2, Plus, X, ClipboardCheck, History, Database, ClipboardList, Plane, Hotel, Bus, PartyPopper } from 'lucide-react'
import type { UploadedFile, FileUploadResponse, MappingReportEntry } from '@/lib/api'
import { api, errorMessage } from '@/lib/api'
import { SourceVersions } from '@/components/sources/SourceVersions'

/** Each source type wears the icon of the page it feeds.
 *
 *  These were the last emoji in the product — on the very first screen
 *  somebody uses, while every other icon in the application comes from one
 *  set. A file of flights now carries the same plane the Vols page and its
 *  navigation entry carry, so the connection is visible rather than implied.
 *
 *  The names and one-liners live in `messages/*.json` under `sources.types`. */
/** Every target field the mapping can write to, in the order the dropdown
 *  offers them. The labels are in the `fields` namespace; this list fixes the
 *  order, and the set of keys that count as canonical. */
const CANONICAL_FIELDS = [
  'id', 'first_name', 'last_name', 'email', 'company', 'phone', 'nationality',
  'dietary_requirements', 'departure_date', 'return_date', 'flight_number',
  'departure_airport', 'arrival_airport', 'departure_time', 'arrival_time',
  'pnr_code', 'airline', 'baggage_info', 'hotel_name', 'check_in_date',
  'check_out_date', 'room_type', 'transfer_type', 'pickup_location',
  'dropoff_location', 'pickup_time', 'vehicle_type', 'activity_name',
  'attendee_category', 'job_title', 'region', 'function', 'language',
  'badge_name', 'country', 'booking_country', 'date_of_birth',
  'passport_number', 'passport_expiry', 'food_allergy_info', 'arrival_date',
  'departure_city', 'departure_country', 'arrival_city', 'arrival_country',
  'traveler_name', 'flight_domestic_intl', 'early_checkin', 'late_checkout',
  'fast_track', 'extra_meetings', 'headphones_translation',
]

/** Which fields each kind of file offers, and which it cannot do without.
 *
 *  `labelKey` is the exception, not the rule: a handful of fields read
 *  differently inside a global file, where "Heure" alone would not say
 *  whether it is the flight's or the shuttle's. */
const MAPPING_FIELDS_BY_TYPE: Record<string, { field: string; labelKey?: string; required: boolean }[]> = {
  // Master File: a single file mixing every kind of info. All fields are offered
  // and none is strictly required - the user maps whatever the file contains.
  masterfile: [
    { field: 'first_name', required: false },
    { field: 'last_name', required: false },
    { field: 'traveler_name', labelKey: 'traveler_name_full', required: false },
    { field: 'email', required: false },
    { field: 'company', required: false },
    { field: 'phone', required: false },
    { field: 'nationality', required: false },
    { field: 'attendee_category', required: false },
    { field: 'job_title', required: false },
    { field: 'region', required: false },
    { field: 'country', required: false },
    { field: 'date_of_birth', required: false },
    { field: 'passport_number', required: false },
    { field: 'passport_expiry', required: false },
    { field: 'dietary_requirements', required: false },
    { field: 'food_allergy_info', required: false },
    { field: 'airline', required: false },
    { field: 'flight_number', required: false },
    { field: 'departure_airport', required: false },
    { field: 'arrival_airport', required: false },
    { field: 'departure_time', required: false },
    { field: 'arrival_time', required: false },
    { field: 'pnr_code', required: false },
    { field: 'hotel_name', required: false },
    { field: 'check_in_date', required: false },
    { field: 'check_out_date', required: false },
    { field: 'room_type', required: false },
    { field: 'pickup_location', labelKey: 'transfer_pickup_location', required: false },
    { field: 'dropoff_location', labelKey: 'transfer_dropoff_location', required: false },
    { field: 'pickup_time', labelKey: 'transfer_pickup_time', required: false },
    { field: 'activity_name', required: false },
  ],
  registration: [
    { field: 'first_name', required: true },
    { field: 'last_name', required: true },
    { field: 'email', required: true },
    { field: 'company', required: false },
    { field: 'phone', required: false },
    { field: 'dietary_requirements', required: false },
    { field: 'nationality', required: false }
  ],
  // Non-registration files identify the traveller by a single name (Traveller)
  // or email and are matched to existing participants - so identity fields are
  // OPTIONAL here (only the domain fields are truly required).
  fcm: [
    { field: 'traveler_name', required: false },
    { field: 'first_name', required: false },
    { field: 'last_name', required: false },
    { field: 'email', required: false },
    { field: 'flight_number', required: true },
    { field: 'pnr_code', required: false },
    { field: 'airline', required: false },
    { field: 'departure_airport', required: true },
    { field: 'arrival_airport', required: true },
    { field: 'departure_time', required: true },
    { field: 'arrival_time', required: true },
    { field: 'baggage_info', required: false }
  ],
  hotel: [
    { field: 'traveler_name', labelKey: 'traveler_name_full', required: false },
    { field: 'first_name', required: false },
    { field: 'last_name', required: false },
    { field: 'email', required: false },
    { field: 'hotel_name', required: true },
    { field: 'check_in_date', required: true },
    { field: 'check_out_date', required: true },
    { field: 'room_type', required: false }
  ],
  transfer: [
    { field: 'traveler_name', labelKey: 'traveler_name_full', required: false },
    { field: 'first_name', required: false },
    { field: 'last_name', required: false },
    { field: 'email', required: false },
    { field: 'transfer_type', labelKey: 'transfer_type_direction', required: false },
    { field: 'pickup_location', required: true },
    { field: 'dropoff_location', required: true },
    { field: 'pickup_time', required: true },
    { field: 'vehicle_type', required: false }
  ],
  activity: [
    { field: 'traveler_name', labelKey: 'traveler_name_full', required: false },
    { field: 'first_name', required: false },
    { field: 'last_name', required: false },
    { field: 'email', required: false },
    { field: 'activity_name', required: true }
  ]
}

export default function SourcesPage() {
  const params = useParams()
  const router = useRouter()
  const locale = params.locale as string
  const eventId = params.eventId as string

  const t = useTranslations('nav')
  // Its own namespace: `t` above is the navigation's, and resolving a
  // page string against it is how 144 keys once landed in the wrong table.
  const tSrc = useTranslations('sources')
  const tAct = useTranslations('actions')

  // The mapping targets, named once for the whole product: the same column is
  // called the same thing here, on the registration form and in the exception
  // list. Written out one by one on purpose — a key built at runtime would
  // slip past check-i18n and surface as a raw path in Dutch.
  const tf = useTranslations('fields')
  const FIELD_LABELS: Record<string, string> = useMemo(() => ({
    id: tf('id'),
    first_name: tf('first_name'),
    last_name: tf('last_name'),
    email: tf('email'),
    company: tf('company'),
    phone: tf('phone'),
    nationality: tf('nationality'),
    dietary_requirements: tf('dietary_requirements'),
    departure_date: tf('departure_date'),
    return_date: tf('return_date'),
    flight_number: tf('flight_number'),
    departure_airport: tf('departure_airport'),
    arrival_airport: tf('arrival_airport'),
    departure_time: tf('departure_time'),
    arrival_time: tf('arrival_time'),
    pnr_code: tf('pnr_code'),
    airline: tf('airline'),
    baggage_info: tf('baggage_info'),
    hotel_name: tf('hotel_name'),
    check_in_date: tf('check_in_date'),
    check_out_date: tf('check_out_date'),
    room_type: tf('room_type'),
    transfer_type: tf('transfer_type'),
    pickup_location: tf('pickup_location'),
    dropoff_location: tf('dropoff_location'),
    pickup_time: tf('pickup_time'),
    vehicle_type: tf('vehicle_type'),
    activity_name: tf('activity_name'),
    attendee_category: tf('attendee_category'),
    job_title: tf('job_title'),
    region: tf('region'),
    function: tf('function'),
    language: tf('language'),
    badge_name: tf('badge_name'),
    country: tf('country'),
    booking_country: tf('booking_country'),
    date_of_birth: tf('date_of_birth'),
    passport_number: tf('passport_number'),
    passport_expiry: tf('passport_expiry'),
    food_allergy_info: tf('food_allergy_info'),
    arrival_date: tf('arrival_date'),
    departure_city: tf('departure_city'),
    departure_country: tf('departure_country'),
    arrival_city: tf('arrival_city'),
    arrival_country: tf('arrival_country'),
    traveler_name: tf('traveler_name'),
    flight_domestic_intl: tf('flight_domestic_intl'),
    early_checkin: tf('early_checkin'),
    late_checkout: tf('late_checkout'),
    fast_track: tf('fast_track'),
    extra_meetings: tf('extra_meetings'),
    headphones_translation: tf('headphones_translation'),
    // The few that read differently inside a global file.
    traveler_name_full: tf('traveler_name_full'),
    transfer_pickup_location: tf('transfer_pickup_location'),
    transfer_dropoff_location: tf('transfer_dropoff_location'),
    transfer_pickup_time: tf('transfer_pickup_time'),
    transfer_type_direction: tf('transfer_type_direction'),
  }), [tf])

  const SOURCE_TYPES = useMemo(() => [
    { key: 'masterfile', Icon: Database, name: tSrc('types.masterfile.name'), subtitle: tSrc('types.masterfile.subtitle') },
    { key: 'registration', Icon: ClipboardList, name: tSrc('types.registration.name'), subtitle: tSrc('types.registration.subtitle') },
    { key: 'fcm', Icon: Plane, name: tSrc('types.fcm.name'), subtitle: tSrc('types.fcm.subtitle') },
    { key: 'hotel', Icon: Hotel, name: tSrc('types.hotel.name'), subtitle: tSrc('types.hotel.subtitle') },
    { key: 'transfer', Icon: Bus, name: tSrc('types.transfer.name'), subtitle: tSrc('types.transfer.subtitle') },
    { key: 'activity', Icon: PartyPopper, name: tSrc('types.activity.name'), subtitle: tSrc('types.activity.subtitle') },
  ], [tSrc])

  const [uploadingType, setUploadingType] = useState<string | null>(null)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [isMappingMode, setIsMappingMode] = useState(false)
  const [uploadResponse, setUploadResponse] = useState<FileUploadResponse | null>(null)
  const [mapping, setMapping] = useState<Record<string, string>>({})
  // Columns the user chose to map to a custom (non-predefined) field
  const [customFields, setCustomFields] = useState<Record<string, boolean>>({})
  // Reusable user-defined target fields (persisted per event), available in every
  // column's dropdown so the user can add mapping fields freely.
  const [customFieldList, setCustomFieldList] = useState<string[]>([])
  const [newCustomField, setNewCustomField] = useState('')

  const customFieldsKey = `mapping_custom_fields_${eventId}`

  useEffect(() => {
    try {
      const saved = localStorage.getItem(customFieldsKey)
      if (saved) setCustomFieldList(JSON.parse(saved))
    } catch { /* ignore corrupt storage */ }
  }, [customFieldsKey])

  const persistCustomFields = (list: string[]) => {
    setCustomFieldList(list)
    try { localStorage.setItem(customFieldsKey, JSON.stringify(list)) } catch { /* ignore */ }
  }

  const addCustomField = () => {
    const name = newCustomField.trim()
    if (!name) return
    if (customFieldList.some(f => f.toLowerCase() === name.toLowerCase())) { setNewCustomField(''); return }
    persistCustomFields([...customFieldList, name])
    setNewCustomField('')
  }

  const removeCustomField = (name: string) => {
    persistCustomFields(customFieldList.filter(f => f !== name))
    // Unmap any column that used this custom field
    setMapping(prev => {
      const next = { ...prev }
      Object.keys(next).forEach(col => { if (next[col] === name) delete next[col] })
      return next
    })
  }

  // User-added source-column rows (name of a column in the file + its target).
  // Lets the user add as many columns to map as they want.
  const [extraColumns, setExtraColumns] = useState<{ id: string; name: string; target: string }[]>([])

  const addExtraColumn = () => {
    setExtraColumns(prev => [...prev, { id: `x_${Date.now()}_${prev.length}`, name: '', target: '' }])
  }
  const updateExtraColumn = (id: string, patch: Partial<{ name: string; target: string }>) => {
    setExtraColumns(prev => prev.map(c => (c.id === id ? { ...c, ...patch } : c)))
  }
  const removeExtraColumn = (id: string) => {
    setExtraColumns(prev => prev.filter(c => c.id !== id))
  }

  // Real file list state
  const [importedFiles, setImportedFiles] = useState<UploadedFile[]>([])
  const [filesLoading, setFilesLoading] = useState(true)

  // Upload states
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState<string | null>(null)
  const [uploadSuccess, setUploadSuccess] = useState<string | null>(null)
  const [deletingFileId, setDeletingFileId] = useState<string | null>(null)

  const loadFiles = useCallback(async () => {
    setFilesLoading(true)
    try {
      const files = await api.files.list(eventId)
      setImportedFiles(files)
    } catch (err) {
      console.error('Failed to load files:', err)
    } finally {
      setFilesLoading(false)
    }
  }, [eventId])

  useEffect(() => {
    loadFiles()
  }, [loadFiles])

  // The public registration link lives on its own page (events/[id]/
  // registration-form) — it is something you share with attendees, not a
  // file you import here, and it was competing for attention with the
  // upload flow this page exists for.

  // While a file is still being auto-mapped in the background ('pending'), poll
  // so the list reflects its next state (review / processed) without a manual
  // refresh. Stops as soon as nothing is pending.
  useEffect(() => {
    const hasPending = importedFiles.some((f) => f.status === 'pending')
    if (!hasPending) return
    const timer = setInterval(loadFiles, 8000)
    return () => clearInterval(timer)
  }, [importedFiles, loadFiles])

  const [reviewFileId, setReviewFileId] = useState<string | null>(null)
  // Per-column report (confidence, source, needs_split) for the file under review.
  const [mappingReport, setMappingReport] = useState<Record<string, MappingReportEntry>>({})

  // Open the mapping editor for a file the engine flagged as a brand-new format
  // ('review'): load its FULL auto-built mapping (every column, incl. custom
  // fields) so confirming never drops anything, plus the per-column report so the
  // user's attention goes to the uncertain columns. Memorised after confirmation.
  const openReview = async (file: UploadedFile) => {
    setReviewFileId(file.id)
    setUploadError(null)
    try {
      const preview = await api.files.preview(file.id)
      const synthetic: FileUploadResponse = {
        file_id: file.id,
        filename: file.filename,
        row_count: file.row_count,
        columns: preview.columns,
        uploaded_at: file.uploaded_at,
        import_status: 'review',
        mapping_suggestions: preview.mapping_suggestions,
        canonical_fields: preview.canonical_fields,
        remembered: preview.remembered,
      }
      // Seed from the COMPLETE stored mapping (A→Z catch-all) so nothing is lost;
      // fall back to confident suggestions only if the stored mapping is absent.
      let initialMapping: Record<string, string> = {}
      if (preview.column_mapping && Object.keys(preview.column_mapping).length > 0) {
        initialMapping = { ...preview.column_mapping }
      } else {
        Object.entries(preview.mapping_suggestions || {}).forEach(([col, sug]) => {
          if (sug.suggested_field && sug.confidence >= 0.5) initialMapping[col] = sug.suggested_field
        })
      }
      // Custom (non-canonical) targets from the catch-all: surface them as
      // options so those columns show as mapped ("Perso"), not "-- Ignorer --".
      const customTargets = Object.values(initialMapping).filter(
        (v) => v && !CANONICAL_FIELDS.includes(v)
      )
      if (customTargets.length > 0) {
        setCustomFieldList((prev) => Array.from(new Set([...prev, ...customTargets])))
      }
      setUploadingType(file.source_type)
      setSelectedFile({ name: file.filename } as File)
      setUploadResponse(synthetic)
      setMapping(initialMapping)
      setMappingReport(preview.mapping_report || {})
      setExtraColumns([])
      setIsMappingMode(true)
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : tSrc('errLoadFile'))
    } finally {
      setReviewFileId(null)
    }
  }

  const reviewCount = importedFiles.filter((f) => f.status === 'review').length

  // Small per-column confidence/source/split line shown under each column name in
  // the review editor, driven by the backend mapping_report.
  const SOURCE_LABEL: Record<string, string> = { ai: tSrc('srcAi'), heuristic: tSrc('srcAuto'), custom: tSrc('srcCustom') }
  const renderColMeta = (col: string) => {
    const r = mappingReport[col]
    if (!r) {
      const s = uploadResponse?.mapping_suggestions?.[col]
      if (!s?.suggested_field) return null
      return (
        <span className={`mt-0.5 text-[10px] font-medium ${s.confidence >= 0.7 ? 'text-emerald-600' : 'text-amber-600'}`}>
          {tSrc('suggestedPct', { pct: Math.round(s.confidence * 100) })}
        </span>
      )
    }
    const conf = r.confidence
    const confCls = r.source === 'custom' ? 'text-slate-500' : conf >= 90 ? 'text-emerald-600' : conf >= 60 ? 'text-amber-600' : 'text-rose-600'
    return (
      <span className="mt-0.5 flex flex-wrap items-center gap-1">
        <span className={`text-[10px] font-semibold ${confCls}`}>
          {SOURCE_LABEL[r.source] || tSrc('srcAuto')}{r.source !== 'custom' ? ` — ${conf}%` : ''}
        </span>
        {r.needs_split && (
          <span className="rounded bg-orange-100 px-1 py-0.5 text-[9px] font-bold text-orange-700" title={tSrc('toSplitHint')}>
            {tSrc('toSplit')}
          </span>
        )}
      </span>
    )
  }

  const handleDeleteFile = async (fileId: string) => {
    if (!confirm(tSrc('confirmDeleteFile'))) {
      return
    }
    setDeletingFileId(fileId)
    try {
      await api.files.delete(fileId)
      await loadFiles()
      router.refresh()
    } catch (err) {
      console.error('Failed to delete file:', err)
      // Deletion is refused (409) while a consolidation is running on the
      // event — a real, temporary, self-resolving condition the API spells
      // out. Show it: "erreur" alone left the user with nothing to act on.
      alert(errorMessage(err, tSrc('errDeleteFile')))
    } finally {
      setDeletingFileId(null)
    }
  }

  const getFieldLabel = (field: string) => {
    const fields = MAPPING_FIELDS_BY_TYPE[uploadingType || 'registration'] || []
    const found = fields.find(f => f.field === field)
    if (found?.labelKey) return FIELD_LABELS[found.labelKey] || field
    return FIELD_LABELS[field] || field
  }

  const getSortedFieldsForColumn = (col: string) => {
    const suggestion = uploadResponse?.mapping_suggestions?.[col]
    const suggestedField = suggestion?.suggested_field || null
    const alternatives = suggestion?.alternatives || []
    // Offer every canonical field (the master file is rich and may be imported
    // under any source type); prioritise the current type's fields first.
    const typeFields = (MAPPING_FIELDS_BY_TYPE[uploadingType || 'registration'] || []).map(f => f.field)
    const allFields = CANONICAL_FIELDS
    const currentTypeFields = [...typeFields, ...allFields.filter(f => !typeFields.includes(f))]

    const validSuggestedField = currentTypeFields.includes(suggestedField || '') ? suggestedField : null
    const validAlternatives = alternatives.filter(f => currentTypeFields.includes(f))

    const alternativesList = validAlternatives.filter(f => f !== validSuggestedField)
    const othersList = currentTypeFields.filter(f => f !== validSuggestedField && !alternativesList.includes(f))

    othersList.sort((a, b) => {
      const labelA = getFieldLabel(a)
      const labelB = getFieldLabel(b)
      return labelA.localeCompare(labelB)
    })

    return {
      suggestedField: validSuggestedField,
      alternatives: alternativesList,
      others: othersList,
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0])
      setUploadError(null)
    }
  }

  const handleUpload = async () => {
    if (!selectedFile || !uploadingType) return

    setUploading(true)
    setUploadError(null)
    setUploadSuccess(null)
    const fileName = selectedFile.name
    try {
      // 'masterfile' is a UI convenience (mixed-info file). It is stored as
      // 'registration' — a valid DB source type that already creates participants;
      // the domain extractor pulls flight/hotel/transfer/activity from every row.
      const apiSourceType = uploadingType === 'masterfile' ? 'registration' : uploadingType
      const response = await api.files.upload(eventId, selectedFile, apiSourceType)
      setUploadResponse(response)

      // Pre-fill an initial mapping guess (kept ready ONLY for the optional
      // "Ajuster le mapping" action — not shown automatically).
      const initialMapping: Record<string, string> = {}
      if (response.mapping_suggestions) {
        Object.entries(response.mapping_suggestions).forEach(([col, sug]) => {
          if (sug.suggested_field && sug.confidence >= 0.5) {
            initialMapping[col] = sug.suggested_field
          }
        })
      }
      setMapping(initialMapping)
      setExtraColumns([])
      // FULLY AUTOMATIC: no manual mapping page. Confirm and refresh the list;
      // the mapping + consolidation run in the background.
      setIsMappingMode(false)
      setUploadingType(null)
      setSelectedFile(null)
      setUploadSuccess(tSrc('uploadedFile', { name: fileName }))
      await loadFiles()
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : tSrc('errUpload'))
    } finally {
      setUploading(false)
    }
  }

  const handleConfirmMapping = async () => {
    if (!uploadResponse) return

    try {
      // Merge auto-detected mappings with the columns the user added manually.
      const finalMapping: Record<string, string> = { ...mapping }
      extraColumns.forEach(c => {
        const name = c.name.trim()
        if (name && c.target) finalMapping[name] = c.target
      })
      await api.files.mapColumns(uploadResponse.file_id, finalMapping)
      await loadFiles()
      setIsMappingMode(false)
      setUploadingType(null)
      setSelectedFile(null)
      setUploadResponse(null)
      setExtraColumns([])
      setUploadError(null)
      router.refresh()
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : tSrc('errConfirmMapping'))
    }
  }

  return (
    <AppLayout
      eventId={eventId}
      locale={locale}
    >
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text-primary)] flex items-center gap-2">
            <Database className="h-6 w-6 text-[var(--color-accent)]" />
            {t('sources')}
          </h1>
          <p className="mt-1 text-sm text-[var(--color-text-secondary)]">{tSrc('subtitle')}</p>
        </div>

        {/* Prominent call-to-action for the import step (§8) */}
        {!isMappingMode && (
          <div className="flex flex-col gap-3 rounded-[var(--radius-card)] border border-[var(--color-accent)]/30 bg-[var(--color-accent-light)] p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <Upload className="h-5 w-5 flex-shrink-0 text-[var(--color-accent)]" />
              <div>
                <p className="text-sm font-semibold text-[var(--color-text-primary)]">
                  {tSrc('importCta', { done: new Set(importedFiles.map((f) => f.source_type)).size, total: SOURCE_TYPES.length })}
                </p>
                <p className="text-xs text-[var(--color-text-secondary)]">
                  {tSrc('importCtaHint')}
                </p>
              </div>
            </div>
            <button
              onClick={() => document.getElementById('import-zone')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
              className="inline-flex items-center gap-2 self-start rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-[var(--color-accent)]/90 sm:self-auto"
            >
              <Upload className="h-4 w-4" /> {tSrc('uploadTitle')}
            </button>
          </div>
        )}

        {/* One-time review prompt: a brand-new file format needs its mapping
            confirmed once. Recognised formats stay 100% automatic. */}
        {!isMappingMode && reviewCount > 0 && (
          <div className="flex flex-col gap-3 rounded-[var(--radius-card)] border border-amber-300 bg-amber-50 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <ClipboardCheck className="h-5 w-5 flex-shrink-0 text-amber-600" />
              <div>
                <p className="text-sm font-semibold text-amber-900">
                  {tSrc('reviewBanner', { count: reviewCount })}
                </p>
                <p className="text-xs text-amber-800">
                  {tSrc('reviewBannerHint')}
                </p>
              </div>
            </div>
          </div>
        )}

        {isMappingMode && uploadResponse ? (
          <Card className="p-6 border-[var(--color-border)] shadow-[var(--shadow-card)] space-y-6">
            <div className="flex items-start gap-3 rounded-lg border border-[var(--color-success)]/30 bg-[var(--color-success-light)] px-4 py-3">
              <CheckCircle2 className="h-5 w-5 shrink-0 text-[var(--color-success)] mt-0.5" />
              <div className="text-sm">
                <p className="font-semibold text-[var(--color-text-primary)]">
                  {tSrc('uploadedTitle')}
                </p>
                <p className="text-xs text-[var(--color-text-secondary)] mt-0.5">
                  {tSrc('autoDetected')}{' '}
                  <button
                    onClick={() => router.push(`/${locale}/events/${eventId}/master-list`)}
                    className="font-semibold text-[var(--color-accent)] underline"
                  >
                    {tSrc('goToMasterList')}
                  </button>.
                </p>
              </div>
            </div>
            {uploadResponse.remembered && (
              <div className="flex items-start gap-3 rounded-lg border border-[var(--color-accent)]/30 bg-[var(--color-accent-light)]/40 px-4 py-3">
                <History className="h-5 w-5 shrink-0 text-[var(--color-accent)] mt-0.5" />
                <div className="text-sm">
                  <p className="font-semibold text-[var(--color-text-primary)]">
                    {tSrc('rememberedTitle')}
                  </p>
                  <p className="text-xs text-[var(--color-text-secondary)] mt-0.5">
                    {tSrc('rememberedHint')}
                  </p>
                </div>
              </div>
            )}
            <div className="flex items-center justify-between border-b pb-4">
              <div>
                <h3 className="text-lg font-semibold text-[var(--color-text-primary)]">
                  {tSrc('mappingTitle')} — {selectedFile?.name}
                </h3>
                <p className="text-xs text-[var(--color-text-secondary)] mt-0.5">
                  {uploadResponse.remembered
                    ? tSrc('rememberedShort')
                    : tSrc('autoDetectedShort')}
                </p>
              </div>
              <Badge variant="outline" className="border-[var(--color-accent)] text-[var(--color-accent)] bg-[var(--color-accent-light)]">
                {tSrc('rowsDetected', { count: uploadResponse.row_count })}
              </Badge>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Mapping Form */}
              <div className="space-y-4">
                <h4 className="text-xs font-semibold text-[var(--color-text-secondary)] uppercase tracking-wider">
                  {tSrc('mappingTitle')}
                </h4>

                {/* Reusable custom target fields — add mapping fields as you want */}
                <div className="rounded-md border border-dashed border-[var(--color-accent)]/40 bg-[var(--color-accent-light)]/20 p-3 space-y-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={newCustomField}
                      onChange={(e) => setNewCustomField(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addCustomField() } }}
                      placeholder={tSrc('addFieldPlaceholder')}
                      className="flex-1 text-xs rounded-md border border-[var(--color-border)] bg-white p-2 text-[var(--color-text-primary)] focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                    />
                    <Button
                      type="button"
                      size="sm"
                      className="bg-[var(--color-accent)] hover:bg-[var(--color-accent)]/90 text-white shrink-0"
                      onClick={addCustomField}
                    >
                      <Plus className="h-3.5 w-3.5 mr-1" /> {tSrc('addField')}
                    </Button>
                  </div>
                  {customFieldList.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {customFieldList.map(name => (
                        <span key={name} className="inline-flex items-center gap-1 rounded-full bg-white border border-[var(--color-accent)]/30 px-2 py-0.5 text-[11px] font-medium text-[var(--color-accent)]">
                          {name}
                          <button type="button" onClick={() => removeCustomField(name)} className="hover:text-[var(--color-danger)]" title={tSrc('removeField')}>
                            <X className="h-3 w-3" />
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                  <p className="text-[10px] text-[var(--color-text-secondary)]">
                    {tSrc('customFieldsHint')}
                  </p>
                </div>

                <div className="space-y-3 max-h-[350px] overflow-y-auto pr-2 border rounded-md p-4 bg-slate-50">
                  {uploadResponse.columns.map((col: string) => {
                    const colOptions = getSortedFieldsForColumn(col)
                    return (
                      <div key={col} className="grid grid-cols-12 items-center gap-3">
                        <div className="col-span-5 flex flex-col min-w-0">
                          <span className="text-sm font-medium text-[var(--color-text-primary)] truncate" title={col}>
                            {col}
                          </span>
                          {renderColMeta(col)}
                        </div>
                        <div className="col-span-7 space-y-1.5">
                          <select
                            className="w-full text-xs rounded-md border border-[var(--color-border)] bg-white p-2 text-[var(--color-text-primary)] focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                            value={customFields[col] ? '__custom__' : (mapping[col] || '')}
                            onChange={(e) => {
                              const val = e.target.value
                              if (val === '__custom__') {
                                setCustomFields(prev => ({ ...prev, [col]: true }))
                                setMapping(prev => { const next = { ...prev }; delete next[col]; return next })
                                return
                              }
                              setCustomFields(prev => ({ ...prev, [col]: false }))
                              setMapping(prev => {
                                const next = { ...prev }
                                if (val) next[col] = val
                                else delete next[col]
                                return next
                              })
                            }}
                          >
                            <option value="">{tSrc('ignoreColumn')}</option>
                            {customFieldList.length > 0 && (
                              <optgroup label={tSrc('groupMine')}>
                                {customFieldList.map(name => (
                                  <option key={name} value={name}>
                                    {name}
                                  </option>
                                ))}
                              </optgroup>
                            )}
                            {colOptions.suggestedField && (
                              <optgroup label={tSrc('groupSuggested')}>
                                <option value={colOptions.suggestedField}>
                                  {getFieldLabel(colOptions.suggestedField)}
                                </option>
                              </optgroup>
                            )}
                            {colOptions.alternatives.length > 0 && (
                              <optgroup label={tSrc('groupAlternatives')}>
                                {colOptions.alternatives.map(field => (
                                  <option key={field} value={field}>
                                    {getFieldLabel(field)}
                                  </option>
                                ))}
                              </optgroup>
                            )}
                            <optgroup label={tSrc('groupAll')}>
                              {colOptions.others.map(field => (
                                <option key={field} value={field}>
                                  {getFieldLabel(field)}
                                </option>
                              ))}
                            </optgroup>
                            <option value="__custom__">{tSrc('oneOffField')}</option>
                          </select>
                          {customFields[col] && (
                            <input
                              type="text"
                              autoFocus
                              placeholder={tSrc('oneOffPlaceholder')}
                              value={mapping[col] || ''}
                              onChange={(e) => {
                                const v = e.target.value
                                setMapping(prev => {
                                  const next = { ...prev }
                                  if (v.trim()) next[col] = v
                                  else delete next[col]
                                  return next
                                })
                              }}
                              className="w-full text-xs rounded-md border border-[var(--color-accent)] bg-white p-2 text-[var(--color-text-primary)] focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                            />
                          )}
                        </div>
                      </div>
                    )
                  })}

                  {/* Columns the user adds manually (name from the file + target) */}
                  {extraColumns.map((c) => (
                    <div key={c.id} className="grid grid-cols-12 items-center gap-3">
                      <div className="col-span-5 flex items-center gap-1.5 min-w-0">
                        <input
                          type="text"
                          list="file-columns-list"
                          value={c.name}
                          onChange={(e) => updateExtraColumn(c.id, { name: e.target.value })}
                          placeholder={tSrc('columnNamePlaceholder')}
                          className="w-full text-sm rounded-md border border-[var(--color-accent)]/50 bg-white p-2 text-[var(--color-text-primary)] focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                        />
                        <button type="button" onClick={() => removeExtraColumn(c.id)} className="shrink-0 text-[var(--color-text-secondary)] hover:text-[var(--color-danger)]" title={tSrc('removeColumn')}>
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="col-span-7">
                        <select
                          className="w-full text-xs rounded-md border border-[var(--color-border)] bg-white p-2 text-[var(--color-text-primary)] focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                          value={c.target}
                          onChange={(e) => updateExtraColumn(c.id, { target: e.target.value })}
                        >
                          <option value="">{tSrc('chooseTarget')}</option>
                          {customFieldList.length > 0 && (
                            <optgroup label={tSrc('groupMine')}>
                              {customFieldList.map(name => (
                                <option key={name} value={name}>{name}</option>
                              ))}
                            </optgroup>
                          )}
                          <optgroup label={tSrc('groupAll')}>
                            {CANONICAL_FIELDS.map(field => (
                              <option key={field} value={field}>{FIELD_LABELS[field]}</option>
                            ))}
                          </optgroup>
                        </select>
                      </div>
                    </div>
                  ))}

                  {/* Datalist of the file's real columns, for quick autocomplete */}
                  <datalist id="file-columns-list">
                    {(uploadResponse.columns || []).map((col: string) => (
                      <option key={col} value={col} />
                    ))}
                  </datalist>

                  <button
                    type="button"
                    onClick={addExtraColumn}
                    className="flex items-center gap-1.5 text-xs font-semibold text-[var(--color-accent)] hover:underline pt-1"
                  >
                    <Plus className="h-3.5 w-3.5" /> {tSrc('addColumn')}
                  </button>
                </div>
              </div>

              {/* Required fields indicator / preview */}
              <div className="space-y-4">
                <h4 className="text-xs font-semibold text-[var(--color-text-secondary)] uppercase tracking-wider">
                  {tSrc('targetFields')}
                </h4>
                <div className="p-4 bg-slate-50 rounded-lg border space-y-3">
                  <p className="text-xs text-[var(--color-text-secondary)]">
                    {tSrc('appliedFor')} <strong>{SOURCE_TYPES.find(s => s.key === uploadingType)?.name}</strong>
                  </p>
                  <ul className="text-xs space-y-2 mt-2 max-h-[300px] overflow-y-auto pr-2">
                    {(MAPPING_FIELDS_BY_TYPE[uploadingType || 'registration'] || []).map(({ field, labelKey, required }) => {
                      const isMapped = Object.values(mapping).includes(field)
                      return (
                        <li key={field} className="flex items-center justify-between border-b pb-1.5 border-slate-100 last:border-b-0 last:pb-0">
                          <span className={`${required ? 'font-semibold' : ''} text-[var(--color-text-primary)]`}>
                            {FIELD_LABELS[labelKey || field] || field} {required && <span className="text-[var(--color-danger)]">*</span>}
                          </span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            isMapped
                              ? 'bg-emerald-100 text-emerald-800'
                              : required
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}>
                            {isMapped ? tSrc('mapped') : required ? tSrc('fieldRequired') : tSrc('fieldOptional')}
                          </span>
                        </li>
                      )
                    })}
                    {/* User-added custom fields shown as real target columns */}
                    {customFieldList.map((name) => {
                      const isMapped = Object.values(mapping).includes(name)
                      return (
                        <li key={`custom-${name}`} className="flex items-center justify-between border-b pb-1.5 border-slate-100 last:border-b-0 last:pb-0">
                          <span className="text-[var(--color-text-primary)] inline-flex items-center gap-1">
                            <span className="text-[9px] font-bold text-[var(--color-accent)] bg-[var(--color-accent-light)]/50 rounded px-1 py-0.5">{tSrc('customBadge')}</span>
                            {name}
                          </span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            isMapped ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {isMapped ? tSrc('mapped') : tSrc('fieldOptional')}
                          </span>
                        </li>
                      )
                    })}
                  </ul>
                </div>
              </div>
            </div>

            {uploadError && (
              <div className="flex items-center gap-2 rounded-md border border-[var(--color-danger)] bg-red-50 p-3 text-sm text-[var(--color-danger)]">
                <AlertTriangle className="h-4 w-4 shrink-0" />
                <span>{uploadError}</span>
              </div>
            )}

            {uploadSuccess && (
              <div className="flex flex-wrap items-center gap-2 rounded-md border border-[var(--color-success)]/30 bg-[var(--color-success-light)] p-3 text-sm text-[var(--color-text-primary)]">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-[var(--color-success)]" />
                <span className="flex-1">{uploadSuccess}</span>
                <button
                  onClick={() => router.push(`/${locale}/events/${eventId}/master-list`)}
                  className="text-xs font-semibold text-[var(--color-accent)] underline"
                >
                  {tSrc('goToMasterList')}
                </button>
                {uploadResponse && (
                  <button
                    onClick={() => setIsMappingMode(true)}
                    className="text-xs font-semibold text-[var(--color-text-secondary)] underline"
                  >
                    {tSrc('adjustMapping')}
                  </button>
                )}
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={() => setIsMappingMode(false)}>
                {tAct('cancel')}
              </Button>
              <Button
                className="bg-[var(--color-accent)] hover:bg-[var(--color-accent)]/90 text-white"
                onClick={handleConfirmMapping}
              >
                {tSrc('confirmAndAnalyse')} <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </Card>
        ) : (
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            {/* Import options */}
            <div id="import-zone" className="col-span-12 lg:col-span-2 space-y-6 scroll-mt-24">
              <Card className="p-6 border-[var(--color-border)] shadow-[var(--shadow-card)]">
                <h3 className="text-base font-semibold text-[var(--color-text-primary)] mb-4">
                  {tSrc('importNewSource')}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {SOURCE_TYPES.map((src) => (
                    <div
                      key={src.key}
                      className="group cursor-pointer rounded-lg border border-[var(--color-border)] p-4 bg-white hover:border-[var(--color-accent)] hover:bg-[var(--color-accent-light)]/10 transition-all flex items-start gap-3.5"
                      onClick={() => setUploadingType(src.key)}
                    >
                      <span className="flex h-9 w-9 items-center justify-center rounded-md bg-slate-50 text-[var(--color-accent)] transition-colors group-hover:bg-white">
                        <src.Icon className="h-5 w-5" />
                      </span>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-semibold text-[var(--color-text-primary)] group-hover:text-[var(--color-accent)] transition-colors">
                          {src.name}
                        </h4>
                        <p className="text-xs text-[var(--color-text-secondary)] mt-0.5">{src.subtitle}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Upload Overlay Modal if type selected */}
              {uploadingType && !isMappingMode && (
                <Card className="p-6 border-[var(--color-accent)] bg-[var(--color-accent-light)]/5 shadow-[var(--shadow-card)] space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-[var(--color-text-primary)]">
                      {tSrc('importType', { name: SOURCE_TYPES.find(s => s.key === uploadingType)?.name || '' })}
                    </h3>
                    <Button variant="ghost" size="sm" onClick={() => { setUploadingType(null); setSelectedFile(null); setUploadError(null) }}>{tAct('close')}</Button>
                  </div>
                  <div className="flex flex-col items-center justify-center border-2 border-dashed border-[var(--color-border-strong)] rounded-lg p-6 bg-white hover:border-[var(--color-accent)] transition-colors relative">
                    <input
                      type="file"
                      id="source-file-upload"
                      className="absolute inset-0 opacity-0 cursor-pointer"
                      accept=".xlsx,.xls,.csv"
                      onChange={handleFileChange}
                    />
                    <Upload className="h-8 w-8 text-[var(--color-text-secondary)] mb-2" />
                    <p className="text-xs text-[var(--color-text-primary)] font-medium">
                      {selectedFile ? selectedFile.name : tSrc('uploadDescription')}
                    </p>
                    <p className="text-[10px] text-[var(--color-text-secondary)] mt-1">{tSrc('acceptedFormats')}</p>
                  </div>

                  {uploadError && (
                    <div className="flex items-center gap-2 rounded-md border border-[var(--color-danger)] bg-red-50 p-3 text-sm text-[var(--color-danger)]">
                      <AlertTriangle className="h-4 w-4 shrink-0" />
                      <span>{uploadError}</span>
                    </div>
                  )}

                  <div className="flex justify-end gap-2.5">
                    <Button variant="outline" onClick={() => { setUploadingType(null); setSelectedFile(null); setUploadError(null) }}>
                      {tAct('cancel')}
                    </Button>
                    <Button
                      className="bg-[var(--color-accent)] hover:bg-[var(--color-accent)]/90 text-white flex items-center gap-2"
                      disabled={!selectedFile || uploading}
                      onClick={handleUpload}
                    >
                      {uploading && <Loader2 className="h-4 w-4 animate-spin" />}
                      {uploading ? tSrc('analysing') : tSrc('analyseFile')}
                    </Button>
                  </div>
                </Card>
              )}

              {/* §20 — Add/Update vs Replace. Sits above the registry because
                  it is about the relationship BETWEEN the files below. */}
              <SourceVersions eventId={eventId} />

              {/* File registry list */}
              <Card className="p-6 border-[var(--color-border)] shadow-[var(--shadow-card)] space-y-4">
                <h3 className="text-base font-semibold text-[var(--color-text-primary)]">
                  {tSrc('importedFiles')}
                </h3>
                <div className="overflow-x-auto">
                  {filesLoading ? (
                    <div className="flex items-center justify-center py-10 text-sm text-[var(--color-text-secondary)]">
                      <Loader2 className="h-5 w-5 animate-spin mr-2" />
                      {tSrc('loadingFiles')}
                    </div>
                  ) : importedFiles.length === 0 ? (
                    <div className="py-10 text-center text-sm text-[var(--color-text-secondary)]">
                      {tSrc('noFiles')}
                    </div>
                  ) : (
                    <table className="w-full text-left text-sm">
                      <thead>
                        <tr className="border-b text-[var(--color-text-secondary)] font-medium text-xs uppercase tracking-wider">
                          <th className="pb-3">{tSrc('colFile')}</th>
                          <th className="pb-3">{tSrc('colType')}</th>
                          <th className="pb-3">{tSrc('colRows')}</th>
                          <th className="pb-3">{tSrc('colImported')}</th>
                          <th className="pb-3">{tSrc('colStatus')}</th>
                          <th className="pb-3 text-right">{tSrc('colActions')}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y text-[var(--color-text-primary)]">
                        {importedFiles.map((file) => (
                          <tr key={file.id} className="hover:bg-slate-50/50">
                            <td className="py-3.5 font-medium">{file.filename}</td>
                            <td className="py-3.5 text-xs text-[var(--color-text-secondary)]">
                              {SOURCE_TYPES.find(s => s.key === file.source_type)?.name || file.source_type}
                            </td>
                            <td className="py-3.5 text-xs font-semibold">{tSrc('rows', { count: file.row_count })}</td>
                            <td className="py-3.5 text-xs text-[var(--color-text-secondary)]">
                              {new Date(file.uploaded_at).toLocaleString(locale)}
                            </td>
                            <td className="py-3.5">
                              {file.status === 'error' ? (
                                <Badge className="bg-red-100 text-[var(--color-danger)] border-0 flex items-center gap-1 w-fit">
                                  <AlertTriangle className="h-3 w-3" /> {tSrc('status.error')}
                                </Badge>
                              ) : file.status === 'review' ? (
                                <Badge className="bg-amber-50 text-amber-700 border-0 flex items-center gap-1 w-fit">
                                  <ClipboardCheck className="h-3 w-3" /> {tSrc('status.review')}
                                </Badge>
                              ) : file.status === 'pending' ? (
                                <Badge className="bg-yellow-50 text-yellow-700 border-0 flex items-center gap-1 w-fit">
                                  <Loader2 className="h-3 w-3 animate-spin" /> {tSrc('status.pending')}
                                </Badge>
                              ) : (
                                <Badge className="bg-[var(--color-success-light)] text-[var(--color-success)] border-0 flex items-center gap-1 w-fit">
                                  <CheckCircle2 className="h-3 w-3" /> {tSrc('status.done')}
                                </Badge>
                              )}
                            </td>
                            <td className="py-3.5 text-right">
                              <div className="flex items-center justify-end gap-1">
                                {file.status === 'review' && (
                                  <Button
                                    size="sm"
                                    className="bg-amber-500 hover:bg-amber-600 text-white flex items-center gap-1"
                                    onClick={() => openReview(file)}
                                    disabled={reviewFileId === file.id}
                                  >
                                    {reviewFileId === file.id ? (
                                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                    ) : (
                                      <ClipboardCheck className="h-3.5 w-3.5" />
                                    )}
                                    {tAct('validate')}
                                  </Button>
                                )}
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="text-[var(--color-danger)] hover:text-[var(--color-danger)] hover:bg-red-50"
                                  onClick={() => handleDeleteFile(file.id)}
                                  disabled={deletingFileId === file.id}
                                >
                                  {deletingFileId === file.id ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <Trash2 className="h-4 w-4" />
                                  )}
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </Card>
            </div>

            {/* Sidebar info */}
            <div className="col-span-12 lg:col-span-1 space-y-6">
              <Card className="p-5 border-[var(--color-border)] shadow-[var(--shadow-card)] space-y-4">
                <h4 className="text-sm font-semibold text-[var(--color-text-primary)]">{tSrc('qualityTitle')}</h4>
                <div className="space-y-3 text-xs text-[var(--color-text-secondary)] leading-relaxed">
                  <p>
                    {tSrc('mappingDescription')}
                  </p>
                  <div className="flex gap-2.5 items-start">
                    <CheckCircle2 className="h-4 w-4 text-[var(--color-success)] shrink-0 mt-0.5" />
                    <span>{tSrc('qualityAuto')}</span>
                  </div>
                  <div className="flex gap-2.5 items-start">
                    <AlertTriangle className="h-4 w-4 text-[var(--color-warning)] shrink-0 mt-0.5" />
                    <span><strong>{tSrc('qualityValidationLabel')}</strong> {tSrc('qualityValidation')}</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  )
}
