'use client'

import { useState, useEffect, useMemo, useCallback } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useTranslations } from 'next-intl'
import { displayCountry } from '@/lib/countries'
import { cn } from '@/lib/utils'
import { AppLayout } from '@/components/layout/AppLayout'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Download, Search, Filter, CheckCircle2, AlertCircle, HelpCircle, Loader2, RefreshCw, ListChecks } from 'lucide-react'
import { api } from '@/lib/api'

const PER_PAGE = 20

interface MasterRow {
  id: string
  first_name?: string
  last_name?: string
  email?: string
  company?: string
  phone?: string
  completeness_status?: string
  has_flight?: boolean
  has_hotel?: boolean
  has_transfer?: boolean
  has_activities?: boolean
  attendee_category?: string | null
  job_title?: string | null
  region?: string | null
  // Three different questions that all read as "pays" on an imported sheet:
  // citizenship, where they live, and where the booking was made.
  nationality?: string | null
  country?: string | null
  booking_country?: string | null
  passport_number?: string | null
  dietary_requirements?: string | null
  food_allergy_info?: string | null
  // Operational columns carried by a real client master file
  business_unit?: string | null
  function?: string | null
  vip_status?: string | null
  shirt_size?: string | null
  medical_info?: string | null
  comments?: string | null
  // Outside the programme's own dates (§3). Derived from their own flight,
  // not asked of them: somebody flying home five days after the event is on
  // their own nights whether or not anybody wrote it down.
  own_expense?: boolean
  nights_outside_programme?: number
  arrives_early_days?: number
  stays_late_days?: number
  // Enriched travel details (from master_list_service)
  flight_summary?: string | null
  flight_count?: number
  hotel_name?: string | null
  hotel_checkin?: string | null
  hotel_checkout?: string | null
  hotel_nights_count?: number
  hotel_room_type?: string | null
  transfer_summary?: string | null
  activities_summary?: string | null
  custom?: Record<string, string | null>
  // Point 14: which note category, if any, colours this row — and the
  // colour itself, computed server-side (services/note_service) so this
  // page never has to know the category→colour mapping.
  note_category?: string | null
  note_color?: string | null
  /** What to call the colour: a preset's own name ("Super VIP") when the note
   *  came from one, the category label otherwise. */
  note_label?: string | null
}

// Mirrors services/note_service.CATEGORY_LABELS. Built per render rather than
// as a constant: a constant cannot read the locale. The colour itself always
// comes from the backend (note_color), never computed on this page.
function noteCategoryLabels(
  // Named `translate`, not `t`: this file binds `t` to the `nav` namespace, and
  // a parameter of the same name silently resolved these five keys against it.
  translate: ReturnType<typeof useTranslations>,
): Record<string, string> {
  return {
    general: translate('noteGeneral'),
    accommodation: translate('noteAccommodation'),
    flight: translate('noteFlight'),
    transfer: translate('noteTransfer'),
    activity: translate('noteActivity'),
  }
}

/** Multi-line detail cell: shows the text (pre-wrapped) or a red "manquant" hint. */
/** Nights outside the programme's dates, as a fact rather than a question.
 *
 *  Somebody flying home five days after the event is on their own nights, and
 *  the hotel invoice will say so whether or not anybody wrote it down first.
 *  Shown here, beside the flight it is derived from, so it can be read,
 *  filtered and exported instead of being asked once per person on the
 *  exceptions page. */
function OwnExpenseCell({ row }: { row: MasterRow }) {
  const tML = useTranslations('masterList')
  if (!row.own_expense) return <span className="text-[var(--color-text-secondary)]">—</span>
  const bits: string[] = []
  if (row.arrives_early_days) bits.push(tML('earlyDays', { count: row.arrives_early_days }))
  if (row.stays_late_days) bits.push(tML('lateDays', { count: row.stays_late_days }))
  return (
    <span className="inline-flex flex-col gap-0.5">
      <span className="w-fit rounded-full bg-[var(--color-accent)]/10 px-2 py-0.5 text-[11px] font-semibold text-[var(--color-accent)]">
        {tML('ownExpenseNights', { count: row.nights_outside_programme ?? 0 })}
      </span>
      <span className="text-[11px] text-[var(--color-text-secondary)]">{bits.join(' · ')}</span>
    </span>
  )
}

function DetailCell({ text, missing }: { text?: string | null; missing: string }) {
  if (text && text.trim()) {
    return <span className="block whitespace-pre-line text-[11px] leading-snug text-[var(--color-text-primary)]">{text}</span>
  }
  return <span className="text-[11px] font-semibold text-[var(--color-danger)]">{missing}</span>
}

function StatusPill({ status }: { status?: string }) {
  const cfg =
    status === 'complete' ? { c: 'bg-[var(--color-success-light)] text-[var(--color-success)]', l: 'Complet' }
      : status === 'conflict' ? { c: 'bg-[var(--color-danger-light)] text-[var(--color-danger)]', l: 'Conflit' }
      : { c: 'bg-[var(--color-warning-light)] text-[var(--color-warning)]', l: 'Incomplet' }
  return <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${cfg.c}`}>{cfg.l}</span>
}

export default function MasterListPage() {
  const params = useParams()
  const router = useRouter()
  const locale = params.locale as string
  const eventId = params.eventId as string

  const t = useTranslations('nav')
  const tActions = useTranslations('actions')
  const tML = useTranslations('masterList')
  const tStatus = useTranslations('status')

  const [rows, setRows] = useState<MasterRow[]>([])
  const [customCols, setCustomCols] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState<string | null>(null)
  const [missingFilter, setMissingFilter] = useState<'flight' | 'hotel' | 'transfer' | 'activities' | null>(null)
  // Not a gap like the others — a designation. Kept as its own toggle so it
  // never reads as "something missing" beside four filters that mean exactly
  // that.
  const [ownExpenseOnly, setOwnExpenseOnly] = useState(false)
  const [page, setPage] = useState(1)
  const [isExporting, setIsExporting] = useState(false)
  const [consolidating, setConsolidating] = useState(false)

  useEffect(() => {
    const m = new URLSearchParams(window.location.search).get('missing')
    if (m === 'flight' || m === 'hotel' || m === 'transfer' || m === 'activities') setMissingFilter(m)
  }, [])

  const loadMasterList = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await api.masterList.get(eventId)
      setRows(res.items || [])
      setCustomCols((res as { custom_fields?: string[] }).custom_fields || [])
    } catch (err) {
      setError(err instanceof Error ? err.message : tML('errLoad'))
    } finally {
      setLoading(false)
    }
  }, [eventId])

  useEffect(() => {
    if (eventId) loadMasterList()
  }, [eventId, loadMasterList])

  // "Lancer la consolidation" directly from the database view: trigger a run,
  // poll resiliently until it completes, then reload the consolidated list.
  const handleConsolidate = async () => {
    setConsolidating(true)
    setError(null)
    try {
      const run = await api.consolidation.run(eventId)
      let failures = 0
      for (;;) {
        await new Promise((r) => setTimeout(r, 4000))
        try {
          const updated = await api.consolidation.get(eventId, run.id)
          failures = 0
          // Bug found in the 2026-07-21/22 audit: checked 'done'/'error', values
          // the backend never writes (only 'running' | 'completed' | 'failed') --
          // this loop never broke on a real completion and polled forever.
          if (updated.status === 'completed') break
          if (updated.status === 'failed') {
            setError(tML('errRunFailed'))
            break
          }
        } catch {
          // Transient failure while the worker is busy — keep polling.
          failures += 1
          if (failures > 30) { setError(tML('errTrack')); break }
        }
      }
      await loadMasterList()
    } catch (err) {
      setError(err instanceof Error ? err.message : tML('errStart'))
    } finally {
      setConsolidating(false)
    }
  }

  useEffect(() => { setPage(1) }, [searchQuery, statusFilter, missingFilter, ownExpenseOnly])

  // Counted over every row, not the filtered ones: the toggle has to say how
  // many there are in order to be worth pressing.
  const ownExpenseCount = rows.filter((r) => r.own_expense).length
  const ownExpenseNights = rows.reduce((n, r) => n + (r.nights_outside_programme ?? 0), 0)

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase()
    return rows.filter((r) => {
      if (statusFilter && r.completeness_status !== statusFilter) return false
      if (missingFilter === 'flight' && r.has_flight) return false
      if (missingFilter === 'hotel' && r.has_hotel) return false
      if (missingFilter === 'transfer' && r.has_transfer) return false
      if (missingFilter === 'activities' && r.has_activities) return false
      if (ownExpenseOnly && !r.own_expense) return false
      if (!q) return true
      return [r.first_name, r.last_name, r.email, r.company, r.region, r.attendee_category, r.country, r.job_title, r.phone, ...Object.values(r.custom || {})]
        .some((v) => (v || '').toString().toLowerCase().includes(q))
    })
  }, [rows, searchQuery, statusFilter, missingFilter, ownExpenseOnly])

  const total = filtered.length
  const totalPages = Math.max(1, Math.ceil(total / PER_PAGE))
  const pageRows = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE)
  const startItem = total === 0 ? 0 : (page - 1) * PER_PAGE + 1
  const endItem = Math.min(page * PER_PAGE, total)

  const handleExport = async () => {
    setIsExporting(true)
    setError(null)
    try {
      const exp = await api.exports.create(eventId, '')
      const { signed_url, filename } = await api.exports.getDownloadUrl(exp.id)
      // NOT window.open(): by the time these two awaits resolve, the browser
      // no longer treats this as a direct response to the click — popup
      // blockers silently swallow window.open() here (no console error, no
      // visible feedback: exactly "j'appuie, ça charge, puis rien"). A
      // programmatic <a download> click is recognised as a file download
      // rather than a popup and is not blocked the same way.
      const a = document.createElement('a')
      a.href = signed_url
      a.download = filename || 'master-list.xlsx'
      document.body.appendChild(a)
      a.click()
      a.remove()
    } catch (err) {
      setError(
        err instanceof Error
          ? tML('exportFailedWith', { detail: err.message })
          : tML('exportFailed')
      )
    } finally {
      setIsExporting(false)
    }
  }

  return (
    <AppLayout
      eventId={eventId}
      locale={locale}
    >
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text-primary)] flex items-center gap-2">
              <ListChecks className="h-6 w-6 text-[var(--color-accent)]" />
              {t('masterList')}
            </h1>
            <p className="mt-1 text-sm text-[var(--color-text-secondary)]">
              {loading ? tML('loading') : tML('countLine', { count: rows.length })}
            </p>
          </div>
          <div className="flex items-center gap-2 self-start md:self-auto">
            <Button
              className="bg-[var(--color-accent)] hover:bg-[var(--color-accent)]/90 text-white font-medium flex items-center gap-2 shadow-sm"
              onClick={handleConsolidate}
              disabled={consolidating}
            >
              {consolidating ? <Loader2 className="h-4.5 w-4.5 animate-spin" /> : <RefreshCw className="h-4.5 w-4.5" />}
              {consolidating ? tML('consolidating') : tML('runConsolidation')}
            </Button>
            <Button
              className="bg-[var(--color-cta)] hover:bg-[var(--color-cta)]/90 text-white font-medium flex items-center gap-2 shadow-sm"
              onClick={handleExport}
              disabled={isExporting}
            >
              {isExporting ? <Loader2 className="h-4.5 w-4.5 animate-spin" /> : <Download className="h-4.5 w-4.5" />}
              {isExporting ? tML('generating') : tActions('export')}
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card className="p-4 border-[var(--color-border)] shadow-[var(--shadow-card)] flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-[var(--color-text-secondary)]" />
            <input
              type="text"
              placeholder={tML('searchPlaceholder')}
              className="w-full text-sm rounded-md border border-[var(--color-border)] bg-white pl-9 pr-4 py-2 text-[var(--color-text-primary)] focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex flex-wrap gap-2 w-full md:w-auto items-center">
            <span className="text-xs font-semibold text-[var(--color-text-secondary)] flex items-center gap-1">
              <Filter className="h-3 w-3" /> {tActions('filterLabel')}
            </span>
            {([[tActions('all'), null], [tStatus('complete'), 'complete'], [tStatus('incomplete'), 'incomplete'], [tStatus('conflict'), 'conflict']] as const).map(([label, val]) => (
              <Button
                key={label}
                variant={statusFilter === val ? 'default' : 'outline'}
                size="sm"
                className={statusFilter === val ? 'bg-[var(--color-accent)] text-white border-0' : 'text-xs border-[var(--color-border)]'}
                onClick={() => setStatusFilter(val)}
              >
                {label}
              </Button>
            ))}
          </div>
        </Card>

        {ownExpenseCount > 0 && (
          <button
            type="button"
            onClick={() => setOwnExpenseOnly((v) => !v)}
            className={cn(
              'mb-3 mr-2 inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors',
              ownExpenseOnly
                ? 'border-[var(--color-accent)] bg-[var(--color-accent)] text-white'
                : 'border-[var(--color-border)] bg-white text-[var(--color-text-secondary)]'
            )}
          >
            {tML('ownExpenseFilter', { count: ownExpenseCount, nights: ownExpenseNights })}
          </button>
        )}

        {missingFilter && (
          <div className="flex items-center justify-between gap-3 rounded-lg border border-[var(--color-warning)]/30 bg-[var(--color-warning-light)] px-4 py-2.5 text-sm">
            <span className="font-medium text-[var(--color-text-primary)]">
              {tML('filterLine', { what: tML('missing.' + missingFilter as 'missing.flight'), count: total })}
            </span>
            <button
              onClick={() => { setMissingFilter(null); window.history.replaceState({}, '', window.location.pathname) }}
              className="text-xs font-semibold text-[var(--color-accent)] hover:underline"
            >
              {tML('reset')}
            </button>
          </div>
        )}

        {error && (
          <div className="flex items-center gap-2 rounded-md border border-[var(--color-danger)] bg-red-50 p-4 text-sm text-[var(--color-danger)]">
            <AlertCircle className="h-4 w-4 shrink-0" /><span>{error}</span>
          </div>
        )}

        {/* Detailed master table */}
        {/* What the row colours mean. Built from the rows actually on screen,
            so it lists the codes in use rather than every colour that exists. */}
        {(() => {
          const seen = new Map<string, string>()
          for (const r of filtered) {
            if (r.note_color && !seen.has(r.note_color)) {
              seen.set(r.note_color, r.note_label || noteCategoryLabels(tML)[r.note_category || ''] || tML('noteFallback'))
            }
          }
          if (seen.size === 0) return null
          return (
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-[var(--color-text-secondary)]">
              <span className="font-medium">{tML('colourKey')}</span>
              {[...seen.entries()].map(([color, label]) => (
                <span key={color} className="flex items-center gap-1.5">
                  <span className="h-3 w-3 rounded-sm" style={{ backgroundColor: color }} />
                  {label}
                </span>
              ))}
            </div>
          )
        })()}

        <Card className="border-[var(--color-border)] shadow-[var(--shadow-card)] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1800px] border-collapse text-sm">
              <thead>
                <tr className="border-b border-[var(--color-border)] bg-[var(--color-bg-subtle)] text-left text-xs font-semibold uppercase tracking-wider text-[var(--color-text-secondary)]">
                  <th className="px-3 py-3">{tML('thLastName')}</th>
                  <th className="px-3 py-3">{tML('thFirstName')}</th>
                  <th className="px-3 py-3">{tML('thEmail')}</th>
                  <th className="px-3 py-3">{tML('thCompany')}</th>
                  <th className="px-3 py-3">VIP</th>
                  <th className="px-3 py-3">{tML('thCategory')}</th>
                  <th className="px-3 py-3">{tML('thRegion')}</th>
                  <th className="px-3 py-3">{tML('thNationality')}</th>
                  <th className="px-3 py-3">{tML('thCountry')}</th>
                  <th className="px-3 py-3">{tML('thBookingCountry')}</th>
                  <th className="px-3 py-3 min-w-[210px]">{tML('colFlight')}</th>
                  <th className="px-3 py-3 min-w-[130px]">{tML('thOwnExpense')}</th>
                  <th className="px-3 py-3 min-w-[150px]">{tML('thHotel')}</th>
                  <th className="px-3 py-3 min-w-[180px]">{tML('thTransfer')}</th>
                  <th className="px-3 py-3 min-w-[160px]">{tML('thActivities')}</th>
                  <th className="px-3 py-3 min-w-[140px]">{tML('thDiet')}</th>
                  <th className="px-3 py-3">{tML('thShirtSize')}</th>
                  <th className="px-3 py-3 min-w-[120px]">{tML('thMedical')}</th>
                  {customCols.map((c) => (
                    <th key={c} className="px-3 py-3 min-w-[120px]" title={`Champ personnalisé : ${c}`}>{c}</th>
                  ))}
                  <th className="px-3 py-3">{tML('thStatus')}</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  [...Array(6)].map((_, i) => (
                    <tr key={i} className="border-b border-[var(--color-border)] animate-pulse">
                      {[...Array(18 + customCols.length)].map((__, j) => (
                        <td key={j} className="px-3 py-3"><div className="h-4 rounded bg-gray-100" style={{ width: `${50 + ((j * 13) % 40)}%` }} /></td>
                      ))}
                    </tr>
                  ))
                ) : pageRows.length === 0 ? (
                  <tr><td colSpan={18 + customCols.length} className="py-12 text-center text-sm text-[var(--color-text-secondary)]">{tML('noParticipant')}</td></tr>
                ) : (
                  pageRows.map((r) => {
                    const hotelText = [
                      r.hotel_name,
                      (r.hotel_checkin || r.hotel_checkout) ? `${r.hotel_checkin || '?'} → ${r.hotel_checkout || '?'}` : '',
                      [r.hotel_room_type, r.hotel_nights_count ? tML('nights', { count: r.hotel_nights_count }) : ''].filter(Boolean).join(' · '),
                    ].filter(Boolean).join('\n')
                    const dietText = [r.dietary_requirements, r.food_allergy_info].filter(Boolean).join('\n')
                    // The whole row carries the note's colour, not just an edge:
                    // at this table's width a 4px rule on the far left is
                    // invisible by the time the eye reaches the name. "1F" is
                    // ~12% alpha — reads as a colour, still legible underneath.
                    return (
                    <tr
                      key={r.id}
                      onClick={() => router.push(`/${locale}/events/${eventId}/participants/${r.id}`)}
                      title={r.note_color
                        ? tML('noteTooltip', { label: r.note_label || noteCategoryLabels(tML)[r.note_category || ''] || r.note_category || '' })
                        : undefined}
                      style={r.note_color
                        ? { borderLeft: `4px solid ${r.note_color}`, backgroundColor: `${r.note_color}1F` }
                        : undefined}
                      className={`group border-b border-[var(--color-border)] cursor-pointer align-top transition-colors last:border-0 ${
                        r.note_color ? 'hover:brightness-95' : 'bg-white hover:bg-[var(--color-accent-light)]'
                      }`}
                    >
                      <td className="px-3 py-3 font-medium text-[var(--color-text-primary)]">{r.last_name || '—'}</td>
                      <td className="px-3 py-3 text-[var(--color-text-primary)]">{r.first_name || '—'}</td>
                      <td className="px-3 py-3 text-[var(--color-text-secondary)]">{r.email || <span className="font-semibold text-[var(--color-danger)]">{tML('missing')}</span>}</td>
                      <td className="px-3 py-3 text-[var(--color-text-secondary)]">{r.company || r.business_unit || r.function || '—'}</td>
                      <td className="px-3 py-3 text-[var(--color-text-secondary)]">{r.vip_status || '—'}</td>
                      <td className="px-3 py-3 text-[var(--color-text-secondary)]">{r.attendee_category || '—'}</td>
                      <td className="px-3 py-3 text-[var(--color-text-secondary)]">{r.region || '—'}</td>
                      <td className="px-3 py-3 text-[var(--color-text-secondary)]">{displayCountry(r.nationality, locale) || '—'}</td>
                      <td className="px-3 py-3 text-[var(--color-text-secondary)]">{r.country || '—'}</td>
                      <td className="px-3 py-3 text-[var(--color-text-secondary)]">{r.booking_country || '—'}</td>
                      <td className="px-3 py-3"><DetailCell text={r.flight_summary} missing={tML('noFlight')} /></td>
                      <td className="px-3 py-3"><OwnExpenseCell row={r} /></td>
                      <td className="px-3 py-3"><DetailCell text={hotelText} missing={tML('noHotel')} /></td>
                      <td className="px-3 py-3"><DetailCell text={r.transfer_summary} missing={tML('noTransfer')} /></td>
                      <td className="px-3 py-3"><DetailCell text={r.activities_summary} missing={tML('noActivity')} /></td>
                      <td className="px-3 py-3"><DetailCell text={dietText} missing={tML('notSet')} /></td>
                      <td className="px-3 py-3 text-[var(--color-text-secondary)]">{r.shirt_size || '—'}</td>
                      <td className="px-3 py-3 text-[11px] text-[var(--color-text-secondary)]">{r.medical_info || '—'}</td>
                      {customCols.map((c) => (
                        <td key={c} className="px-3 py-3 text-[11px] text-[var(--color-text-secondary)]">{r.custom?.[c] || '—'}</td>
                      ))}
                      <td className="px-3 py-3"><StatusPill status={r.completeness_status} /></td>
                    </tr>
                    )
                  })
                )}
              </tbody>
            </table>
          </div>

          <div className="p-4 bg-slate-50 border-t border-[var(--color-border)] flex items-center justify-between text-xs text-[var(--color-text-secondary)]">
            <div>{loading ? tActions('loading') : total === 0 ? tML('noParticipant') : tML('showingRange', { from: startItem, to: endItem, total })}</div>
            <div className="flex gap-1.5">
              <Button variant="outline" size="sm" className="h-7 text-xs border-[var(--color-border)]" disabled={page <= 1 || loading} onClick={() => setPage(p => Math.max(1, p - 1))}>{tActions('previous')}</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs border-[var(--color-border)]" disabled={page >= totalPages || loading} onClick={() => setPage(p => Math.min(totalPages, p + 1))}>{tActions('next')}</Button>
            </div>
          </div>
        </Card>

        {/* Legend */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-start gap-2.5 p-3.5 bg-slate-50 rounded-lg border border-[var(--color-border)]">
            <CheckCircle2 className="h-5 w-5 text-[var(--color-success)] shrink-0" />
            <div>
              <h4 className="text-xs font-semibold text-[var(--color-text-primary)]">{tML('legendComplete')}</h4>
              <p className="text-[10px] text-[var(--color-text-secondary)] mt-0.5">{tML('legendCompleteHint')}</p>
            </div>
          </div>
          <div className="flex items-start gap-2.5 p-3.5 bg-slate-50 rounded-lg border border-[var(--color-border)]">
            <AlertCircle className="h-5 w-5 text-[var(--color-warning)] shrink-0" />
            <div>
              <h4 className="text-xs font-semibold text-[var(--color-text-primary)]">{tML('legendIncomplete')}</h4>
              <p className="text-[10px] text-[var(--color-text-secondary)] mt-0.5">{tML('legendIncompleteHint')}</p>
            </div>
          </div>
          <div className="flex items-start gap-2.5 p-3.5 bg-slate-50 rounded-lg border border-[var(--color-border)]">
            <HelpCircle className="h-5 w-5 text-[var(--color-danger)] shrink-0" />
            <div>
              <h4 className="text-xs font-semibold text-[var(--color-text-primary)]">{tML('legendConflict')}</h4>
              <p className="text-[10px] text-[var(--color-text-secondary)] mt-0.5">{tML('legendConflictHint')}</p>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
