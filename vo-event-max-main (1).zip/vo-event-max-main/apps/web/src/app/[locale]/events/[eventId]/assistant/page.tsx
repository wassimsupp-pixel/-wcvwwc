'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { useTranslations } from 'next-intl'
import { localeTag } from '@/lib/dates'
import { useParams } from 'next/navigation'
import { AppLayout } from '@/components/layout/AppLayout'
import { Button } from '@/components/ui/button'
import { Send, Loader2, Sparkles, ChevronDown, RotateCcw, History, Trash2, X } from 'lucide-react'
import { api, type ChatAnswer, type ChatConversationSummary } from '@/lib/api'

interface Turn {
  id: number
  question: string
  answer?: ChatAnswer
}

/** Rows are shown collapsed past this many; the full list always lives on the
 *  page named in the answer's sources. */
const PREVIEW_ROWS = 5

function ResultTable({ rows }: { rows: Record<string, unknown>[] }) {
  const tA = useTranslations('assistant')
  const [expanded, setExpanded] = useState(false)
  if (!rows.length) return null
  const columns = Object.keys(rows[0]).filter((c) => c !== 'id')
  const visible = expanded ? rows : rows.slice(0, PREVIEW_ROWS)
  const hidden = rows.length - visible.length

  const render = (v: unknown) =>
    v === true ? 'oui' : v === false ? 'non' : String(v ?? '—')

  return (
    <div className="mt-3">
      <div className="overflow-x-auto rounded-lg border border-[var(--color-border)]">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-[var(--color-border)]">
              {columns.map((c) => (
                <th key={c} className="px-3 py-2 font-medium text-[var(--color-text-secondary)]">
                  {c.replace(/_/g, ' ')}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {visible.map((row, i) => (
              <tr key={i} className="border-b border-[var(--color-border)] last:border-0">
                {columns.map((c) => (
                  <td key={c} className="px-3 py-2 text-[var(--color-text-primary)]">
                    {render(row[c])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {hidden > 0 && (
        <button
          onClick={() => setExpanded(true)}
          className="mt-2 flex items-center gap-1 text-xs font-medium text-[var(--color-accent)] hover:underline"
        >
          <ChevronDown className="h-3 w-3" />
          {tA('showMore', { count: hidden })}
        </button>
      )}
    </div>
  )
}

export default function AssistantPage() {
  const tA = useTranslations('assistant')
  const params = useParams()
  const locale = params.locale as string
  const eventId = params.eventId as string

  const [turns, setTurns] = useState<Turn[]>([])
  const [input, setInput] = useState('')
  const [asking, setAsking] = useState(false)
  const [suggestions, setSuggestions] = useState<string[]>([])
  // The thread this exchange belongs to. Null until the first answer comes
  // back — and it stays null on a deployment without migration 019, where the
  // browser keeps carrying the history itself exactly as before.
  const [conversationId, setConversationId] = useState<string | null>(null)
  const [threads, setThreads] = useState<ChatConversationSummary[]>([])
  const [showThreads, setShowThreads] = useState(false)
  const [loadingThread, setLoadingThread] = useState(false)
  const bottomRef = useRef<HTMLDivElement | null>(null)
  const inputRef = useRef<HTMLInputElement | null>(null)
  const nextTurnId = useRef(0)

  useEffect(() => {
    let cancelled = false
    api.chat
      .suggestions(eventId)
      .then((s) => { if (!cancelled) setSuggestions(s.questions.slice(0, 4)) })
      .catch(() => { /* chips are a convenience — the input still works */ })
    return () => { cancelled = true }
  }, [eventId])

  const loadThreads = useCallback(async () => {
    try {
      setThreads(await api.chat.conversations(eventId))
    } catch {
      // No history table, or no access. The assistant still answers; only the
      // sidebar is unavailable, and an empty list says that plainly enough.
      setThreads([])
    }
  }, [eventId])

  useEffect(() => { loadThreads() }, [loadThreads])

  useEffect(() => {
    if (turns.length) bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [turns, asking])

  /** Reopen a stored thread. The rows are gone by design — they were
   *  participant data and were never stored — so the answers come back as the
   *  prose that was said, and asking again recomputes the table. */
  const openThread = async (id: string) => {
    setLoadingThread(true)
    setShowThreads(false)
    try {
      const { messages } = await api.chat.transcript(id)
      const restored: Turn[] = []
      for (const message of messages) {
        if (message.role === 'user') {
          nextTurnId.current += 1
          restored.push({ id: nextTurnId.current, question: message.content })
        } else if (restored.length) {
          restored[restored.length - 1].answer = {
            answer: message.content,
            rows: [],
            references: message.row_count
              ? [tA('rowsDropped', { count: message.row_count })]
              : [],
            intent: message.intent,
            answered: message.answered ?? true,
          }
        }
      }
      setTurns(restored)
      setConversationId(id)
    } catch {
      setTurns([])
      setConversationId(null)
    } finally {
      setLoadingThread(false)
    }
  }

  const forgetThread = async (id: string) => {
    try {
      await api.chat.forget(id)
      if (id === conversationId) { setTurns([]); setConversationId(null) }
      await loadThreads()
    } catch {
      /* the row stays; nothing was lost */
    }
  }

  const send = async (question: string) => {
    const q = question.trim()
    if (!q || asking) return
    nextTurnId.current += 1
    const id = nextTurnId.current
    const history = turns.map((t) => ({ question: t.question }))
    setTurns((prev) => [...prev, { id, question: q }])
    setInput('')
    setAsking(true)
    try {
      const answer = await api.chat.ask(eventId, q, history, conversationId)
      setTurns((prev) => prev.map((t) => (t.id === id ? { ...t, answer } : t)))
      if (answer.conversation_id) {
        const isNew = answer.conversation_id !== conversationId
        setConversationId(answer.conversation_id)
        // Refresh the list so a brand-new thread appears in it, and so an
        // existing one moves back to the top.
        loadThreads()
        void isNew
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erreur inconnue.'
      setTurns((prev) =>
        prev.map((t) =>
          t.id === id
            ? { ...t, answer: { answer: message, rows: [], references: [], intent: null, answered: false } }
            : t
        )
      )
    } finally {
      setAsking(false)
      inputRef.current?.focus()
    }
  }

  const isEmpty = turns.length === 0

  return (
    <AppLayout
      eventId={eventId}
      locale={locale}
    >
      <div className="mx-auto flex min-h-[calc(100vh-13rem)] max-w-3xl flex-col">
        {threads.length > 0 && (
          <div className="mb-2 flex items-center justify-end">
            <button
              onClick={() => setShowThreads((v) => !v)}
              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-[var(--color-text-secondary)] transition-colors hover:bg-[var(--color-bg-subtle)]"
            >
              {showThreads ? <X className="h-3.5 w-3.5" /> : <History className="h-3.5 w-3.5" />}
              {showThreads ? tA('close') : tA('threadCount', { count: threads.length })}
            </button>
          </div>
        )}

        {showThreads && (
          <ul className="mb-4 divide-y divide-[var(--color-border)] rounded-xl border border-[var(--color-border)] bg-white">
            {threads.map((thread) => (
              <li key={thread.id} className="flex items-center gap-2 px-3 py-2.5">
                <button
                  onClick={() => openThread(thread.id)}
                  className="min-w-0 flex-1 text-left"
                >
                  <span className="block truncate text-sm text-[var(--color-text-primary)]">
                    {thread.title}
                  </span>
                  <span className="text-[11px] text-[var(--color-text-secondary)]">
                    {thread.questions} question(s)
                    {thread.unanswered > 0 && ` · ${tA('unanswered', { count: thread.unanswered })}`}
                    {thread.updated_at && ` · ${formatDay(thread.updated_at, locale, tA('yesterday'))}`}
                  </span>
                </button>
                <button
                  onClick={() => forgetThread(thread.id)}
                  title={tA('deleteThread')}
                  className="rounded-lg p-1.5 text-[var(--color-text-secondary)] transition-colors hover:bg-[var(--color-bg-subtle)] hover:text-[var(--color-danger)]"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </li>
            ))}
          </ul>
        )}

        {loadingThread ? (
          <div className="flex flex-1 items-center justify-center gap-2 text-sm text-[var(--color-text-secondary)]">
            <Loader2 className="h-4 w-4 animate-spin" />
            {tA('openingThread')}
          </div>
        ) : isEmpty ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-6 px-4 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[var(--color-accent)]/10">
              <Sparkles className="h-6 w-6 text-[var(--color-accent)]" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-[var(--color-text-primary)]">
                {tA('emptyTitle')}
              </h1>
              <p className="mt-1.5 text-sm text-[var(--color-text-secondary)]">
                {tA('emptyHint')}
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              {suggestions.map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  className="rounded-full border border-[var(--color-border)] px-3.5 py-1.5 text-xs text-[var(--color-text-secondary)] transition-colors hover:border-[var(--color-accent)] hover:text-[var(--color-accent)]"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex-1 space-y-6 py-2">
            {turns.map((turn) => (
              <div key={turn.id} className="space-y-3">
                <div className="flex justify-end">
                  <div className="max-w-[85%] rounded-2xl rounded-br-md bg-[var(--color-accent)] px-4 py-2.5 text-sm text-white">
                    {turn.question}
                  </div>
                </div>

                {turn.answer ? (
                  <div className="max-w-[95%]">
                    <p
                      className={
                        // whitespace-pre-wrap: the advisory answers are several
                        // sentences and may carry their own line breaks.
                        'whitespace-pre-wrap text-sm leading-relaxed ' +
                        (turn.answer.answered
                          ? 'text-[var(--color-text-primary)]'
                          : 'text-[var(--color-text-secondary)]')
                      }
                    >
                      {turn.answer.answer}
                    </p>
                    <ResultTable rows={turn.answer.rows} />
                    {turn.answer.references.length > 0 && (
                      <p className="mt-2 text-[11px] text-[var(--color-text-secondary)]">
                        {turn.answer.references.join(' · ')}
                      </p>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-sm text-[var(--color-text-secondary)]">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    {tA('reading')}
                  </div>
                )}
              </div>
            ))}
            <div ref={bottomRef} />
          </div>
        )}

        <div className="sticky bottom-0 bg-[var(--color-bg)] pb-4 pt-3">
          <form
            onSubmit={(e) => { e.preventDefault(); send(input) }}
            className="flex items-center gap-2 rounded-xl border border-[var(--color-border)] bg-white p-1.5 shadow-sm focus-within:border-[var(--color-accent)]"
          >
            <input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={tA('askPlaceholder')}
              disabled={asking}
              maxLength={500}
              autoFocus
              className="flex-1 bg-transparent px-3 py-1.5 text-sm text-[var(--color-text-primary)] outline-none placeholder:text-[var(--color-text-secondary)] disabled:opacity-60"
            />
            {!isEmpty && !asking && (
              <button
                type="button"
                onClick={() => {
                  setTurns([]); setConversationId(null); inputRef.current?.focus()
                }}
                title={tA('newThread')}
                className="rounded-lg p-2 text-[var(--color-text-secondary)] transition-colors hover:bg-[var(--color-bg-subtle)]"
              >
                <RotateCcw className="h-4 w-4" />
              </button>
            )}
            <Button type="submit" disabled={asking || !input.trim()} className="h-9 w-9 shrink-0 rounded-lg p-0">
              {asking ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </form>
        </div>
      </div>
    </AppLayout>
  )
}

/** A short date for the conversation list. Today and yesterday read better as
 *  words: a list where every row says the same date is a list you scan by
 *  time, not by date. */
function formatDay(value: string, locale: string, yesterdayLabel: string): string {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return ''
  const today = new Date()
  const sameDay = (a: Date, b: Date) => a.toDateString() === b.toDateString()
  if (sameDay(date, today)) {
    return date.toLocaleTimeString(localeTag(locale), { hour: '2-digit', minute: '2-digit' })
  }
  const yesterday = new Date(today)
  yesterday.setDate(today.getDate() - 1)
  if (sameDay(date, yesterday)) return yesterdayLabel
  return date.toLocaleDateString(localeTag(locale), { day: '2-digit', month: '2-digit' })
}
