'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useTranslations } from 'next-intl'
import { AppLayout } from '@/components/layout/AppLayout'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { AlertCircle, AlertTriangle, Info, CheckCircle2, UserCheck, ShieldAlert, Sparkles, Loader2, Mail, Phone, Globe, Utensils, Plus, ChevronDown, ChevronRight, ClipboardList, Users, Search, ArrowRight, SlidersHorizontal } from 'lucide-react'
import { api, errorMessage, type Exception } from '@/lib/api'
import type { CohortRow } from '@/components/ui/ConcernedParticipants'
import { RequestMissingInfo } from '@/components/exceptions/RequestMissingInfo'
import { isOverdue } from '@/lib/alerts'
import { MissingEventDates } from '@/components/ui/MissingEventDates'
import { FieldPolicyEditor } from '@/components/ui/FieldPolicyEditor'

// Sub-categories of "Champs manquants" — the actionable editable fiche
// fields. The labels come from the shared `fields` namespace, so a column is
// called the same thing here and on the import screen.
const MISSING_FIELD_META: Record<string, React.ElementType> = {
  first_name: UserCheck,
  email: Mail,
  phone: Phone,
  nationality: Globe,
  dietary_requirements: Utensils,
}
const MISSING_FIELD_ORDER = ['first_name', 'email', 'phone', 'nationality', 'dietary_requirements']

// Coverage exceptions ("208 participants n'ont pas encore d'hébergement") used
// to show that number and nothing else, which is the one thing an organizer
// cannot act on: they need the names. Each dimension maps to the master-list
// flag that identifies the concerned people, and to the page where the gap is
// actually filled.
const COVERAGE_DIMENSIONS: Record<string, { route: string; nav: string }> = {
  has_flight: { route: 'flights', nav: 'flights' },
  has_hotel: { route: 'hotels', nav: 'hotels' },
  has_transfer: { route: 'transfers', nav: 'transfers' },
  has_activities: { route: 'activities', nav: 'activities' },
}

/** Which coverage dimension an exception is about, or null if it isn't one. */
function coverageFlagOf(exc: Exception): string | null {
  const ctx = (exc.context_data || {}) as Record<string, unknown>
  const explicit = ctx.coverage_flag
  if (typeof explicit === 'string' && explicit in COVERAGE_DIMENSIONS) return explicit

  // Exceptions written before context_data carried coverage_flag (2026-08-07)
  // have to be recognised from what they do have. The type settles two of the
  // three; the transfer card is filed under the generic MISSING_REQUIRED_FIELD
  // because the Postgres ENUM has no value for it, so only its wording is
  // left. Order matters — "sans transfert" also contains no other keyword, but
  // hébergement/vol must be tested before the short "vol" substring.
  if (exc.exception_type === 'PARTICIPANT_NO_FLIGHT') return 'has_flight'
  if (exc.exception_type === 'PARTICIPANT_NO_HOTEL') return 'has_hotel'
  if (!ctx.aggregate) return null
  const m = (exc.message || '').toLowerCase()
  if (m.includes('transfert')) return 'has_transfer'
  if (m.includes('hébergement') || m.includes('hôtel') || m.includes('hotel')) return 'has_hotel'
  if (m.includes('activité')) return 'has_activities'
  if (m.includes('vol')) return 'has_flight'
  return null
}

const rowName = (r: CohortRow) => [r.first_name, r.last_name].filter(Boolean).join(' ') || '—'

/**
 * The people behind an aggregated exception, read from the CURRENT master list
 * rather than from the exception's stored id list: that list is a snapshot of
 * the consolidation that produced it, so a participant fixed since would still
 * be named here. When the two disagree, the card says so instead of quietly
 * showing a different number from the one in the message above it.
 */
function ConcernedList({
  rows, snapshotCount, dimension, onOpen,
}: {
  rows: CohortRow[]
  snapshotCount: number | null
  dimension: { noun: string; page: string; route: string }
  onOpen: (id: string) => void
}) {
  const tExc = useTranslations('exceptions')
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')

  const q = query.trim().toLowerCase()
  const shown = q
    ? rows.filter((r) => rowName(r).toLowerCase().includes(q) || (r.company || '').toLowerCase().includes(q))
    : rows

  return (
    <div className="pt-1">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1.5 text-xs font-semibold text-[var(--color-text-primary)] hover:underline"
      >
        {open ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
        <Users className="h-3.5 w-3.5" />
        {open ? tExc('hideConcerned', { count: rows.length }) : tExc('showConcerned', { count: rows.length })}
      </button>

      {open && (
        <div className="mt-2 rounded-lg border border-[var(--color-border)]">
          {snapshotCount !== null && snapshotCount !== rows.length && (
            <p className="border-b bg-[var(--color-bg-subtle)] px-3 py-2 text-[11px] text-[var(--color-text-secondary)]">
              {tExc('snapshotDiffers', { snapshot: snapshotCount, now: rows.length })}
            </p>
          )}
          {rows.length > 8 && (
            <div className="flex items-center gap-2 border-b px-3 py-2">
              <Search className="h-3.5 w-3.5 shrink-0 text-[var(--color-text-secondary)]" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={tExc('searchParticipant')}
                className="w-full bg-transparent text-xs outline-none"
              />
            </div>
          )}
          <div className="max-h-80 divide-y overflow-y-auto">
            {shown.length === 0 ? (
              <p className="px-3 py-3 text-xs text-[var(--color-text-secondary)]">
                {rows.length === 0
                  ? tExc('nobodyLeft', { what: dimension.noun })
                  : tExc('noMatch', { term: query })}
              </p>
            ) : (
              shown.map((r) => (
                <div key={r.id} className="flex items-center justify-between gap-3 px-3 py-2">
                  <span className="min-w-0 truncate text-sm text-[var(--color-text-primary)]">
                    {rowName(r)}
                    {r.company && (
                      <span className="ml-2 text-xs text-[var(--color-text-secondary)]">{r.company}</span>
                    )}
                  </span>
                  <Button
                    size="sm"
                    className="h-8 shrink-0 bg-[var(--color-accent)] text-xs text-white hover:bg-[var(--color-accent)]/90"
                    onClick={() => onOpen(r.id)}
                  >
                    <Plus className="mr-1 h-3.5 w-3.5" /> {tExc('fill')}
                  </Button>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default function ExceptionsPage() {
  const params = useParams()
  const router = useRouter()
  const locale = params.locale as string
  const eventId = params.eventId as string

  const t = useTranslations('nav')
  const tExc = useTranslations('exceptions')
  const tf = useTranslations('fields')
  const tAct = useTranslations('actions')

  // Written out one by one rather than looked up on a built key: check-i18n
  // resolves a literal, and a badge that renders its own key path in Dutch is
  // the failure this page is least able to absorb.
  const EXC_TYPE_LABELS: Record<string, string> = {
    conflict: tExc('type.conflict'),
    DATA_CONFLICT: tExc('type.conflict'),
    duplicate: tExc('type.duplicate'),
    POSSIBLE_DUPLICATE: tExc('type.duplicate'),
    DUPLICATE_EMAIL: tExc('type.duplicateEmail'),
    not_found: tExc('type.notFound'),
    to_verify: tExc('type.toVerify'),
    PARTICIPANT_NO_FLIGHT: tExc('type.noFlight'),
    PARTICIPANT_NO_HOTEL: tExc('type.noHotel'),
    PARTICIPANT_NO_TRANSFER: tExc('type.noTransfer'),
    PARTICIPANT_NO_DIETARY: tExc('type.noDietary'),
    MISSING_CONTACT: tExc('type.noContact'),
    MISSING_REQUIRED_FIELD: tExc('type.missingField'),
    INVALID_FORMAT: tExc('type.invalidFormat'),
    DATE_INCOHERENCE: tExc('type.dateIncoherence'),
    FLIGHT_NO_PARTICIPANT: tExc('type.flightNoParticipant'),
    NAME_DIVERGENCE: tExc('type.nameDivergence'),
    PROBABLE_MATCH: tExc('type.probableMatch'),
    coverage: tExc('type.coverage'),
  }

  // What the exception is actually ABOUT, when the type cannot say it.
  //
  // The Postgres ENUM has no value for "has a flight but nobody is meeting
  // them", so the backend files half the travel checks (§18) under the
  // catch-all MISSING_REQUIRED_FIELD. Rendering that enum literally produced
  // cards whose badge said "Champ requis manquant" directly above a sentence
  // about a missing transfer — the badge contradicting the message is worse
  // than no badge. The real subject has always been in context_data.category.
  const EXC_CATEGORY_LABELS: Record<string, string> = {
    flight_without_transfer: tExc('cat.flightWithoutTransfer'),
    transfer_not_assigned: tExc('cat.transferNotAssigned'),
    capacity_exceeded: tExc('cat.capacityExceeded'),
    flight_conflict: tExc('cat.flightConflict'),
    flight_reversed: tExc('cat.flightReversed'),
    missing_return_flight: tExc('cat.missingReturnFlight'),
    staying_own_expense: tExc('cat.stayingOwnExpense'),
    flight_changed: tExc('cat.flightChanged'),
    accommodation_mismatch: tExc('cat.accommodationMismatch'),
    roommate: tExc('cat.roommate'),
    missing_field: tExc('cat.missingField'),
  }

  const missingFieldLabel: Record<string, string> = {
    first_name: tf('first_name'),
    email: tf('email'),
    phone: tf('phone'),
    nationality: tf('nationality'),
    dietary_requirements: tf('dietary_requirements'),
  }

  // Field names as they appear inside a stored conflict message.
  const conflictFieldLabel: Record<string, string> = {
    nationality: tf('nationality'),
    company: tf('company'),
    phone: tf('phone'),
    email: tf('email'),
  }

  /**
   * An exception's message, including the ones written in English before the
   * backend was translated.
   *
   * The message is STORED on the row at consolidation time, so translating
   * the generator only fixes exceptions produced after it — every card
   * already in the table keeps its English text until a new run replaces it.
   * Rewriting the few known templates here means the screen reads correctly
   * today, without touching a single stored row.
   *
   * Anything that does not match a template is returned untouched: a message
   * this does not recognise is far better shown as-is than mangled.
   */
  const excMessage = (exc: Exception): string => {
    const raw = exc.message || ''

    const conflict = raw.match(
      /^Participant '(.+?)' has conflicting data between registration and FCM: (.+)$/
    )
    if (conflict) {
      const details = conflict[2].replace(
        /(\w+): '([^']*)' vs '([^']*)'/g,
        (_m, field, a, b) => `${conflictFieldLabel[field] ?? field} : « ${a} » / « ${b} »`
      )
      return tExc('msgConflict', { name: conflict[1], details })
    }

    const probable = raw.match(
      /^FCM record '(.+?)' was probably matched to participant '(.+?)' \(score=([\d.]+)\)\.\s*Please verify\.$/
    )
    if (probable) {
      return tExc('msgProbable', { ticket: probable[1], name: probable[2], score: probable[3] })
    }

    const unmatched = raw.match(
      /^FCM record for '(.+?)' could not be matched to any registered participant\.$/
    )
    if (unmatched) {
      return tExc('msgUnmatched', { ticket: unmatched[1] })
    }

    const noContact = raw.match(/^Participant '(.+?)' has no email and no phone number\.$/)
    if (noContact) {
      return tExc('msgNoContact', { name: noContact[1] })
    }

    return raw
  }

  /** The badge for one exception: its category when it has one, its type otherwise. */
  const excLabel = (exc: Exception): string => {
    const category = (exc.context_data as Record<string, unknown> | null)?.category
    if (typeof category === 'string' && EXC_CATEGORY_LABELS[category]) {
      return EXC_CATEGORY_LABELS[category]
    }
    const key = exc.exception_type ?? exc.type
    return EXC_TYPE_LABELS[key] || key
  }

  /** A coverage dimension, named for the reader: what is missing, and where to fix it. */
  const coverageNoun: Record<string, string> = {
    has_flight: tExc('dim.flight'),
    has_hotel: tExc('dim.hotel'),
    has_transfer: tExc('dim.transfer'),
    has_activities: tExc('dim.activity'),
  }
  const coveragePage: Record<string, string> = {
    has_flight: t('flights'),
    has_hotel: t('hotels'),
    has_transfer: t('transfers'),
    has_activities: t('activities'),
  }

  // Optional deep-link filter, e.g. /exceptions?type=conflict from the dashboard.
  // Read from window on mount to avoid a static-prerender bail-out on useSearchParams.
  type ExceptionType = 'conflict' | 'duplicate' | 'not_found' | 'to_verify' | 'coverage' | 'missing_field' | 'mapping_health' | 'flight' | 'transfer'
  const validTypes: ExceptionType[] = ['mapping_health', 'conflict', 'flight', 'transfer', 'duplicate', 'not_found', 'to_verify', 'coverage', 'missing_field']
  const [typeFilter, setTypeFilter] = useState<ExceptionType | null>(null)
  const [openSubs, setOpenSubs] = useState<Record<string, boolean>>({})

  useEffect(() => {
    const rawType = new URLSearchParams(window.location.search).get('type')
    if (validTypes.includes(rawType as ExceptionType)) {
      // Reading a URL query param once on mount is a legitimate one-off sync.
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setTypeFilter(rawType as ExceptionType)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const typeLabels: Record<ExceptionType, string> = {
    mapping_health: tExc('type.mappingHealth'),
    conflict: tExc('conflict'),
    duplicate: tExc('duplicate'),
    not_found: tExc('notFound'),
    to_verify: tExc('toCheck'),
    coverage: tExc('coverage'),
    missing_field: tExc('type.missingFields'),
    flight: t('flights'),
    transfer: t('transfers'),
  }

  const [exceptions, setExceptions] = useState<Exception[]>([])
  const [masterRows, setMasterRows] = useState<CohortRow[]>([])
  // Fixed at load time so every card is aged against the same instant —
  // and so no render reads the clock (react-hooks/purity).
  const [loadedAt, setLoadedAt] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [resolving, setResolving] = useState<string | null>(null)
  const [activeResolve, setActiveResolve] = useState<Exception | null>(null)
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  // Which fields this event insists on. Closed by default: it answers
  // "why is this an alert?", a question nobody asks until they have one.
  const [showPolicy, setShowPolicy] = useState(false)

  const loadExceptions = async () => {
    try {
      setLoading(true)
      // The master list resolves aggregated exceptions into actual people. It
      // is fetched alongside, not instead: if it fails, the exceptions still
      // render — they just lose the expandable list.
      const [data, master] = await Promise.all([
        api.exceptions.list(eventId),
        api.participants.coverage(eventId).catch(() => ({ items: [] as CohortRow[] })),
      ])
      setExceptions(data.filter(e => !e.resolved))
      setLoadedAt(Date.now())
      setMasterRows((master.items as CohortRow[]) || [])
    } catch {
      setError(tExc('errLoad'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadExceptions()
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventId])

  const handleResolveConflict = async (resolution: string) => {
    if (!activeResolve) return

    setResolving(activeResolve.id)
    try {
      await api.exceptions.resolve(activeResolve.id, resolution)
      setSuccessMessage(tExc('conflictResolved', { name: activeResolve.participant_name ?? activeResolve.id, value: resolution }))
      setTimeout(() => setSuccessMessage(null), 3000)
      setActiveResolve(null)
      await loadExceptions()
    } catch (err) {
      setError(errorMessage(err, tExc('errResolveConflict')))
    } finally {
      setResolving(null)
    }
  }

  const handleResolveSimple = async (exc: Exception) => {
    setResolving(exc.id)
    try {
      await api.exceptions.resolve(exc.id, 'resolved')
      setSuccessMessage(tExc('markedResolved'))
      setTimeout(() => setSuccessMessage(null), 3000)
      await loadExceptions()
    } catch (err) {
      setError(errorMessage(err, tExc('errResolve')))
    } finally {
      setResolving(null)
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertCircle className="h-5 w-5 text-[var(--color-danger)]" />
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-[var(--color-warning)]" />
      default:
        return <Info className="h-5 w-5 text-[var(--color-text-secondary)]" />
    }
  }

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'critical':
        return (
          <Badge className="bg-[var(--color-danger-light)] text-[var(--color-danger)] border-0">
            {tExc('sevCritical')}
          </Badge>
        )
      case 'warning':
        return (
          <Badge className="bg-[var(--color-warning-light)] text-[var(--color-warning)] border-0">
            {tExc('sevWarning')}
          </Badge>
        )
      default:
        return (
          <Badge className="bg-slate-100 text-slate-600 border-0">
            {tExc('sevInfo')}
          </Badge>
        )
    }
  }

  const filteredExceptions = typeFilter
    ? exceptions.filter((e) => e.type === typeFilter)
    : exceptions

  // "Champs manquants" get a dedicated grouped-by-field rendering (one row per
  // participant with an "Ajouter" button). Everything else stays a flat list,
  // suspected mapping anomalies first — they usually explain the OTHER cards
  // (300 missing nationalities is one bad column, not 300 problems), so the
  // reader must see them before wading into the noise they generated.
  const missingFieldExcs = filteredExceptions.filter((e) => e.type === 'missing_field')
  const SEVERITY_RANK: Record<string, number> = { critical: 0, warning: 1, info: 2 }
  const flatExcs = filteredExceptions
    .filter((e) => e.type !== 'missing_field')
    .sort((a, b) =>
      (a.type === 'mapping_health' ? -1 : 0) - (b.type === 'mapping_health' ? -1 : 0)
      // An alert that stopped moving outranks a fresher one of equal gravity:
      // it is the one nobody is dealing with.
      || (isOverdue(b, loadedAt) ? 1 : 0) - (isOverdue(a, loadedAt) ? 1 : 0)
      || (SEVERITY_RANK[a.severity] ?? 3) - (SEVERITY_RANK[b.severity] ?? 3)
    )
  const missingBySub: Record<string, Exception[]> = {}
  for (const f of MISSING_FIELD_ORDER) missingBySub[f] = []
  for (const e of missingFieldExcs) {
    const mf = (e.context_data?.missing_fields as string[] | undefined) || []
    for (const f of mf) if (missingBySub[f]) missingBySub[f].push(e)
  }
  const goToParticipant = (pid?: string, field?: string) => {
    if (!pid) return
    router.push(`/${locale}/events/${eventId}/participants/${pid}${field ? `?field=${field}` : ''}`)
  }

  return (
    <AppLayout
      eventId={eventId}
      locale={locale}
    >
      <div className="space-y-6">
        {/* Some checks on this page cannot run without the programme's dates.
            Silence is correct there; silence with no explanation is not. */}
        <MissingEventDates eventId={eventId} locale={locale} />
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text-primary)] flex items-center gap-2">
            <AlertTriangle className="h-6 w-6 text-[var(--color-accent)]" />
            {t('exceptions')}
          </h1>
          <p className="mt-1 text-sm text-[var(--color-text-secondary)]">
            {loading ? '…' : tExc('countLine', { count: filteredExceptions.length })}
          </p>
        </div>

        {/* Every card on this page exists because some field is marked
            required. That rule was reachable only through the API — the
            editor was written, wired, and mounted nowhere — so an organizer
            reading an alert they consider normal had no way to say so. It
            belongs next to the alerts it produces, and per event rather than
            in global settings: whether a blank diet is a gap depends on
            whether THIS event serves a plated dinner. */}
        <div>
          <button
            onClick={() => setShowPolicy((v) => !v)}
            className="flex items-center gap-2 rounded-lg border border-[var(--color-border)] bg-white px-3 py-2 text-sm text-[var(--color-text-secondary)]"
          >
            <SlidersHorizontal className="h-4 w-4" />
            {tExc('whatWeAskFor')}
            {showPolicy ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </button>
          {showPolicy && (
            <div className="mt-3">
              <FieldPolicyEditor eventId={eventId} />
            </div>
          )}
        </div>

        {/* Type filter (deep-linkable from the dashboard) */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setTypeFilter(null)}
            className={
              'rounded-full px-3 py-1 text-xs font-semibold transition-colors ' +
              (typeFilter === null
                ? 'bg-[var(--color-accent)] text-white'
                : 'border border-[var(--color-border)] text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-subtle)]')
            }
          >
            {tExc('filterAll')}
          </button>
          {validTypes.map((vt) => (
            <button
              key={vt}
              onClick={() => setTypeFilter(vt)}
              className={
                'rounded-full px-3 py-1 text-xs font-semibold transition-colors ' +
                (typeFilter === vt
                  ? 'bg-[var(--color-accent)] text-white'
                  : 'border border-[var(--color-border)] text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-subtle)]')
              }
            >
              {typeLabels[vt]}
            </button>
          ))}
        </div>

        {/* §14 — the exceptions above are gaps; this turns them into questions.
            Placed here rather than per-card on purpose: one person with three
            gaps must receive one email, not three. */}
        <RequestMissingInfo eventId={eventId} onCreated={loadExceptions} />

        {successMessage && (
          <div className="flex items-center gap-2 p-4 rounded-lg bg-[var(--color-success-light)] border border-[var(--color-success)]/20 text-[var(--color-success)] text-sm font-medium animate-fade-in">
            <CheckCircle2 className="h-5 w-5 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {error && (
          <div className="flex items-center gap-2 p-4 rounded-lg bg-[var(--color-danger-light)] border border-[var(--color-danger)]/20 text-[var(--color-danger)] text-sm font-medium">
            <AlertCircle className="h-5 w-5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div className="grid grid-cols-12 gap-6">
          {/* Main Exceptions List */}
          <div className="col-span-12 lg:col-span-8 space-y-4">
            {loading ? (
              <Card className="p-8 border-[var(--color-border)] shadow-[var(--shadow-card)] bg-white flex items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-[var(--color-accent)]" />
              </Card>
            ) : filteredExceptions.length === 0 ? (
              <Card className="p-8 text-center border-[var(--color-border)] shadow-[var(--shadow-card)] flex flex-col items-center justify-center space-y-3 bg-white">
                <div className="h-12 w-12 rounded-full bg-[var(--color-success-light)] flex items-center justify-center">
                  <CheckCircle2 className="h-6 w-6 text-[var(--color-success)]" />
                </div>
                <h3 className="font-semibold text-sm text-[var(--color-text-primary)]">{tExc('allClearTitle')}</h3>
                <p className="text-xs text-[var(--color-text-secondary)]">{tExc('allClearBody')}</p>
              </Card>
            ) : (
              <>
              {/* Champs manquants — grouped by field, each with an "Ajouter" button */}
              {missingFieldExcs.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <ClipboardList className="h-5 w-5 text-[var(--color-accent)]" />
                    <h2 className="text-sm font-bold text-[var(--color-text-primary)]">{tExc('type.missingFields')}</h2>
                    <span className="text-xs text-[var(--color-text-secondary)]">
                      {tExc('missingFieldsHint')}
                    </span>
                  </div>
                  {MISSING_FIELD_ORDER.filter((f) => missingBySub[f].length > 0).map((f) => {
                    const Icon = MISSING_FIELD_META[f]
                    const items = missingBySub[f]
                    const open = openSubs[f] ?? true
                    return (
                      <Card key={f} className="overflow-hidden border-[var(--color-border)] shadow-[var(--shadow-card)] bg-white p-0">
                        <button
                          onClick={() => setOpenSubs((s) => ({ ...s, [f]: !(s[f] ?? true) }))}
                          className="flex w-full items-center justify-between px-5 py-3 hover:bg-slate-50"
                        >
                          <span className="flex items-center gap-2 text-sm font-semibold text-[var(--color-text-primary)]">
                            <Icon className="h-4 w-4 text-[var(--color-accent)]" />
                            {missingFieldLabel[f]}
                            <Badge className="bg-[var(--color-accent-light)] text-[var(--color-accent)] border-0">{items.length}</Badge>
                          </span>
                          {open ? <ChevronDown className="h-4 w-4 text-[var(--color-text-secondary)]" /> : <ChevronRight className="h-4 w-4 text-[var(--color-text-secondary)]" />}
                        </button>
                        {open && (
                          <div className="divide-y border-t">
                            {items.map((e) => (
                              <div key={e.id} className="flex items-center justify-between gap-3 px-5 py-2.5">
                                <span className="text-sm text-[var(--color-text-primary)] truncate">
                                  {e.participant_name || (e.context_data?.participant_name as string) || '—'}
                                </span>
                                <Button
                                  size="sm"
                                  className="h-8 shrink-0 bg-[var(--color-accent)] text-white hover:bg-[var(--color-accent)]/90 text-xs"
                                  onClick={() => goToParticipant(e.participant_id, f)}
                                >
                                  <Plus className="mr-1 h-3.5 w-3.5" /> {tExc('fill')}
                                </Button>
                              </div>
                            ))}
                          </div>
                        )}
                      </Card>
                    )
                  })}
                </div>
              )}

              {/* Flat list for all other exception types */}
              {flatExcs.map((exc) => {
                const flag = coverageFlagOf(exc)
                const dimension = flag
                  ? { ...COVERAGE_DIMENSIONS[flag], noun: coverageNoun[flag], page: coveragePage[flag] }
                  : null
                // The card's OWN list first, narrowed to people still on the
                // event. Filtering the master list by the coverage flag alone
                // answers a wider question than the card asked: "1 participant
                // sur 65 a un vol sans aucun transfert" came with a link
                // reading "Voir les 18 participants concernés", because 18 is
                // everybody without a transfert and 1 is the intersection the
                // card is actually about.
                const named = Array.isArray(exc.context_data?.participant_ids)
                  ? new Set((exc.context_data!.participant_ids as string[]).map(String))
                  : null
                const concerned = named
                  ? masterRows.filter((r) => named.has(String(r.id)))
                  : flag
                  ? masterRows.filter((r) => !r[flag as keyof CohortRow])
                  : []
                const snapshotCount = typeof exc.context_data?.count === 'number'
                  ? (exc.context_data.count as number)
                  : null
                return (
                <Card
                  key={exc.id}
                  className="p-5 border-[var(--color-border)] shadow-[var(--shadow-card)] hover:border-slate-300 transition-all bg-white flex items-start gap-4"
                >
                  <div className="mt-0.5">{getSeverityIcon(exc.severity)}</div>
                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      {/* The category before the raw type. `exception_type`
                          is an ENUM the database constrains, so a stay outside
                          the programme dates is stored as
                          MISSING_REQUIRED_FIELD and was headed "Champ requis
                          manquant" — which is not what it is, and is the
                          opposite of the point: nothing is missing, somebody
                          is paying for their own nights. */}
                      <h3 className="text-sm font-semibold text-[var(--color-text-primary)] truncate">
                        {exc.participant_name ?? excLabel(exc)}
                      </h3>
                      {getSeverityBadge(exc.severity)}
                      {isOverdue(exc, loadedAt) && (
                        <Badge className="border-0 bg-[var(--color-warning-light)] text-[var(--color-warning)]">
                          {tExc('overdueBadge')}
                        </Badge>
                      )}
                      {/* Only when it adds something: with no participant name
                          the title already falls back to this same label, and
                          a card headed "Conflit de données" with a badge that
                          repeats it says one thing twice. */}
                      {excLabel(exc) !== (exc.participant_name ?? excLabel(exc)) && (
                        <Badge variant="outline" className="text-[10px] border-slate-200">
                          {excLabel(exc)}
                        </Badge>
                      )}
                    </div>

                    <p className="text-xs text-[var(--color-text-secondary)] font-medium leading-relaxed">
                      {excMessage(exc)}
                    </p>

                    {dimension && masterRows.length > 0 && (
                      <ConcernedList
                        rows={concerned}
                        snapshotCount={snapshotCount}
                        dimension={dimension}
                        onOpen={(pid) => goToParticipant(pid)}
                      />
                    )}

                    <div className="pt-2 flex items-center gap-2">
                      {dimension && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-xs h-8 border-[var(--color-border)]"
                          onClick={() => router.push(`/${locale}/events/${eventId}/${dimension.route}`)}
                        >
                          {tExc('goToPage', { page: dimension.page })} <ArrowRight className="ml-1.5 h-3.5 w-3.5" />
                        </Button>
                      )}
                      {exc.type === 'conflict' && exc.value_a !== undefined && exc.value_b !== undefined ? (
                        <Button
                          size="sm"
                          className="bg-[var(--color-accent)] hover:bg-[var(--color-accent)]/90 text-white text-xs h-8"
                          onClick={() => setActiveResolve(exc)}
                          disabled={resolving === exc.id}
                        >
                          {resolving === exc.id ? (
                            <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />
                          ) : (
                            <Sparkles className="h-3.5 w-3.5 mr-1.5" />
                          )}
                          {tExc('resolveTitle')}
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-xs h-8 border-[var(--color-border)]"
                          onClick={() => handleResolveSimple(exc)}
                          disabled={resolving === exc.id}
                        >
                          {resolving === exc.id ? (
                            <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />
                          ) : (
                            <CheckCircle2 className="h-3.5 w-3.5 mr-1.5" />
                          )}
                          {tExc('markResolved')}
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
                )
              })}
              </>
            )}
          </div>

          {/* Right Panel: Resolution details */}
          <div className="col-span-12 lg:col-span-4 space-y-6">
            {activeResolve ? (
              <Card className="p-5 border-[var(--color-accent)] shadow-[var(--shadow-card)] bg-white space-y-5">
                <div className="border-b pb-3 flex items-start gap-2">
                  <ShieldAlert className="h-5 w-5 text-[var(--color-accent)] mt-0.5 shrink-0" />
                  <div>
                    <h3 className="text-sm font-semibold text-[var(--color-text-primary)]">
                      {tExc('resolveTitle')}
                    </h3>
                    <p className="text-[10px] text-[var(--color-text-secondary)] mt-0.5">
                      {tExc('resolveHint')}
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="text-xs text-[var(--color-text-primary)]">
                    {tExc('participantLabel')} <strong className="font-semibold">{activeResolve.participant_name ?? '\u2014'}</strong>
                  </div>

                  <div className="space-y-3">
                    <div
                      className="rounded-md border p-3 bg-slate-50 space-y-2 hover:border-[var(--color-accent)] cursor-pointer"
                      onClick={() => handleResolveConflict(activeResolve.value_a || '')}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                          {activeResolve.source_a ?? tExc('sourceA')}
                        </span>
                        <Badge className="bg-slate-200 text-slate-700 hover:bg-slate-200/90 text-[9px]">{tExc('keep')}</Badge>
                      </div>
                      <div className="text-sm font-bold text-[var(--color-text-primary)]">
                        {activeResolve.value_a}
                      </div>
                    </div>

                    <div
                      className="rounded-md border p-3 bg-slate-50 space-y-2 hover:border-[var(--color-accent)] cursor-pointer"
                      onClick={() => handleResolveConflict(activeResolve.value_b || '')}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                          {activeResolve.source_b ?? tExc('sourceB')}
                        </span>
                        <Badge className="bg-slate-200 text-slate-700 hover:bg-slate-200/90 text-[9px]">{tExc('keep')}</Badge>
                      </div>
                      <div className="text-sm font-bold text-[var(--color-text-primary)]">
                        {activeResolve.value_b}
                      </div>
                    </div>
                  </div>

                  <div className="text-[10px] text-[var(--color-text-secondary)] leading-relaxed">
                    {tExc('resolveLockHint')}
                  </div>
                </div>

                <Button variant="outline" size="sm" className="w-full text-xs h-9 border-[var(--color-border)]" onClick={() => setActiveResolve(null)}>
                  {tAct('close')}
                </Button>
              </Card>
            ) : (
              <Card className="p-5 border-[var(--color-border)] shadow-[var(--shadow-card)] bg-white space-y-4">
                <h4 className="text-sm font-semibold text-[var(--color-text-primary)]">{tExc('instructions')}</h4>
                <div className="space-y-3 text-xs text-[var(--color-text-secondary)] leading-relaxed">
                  <p>
                    {tExc('instructionsBody')}
                  </p>
                  <div className="flex gap-2 items-start">
                    <UserCheck className="h-4 w-4 text-[var(--color-accent)] shrink-0" />
                    <span><strong>{tExc('nothingLostLabel')}</strong> {tExc('nothingLost')}</span>
                  </div>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
