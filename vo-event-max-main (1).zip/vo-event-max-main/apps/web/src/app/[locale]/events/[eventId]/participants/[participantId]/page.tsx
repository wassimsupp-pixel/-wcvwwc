'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useTranslations } from 'next-intl'
import { AppLayout } from '@/components/layout/AppLayout'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Lock, Unlock, ArrowLeft, Save, User, Clock, FileText, CheckCircle2, Loader2, Plane, Hotel, Bus, Sparkles, Database, Mail, Send, AlertTriangle, PartyPopper } from 'lucide-react'
import { api, errorMessage } from '@/lib/api'
import { formatDateOnly, formatScheduleTime } from '@/lib/dates'
import type { Participant } from '@/lib/api'
import { ParticipantNotes } from '@/components/ui/ParticipantNotes'
import { ParticipantAttachments } from '@/components/ui/ParticipantAttachments'
import { ExtensionRequestBanner } from '@/components/ui/ExtensionRequestBanner'

interface ConsolidatedView {
  flights: any[]
  transfers: any[]
  hotel_nights: any[]
  activities: any[]
  source_records: any[]
}

const EDITABLE_FIELDS = ['first_name', 'last_name', 'email', 'company', 'phone', 'nationality', 'dietary_requirements']

export default function ParticipantDetailPage() {
  const params = useParams()
  const router = useRouter()
  const locale = params.locale as string
  const eventId = params.eventId as string
  const participantId = params.participantId as string

  const tp = useTranslations('participantDetail')
  const tf = useTranslations('fields')
  const tAct = useTranslations('actions')

  // Same wording as the master list's "sources utilisées" column, so the fiche
  // and the table never name the same file differently.
  const SOURCE_LABELS: Record<string, string> = {
    registration: tp('src.registration'),
    fcm: tp('src.fcm'),
    hotel: tp('src.hotel'),
    transfer: tp('src.transfer'),
    activity: tp('src.activity'),
    email: tp('src.email'),
    masterfile: tp('src.masterfile'),
    other: tp('src.other'),
  }

  const [participant, setParticipant] = useState<Participant | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [lockedFields, setLockedFields] = useState<Record<string, boolean>>({})
  const [isSaved, setIsSaved] = useState(false)
  const [consolidated, setConsolidated] = useState<ConsolidatedView | null>(null)

  // Individual confirmation (§13 + Lettre individuelle)
  const [confirmation, setConfirmation] = useState<{
    subject: string; body: string; missing: string[]; source: string; commId: string | null; persisted: boolean
  } | null>(null)
  const [genConfirm, setGenConfirm] = useState(false)
  const [pdfBusy, setPdfBusy] = useState(false)
  const [confirmMsg, setConfirmMsg] = useState<string | null>(null)
  // In-flight guards: without these, double-clicking "Marquer comme envoyé"
  // fires api.communications.send() twice concurrently -- sending the
  // confirmation email to the participant twice.
  const [savingConfirm, setSavingConfirm] = useState(false)
  const [sendingConfirm, setSendingConfirm] = useState(false)

  useEffect(() => {
    async function load() {
      try {
        setLoading(true)
        const data = await api.participants.get(participantId)
        setParticipant(data)
        const locks: Record<string, boolean> = {}
        EDITABLE_FIELDS.forEach(f => { locks[f] = data.locked_fields.includes(f) })
        setLockedFields(locks)
      } catch {
        setError(tp('errLoad'))
      } finally {
        setLoading(false)
      }
      // Consolidated view is best-effort — don't block the profile if it fails
      try {
        setConsolidated(await api.participants.getConsolidated(participantId))
      } catch {
        /* ignore */
      }
    }
    if (participantId) load()
  // `tp` is stable per locale; listing it keeps the failure message in the
  // language the reader switched to.
  }, [participantId, tp])

  // Deep-link from the "Champs manquants" exceptions: ?field=email focuses and
  // highlights that input so the user lands right on the field to fill.
  useEffect(() => {
    if (!participant) return
    const field = new URLSearchParams(window.location.search).get('field')
    if (!field) return
    const timer = setTimeout(() => {
      const el = document.querySelector(`input[name="${field}"]`) as HTMLInputElement | null
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' })
        el.focus()
        el.classList.add('ring-2', 'ring-[var(--color-accent)]')
        setTimeout(() => el.classList.remove('ring-2', 'ring-[var(--color-accent)]'), 2500)
      }
    }, 150)
    return () => clearTimeout(timer)
  }, [participant])

  const handleToggleLock = async (field: string) => {
    if (!participant) return
    const isLocked = lockedFields[field]
    setLockedFields(prev => ({ ...prev, [field]: !prev[field] }))
    try {
      if (isLocked) {
        await api.participants.unlockField(participantId, field)
      } else {
        await api.participants.lockField(participantId, field)
      }
    } catch {
      // Revert on failure
      setLockedFields(prev => ({ ...prev, [field]: isLocked }))
    }
  }

  const handleDownloadPdf = async () => {
    setPdfBusy(true)
    setConfirmMsg(null)
    try {
      await api.communications.downloadConfirmationPdf(
        eventId, participantId, locale,
        [participant?.first_name, participant?.last_name].filter(Boolean).join(' ')
      )
    } catch (err) {
      setConfirmMsg(errorMessage(err, tp('errPdf')))
    } finally {
      setPdfBusy(false)
    }
  }

  const handleGenerateConfirmation = async () => {
    setGenConfirm(true)
    setConfirmMsg(null)
    try {
      const r = await api.communications.generateConfirmation(eventId, participantId)
      setConfirmation({
        subject: r.subject,
        body: r.body,
        missing: r.missing,
        source: r.source,
        commId: r.communication?.id ?? null,
        persisted: r.persisted,
      })
      if (!r.persisted) setConfirmMsg(tp('previewOnly'))
    } catch (err) {
      setConfirmMsg(errorMessage(err, tp('errGenerate')))
    } finally {
      setGenConfirm(false)
    }
  }

  const handleSaveConfirmation = async () => {
    if (!confirmation?.commId || savingConfirm) return
    setSavingConfirm(true)
    try {
      await api.communications.update(confirmation.commId, { subject: confirmation.subject, body: confirmation.body, status: 'ready' })
      setConfirmMsg(tp('confirmSaved'))
    } catch (err) {
      setConfirmMsg(errorMessage(err, tp('errSaveConfirm')))
    } finally {
      setSavingConfirm(false)
    }
  }

  const handleSendConfirmation = async () => {
    if (!confirmation?.commId || sendingConfirm) return
    setSendingConfirm(true)
    try {
      await api.communications.update(confirmation.commId, { subject: confirmation.subject, body: confirmation.body })
      await api.communications.send(confirmation.commId)
      setConfirmMsg(tp('confirmSent'))
    } catch (err) {
      setConfirmMsg(errorMessage(err, tp('errSend')))
    } finally {
      setSendingConfirm(false)
    }
  }

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!participant) return
    setSaving(true)
    setError(null)
    try {
      const formData = new FormData(e.currentTarget)
      // The backend writes one change_log entry per field (non-repudiation),
      // so a multi-field form save is one PATCH per changed field, not one
      // bulk PATCH — see routers/participants.py's ParticipantUpdate.
      let updated = participant
      for (const field of EDITABLE_FIELDS) {
        const val = formData.get(field)
        if (val === null) continue
        const newValue = val as string
        const oldValue = (participant as unknown as Record<string, string | undefined>)[field] ?? ''
        if (newValue === oldValue) continue
        updated = await api.participants.update(participantId, {
          field,
          value: newValue,
          reason: 'manual_edit',
        })
      }
      setParticipant(updated)
      setIsSaved(true)
      setTimeout(() => setIsSaved(false), 2000)
    } catch (err) {
      setError(errorMessage(err, tp('errSave')))
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <AppLayout
        eventId={eventId}
        locale={locale}
        pageTitle={tp('title')}
        pageSubtitle={tp('subtitle')}
      >
        <div className="flex items-center justify-center py-24">
          <Loader2 className="h-10 w-10 animate-spin text-[var(--color-accent)]" />
        </div>
      </AppLayout>
    )
  }

  if (error && !participant) {
    return (
      <AppLayout
        eventId={eventId}
        locale={locale}
        pageTitle={tp('title')}
        pageSubtitle={tp('subtitle')}
      >
        <div className="flex flex-col items-center justify-center py-24 gap-4">
          <p className="text-sm text-[var(--color-danger)]">{error}</p>
          <Button variant="outline" onClick={() => router.back()}>{tAct('back')}</Button>
        </div>
      </AppLayout>
    )
  }

  if (!participant) return null

  return (
    <AppLayout
      eventId={eventId}
      locale={locale}
      pageTitle={tp('title')}
      pageSubtitle={tp('subtitle')}
    >
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Button variant="outline" size="icon" onClick={() => router.back()} className="h-9 w-9 border-[var(--color-border)]">
            <ArrowLeft className="h-4.5 w-4.5 text-[var(--color-text-secondary)]" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-[var(--color-text-primary)]">
              {participant.first_name} {participant.last_name}
            </h1>
            <p className="mt-0.5 text-xs text-[var(--color-text-secondary)]">ID: {participantId}</p>
          </div>
        </div>

        {isSaved && (
          <div className="flex items-center gap-2 p-4 rounded-lg bg-[var(--color-success-light)] border border-[var(--color-success)]/20 text-[var(--color-success)] text-sm font-medium animate-fade-in">
            <CheckCircle2 className="h-5 w-5 shrink-0" />
            <span>{tp('saved')}</span>
          </div>
        )}

        {error && (
          <div className="flex items-center gap-2 p-4 rounded-lg bg-[var(--color-danger-light)] border border-[var(--color-danger)]/20 text-[var(--color-danger)] text-sm font-medium">
            <span>{error}</span>
          </div>
        )}

        <div className="grid grid-cols-12 gap-6">
          {/* Main Edit Form */}
          <div className="col-span-12 lg:col-span-8 space-y-6">
            <Card className="p-6 border-[var(--color-border)] shadow-[var(--shadow-card)] bg-white">
              <form onSubmit={handleSave} className="space-y-6">
                <div className="flex items-center justify-between border-b pb-4">
                  <div className="flex items-center gap-2">
                    <User className="h-5 w-5 text-[var(--color-accent)]" />
                    <h3 className="font-semibold text-sm text-[var(--color-text-primary)]">{tp('profile')}</h3>
                  </div>
                  <Badge variant="outline" className="border-[var(--color-success)] text-[var(--color-success)] bg-[var(--color-success-light)]">
                    {tp('consolidated', { score: participant.confidence })}
                  </Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {[
                    { field: 'first_name', label: tf('first_name'), val: participant.first_name },
                    { field: 'last_name', label: tf('last_name'), val: participant.last_name },
                    { field: 'email', label: tf('email'), val: participant.email },
                    { field: 'company', label: tf('company'), val: participant.company || '' },
                    { field: 'phone', label: tf('phone'), val: participant.phone || '' },
                    { field: 'nationality', label: tf('nationality'), val: participant.nationality || '' },
                    { field: 'dietary_requirements', label: tf('dietary_requirements'), val: participant.dietary_requirements || '', sensitive: true }
                  ].map((item) => (
                    <div key={item.field} className="space-y-1.5">
                      <label className="text-xs font-semibold text-[var(--color-text-secondary)] flex items-center justify-between">
                        <span>{item.label} {item.sensitive && <span className="text-[var(--color-danger)] font-medium">{tp('sensitive')}</span>}</span>
                        {lockedFields[item.field] !== undefined && (
                          <button
                            type="button"
                            className={`flex items-center gap-1 text-[10px] hover:underline font-semibold ${
                              lockedFields[item.field] ? 'text-[var(--color-accent)]' : 'text-slate-400'
                            }`}
                            onClick={() => handleToggleLock(item.field)}
                          >
                            {lockedFields[item.field] ? (
                              <>
                                <Lock className="h-3 w-3" /> {tp('locked')}
                              </>
                            ) : (
                              <>
                                <Unlock className="h-3 w-3" /> {tp('unlocked')}
                              </>
                            )}
                          </button>
                        )}
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          name={item.field}
                          defaultValue={item.val}
                          disabled={lockedFields[item.field]}
                          className="w-full text-sm rounded-md border border-[var(--color-border)] bg-white px-3 py-2 text-[var(--color-text-primary)] disabled:bg-slate-50 disabled:text-slate-500 focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-end pt-4 border-t gap-3">
                  <Button variant="outline" type="button" onClick={() => router.back()}>
                    {tAct('back')}
                  </Button>
                  <Button
                    type="submit"
                    disabled={saving}
                    className="bg-[var(--color-accent)] hover:bg-[var(--color-accent)]/90 text-white flex items-center gap-2"
                  >
                    {saving ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Save className="h-4 w-4" />
                    )}
                    {tp('saveChanges')}
                  </Button>
                </div>
              </form>
            </Card>
          </div>

          {/* Right Panel: Audit Trail & Sources */}
          <div className="col-span-12 lg:col-span-4 space-y-6">
            {/* Sources tracking */}
            <Card className="p-5 border-[var(--color-border)] shadow-[var(--shadow-card)] bg-white space-y-4">
              <h4 className="text-sm font-semibold text-[var(--color-text-primary)] flex items-center gap-2">
                <FileText className="h-4.5 w-4.5 text-[var(--color-accent)]" /> {tp('sources')}
              </h4>
              <div className="space-y-3">
                {participant.sources.length === 0 ? (
                  <p className="text-xs text-[var(--color-text-secondary)]">{tp('noSources')}</p>
                ) : (
                  participant.sources.map((source) => (
                    <div key={source} className="flex items-center justify-between p-2.5 rounded border border-slate-100 bg-slate-50">
                      <span className="text-xs font-medium text-[var(--color-text-primary)]">{SOURCE_LABELS[source] || source}</span>
                      <Badge className="bg-[var(--color-success-light)] text-[var(--color-success)] border-0 text-[10px]">{tp('present')}</Badge>
                    </div>
                  ))
                )}
              </div>
            </Card>

            {/* Audit Trail */}
            <Card className="p-5 border-[var(--color-border)] shadow-[var(--shadow-card)] bg-white space-y-4">
              <h4 className="text-sm font-semibold text-[var(--color-text-primary)] flex items-center gap-2">
                <Clock className="h-4.5 w-4.5 text-[var(--color-accent)]" /> {tp('auditTrail')}
              </h4>
              <p className="text-xs text-[var(--color-text-secondary)] leading-relaxed">
                {tp('auditPending')}
              </p>
            </Card>
          </div>
        </div>

        {/* Consolidated operational master-list view (§6) */}
        {consolidated && (
          <Card className="p-6 border-[var(--color-border)] shadow-[var(--shadow-card)] bg-white space-y-6">
            <div className="flex items-center gap-2 border-b pb-4">
              <Database className="h-5 w-5 text-[var(--color-accent)]" />
              <h3 className="font-semibold text-sm text-[var(--color-text-primary)]">{tp('consolidatedView')}</h3>
            </div>

            {/* Summary tiles */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { icon: <Plane className="h-4 w-4" />, label: tp('tileFlights'), count: consolidated.flights.length },
                { icon: <Hotel className="h-4 w-4" />, label: tp('tileNights'), count: consolidated.hotel_nights.length },
                { icon: <Bus className="h-4 w-4" />, label: tp('tileTransfers'), count: consolidated.transfers.length },
                { icon: <PartyPopper className="h-4 w-4" />, label: tp('tileActivities'), count: consolidated.activities.length },
              ].map((s) => (
                <div key={s.label} className="rounded-lg border border-[var(--color-border)] bg-slate-50 p-3">
                  <div className="flex items-center gap-1.5 text-[var(--color-text-secondary)]">
                    {s.icon}
                    <span className="text-xs font-medium">{s.label}</span>
                  </div>
                  <div className="mt-1 text-2xl font-bold text-[var(--color-text-primary)]">{s.count}</div>
                </div>
              ))}
            </div>

            {/* Flights */}
            {consolidated.flights.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-wide text-[var(--color-text-secondary)]">{tp('tileFlights')}</h4>
                {consolidated.flights.map((f) => (
                  <div key={f.id} className="space-y-1.5 rounded border border-slate-100 bg-slate-50 px-3 py-2.5 text-xs">
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                      <span className="rounded border border-slate-200 bg-white px-1.5 py-0.5 font-mono font-semibold">{f.flight_number || '—'}</span>
                      {f.airline && <span className="font-medium text-[var(--color-text-primary)]">{f.airline}</span>}
                      {f.pnr_code && <span className="text-[var(--color-text-secondary)]">PNR&nbsp;<span className="font-mono">{f.pnr_code}</span></span>}
                      {f.status && (
                        <span className={`ml-auto rounded-full border px-2 py-0.5 text-[10px] font-semibold ${
                          f.status === 'cancelled'
                            ? 'border-rose-200 bg-rose-50 text-rose-700'
                            : 'border-emerald-200 bg-emerald-50 text-emerald-700'
                        }`}>
                          {f.status === 'cancelled' ? tp('cancelled') : f.status === 'confirmed' ? tp('confirmed') : f.status}
                        </span>
                      )}
                    </div>
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                      <span className="font-semibold text-[var(--color-text-primary)]">{f.departure_airport || '—'}</span>
                      {f.departure_time && <span className="text-[var(--color-text-secondary)]">{formatScheduleTime(f.departure_time, locale)}</span>}
                      <span className="text-[var(--color-text-secondary)]">→</span>
                      <span className="font-semibold text-[var(--color-text-primary)]">{f.arrival_airport || '—'}</span>
                      {f.arrival_time && <span className="text-[var(--color-text-secondary)]">{formatScheduleTime(f.arrival_time, locale)}</span>}
                    </div>
                    {f.baggage_info && (
                      <div className="text-[var(--color-text-secondary)]">{tp('baggage', { info: f.baggage_info })}</div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Hotel nights */}
            {consolidated.hotel_nights.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-wide text-[var(--color-text-secondary)]">{tp('hotelsAndNights')}</h4>
                {consolidated.hotel_nights.map((h) => (
                  <div key={h.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 rounded border border-slate-100 bg-slate-50 px-3 py-2 text-xs">
                    <span className="font-semibold">{h.hotels?.name || tp('hotel')}</span>
                    {h.night_date && <span>{formatDateOnly(h.night_date, locale, { dateStyle: 'medium' })}</span>}
                    {h.room_type && <span className="text-[var(--color-text-secondary)]">{h.room_type}</span>}
                    {h.status && <span className="text-[var(--color-text-secondary)]">{h.status}</span>}
                  </div>
                ))}
              </div>
            )}

            {/* Transfers */}
            {consolidated.transfers.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-wide text-[var(--color-text-secondary)]">{tp('tileTransfers')}</h4>
                {consolidated.transfers.map((tr) => (
                  <div key={tr.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 rounded border border-slate-100 bg-slate-50 px-3 py-2 text-xs">
                    <span className="font-semibold">{tr.pickup_location || '—'} → {tr.dropoff_location || '—'}</span>
                    {tr.pickup_time && <span className="text-[var(--color-text-secondary)]">{formatScheduleTime(tr.pickup_time, locale)}</span>}
                    {tr.transfer_type && <span className="text-[var(--color-text-secondary)]">{tr.transfer_type}</span>}
                  </div>
                ))}
              </div>
            )}

            {/* Activities */}
            {consolidated.activities.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-wide text-[var(--color-text-secondary)]">{tp('tileActivities')}</h4>
                <div className="flex flex-wrap gap-2">
                  {consolidated.activities.map((a) => (
                    <Badge key={a.id} className="bg-[var(--color-accent-light)] text-[var(--color-accent)] border-0">
                      {a.activities?.name || tp('activity')}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Raw source rows (admin/pm only, provided by the API) */}
            {consolidated.source_records.length > 0 && (
              <div className="space-y-3">
                <h4 className="text-xs font-semibold uppercase tracking-wide text-[var(--color-text-secondary)]">
                  {tp('rawSources', { count: consolidated.source_records.length })}
                </h4>
                {consolidated.source_records.map((sr) => {
                  const data: Record<string, any> = sr.normalized_data || sr.raw_data || {}
                  const entries = Object.entries(data).filter(([, v]) => v !== null && v !== '' && v !== undefined)
                  return (
                    <div key={sr.id} className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                      <div className="mb-2 text-[11px] font-semibold text-[var(--color-accent)]">
                        {sr.uploaded_files?.source_type || 'source'}
                        {sr.uploaded_files?.original_filename ? ` — ${sr.uploaded_files.original_filename}` : ''}
                      </div>
                      <div className="grid grid-cols-1 gap-x-6 gap-y-1 sm:grid-cols-2 lg:grid-cols-3">
                        {entries.map(([k, v]) => (
                          <div key={k} className="flex flex-col">
                            <span className="text-[10px] uppercase tracking-wide text-[var(--color-text-secondary)]">{k.replace(/_/g, ' ')}</span>
                            <span className="text-xs text-[var(--color-text-primary)] break-words">{String(v)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </Card>
        )}

        {/* Individual confirmation (§13 + Lettre individuelle) */}
        <Card className="p-6 border-[var(--color-border)] shadow-[var(--shadow-card)] bg-white space-y-5">
          <div className="flex items-center justify-between border-b pb-4">
            <div className="flex items-center gap-2">
              <Mail className="h-5 w-5 text-[var(--color-accent)]" />
              <h3 className="font-semibold text-sm text-[var(--color-text-primary)]">{tp('confirmationTitle')}</h3>
            </div>
            {confirmation && (
              <Badge variant="outline" className="text-[10px] border-[var(--color-border)] text-[var(--color-text-secondary)]">
                {confirmation.source === 'gemini' ? tp('byAi') : tp('byTemplate')}
              </Badge>
            )}
          </div>

          {confirmMsg && (
            <div className="flex items-center gap-2 rounded-lg bg-[var(--color-accent-light)] px-3 py-2 text-xs font-medium text-[var(--color-text-primary)]">
              <CheckCircle2 className="h-4 w-4 shrink-0 text-[var(--color-accent)]" />
              <span>{confirmMsg}</span>
            </div>
          )}

          {!confirmation ? (
            <div className="flex flex-col items-start gap-3">
              <p className="text-xs text-[var(--color-text-secondary)]">
                {tp('confirmationHint')}
              </p>
              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={handleGenerateConfirmation}
                  disabled={genConfirm}
                  className="bg-[var(--color-accent)] hover:bg-[var(--color-accent)]/90 text-white flex items-center gap-2"
                >
                  {genConfirm ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                  {tp('generate')}
                </Button>
                {/* §16 — the PDF does not need the email to exist first: it is
                    built from the same consolidated facts, not from the text. */}
                <Button variant="outline" onClick={handleDownloadPdf} disabled={pdfBusy} className="flex items-center gap-2">
                  {pdfBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />}
                  {tp('downloadPdf')}
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {confirmation.missing.length > 0 && (
                <div className="flex items-start gap-2 rounded-lg border border-[var(--color-warning)]/30 bg-[var(--color-warning-light)] px-3 py-2 text-xs">
                  <AlertTriangle className="h-4 w-4 shrink-0 text-[var(--color-warning)]" />
                  <span className="text-[var(--color-text-primary)]">
                    {tp('missingInfo')}{' '}
                    {confirmation.missing.map((m) => (m === 'flights' ? tp('missFlights') : m === 'hotel_nights' ? tp('missHotel') : m === 'transfers' ? tp('missTransfers') : m)).join(', ')}.
                  </span>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[var(--color-text-secondary)]">{tp('subjectLabel')}</label>
                <input
                  type="text"
                  value={confirmation.subject}
                  onChange={(e) => setConfirmation((c) => c && { ...c, subject: e.target.value })}
                  className="w-full text-sm rounded-md border border-[var(--color-border)] bg-white px-3 py-2 text-[var(--color-text-primary)] focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[var(--color-text-secondary)]">{tp('messageLabel')}</label>
                <textarea
                  value={confirmation.body}
                  onChange={(e) => setConfirmation((c) => c && { ...c, body: e.target.value })}
                  rows={14}
                  className="w-full text-sm rounded-md border border-[var(--color-border)] bg-white px-3 py-2 font-mono text-[var(--color-text-primary)] whitespace-pre-wrap focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                />
              </div>

              <div className="flex flex-wrap justify-end gap-2 border-t pt-4">
                <Button variant="outline" onClick={handleGenerateConfirmation} disabled={genConfirm} className="flex items-center gap-2">
                  {genConfirm ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                  {tp('regenerate')}
                </Button>
                <Button variant="outline" onClick={handleDownloadPdf} disabled={pdfBusy} className="flex items-center gap-2">
                  {pdfBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />}
                  PDF
                </Button>
                <Button
                  variant="outline"
                  onClick={handleSaveConfirmation}
                  disabled={!confirmation.commId || savingConfirm}
                  className="flex items-center gap-2"
                  title={confirmation.commId ? '' : tp('migrationRequired')}
                >
                  {savingConfirm ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} {tAct('save')}
                </Button>
                <Button
                  onClick={handleSendConfirmation}
                  disabled={!confirmation.commId || sendingConfirm}
                  className="bg-[var(--color-success)] hover:bg-emerald-600 text-white flex items-center gap-2"
                  title={confirmation.commId ? '' : tp('migrationRequired')}
                >
                  {sendingConfirm ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />} {tp('markSent')}
                </Button>
              </div>
            </div>
          )}
        </Card>

        {/* Documents collected by the form (§9). Renders nothing at all when
            there are none, so a participant who uploaded nothing does not get
            an empty box asking why. */}
        <ParticipantAttachments eventId={eventId} participantId={participantId} />

        {/* Personal extension at the registrant's own expense (§3). Renders
            nothing when nobody asked. */}
        {participant && <ExtensionRequestBanner participant={participant} />}

        {/* Operational remarks (feedback §8). Placed last because it is what
            somebody adds after reading everything above. */}
        <Card className="p-6">
          <ParticipantNotes eventId={eventId} participantId={participantId} />
        </Card>
      </div>
    </AppLayout>
  )
}
