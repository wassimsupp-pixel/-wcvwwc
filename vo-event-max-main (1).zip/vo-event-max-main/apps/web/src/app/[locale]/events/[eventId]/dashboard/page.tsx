'use client'

import { useState, useEffect } from 'react'
import { useTranslations } from 'next-intl'
import { AppLayout } from '@/components/layout/AppLayout'
import { KPICard } from '@/components/ui/KPICard'
import { ConsolidationStepper } from '@/components/ui/ConsolidationStepper'
import { DataSourceCard } from '@/components/ui/DataSourceCard'
import { ExceptionItem } from '@/components/ui/ExceptionItem'
import { ParticipantTable } from '@/components/participants/ParticipantTable'
import { DistributionChart } from '@/components/ui/DistributionChart'
import Link from 'next/link'
import { useParams, useRouter } from 'next/navigation'
import { Users, Database, CheckSquare, AlertTriangle, ChevronRight, CheckCircle2, Loader2, Zap, XCircle, ShieldCheck, Sparkles, Lightbulb, Plane, Hotel, Bus, PartyPopper, BellRing, LayoutDashboard, ClipboardList } from 'lucide-react'
import { api, type Participant, type UploadedFile, type Exception, type ConsolidationRun, type DashboardData } from '@/lib/api'
import { EventPulse } from '@/components/ui/EventPulse'
import { CompanyGaps } from '@/components/ui/CompanyGaps'
import { overdueAlerts, ageLabel } from '@/lib/alerts'
import { coverageVerdict } from '@/lib/coverage'

export default function DashboardPage() {
  const params = useParams()
  const router = useRouter()
  const locale = (params.locale as string) || 'fr'
  const eventId = params.eventId as string

  const t = useTranslations('dashboard')
  const tKpi = useTranslations('dashboard.kpi')
  const tActions = useTranslations('actions')
  const tExceptions = useTranslations('exceptions')
  const tSources = useTranslations('sources')
  const tDash = useTranslations('dashboard')
  const tChart = useTranslations('dashboard.chart')
  const tSrc = useTranslations('dashboard.sourceCards')
  const tDim = useTranslations('dashboard.dimensions')
  const tSteps = useTranslations('steps')

  const [loading, setLoading] = useState(true)
  const [participants, setParticipants] = useState<Participant[]>([])
  const [totalParticipants, setTotalParticipants] = useState(0)
  const [files, setFiles] = useState<UploadedFile[]>([])
  const [exceptions, setExceptions] = useState<Exception[]>([])
  // Alerts left unresolved for more than 24 h. Computed when the data lands,
  // not during render: reading the clock in a render body is impure.
  const [overdue, setOverdue] = useState<{ count: number; oldestAgeMs: number }>({ count: 0, oldestAgeMs: 0 })
  const [analysis, setAnalysis] = useState<any>(null)
  const [dash, setDash] = useState<DashboardData | null>(null)
  const [analysisLoading, setAnalysisLoading] = useState(false)

  // Consolidation state
  const [consolidating, setConsolidating] = useState(false)
  const [, setConsolidationRun] = useState<ConsolidationRun | null>(null)
  const [consolidationMsg, setConsolidationMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null)

  const loadDashboardData = async () => {
      if (!eventId) return
      setLoading(true)
      try {
        // reports/analysis merges ten tables (every source_records blob
        // included) to produce a score and three recommendations. Awaiting it
        // here held the ENTIRE page hostage to the slowest call on the site.
        // It is fetched after the paint now; its card fills in when it lands.
        const [participantsData, filesData, exceptionsData, dashData] = await Promise.all([
          api.participants.list(eventId, { page_size: 5 }),
          api.files.list(eventId),
          api.exceptions.list(eventId),
          api.dashboard.get(eventId).catch(() => null),
        ])
        setParticipants(participantsData.items)
        setTotalParticipants(participantsData.total)
        setFiles(filesData)
        setExceptions(exceptionsData)
        const late = overdueAlerts(exceptionsData, Date.now())
        setOverdue({ count: late.items.length, oldestAgeMs: late.oldestAgeMs })
        setDash(dashData)
      } catch (err) {
        console.error('Failed to load dashboard data:', err)
      } finally {
        setLoading(false)
      }

      // Second wave: the deep analysis, once the page is already on screen.
      setAnalysisLoading(true)
      api.reports
        .getAnalysis(eventId)
        .then(setAnalysis)
        .catch(() => setAnalysis(null))
        .finally(() => setAnalysisLoading(false))
    }

  useEffect(() => {
    loadDashboardData()
  }, [eventId])

  // Kick off a consolidation run and poll until done
  const handleRunConsolidation = async () => {
    if (consolidating || files.length === 0) return
    setConsolidating(true)
    setConsolidationMsg(null)
    try {
      const run = await api.consolidation.run(eventId)
      setConsolidationRun(run)

      // Poll until the run finishes. A large consolidation keeps the API worker
      // busy, so individual status polls can transiently fail/timeout — we
      // tolerate that and keep waiting instead of falsely reporting an error.
      const sleep = (ms: number) => new Promise(r => setTimeout(r, ms))
      const MAX_MINUTES = 20
      const start = Date.now()
      const poll = async (consecutiveFailures = 0): Promise<void> => {
        if (Date.now() - start > MAX_MINUTES * 60_000) {
          setConsolidationMsg({ type: 'error', text: t('errorRun') })
          return
        }
        let updated
        try {
          updated = await api.consolidation.get(eventId, run.id)
        } catch {
          // API busy during the heavy run — wait longer and retry, don't error out.
          if (consecutiveFailures >= 40) {
            setConsolidationMsg({ type: 'error', text: t('errorApi') })
            return
          }
          await sleep(5000)
          return poll(consecutiveFailures + 1)
        }
        setConsolidationRun(updated)
        if (updated.status === 'running') {
          await sleep(3000)
          return poll(0)
        }
        // Bug found in the 2026-07-21/22 audit: this checked status === 'done',
        // a value the backend never writes (docs/schema.sql only allows
        // 'running' | 'completed' | 'failed') — every successful consolidation
        // fell through to the error branch and showed a false failure banner.
        if (updated.status === 'completed') {
          // The banner used to read "178 participants matchés, 100 conflits
          // détectés" on an event holding 117 participants and zero conflicts:
          // `matched_certain` counts FCM ROWS matched (a round trip is two),
          // and `exceptions_count` is every alert, mostly missing fields. Two
          // wrong words on the message a client reads right after the main
          // action of a demo. Report the running total and call an alert an
          // alert.
          const participantCount = updated.stats?.participants_total ?? totalParticipants
          const alerts = updated.stats?.exceptions_count ?? 0
          setConsolidationMsg({
            type: 'success',
            text: t('successRun', { participants: participantCount, alerts }),
          })
          await loadDashboardData()   // auto-refresh — no manual reload needed
        } else {
          setConsolidationMsg({ type: 'error', text: t('errorRun') })
          await loadDashboardData()
        }
      }
      await poll()
    } catch (err) {
      console.error('Consolidation failed:', err)
      // Show the API's own explanation rather than a blanket connection
      // error: the commonest case here is a 409 because a consolidation is
      // ALREADY running (validating a mapping auto-starts one), and telling
      // the user to "check the API connection" sent them chasing a network
      // problem that never existed while the run was succeeding behind them.
      const text = err instanceof Error && err.message ? err.message : t('errorApi')
      setConsolidationMsg({ type: 'error', text })
    } finally {
      setConsolidating(false)
    }
  }

  // Calculations
  // Full-event-accurate, like withoutFlightCount etc. below: `participants` is
  // capped at page_size: 5, so computing this from it silently showed the
  // completion rate of an arbitrary 5-person sample instead of the event.
  const completeCount = dash?.participants.complete ?? analysis?.complete_count ?? (totalParticipants > 0 ? participants.filter((p) => p.completeness_status === 'complete').length : 0)
  const completenessRate = totalParticipants > 0 ? Math.round((completeCount / totalParticipants) * 100) : 0

  const openExceptions = exceptions.filter((e) => !e.resolved)
  const activeExceptionsCount = openExceptions.length
  const conflictsCount = openExceptions.filter((e) => e.type === 'conflict').length
  const duplicatesCount = openExceptions.filter((e) => e.type === 'duplicate').length
  const notFoundCount = openExceptions.filter((e) => e.type === 'not_found').length
  // Everything the three lines above do not name. The panel used to count only
  // conflict/duplicate/not_found/to_verify, and `missing_field` — which is
  // what almost every alert actually is — fell through all four: the card read
  // 0, 0, 0, 0 directly under a KPI announcing 104 alerts. Counting the
  // remainder means the four lines always add up to the KPI, whatever new
  // category the backend introduces next.
  const NAMED_TYPES = new Set(['conflict', 'duplicate', 'not_found'])
  const toCheckCount = openExceptions.filter((e) => !NAMED_TYPES.has(e.type)).length


  // Thresholds live in lib/coverage.ts — they are a guess at how VO works,
  // not a measurement, and must be correctable in one place.
  const verdict = (covered: number) =>
    coverageVerdict(covered, totalParticipants, dash?.event.days_until_start ?? null)

  // Navigation targets for the dashboard's clickable blocks
  const exceptionsBase = `/${locale}/events/${eventId}/exceptions`
  const stepperRoutes = [
    `/${locale}/events/${eventId}/sources`,     // 0 Importation
    `/${locale}/events/${eventId}/sources`,     // 1 Analyse
    `/${locale}/events/${eventId}/master-list`, // 2 Matching
    `/${locale}/events/${eventId}/master-list`, // 3 Consolidation
    exceptionsBase,                             // 4 Validation
  ]

  // Files checklist counts
  // The frontend's own vocabulary: the backend's `processed` arrives as
  // `imported`. 'review' counts as pending — it is waiting on a human.
  const filesPending = files.filter((f) =>
    f.status === 'pending' || f.status === 'mapped' || f.status === 'review').length

  // Source cards configuration
  const dataSourcesConfig = [
    // Each card wears the icon of the page it feeds.
    { type: 'registration', name: tSrc('registrationName'), subtitle: tSrc('registrationSubtitle'), Icon: ClipboardList },
    { type: 'fcm', name: tSrc('fcmName'), subtitle: tSrc('fcmSubtitle'), Icon: Plane },
    { type: 'hotel', name: tSrc('hotelName'), subtitle: tSrc('hotelSubtitle'), Icon: Hotel },
    { type: 'transfer', name: tSrc('transferName'), subtitle: tSrc('transferSubtitle'), Icon: Bus },
    { type: 'activity', name: tSrc('activityName'), subtitle: tSrc('activitySubtitle'), Icon: PartyPopper },
  ]

  // Raw "sans X" counts (MVP feedback §14) come from `analysis`
  // (api.reports.getAnalysis → build_analysis), which scans EVERY participant
  // of the event. The `participants` array above is capped at 5 rows
  // (page_size: 5, it only feeds the "recent participants" preview table) —
  // computing coverage from it would silently show counts for 5 people out of
  // however many are actually in the event. Each tile links straight to the
  // master list pre-filtered to exactly those participants (master-list/
  // page.tsx already reads ?missing= from the URL), not just to the general
  // page for that category.
  const withoutFlightCount = dash?.coverage.has_flight.without ?? analysis?.without_flight ?? (totalParticipants > 0 ? participants.filter((p) => !p.has_flight).length : 0)
  const withoutHotelCount = dash?.coverage.has_hotel.without ?? analysis?.without_hotel ?? (totalParticipants > 0 ? participants.filter((p) => !p.has_hotel).length : 0)
  const withoutTransferCount = dash?.coverage.has_transfer.without ?? analysis?.without_transfer ?? (totalParticipants > 0 ? participants.filter((p) => !p.has_transfer).length : 0)
  const withoutActivitiesCount = dash?.coverage.has_activities.without ?? analysis?.without_activities ?? (totalParticipants > 0 ? participants.filter((p) => !p.has_activities).length : 0)
  const masterListBase = `/${locale}/events/${eventId}/master-list`

  // Distribution chart percentages — same full-event source as above.
  const flightsPct = totalParticipants > 0 ? Math.round(((totalParticipants - withoutFlightCount) / totalParticipants) * 100) : 0
  const hotelsPct = totalParticipants > 0 ? Math.round(((totalParticipants - withoutHotelCount) / totalParticipants) * 100) : 0
  const transfersPct = totalParticipants > 0 ? Math.round(((totalParticipants - withoutTransferCount) / totalParticipants) * 100) : 0
  const activitiesPct = totalParticipants > 0 ? Math.round(((totalParticipants - withoutActivitiesCount) / totalParticipants) * 100) : 0
  // Was `totalParticipants > 0 ? 90 : 0` — a constant shown as data on every
  // event. Now the real share of participants who have actually been written
  // to, and null when the communications table is not deployed, in which case
  // the slice is dropped rather than guessed.
  const commsPct = dash?.communications.pct ?? null

  // `route` travels with the slice rather than being looked up from its label:
  // the label is translated, and a route table keyed on French text would stop
  // matching the moment somebody reads the dashboard in Dutch.
  const distributionData = [
    { name: tChart('flights'), route: 'flights', value: flightsPct, color: '#806CAF' },
    { name: tChart('hotels'), route: 'hotels', value: hotelsPct, color: '#47AB75' },
    { name: tChart('transfers'), route: 'transfers', value: transfersPct, color: '#F99A4C' },
    { name: tChart('activities'), route: 'activities', value: activitiesPct, color: '#3B82F6' },
    ...(commsPct === null ? [] : [{ name: tChart('comms'), route: 'communications', value: commsPct, color: '#8B5CF6' }]),
  ]

  // Red/amber/green so a 0% dimension or a low overall score is visible at a
  // glance, instead of blending into the rest of the monochrome dashboard.
  const scoreColor = (v: number): string =>
    v >= 80 ? 'var(--color-success)' : v >= 50 ? 'var(--color-warning)' : 'var(--color-danger)'

  // Stepper steps status
  const getStepperSteps = () => {
    const hasFiles = files.length > 0
    const hasMatched = totalParticipants > 0
    const isFullyValidated = hasMatched && activeExceptionsCount === 0

    return [
      { label: tSteps('import'), count: `${files.length}`, status: hasFiles ? ('done' as const) : ('active' as const) },
      { label: tSteps('analysis'), status: hasFiles ? ('done' as const) : ('pending' as const) },
      { label: tSteps('matching'), status: hasMatched ? ('done' as const) : hasFiles ? ('active' as const) : ('pending' as const) },
      { label: tSteps('consolidation'), status: hasMatched ? (isFullyValidated ? ('done' as const) : ('active' as const)) : ('pending' as const) },
      { label: tSteps('validation'), status: isFullyValidated ? ('done' as const) : ('pending' as const) },
    ]
  }

  if (loading) {
    return (
      <AppLayout eventId={eventId} locale={locale}>
        <div className="flex h-[60vh] w-full flex-col items-center justify-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-[var(--color-text-primary)]" />
          <p className="text-sm font-medium text-[var(--color-text-secondary)]">
            {tDash('loading')}
          </p>
        </div>
      </AppLayout>
    )
  }

  return (
    <AppLayout eventId={eventId} locale={locale}>
      <div className="space-y-6">
        {/* Page header with Consolidation CTA */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text-primary)] flex items-center gap-2">
              <LayoutDashboard className="h-6 w-6 text-[var(--color-accent)]" />
              {t('title')}
            </h1>
            <p className="mt-1 text-sm text-[var(--color-text-secondary)]">{t('subtitle')}</p>
          </div>
          <button
            onClick={handleRunConsolidation}
            disabled={consolidating || files.length === 0 || loading}
            className="flex items-center gap-2 rounded-lg bg-[var(--color-text-primary)] px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-[var(--color-text-primary)]/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]"
          >
            {consolidating ? (
              <><Loader2 className="h-4 w-4 animate-spin" /> {tDash('consolidating')}</>
            ) : (
              <><Zap className="h-4 w-4" /> {tDash('runConsolidation')}</>
            )}
          </button>
        </div>

        {/* Alerts that stopped moving. A running total reads the same on day
            one and day five; this is the part that needs a name. */}
        {overdue.count > 0 && (
          <div className="flex flex-col gap-3 rounded-[var(--radius-card)] border border-[var(--color-warning)]/40 bg-[var(--color-warning-light)] p-4 sm:flex-row sm:items-center">
            <BellRing className="h-5 w-5 shrink-0 text-[var(--color-warning)]" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-[var(--color-text-primary)]">
                {tExceptions('overdueTitle')}
              </p>
              <p className="mt-0.5 text-sm text-[var(--color-text-secondary)]">
                {tExceptions('overdueBody', {
                  count: overdue.count,
                  oldest: ageLabel(overdue.oldestAgeMs, locale),
                })}
              </p>
            </div>
            <Link
              href={exceptionsBase}
              className="shrink-0 rounded-lg bg-[var(--color-text-primary)] px-4 py-2 text-center text-sm font-semibold text-white transition-colors hover:bg-[var(--color-text-primary)]/90"
            >
              {tExceptions('overdueCta')}
            </Link>
          </div>
        )}

        {/* Consolidation status banner */}
        {consolidationMsg && (
          <div className="flex items-center gap-3 rounded-lg border border-[var(--color-border-strong)] bg-white p-4 text-sm font-medium text-[var(--color-text-primary)]">
            {consolidationMsg.type === 'success'
              ? <CheckCircle2 className="h-5 w-5 shrink-0" />
              : <XCircle className="h-5 w-5 shrink-0" />
            }
            <span>{consolidationMsg.text}</span>
            <button onClick={() => setConsolidationMsg(null)} className="ml-auto text-xs underline opacity-70 hover:opacity-100">{tActions('close')}</button>
          </div>
        )}

        {/* When the event is, how many answered, and whether the numbers move */}
        {dash && (
          <EventPulse
            data={dash}
            locale={locale}
            eventId={eventId}
            onEventUpdated={loadDashboardData}
          />
        )}

        {/* KPI Row */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <KPICard
            label={tKpi('participants')}
            value={totalParticipants}
            icon={<Users className="h-5 w-5" />}
            href={`/${locale}/events/${eventId}/master-list`}
          />
          <KPICard
            label={tKpi('sources')}
            // Files, not source KINDS. The fraction read "2/5" here and
            // "2/6" on the Sources page — two denominators for the same
            // thing, neither matching the three files actually listed.
            value={files.length}
            delta={
              // "Importation en cours" was shown whenever fewer than the five
              // POSSIBLE source kinds were present — so an event whose every
              // file was imported and consolidated still announced an import in
              // progress, in green, on the first card a client reads. Say what
              // the files are actually doing instead.
              filesPending > 0
                ? tDash('filesPending', { count: filesPending })
                : files.length > 0
                ? tDash('filesProcessed', { count: files.length })
                : tDash('filesNone')
            }
            deltaPositive={filesPending === 0 && files.length > 0}
            icon={<Database className="h-5 w-5" />}
            href={`/${locale}/events/${eventId}/sources`}
          />
          <KPICard
            label={tKpi('complete')}
            value={totalParticipants > 0 ? `${completenessRate}%` : '-'}
            icon={<CheckSquare className="h-5 w-5" />}
            href={`/${locale}/events/${eventId}/master-list`}
          />
          <KPICard
            label={tKpi('exceptions')}
            value={activeExceptionsCount}
            delta={activeExceptionsCount === 0 ? tDash('noException') : undefined}
            deltaPositive={activeExceptionsCount === 0}
            icon={<AlertTriangle className="h-5 w-5" />}
            href={`/${locale}/events/${eventId}/exceptions`}
          />
        </div>

        {/* Couverture — raw counts, click-through to the exact concerned
            participants on the master list (MVP feedback §14). A rate is
            meaningless without the deadline: 64 % of transfers is comfortable
            at D-90 and an emergency at D-5, so each card is judged against
            the days remaining rather than against 100 %. */}
        {totalParticipants > 0 && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <KPICard
              label={tDash('withoutFlight')}
              value={withoutFlightCount}
              delta={verdict(totalParticipants - withoutFlightCount).label || undefined}
              deltaPositive={verdict(totalParticipants - withoutFlightCount).ok}
              icon={<Plane className="h-5 w-5" />}
              href={`${masterListBase}?missing=flight`}
            />
            <KPICard
              label={tDash('withoutHotel')}
              value={withoutHotelCount}
              delta={verdict(totalParticipants - withoutHotelCount).label || undefined}
              deltaPositive={verdict(totalParticipants - withoutHotelCount).ok}
              icon={<Hotel className="h-5 w-5" />}
              href={`${masterListBase}?missing=hotel`}
            />
            <KPICard
              label={tDash('withoutTransfer')}
              value={withoutTransferCount}
              delta={verdict(totalParticipants - withoutTransferCount).label || undefined}
              deltaPositive={verdict(totalParticipants - withoutTransferCount).ok}
              icon={<Bus className="h-5 w-5" />}
              href={`${masterListBase}?missing=transfer`}
            />
            <KPICard
              label={tDash('withoutActivity')}
              value={withoutActivitiesCount}
              delta={verdict(totalParticipants - withoutActivitiesCount).label || undefined}
              deltaPositive={verdict(totalParticipants - withoutActivitiesCount).ok}
              icon={<PartyPopper className="h-5 w-5" />}
              href={`${masterListBase}?missing=activities`}
            />
          </div>
        )}

        {/* Intelligent data-quality analysis (same engine as Rapports §15).
            Arrives after the first paint — it is the one call that has to read
            the whole master list. */}
        {analysisLoading && !analysis && (
          <div className="flex items-center gap-2 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white p-5 text-sm text-[var(--color-text-secondary)] shadow-[var(--shadow-card)]">
            <Loader2 className="h-4 w-4 animate-spin" />
            {tDash('qualityTitle')}
          </div>
        )}
        {analysis && analysis.total > 0 && (
          <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white p-5 shadow-[var(--shadow-card)]">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--color-text-primary)]">
                <ShieldCheck className="h-4 w-4 text-[var(--color-text-primary)]" />
                {tDash('qualityTitle')}
              </h3>
              <Link
                href={`/${locale}/events/${eventId}/reports`}
                className="flex items-center gap-1 text-xs font-medium text-[var(--color-text-primary)] hover:underline"
              >
                {tDash('fullReport')} <ChevronRight className="h-3 w-3" />
              </Link>
            </div>
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
              {/* Score + dimensions */}
              <div className="flex items-center gap-4 lg:col-span-1">
                <div
                  className="flex h-20 w-20 flex-shrink-0 flex-col items-center justify-center rounded-full border-4"
                  style={{ borderColor: scoreColor(analysis.quality_score) }}
                >
                  <span className="text-2xl font-bold text-[var(--color-text-primary)]">{analysis.quality_score}</span>
                  <span className="text-[9px] text-[var(--color-text-secondary)]">/ 100</span>
                </div>
                <div className="flex-1 space-y-1.5">
                  {Object.entries(analysis.dimensions || {}).map(([dim, val]) => {
                    const labels: Record<string, string> = {
                      identite: tDim('identite'), contact: tDim('contact'), voyage: tDim('voyage'),
                      hebergement: tDim('hebergement'), regime: tDim('regime'), passeport: tDim('passeport'),
                    }
                    const v = val as number
                    return (
                      <div key={dim}>
                        <div className="mb-0.5 flex justify-between text-[10px]">
                          <span className="text-[var(--color-text-secondary)]">{labels[dim] || dim}</span>
                          <span className="font-semibold text-[var(--color-text-primary)]">{v}%</span>
                        </div>
                        <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
                          <div className="h-full rounded-full" style={{ width: `${v}%`, backgroundColor: scoreColor(v) }} />
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* Recommendations */}
              <div className="lg:col-span-2">
                <div className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold text-[var(--color-text-primary)]">
                  <Lightbulb className="h-3.5 w-3.5" /> {tDash('priorityAdvice')}
                </div>
                {(!analysis.recommendations || analysis.recommendations.length === 0) ? (
                  <p className="text-xs text-[var(--color-text-secondary)]">{tDash('dataComplete')}</p>
                ) : (
                  <ul className="space-y-1.5">
                    {analysis.recommendations.slice(0, 4).map((r: any, i: number) => (
                      <li key={i} className="flex items-start gap-2 rounded-lg border border-slate-100 bg-slate-50 px-3 py-1.5">
                        <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[var(--color-text-primary)]" />
                        <span className="text-xs text-[var(--color-text-primary)]"><strong className="font-semibold">{r.count}</strong> {r.text}</span>
                      </li>
                    ))}
                  </ul>
                )}
                {analysis.ai_summary && (
                  <div className="mt-3 rounded-lg border border-[var(--color-border-strong)] bg-slate-50 p-2.5">
                    <div className="mb-1 flex items-center gap-1.5 text-[10px] font-semibold text-[var(--color-text-primary)]">
                      <Sparkles className="h-3 w-3" /> {tDash('aiSummary')}
                    </div>
                    <p className="whitespace-pre-wrap text-[11px] leading-relaxed text-[var(--color-text-primary)]">{analysis.ai_summary}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Main content + right panel */}
        <div className="grid grid-cols-12 gap-6">
          {/* Left/main column — col-span-8 */}
          <div className="col-span-12 space-y-6 lg:col-span-8">
            {/* Visual blocks row */}
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              {/* Consolidation Stepper */}
              <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white p-5 shadow-[var(--shadow-card)]">
                <h3 className="mb-4 text-sm font-semibold text-[var(--color-text-primary)]">
                  {t('consolidationProgress')}
                </h3>
                <ConsolidationStepper
                  steps={getStepperSteps()}
                  onStepClick={(i) => router.push(stepperRoutes[i])}
                />
              </div>

              {/* Distribution Donut */}
              <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white p-5 shadow-[var(--shadow-card)]">
                <h3 className="mb-4 text-sm font-semibold text-[var(--color-text-primary)]">
                  {t('breakdown')}
                </h3>
                <DistributionChart
                  data={distributionData}
                  onItemClick={(name) => {
                    const routes: Record<string, string> = Object.fromEntries(
                      distributionData.map((d) => [d.name, d.route])
                    )
                    const seg = routes[name]
                    if (seg) router.push(`/${locale}/events/${eventId}/${seg}`)
                  }} />
              </div>
            </div>

            {/* Participant Table */}
            <div>
              <div className="mb-3 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-[var(--color-text-primary)]">
                  {t('recentParticipants')}
                </h3>
                {totalParticipants > 0 && (
                  <Link
                    href={`/${locale}/events/${eventId}/master-list`}
                    className="flex items-center gap-1 text-xs font-medium text-[var(--color-text-primary)] hover:underline"
                  >
                    {tActions('viewMasterList')}
                    <ChevronRight className="h-3 w-3" />
                  </Link>
                )}
              </div>
              
              {totalParticipants > 0 ? (
                <ParticipantTable
                  participants={participants}
                  eventId={eventId}
                  locale={locale}
                />
              ) : (
                <div className="flex flex-col items-center justify-center rounded-[var(--radius-card)] border border-dashed border-[var(--color-border)] bg-white p-8 text-center">
                  <Users className="mb-3 h-8 w-8 text-[var(--color-text-secondary)]" />
                  <p className="text-sm font-medium text-[var(--color-text-primary)]">
                    {tDash('noParticipants')}
                  </p>
                  <p className="mt-1 text-xs text-[var(--color-text-secondary)]">
                    {tDash('noParticipantsHint')}
                  </p>
                </div>
              )}
            </div>

            {/* Data Sources Grid */}
            <div>
              <div className="mb-3 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-[var(--color-text-primary)]">
                  {t('dataSources')}
                </h3>
                <Link
                  href={`/${locale}/events/${eventId}/sources`}
                  className="flex items-center gap-1 text-xs font-medium text-[var(--color-text-primary)] hover:underline"
                >
                  {tActions('viewAll')}
                  <ChevronRight className="h-3 w-3" />
                </Link>
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
                {dataSourcesConfig.map((source) => {
                  const uploaded = files.find((f) => f.source_type === source.type)
                  const hasFile = !!uploaded
                  const status = hasFile ? (uploaded.status === 'error' ? 'error' as const : 'imported' as const) : 'pending' as const
                  
                  return (
                    <DataSourceCard
                      key={source.type}
                      name={source.name}
                      subtitle={source.subtitle}
                      Icon={source.Icon}
                      status={status}
                      lastUpdated={hasFile ? tSources('recently') : undefined}
                      onImport={() => router.push(`/${locale}/events/${eventId}/sources`)}
                    />
                  )
                })}
              </div>
            </div>
          </div>

          {/* Right panel — col-span-4 */}
          <div className="col-span-12 space-y-5 lg:col-span-4">
            {/* Exceptions Summary */}
            <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white p-5 shadow-[var(--shadow-card)]">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-[var(--color-text-primary)]">
                  {t('exceptionsSummary')}
                </h3>
                {activeExceptionsCount > 0 && (
                  <Link
                    href={`/${locale}/events/${eventId}/exceptions`}
                    className="text-xs font-medium text-[var(--color-text-primary)] hover:underline"
                  >
                    {tActions('viewAll')}
                  </Link>
                )}
              </div>
              <div className="space-y-1">
                <ExceptionItem
                  type={tExceptions('conflict')}
                  count={conflictsCount}
                  severity="critical"
                  onClick={() => router.push(`${exceptionsBase}?type=conflict`)}
                />
                <ExceptionItem
                  type={tExceptions('duplicate')}
                  count={duplicatesCount}
                  severity="warning"
                  onClick={() => router.push(`${exceptionsBase}?type=duplicate`)}
                />
                <ExceptionItem
                  type={tExceptions('notFound')}
                  count={notFoundCount}
                  severity="warning"
                  onClick={() => router.push(`${exceptionsBase}?type=not_found`)}
                />
                <ExceptionItem
                  type={tExceptions('otherAlerts')}
                  count={toCheckCount}
                  severity="info"
                  onClick={() => router.push(exceptionsBase)}
                />
              </div>
            </div>

            {/* Priorities — the same ranking the assistant reasons with, so the
                page and the answer cannot disagree. The fixed checklist below
                is kept for a brand-new event, where there is nothing to rank
                yet and the onboarding order is the useful thing to show. */}
            {dash && dash.priorities.length > 0 ? (
              <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white p-5 shadow-[var(--shadow-card)]">
                <h3 className="mb-1 text-sm font-semibold text-[var(--color-text-primary)]">
                  {tDash('priorities')}
                </h3>
                <p className="mb-4 text-xs text-[var(--color-text-secondary)]">
                  {tDash('prioritiesHint')}
                </p>
                <ul className="space-y-2.5">
                  {dash.priorities.slice(0, 6).map((pr, i) => (
                    <li key={i} className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm text-[var(--color-text-primary)]">{pr.point}</p>
                        <p className="text-xs text-[var(--color-text-secondary)]">{pr['où']}</p>
                      </div>
                      <span className="shrink-0 rounded-full bg-[var(--color-bg-subtle)] px-2 py-0.5 text-xs font-bold text-[var(--color-text-primary)]">
                        {pr.nombre}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
            <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white p-5 shadow-[var(--shadow-card)]">
              <h3 className="mb-4 text-sm font-semibold text-[var(--color-text-primary)]">
                {t('nextSteps')}
              </h3>
              <ul className="space-y-2.5">
                {[
                  { done: files.length > 0, label: tDash('stepImport') },
                  { done: totalParticipants > 0, label: tActions('consolidate') },
                  { done: conflictsCount === 0 && totalParticipants > 0, label: tDash('stepResolve') },
                  { done: duplicatesCount === 0 && totalParticipants > 0, label: tDash('stepDuplicates') },
                  { done: totalParticipants > 0 && activeExceptionsCount === 0, label: tDash('stepExport') },
                ].map((step, i) => (
                  <li key={i} className="flex items-start gap-2.5">
                    <div
                      className={`mt-0.5 flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full border-2 ${
                        step.done
                          ? 'border-[var(--color-text-primary)] bg-[var(--color-text-primary)]'
                          : 'border-[var(--color-border-strong)] bg-white'
                      }`}
                    >
                      {step.done && <CheckCircle2 className="h-2.5 w-2.5 text-white" />}
                    </div>
                    <span
                      className={`text-sm ${
                        step.done
                          ? 'text-[var(--color-text-secondary)] line-through'
                          : 'text-[var(--color-text-primary)]'
                      }`}
                    >
                      {step.label}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
            )}
          </div>
        </div>

        {/* Who still owes us their list */}
        {dash && <CompanyGaps companies={dash.companies} />}
      </div>
    </AppLayout>
  )
}
