'use client'

import React, { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import { useTranslations } from 'next-intl'
import { AppLayout } from '@/components/layout/AppLayout'
import { KPICard } from '@/components/ui/KPICard'
import { Truck, Users, Compass, Search, UserX, Bus } from 'lucide-react'
import { api, type Transfer } from '@/lib/api'
import { ConcernedParticipants, type CohortRow } from '@/components/ui/ConcernedParticipants'
import { TransferPlanner } from '@/components/ui/TransferPlanner'
import { TransferGroupedList, clumpKey } from '@/components/ui/TransferGroupedList'

export default function TransfersPage() {
  const tTr = useTranslations('transfers')
  const { eventId, locale } = useParams() as { eventId: string; locale: string }
  const t = useTranslations('transfers')
  const [transfers, setTransfers] = useState<Transfer[]>([])
  const [masterRows, setMasterRows] = useState<CohortRow[]>([])
  const [showMissing, setShowMissing] = useState(false)
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')

  // The event's own fleet, so the planner offers the vehicles MAX actually has
  // rather than a hardcoded list. Falls back to the defaults the API resolves.
  const [fleet, setFleet] = useState<{ name: string; capacity: number }[]>([])

  useEffect(() => {
    let cancelled = false
    api.transfers.getSettings(eventId)
      .then((s) => { if (!cancelled) setFleet(s.vehicles) })
      .catch(() => { /* the planner degrades to "no vehicle" on its own */ })
    return () => { cancelled = true }
  }, [eventId])

  const fetchTransfers = async () => {
    try {
      setLoading(true)
      const [data, master] = await Promise.all([
        api.transfers.list(eventId),
        api.masterList.get(eventId).catch(() => ({ items: [] as CohortRow[] })),
      ])
      setTransfers(data)
      setMasterRows((master.items as CohortRow[]) || [])
    } catch (err) {
      console.error('Failed to fetch transfers', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchTransfers()
  }, [eventId])

  const filteredTransfers = transfers.filter(t =>
    (t.participant_name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.pickup_location.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.dropoff_location.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const withoutTransfer = masterRows.filter(r => !r.has_transfer)
  // Counted the way the list groups, not by pickup time alone.
  const vehicleCount = new Set(transfers.map(clumpKey)).size

  // Clicking a KPI scrolls to the detailed list of concerned participants (§12)
  const scrollToDetailList = () => {
    document.getElementById('detail-list')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <AppLayout eventId={eventId} locale={locale}>
      <div className="flex flex-col gap-6 p-6">
        {/* Header */}
        <div className="flex justify-between items-center border-b pb-5">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text-primary)] flex items-center gap-2">
              <Bus className="h-6 w-6 text-[var(--color-accent)]" />
              {t('title')}
            </h1>
            <p className="text-sm text-[var(--color-text-secondary)]">
              {t('subtitle')}
            </p>
          </div>
        </div>


        {/* The plan the flights imply, proposed and never applied on its own
            (feedback §1). Placed above the existing list because it is the
            step that fills it. */}
        <TransferPlanner
          eventId={eventId}
          vehicles={fleet}
          onApplied={() => window.location.reload()}
        />

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <KPICard
            label={t('kpiTransfers')}
            value={transfers.length}
            icon={<Truck className="h-5 w-5" />}
            onClick={scrollToDetailList}
          />
          <KPICard
            label={t('kpiGrouped')}
            value={vehicleCount}
            icon={<Compass className="h-5 w-5" />}
            onClick={scrollToDetailList}
          />
          <KPICard
            label={t('kpiShuttles')}
            value={vehicleCount > 0 ? (transfers.length / vehicleCount).toFixed(1) : 0}
            icon={<Users className="h-5 w-5" />}
            onClick={scrollToDetailList}
          />
          <KPICard
            label={tTr('withoutTransfer')}
            value={withoutTransfer.length}
            icon={<UserX className="h-5 w-5" />}
            onClick={() => setShowMissing(v => !v)}
            active={showMissing}
          />
        </div>

        {/* Concerned participants: those without any transfer (§12) */}
        {showMissing && (
          <ConcernedParticipants
            rows={withoutTransfer}
            title={tTr('withoutTransferTitle')}
            action={tTr('withoutTransferAction')}
            emptyText={tTr('allHaveTransfer')}
            locale={locale}
            eventId={eventId}
          />
        )}

        {/* Search */}
        <div id="detail-list" className="flex items-center gap-2 max-w-md bg-white border rounded-lg px-3 py-2 shadow-sm scroll-mt-24">
          <Search className="h-4 w-4 text-[var(--color-text-secondary)]" />
          <input
            type="text"
            placeholder={t('searchPlaceholder')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-sm outline-none bg-transparent"
          />
        </div>

        {/* Transfers list, grouped by who is actually travelling together.
            Everything here is a real booking: editing saves immediately,
            there is no separate "apply" step like the planner above. */}
        <div className="rounded-[var(--radius-card)] border bg-white shadow-sm overflow-hidden">
          {loading ? (
            <div className="space-y-3 p-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-16 animate-pulse rounded-lg bg-slate-100" />
              ))}
            </div>
          ) : (
            <TransferGroupedList
              eventId={eventId}
              transfers={filteredTransfers}
              locale={locale}
              vehicles={fleet}
              onChanged={fetchTransfers}
            />
          )}
        </div>
      </div>
    </AppLayout>
  )
}
