'use client'

import { useState, useEffect, useCallback } from 'react'
import { useTranslations } from 'next-intl'
import { useParams } from 'next/navigation'
import { AppLayout } from '@/components/layout/AppLayout'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Link2, Copy, Check, Loader2, ExternalLink, Users, Info, AlertTriangle, RefreshCw, ListChecks, Lock, GripVertical } from 'lucide-react'
import { api, errorMessage, type RegistrationFieldState, type RegistrationBadge, type RegistrationProposal } from '@/lib/api'
import { cn } from '@/lib/utils'
import { DEFAULT_THEME, resolveTheme, type RegistrationTheme } from '@/lib/registrationTheme'
import { reordered, useReorder } from '@/lib/useReorder'
import { RegistrationLayoutEditor } from '@/components/ui/RegistrationLayoutEditor'
import { RegistrationAssistantPanel } from '@/components/ui/RegistrationAssistantPanel'
import { RegistrationExtrasEditor } from '@/components/ui/RegistrationExtrasEditor'
import { EventLogoUpload } from '@/components/ui/EventLogoUpload'
import { RegistrationBadgesEditor } from '@/components/ui/RegistrationBadgesEditor'

export default function RegistrationFormPage() {
  const t = useTranslations('registrationForm')
  // The page is titled with the name the navigation uses to reach it.
  const tNav = useTranslations('nav')
  const tAct = useTranslations('actions')
  const params = useParams()
  const locale = params.locale as string
  const eventId = params.eventId as string

  const [link, setLink] = useState<{ url: string; is_open: boolean } | null>(null)
  const [loading, setLoading] = useState(true)
  const [unavailable, setUnavailable] = useState<string | null>(null)
  const [toggling, setToggling] = useState(false)
  const [copied, setCopied] = useState(false)
  const [copiedBadge, setCopiedBadge] = useState<string | null>(null)
  const [submissions, setSubmissions] = useState<number | null>(null)
  const [actionError, setActionError] = useState<string | null>(null)
  const [refreshing, setRefreshing] = useState(false)

  // Which questions the form asks. Edited locally, saved in one go: toggling
  // twenty fields one PUT at a time would be twenty chances to half-save.
  const [fields, setFields] = useState<RegistrationFieldState[] | null>(null)
  const [savingFields, setSavingFields] = useState(false)
  const [fieldsSaved, setFieldsSaved] = useState(false)
  const [fieldsError, setFieldsError] = useState<string | null>(null)

  // How the form looks (migration 030). Held here rather than inside the
  // editor because the assistant can rewrite it too, and two owners of one
  // theme is how a preview starts disagreeing with what was saved.
  // Owned here so the AI assistant can also set it (applyProposal); the layout
  // editor renders its controls under "Apparence" and saves it with the rest.
  const [theme, setTheme] = useState<RegistrationTheme>(DEFAULT_THEME)
  // The real name, so the appearance preview shows the actual heading a
  // participant will read rather than a placeholder standing in for it.
  // Questions the assistant proposed that the catalogue cannot hold. Handed
  // down to the extras editor, which is the panel that owns them.
  const [suggestedQuestions, setSuggestedQuestions] = useState<{ label: string; type: string }[]>([])

  // Named audiences (point 13, v1). Loaded once here so both the badges
  // manager and the per-field checkboxes below share the same list — a
  // field cannot be restricted to a badge that no longer exists.
  const [badges, setBadges] = useState<RegistrationBadge[] | null>(null)

  const loadLink = useCallback(async (fresh = false) => {
    try {
      const info = await api.events.getRegistrationLink(eventId, { fresh })
      // Built from the browser's own origin + the organizer's current locale,
      // so the shared link matches the domain in use and opens in their
      // language (the API's own url hardcodes /fr/).
      setLink({ url: `${window.location.origin}/${locale}/register/${info.token}`, is_open: info.is_open })
      setSubmissions(info.submissions)
      setUnavailable(null)
    } catch (err) {
      setUnavailable(errorMessage(err, t('errUnavailable')))
      setLink(null)
    } finally {
      setLoading(false)
    }
  }, [eventId, locale])

  useEffect(() => {
    loadLink()
  }, [loadLink])

  useEffect(() => {
    let cancelled = false
    api.events
      .getRegistrationFields(eventId)
      .then((res) => { if (!cancelled) setFields(res.fields) })
      .catch((err) => {
        if (!cancelled) setFieldsError(errorMessage(err, t('errFieldsUnavailable')))
      })
    return () => { cancelled = true }
  }, [eventId])

  useEffect(() => {
    let cancelled = false
    api.events
      .getRegistrationTheme(eventId)
      .then((res) => { if (!cancelled) setTheme(resolveTheme(res.theme)) })
      // An event on a deployment without migration 030 has no theme to read.
      // The defaults are already in state and are exactly what its form
      // renders, so there is nothing to report and nothing to fix.
      .catch(() => {})
    return () => { cancelled = true }
  }, [eventId])

  useEffect(() => {
    let cancelled = false
    api.events
      .getRegistrationBadges(eventId)
      .then((res) => { if (!cancelled) setBadges(res.badges) })
      .catch(() => { if (!cancelled) setBadges([]) })
    return () => { cancelled = true }
  }, [eventId])

  const toggleField = (key: string, patch: Partial<RegistrationFieldState>) => {
    setFieldsSaved(false)
    setFields((prev) =>
      prev?.map((f) => {
        if (f.key !== key || f.locked) return f
        const next = { ...f, ...patch }
        // A hidden question cannot be mandatory — that pair would make the
        // form impossible to submit. The backend enforces it too; doing it
        // here as well means the checkbox never looks checked in a state that
        // will not survive the save.
        if (!next.enabled) next.required = false
        return next
      }) ?? prev
    )
  }

  const toggleFieldBadge = (key: string, badgeId: string) => {
    setFieldsSaved(false)
    setFields((prev) =>
      prev?.map((f) => {
        if (f.key !== key || f.locked) return f
        const has = f.badges.includes(badgeId)
        return { ...f, badges: has ? f.badges.filter((b) => b !== badgeId) : [...f.badges, badgeId] }
      }) ?? prev
    )
  }

  // Point 13 (v1): the order fields ask in, on both this table and the actual
  // public form. Moves within the same flat list this state already is — no
  // separate order array to keep in sync.
  //
  // Blocked across groups: the table is DRAWN in groups, so a question dropped
  // among another group's rows would reappear where it started. Refusing the
  // drop says that; accepting it and doing nothing does not.
  const reorder = useReorder(
    fields?.length ?? 0,
    (from, to) => {
      setFieldsSaved(false)
      setFields((prev) => (prev ? reordered(prev, from, to) : prev))
    },
    (from, to) => !fields || fields[from].group !== fields[to].group,
  )

  /** Take the assistant's whole proposal into the editor — and no further.
   *
   *  Nothing here writes to the server. The organizer still reviews the table
   *  and presses Save, which keeps "the assistant suggested it" and "I
   *  published it to three hundred people" as two separate decisions. */
  const applyProposal = (proposal: RegistrationProposal) => {
    setFieldsSaved(false)
    setFields((prev) => {
      if (!prev) return prev
      const byKey = new Map(prev.map((f) => [f.key, f]))
      const named = new Set(proposal.order)
      const ordered = proposal.order
        .map((key) => byKey.get(key))
        .filter((f): f is RegistrationFieldState => Boolean(f))
      // A field the proposal never mentioned keeps its place at the end
      // rather than vanishing from a table the organizer is reading.
      ordered.push(...prev.filter((f) => !named.has(f.key)))
      return ordered.map((f) => {
        const patch = proposal.fields[f.key]
        if (!patch || f.locked) return f
        return { ...f, enabled: patch.enabled, required: patch.enabled && patch.required }
      })
    })
    setTheme(resolveTheme(proposal.theme))
    setSuggestedQuestions(proposal.custom_fields)
  }

  const handleSaveFields = async () => {
    if (!fields || savingFields) return
    setSavingFields(true)
    setFieldsError(null)
    try {
      const payload = Object.fromEntries(
        fields.map((f) => [f.key, { enabled: f.enabled, required: f.required, badges: f.badges }])
      )
      const order = fields.map((f) => f.key)
      const res = await api.events.setRegistrationFields(eventId, payload, order)
      setFields(res.fields)
      setFieldsSaved(true)
    } catch (err) {
      setFieldsError(errorMessage(err, t('errSaveFields')))
    } finally {
      setSavingFields(false)
    }
  }

  const handleCopy = async () => {
    if (!link) return
    try {
      await navigator.clipboard.writeText(link.url)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      setActionError(t('errCopy'))
    }
  }

  const handleCopyBadgeLink = async (badgeId: string, url: string) => {
    try {
      await navigator.clipboard.writeText(url)
      setCopiedBadge(badgeId)
      setTimeout(() => setCopiedBadge((prev) => (prev === badgeId ? null : prev)), 2000)
    } catch {
      setActionError(t('errCopy'))
    }
  }

  const handleToggle = async () => {
    if (!link || toggling) return
    setToggling(true)
    setActionError(null)
    try {
      const res = await api.events.setRegistrationOpen(eventId, !link.is_open)
      setLink((prev) => (prev ? { ...prev, is_open: res.is_open } : prev))
    } catch (err) {
      setActionError(errorMessage(err, t('errToggle')))
    } finally {
      setToggling(false)
    }
  }

  return (
    <AppLayout
      eventId={eventId}
      locale={locale}
    >
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text-primary)] flex items-center gap-2">
            <Link2 className="h-6 w-6 text-[var(--color-accent)]" />
            {tNav('registrationForm')}
          </h1>
          <p className="mt-1 text-sm text-[var(--color-text-secondary)]">
            {t('sendThisLink')}
          </p>
        </div>

        {actionError && (
          <div className="rounded-lg border border-[var(--color-danger)] bg-[var(--color-danger-light)] px-4 py-3 text-sm text-[var(--color-danger)]">
            {actionError}
          </div>
        )}

        {loading ? (
          <Card className="flex items-center gap-2 p-6 text-sm text-[var(--color-text-secondary)]">
            <Loader2 className="h-4 w-4 animate-spin" />
            {t('loadingLink')}
          </Card>
        ) : unavailable ? (
          <Card className="p-6">
            <div className="flex items-start gap-3">
              <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-[var(--color-warning)]" />
              <div>
                <p className="text-sm font-semibold text-[var(--color-text-primary)]">
                  {t('linkUnavailable')}
                </p>
                <p className="mt-1 text-sm text-[var(--color-text-secondary)]">{unavailable}</p>
              </div>
            </div>
          </Card>
        ) : link ? (
          <>
            <Card className="p-6">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-start gap-3">
                  <Link2 className="mt-0.5 h-5 w-5 shrink-0 text-[var(--color-accent)]" />
                  <div>
                    <p className="text-sm font-semibold text-[var(--color-text-primary)]">
                      {t('publicLink')}
                    </p>
                    <p className="text-xs text-[var(--color-text-secondary)]">
                      {t('noAccountNeeded')}
                    </p>
                  </div>
                </div>
                <Badge
                  variant="outline"
                  className={
                    link.is_open
                      ? 'border-[var(--color-success)] bg-[var(--color-success-light)] text-[var(--color-success)]'
                      : 'border-[var(--color-text-secondary)] bg-slate-50 text-[var(--color-text-secondary)]'
                  }
                >
                  {link.is_open ? t('registrationsOpen') : t('registrationsClosed')}
                </Badge>
              </div>

              <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center">
                <input
                  readOnly
                  value={link.url}
                  onFocus={(e) => e.currentTarget.select()}
                  className="w-full flex-1 truncate rounded-md border border-[var(--color-border)] bg-slate-50 px-3 py-2 text-xs text-[var(--color-text-secondary)] outline-none"
                />
                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" type="button" onClick={handleCopy} className="flex items-center gap-1.5 whitespace-nowrap">
                    {copied ? <Check className="h-3.5 w-3.5 text-[var(--color-success)]" /> : <Copy className="h-3.5 w-3.5" />}
                    {copied ? t('copied') : tAct('copy')}
                  </Button>
                  <a href={link.url} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" type="button" className="flex items-center gap-1.5 whitespace-nowrap">
                      <ExternalLink className="h-3.5 w-3.5" />
                      {t('preview')}
                    </Button>
                  </a>
                  <Button
                    variant="outline"
                    type="button"
                    onClick={handleToggle}
                    disabled={toggling}
                    className="whitespace-nowrap"
                  >
                    {toggling ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : link.is_open ? t('closeRegistrations') : t('reopenRegistrations')}
                  </Button>
                </div>
              </div>

              {!link.is_open && (
                <p className="mt-3 text-xs text-[var(--color-text-secondary)]">
                  {t('closedHint')}
                </p>
              )}

              {/* Point 13 (v1): the same token, one variant per badge. A
                  visitor never picks their own audience — it comes from
                  which of these links they were sent. */}
              {badges && badges.length > 0 && (
                <div className="mt-4 space-y-2 border-t border-[var(--color-border)] pt-4">
                  <p className="text-xs font-semibold uppercase tracking-wider text-[var(--color-text-secondary)]">
                    {t('badgeLinks')}
                  </p>
                  {badges.map((b) => {
                    const badgeUrl = `${link.url}?badge=${encodeURIComponent(b.id)}`
                    return (
                      <div key={b.id} className="flex flex-col gap-2 sm:flex-row sm:items-center">
                        <span className="w-full shrink-0 text-xs font-medium text-[var(--color-text-primary)] sm:w-28">
                          {b.name}
                        </span>
                        <input
                          readOnly
                          value={badgeUrl}
                          onFocus={(e) => e.currentTarget.select()}
                          className="w-full flex-1 truncate rounded-md border border-[var(--color-border)] bg-slate-50 px-3 py-1.5 text-xs text-[var(--color-text-secondary)] outline-none"
                        />
                        <Button
                          variant="outline"
                          type="button"
                          onClick={() => handleCopyBadgeLink(b.id, badgeUrl)}
                          className="flex shrink-0 items-center gap-1.5 whitespace-nowrap py-1.5"
                        >
                          {copiedBadge === b.id ? <Check className="h-3.5 w-3.5 text-[var(--color-success)]" /> : <Copy className="h-3.5 w-3.5" />}
                          {copiedBadge === b.id ? t('copied') : 'Copier'}
                        </Button>
                      </div>
                    )
                  })}
                </div>
              )}
            </Card>

            <div className="grid gap-4 sm:grid-cols-2">
              <Card className="p-5">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <Users className="h-5 w-5 text-[var(--color-accent)]" />
                    <div>
                      <p className="text-2xl font-bold text-[var(--color-text-primary)]">
                        {submissions === null ? '—' : submissions}
                      </p>
                      <p className="text-xs text-[var(--color-text-secondary)]">
                        {submissions === null
                          ? t('repliesUnavailable')
                          : submissions === 0
                          ? t('repliesNone')
                          : submissions === 1
                          ? t('repliesOne')
                          : t('repliesMany')}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => { setRefreshing(true); loadLink(true).finally(() => setRefreshing(false)) }}
                    disabled={refreshing}
                    title={t('refreshCount')}
                    className="rounded-lg p-2 text-[var(--color-text-secondary)] transition-colors hover:bg-[var(--color-bg-subtle)] disabled:opacity-50"
                  >
                    <RefreshCw className={'h-4 w-4' + (refreshing ? ' animate-spin' : '')} />
                  </button>
                </div>
              </Card>

              <Card className="p-5">
                <div className="flex items-start gap-3">
                  <Info className="mt-0.5 h-5 w-5 shrink-0 text-[var(--color-text-secondary)]" />
                  <p className="text-xs leading-relaxed text-[var(--color-text-secondary)]">
                    {t('autoConsolidated')}
                  </p>
                </div>
              </Card>
            </div>

            {/* Describe the event, get a form. First, because it is the
                fastest way to fill in everything below — and because an
                organizer who prefers to click past it loses nothing. */}
            <RegistrationAssistantPanel eventId={eventId} onApply={applyProposal} />

            {/* Which questions the form asks */}
            <Card className="p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <ListChecks className="mt-0.5 h-5 w-5 shrink-0 text-[var(--color-accent)]" />
                  <div>
                    <p className="text-sm font-semibold text-[var(--color-text-primary)]">
                      {t('fieldsTitle')}
                    </p>
                    <p className="mt-0.5 text-xs text-[var(--color-text-secondary)]">
                      {t('fieldsHint')}
                    </p>
                  </div>
                </div>
                {fields && (
                  <div className="flex items-center gap-3">
                    {fieldsSaved && (
                      <span className="flex items-center gap-1 text-xs font-medium text-[var(--color-success)]">
                        <Check className="h-3.5 w-3.5" /> {t('saved')}
                      </span>
                    )}
                    <Button type="button" onClick={handleSaveFields} disabled={savingFields}>
                      {savingFields ? <Loader2 className="h-4 w-4 animate-spin" /> : tAct('save')}
                    </Button>
                  </div>
                )}
              </div>

              {fieldsError && (
                <p className="mt-4 rounded-lg border border-[var(--color-danger)] bg-[var(--color-danger-light)] px-3 py-2 text-xs text-[var(--color-danger)]">
                  {fieldsError}
                </p>
              )}

              {!fields ? (
                !fieldsError && (
                  <p className="mt-4 flex items-center gap-2 text-sm text-[var(--color-text-secondary)]">
                    <Loader2 className="h-4 w-4 animate-spin" /> {t('loadingFields')}
                  </p>
                )
              ) : (
                <div className="mt-5 space-y-5">
                  {Array.from(new Set(fields.map((f) => f.group))).map((group) => (
                    <div key={group}>
                      <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-[var(--color-text-secondary)]">
                        {group}
                      </p>
                      <div className="overflow-hidden rounded-lg border border-[var(--color-border)]">
                        <div className="flex items-center gap-4 border-b bg-[var(--color-bg-subtle)] px-4 py-2 text-[11px] font-medium text-[var(--color-text-secondary)]">
                          <span className="w-14 shrink-0 text-center">{t('thOrder')}</span>
                          <span className="flex-1">{t('thQuestion')}</span>
                          <span className="w-20 text-center">{t('thShown')}</span>
                          <span className="w-24 text-center">{t('thRequired')}</span>
                          {badges && badges.length > 0 && <span className="w-48 shrink-0">Badges</span>}
                        </div>
                        {fields.filter((f) => f.group === group).map((f) => {
                          const globalIndex = fields.findIndex((x) => x.key === f.key)
                          return (
                          <div
                            key={f.key}
                            {...reorder.rowProps(globalIndex)}
                            className={cn(
                              'flex items-center gap-4 border-b px-4 py-2.5 last:border-0 transition-colors',
                              reorder.dragging === globalIndex && 'opacity-40',
                              reorder.over === globalIndex && 'bg-[var(--color-accent-light)]'
                            )}
                          >
                            <span className="flex w-14 shrink-0 items-center justify-center">
                              <button
                                type="button"
                                {...reorder.handleProps(globalIndex)}
                                title={t('reorderHint')}
                                aria-label={t('reorderField', { name: f.label })}
                                className="cursor-grab rounded p-1 text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-subtle)] active:cursor-grabbing"
                              >
                                <GripVertical className="h-4 w-4" />
                              </button>
                            </span>
                            <span className="flex flex-1 items-center gap-2 text-sm text-[var(--color-text-primary)]">
                              {f.label}
                              {f.locked && (
                                <span
                                  className="inline-flex items-center gap-1 rounded-full bg-[var(--color-bg-subtle)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text-secondary)]"
                                  title={t('lockedHint')}
                                >
                                  <Lock className="h-3 w-3" /> {t('lockedRequired')}
                                </span>
                              )}
                            </span>
                            <span className="w-20 text-center">
                              <input
                                type="checkbox"
                                checked={f.enabled}
                                disabled={f.locked}
                                onChange={(e) => toggleField(f.key, { enabled: e.target.checked })}
                                className="h-4 w-4 rounded border-[var(--color-border)] disabled:opacity-40"
                              />
                            </span>
                            <span className="w-24 text-center">
                              <input
                                type="checkbox"
                                checked={f.required}
                                disabled={f.locked || !f.enabled}
                                onChange={(e) => toggleField(f.key, { required: e.target.checked })}
                                className="h-4 w-4 rounded border-[var(--color-border)] disabled:opacity-40"
                              />
                            </span>
                            {badges && badges.length > 0 && (
                              <span className="flex w-48 shrink-0 flex-wrap gap-1">
                                {f.locked ? (
                                  <span className="text-[10px] text-[var(--color-text-secondary)]">{t('everyone')}</span>
                                ) : (
                                  badges.map((b) => {
                                    const active = f.badges.includes(b.id)
                                    return (
                                      <button
                                        key={b.id}
                                        type="button"
                                        onClick={() => toggleFieldBadge(f.key, b.id)}
                                        title={active ? t('visibleOnlyFor', { name: b.name }) : t('makeVisibleFor', { name: b.name })}
                                        className={
                                          'rounded-full border px-2 py-0.5 text-[10px] font-medium transition-colors ' +
                                          (active
                                            ? 'border-[var(--color-accent)] bg-[var(--color-accent)] text-white'
                                            : 'border-[var(--color-border)] text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-subtle)]')
                                        }
                                      >
                                        {b.name}
                                      </button>
                                    )
                                  })
                                )}
                              </span>
                            )}
                          </div>
                          )
                        })}
                      </div>
                    </div>
                  ))}
                  {badges && badges.length > 0 && (
                    <p className="text-xs text-[var(--color-text-secondary)]">
                      {t('badgesHint')}
                    </p>
                  )}
                </div>
              )}
            </Card>

            {/* Named audiences (point 13, v1) — sits right after the fields
                table because a badge's whole purpose is restricting fields
                above, and its own links live in the "Lien public" card above
                that. */}
            <Card className="p-6">
              <RegistrationBadgesEditor eventId={eventId} badges={badges} onSaved={setBadges} />
            </Card>

            {/* The organizer's own questions and contractual tick-boxes (§9).
                Sits under the catalogue because it answers the question the
                catalogue leaves open: what to ask that nobody anticipated. */}
            <Card className="p-6">
              <RegistrationExtrasEditor
                eventId={eventId}
                suggestions={suggestedQuestions}
                onSuggestionsUsed={() => setSuggestedQuestions([])}
              />
            </Card>

            {/* Every page of the link — the registration page and each mini-site
                section — composed in blocks, multilingual, in one editor. It
                absorbs the old "Contenu du lien" and "Apparence" cards: page
                appearance, titles, order, visibility and blocks all live here. */}
            <RegistrationLayoutEditor
              eventId={eventId}
              theme={theme}
              onThemeChange={setTheme}
            />

            {/* This event's own branding (point 11). */}
            <EventLogoUpload eventId={eventId} />
          </>
        ) : null}
      </div>
    </AppLayout>
  )
}
