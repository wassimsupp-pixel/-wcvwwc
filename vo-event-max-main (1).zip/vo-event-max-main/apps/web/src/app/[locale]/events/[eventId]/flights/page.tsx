'use client'

import React, { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import { useTranslations } from 'next-intl'
import { formatScheduleTime, localeTag } from '@/lib/dates'
import { AppLayout } from '@/components/layout/AppLayout'
import { KPICard } from '@/components/ui/KPICard'
import { TableSkeleton } from '@/components/ui/TableSkeleton'
import { Plane, Upload, AlertCircle, RefreshCw, CheckCircle, Search, UserX, Plus, AlertTriangle, CheckCircle2 } from 'lucide-react'
import { api, errorMessage, type ParticipantLookupItem } from '@/lib/api'
import { ConcernedParticipants, type CohortRow } from '@/components/ui/ConcernedParticipants'
import { OwnExpenseAlert } from '@/components/ui/OwnExpenseAlert'

interface Flight {
  id: string
  participant_id?: string
  pnr_code?: string
  airline?: string
  flight_number: string
  departure_airport: string
  arrival_airport: string
  departure_time: string
  arrival_time: string
  baggage_info?: string
  status: string
  participant_name?: string
}

interface PassengerFlights {
  key: string
  participant_id?: string
  participant_name: string
  segments: Flight[]
}

export default function FlightsPage() {
  const { eventId, locale } = useParams() as { eventId: string; locale: string }
  const t = useTranslations('flights')
  const tf = useTranslations('fields')
  const tAct = useTranslations('actions')
  const [flights, setFlights] = useState<Flight[]>([])
  const [loading, setLoading] = useState(true)
  const [extracting, setExtracting] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusMessage, setStatusMessage] = useState('')
  const [statusFilter, setStatusFilter] = useState<'all' | 'confirmed' | 'cancelled'>('all')
  const [masterRows, setMasterRows] = useState<CohortRow[]>([])
  const [showMissing, setShowMissing] = useState(false)

  // "Ajouter un vol" — the counterpart of the rooming form on the hébergements
  // page: a flight that arrives by email instead of in the FCM export can be
  // recorded here and lands in the master list straight away.
  const [participants, setParticipants] = useState<ParticipantLookupItem[]>([])
  const [flightParticipantId, setFlightParticipantId] = useState('')
  const [participantSearch, setParticipantSearch] = useState('')
  const [showParticipantDropdown, setShowParticipantDropdown] = useState(false)
  const [newFlight, setNewFlight] = useState({
    flight_number: '', airline: '', pnr_code: '',
    departure_airport: '', arrival_airport: '',
    departure_date: '', departure_hour: '', arrival_date: '', arrival_hour: '',
  })
  const [addingFlight, setAddingFlight] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)
  const [actionSuccess, setActionSuccess] = useState<string | null>(null)

  const fetchFlights = async () => {
    try {
      setLoading(true)
      const [data, master, partList] = await Promise.all([
        api.flights.list(eventId),
        api.participants.coverage(eventId).catch(() => ({ items: [] as CohortRow[] })),
        api.participants.lookup(eventId).catch(() => [] as ParticipantLookupItem[]),
      ])
      setFlights(data)
      setMasterRows((master.items as CohortRow[]) || [])
      setParticipants(partList)
    } catch (err) {
      console.error('Failed to fetch flights', err)
    } finally {
      setLoading(false)
    }
  }

  const handleAddFlight = async (e: React.FormEvent) => {
    e.preventDefault()
    if (addingFlight) return
    if (!flightParticipantId) {
      setActionError(t('errPickParticipant'))
      return
    }
    const f = newFlight
    if (!f.flight_number || !f.departure_airport || !f.arrival_airport
        || !f.departure_date || !f.arrival_date) {
      setActionError(t('errRequiredFields'))
      return
    }
    // Times are sent as UTC instants: a bare "2027-03-14T08:00" would be read
    // as local time by the browser and shift the flight by the timezone offset
    // once it comes back (the same trap the rooming dates hit).
    const departure_time = `${f.departure_date}T${f.departure_hour || '00:00'}:00Z`
    const arrival_time = `${f.arrival_date}T${f.arrival_hour || '00:00'}:00Z`
    if (arrival_time < departure_time) {
      setActionError(t('errArrivalBeforeDeparture'))
      return
    }
    setAddingFlight(true)
    setActionError(null)
    setActionSuccess(null)
    try {
      await api.flights.create(eventId, {
        participant_id: flightParticipantId,
        flight_number: f.flight_number,
        departure_airport: f.departure_airport,
        arrival_airport: f.arrival_airport,
        departure_time,
        arrival_time,
        airline: f.airline || undefined,
        pnr_code: f.pnr_code || undefined,
      })
      setActionSuccess(
        t('flightAdded', { flight: f.flight_number.toUpperCase(), who: participantSearch || t('theParticipant') })
      )
      setNewFlight({
        flight_number: '', airline: '', pnr_code: '',
        departure_airport: '', arrival_airport: '',
        departure_date: '', departure_hour: '', arrival_date: '', arrival_hour: '',
      })
      setFlightParticipantId('')
      setParticipantSearch('')
      await fetchFlights()
    } catch (err) {
      setActionError(errorMessage(err, t('errAddFlight')))
    } finally {
      setAddingFlight(false)
    }
  }

  // Pre-fills the add form from a participant clicked in the "Sans vol" list.
  const handleQuickAddFlight = (row: CohortRow) => {
    setFlightParticipantId(row.id)
    setParticipantSearch([row.first_name, row.last_name].filter(Boolean).join(' '))
    document.getElementById('add-flight-form')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  const scrollToDetailList = () => {
    document.getElementById('detail-list')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  useEffect(() => {
    fetchFlights()
  }, [eventId])

  const handleExtract = async () => {
    try {
      setExtracting(true)
      setStatusMessage('')
      const res = await api.flights.extract(eventId)
      setStatusMessage(t('extractSuccess') + ': ' + res.message)
      await fetchFlights()
    } catch (err) {
      console.error('Failed to extract flights', err)
      setStatusMessage(t('extractError'))
    } finally {
      setExtracting(false)
    }
  }

  const filteredFlights = flights.filter(f => {
    const q = searchTerm.toLowerCase()
    const matchesSearch =
      (f.participant_name || '').toLowerCase().includes(q) ||
      f.flight_number.toLowerCase().includes(q) ||
      (f.pnr_code || '').toLowerCase().includes(q)
    const matchesStatus = statusFilter === 'all' ? true : f.status === statusFilter
    return matchesSearch && matchesStatus
  })

  // Group segments by passenger: a round trip = outbound + return = ONE row,
  // not two. Keeps every segment but shows one line per participant.
  const groupedPassengers: PassengerFlights[] = (() => {
    const map = new Map<string, PassengerFlights>()
    for (const f of filteredFlights) {
      const key = f.participant_id || f.participant_name || f.id
      let g = map.get(key)
      if (!g) {
        g = { key, participant_id: f.participant_id, participant_name: f.participant_name || 'N/A', segments: [] }
        map.set(key, g)
      }
      g.segments.push(f)
    }
    const arr = Array.from(map.values())
    arr.forEach(g => g.segments.sort((a, b) => String(a.departure_time || '').localeCompare(String(b.departure_time || ''))))
    arr.sort((a, b) => a.participant_name.localeCompare(b.participant_name))
    return arr
  })()

  const segmentLabel = (count: number, idx: number) => {
    if (count < 2) return null
    if (idx === 0) return 'Aller'
    if (idx === count - 1) return 'Retour'
    return `Vol ${idx + 1}`
  }

  const missingFlightsCount = flights.filter(f => f.status === 'cancelled').length
  const withoutFlight = masterRows.filter(r => !r.has_flight)

  return (
    <AppLayout eventId={eventId} locale={locale}>
      <div className="flex flex-col gap-6 p-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b pb-5">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text-primary)] flex items-center gap-2">
              <Plane className="h-6 w-6 text-[var(--color-accent)]" />
              {t('title')}
            </h1>
            <p className="text-sm text-[var(--color-text-secondary)]">
              {t('subtitle')}
            </p>
          </div>
          <button
            onClick={handleExtract}
            disabled={extracting}
            className="flex items-center gap-2 rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[var(--color-accent)]/90 transition-colors disabled:opacity-50"
          >
            {extracting ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Upload className="h-4 w-4" />
            )}
            {t('extractButton')}
          </button>
        </div>

        {statusMessage && (
          <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-4 text-sm text-emerald-800 flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-emerald-600" />
            {statusMessage}
          </div>
        )}

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <KPICard
            label={t('kpiTotal')}
            value={flights.length}
            icon={<Plane className="h-5 w-5" />}
            onClick={() => { setStatusFilter('all'); setShowMissing(false) }}
            active={statusFilter === 'all' && !showMissing}
          />
          <KPICard
            label={t('kpiAirports')}
            value={new Set(flights.map(f => f.departure_airport)).size}
            icon={<Plane className="h-5 w-5 rotate-45" />}
            onClick={scrollToDetailList}
          />
          <KPICard
            label={t('kpiCancelled')}
            value={missingFlightsCount}
            icon={<AlertCircle className="h-5 w-5" />}
            onClick={() => { setStatusFilter('cancelled'); setShowMissing(false) }}
            active={statusFilter === 'cancelled' && !showMissing}
          />
          <KPICard
            label={t('kpiWithout')}
            value={withoutFlight.length}
            icon={<UserX className="h-5 w-5" />}
            onClick={() => setShowMissing(v => !v)}
            active={showMissing}
          />
        </div>

        {/* Whose own flight puts them outside the programme's dates. Here
            because this is the page where that flight is read. */}
        <OwnExpenseAlert rows={masterRows} locale={locale} eventId={eventId} context="flights" />

        {/* Concerned participants: those without any flight (§10) */}
        {showMissing && (
          <ConcernedParticipants
            rows={withoutFlight}
            title={t('withoutTitle')}
            action={t('withoutAction')}
            emptyText={t('withoutEmpty')}
            locale={locale}
            eventId={eventId}
            quickActionLabel={t('addFlight')}
            onQuickAction={handleQuickAddFlight}
          />
        )}

        {/* Add a flight by hand */}
        <div id="add-flight-form" className="rounded-[var(--radius-card)] border bg-white p-6 shadow-sm scroll-mt-24">
          <h2 className="mb-1 flex items-center gap-2 text-lg font-bold text-[var(--color-text-primary)]">
            <Plus className="h-5 w-5 text-[var(--color-accent)]" />
            {t('addFlight')}
          </h2>
          <p className="mb-4 text-xs text-[var(--color-text-secondary)]">
            {t('addFlightHint')}
          </p>
          <form onSubmit={handleAddFlight} className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div className="relative md:col-span-3">
              <label className="mb-1 block text-sm font-semibold text-[var(--color-text-secondary)]">
                {tf('participant')}
              </label>
              <input
                type="text"
                value={participantSearch}
                onChange={(e) => {
                  setParticipantSearch(e.target.value)
                  setFlightParticipantId('')
                  setShowParticipantDropdown(true)
                }}
                onFocus={() => setShowParticipantDropdown(true)}
                onBlur={() => setTimeout(() => setShowParticipantDropdown(false), 150)}
                placeholder={t('searchParticipant')}
                className="w-full rounded-lg border px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
              />
              {showParticipantDropdown && (
                <div className="absolute z-10 mt-1 max-h-60 w-full overflow-y-auto rounded-lg border bg-white shadow-lg">
                  {(() => {
                    const q = participantSearch.trim().toLowerCase()
                    const matches = participants
                      .filter(p => `${p.first_name} ${p.last_name}`.toLowerCase().includes(q))
                      .slice(0, 50)
                    if (matches.length === 0) {
                      return (
                        <div className="px-3 py-2 text-sm text-[var(--color-text-secondary)]">
                          {t('noParticipantFound')}
                        </div>
                      )
                    }
                    return matches.map(p => (
                      <button
                        key={p.id}
                        type="button"
                        onMouseDown={() => {
                          setFlightParticipantId(p.id)
                          setParticipantSearch(`${p.first_name} ${p.last_name}`)
                          setShowParticipantDropdown(false)
                        }}
                        className="block w-full px-3 py-2 text-left text-sm hover:bg-slate-50"
                      >
                        {p.first_name} {p.last_name}
                      </button>
                    ))
                  })()}
                </div>
              )}
            </div>

            {([
              ['flight_number', tf('flight_number'), t('exFlightNumber'), true],
              ['airline', tf('airline'), t('exAirline'), false],
              ['pnr_code', tf('pnr_code'), t('exPnr'), false],
              ['departure_airport', tf('departure_airport'), t('exDepartureAirport'), true],
              ['arrival_airport', tf('arrival_airport'), t('exArrivalAirport'), true],
            ] as const).map(([key, label, placeholder, required]) => (
              <div key={key}>
                <label className="mb-1 block text-sm font-semibold text-[var(--color-text-secondary)]">
                  {label}
                </label>
                <input
                  type="text"
                  value={newFlight[key]}
                  onChange={(e) => setNewFlight(v => ({ ...v, [key]: e.target.value }))}
                  placeholder={placeholder}
                  required={required}
                  className="w-full rounded-lg border px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                />
              </div>
            ))}
            <div className="hidden md:block" />

            {([
              ['departure_date', 'departure_hour', t('departure')],
              ['arrival_date', 'arrival_hour', t('arrival')],
            ] as const).map(([dateKey, hourKey, label]) => (
              <div key={dateKey} className="md:col-span-1">
                <label className="mb-1 block text-sm font-semibold text-[var(--color-text-secondary)]">
                  {label}
                </label>
                <div className="flex gap-2">
                  <input
                    type="date"
                    value={newFlight[dateKey]}
                    onChange={(e) => setNewFlight(v => ({ ...v, [dateKey]: e.target.value }))}
                    required
                    className="w-full rounded-lg border px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                  />
                  <input
                    type="time"
                    value={newFlight[hourKey]}
                    onChange={(e) => setNewFlight(v => ({ ...v, [hourKey]: e.target.value }))}
                    className="w-32 rounded-lg border px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                  />
                </div>
              </div>
            ))}

            <div className="md:col-span-3">
              <button
                type="submit"
                disabled={addingFlight}
                className="w-full rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-[var(--color-accent)]/90 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {addingFlight ? '…' : t('saveFlight')}
              </button>
            </div>
          </form>
        </div>

        {actionSuccess && (
          <div className="flex items-center gap-2 rounded-lg border border-[var(--color-success)]/30 bg-[var(--color-success-light)] px-4 py-2.5 text-sm text-[var(--color-success)]">
            <CheckCircle2 className="h-4 w-4 shrink-0" />
            <span>{actionSuccess}</span>
            <button onClick={() => setActionSuccess(null)} className="ml-auto text-xs underline opacity-70 hover:opacity-100">{tAct('close')}</button>
          </div>
        )}

        {actionError && (
          <div className="flex items-center gap-2 rounded-lg border border-[var(--color-danger)]/30 bg-[var(--color-danger-light)] px-4 py-2.5 text-sm text-[var(--color-danger)]">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span>{actionError}</span>
          </div>
        )}

        {/* Search */}
        <div id="detail-list" className="flex items-center gap-2 max-w-md bg-white border rounded-lg px-3 py-2 shadow-sm scroll-mt-24">
          <Search className="h-4 w-4 text-[var(--color-text-secondary)]" />
          <input
            type="text"
            placeholder={t('searchPlaceholder')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-sm outline-none bg-transparent"
          />
        </div>

        {/* Flights list */}
        <div className="rounded-[var(--radius-card)] border bg-white shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="border-b bg-[var(--color-bg-subtle)] text-[var(--color-text-secondary)] font-medium">
                  <th className="p-4">{t('tablePassenger')}</th>
                  <th className="p-4">{t('tableFlights')}</th>
                  <th className="p-4">{t('tablePnr')}</th>
                  <th className="p-4">{t('tableStatus')}</th>
                </tr>
              </thead>
              <tbody className="divide-y text-[var(--color-text-primary)]">
                {loading ? (
                  <TableSkeleton cols={4} rows={4} />
                ) : groupedPassengers.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="p-8 text-center text-[var(--color-text-secondary)]">
                      {t('noFlights')}
                    </td>
                  </tr>
                ) : (
                  groupedPassengers.map((pax) => {
                    const anyCancelled = pax.segments.some(s => s.status === 'cancelled')
                    const pnrs = Array.from(new Set(pax.segments.map(s => s.pnr_code).filter(Boolean)))
                    return (
                      <tr key={pax.key} className="hover:bg-slate-50 transition-colors align-top">
                        <td className="p-4 font-semibold whitespace-nowrap">
                          {pax.participant_name}
                          {pax.segments.length > 1 && (
                            <span className="ml-2 rounded-full bg-slate-100 px-1.5 py-0.5 text-[10px] font-medium text-slate-600">
                              {pax.segments.length} vols
                            </span>
                          )}
                        </td>
                        <td className="p-4">
                          <div className="flex flex-col gap-1.5">
                            {pax.segments.map((s, idx) => {
                              const label = segmentLabel(pax.segments.length, idx)
                              const tag = localeTag(locale)
                              return (
                                <div key={s.id} className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs">
                                  {/* Monochrome like the rest of the app: aller and retour
                                      stay told apart by weight, not by hue. */}
                                  {label && (
                                    <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${idx === 0 ? 'bg-[var(--color-text-primary)] text-white' : 'bg-slate-200 text-slate-700'}`}>
                                      {label}
                                    </span>
                                  )}
                                  <span className="font-mono bg-slate-100 rounded px-1.5 py-0.5 text-slate-800">{s.flight_number}</span>
                                  {s.airline && <span className="font-medium">{s.airline}</span>}
                                  <span className="font-medium">{s.departure_airport} → {s.arrival_airport}</span>
                                  <span className="text-[var(--color-text-secondary)]">
                                    {formatScheduleTime(s.departure_time, tag)}
                                    {s.arrival_time && ` → ${formatScheduleTime(s.arrival_time, tag)}`}
                                  </span>
                                  {s.baggage_info && (
                                    <span className="text-[var(--color-text-secondary)]">· Bagages : {s.baggage_info}</span>
                                  )}
                                  {s.status === 'cancelled' && (
                                    <span className="text-[10px] font-semibold text-rose-600">{t('cancelled')}</span>
                                  )}
                                </div>
                              )
                            })}
                          </div>
                        </td>
                        <td className="p-4 font-mono text-xs whitespace-nowrap">{pnrs.length > 0 ? pnrs.join(', ') : '-'}</td>
                        <td className="p-4">
                          <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold ${
                            !anyCancelled
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}>
                            {!anyCancelled ? t('statusConfirmed') : t('statusCancelled')}
                          </span>
                        </td>
                      </tr>
                    )
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
