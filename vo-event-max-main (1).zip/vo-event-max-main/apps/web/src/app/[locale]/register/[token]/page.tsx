'use client'

import { useState, useEffect, useMemo } from 'react'
import { useParams } from 'next/navigation'
import { Loader2, AlertCircle, CheckCircle2, Lock } from 'lucide-react'
import { api } from '@/lib/api'
import type {
  EventSiteSection, RegistrationAttachmentRequest, UploadedAttachment,
  RegistrationConfirmation, RegistrationCustomField, RegistrationFieldState,
} from '@/lib/api'
import { cn } from '@/lib/utils'
import { EventMaxLogo } from '@/components/ui/EventMaxLogo'
import { COUNTRIES, countryLabel, suggestCountries, toEnglishCountry } from '@/lib/countries'
import { registrationCopy } from '@/lib/registrationCopy'
import { RegistrationHeader } from '@/components/ui/RegistrationHeader'
import {
  DEFAULT_THEME, resolveTheme, themeVariables, pageBackground, type RegistrationTheme,
} from '@/lib/registrationTheme'
import { LayoutCanvas, resolveLayoutPages, GUTTER, type LayoutBlock } from '@/lib/registrationLayout'

type LoadState =
  | { status: 'loading' }
  | { status: 'invalid' }
  | { status: 'closed'; eventName: string }
  | { status: 'ready'; eventName: string }
  | { status: 'submitted' }

const fieldClass = cn(
  'w-full rounded-xl border border-[var(--color-border)] px-4 py-3 text-[15px]',
  'text-[var(--color-text-primary)] placeholder:text-[var(--color-text-secondary)]',
  'outline-none transition-all bg-[var(--color-input)]',
  'focus:border-[var(--color-accent)] focus:ring-4 focus:ring-[var(--color-accent-light)]',
  'disabled:opacity-60'
)

function Field({
  id, label, required, children,
}: { id: string; label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div className="mb-5">
      <label
        htmlFor={id}
        className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-[var(--color-text-secondary)]"
      >
        {label} {required && <span className="text-[var(--color-danger)]">*</span>}
      </label>
      {children}
    </div>
  )
}

const LANG_LABELS: Record<string, string> = { fr: 'Français', nl: 'Nederlands', en: 'English' }

/**
 * The language picker sits at the very top, above the event name, the way the
 * reference form MAX already runs opens on "Kies uw taal / Choisissez votre
 * langue". The first thing you ask somebody should not itself be a barrier.
 *
 * Changing it refetches from the server rather than swapping strings in the
 * browser: the field labels, the organizer's own questions and the
 * required-field errors are all produced server-side, so a client-side switch
 * would give a page that is Dutch above the fold and French in its errors.
 */
function Shell({
  children, lang, locales, onLang, logoUrl, nav, theme, header, blockMode,
}: {
  children: React.ReactNode
  /** When the organizer arranged the form in blocks, the blocks carry the
   *  branding, so the standalone logo band is dropped — an image or title
   *  block stands in its place, wherever they put it. */
  blockMode?: boolean
  lang?: string
  locales?: string[]
  onLang?: (next: string) => void
  /** Point 11 — this event's own logo. Falls back to the default MAX mark
   *  when unset, exactly as the form always looked before. */
  logoUrl?: string | null
  /** Point 10 — the mini-site's own navigation (Programme, Infos pratiques…),
   *  one tab per configured section, sitting right below the language
   *  picker the same way it does on the reference form this was modelled
   *  on. Omitted entirely when there is nothing to navigate to. */
  nav?: React.ReactNode
  /** Migration 030 — the event's own appearance. Applied by redefining the
   *  variables this page was already written in, on the outermost element, so
   *  the whole subtree re-themes without a single className changing. Scoped
   *  here rather than on :root: an organizer's colour must not be able to
   *  repaint anything else in the app. */
  theme?: RegistrationTheme
  /** The band above the form (title, photo, or the title over the photo).
   *  Rendered by the caller because only it knows the event's name. */
  header?: React.ReactNode
}) {
  const t = theme ?? DEFAULT_THEME
  const photo = Boolean(t.background_image)
  // The page fills the screen. A background photo covers the whole of it,
  // behind the scrim that makes the theme's ink readable on it; otherwise the
  // surface's own gradient. Both decided in registrationTheme, so the editor's
  // preview cannot show one thing and the participant's page another.
  return (
    <div
      className="flex min-h-screen w-full flex-col"
      style={{ ...themeVariables(t), background: photo ? undefined : pageBackground(t) }}
    >
      {/* The photo is pinned to the SCREEN, not stretched over the document.
          As a background on this element it was sized to cover the whole page —
          a filled-in form runs past 6000px — so a 2400px photo was blown up to
          nine thousand wide and the visitor saw one magnified square of it. A
          fixed layer is sized to the viewport instead, and is also the one form
          iOS honours: it mishandles `background-attachment: fixed`, never a
          fixed element. */}
      {photo ? (
        <div aria-hidden className="pointer-events-none fixed inset-0" style={{ background: pageBackground(t) }} />
      ) : null}
      {/* Edge to edge: the content fills the whole screen, no max-width, no
          card. Over a background photo the column is transparent so the photo
          shows through the whole page; otherwise it wears the surface colour as
          a clean full-screen page. `relative` puts it above the fixed layer. */}
      <div
        className="relative flex min-h-screen w-full flex-col"
        style={{ background: photo ? 'transparent' : 'var(--color-surface)' }}
      >
        {onLang && (locales?.length ?? 0) > 1 && (
          <div className="flex justify-center gap-1 border-b border-[var(--color-border)] px-6 py-2.5">
            {locales!.map((code) => (
              <button
                key={code}
                type="button"
                onClick={() => onLang(code)}
                aria-pressed={lang === code}
                className={cn(
                  'rounded-full px-3 py-1 text-xs font-medium transition-colors',
                  lang === code
                    ? 'bg-[var(--color-accent)] text-[var(--color-on-accent)]'
                    : 'text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]'
                )}
              >
                {LANG_LABELS[code] ?? code.toUpperCase()}
              </button>
            ))}
          </div>
        )}
        {nav}
        {header}
        {!blockMode && (
          <div className="px-6 pb-4 pt-8 text-center sm:px-8">
            <div className="mb-4 flex flex-col items-center justify-center select-none">
              {logoUrl ? (
                // A remote, per-event logo isn't a build-time-known asset next/image can optimise.
                // eslint-disable-next-line @next/next/no-img-element
                <img src={logoUrl} alt="" className="h-24 w-auto max-w-[320px] object-contain sm:h-28" />
              ) : (
                <EventMaxLogo className="h-20 w-auto max-w-[320px] text-[var(--color-text-primary)]" />
              )}
            </div>
          </div>
        )}
        {children}
      </div>
    </div>
  )
}

export default function PublicRegistrationPage() {
  const params = useParams()
  const token = params.token as string
  // /nl/register/<token> opens in Dutch. The organiser sends the link; making
  // its prefix mean something is free, and it is the only signal available
  // before the form has loaded — which is exactly when the "link no longer
  // valid" page has to pick a language.
  const urlLocale = typeof params.locale === 'string' ? params.locale : 'fr'
  // Point 13 (v1): which audience this link was sent to. Comes from the URL
  // the visitor actually opened, never from a choice on the form itself —
  // the way a real event sends the VIP list a different link than the
  // general one, on the same underlying token. Read from window on mount
  // (not useSearchParams) to avoid a static-prerender bail-out.
  const [badge, setBadge] = useState<string | null>(null)
  useEffect(() => {
    const raw = new URLSearchParams(window.location.search).get('badge')
    if (raw) setBadge(raw)
  }, [])

  const [theme, setTheme] = useState<RegistrationTheme>(DEFAULT_THEME)
  // A map of page -> blocks (migration 032): "home" is the registration page,
  // other keys are mini-site section slugs. A page absent from the map renders
  // the classic way, exactly as this page always did — so nothing changes for
  // an event, or a page, that opted out.
  const [layout, setLayout] = useState<Record<string, LayoutBlock[]>>({})
  const [state, setState] = useState<LoadState>({ status: 'loading' })
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [form, setForm] = useState({
    first_name: '', last_name: '', email: '', company: '', nationality: '',
    date_of_birth: '', passport_number: '', passport_expiry: '',
    job_title: '', badge_name: '', language: '',
    dietary_requirements: '', food_allergy_info: '', special_requests: '', room_preference: '',
    pmr_needs: '', remarks: '', emergency_contact_name: '', consent: false,
    website: '', // honeypot — left empty by real visitors, never shown
  })
  // Phone is split so a country code is always attached to the number
  // (ex. +32 for la Belgique, +213 pour l'Algérie) instead of a bare local
  // number that's meaningless once mixed with other countries' participants.
  // Same reasoning applies to the emergency contact's number.
  const [phoneCountryCode, setPhoneCountryCode] = useState('')
  const [phoneNumber, setPhoneNumber] = useState('')
  const [emergencyCountryCode, setEmergencyCountryCode] = useState('')
  const [emergencyNumber, setEmergencyNumber] = useState('')
  const [showNationalityDropdown, setShowNationalityDropdown] = useState(false)
  // Which questions this event asks, decided by the organizer on the
  // Formulaire d'inscription page. Absent (older API, or the config column not
  // migrated yet) means "ask everything", which is how the form always behaved.
  const [fieldCfg, setFieldCfg] = useState<Record<string, { enabled: boolean; required: boolean }>>({})
  const show = (key: string) => fieldCfg[key]?.enabled ?? true
  const req = (key: string) => fieldCfg[key]?.required ?? false
  const anyShown = (...keys: string[]) => keys.some(show)

  // The catalogue as the server resolved it, kept whole. The blocks below
  // render the fields that need bespoke UI — a phone with its dial code, the
  // nationality autocomplete — and everything else is rendered from this,
  // grouped by section. That is what lets a field added on the server appear
  // here without touching this file: the alternative was another twenty-five
  // hand-written blocks, and the next twenty-five after that.
  const [catalogue, setCatalogue] = useState<RegistrationFieldState[]>([])
  // The label the SERVER resolved for a field this file renders by hand.
  //
  // Twenty fields below are hand-written rather than generated, and each used
  // to carry its French label inline — so registration_i18n translated
  // "first_name" into "Voornaam" and the page printed "Prénom" anyway. In
  // French the inline wording still wins: two of them are deliberately shorter
  // than the catalogue's ("Nom du contact" under a "Contact d'urgence"
  // heading, not "Nom du contact d'urgence"). In every other language the
  // server's translation is the only one there is.
  const fieldLabel = (key: string, french: string) =>
    lang === 'fr' ? french : (catalogue.find((f) => f.key === key)?.label || french)
  const [customFields, setCustomFields] = useState<RegistrationCustomField[]>([])
  const [confirmations, setConfirmations] = useState<RegistrationConfirmation[]>([])
  const [customAnswers, setCustomAnswers] = useState<Record<string, string>>({})
  const [ticked, setTicked] = useState<Record<string, boolean>>({})
  const [generic, setGeneric] = useState<Record<string, string>>({})
  // The language the participant reads the form in. Sent to the API on
  // every call so the field labels AND the refusals come back in it —
  // a Dutch form answering in French is a form somebody gives up on.
  const [lang, setLang] = useState<string>(urlLocale)
  // This page's own words. Keyed on the picker's language, not on the URL —
  // see lib/registrationCopy for why next-intl cannot answer here.
  const t = useMemo(() => registrationCopy(lang), [lang])
  const [locales, setLocales] = useState<string[]>(['fr', 'nl', 'en'])
  // Point 11 — this event's own logo, or null for the default MAX mark.
  const [logoUrl, setLogoUrl] = useState<string | null>(null)
  // Point 10 — which mini-site tab is showing. 'home' is the form itself
  // (plus the welcome text, if any); any other value is a section slug and
  // replaces the form with that section's content alone, the way the
  // reference site's own Programme / Praktische informatie pages do.
  const [activeTab, setActiveTab] = useState<string>('home')
  // §11 — the mini event site above the form. Empty on an event that
  // configured none, which is also what a deployment without migration 018
  // looks like: the link shows the form alone, exactly as before.
  const [sections, setSections] = useState<EventSiteSection[]>([])
  // §9 — the documents this event asks for, and what has been uploaded so far.
  // Files go up BEFORE the form is submitted: the participant does not exist
  // yet, so each upload is stored unclaimed and bound on submission.
  const [wantedFiles, setWantedFiles] = useState<RegistrationAttachmentRequest[]>([])
  const [uploaded, setUploaded] = useState<Record<string, UploadedAttachment>>({})
  const [uploading, setUploading] = useState<string>('')
  const [uploadError, setUploadError] = useState<Record<string, string>>({})
  // §9 — a second person in the same submission.
  const [withCompanion, setWithCompanion] = useState(false)
  const [companion, setCompanion] = useState({
    first_name: '', last_name: '', email: '', phone: '',
    date_of_birth: '', nationality: '', dietary_requirements: '',
    shirt_size: '', remarks: '', shares_room: true,
  })

  useEffect(() => {
    let cancelled = false
    async function load() {
      try {
        const info = await api.publicRegistration.getInfo(token, lang, badge)
        if (cancelled) return
        setFieldCfg(Object.fromEntries(
          (info.fields || []).map((f) => [f.key, { enabled: f.enabled, required: f.required }])
        ))
        setCatalogue(info.fields || [])
        if (info.supported_locales?.length) setLocales(info.supported_locales)
        setLogoUrl(info.logo_url || null)
        // Resolved rather than trusted: a tab held open across a deploy
        // that adds a key would otherwise render a theme with a hole in it.
        setTheme(resolveTheme(info.theme))
        setLayout(resolveLayoutPages(info.layout))
        // The public form is English-only: render whatever language the API
        // says it served (always "en"), so blocks and labels agree.
        if (info.locale) setLang(info.locale)
        setCustomFields(info.custom_fields || [])
        setConfirmations(info.confirmations || [])
        setSections(info.sections || [])
        setWantedFiles(info.attachments || [])
        setState(info.is_open ? { status: 'ready', eventName: info.event_name } : { status: 'closed', eventName: info.event_name })
      } catch {
        if (!cancelled) setState({ status: 'invalid' })
      }
    }
    if (token) load()
    return () => { cancelled = true }
  }, [token, lang, badge])

  const setField = (field: keyof typeof form) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const value = e.target.type === 'checkbox' ? (e.target as HTMLInputElement).checked : e.target.value
    setForm((f) => ({ ...f, [field]: value }))
  }

  // Keys this file renders itself, either because the value needs assembling
  // (a phone and its dial code) or because the input is more than a text box.
  // Everything else in the catalogue is rendered generically below.
  const HANDCRAFTED = new Set([
    'first_name', 'last_name', 'email', 'company', 'phone', 'nationality',
    'date_of_birth', 'passport_number', 'passport_expiry', 'job_title',
    'badge_name', 'language', 'dietary_requirements', 'food_allergy_info',
    'room_preference', 'pmr_needs', 'emergency_contact_name',
    'emergency_contact_phone', 'special_requests', 'remarks',
  ])
  // Room type is a CHOICE, not free text. Typing "twin", "TWIN", "2 pers" or
  // "chambre double" into a box is what made the pairing guess at all; three
  // options is what lets it be exact. Mirrors services/rooming_service.
  const ROOM_TYPES = [
    { value: 'single', label: t('roomSingle') },
    { value: 'twin', label: t('roomTwin') },
    { value: 'double', label: t('roomDouble') },
  ]
  const sharesRoom = ['twin', 'double'].includes((generic.room_type || '').toLowerCase())

  const genericFields = catalogue
    .filter((f) => !HANDCRAFTED.has(f.key) && f.enabled)
    // The roommate question only makes sense once a shared room is chosen —
    // asking everyone who they share with, including the single rooms, is how
    // you collect names nobody meant to give.
    .filter((f) => f.key !== 'roommate' || sharesRoom)
  const genericGroups = Array.from(new Set(genericFields.map((f) => f.group)))

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    if (!form.consent) {
      setError(t('errConsent'))
      return
    }
    const unticked = confirmations.filter((c) => !ticked[c.key])
    if (unticked.length > 0) {
      setError(t('errConfirm', { fields: unticked.map((c) => c.label).join(', ') }))
      return
    }
    if (req('phone') && !phoneNumber.trim()) {
      setError(t('errPhone'))
      return
    }
    if (req('emergency_contact_phone') && !emergencyNumber.trim()) {
      setError(t('errEmergencyPhone'))
      return
    }
    if (phoneNumber.trim() && !phoneCountryCode) {
      setError(t('errDialCode'))
      return
    }
    if (emergencyNumber.trim() && !emergencyCountryCode) {
      setError(t('errEmergencyDialCode'))
      return
    }
    setSubmitting(true)
    try {
      const phone = phoneCountryCode && phoneNumber.trim() ? `${phoneCountryCode} ${phoneNumber.trim()}` : ''
      const emergency_contact_phone = emergencyCountryCode && emergencyNumber.trim() ? `${emergencyCountryCode} ${emergencyNumber.trim()}` : ''
      const answers: Record<string, unknown> = Object.fromEntries(
        Object.entries({ ...form, phone, emergency_contact_phone }).map(([k, v]) =>
          // consent and the honeypot are not catalogue fields — never filtered.
          k === 'consent' || k === 'website' || show(k) ? [k, v] : [k, '']
        )
      )
      // Generic catalogue answers, then the organizer's own questions and
      // tick-boxes. `custom` and `confirmations` stay in their own namespaces
      // so an organizer's key can never collide with a catalogue field.
      for (const f of genericFields) {
        const value = generic[f.key]
        if (value) answers[f.key] = value
      }
      // The column speaks one language, the form speaks the participant's.
      // A nationality this table does not recognise is sent exactly as typed:
      // "Kosovar", a dual nationality or a plain typo is worth keeping, and
      // never worth silently dropping.
      if (typeof answers.nationality === 'string' && answers.nationality.trim()) {
        answers.nationality = toEnglishCountry(answers.nationality) ?? answers.nationality
      }
      answers.custom = customAnswers
      answers.confirmations = ticked
      answers.attachments = Object.values(uploaded).map((a) => ({ kind: a.kind, id: a.id }))
      // Sent only when actually filled in: an empty companion block would
      // create a nameless second fiche the organiser then has to delete.
      if (withCompanion && companion.first_name.trim() && companion.last_name.trim()) {
        answers.companion = companion
      }
      await api.publicRegistration.submit(token, answers, lang, badge)
      setState({ status: 'submitted' })
    } catch (err) {
      setError(err instanceof Error ? err.message : t('errGeneric'))
    } finally {
      setSubmitting(false)
    }
  }

  async function uploadFile(kind: string, file: File | null) {
    if (!file) return
    setUploading(kind)
    setUploadError((prev) => ({ ...prev, [kind]: '' }))
    try {
      const result = await api.publicRegistration.uploadAttachment(token, kind, file, lang)
      setUploaded((prev) => ({ ...prev, [kind]: result }))
    } catch (err) {
      // The server's own refusal, verbatim: it says which format or which size,
      // and a generic "upload failed" would send the visitor to support.
      setUploadError((prev) => ({
        ...prev,
        [kind]: err instanceof Error ? err.message : t('errUpload'),
      }))
    } finally {
      setUploading('')
    }
  }

  if (state.status === 'loading') {
    return (
      <Shell>
        <div className="flex flex-col items-center gap-3 px-8 pb-10">
          <Loader2 className="h-6 w-6 animate-spin text-[var(--color-accent)]" />
          <p className="text-sm text-[var(--color-text-secondary)]">{t('loading')}</p>
        </div>
      </Shell>
    )
  }

  if (state.status === 'invalid') {
    return (
      <Shell>
        <div className="flex flex-col items-center gap-3 px-8 pb-10 text-center">
          <AlertCircle className="h-8 w-8 text-[var(--color-danger)]" />
          <h1 className="text-lg font-bold text-[var(--color-text-primary)]">{t('invalidTitle')}</h1>
          <p className="text-sm text-[var(--color-text-secondary)]">{t('invalidBody')}</p>
        </div>
      </Shell>
    )
  }

  if (state.status === 'closed') {
    return (
      <Shell lang={lang} locales={locales} onLang={setLang} logoUrl={logoUrl}>
        <div className="flex flex-col items-center gap-3 px-8 pb-10 text-center">
          <Lock className="h-8 w-8 text-[var(--color-text-secondary)]" />
          <h1 className="text-lg font-bold text-[var(--color-text-primary)]">{t('closedTitle')}</h1>
          <p className="text-sm text-[var(--color-text-secondary)]">
            {/* The event name stays bold, as it was: a template string cannot
                carry markup, so the sentence is split on its placeholder. */}
            {t('closedBody').split('{event}').flatMap((part, i) =>
              i === 0 ? [part] : [<strong key={i}>{state.eventName}</strong>, part]
            )}
          </p>
        </div>
      </Shell>
    )
  }

  if (state.status === 'submitted') {
    return (
      <Shell>
        <div className="flex flex-col items-center gap-3 px-8 pb-10 text-center">
          <CheckCircle2 className="h-8 w-8 text-[var(--color-success)]" />
          <h1 className="text-lg font-bold text-[var(--color-text-primary)]">{t('submittedTitle')}</h1>
          <p className="text-sm text-[var(--color-text-secondary)]">{t('submittedBody')}</p>
        </div>
      </Shell>
    )
  }

  // Point 10 — one nav tab per configured section, "welcome" excepted: that
  // one is short intro text meant to sit above the form itself (Home), not a
  // page of its own, matching how the reference site's own "Home" tab is
  // where the form lives and every OTHER tab is a page to read and leave.
  const welcomeSection = sections.find((s) => s.slug === 'welcome') ?? null
  const tabSections = sections.filter((s) => s.slug !== 'welcome')
  const activeSection = tabSections.find((s) => s.slug === activeTab) ?? null

  const siteNav = tabSections.length > 0 ? (
    <div className="flex flex-wrap justify-center gap-1 border-b border-[var(--color-border)] bg-[var(--color-bg-subtle)] px-4 py-2">
      <button
        type="button"
        onClick={() => setActiveTab('home')}
        aria-pressed={activeTab === 'home'}
        className={cn(
          'rounded-full px-3 py-1 text-xs font-medium transition-colors',
          activeTab === 'home'
            ? 'bg-[var(--color-accent)] text-[var(--color-on-accent)]'
            : 'text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]'
        )}
      >
        {t('navRegistration')}
      </button>
      {tabSections.map((section) => (
        <button
          key={section.slug}
          type="button"
          onClick={() => setActiveTab(section.slug)}
          aria-pressed={activeTab === section.slug}
          className={cn(
            'rounded-full px-3 py-1 text-xs font-medium transition-colors',
            activeTab === section.slug
              ? 'bg-[var(--color-accent)] text-[var(--color-on-accent)]'
              : 'text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]'
          )}
        >
          {section.title}
        </button>
      ))}
    </div>
  ) : null

  const formBody = (
      <form
        onSubmit={handleSubmit}
        className="pb-16 pt-10"
        style={{ paddingInline: GUTTER }}
      >
        <p className="mb-10 text-center text-[15px] leading-relaxed text-[var(--color-text-secondary)]">{t('intro')}</p>

        <EventSite sections={welcomeSection ? [welcomeSection] : []} />

        {error && (
          <div className="mb-4 flex items-start gap-2 rounded-lg bg-[var(--color-danger-light)] p-3">
            <AlertCircle className="mt-0.5 h-4 w-4 flex-shrink-0 text-[var(--color-danger)]" />
            <p className="text-sm text-[var(--color-danger)]">{error}</p>
          </div>
        )}

        {/* Honeypot — hidden from real visitors, bots fill every field they find */}
        <div className="hidden" aria-hidden="true">
          <label htmlFor="website">{t('honeypot')}</label>
          <input id="website" name="website" type="text" tabIndex={-1} autoComplete="off" value={form.website} onChange={setField('website')} />
        </div>

        <div className="grid grid-cols-1 gap-x-4 sm:grid-cols-2">
          <Field id="first_name" label={fieldLabel('first_name', 'Prénom')} required>
            <input id="first_name" type="text" required value={form.first_name} onChange={setField('first_name')} className={fieldClass} disabled={submitting} />
          </Field>
          <Field id="last_name" label={fieldLabel('last_name', 'Nom')} required>
            <input id="last_name" type="text" required value={form.last_name} onChange={setField('last_name')} className={fieldClass} disabled={submitting} />
          </Field>
        </div>

        <Field id="email" label={fieldLabel('email', 'Adresse email')} required>
          <input id="email" type="email" required value={form.email} onChange={setField('email')} className={fieldClass} disabled={submitting} />
        </Field>

        {show('company') && (
          <Field id="company" label={fieldLabel('company', 'Société')} required={req('company')}>
            <input id="company" type="text" required={req('company')} value={form.company} onChange={setField('company')} className={fieldClass} disabled={submitting} />
          </Field>
        )}

        {show('phone') && (
        <Field id="phone_number" label={fieldLabel('phone', 'Téléphone')} required={req('phone')}>
          <div className="flex gap-2">
            <select
              id="phone_country_code"
              value={phoneCountryCode}
              onChange={(e) => setPhoneCountryCode(e.target.value)}
              disabled={submitting}
              className={cn(fieldClass, 'w-[130px] flex-shrink-0')}
            >
              <option value="">{t('dialCode')}</option>
              {COUNTRIES.map((c) => (
                <option key={c.iso2} value={c.dialCode}>{c.dialCode} — {countryLabel(c, lang)}</option>
              ))}
            </select>
            <input
              id="phone_number"
              type="tel"
              placeholder="4xx xx xx xx"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              className={fieldClass}
              disabled={submitting}
            />
          </div>
          <p className="mt-1 text-xs text-[var(--color-text-secondary)]">{t('dialCodeHint')}</p>
        </Field>
        )}

        {show('nationality') && (
        <div className="relative">
          <Field id="nationality" label={fieldLabel('nationality', 'Nationalité')} required={req('nationality')}>
            <input
              id="nationality"
              type="text"
              autoComplete="off"
              value={form.nationality}
              onChange={(e) => {
                setForm((f) => ({ ...f, nationality: e.target.value }))
                setShowNationalityDropdown(true)
              }}
              onFocus={() => setShowNationalityDropdown(true)}
              onBlur={() => setTimeout(() => setShowNationalityDropdown(false), 150)}
              className={fieldClass}
              required={req('nationality')}
              disabled={submitting}
            />
          </Field>
          {showNationalityDropdown && (
            <div className="absolute z-10 -mt-3 max-h-56 w-full overflow-y-auto rounded-lg border border-[var(--color-border)] bg-white shadow-lg">
              {suggestCountries(form.nationality, lang).map((c) => (
                <button
                  key={c.iso2}
                  type="button"
                  onMouseDown={() => {
                    // The box keeps the language they are reading in; the
                    // translation to English happens once, on submit.
                    setForm((f) => ({ ...f, nationality: countryLabel(c, lang) }))
                    setShowNationalityDropdown(false)
                  }}
                  className="block w-full px-3 py-2 text-left text-sm hover:bg-slate-50"
                >
                  {countryLabel(c, lang)}
                </button>
              ))}
            </div>
          )}
        </div>
        )}

        <div className="grid grid-cols-1 gap-x-4 sm:grid-cols-2">
          {show('date_of_birth') && (
          <Field id="date_of_birth" label={fieldLabel('date_of_birth', 'Date de naissance')} required={req('date_of_birth')}>
            <input id="date_of_birth" type="date" required={req('date_of_birth')} value={form.date_of_birth} onChange={setField('date_of_birth')} className={fieldClass} disabled={submitting} />
          </Field>
          )}
          {show('job_title') && (
          <Field id="job_title" label={fieldLabel('job_title', 'Fonction / Poste')} required={req('job_title')}>
            <input id="job_title" type="text" required={req('job_title')} value={form.job_title} onChange={setField('job_title')} className={fieldClass} disabled={submitting} />
          </Field>
          )}
        </div>

        <div className="grid grid-cols-1 gap-x-4 sm:grid-cols-2">
          {show('badge_name') && (
          <Field id="badge_name" label={fieldLabel('badge_name', 'Nom sur badge')} required={req('badge_name')}>
            <input id="badge_name" type="text" placeholder={t('phBadgeName')} required={req('badge_name')} value={form.badge_name} onChange={setField('badge_name')} className={fieldClass} disabled={submitting} />
          </Field>
          )}
          {show('language') && (
          <Field id="language" label={fieldLabel('language', 'Langue préférée')} required={req('language')}>
            <select id="language" required={req('language')} value={form.language} onChange={setField('language')} className={cn(fieldClass, 'bg-white')} disabled={submitting}>
              <option value="">{t('selectPlaceholder')}</option>
              <option value="Français">Français</option>
              <option value="English">English</option>
              <option value="Nederlands">Nederlands</option>
            </select>
          </Field>
          )}
        </div>

        <div className="grid grid-cols-1 gap-x-4 sm:grid-cols-2">
          {show('passport_number') && (
          <Field id="passport_number" label={fieldLabel('passport_number', 'Numéro de passeport')} required={req('passport_number')}>
            <input id="passport_number" type="text" required={req('passport_number')} value={form.passport_number} onChange={setField('passport_number')} className={fieldClass} disabled={submitting} />
          </Field>
          )}
          {show('passport_expiry') && (
          <Field id="passport_expiry" label={fieldLabel('passport_expiry', 'Expiration du passeport')} required={req('passport_expiry')}>
            <input id="passport_expiry" type="date" required={req('passport_expiry')} value={form.passport_expiry} onChange={setField('passport_expiry')} className={fieldClass} disabled={submitting} />
          </Field>
          )}
        </div>

        {anyShown('dietary_requirements', 'food_allergy_info', 'room_preference', 'pmr_needs') && (
          <div className="my-5 border-t border-[var(--color-border)] pt-5">
            <h2 className="mb-3 text-sm font-semibold text-[var(--color-text-primary)]">{t('extraInfo')}</h2>
          </div>
        )}

        {show('dietary_requirements') && (
          <Field id="dietary_requirements" label={fieldLabel('dietary_requirements', 'Régime alimentaire')} required={req('dietary_requirements')}>
            <input id="dietary_requirements" type="text" placeholder={t('phDiet')} required={req('dietary_requirements')} value={form.dietary_requirements} onChange={setField('dietary_requirements')} className={fieldClass} disabled={submitting} />
          </Field>
        )}

        {show('food_allergy_info') && (
          <Field id="food_allergy_info" label={fieldLabel('food_allergy_info', 'Allergies')} required={req('food_allergy_info')}>
            <input id="food_allergy_info" type="text" placeholder={t('phAllergy')} required={req('food_allergy_info')} value={form.food_allergy_info} onChange={setField('food_allergy_info')} className={fieldClass} disabled={submitting} />
          </Field>
        )}

        {show('room_preference') && (
          <Field id="room_preference" label={fieldLabel('room_preference', 'Préférences de chambre')} required={req('room_preference')}>
            <input id="room_preference" type="text" placeholder={t('phRoomPreference')} required={req('room_preference')} value={form.room_preference} onChange={setField('room_preference')} className={fieldClass} disabled={submitting} />
          </Field>
        )}

        {show('pmr_needs') && (
          <Field id="pmr_needs" label={fieldLabel('pmr_needs', "Besoins d'accessibilité (PMR)")} required={req('pmr_needs')}>
            <input id="pmr_needs" type="text" placeholder={t('phPmr')} required={req('pmr_needs')} value={form.pmr_needs} onChange={setField('pmr_needs')} className={fieldClass} disabled={submitting} />
          </Field>
        )}

        {anyShown('emergency_contact_name', 'emergency_contact_phone') && (
          <div className="my-5 border-t border-[var(--color-border)] pt-5">
            <h2 className="mb-3 text-sm font-semibold text-[var(--color-text-primary)]">{t('emergencyHeading')}</h2>
          </div>
        )}

        {show('emergency_contact_name') && (
          <Field id="emergency_contact_name" label={fieldLabel('emergency_contact_name', 'Nom du contact')} required={req('emergency_contact_name')}>
            <input id="emergency_contact_name" type="text" required={req('emergency_contact_name')} value={form.emergency_contact_name} onChange={setField('emergency_contact_name')} className={fieldClass} disabled={submitting} />
          </Field>
        )}

        {show('emergency_contact_phone') && (
        <Field id="emergency_contact_phone" label={fieldLabel('emergency_contact_phone', 'Téléphone du contact')} required={req('emergency_contact_phone')}>
          <div className="flex gap-2">
            <select
              id="emergency_country_code"
              value={emergencyCountryCode}
              onChange={(e) => setEmergencyCountryCode(e.target.value)}
              disabled={submitting}
              className={cn(fieldClass, 'w-[130px] flex-shrink-0')}
            >
              <option value="">{t('dialCode')}</option>
              {COUNTRIES.map((c) => (
                <option key={c.iso2} value={c.dialCode}>{c.dialCode} — {countryLabel(c, lang)}</option>
              ))}
            </select>
            <input
              id="emergency_contact_phone"
              type="tel"
              placeholder="4xx xx xx xx"
              value={emergencyNumber}
              onChange={(e) => setEmergencyNumber(e.target.value)}
              className={fieldClass}
              disabled={submitting}
            />
          </div>
        </Field>
        )}

        {show('special_requests') && (
          <Field id="special_requests" label={fieldLabel('special_requests', 'Demandes spéciales')} required={req('special_requests')}>
            <textarea id="special_requests" rows={2} required={req('special_requests')} value={form.special_requests} onChange={setField('special_requests')} className={fieldClass} disabled={submitting} />
          </Field>
        )}

        {show('remarks') && (
          <Field id="remarks" label={fieldLabel('remarks', 'Remarques')} required={req('remarks')}>
            <textarea id="remarks" rows={2} required={req('remarks')} value={form.remarks} onChange={setField('remarks')} className={fieldClass} disabled={submitting} />
          </Field>
        )}

        {/* Everything the catalogue holds that this file does not render by
            hand — grouped by section, so a field added on the server lands in
            the right place without any change here. */}
        {genericGroups.map((group) => (
          <div key={group}>
            <p className="mb-3 mt-6 text-xs font-semibold uppercase tracking-wide text-[var(--color-text-secondary)]">
              {group}
            </p>
            {genericFields.filter((f) => f.group === group).map((f) => (
              <Field key={f.key} id={f.key} label={f.label} required={f.required}>
                {f.key === 'room_type' ? (
                  <select
                    id={f.key}
                    required={f.required}
                    value={generic[f.key] || ''}
                    onChange={(e) => setGeneric((g) => ({
                      ...g,
                      room_type: e.target.value,
                      // Switching to a single room drops a roommate that was
                      // already typed: leaving it would send a name with a
                      // room type that contradicts it.
                      ...(['twin', 'double'].includes(e.target.value) ? {} : { roommate: '' }),
                    }))}
                    className={fieldClass}
                    disabled={submitting}
                  >
                    <option value="">{t('choosePlaceholder')}</option>
                    {ROOM_TYPES.map((r) => (
                      <option key={r.value} value={r.value}>{r.label}</option>
                    ))}
                  </select>
                ) : (
                  <input
                    id={f.key}
                    type={f.key.includes('date') || f.key.endsWith('_start') || f.key.endsWith('_end') ? 'date' : 'text'}
                    required={f.required}
                    value={generic[f.key] || ''}
                    onChange={(e) => setGeneric((g) => ({ ...g, [f.key]: e.target.value }))}
                    className={fieldClass}
                    disabled={submitting}
                    placeholder={f.key === 'roommate' ? t('phRoommate') : undefined}
                  />
                )}
              </Field>
            ))}
          </div>
        ))}

        {/* The organizer's own questions. The reference form asks for a
            favourite sweet and a favourite song; no catalogue could. */}
        {customFields.length > 0 && (
          <div>
            <p className="mb-3 mt-6 text-xs font-semibold uppercase tracking-wide text-[var(--color-text-secondary)]">
              {t('extraInfo')}
            </p>
            {customFields.map((f) => (
              <Field key={f.key} id={`custom_${f.key}`} label={f.label} required={f.required}>
                {f.type === 'textarea' ? (
                  <textarea
                    id={`custom_${f.key}`} rows={2} required={f.required}
                    value={customAnswers[f.key] || ''}
                    onChange={(e) => setCustomAnswers((c) => ({ ...c, [f.key]: e.target.value }))}
                    className={fieldClass} disabled={submitting}
                  />
                ) : f.type === 'select' ? (
                  <select
                    id={`custom_${f.key}`} required={f.required}
                    value={customAnswers[f.key] || ''}
                    onChange={(e) => setCustomAnswers((c) => ({ ...c, [f.key]: e.target.value }))}
                    className={cn(fieldClass, 'bg-white')} disabled={submitting}
                  >
                    <option value="">{t('selectPlaceholder')}</option>
                    {f.options.map((o) => <option key={o} value={o}>{o}</option>)}
                  </select>
                ) : f.type === 'boolean' ? (
                  <label className="flex items-center gap-2 text-sm text-[var(--color-text-primary)]">
                    <input
                      id={`custom_${f.key}`} type="checkbox"
                      checked={customAnswers[f.key] === 'oui'}
                      onChange={(e) => setCustomAnswers((c) => ({ ...c, [f.key]: e.target.checked ? 'oui' : 'non' }))}
                      className="h-4 w-4 rounded border-[var(--color-border)]" disabled={submitting}
                    />
                    {t('yes')}
                  </label>
                ) : (
                  <input
                    id={`custom_${f.key}`} type={f.type === 'date' ? 'date' : 'text'} required={f.required}
                    value={customAnswers[f.key] || ''}
                    onChange={(e) => setCustomAnswers((c) => ({ ...c, [f.key]: e.target.value }))}
                    className={fieldClass} disabled={submitting}
                  />
                )}
              </Field>
            ))}
          </div>
        )}

        {/* Contractual tick-boxes, in the organizer's own wording. A
            cancellation policy with a deadline is not something to paraphrase,
            so the text is shown exactly as it was written. */}
        {confirmations.map((c) => (
          <label key={c.key} className="mb-4 flex items-start gap-2.5 text-xs text-[var(--color-text-secondary)]">
            <input
              type="checkbox"
              checked={ticked[c.key] || false}
              onChange={(e) => setTicked((t) => ({ ...t, [c.key]: e.target.checked }))}
              disabled={submitting}
              className="mt-0.5 h-4 w-4 flex-shrink-0 rounded border-[var(--color-border)]"
            />
            <span>{c.text} <span className="text-[var(--color-danger)]">*</span></span>
          </label>
        ))}

        {wantedFiles.length > 0 && (
          <fieldset className="mb-6 mt-2 rounded-lg border border-[var(--color-border)] p-3">
            <legend className="px-1 text-xs font-semibold text-[var(--color-text-primary)]">
              {t('documents')}
            </legend>
            {wantedFiles.map((wanted) => (
              <div key={wanted.kind} className="mb-3 last:mb-0">
                <label className="block text-xs text-[var(--color-text-secondary)]">
                  {wanted.label}
                  {wanted.required && <span className="text-[var(--color-danger)]"> *</span>}
                  <input
                    type="file"
                    accept={wanted.accept.join(',')}
                    required={wanted.required && !uploaded[wanted.kind]}
                    disabled={submitting || uploading === wanted.kind}
                    onChange={(e) => uploadFile(wanted.kind, e.target.files?.[0] ?? null)}
                    className="mt-1 block w-full text-xs file:mr-3 file:rounded-md file:border-0 file:bg-[var(--color-bg-subtle)] file:px-3 file:py-1.5 file:text-xs"
                  />
                </label>
                <p className="mt-1 text-[11px] text-[var(--color-text-secondary)]">
                  {t('fileLimit', { types: wanted.accept.join(', '), mb: Math.round(wanted.max_bytes / (1024 * 1024)) })}
                </p>
                {uploading === wanted.kind && (
                  <p className="mt-1 flex items-center gap-1.5 text-[11px] text-[var(--color-text-secondary)]">
                    <Loader2 className="h-3 w-3 animate-spin" /> {t('uploading')}
                  </p>
                )}
                {uploaded[wanted.kind] && (
                  <p className="mt-1 flex items-center gap-1.5 text-[11px] text-[var(--color-success)]">
                    <CheckCircle2 className="h-3 w-3" />
                    {uploaded[wanted.kind].filename}
                  </p>
                )}
                {uploadError[wanted.kind] && (
                  <p className="mt-1 text-[11px] text-[var(--color-danger)]">
                    {uploadError[wanted.kind]}
                  </p>
                )}
              </div>
            ))}
          </fieldset>
        )}

        <fieldset className="mb-6 rounded-lg border border-[var(--color-border)] p-3">
          <legend className="px-1 text-xs font-semibold text-[var(--color-text-primary)]">
            {t('companionHeading')}
          </legend>
          <label className="flex items-center gap-2 text-xs text-[var(--color-text-primary)]">
            <input
              type="checkbox"
              checked={withCompanion}
              onChange={(e) => setWithCompanion(e.target.checked)}
              disabled={submitting}
            />
            {t('companionAdd')}
          </label>

          {withCompanion && (
            <div className="mt-3">
              <p className="mb-2 text-[11px] text-[var(--color-text-secondary)]">{t('companionNote')}</p>
              <div className="grid grid-cols-1 gap-x-4 sm:grid-cols-2">
                <Field id="c_first_name" label={t('companionFirstName')} required>
                  <input
                    id="c_first_name" type="text" required value={companion.first_name}
                    onChange={(e) => setCompanion((c) => ({ ...c, first_name: e.target.value }))}
                    className={fieldClass} disabled={submitting}
                  />
                </Field>
                <Field id="c_last_name" label={t('companionLastName')} required>
                  <input
                    id="c_last_name" type="text" required value={companion.last_name}
                    onChange={(e) => setCompanion((c) => ({ ...c, last_name: e.target.value }))}
                    className={fieldClass} disabled={submitting}
                  />
                </Field>
              </div>
              <Field id="c_email" label={t('companionEmail')}>
                <input
                  id="c_email" type="email" value={companion.email}
                  onChange={(e) => setCompanion((c) => ({ ...c, email: e.target.value }))}
                  className={fieldClass} disabled={submitting}
                />
              </Field>
              <Field id="c_dietary" label={t('companionDiet')}>
                <input
                  id="c_dietary" type="text" value={companion.dietary_requirements}
                  onChange={(e) => setCompanion((c) => ({ ...c, dietary_requirements: e.target.value }))}
                  className={fieldClass} disabled={submitting}
                />
              </Field>
              <label className="mt-1 flex items-center gap-2 text-xs text-[var(--color-text-primary)]">
                <input
                  type="checkbox"
                  checked={companion.shares_room}
                  onChange={(e) => setCompanion((c) => ({ ...c, shares_room: e.target.checked }))}
                  disabled={submitting}
                />
                {t('companionSharesRoom')}
              </label>
            </div>
          )}
        </fieldset>

        <label className="mb-6 mt-2 flex items-start gap-2.5 text-xs text-[var(--color-text-secondary)]">
          <input
            type="checkbox"
            checked={form.consent}
            onChange={setField('consent')}
            disabled={submitting}
            className="mt-0.5 h-4 w-4 flex-shrink-0 rounded border-[var(--color-border)]"
          />
          <span>
            {t('consent')} <span className="text-[var(--color-danger)]">*</span>
          </span>
        </label>

        <button
          type="submit"
          disabled={submitting}
          className="flex w-full items-center justify-center gap-2 rounded-lg bg-[var(--color-accent)] px-4 py-3 text-sm font-semibold text-[var(--color-on-accent)] shadow-sm transition-colors hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
          {submitting ? t('submitting') : t('submit')}
        </button>
      </form>
  )

  // Each page picks its own rendering. The registration page ("home") gets its
  // blocks with the real form slotted in, or the classic form when it has none.
  // A mini-site sub-page gets its blocks (no form), or the classic title+body
  // when it has none. An absent page key means "classic" — the opt-in per page.
  const homeBlocks = layout.home ?? []
  const sectionBlocks = activeSection ? (layout[activeSection.slug] ?? []) : []
  const activeHasBlocks = activeSection ? sectionBlocks.length > 0 : homeBlocks.length > 0

  const body =
    activeTab !== 'home' && activeSection ? (
      sectionBlocks.length > 0 ? (
        <LayoutCanvas blocks={sectionBlocks} locale={lang} renderForm={() => null} />
      ) : (
        <EventSitePage section={activeSection} />
      )
    ) : homeBlocks.length > 0 ? (
      <LayoutCanvas blocks={homeBlocks} locale={lang} renderForm={() => formBody} />
    ) : (
      formBody
    )

  return (
    <Shell
      lang={lang}
      locales={locales}
      onLang={setLang}
      logoUrl={logoUrl}
      nav={siteNav}
      theme={theme}
      // When the active page is arranged in blocks, the blocks carry the header
      // and branding themselves, so the standalone header/logo band is dropped.
      header={activeHasBlocks ? undefined : <RegistrationHeader theme={theme} eventName={state.eventName} />}
      blockMode={activeHasBlocks}
    >
      {body}
    </Shell>
  )
}


/**
 * The mini event site above the form (§11).
 *
 * Rendered as TEXT, deliberately. The server strips tags before storing and
 * this renders through React's own escaping, so an organizer account cannot
 * become a stored-XSS vector against every participant of the event. The one
 * structure the text keeps is paragraphs, which the server already split.
 */
function EventSite({ sections }: { sections: EventSiteSection[] }) {
  if (sections.length === 0) return null
  return (
    <div className="mb-8 space-y-6">
      {sections.map((section) => {
        /* A ratio rather than a height cap. Across a full-width page the old
           256px cap made this a 6:1 sliver; 16/9 is a real photo on a phone and
           a wide band on a monitor, which is the same picture either way. */
        /* eslint-disable-next-line @next/next/no-img-element -- an organiser-supplied
           absolute URL, not a bundled asset: next/image would need every possible
           host allowlisted in next.config, and a blocked host renders nothing. */
        const photo = section.image_url ? (
          <img
            src={section.image_url}
            alt=""
            className={`w-full rounded-lg object-cover ${
              section.image_position === 'below' ? 'mt-3' : 'mb-3'
            }`}
            style={{ aspectRatio: '16 / 9', maxHeight: 420 }}
            loading="lazy"
          />
        ) : null
        return (
          <section key={section.slug}>
            <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-[var(--color-text-primary)]">
              {section.title}
            </h2>
            {section.image_position !== 'below' && photo}
            {section.paragraphs.map((paragraph, i) => (
              <p key={i} className="mb-2 text-sm leading-relaxed text-[var(--color-text-secondary)]">
                {paragraph}
              </p>
            ))}
            {section.image_position === 'below' && photo}
          </section>
        )
      })}
      <hr className="border-[var(--color-border)]" />
    </div>
  )
}

/** Point 10 — one mini-site section shown as its own page, the way the
 *  reference site's Programme / Praktische informatie tabs work: read this,
 *  then use the nav to come back to Inscription. Text-only styling reused
 *  from EventSite above; this just owns the page-level layout around it. */
function EventSitePage({ section }: { section: EventSiteSection }) {
  // eslint-disable-next-line @next/next/no-img-element
  const photo = section.image_url ? (
    <img
      src={section.image_url}
      alt=""
      className={`w-full rounded-lg object-cover ${
        section.image_position === 'below' ? 'mt-4' : 'mb-4'
      }`}
      style={{ aspectRatio: '16 / 9', maxHeight: 480 }}
      loading="lazy"
    />
  ) : null

  // The same gutter as the form: a sub-page is the same page, and text glued
  // to the glass on one tab and inset on the next reads as a broken link.
  return (
    <div className="pb-14 pt-4 text-left" style={{ paddingInline: GUTTER }}>
      <h1 className="mb-4 text-center text-lg font-bold text-[var(--color-text-primary)]">
        {section.title}
      </h1>
      {section.image_position !== 'below' && photo}
      {section.paragraphs.map((paragraph, i) => (
        <p key={i} className="mb-3 text-sm leading-relaxed text-[var(--color-text-secondary)]">
          {paragraph}
        </p>
      ))}
      {section.image_position === 'below' && photo}
    </div>
  )
}
