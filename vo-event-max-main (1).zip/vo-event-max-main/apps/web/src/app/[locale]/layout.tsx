import { NextIntlClientProvider } from 'next-intl'
import { getMessages, getTranslations } from 'next-intl/server'
import { notFound } from 'next/navigation'
import { routing } from '@/i18n/routing'
import type { Metadata } from 'next'
import { Inter, Nunito, Roboto_Slab, Source_Serif_4, Space_Grotesk } from 'next/font/google'

const inter = Inter({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700', '800'],
  display: 'swap',
})

// The typefaces a public registration form can be set in (migration 030).
//
// Declared here so next/font downloads them at build time and serves them from
// our own origin — a participant opening a form never talks to a font CDN,
// which keeps the one public page in the product free of a third-party request
// nobody agreed to.
//
// `preload: false` matters as much as the families do: preloading five
// typefaces on every screen of the app, to style one public page, would make
// every organizer pay for it. Without it the browser fetches only the family
// the page's --font-form variable actually resolves to.
// One const each, at module scope. The loader is a compile-time transform, not
// a function call: collecting these into an array literal fails the build with
// "Font loaders must be called and assigned to a const in the module scope".
const grotesk = Space_Grotesk({ subsets: ['latin'], weight: ['400', '500', '700'], display: 'swap', variable: '--font-grotesk', preload: false })
const serif = Source_Serif_4({ subsets: ['latin'], weight: ['400', '600', '700'], display: 'swap', variable: '--font-serif', preload: false })
const slab = Roboto_Slab({ subsets: ['latin'], weight: ['400', '500', '700'], display: 'swap', variable: '--font-slab', preload: false })
const rounded = Nunito({ subsets: ['latin'], weight: ['400', '600', '800'], display: 'swap', variable: '--font-rounded', preload: false })

const fontVariables = [grotesk, serif, slab, rounded].map((font) => font.variable).join(' ')

type Locale = 'fr' | 'nl' | 'en'

/** The tab title is the product's name in every language; the description a
 *  search result or a shared link shows is not, so it follows the locale. */
export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params
  const t = await getTranslations({ locale, namespace: 'meta' })
  return {
    title: {
      default: 'VO Event Max',
      template: '%s — VO Event Max',
    },
    description: t('description'),
  }
}

interface LocaleLayoutProps {
  children: React.ReactNode
  params: Promise<{ locale: string }>
}

export default async function LocaleLayout({ children, params }: LocaleLayoutProps) {
  const { locale } = await params

  // Validate locale
  if (!routing.locales.includes(locale as Locale)) {
    notFound()
  }

  const messages = await getMessages()

  return (
    <html lang={locale} className={`${inter.className} ${fontVariables}`}>
      <body>
        <NextIntlClientProvider messages={messages}>
          {children}
        </NextIntlClientProvider>
      </body>
    </html>
  )
}

export function generateStaticParams() {
  return routing.locales.map((locale) => ({ locale }))
}
