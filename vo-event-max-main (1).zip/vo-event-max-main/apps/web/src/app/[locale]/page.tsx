'use client'

import { useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Loader2 } from 'lucide-react'
import { createClient } from '@/lib/supabase'
import { landingPath } from '@/lib/landing'

/**
 * The locale root. It used to redirect to the login page unconditionally,
 * signed in or not — which is what turned "no event yet" into an apparent
 * login failure: the login page sent the user here, and here sent them back.
 *
 * It now asks who is asking. No session → the login form. A session → the
 * dashboard, or the global shell when the account has no event yet.
 */
export default function LocaleHome() {
  const { locale } = useParams() as { locale: string }
  const router = useRouter()

  useEffect(() => {
    let cancelled = false
    async function route() {
      const supabase = createClient()
      const { data: { session } } = await supabase.auth.getSession()
      if (cancelled) return
      if (!session) {
        router.replace(`/${locale}/login`)
        return
      }
      const target = await landingPath(locale)
      if (!cancelled) router.replace(target)
    }
    route()
    return () => { cancelled = true }
  }, [locale, router])

  return (
    <div className="flex min-h-screen items-center justify-center bg-[var(--color-bg-subtle)]">
      <Loader2 className="h-6 w-6 animate-spin text-[var(--color-text-secondary)]" />
    </div>
  )
}
