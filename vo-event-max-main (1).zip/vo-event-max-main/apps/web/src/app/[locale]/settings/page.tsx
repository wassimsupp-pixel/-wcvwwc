'use client'

import React, { useState, useEffect } from 'react'
import { useTranslations } from 'next-intl'
import { useParams } from 'next/navigation'
// next-intl's own router: it knows the locale is a URL segment, so it can
// re-render the page in another language instead of hard-reloading it.
import { usePathname, useRouter } from '@/i18n/navigation'
import { AppLayout } from '@/components/layout/AppLayout'
import { Settings, User, Shield, Globe, Save, CheckCircle2, Loader2, GitMerge, MapPin, Users, Star, AlertTriangle } from 'lucide-react'
import { createClient } from '@/lib/supabase'
import { api, type EventMergeSuggestion } from '@/lib/api'

export default function SettingsPage() {
  const t = useTranslations('settings')
  const { locale } = useParams() as { locale: string }
  const router = useRouter()

  const pathname = usePathname()
  const [language, setLanguage] = useState(locale)
  const [switchingLang, setSwitchingLang] = useState(false)
  // Empty until the session answers — see the same change in Sidebar.tsx.
  // Here the stakes were higher than a cosmetic flash: these values are bound
  // to the profile form, so a save fired before the real user loaded would
  // have written "Marie Dubois" onto the account as its full_name.
  const [userName, setUserName] = useState('')
  const [userRole, setUserRole] = useState('')
  const [email, setEmail] = useState('')
  const [notifEmails, setNotifEmails] = useState(true)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [success, setSuccess] = useState(false)

  // Similar-event merge suggestions (org-level, non-destructive until confirmed)
  const [suggestions, setSuggestions] = useState<EventMergeSuggestion[]>([])
  const [loadingSug, setLoadingSug] = useState(true)
  const [mergingId, setMergingId] = useState<string | null>(null)
  const [mergeMsg, setMergeMsg] = useState<string | null>(null)

  const loadSuggestions = async () => {
    setLoadingSug(true)
    try {
      setSuggestions(await api.eventGrouping.suggestions())
    } catch {
      /* endpoint may be unavailable — show nothing */
    } finally {
      setLoadingSug(false)
    }
  }

  useEffect(() => {
    loadSuggestions()
  }, [])

  const handleMerge = async (s: EventMergeSuggestion) => {
    const mergeIds = s.events.map((e) => e.id).filter((id) => id !== s.canonical_event_id)
    const canonicalName = s.events.find((e) => e.id === s.canonical_event_id)?.name || t('thisEvent')
    if (!confirm(t('confirmMerge', { count: mergeIds.length, name: canonicalName }))) return
    setMergingId(s.canonical_event_id)
    setMergeMsg(null)
    try {
      const res = await api.eventGrouping.merge(s.canonical_event_id, mergeIds)
      setMergeMsg(res.message)
      await loadSuggestions()
    } catch (err) {
      setMergeMsg(err instanceof Error ? err.message : t('errMerge'))
    } finally {
      setMergingId(null)
    }
  }

  useEffect(() => {
    async function loadUser() {
      try {
        const supabase = createClient()
        const { data: { user } } = await supabase.auth.getUser()
        if (user) {
          const name = user.user_metadata?.full_name || user.email?.split('@')[0] || 'Utilisateur VO'
          setUserName(name)
          setEmail(user.email || '')

          try {
            const { data: profile } = await supabase.from('users').select('role').eq('id', user.id).single()
            if (profile) {
              setUserRole(profile.role || 'user')
            }
          } catch {
            // ignore
          }
        }
      } catch (err) {
        console.error('Failed to load settings:', err)
      } finally {
        setLoading(false)
      }
    }
    loadUser()
  }, [])

  /** Applies on change, and is remembered for the next sign-in. */
  const switchLanguage = (next: string) => {
    if (next === language) return
    setLanguage(next)
    setSwitchingLang(true)

    // Fire-and-forget: this is a client-side navigation, so the request
    // survives it. A database without the column — or an offline moment —
    // costs the memory of the choice, never the choice itself.
    void (async () => {
      try {
        const supabase = createClient()
        const { data: { user } } = await supabase.auth.getUser()
        if (!user) return
        await supabase.auth.updateUser({ data: { preferred_language: next } })
        await supabase.from('users').update({ preferred_language: next }).eq('id', user.id)
      } catch (err) {
        console.error('Could not remember the language preference:', err)
      }
    })()

    router.replace(pathname, { locale: next as 'fr' | 'nl' | 'en' })
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    // Now that the name starts empty rather than pre-filled with a fake one,
    // an early submit would blank the account's full_name instead of
    // overwriting it with a stranger's. Neither is acceptable: wait for the
    // profile.
    if (!userName.trim()) return
    setSuccess(false)
    setSaving(true)
    try {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        // 1. Update Supabase Auth metadata
        await supabase.auth.updateUser({
          data: { full_name: userName }
        })
        // 2. Update public.users database row
        await supabase.from('users').update({
          full_name: userName,
        }).eq('id', user.id)
      }
      setSuccess(true)
      setTimeout(() => setSuccess(false), 2500)
    } catch (err) {
      console.error('Failed to save settings:', err)
    } finally {
      setSaving(false)
    }
  }

  return (
    <AppLayout eventId="global" locale={locale}>
      <div className="flex flex-col gap-6 p-6 max-w-4xl">
        {/* Header */}
        <div className="flex justify-between items-center border-b pb-5">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text-primary)] flex items-center gap-2">
              <Settings className="h-6 w-6 text-[var(--color-accent)]" />
              {t('title')}
            </h1>
            <p className="text-sm text-[var(--color-text-secondary)]">
              {t('subtitle')}
            </p>
          </div>
        </div>

        {success && (
          <div className="flex items-center gap-2 rounded-lg bg-[var(--color-success-light)] p-3 text-sm text-[var(--color-success)] font-semibold animate-fade-in">
            <CheckCircle2 className="h-5 w-5" />
            {t('saved')}
          </div>
        )}

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-[var(--color-accent)]" />
          </div>
        ) : (
          <form onSubmit={handleSave} className="space-y-6">
            {/* Profile Section */}
            <div className="rounded-[var(--radius-card)] border bg-white p-6 shadow-sm">
              <h3 className="text-sm font-semibold text-[var(--color-text-primary)] mb-4 flex items-center gap-2">
                <User className="h-4 w-4 text-[var(--color-accent)]" />
                {t('profile')}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[var(--color-text-secondary)] mb-1">{t('fullName')}</label>
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    className="w-full rounded-lg border border-[var(--color-border)] px-3 py-2 text-sm outline-none text-[var(--color-text-primary)] focus:border-[var(--color-accent)]"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[var(--color-text-secondary)] mb-1">{t('role')}</label>
                  <input
                    type="text"
                    value={userRole === 'admin' ? t('roleAdmin') : userRole === 'pm' ? t('rolePm') : userRole ? t('roleUser') : ''}
                    disabled
                    className="w-full rounded-lg border border-[var(--color-border)] bg-gray-50 px-3 py-2 text-sm outline-none text-[var(--color-text-secondary)]"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-[var(--color-text-secondary)] mb-1">{t('email')}</label>
                  <input
                    type="email"
                    value={email}
                    disabled
                    className="w-full rounded-lg border border-[var(--color-border)] bg-gray-50 px-3 py-2 text-sm outline-none text-[var(--color-text-secondary)]"
                  />
                </div>
              </div>
            </div>

            {/* Platform Settings */}
            <div className="rounded-[var(--radius-card)] border bg-white p-6 shadow-sm">
              <h3 className="text-sm font-semibold text-[var(--color-text-primary)] mb-4 flex items-center gap-2">
                <Globe className="h-4 w-4 text-[var(--color-accent)]" />
                {t('uiLanguage')}
              </h3>
              <div className="max-w-xs">
                <label className="block text-xs font-semibold text-[var(--color-text-secondary)] mb-1">{t('defaultLanguage')}</label>
                <select
                  value={language}
                  onChange={(e) => switchLanguage(e.target.value)}
                  disabled={switchingLang}
                  className="w-full rounded-lg border border-[var(--color-border)] px-3 py-2 text-sm outline-none text-[var(--color-text-primary)] bg-white focus:border-[var(--color-accent)]"
                >
                  <option value="fr">Français (FR)</option>
                  <option value="nl">Nederlands (NL)</option>
                  <option value="en">English (EN)</option>
                </select>
                <p className="mt-1.5 flex items-center gap-1.5 text-xs text-[var(--color-text-secondary)]">
                  {switchingLang && <Loader2 className="h-3 w-3 animate-spin" />}
                  {t('languageHint')}
                </p>
              </div>
            </div>

            {/* Notifications */}
            <div className="rounded-[var(--radius-card)] border bg-white p-6 shadow-sm">
              <h3 className="text-sm font-semibold text-[var(--color-text-primary)] mb-4 flex items-center gap-2">
                <Shield className="h-4 w-4 text-[var(--color-accent)]" />
                {t('notifications')}
              </h3>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifEmails}
                  onChange={(e) => setNotifEmails(e.target.checked)}
                  className="h-4 w-4 rounded border-[var(--color-border)] text-[var(--color-accent)] focus:ring-[var(--color-accent)]"
                />
                <span className="text-sm text-[var(--color-text-primary)]">
                  {t('weeklyReports')}
                </span>
              </label>
            </div>

            {/* Action button */}
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={saving || !userName.trim()}
                className="flex items-center gap-1.5 rounded-lg bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[var(--color-accent)]/90 transition-all active:scale-[0.98] disabled:opacity-60"
              >
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                {t('save')}
              </button>
            </div>
          </form>
        )}

        {/* Similar-event merge — org-level, non-destructive until confirmed */}
        <div className="rounded-[var(--radius-card)] border bg-white p-6 shadow-sm">
          <h3 className="mb-1 flex items-center gap-2 text-sm font-semibold text-[var(--color-text-primary)]">
            <GitMerge className="h-4 w-4 text-[var(--color-accent)]" />
            {t('mergeTitle')}
          </h3>
          <p className="mb-4 text-xs text-[var(--color-text-secondary)]">
            {t('mergeHint1')}{' '}
            {t('mergeHint2')}
          </p>

          {mergeMsg && (
            <div className="mb-4 flex items-center gap-2 rounded-lg bg-[var(--color-accent-light)] px-3 py-2 text-xs font-medium text-[var(--color-text-primary)]">
              <CheckCircle2 className="h-4 w-4 shrink-0 text-[var(--color-accent)]" />
              {mergeMsg}
            </div>
          )}

          {loadingSug ? (
            <div className="flex items-center justify-center py-8 text-sm text-[var(--color-text-secondary)]">
              <Loader2 className="mr-2 h-5 w-5 animate-spin" /> {t('analysing')}
            </div>
          ) : suggestions.length === 0 ? (
            <p className="rounded-lg bg-slate-50 px-3 py-4 text-center text-xs text-[var(--color-text-secondary)]">
              {t('noSuggestions')}
            </p>
          ) : (
            <div className="space-y-4">
              {suggestions.map((s) => (
                <div key={s.canonical_event_id} className="rounded-lg border border-amber-200 bg-amber-50/40 p-4">
                  <div className="mb-3 flex flex-wrap items-center gap-2 text-[11px]">
                    <span className="inline-flex items-center gap-1 rounded-full bg-white px-2 py-0.5 font-semibold text-amber-700 border border-amber-200">
                      <AlertTriangle className="h-3 w-3" /> {t('nearbyEvents', { count: s.events.length })}
                    </span>
                    <span className="text-[var(--color-text-secondary)]">{t('minSimilarity', { pct: Math.round(s.min_similarity) })}</span>
                    {s.ai_confirmed === true && (
                      <span className="rounded-full bg-emerald-100 px-2 py-0.5 font-semibold text-emerald-700">{t('aiSameEvent')}</span>
                    )}
                  </div>

                  <div className="space-y-1.5">
                    {s.events.map((ev) => {
                      const isCanonical = ev.id === s.canonical_event_id
                      return (
                        <div
                          key={ev.id}
                          className={`flex flex-wrap items-center gap-x-3 gap-y-1 rounded-md border px-3 py-2 text-xs ${
                            isCanonical ? 'border-[var(--color-accent)] bg-white' : 'border-slate-200 bg-white/60'
                          }`}
                        >
                          {isCanonical ? (
                            <span className="inline-flex items-center gap-1 font-semibold text-[var(--color-accent)]">
                              <Star className="h-3.5 w-3.5" /> {t('keep')}
                            </span>
                          ) : (
                            <span className="text-[10px] font-semibold text-rose-600">{t('willMerge')}</span>
                          )}
                          <span className="font-semibold text-[var(--color-text-primary)]">{ev.name}</span>
                          <span className="inline-flex items-center gap-1 text-[var(--color-text-secondary)]">
                            <Users className="h-3 w-3" /> {ev.participant_count}
                          </span>
                          {ev.location_city && (
                            <span className="inline-flex items-center gap-1 text-[var(--color-text-secondary)]">
                              <MapPin className="h-3 w-3" /> {ev.location_city}
                            </span>
                          )}
                          {ev.start_date && <span className="text-[var(--color-text-secondary)]">{ev.start_date}</span>}
                        </div>
                      )
                    })}
                  </div>

                  <div className="mt-3 flex justify-end">
                    <button
                      onClick={() => handleMerge(s)}
                      disabled={mergingId === s.canonical_event_id}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-[var(--color-accent)] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[var(--color-accent)]/90 disabled:opacity-50"
                    >
                      {mergingId === s.canonical_event_id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <GitMerge className="h-3.5 w-3.5" />}
                      {t('mergeButton')}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  )
}
