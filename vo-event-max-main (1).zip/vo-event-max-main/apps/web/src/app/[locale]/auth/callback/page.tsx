'use client'

/**
 * OAuth return page for Microsoft 365 (Entra ID) sign-in.
 *
 * `signInWithOAuth` sends the browser to Microsoft and Microsoft sends it back
 * here with either a `?code=` to exchange for a session or an `?error=` if it
 * refused. The whole app authenticates client-side — every API call reads the
 * session with `getSession()` and sends it as a Bearer token — so there is no
 * server client or middleware to involve: the browser Supabase client picks the
 * code out of the URL, completes the PKCE exchange (its verifier is in shared
 * storage from the login page that started the flow), and emits `SIGNED_IN`.
 * We wait for that, then route to wherever the user belongs.
 *
 * Two failure modes are surfaced rather than swallowed:
 *   - Microsoft/GoTrue returned an error — including the provisioning trigger
 *     refusing a domain that is not on the allow-list, which arrives here as
 *     `?error=...`. The user sees why and a way back to the login page.
 *   - The exchange simply never lands (network, a stale/replayed link). A short
 *     timeout turns an infinite spinner into a plain message.
 */

import { useEffect, useState } from 'react'
import { useRouter, useParams, useSearchParams } from 'next/navigation'
import { Loader2, AlertCircle } from 'lucide-react'
import { createClient } from '@/lib/supabase'
import { landingPath } from '@/lib/landing'
import { EventMaxLogo } from '@/components/ui/EventMaxLogo'

export default function AuthCallbackPage() {
  const router = useRouter()
  const params = useParams()
  const searchParams = useSearchParams()
  const locale = (params?.locale as string) || 'fr'
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let done = false
    const supabase = createClient()

    const go = async () => {
      if (done) return
      done = true
      router.replace(await landingPath(locale))
      router.refresh()
    }

    // A provider/GoTrue error comes back as query params. `error_description`
    // is the human-readable one; our domain gate raises "signup_not_allowed".
    const providerError =
      searchParams.get('error_description') || searchParams.get('error')
    if (providerError) {
      setError(
        /signup_not_allowed/i.test(providerError)
          ? "Ce compte Microsoft n'est pas autorisé sur cette instance. " +
              "Contactez votre administrateur."
          : providerError
      )
      return
    }

    // The browser client auto-detects the code in the URL and exchanges it;
    // listen for the resulting sign-in rather than racing that exchange.
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN' && session) void go()
    })

    // In case the session was already established before the listener attached.
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) void go()
    })

    // Neither fired: don't spin forever.
    const timer = setTimeout(() => {
      if (!done) {
        setError(
          'La connexion Microsoft a expiré. Réessayez depuis la page de connexion.'
        )
      }
    }, 12000)

    return () => {
      sub.subscription.unsubscribe()
      clearTimeout(timer)
    }
  }, [locale, router, searchParams])

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-[var(--color-accent-light)] via-white to-[var(--color-cta-light)] px-4">
      <div className="w-full max-w-[400px] text-center">
        <div className="mb-6 flex justify-center">
          <EventMaxLogo className="h-12 w-auto text-[var(--color-text-primary)]" />
        </div>

        {error ? (
          <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white p-6"
               style={{ boxShadow: 'var(--shadow-modal)' }}>
            <div className="mb-3 flex items-start gap-2 rounded-lg bg-[var(--color-danger-light)] p-3 text-left">
              <AlertCircle className="mt-0.5 h-4 w-4 flex-shrink-0 text-[var(--color-danger)]" />
              <p className="text-sm text-[var(--color-danger)]">{error}</p>
            </div>
            <button
              onClick={() => router.replace(`/${locale}/login`)}
              className="mt-1 w-full rounded-lg bg-[var(--color-text-primary)] px-4 py-2 text-sm font-medium text-white"
            >
              Retour à la connexion
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3 text-[var(--color-text-secondary)]">
            <Loader2 className="h-6 w-6 animate-spin" />
            <p className="text-sm">Connexion en cours…</p>
          </div>
        )}
      </div>
    </div>
  )
}
