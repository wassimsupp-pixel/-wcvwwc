'use client'

import { useEffect, useState, useTransition } from 'react'
import { useTranslations } from 'next-intl'
import { useRouter, useParams } from 'next/navigation'
import { Eye, EyeOff, Loader2, AlertCircle, CheckCircle2 } from 'lucide-react'
import { createClient } from '@/lib/supabase'
import { cn } from '@/lib/utils'
import { EventMaxLogo } from '@/components/ui/EventMaxLogo'
import { landingPath } from '@/lib/landing'
import { VO_SITE_URL } from '@/lib/brand'

export default function LoginPage() {
  const tLogin = useTranslations('login')
  const router = useRouter()
  const params = useParams()
  const locale = (params?.locale as string) || 'fr'
  const [isPending, startTransition] = useTransition()
  const [isSignUp, setIsSignUp] = useState(false)
  const [email, setEmail] = useState('')
  const [fullName, setFullName] = useState('')
  const [language, setLanguage] = useState(locale)
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  // Someone who is still signed in has no business filling this form again:
  // reopening the app goes straight to the dashboard. Logout awaits signOut()
  // before navigating here, so this cannot bounce a user who just left.
  useEffect(() => {
    let cancelled = false
    async function skipIfSignedIn() {
      const { data: { session } } = await createClient().auth.getSession()
      if (cancelled || !session) return
      const target = await landingPath(locale)
      if (!cancelled) router.replace(target)
    }
    skipIfSignedIn()
    return () => { cancelled = true }
  }, [locale, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setSuccess(null)

    startTransition(async () => {
      try {
        const supabase = createClient()
        if (isSignUp) {
          const { data, error } = await supabase.auth.signUp({
            email,
            password,
            options: {
              data: {
                full_name: fullName,
                preferred_language: language,
              },
            },
          })
          if (error) {
            setError(error.message)
            return
          }
          
          // Optionally attempt public.users table update
          if (data?.user) {
            try {
              await supabase.from('users').update({
                preferred_language: language,
              }).eq('id', data.user.id)
            } catch (dbErr) {
              console.warn('Could not update users table directly:', dbErr)
            }
          }
          
          setSuccess(tLogin('accountCreated'))
          setIsSignUp(false)
          setPassword('')
        } else {
          const { data, error } = await supabase.auth.signInWithPassword({ email, password })
          if (error) {
            setError(error.message === 'Invalid login credentials'
              ? tLogin('badCredentials')
              : error.message
            )
            return
          }
          
          let userLang = locale || 'fr'
          if (data?.user) {
            try {
              const { data: profile } = await supabase
                .from('users')
                .select('preferred_language')
                .eq('id', data.user.id)
                .single()
              if (profile?.preferred_language) {
                userLang = profile.preferred_language
              }
            } catch (pErr) {
              console.warn('Failed to load user language preference on login:', pErr)
            }
          }
          
          // Straight to the dashboard. The fallback used to be `/${userLang}`,
          // which redirects to this very page — so an account with no event
          // was thrown back at the login form it had just passed.
          router.replace(await landingPath(userLang))
          router.refresh()
        }
      } catch {
        setError(tLogin('unexpectedError'))
      }
    })
  }

  // Microsoft 365 (Entra ID). This only starts the redirect to Microsoft; the
  // session is completed back on /[locale]/auth/callback. Who is actually
  // allowed to end up with an account is enforced in the database
  // (allowed_signup_domains + the provisioning trigger), not here — a button
  // cannot be the gate, because anyone can reach this page.
  const handleMicrosoft = async () => {
    setError(null)
    setSuccess(null)
    try {
      const supabase = createClient()
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'azure',
        options: {
          scopes: 'openid email profile',
          redirectTo: `${window.location.origin}/${locale}/auth/callback`,
        },
      })
      if (error) setError(tLogin('ssoError'))
      // On success the browser is already navigating away to Microsoft.
    } catch {
      setError(tLogin('ssoError'))
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-[var(--color-accent-light)] via-white to-[var(--color-cta-light)] px-4">
      <div className="w-full max-w-[400px]">
        {/* Card */}
        <div
          className="overflow-hidden rounded-[var(--radius-card)] border border-[var(--color-border)] bg-white"
          style={{ boxShadow: 'var(--shadow-modal)' }}
        >
          {/* Header */}
          <div className="px-8 pb-4 pt-8 text-center">
            <div className="mb-4 flex flex-col items-center justify-center select-none">
              <EventMaxLogo className="h-12 w-auto text-[var(--color-text-primary)]" />
              {/* Same attribution as the sidebar's, same destination. */}
              <a
                href={VO_SITE_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 flex items-center gap-2 text-[var(--color-text-secondary)] transition-colors hover:text-[var(--color-text-primary)] hover:underline"
              >
                <div className="h-[24px] w-[34px] flex-shrink-0" aria-hidden>
                  <svg className="h-full w-full" viewBox="0 0 60 40">
                    <text x="0" y="27" fontFamily="system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif" fontWeight="900" fontSize="30" letterSpacing="-1.5" fill="currentColor">VO</text>
                    <line x1="1" y1="34" x2="44" y2="34" stroke="currentColor" strokeWidth="4" />
                  </svg>
                </div>
                <span className="text-[10px] font-medium">Powered by VO Communication Group</span>
              </a>
            </div>
            <h1 className="text-xl font-bold text-[var(--color-text-primary)]">
              {isSignUp ? tLogin('createAccount') : 'Connexion'}
            </h1>
            <p className="mt-1 text-sm text-[var(--color-text-secondary)]">
              Event Intelligence V1
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="px-8 pb-6">
            {/* Error message */}
            {error && (
              <div className="mb-4 flex items-start gap-2 rounded-lg bg-[var(--color-danger-light)] p-3">
                <AlertCircle className="mt-0.5 h-4 w-4 flex-shrink-0 text-[var(--color-danger)]" />
                <p className="text-sm text-[var(--color-danger)]">{error}</p>
              </div>
            )}

            {/* Success message */}
            {success && (
              <div className="mb-4 flex items-start gap-2 rounded-lg bg-[var(--color-success-light)] p-3">
                <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-[var(--color-success)]" />
                <p className="text-sm text-[var(--color-success)]">{success}</p>
              </div>
            )}

            {/* Full name (Sign Up only) */}
            {isSignUp && (
              <>
                <div className="mb-4">
                  <label
                    htmlFor="fullName"
                    className="mb-1.5 block text-sm font-medium text-[var(--color-text-primary)]"
                  >
                    {tLogin('fullName')}
                  </label>
                  <input
                    id="fullName"
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder={tLogin('fullNamePlaceholder')}
                    required={isSignUp}
                    className={cn(
                      'w-full rounded-lg border border-[var(--color-border)] px-3 py-2.5 text-sm',
                      'text-[var(--color-text-primary)] placeholder:text-[var(--color-text-secondary)]',
                      'outline-none transition-all',
                      'focus:border-[var(--color-accent)] focus:ring-2 focus:ring-[var(--color-accent-light)]',
                      'disabled:opacity-60'
                    )}
                    disabled={isPending}
                  />
                </div>

                <div className="mb-4">
                  <label
                    htmlFor="language"
                    className="mb-1.5 block text-sm font-medium text-[var(--color-text-primary)]"
                  >
                    {tLogin('preferredLanguage')}
                  </label>
                  <select
                    id="language"
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                    className={cn(
                      'w-full rounded-lg border border-[var(--color-border)] px-3 py-2.5 text-sm bg-white',
                      'text-[var(--color-text-primary)]',
                      'outline-none transition-all',
                      'focus:border-[var(--color-accent)] focus:ring-2 focus:ring-[var(--color-accent-light)]',
                      'disabled:opacity-60'
                    )}
                    disabled={isPending}
                  >
                    <option value="fr">Français (FR)</option>
                    <option value="en">English (EN)</option>
                    <option value="nl">Nederlands (NL)</option>
                  </select>
                </div>
              </>
            )}

            {/* Email */}
            <div className="mb-4">
              <label
                htmlFor="email"
                className="mb-1.5 block text-sm font-medium text-[var(--color-text-primary)]"
              >
                {tLogin('email')}
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={tLogin('emailPlaceholder')}
                required
                autoComplete="email"
                className={cn(
                  'w-full rounded-lg border border-[var(--color-border)] px-3 py-2.5 text-sm',
                  'text-[var(--color-text-primary)] placeholder:text-[var(--color-text-secondary)]',
                  'outline-none transition-all',
                  'focus:border-[var(--color-accent)] focus:ring-2 focus:ring-[var(--color-accent-light)]',
                  'disabled:opacity-60'
                )}
                disabled={isPending}
              />
            </div>

            {/* Password */}
            <div className="mb-6">
              <label
                htmlFor="password"
                className="mb-1.5 block text-sm font-medium text-[var(--color-text-primary)]"
              >
                {tLogin('password')}
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  autoComplete="current-password"
                  className={cn(
                    'w-full rounded-lg border border-[var(--color-border)] px-3 py-2.5 pr-10 text-sm',
                    'text-[var(--color-text-primary)] placeholder:text-[var(--color-text-secondary)]',
                    'outline-none transition-all',
                    'focus:border-[var(--color-accent)] focus:ring-2 focus:ring-[var(--color-accent-light)]',
                    'disabled:opacity-60'
                  )}
                  disabled={isPending}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={isPending || !email || !password || (isSignUp && !fullName)}
              className={cn(
                'flex w-full items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-semibold text-white',
                'bg-[var(--color-accent)] transition-all hover:bg-[#6B5A93] active:scale-[0.99]',
                'disabled:cursor-not-allowed disabled:opacity-60'
              )}
            >
              {isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  {isSignUp ? tLogin('signingUp') : tLogin('signingIn')}
                </>
              ) : (
                isSignUp ? tLogin('signUp') : tLogin('signIn')
              )}
            </button>

            {/* Divider */}
            <div className="my-4 flex items-center gap-3">
              <div className="h-px flex-1 bg-[var(--color-border)]" />
              <span className="text-xs text-[var(--color-text-secondary)]">
                {tLogin('orContinueWith')}
              </span>
              <div className="h-px flex-1 bg-[var(--color-border)]" />
            </div>

            {/* Microsoft 365 SSO */}
            <button
              type="button"
              onClick={handleMicrosoft}
              disabled={isPending}
              className={cn(
                'flex w-full items-center justify-center gap-2.5 rounded-lg border border-[var(--color-border)] bg-white py-2.5 text-sm font-medium',
                'text-[var(--color-text-primary)] transition-all hover:bg-slate-50 active:scale-[0.99]',
                'disabled:cursor-not-allowed disabled:opacity-60'
              )}
            >
              <svg className="h-4 w-4" viewBox="0 0 21 21" aria-hidden="true">
                <rect x="1" y="1" width="9" height="9" fill="#f25022" />
                <rect x="11" y="1" width="9" height="9" fill="#7fba00" />
                <rect x="1" y="11" width="9" height="9" fill="#00a4ef" />
                <rect x="11" y="11" width="9" height="9" fill="#ffb900" />
              </svg>
              {tLogin('continueMicrosoft')}
            </button>
          </form>

          {/* Toggle signup/login */}
          <div className="border-t border-slate-100 bg-slate-50/50 px-8 py-4 text-center">
            <button
              type="button"
              onClick={() => {
                setIsSignUp(!isSignUp)
                setError(null)
                setSuccess(null)
              }}
              className="text-xs font-semibold text-[var(--color-accent)] hover:underline"
              disabled={isPending}
            >
              {isSignUp ? tLogin('haveAccount') : tLogin('noAccount')}
            </button>
          </div>
        </div>

        {/* Footer */}
        <p className="mt-6 text-center text-xs text-[var(--color-text-secondary)]">
          © 2026 VO Group. {tLogin('rightsReserved')}
        </p>
      </div>
    </div>
  )
}
