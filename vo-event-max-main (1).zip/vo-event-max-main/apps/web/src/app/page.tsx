import { redirect } from 'next/navigation'

// Hand over to the locale root, which decides between the login form and the
// dashboard based on the session. Sending people straight to /fr/login here
// meant a signed-in user opening the bare domain was shown a login form.
export default function RootPage() {
  redirect('/fr')
}
