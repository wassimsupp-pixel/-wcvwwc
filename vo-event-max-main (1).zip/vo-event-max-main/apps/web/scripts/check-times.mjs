/**
 * check-times — a schedule time is a clock face, not an instant.
 *
 * A flight departs at the hour printed on the boarding pass. FCM writes
 * "12:00" for a Frankfurt departure, the import stores that clock verbatim
 * tagged UTC, and the API renders it back verbatim. A browser asked to render
 * it "locally" adds the reader's own offset on top — so an organizer in
 * Brussels read 14:00 for a flight leaving at 12:00, while the master list on
 * the next screen said 12:00.
 *
 * This is the second time this class of bug shipped: the first shifted hotel
 * check-in dates by a day for any viewer west of UTC. Both had the same
 * shape — a stored clock face handed to `toLocale*` without a timeZone.
 *
 * So: every schedule field must go through `formatScheduleTime` (times) or
 * `formatDateOnly` (date-only columns), both of which pin the zone. Real
 * MOMENTS — when an email arrived, when a consolidation ran, when a field was
 * edited — are instants and are none of this file's business; they are meant
 * to follow the reader's timezone and are not listed below.
 *
 *   node scripts/check-times.mjs
 */
import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = join(fileURLToPath(new URL('.', import.meta.url)), '..')
const SRC = join(ROOT, 'src')

/** Columns that hold a wall clock at a place, not a moment in time. */
const SCHEDULE = [
  'departure_time', 'arrival_time', 'pickup_time', 'date_time',
  'night_date', 'check_in_date', 'check_out_date', 'start_date', 'end_date',
  'departure_date', 'return_date', 'arrival_date', 'passport_expiry',
  'date_of_birth',
]

function walk(dir, out = []) {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry)
    if (statSync(full).isDirectory()) walk(full, out)
    else if (entry.endsWith('.tsx') || entry.endsWith('.ts')) out.push(full)
  }
  return out
}

const problems = []
let checked = 0

for (const file of walk(SRC)) {
  if (file.endsWith(join('lib', 'dates.ts'))) continue // the helpers themselves
  const src = readFileSync(file, 'utf8')

  // `new Date(<something>.departure_time).toLocaleString(…)` — the shape that
  // hands a stored clock face to the reader's timezone.
  const calls = src.matchAll(
    /new Date\(([^)]*)\)\s*\.\s*toLocale(?:String|TimeString|DateString)\s*\(([\s\S]{0,160}?)\)/g
  )
  for (const call of calls) {
    const [whole, subject, args] = call
    const field = SCHEDULE.find((f) => subject.includes(f))
    if (!field) continue
    checked++
    if (/timeZone/.test(args)) continue
    const line = src.slice(0, call.index).split('\n').length
    problems.push(
      `${relative(ROOT, file)}:${line}  « ${field} » rendu sans fuseau — ` +
      `utilisez formatScheduleTime (ou formatDateOnly)`
    )
    void whole
  }

  // The same field handed straight to Intl.DateTimeFormat.
  for (const call of src.matchAll(/new Intl\.DateTimeFormat\(([\s\S]{0,200}?)\)/g)) {
    if (!/timeZone/.test(call[1])) {
      const after = src.slice(call.index, call.index + 400)
      const field = SCHEDULE.find((f) => after.includes(f))
      if (field) {
        checked++
        const line = src.slice(0, call.index).split('\n').length
        problems.push(
          `${relative(ROOT, file)}:${line}  « ${field} » formaté sans fuseau (Intl.DateTimeFormat)`
        )
      }
    }
  }
}

if (problems.length > 0) {
  console.error(`\n${problems.length} horaire(s) rendus dans le fuseau du lecteur :\n`)
  for (const line of problems) console.error('  ' + line)
  console.error(
    '\nUn horaire de vol, de navette ou d’activité est une heure locale sur place.\n' +
    'Le rendre « en local » y ajoute le décalage du lecteur.\n'
  )
  process.exit(1)
}

// Nothing wrong is the normal case, so say something useful instead of "0":
// how many schedule fields DO go through a helper that pins the zone.
let pinned = 0
for (const file of walk(SRC)) {
  if (file.endsWith(join('lib', 'dates.ts'))) continue
  const src = readFileSync(file, 'utf8')
  pinned += (src.match(/formatScheduleTime\(|formatDateOnly\(/g) || []).length
}

console.log(
  `horaires OK — ${pinned} champ(s) d'horaire rendus via formatScheduleTime/formatDateOnly, ` +
  `${checked} rendu(s) direct(s) vérifié(s)`
)
