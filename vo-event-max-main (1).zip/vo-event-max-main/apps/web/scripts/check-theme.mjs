/**
 * check-theme — the form's appearance is chosen in Python and drawn in
 * TypeScript, and the two must agree.
 *
 * `services/registration_theme.py` decides which keys may be stored;
 * `lib/registrationTheme.ts` decides what each key looks like. Neither imports
 * the other, so adding a sixth typeface on one side and forgetting the other
 * is a two-line change that ships a form rendered in `font-family: undefined`
 * — with nothing failing anywhere, because a missing key in a lookup is not an
 * error in either language.
 *
 * So this reads the tuples out of the Python and checks them against the maps
 * in the TypeScript, then walks every combination through the renderer.
 *
 * Two other things it guards:
 *
 *   **Contrast.** The submit button is the one control the page exists to get
 *   clicked. Its label is set in whichever ink reads better on the organizer's
 *   colour, and "reads better" has to be computed — the point where white and
 *   black are equally legible sits near luminance 0.18, so any eyeballed
 *   threshold puts white text on a band of mid-tones where dark ink reads
 *   twice as well.
 *
 *   **Injection.** These values land in a `style` attribute on a page open to
 *   the world. The Python sanitizer is the real defence; this is the second
 *   pair of eyes on the other end of the wire.
 *
 *   node scripts/check-theme.mjs
 */
import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const ROOT = join(fileURLToPath(new URL('.', import.meta.url)), '..')
const API = join(ROOT, '../../apps/api/services/registration_theme.py')

const T = await import(pathToFileURL(join(ROOT, 'src/lib/registrationTheme.ts')).href)

const problems = []
let assertions = 0
const check = (ok, message) => {
  assertions++
  if (!ok) problems.push(message)
}

// ---------------------------------------------------------------------------
// The two sides hold the same sets
// ---------------------------------------------------------------------------
const python = readFileSync(API, 'utf8')

/** `NAME: tuple[str, ...] = ("a", "b")` → ['a', 'b'] */
function tupleFromPython(name) {
  const match = python.match(new RegExp(`${name}:\\s*tuple\\[str, \\.\\.\\.\\]\\s*=\\s*\\(([^)]*)\\)`))
  if (!match) {
    problems.push(`${name} introuvable dans registration_theme.py — la table a changé de forme`)
    return []
  }
  return [...match[1].matchAll(/"([^"]+)"/g)].map((m) => m[1])
}

for (const [pythonName, typescript] of [
  ['FONTS', T.FONTS],
  ['SURFACES', T.SURFACE_NAMES],
  ['CORNERS', T.CORNER_NAMES],
  ['HEADER_STYLES', T.HEADER_STYLES],
]) {
  const stored = tupleFromPython(pythonName)
  check(
    stored.length > 0 && stored.join(',') === [...typescript].join(','),
    `${pythonName} : l'API accepte [${stored}] mais le rendu connaît [${[...typescript]}]`
  )
}

// The default the API falls back to has to be one the renderer can draw.
const defaultAccent = python.match(/DEFAULT_ACCENT = "(#[0-9a-f]{6})"/)?.[1]
check(
  defaultAccent === T.DEFAULT_THEME.accent,
  `couleur par défaut : API ${defaultAccent}, rendu ${T.DEFAULT_THEME.accent}`
)

// ---------------------------------------------------------------------------
// Every combination renders something
// ---------------------------------------------------------------------------
const FORBIDDEN = /[;{}<>]|url\s*\(|expression\s*\(|javascript:/i
// Every colour the theme emits must be a literal a browser has always
// understood. `color-mix` shipped in 2023 and does not degrade politely: an
// unsupported function drops the whole declaration, so a page whose background
// is a gradient between two mixed colours simply loses its background — on the
// one page in this product a member of the public opens on their own phone.
const COLOUR_KEYS = /(accent|page|surface|input|border|text|bg|cta|on-accent)/
const LITERAL_COLOUR = /^#[0-9a-f]{6}$/i

for (const font of T.FONTS) {
  for (const surface of T.SURFACE_NAMES) {
    for (const corners of T.CORNER_NAMES) {
      const theme = T.resolveTheme({ font, surface, corners, accent: '#7c3aed' })
      const vars = T.themeVariables(theme)

      for (const [name, value] of Object.entries(vars)) {
        check(
          value !== undefined && value !== null && String(value).length > 0,
          `${font}/${surface}/${corners} : « ${name} » ne résout rien`
        )
        // color-mix() is the one function these values legitimately use, and
        // it carries parentheses but never a declaration separator.
        check(
          !FORBIDDEN.test(String(value).replace(/color-mix\s*\(/g, '')),
          `${font}/${surface}/${corners} : « ${name} » contient de quoi sortir de l'attribut style`
        )
      }
      for (const [name, value] of Object.entries(vars)) {
        if (!name.startsWith('--') || !COLOUR_KEYS.test(name)) continue
        check(
          LITERAL_COLOUR.test(String(value)),
          `${surface} : « ${name} » vaut « ${value} » — attendu un #rrggbb littéral, ` +
          `pas une fonction CSS que le navigateur du participant peut ignorer`
        )
      }
      check(String(vars.fontFamily || '').includes(','), `${font} : pas de police de repli`)
    }
  }
}

// ---------------------------------------------------------------------------
// The submit button stays readable
// ---------------------------------------------------------------------------
const luminance = (hex) => {
  const channel = (at) => {
    const srgb = parseInt(hex.slice(at, at + 2), 16) / 255
    return srgb <= 0.03928 ? srgb / 12.92 : Math.pow((srgb + 0.055) / 1.055, 2.4)
  }
  return 0.2126 * channel(1) + 0.7152 * channel(3) + 0.0722 * channel(5)
}
const ratio = (a, b) => {
  const [hi, lo] = a > b ? [a, b] : [b, a]
  return (hi + 0.05) / (lo + 0.05)
}

// No pair of inks rescues every colour. Two inks at the extremes of the scale
// still leave a band of mid-tones -- around luminance 0.18 -- where the better
// of the two reaches only ~4.48:1, and our dark ink is #111827 rather than
// pure black, which costs a little more. So AA (4.5) is not a floor this can
// assert; what it CAN assert is above -- that the ink chosen is always the
// better of the two, checked on every colour below. This floor only catches a
// chooser that has gone badly wrong.
const FLOOR = 4.15
let worst = { hex: '', ratio: Infinity }

for (let r = 0; r < 256; r += 17) {
  for (let g = 0; g < 256; g += 17) {
    for (let b = 0; b < 256; b += 17) {
      const hex = '#' + [r, g, b].map((c) => c.toString(16).padStart(2, '0')).join('')
      const ink = T.onAccent(hex)
      const got = ratio(luminance(hex), luminance(ink))
      const other = ratio(luminance(hex), luminance(ink === '#ffffff' ? '#111827' : '#ffffff'))
      check(got >= other, `${hex} : encre ${ink} à ${got.toFixed(2)}:1, l'autre ferait ${other.toFixed(2)}:1`)
      if (got < worst.ratio) worst = { hex, ratio: got }
    }
  }
}
check(
  worst.ratio >= FLOOR,
  `contraste minimum ${worst.ratio.toFixed(2)}:1 sur ${worst.hex} — en dessous du plancher ${FLOOR}`
)

// Half-typed colours. The editor hands themeVariables whatever is in the hex
// field, one keystroke at a time, so every prefix of a real colour goes through
// it. A five-digit value used to parse into a plausible WRONG colour, which is
// the failure nobody notices.
for (const partial of ['#', '#2', '#25', '#256', '#2563', '#2563e', 'abc', '', '  ', 'blue']) {
  const vars = T.themeVariables({ ...T.DEFAULT_THEME, accent: partial })
  for (const [name, value] of Object.entries(vars)) {
    if (!name.startsWith('--') || !COLOUR_KEYS.test(name)) continue
    check(
      LITERAL_COLOUR.test(String(value)),
      `accent « ${partial} » : « ${name} » vaut « ${value} » — une couleur a moitie tapee ne doit rien casser`
    )
  }
  check(
    vars['--color-accent'] === T.DEFAULT_THEME.accent,
    `accent « ${partial} » devrait retomber sur la couleur par defaut, pas « ${vars['--color-accent']} »`
  )
}

// A colour it cannot read falls back rather than crashing the page.
for (const junk of ['', 'red', '#12345', 'rgb(1,2,3)', null, undefined, '#ABC']) {
  check(
    ['#ffffff', '#111827'].includes(T.onAccent(junk)),
    `« ${junk} » : encre inattendue ${T.onAccent(junk)}`
  )
}

// ---------------------------------------------------------------------------
// A partial theme is completed, never passed through
// ---------------------------------------------------------------------------
for (const partial of [null, undefined, {}, { font: 'nope' }, { header: {} }, { accent: 'nope' }]) {
  const theme = T.resolveTheme(partial)
  check(T.FONTS.includes(theme.font), `${JSON.stringify(partial)} : police invalide`)
  check(T.SURFACE_NAMES.includes(theme.surface), `${JSON.stringify(partial)} : fond invalide`)
  check(T.CORNER_NAMES.includes(theme.corners), `${JSON.stringify(partial)} : angles invalides`)
  check(/^#[0-9a-f]{6}$/.test(theme.accent), `${JSON.stringify(partial)} : couleur invalide`)
  check(T.HEADER_STYLES.includes(theme.header.style), `${JSON.stringify(partial)} : en-tête invalide`)
  for (const key of ['image_url', 'title', 'subtitle']) {
    check(typeof theme.header[key] === 'string', `${JSON.stringify(partial)} : header.${key} non défini`)
  }
}

if (problems.length > 0) {
  console.error(`\n${problems.length} problème(s) d'apparence :\n`)
  for (const line of problems.slice(0, 30)) console.error('  ' + line)
  if (problems.length > 30) console.error(`  … et ${problems.length - 30} autres`)
  process.exit(1)
}

console.log(
  `apparence OK — ${assertions} vérifications, API et rendu d'accord sur ` +
  `${T.FONTS.length} polices / ${T.SURFACE_NAMES.length} fonds / ${T.CORNER_NAMES.length} angles, ` +
  `contraste minimum ${worst.ratio.toFixed(2)}:1`
)
