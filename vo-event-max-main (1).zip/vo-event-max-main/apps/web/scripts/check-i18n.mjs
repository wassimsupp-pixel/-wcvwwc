/**
 * check-i18n — every t('key') resolves, in every language.
 *
 * next-intl does not throw on a missing key in production; it renders the key
 * path or falls back. So a namespace typo, or a French string translated into
 * two languages out of three, produces a page that looks fine to whoever wrote
 * it and shows raw keys — or the wrong language — to everybody else. That is
 * invisible in review and obvious to a user, which is the worst possible split.
 *
 * This walks the source for `const x = useTranslations('ns')` and every `x('k')`
 * that follows, resolves each against messages/{fr,nl,en}.json, and exits
 * non-zero on the first gap.
 *
 *   node scripts/check-i18n.mjs
 */
import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = join(fileURLToPath(new URL('.', import.meta.url)), '..')
const SRC = join(ROOT, 'src')
const MESSAGES = join(SRC, 'messages')
const LOCALES = ['fr', 'nl', 'en']

const dicts = Object.fromEntries(
  LOCALES.map((l) => [l, JSON.parse(readFileSync(join(MESSAGES, `${l}.json`), 'utf8'))])
)

/** Walk a dotted path; returns undefined rather than throwing on a dead end. */
function lookup(dict, path) {
  return path.split('.').reduce((node, part) => (node == null ? undefined : node[part]), dict)
}

function walk(dir, out = []) {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry)
    if (statSync(full).isDirectory()) walk(full, out)
    else if (entry.endsWith('.tsx') || entry.endsWith('.ts')) out.push(full)
  }
  return out
}

const problems = []
let checked = 0
/** key path -> every call site's argument names (null = could not tell). */
const callArgs = new Map()

/**
 * The argument names a `t('key', { … })` call passes, read from the source
 * right after the key. Returns null for `t('key', props)` or a spread, where
 * the names are only known at runtime — a guess there would be a false alarm.
 */
function argsGivenAt(rest) {
  if (!rest.startsWith(',')) return rest.startsWith(')') ? new Set() : null
  const body = rest.slice(1).trimStart()
  if (!body.startsWith('{')) return null
  // Match to the closing brace, counting nesting so `{ n: { a: 1 } }` works.
  let depth = 0
  let end = -1
  for (let i = 0; i < body.length; i++) {
    if (body[i] === '{') depth++
    else if (body[i] === '}' && --depth === 0) { end = i; break }
  }
  if (end === -1) return null
  const inner = body.slice(1, end)
  const names = new Set()
  let level = 0
  let token = ''
  for (const ch of inner) {
    if ('{[('.includes(ch)) level++
    else if ('}])'.includes(ch)) level--
    if (ch === ',' && level === 0) { token = '' ; continue }
    if (ch === ':' && level === 0) { if (token.trim()) names.add(token.trim()); token = '' ; continue }
    if (level === 0 && (ch === ':' || ch === ',')) continue
    token += ch
  }
  // `{ who, hotel }` shorthand: whatever is left after the last comma.
  for (const part of inner.split(',')) {
    const short = part.trim()
    if (/^[A-Za-z_$][\w$]*$/.test(short)) names.add(short)
  }
  if (inner.includes('...')) return null
  return names
}

for (const file of walk(SRC)) {
  const src = readFileSync(file, 'utf8')
  // hook variable -> namespace, e.g. `const tKpi = useTranslations('dashboard.kpi')`
  const namespaces = new Map()
  for (const m of src.matchAll(/const\s+(\w+)\s*=\s*useTranslations\(\s*'([^']+)'\s*\)/g)) {
    namespaces.set(m[1], m[2])
  }
  if (namespaces.size === 0) continue

  for (const [hook, ns] of namespaces) {
    // `t('key')`, `t('key', { … })` and `t.rich('key', …)`, but not `t` used
    // as a value. `.rich` was invisible here until the paragraphs that carry
    // a <strong> inside them started using it.
    const calls = src.matchAll(new RegExp(`\\b${hook}(?:\\.rich|\\.markup)?\\(\\s*'([^']+)'`, 'g'))
    for (const call of calls) {
      // t('role.' + userRole) — the literal is only the stable prefix of a
      // key built at runtime. Checking it as-is would report a key nobody
      // wrote; the nested values it points at are covered by the
      // language-parity pass below.
      if (call[1].endsWith('.')) continue
      const path = `${ns}.${call[1]}`
      checked++
      // What the call site hands over, when it hands over a plain object.
      // Anything else (a spread, a variable) is not worth guessing at.
      const after = src.slice(call.index + call[0].length)
      callArgs.set(path, (callArgs.get(path) || []).concat([{
        file: relative(ROOT, file),
        given: argsGivenAt(after),
      }]))
      for (const locale of LOCALES) {
        const value = lookup(dicts[locale], path)
        if (typeof value !== 'string') {
          problems.push(
            `${relative(ROOT, file)}  ${locale}  ${path}  ` +
            (value === undefined ? 'absente' : `n'est pas une chaîne (${typeof value})`)
          )
        }
      }
    }
  }
}

// The other direction: a language that is missing keys the others have. A key
// present in fr and absent in nl is exactly the half-translated page this file
// exists to prevent, and no t() call reveals it.
function flatten(node, prefix = '', out = new Set()) {
  for (const [key, value] of Object.entries(node)) {
    const path = prefix ? `${prefix}.${key}` : key
    if (value && typeof value === 'object') flatten(value, path, out)
    else out.add(path)
  }
  return out
}
const reference = flatten(dicts.fr)
for (const locale of LOCALES.filter((l) => l !== 'fr')) {
  const theirs = flatten(dicts[locale])
  for (const path of reference) {
    if (!theirs.has(path)) problems.push(`messages/${locale}.json  ${path}  absente (présente en fr)`)
  }
  for (const path of theirs) {
    if (!reference.has(path)) problems.push(`messages/${locale}.json  ${path}  en trop (absente en fr)`)
  }
}

// Third pass: every message must COMPILE, in every language, and must take
// the same arguments everywhere.
//
// next-intl parses ICU lazily, at render. A missing brace in one plural, or a
// `{count}` a translation dropped, therefore surfaces as a crashed page or a
// sentence with a hole in it — in one language, on one screen, long after
// review. Both are cheap to catch here.
const { IntlMessageFormat } = await import('intl-messageformat')

/** The named arguments an ICU message expects, e.g. {count, name}. */
function argsOf(ast, found = new Set()) {
  for (const node of ast) {
    if (node.type !== 0 && node.value !== undefined) found.add(node.value)
    if (node.options) for (const opt of Object.values(node.options)) argsOf(opt.value, found)
    if (node.children) argsOf(node.children, found)
  }
  return found
}

const compiled = new Map()
for (const locale of LOCALES) {
  for (const path of flatten(dicts[locale])) {
    const message = lookup(dicts[locale], path)
    if (typeof message !== 'string') continue
    try {
      compiled.set(`${locale}|${path}`, argsOf(new IntlMessageFormat(message, locale).getAst()))
    } catch (err) {
      problems.push(`messages/${locale}.json  ${path}  ICU invalide : ${String(err.message).split('\n')[0]}`)
    }
  }
}

for (const path of reference) {
  const french = compiled.get(`fr|${path}`)
  if (!french) continue
  for (const locale of LOCALES.filter((l) => l !== 'fr')) {
    const theirs = compiled.get(`${locale}|${path}`)
    if (!theirs) continue
    for (const arg of french) {
      if (!theirs.has(arg)) problems.push(`messages/${locale}.json  ${path}  n'utilise pas {${arg}} (présent en fr)`)
    }
    for (const arg of theirs) {
      if (!french.has(arg)) problems.push(`messages/${locale}.json  ${path}  utilise {${arg}}, inconnu en fr`)
    }
  }
}

for (const [path, sites] of callArgs) {
  const needed = compiled.get(`fr|${path}`)
  if (!needed || needed.size === 0) continue
  for (const site of sites) {
    if (site.given === null) continue
    for (const arg of needed) {
      if (!site.given.has(arg)) {
        problems.push(`${site.file}  ${path}  appelé sans {${arg}}`)
      }
    }
  }
}

if (problems.length > 0) {
  console.error(`\n${problems.length} problème(s) i18n :\n`)
  for (const line of problems.slice(0, 60)) console.error('  ' + line)
  if (problems.length > 60) console.error(`  … et ${problems.length - 60} autres`)
  process.exit(1)
}

console.log(`i18n OK — ${checked} appels t() résolus dans ${LOCALES.length} langues, ${reference.size} clés par langue, toutes compilées`)
