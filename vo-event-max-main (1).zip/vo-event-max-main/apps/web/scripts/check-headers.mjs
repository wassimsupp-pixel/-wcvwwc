/**
 * The navigation and the page must agree.
 *
 * Sixteen pages had five different headers between them: nine carried an icon
 * and six did not, two carried a different icon from the navigation entry that
 * leads to them, two were `font-semibold` where the rest were `font-bold`, and
 * six were titled with a longer name than the one in the sidebar — you clicked
 * "Vols" and arrived at "Gestion des Vols".
 *
 * This is the guard. Run by `npm run check-headers`, and by check-i18n's
 * sibling in CI, so the next page added to the product cannot quietly invent
 * a sixth header.
 */
import fs from 'node:fs'
import path from 'node:path'

const ROOT = path.join(process.cwd(), 'src')
const PAGES = path.join(ROOT, 'app/[locale]/events/[eventId]')
const SIDEBAR = path.join(ROOT, 'components/layout/Sidebar.tsx')

// route folder -> the nav key that points at it
// The assistant is deliberately absent: it is a conversation screen, and its
// <h1> is a centred greeting in the empty state rather than a page header.
// Forcing a left-aligned title bar onto it would be worse, not more uniform.
const ROUTES = {
  dashboard: 'dashboard',
  'master-list': 'masterList',
  sources: 'sources',
  'registration-form': 'registrationForm',
  participants: 'participants',
  flights: 'flights',
  hotels: 'hotels',
  rooming: 'rooming',
  activities: 'activities',
  transfers: 'transfers',
  communications: 'communications',
  exceptions: 'exceptions',
  'match-review': 'matchReview',
  history: 'history',
  reports: 'reports',
}

const sidebar = fs.readFileSync(SIDEBAR, 'utf8')
const navIcon = {}
for (const m of sidebar.matchAll(/\{\s*key:\s*'([^']+)'[^}]*?icon:\s*([A-Za-z0-9]+)/g)) {
  navIcon[m[1]] = m[2]
}

const problems = []

for (const [folder, key] of Object.entries(ROUTES)) {
  const file = path.join(PAGES, folder, 'page.tsx')
  if (!fs.existsSync(file)) continue
  const src = fs.readFileSync(file, 'utf8')

  const h1 = src.match(/<h1[^>]*className="([^"]*)"[^>]*>([\s\S]{0,300}?)<\/h1>/)
  if (!h1) {
    problems.push(`${folder}: pas de <h1>`)
    continue
  }
  const [, classes, inner] = h1

  if (!/font-bold/.test(classes)) {
    problems.push(`${folder}: le titre n'est pas font-bold`)
  }
  if (!/flex items-center gap-2/.test(classes)) {
    problems.push(`${folder}: le titre n'aligne pas son icône (flex items-center gap-2)`)
  }

  const icon = inner.match(/<([A-Z][A-Za-z0-9]*)\s+className="h-6 w-6 text-\[var\(--color-accent\)\]"/)
  if (!icon) {
    problems.push(`${folder}: pas d'icône h-6 w-6 en couleur d'accent`)
  } else if (navIcon[key] && icon[1] !== navIcon[key]) {
    problems.push(
      `${folder}: icône ${icon[1]} sur la page, ${navIcon[key]} dans la navigation`
    )
  }

  // The top bar must not repeat what the page already says.
  if (/pageTitle=/.test(src)) {
    problems.push(`${folder}: pageTitle en double avec le <h1> de la page`)
  }
}

// The same rule, one level down: where a page carries its own `title`
// message, it must say exactly what the navigation entry that leads to it
// says — in every language. French was aligned by hand; Dutch drifted on four
// pages ("Accommodatiebeheer" in the sidebar, "Beheer van de accommodaties"
// on the page) and English on one, because a translation is written per key
// and nothing compared the two.
const LOCALES = ['fr', 'nl', 'en']
// The nav key IS the namespace for every page: `master-list` -> `masterList`.
const TITLED = [...new Set([...Object.values(ROUTES), 'settings', 'assistant'])]
for (const locale of LOCALES) {
  const dict = JSON.parse(
    fs.readFileSync(path.join(ROOT, 'messages', `${locale}.json`), 'utf8')
  )
  for (const navKey of TITLED) {
    const ns = navKey
    const pageTitle = dict[ns]?.title
    const navName = dict.nav?.[navKey]
    if (pageTitle && navName && pageTitle !== navName) {
      problems.push(
        `${locale} : la navigation dit « ${navName} », la page « ${pageTitle} »`
      )
    }
  }
}

if (problems.length) {
  console.error(`en-têtes : ${problems.length} problème(s)\n`)
  for (const p of problems) console.error(`  ${p}`)
  process.exit(1)
}
console.log(
  `en-têtes OK — ${Object.keys(ROUTES).length} pages, titre et icône alignés sur la navigation, ` +
  `dans ${LOCALES.length} langues`
)
