/**
 * check-countries — the nationality column stays one language, losslessly.
 *
 * The registration form writes the `en` name from `lib/countries.ts` and
 * nothing else. That matters more than it looks: the assistant answers
 * "combien viennent d'Europe" by reading the DISTINCT values of that column
 * — it is shown the values that actually occur so it cannot invent one — so
 * a column holding "Belgique", "België" and "Belgium" offers it three
 * countries where there is one, and a question about Belgians finds a third
 * of them.
 *
 * One country, one stored value, therefore. That holds only while the table
 * holds: two rows sharing an English name, a row that lost its `en`, an ISO
 * code ICU stops knowing — each turns a lookup into a silent pass-through,
 * and the column starts splitting again with nothing failing anywhere.
 *
 * This imports the real module (Node strips the types) and walks all 175
 * rows through both directions, in all three languages.
 *
 *   node scripts/check-countries.mjs
 */
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { pathToFileURL } from 'node:url'

const ROOT = join(fileURLToPath(new URL('.', import.meta.url)), '..')
const { COUNTRIES, countryLabel, toEnglishCountry, displayCountry, suggestCountries } =
  await import(pathToFileURL(join(ROOT, 'src/lib/countries.ts')).href)

const problems = []
let assertions = 0
const check = (ok, message) => {
  assertions++
  if (!ok) problems.push(message)
}

const strip = (s) => (s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()

const seenEnglish = new Map()
const seenIso = new Map()

for (const country of COUNTRIES) {
  const { name: fr, en, iso2 } = country
  const nl = countryLabel(country, 'nl')

  check(Boolean(en), `${iso2} : pas de nom anglais dans la table`)
  check(Boolean(nl), `${iso2} : pas de nom néerlandais`)

  // One country, one English name — the whole point of the column.
  if (seenEnglish.has(en)) {
    problems.push(`« ${en} » est le nom anglais de ${seenEnglish.get(en)} ET de ${iso2}`)
  }
  seenEnglish.set(en, iso2)
  if (seenIso.has(iso2)) problems.push(`code ${iso2} en double`)
  seenIso.set(iso2, en)

  // Typed in any of the three languages, or as its code -> one stored value.
  for (const [lang, typed] of [['fr', fr], ['en', en], ['nl', nl], ['iso', iso2]]) {
    check(
      toEnglishCountry(typed) === en,
      `${iso2} : « ${typed} » (${lang}) donne ${toEnglishCountry(typed)}, attendu ${en}`
    )
  }
  // Case and accents must not decide.
  check(toEnglishCountry(fr.toUpperCase()) === en, `${iso2} : « ${fr.toUpperCase()} » non reconnu`)
  check(toEnglishCountry(strip(fr)) === en, `${iso2} : « ${strip(fr)} » non reconnu`)
  check(toEnglishCountry(`  ${fr}  `) === en, `${iso2} : espaces autour du nom non tolérées`)

  // What is stored reads back in the reader's language — and what an English
  // reader sees is exactly what is in the column, not ICU's variant of it.
  check(displayCountry(en, 'fr') === fr, `${iso2} : ${en} s'affiche « ${displayCountry(en, 'fr')} » en fr`)
  check(displayCountry(en, 'nl') === nl, `${iso2} : ${en} s'affiche mal en nl`)
  check(displayCountry(en, 'en') === en, `${iso2} : ${en} ne se relit pas identique en en`)

  // And so do the rows written in French before this change, which is why the
  // screen reads correctly with or without a migration of the old data.
  check(displayCountry(fr, 'fr') === fr, `${iso2} : ancienne ligne « ${fr} » ne se relit pas`)
  check(displayCountry(fr, 'en') === en, `${iso2} : ancienne ligne « ${fr} » ne devient pas ${en}`)
  check(displayCountry(fr, 'nl') === nl, `${iso2} : ancienne ligne « ${fr} » ne se relit pas en nl`)
}

// Anything the table does not know is passed through, never dropped: a
// nationality it has never heard of is worth storing verbatim.
for (const unknown of ['Kosovar', 'Franco-belge', 'double nationalité', 'zzz']) {
  check(toEnglishCountry(unknown) === null, `« ${unknown} » ne devrait correspondre à aucun pays`)
  check(displayCountry(unknown, 'fr') === unknown, `« ${unknown} » devrait s'afficher tel quel`)
}
for (const empty of ['', null, undefined]) {
  check(toEnglishCountry(empty) === null, `${JSON.stringify(empty)} ne devrait correspondre à rien`)
  check(displayCountry(empty, 'fr') === '', `${JSON.stringify(empty)} devrait s'afficher vide`)
}

// The autocomplete has to find the country in the language being read, which
// is what sends a Dutch participant to the right row in the first place.
for (const [lang, typed, iso2] of [
  ['nl', 'Belgie', 'BE'], ['nl', 'Duitsland', 'DE'], ['nl', 'Frankrijk', 'FR'],
  ['en', 'Germany', 'DE'], ['en', 'Netherlands', 'NL'], ['fr', 'Allemagne', 'DE'],
]) {
  const found = suggestCountries(typed, lang)[0]
  check(found?.iso2 === iso2, `« ${typed} » (${lang}) suggère ${found?.iso2 ?? 'rien'}, attendu ${iso2}`)
}

if (problems.length > 0) {
  console.error(`\n${problems.length} problème(s) sur la table des pays :\n`)
  for (const line of problems.slice(0, 40)) console.error('  ' + line)
  if (problems.length > 40) console.error(`  … et ${problems.length - 40} autres`)
  process.exit(1)
}

console.log(
  `pays OK — ${COUNTRIES.length} pays, ${assertions} vérifications, ` +
  `aller-retour sans perte dans 3 langues`
)
