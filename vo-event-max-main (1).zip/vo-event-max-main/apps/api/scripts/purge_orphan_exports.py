#!/usr/bin/env python
"""
purge_orphan_exports.py — remove export files no row points at any more.

Why these exist
---------------
Until 2026-08-18, ``deletion_service.delete_event`` deleted the ``exports``
ROWS and left their objects in Storage: ``_remove_event_storage`` only ever
read ``uploaded_files``. The paths went with the rows, so nothing in the
application could reach the files again — or find them to delete them. A
listing of the bucket on 2026-08-18 turned up 63 such objects, the oldest from
9 July.

The leak itself is fixed. This clears what it already produced.

A master list carries passport numbers, dietary requirements and medical
information, so these are not merely wasted bytes.

Safety
------
Dry run by default: it prints what it would delete and touches nothing. Pass
``--apply`` to actually delete, and only after reading the list.

Two categories are deliberately KEPT:

  * anything still referenced by a row in ``exports`` — that is a live export;
  * anything outside the ``exports/`` prefix.

Role-redacted copies (``…/redacted-{role}-{uuid}/…``) are *included*: they are
never referenced by a row by design, and they hold the same people as the
original.

Usage
-----
    SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... \
        py -3 scripts/purge_orphan_exports.py            # dry run
    ... py -3 scripts/purge_orphan_exports.py --apply    # delete
"""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from supabase import create_client  # noqa: E402

BUCKET = os.getenv("SUPABASE_STORAGE_BUCKET", "event-files")
PREFIX = "exports"
CHUNK = 100


def _client():
    url = os.getenv("SUPABASE_URL")
    key = os.getenv("SUPABASE_SERVICE_ROLE_KEY")
    if not url or not key:
        sys.exit("SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY sont requis.")
    return create_client(url, key)


def _walk(supabase, prefix: str, depth: int = 4) -> list[str]:
    """Every object key below *prefix*. Folder entries have no id; files do."""
    if depth <= 0:
        return []
    try:
        entries = supabase.storage.from_(BUCKET).list(prefix) or []
    except Exception as exc:
        print(f"  ! impossible de lister {prefix}: {exc}")
        return []
    keys: list[str] = []
    for entry in entries:
        name = (entry or {}).get("name")
        if not name:
            continue
        child = f"{prefix}/{name}"
        if entry.get("id"):
            keys.append(child)
        else:
            keys.extend(_walk(supabase, child, depth - 1))
    return keys


def _referenced(supabase) -> set[str]:
    """Storage paths still named by a row, read in pages.

    PostgREST caps a response at ~1000 rows. A partial set here would mark live
    exports as orphans, which is the one mistake this script must not make — so
    it pages rather than trusting a single read.
    """
    paths: set[str] = set()
    page, size = 0, 1000
    while True:
        res = (
            supabase.table("exports")
            .select("storage_path")
            .range(page * size, page * size + size - 1)
            .execute()
        )
        rows = res.data or []
        paths.update(r["storage_path"] for r in rows if r.get("storage_path"))
        if len(rows) < size:
            return paths
        page += 1


def main() -> None:
    apply = "--apply" in sys.argv
    supabase = _client()

    print("Lecture des lignes exports…")
    referenced = _referenced(supabase)
    print(f"  {len(referenced)} export(s) reference(s) en base")

    print(f"Parcours de {BUCKET}/{PREFIX}/ …")
    everything = _walk(supabase, PREFIX)
    print(f"  {len(everything)} objet(s) dans le stockage")

    orphans = sorted(k for k in everything if k not in referenced)
    if not orphans:
        print("\nAucun orphelin. Rien a faire.")
        return

    print(f"\n{len(orphans)} orphelin(s) :")
    for key in orphans:
        print(f"  {key}")

    if not apply:
        print("\nCoup d'essai — rien n'a ete supprime.")
        print("Relancez avec --apply pour supprimer cette liste.")
        return

    print(f"\nSuppression de {len(orphans)} objet(s)…")
    removed = 0
    for i in range(0, len(orphans), CHUNK):
        batch = orphans[i : i + CHUNK]
        try:
            supabase.storage.from_(BUCKET).remove(batch)
            removed += len(batch)
        except Exception as exc:
            print(f"  ! echec sur un lot de {len(batch)}: {exc}")
    print(f"Termine : {removed}/{len(orphans)} supprime(s).")


if __name__ == "__main__":
    main()
