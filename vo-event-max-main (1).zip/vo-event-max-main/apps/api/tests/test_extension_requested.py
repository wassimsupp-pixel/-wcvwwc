"""
Tests for the personal-extension fields reaching a participant (§3).

Four questions have sat in the registration form's field catalogue since an
earlier pass on §3 — "would you like to extend your stay at your own
expense?" and its start date, end date, hotel — fully wired on the form side
and completely inert on the other end: no participants column existed to
hold an answer, so every reply was silently dropped during consolidation.

These tests cover the two links that were missing: the consolidation
whitelist (so an answer that reaches source_records actually lands on the
participant row), and the participant-detail endpoint's degradation (so a
deployment without migration 022 keeps working rather than 500ing).
"""

from routers.participants import _extension_fields
from services.consolidation_service import _PARTICIPANT_WRITABLE_FIELDS


class TestTheWhitelist:

    def test_all_four_extension_fields_are_writable(self):
        for field in (
            "extension_requested", "extension_start",
            "extension_end", "extension_hotel",
        ):
            assert field in _PARTICIPANT_WRITABLE_FIELDS


class _Query:
    def __init__(self, row, fail=False):
        self.row = row
        self.fail = fail

    def select(self, *_a, **_k):
        return self

    def eq(self, *_a, **_k):
        return self

    def maybe_single(self):
        return self

    def execute(self):
        if self.fail:
            raise RuntimeError('column "extension_requested" does not exist')
        return type("Res", (), {"data": self.row})()


class FakeSupabase:
    def __init__(self, row=None, fail=False):
        self.row = row
        self.fail = fail

    def table(self, _name):
        return _Query(self.row, self.fail)


class TestExtensionFieldsDegradeGracefully:

    def test_the_four_fields_come_back_when_present(self):
        row = {
            "extension_requested": "Oui, je reste 3 jours de plus",
            "extension_start": "2026-09-08",
            "extension_end": "2026-09-11",
            "extension_hotel": "Même hôtel",
        }
        assert _extension_fields("p-1", FakeSupabase(row)) == row

    def test_a_participant_who_never_asked_gets_an_empty_dict(self):
        assert _extension_fields("p-1", FakeSupabase(row=None)) == {}

    def test_missing_migration_022_is_a_no_op_not_a_500(self):
        # This is the exact failure this function exists to prevent:
        # PostgREST fails the WHOLE select when one column is absent, and the
        # participant detail endpoint must keep working regardless.
        assert _extension_fields("p-1", FakeSupabase(fail=True)) == {}
