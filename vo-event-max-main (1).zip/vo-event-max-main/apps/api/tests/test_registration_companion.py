"""
Tests for registering two people in one submission (§9).

Today a couple registers twice, each writes the other's name into a free-text
box, and the pairing step (§4) has to resolve two claims into one fact. When
they arrive in the same submission we already KNOW, and the interesting
question is what the second person inherits rather than retypes.

The rule underneath: a companion is a participant, not a note on somebody
else's fiche. They get their own row, their own flight, their own dietary
requirement — and the consolidation engine then treats them like anybody else.
"""

import pytest

from models.schemas import PublicRegistrationSubmit, RegistrationCompanion
from routers.public_registration import _companion_row, _INHERITED


def _main(**over):
    base = {
        "first_name": "Tina", "last_name": "Fey", "email": "tina@example.com",
        "company": "LivaNova", "city": "Bruxelles", "country": "BE",
        "arrival_flight": "SN2145", "arrival_date": "2027-03-01",
        "room_type": "twin",
    }
    base.update(over)
    return base


def _submit(companion=None, **over):
    payload = {
        "first_name": "Tina", "last_name": "Fey", "email": "tina@example.com",
        "consent": True,
    }
    payload.update(over)
    if companion is not None:
        payload["companion"] = companion
    return PublicRegistrationSubmit(**payload)


class TestNoCompanion:

    def test_a_submission_without_one_produces_no_second_row(self):
        assert _companion_row(_submit(), _main()) is None

    def test_a_companion_with_no_name_is_refused_by_the_model(self):
        with pytest.raises(Exception):
            _submit(companion={"first_name": "", "last_name": "Knope"})


class TestTheSecondPersonIsAParticipant:

    def _row(self, **companion):
        base = {"first_name": "Leslie", "last_name": "Knope"}
        base.update(companion)
        return _companion_row(_submit(companion=base), _main())

    def test_they_get_their_own_row_with_their_own_name(self):
        row = self._row()
        assert row["first_name"] == "Leslie"
        assert row["last_name"] == "Knope"

    def test_their_own_answers_are_kept(self):
        row = self._row(dietary_requirements="Vegan", pmr_needs="Accès fauteuil")
        assert row["dietary_requirements"] == "Vegan"
        assert row["pmr_needs"] == "Accès fauteuil"

    def test_they_may_have_no_email_of_their_own(self):
        # A spouse frequently has no professional address, and refusing the
        # registration over it sends the pair back to email.
        assert "email" not in self._row()

    def test_the_row_records_that_it_arrived_attached_to_somebody(self):
        assert self._row()["registered_with"] == "Tina Fey"

    def test_the_shares_room_flag_itself_is_not_stored_as_data(self):
        assert "shares_room" not in self._row()


class TestWhatIsInheritedRatherThanRetyped:
    """Asking somebody to enter their own company again for their spouse is how
    a form gets abandoned halfway."""

    def _row(self, **companion):
        base = {"first_name": "Leslie", "last_name": "Knope"}
        base.update(companion)
        return _companion_row(_submit(companion=base), _main())

    @pytest.mark.parametrize("field,expected", [
        ("company", "LivaNova"),
        ("city", "Bruxelles"),
        ("country", "BE"),
        ("arrival_flight", "SN2145"),
        ("arrival_date", "2027-03-01"),
    ])
    def test_trip_and_household_facts_are_inherited(self, field, expected):
        assert self._row()[field] == expected

    def test_an_answer_they_gave_themselves_wins_over_the_inherited_one(self):
        # Everything inherited is a default, never an override: a companion who
        # flies in separately said so, and we must not overwrite it.
        row = _companion_row(
            _submit(companion={
                "first_name": "Leslie", "last_name": "Knope",
                "nationality": "US",
            }),
            _main(nationality="BE"),
        )
        assert row["nationality"] == "US"

    def test_only_shared_facts_are_inherited_never_personal_ones(self):
        # A passport number or a dietary requirement belongs to one person.
        for personal in ("passport_number", "dietary_requirements", "date_of_birth"):
            assert personal not in _INHERITED

    def test_an_absent_field_on_the_main_registrant_is_not_invented(self):
        row = _companion_row(
            _submit(companion={"first_name": "Leslie", "last_name": "Knope"}),
            _main(company=None),
        )
        assert "company" not in row


class TestThePairing:
    """This is the case the feature exists for: today the two register
    separately and the pairing step has to guess."""

    def test_sharing_a_room_names_each_in_the_other_s_box(self):
        main = _main()
        row = _companion_row(
            _submit(companion={"first_name": "Leslie", "last_name": "Knope"}), main
        )
        # Reciprocal by construction, which is exactly what rooming_service
        # needs to link them without treating one side as a mere claim.
        assert row["roommate"] == "Tina Fey"
        assert main["roommate"] == "Leslie Knope"

    def test_the_room_type_is_shared(self):
        main = _main(room_type="double")
        row = _companion_row(
            _submit(companion={"first_name": "Leslie", "last_name": "Knope"}), main
        )
        assert row["room_type"] == "double"

    def test_a_twin_is_assumed_when_nobody_said_otherwise(self):
        main = _main(room_type=None)
        row = _companion_row(
            _submit(companion={"first_name": "Leslie", "last_name": "Knope"}), main
        )
        assert row["room_type"] == "twin"
        assert main["room_type"] == "twin"

    def test_two_people_who_want_separate_rooms_are_not_paired(self):
        main = _main()
        row = _companion_row(
            _submit(companion={
                "first_name": "Leslie", "last_name": "Knope", "shares_room": False,
            }),
            main,
        )
        assert "roommate" not in row
        assert "roommate" not in main
