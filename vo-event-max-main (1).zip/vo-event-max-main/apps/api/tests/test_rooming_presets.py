"""
Tests for staff-managed rooming-list numbering presets (point 4).

Generating a rooming list already accepted a starting number and a prefix per
call. What was missing was memory: a collaborator retyped "start at 301,
prefix B-" every single visit because nothing remembered it. A preset is that
pair, named and saved — nothing the planner did not already accept.
"""

from services import rooming_plan as R


def _preset(**over):
    base = {"id": "", "name": "Hôtel B", "start_number": 301, "prefix": "B-"}
    base.update(over)
    return base


class TestResolvingWhatIsStored:

    def test_nothing_saved_yet_is_an_empty_list(self):
        assert R.resolve_presets(None) == []
        assert R.resolve_presets([]) == []

    def test_a_malformed_container_is_survivable(self):
        for stored in (None, "", {}, 42, "presets"):
            assert R.resolve_presets(stored) == []

    def test_a_valid_preset_is_kept(self):
        got = R.resolve_presets([_preset()])
        assert len(got) == 1
        assert got[0]["name"] == "Hôtel B"
        assert got[0]["start_number"] == 301
        assert got[0]["prefix"] == "B-"

    def test_an_id_is_assigned_when_none_was_given(self):
        got = R.resolve_presets([_preset(id="")])
        assert got[0]["id"]

    def test_a_given_id_is_kept(self):
        got = R.resolve_presets([_preset(id="abc123")])
        assert got[0]["id"] == "abc123"

    def test_two_presets_never_collide_on_id(self):
        got = R.resolve_presets([_preset(id="dup"), _preset(id="dup", name="Autre")])
        assert got[0]["id"] != got[1]["id"]


class TestAnUnusablePresetIsDroppedNotFatal:
    """One bad entry — typed by hand in a console, say — must not take down
    every other saved preset."""

    def test_a_nameless_preset_is_dropped(self):
        assert R.resolve_presets([_preset(name="")]) == []
        assert R.resolve_presets([_preset(name="   ")]) == []

    def test_an_impossible_start_number_is_dropped(self):
        for bad in (-1, 100000, "cent", None):
            assert R.resolve_presets([_preset(start_number=bad)]) == []

    def test_one_bad_entry_does_not_sink_the_others(self):
        got = R.resolve_presets([_preset(name=""), _preset(name="Bon")])
        assert len(got) == 1
        assert got[0]["name"] == "Bon"

    def test_a_non_dict_entry_is_skipped(self):
        got = R.resolve_presets(["not a dict", _preset()])
        assert len(got) == 1


class TestFieldsAreBounded:

    def test_the_name_is_truncated_rather_than_rejected(self):
        got = R.resolve_presets([_preset(name="x" * 500)])
        assert len(got[0]["name"]) <= 60

    def test_the_prefix_is_truncated(self):
        got = R.resolve_presets([_preset(prefix="B" * 500)])
        assert len(got[0]["prefix"]) <= 8

    def test_no_prefix_is_a_valid_preset(self):
        got = R.resolve_presets([_preset(prefix="")])
        assert got[0]["prefix"] == ""

    def test_the_list_itself_is_capped(self):
        got = R.resolve_presets([_preset(name=f"P{i}") for i in range(200)])
        assert len(got) == R.MAX_PRESETS
