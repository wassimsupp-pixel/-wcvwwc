"""
Tests for who a campaign addresses.

The individual letter and the send to everybody are the same operation with a
different audience, so they share one code path. That sharing is what needs
guarding: an off-by-one in the filter does not fail loudly, it writes to four
hundred people when one was meant. Every test here answers the same question —
did exactly the intended recipients get a message?
"""

import asyncio
from typing import Any

import pytest

from services import campaign_service


ROWS = [
    {"id": "p1", "first_name": "Tina", "last_name": "Ardis", "email": "tina@x.com"},
    {"id": "p2", "first_name": "Leslie", "last_name": "Moore", "email": "leslie@x.com"},
    {"id": "p3", "first_name": "Darren", "last_name": "McCarthy", "email": "darren@x.com"},
    # No address: written for, never sent to.
    {"id": "p4", "first_name": "Sans", "last_name": "Mail", "email": ""},
]


class FakeDB:
    """Just enough Supabase to answer the two questions the service asks:
    the event's name, and (never, here) its throttle override."""

    def __init__(self) -> None:
        self.inserted: list[dict[str, Any]] = []

    def table(self, name: str) -> "FakeDB":
        self._table = name
        return self

    def select(self, *_a, **_k) -> "FakeDB":
        return self

    def eq(self, *_a, **_k) -> "FakeDB":
        return self

    def maybe_single(self) -> "FakeDB":
        return self

    def single(self) -> "FakeDB":
        return self

    def insert(self, payload) -> "FakeDB":
        self.inserted.extend(payload if isinstance(payload, list) else [payload])
        return self

    def execute(self):
        class R:
            pass

        r = R()
        if self._table == "events":
            r.data = {"name": "Athens 2026"}
        else:
            r.data = []
        return r


@pytest.fixture(autouse=True)
def _fixed_master_list(monkeypatch):
    monkeypatch.setattr(
        campaign_service.master_list_service,
        "build_master_rows",
        lambda supabase, event_id: [dict(r) for r in ROWS],
    )


def _send(db, participant_ids, do_send=False):
    return asyncio.run(
        campaign_service.run_campaign(
            db, "ev1", "template", "Objet {event_name}", "Bonjour {first_name}",
            "", do_send, "user1", participant_ids=participant_ids,
        )
    )


class TestPreview:

    def test_no_target_means_everybody_with_an_address(self):
        out = campaign_service.preview(FakeDB(), "ev1", "template", "S", "B", "")
        assert out["recipient_count"] == 3
        assert out["without_email"] == 1

    def test_naming_one_participant_narrows_to_that_one(self):
        out = campaign_service.preview(
            FakeDB(), "ev1", "template", "S", "Bonjour {first_name}", "",
            participant_ids=["p3"],
        )
        assert out["recipient_count"] == 1
        assert out["samples"][0]["to"] == "darren@x.com"
        assert out["samples"][0]["body"] == "Bonjour Darren"

    def test_a_participant_without_an_address_counts_as_nobody(self):
        # The card reads recipient_count == 0 to say "pas d'adresse dans sa
        # fiche" BEFORE the send, rather than reporting a silent 0 after it.
        out = campaign_service.preview(
            FakeDB(), "ev1", "template", "S", "B", "", participant_ids=["p4"]
        )
        assert out["recipient_count"] == 0
        assert out["without_email"] == 1

    def test_an_unknown_id_reaches_nobody_rather_than_everybody(self):
        # The dangerous failure: a filter that matches nothing falling back to
        # "no filter" and mailing the whole event.
        out = campaign_service.preview(
            FakeDB(), "ev1", "template", "S", "B", "", participant_ids=["ghost"]
        )
        assert out["recipient_count"] == 0


class TestRun:

    def test_an_untargeted_run_writes_to_every_addressable_participant(self):
        db = FakeDB()
        res = _send(db, participant_ids=[])
        assert res["generated"] == 3
        assert res["skipped_no_email"] == 1
        assert {r["participant_id"] for r in db.inserted} == {"p1", "p2", "p3"}

    def test_a_targeted_run_writes_one_row_only(self):
        db = FakeDB()
        res = _send(db, participant_ids=["p2"])
        assert res["generated"] == 1
        assert [r["participant_id"] for r in db.inserted] == ["p2"]
        assert db.inserted[0]["subject"] == "Objet Athens 2026"
        assert db.inserted[0]["body"] == "Bonjour Leslie"

    def test_the_two_kinds_are_tracked_apart(self):
        # "Was this person written to personally?" is a question the history
        # gets asked, and one shared label cannot answer it.
        individual = FakeDB()
        _send(individual, participant_ids=["p1"])
        assert individual.inserted[0]["type"] == "individual"

        mass = FakeDB()
        _send(mass, participant_ids=[])
        assert {r["type"] for r in mass.inserted} == {"campaign"}

    def test_nothing_is_delivered_without_a_connected_mailbox(self, monkeypatch):
        monkeypatch.setattr(
            campaign_service.mail_connection_service, "connected_provider",
            lambda event_id: None,
        )
        db = FakeDB()
        res = _send(db, participant_ids=["p1"], do_send=True)
        assert res["sent"] == 0
        assert res["delivered"] is False
        # Still stored, so it can go out once a mailbox is connected.
        assert db.inserted[0]["status"] == "ready"

    def test_a_targeted_send_reaches_that_address_and_no_other(self, monkeypatch):
        outbox: list[tuple[str, str, str]] = []
        monkeypatch.setattr(
            campaign_service.mail_connection_service, "connected_provider",
            lambda event_id: "outlook",
        )
        monkeypatch.setattr(
            campaign_service.mail_connection_service, "send_email",
            lambda provider, event_id, to, subj, body: outbox.append((to, subj, body)),
        )
        db = FakeDB()
        res = _send(db, participant_ids=["p3"], do_send=True)
        assert res["sent"] == 1
        assert [to for to, _, _ in outbox] == ["darren@x.com"]
        assert db.inserted[0]["status"] == "sent"
        assert db.inserted[0]["sent_at"]
