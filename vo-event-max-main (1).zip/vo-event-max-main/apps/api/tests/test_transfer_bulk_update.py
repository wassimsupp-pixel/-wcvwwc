"""
Tests for "Appliquer à tous les groupes" and for who ends up flagged as having
a transfer.

Two failures live here, and both are the quiet kind.

**The bulk edit was a loop.** The browser fired one PATCH per transfer, in
parallel. On a few hundred people that is a few hundred access checks and a
few hundred writes, and `Promise.all` abandons the batch on the FIRST
rejection while the rest keep going — so the organizer sees some rows changed,
some not, and nothing saying which. One request replaces it.

**`apply` flagged people it had not booked.** A group with no flight time is
reported back as skipped — "à planifier à la main" — and yet everybody in the
payload was marked `has_transfer = True`. Those people then disappeared from
the "Sans transfert" list, which is the one list whose entire job was to
notice them.
"""

from unittest.mock import AsyncMock, patch

import pytest
from fastapi import HTTPException

from models.schemas import TransferBulkUpdate, TransferPlanApply
from routers.transfers import apply_transfers, bulk_update_transfers


EVENT_ID = "22222222-2222-2222-2222-222222222222"
OTHER_EVENT = "99999999-9999-9999-9999-999999999999"


def tid(n: int) -> str:
    return f"1111111{n}-1111-1111-1111-111111111111"


def pid(n: int) -> str:
    return f"3333333{n}-3333-3333-3333-333333333333"


class _Query:
    def __init__(self, table, name):
        self.t = table
        self.name = name
        self.rows = list(table.rows)
        self._filters = {}

    def select(self, *_a, **_k):
        return self

    def eq(self, col, val):
        self.rows = [r for r in self.rows if str(r.get(col)) == str(val)]
        self._filters[col] = str(val)
        return self

    def in_(self, col, values):
        wanted = {str(v) for v in values}
        self.rows = [r for r in self.rows if str(r.get(col)) in wanted]
        return self

    def update(self, payload):
        # Recorded now, applied at execute(): .update() comes BEFORE .eq()/.in_()
        # in the chain, and PostgREST applies those filters server-side. A fake
        # that wrote immediately would report every row as touched and hide
        # exactly the scoping bug these tests exist to catch.
        self._pending_update = payload
        return self

    def insert(self, payload):
        self.t.inserted.append(payload)
        self.t.rows.append(dict(payload, id=tid(len(self.t.rows) + 1)))
        return self

    def delete(self):
        # Same contract as update(): recorded here, applied at execute(), so
        # the filters that follow in the chain really do scope it.
        self._pending_delete = True
        return self

    def execute(self):
        payload = getattr(self, "_pending_update", None)
        if payload is not None:
            self.t.updates.append((self.name, payload, [r["id"] for r in self.rows]))
            for row in self.rows:
                row.update(payload)
        if getattr(self, "_pending_delete", False):
            doomed = {id(r) for r in self.rows}
            self.t.deleted.extend(self.rows)
            self.t.rows[:] = [r for r in self.t.rows if id(r) not in doomed]
        return type("Res", (), {"data": self.rows})()


class _Table:
    def __init__(self, rows):
        self.rows = rows
        self.updates = []
        self.inserted = []
        self.deleted = []


class FakeSupabase:
    def __init__(self, transfers=(), participants=()):
        self.tables = {
            "transfers": _Table([dict(r) for r in transfers]),
            "participants": _Table([dict(r) for r in participants]),
        }

    def table(self, name):
        return _Query(self.tables.setdefault(name, _Table([])), name)


def _transfer(n, event=EVENT_ID, **over):
    base = {
        "id": tid(n), "event_id": event, "participant_id": pid(n),
        "transfer_type": "arrival", "pickup_location": "BRU",
        "dropoff_location": "Hôtel", "pickup_time": "2026-08-29T15:00:00",
        "vehicle_type": "Taxi", "status": "scheduled",
    }
    base.update(over)
    return base


@pytest.mark.asyncio
@patch("routers.transfers.verify_event_access", new_callable=AsyncMock)
@patch("routers.transfers.log_change")
class TestApplyingOneEditToMany:

    async def test_every_named_transfer_is_changed(self, _log, _verify):
        sb = FakeSupabase([_transfer(1), _transfer(2), _transfer(3)])
        body = TransferBulkUpdate(
            transfer_ids=[tid(1), tid(2), tid(3)], patch={"vehicle_type": "Minibus"}
        )
        out = await bulk_update_transfers(EVENT_ID, body, {"id": "u-1"}, sb)
        assert out["updated"] == 3
        assert {r["vehicle_type"] for r in sb.tables["transfers"].rows} == {"Minibus"}

    async def test_it_takes_a_single_write_not_one_per_row(self, _log, _verify):
        # The whole point: a hundred rows must not become a hundred requests.
        sb = FakeSupabase([_transfer(n) for n in range(1, 6)])
        body = TransferBulkUpdate(
            transfer_ids=[tid(n) for n in range(1, 6)], patch={"vehicle_type": "Bus"}
        )
        await bulk_update_transfers(EVENT_ID, body, {"id": "u-1"}, sb)
        transfer_writes = [u for u in sb.tables["transfers"].updates]
        assert len(transfer_writes) == 1

    async def test_a_transfer_from_another_event_is_refused_not_edited(self, _log, _verify):
        # The ids come from a browser. One belonging to another event must not
        # be editable through this door, and must be reported rather than
        # silently dropped.
        sb = FakeSupabase([_transfer(1), _transfer(2, event=OTHER_EVENT)])
        body = TransferBulkUpdate(
            transfer_ids=[tid(1), tid(2)], patch={"vehicle_type": "Van"}
        )
        out = await bulk_update_transfers(EVENT_ID, body, {"id": "u-1"}, sb)
        assert out["updated"] == 1
        assert out["skipped"] == [tid(2)]
        assert sb.tables["transfers"].rows[1]["vehicle_type"] == "Taxi"

    async def test_an_empty_field_is_never_written(self, _log, _verify):
        # "Les champs vides ne sont pas modifiés" is the control's own promise.
        sb = FakeSupabase([_transfer(1)])
        body = TransferBulkUpdate(transfer_ids=[tid(1)], patch={"vehicle_type": "Van"})
        await bulk_update_transfers(EVENT_ID, body, {"id": "u-1"}, sb)
        _, payload, _ = sb.tables["transfers"].updates[0]
        assert payload == {"vehicle_type": "Van"}

    async def test_nothing_to_change_writes_nothing(self, _log, _verify):
        sb = FakeSupabase([_transfer(1)])
        body = TransferBulkUpdate(transfer_ids=[tid(1)], patch={})
        out = await bulk_update_transfers(EVENT_ID, body, {"id": "u-1"}, sb)
        assert out["updated"] == 0
        assert sb.tables["transfers"].updates == []

    async def test_an_empty_id_list_is_a_no_op_not_an_everything_update(self, _log, _verify):
        # The dangerous shape: an UPDATE with no id filter would rewrite the
        # whole event.
        sb = FakeSupabase([_transfer(1), _transfer(2)])
        body = TransferBulkUpdate(transfer_ids=[], patch={"vehicle_type": "Bus"})
        out = await bulk_update_transfers(EVENT_ID, body, {"id": "u-1"}, sb)
        assert out["updated"] == 0
        assert sb.tables["transfers"].updates == []
        assert {r["vehicle_type"] for r in sb.tables["transfers"].rows} == {"Taxi"}

    @pytest.mark.parametrize("bad", ["Arrivée", "shuttle", "ARRIVAL"])
    async def test_a_bogus_direction_is_refused_for_the_whole_batch(self, _log, _verify, bad):
        sb = FakeSupabase([_transfer(1), _transfer(2)])
        body = TransferBulkUpdate(transfer_ids=[tid(1), tid(2)], patch={"transfer_type": bad})
        with pytest.raises(HTTPException) as raised:
            await bulk_update_transfers(EVENT_ID, body, {"id": "u-1"}, sb)
        assert raised.value.status_code == 422
        assert sb.tables["transfers"].updates == []


@pytest.mark.asyncio
@patch("routers.transfers.verify_event_access", new_callable=AsyncMock)
class TestOnlyBookedPeopleReadAsBooked:

    async def test_a_group_with_no_time_leaves_its_people_unflagged(self, _verify):
        # The group the planner itself reports as "à planifier à la main".
        # Flagging them hid them from the "Sans transfert" list.
        sb = FakeSupabase(participants=[{"id": pid(1)}, {"id": pid(2)}])
        body = TransferPlanApply(groups=[
            {"direction": "arrival", "pickup_time": "2026-08-29T15:00:00",
             "pickup_location": "BRU", "dropoff_location": "Hôtel",
             "flight_numbers": [], "participant_ids": [pid(1)],
             "passengers": 1, "vehicle": None, "sequence": 1},
            {"direction": "departure", "pickup_time": None,
             "pickup_location": "Hôtel", "dropoff_location": "BRU",
             "flight_numbers": [], "participant_ids": [pid(2)],
             "passengers": 1, "vehicle": None, "sequence": 1},
        ])
        out = await apply_transfers(EVENT_ID, body, {"id": "u-1"}, sb)
        assert out["written"] == 1
        assert out["skipped"] == 1

        flagged = [ids for name, payload, ids in sb.tables["participants"].updates
                   if payload.get("has_transfer") is True]
        assert flagged, "personne n'a été marquée alors qu'un transfert a été écrit"
        every_flagged = {i for ids in flagged for i in ids}
        assert pid(1) in every_flagged
        assert pid(2) not in every_flagged, "une personne sans horaire a été marquée comme ayant un transfert"


@pytest.mark.asyncio
@patch("routers.transfers.log_change")
@patch("routers.transfers.verify_event_access", new_callable=AsyncMock)
class TestApplyingTwiceBooksOnce:
    """Applying a plan is a REPLACEMENT, not an append.

    This is the normal workflow, not an edge case: the reason to drag somebody
    into another van is to fix a plan and apply it again. Every write in
    ``apply_transfers`` is an insert, so without a clear-out the second apply
    booked all sixty-four people a second time — the master list reads the
    transfers table live and would have shown each of them in two vans at once,
    and the driver sheet would have carried them twice.
    """

    def _plan(self, participant, when="2026-09-01T15:00:00", where="BRU"):
        return TransferPlanApply(groups=[
            {"direction": "arrival", "pickup_time": when,
             "pickup_location": where, "dropoff_location": "Hôtel",
             "flight_numbers": [], "participant_ids": [participant],
             "passengers": 1, "vehicle": None, "sequence": 1},
        ])

    async def test_the_same_plan_applied_twice_leaves_one_transfer(self, _v, _log):
        sb = FakeSupabase(participants=[{"id": pid(1)}])
        await apply_transfers(EVENT_ID, self._plan(pid(1)), {"id": "u-1"}, sb)
        await apply_transfers(EVENT_ID, self._plan(pid(1)), {"id": "u-1"}, sb)
        assert len(sb.tables["transfers"].rows) == 1

    async def test_moving_someone_replaces_their_booking_rather_than_adding_one(self, _v, _log):
        """The exact gesture: dropped into another van, applied again."""
        sb = FakeSupabase(participants=[{"id": pid(1)}])
        await apply_transfers(EVENT_ID, self._plan(pid(1), "2026-09-01T15:00:00"), {"id": "u-1"}, sb)
        out = await apply_transfers(
            EVENT_ID, self._plan(pid(1), "2026-09-01T18:30:00"), {"id": "u-1"}, sb
        )
        rows = sb.tables["transfers"].rows
        assert len(rows) == 1, "la personne est dans deux navettes à la fois"
        assert rows[0]["pickup_time"] == "2026-09-01T18:30:00"
        assert out["replaced"] == 1

    async def test_the_other_direction_is_left_alone(self, _v, _log):
        """Re-applying the arrivals must not cancel anybody's departure."""
        sb = FakeSupabase(
            transfers=[{"id": tid(9), "event_id": EVENT_ID, "participant_id": pid(1),
                        "transfer_type": "departure", "pickup_time": "2026-09-05T06:00:00"}],
            participants=[{"id": pid(1)}],
        )
        await apply_transfers(EVENT_ID, self._plan(pid(1)), {"id": "u-1"}, sb)
        kinds = sorted(r["transfer_type"] for r in sb.tables["transfers"].rows)
        assert kinds == ["arrival", "departure"]

    async def test_somebody_the_plan_does_not_mention_keeps_their_transfer(self, _v, _log):
        """A transfer typed in by hand for a person outside this plan is not
        ours to remove."""
        sb = FakeSupabase(
            transfers=[{"id": tid(9), "event_id": EVENT_ID, "participant_id": pid(2),
                        "transfer_type": "arrival", "pickup_time": "2026-09-01T09:00:00"}],
            participants=[{"id": pid(1)}, {"id": pid(2)}],
        )
        await apply_transfers(EVENT_ID, self._plan(pid(1)), {"id": "u-1"}, sb)
        survivors = {r["participant_id"] for r in sb.tables["transfers"].rows}
        assert pid(2) in survivors

    async def test_a_group_with_no_time_clears_nothing(self, _v, _log):
        """It writes nothing, so it must delete nothing either — otherwise
        accepting an unschedulable group would quietly cancel the booking that
        was already there."""
        sb = FakeSupabase(
            transfers=[{"id": tid(9), "event_id": EVENT_ID, "participant_id": pid(1),
                        "transfer_type": "arrival", "pickup_time": "2026-09-01T09:00:00"}],
            participants=[{"id": pid(1)}],
        )
        body = TransferPlanApply(groups=[
            {"direction": "arrival", "pickup_time": None,
             "pickup_location": "BRU", "dropoff_location": "Hôtel",
             "flight_numbers": [], "participant_ids": [pid(1)],
             "passengers": 1, "vehicle": None, "sequence": 1},
        ])
        out = await apply_transfers(EVENT_ID, body, {"id": "u-1"}, sb)
        assert out["written"] == 0
        assert len(sb.tables["transfers"].rows) == 1
