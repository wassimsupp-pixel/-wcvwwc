"""
Tests for pacing a mass send (§15).

The feedback names the failure directly: "il faudra gérer intelligemment
l'envoi de masse pour éviter que Outlook considère 200 mails envoyés
simultanément comme du spam."

What makes this worth testing rather than eyeballing is that the failure is
invisible at the moment it happens. Exchange Online does not bounce a burst; it
notes it, and the tenant's mail starts landing in Junk days later, long after
the campaign that caused it. So the pacing is a plan computed BEFORE anything
leaves, and these tests assert the plan.
"""

import pytest

from services import mail_throttle as T


class TestRates:

    def test_outlook_is_paced_below_what_exchange_enforces(self):
        # Exchange Online throttles around 30/minute. Racing the ceiling is how
        # you find it.
        assert T.settings_for("outlook")["per_minute"] < 30

    def test_gmail_gets_its_own_looser_rate(self):
        assert T.settings_for("gmail")["per_minute"] > T.settings_for("outlook")["per_minute"]

    def test_an_unknown_provider_gets_the_cautious_default(self):
        # Guessing high on a mailbox we know nothing about burns a reputation.
        assert T.settings_for("carrier-pigeon") == T.FALLBACK
        assert T.settings_for(None) == T.FALLBACK

    def test_an_event_can_slow_itself_down(self):
        assert T.settings_for("outlook", {"per_minute": 5})["per_minute"] == 5

    @pytest.mark.parametrize("bad", [
        {"per_minute": 0}, {"per_minute": -3}, {"per_minute": 10_000},
        {"per_minute": "vite"}, {"per_minute": True}, {"per_minute": None},
        "not a dict", None, 42,
    ])
    def test_a_malformed_override_falls_back_instead_of_raising(self, bad):
        # A rate of zero would make the sender wait forever on message one.
        rules = T.settings_for("outlook", bad)
        assert rules["per_minute"] == T.DEFAULT_RATES["outlook"]["per_minute"]

    def test_a_batch_never_exceeds_the_minute_it_has_to_last(self):
        # Otherwise the whole minute's quota leaves in one burst, which is the
        # exact shape a throttler notices.
        rules = T.settings_for("outlook", {"per_minute": 5, "batch": 50})
        assert rules["batch"] <= rules["per_minute"]


class TestThePlan:

    def test_it_splits_the_send_into_batches(self):
        schedule = T.plan(200, "outlook")
        assert schedule["batches"] == 20
        assert schedule["batch_size"] == 10

    def test_a_partial_last_batch_still_counts(self):
        assert T.plan(21, "outlook")["batches"] == 3

    def test_the_pause_holds_the_rate(self):
        # 10 per batch at 20/minute is one batch every 30 seconds.
        assert T.plan(200, "outlook")["pause_seconds"] == 30.0

    def test_there_is_no_pause_after_the_last_batch(self):
        # Waiting after the final message delays nothing but the report.
        assert T.plan(10, "outlook")["estimated_seconds"] == 0

    def test_the_duration_is_stated_up_front(self):
        assert T.plan(200, "outlook")["estimated_seconds"] == 570.0

    def test_nobody_to_send_to_is_a_valid_plan(self):
        schedule = T.plan(0, "outlook")
        assert schedule["batches"] == 0
        assert schedule["estimated_seconds"] == 0

    def test_a_negative_total_does_not_produce_nonsense(self):
        assert T.plan(-5, "outlook")["attempted"] == 0


class TestTheDailyCap:
    """An organizer who learns at message 9001 that the rest never went is one
    who has already told a client they were sent."""

    def test_what_will_not_be_attempted_is_reported_up_front(self):
        schedule = T.plan(10_000, "outlook")
        assert schedule["attempted"] == 9000
        assert schedule["deferred"] == 1000

    def test_a_normal_send_defers_nothing(self):
        assert T.plan(200, "outlook")["deferred"] == 0

    def test_the_sentence_names_the_shortfall(self):
        line = T.describe(T.plan(10_000, "outlook"))
        assert "1000" in line and "plafond" in line

    def test_the_sentence_stays_quiet_when_there_is_none(self):
        assert "plafond" not in T.describe(T.plan(200, "outlook"))


class TestBatching:

    def test_it_cuts_the_list_into_chunks(self):
        assert T.batches([1, 2, 3, 4, 5], 2) == [[1, 2], [3, 4], [5]]

    def test_an_empty_list_yields_no_batches(self):
        assert T.batches([], 10) == []

    def test_a_zero_size_does_not_loop_forever(self):
        assert T.batches([1, 2], 0) == [[1], [2]]


class TestTheSentence:

    def test_it_reads_in_french_by_default(self):
        line = T.describe(T.plan(200, "outlook"))
        assert "200 email(s)" in line and "minute" in line

    def test_it_reads_in_english_too(self):
        assert "batches of" in T.describe(T.plan(200, "outlook"), "en")

    def test_a_short_send_is_not_described_as_zero_minutes(self):
        assert "moins d'une minute" in T.describe(T.plan(10, "outlook"))

    def test_no_recipients_says_so(self):
        assert T.describe(T.plan(0, "outlook")) == "Aucun destinataire."
