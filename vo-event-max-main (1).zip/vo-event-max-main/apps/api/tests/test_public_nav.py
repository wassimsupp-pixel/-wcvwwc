"""
Which pages reach the public link's navigation.

A page is reachable when a visitor can get to it from the tabs. Two ways in:
the classic way (a section with text or a photo), and the block way (a page the
organizer composed in blocks, which has no classic body at all — `event_site.render`
drops those, so the payload has to union them back in).

The case that matters most is the third test: compose a page in blocks, make it
visible, and it must appear. That is precisely what "j'affiche une page et elle
n'apparaît pas dans le formulaire" would look like if the union were wrong.
"""

from routers.public_registration import _site_sections


class _Fake:
    """Just enough Supabase to return canned event_site rows."""

    def __init__(self, rows):
        self._rows = rows

    def table(self, *_a, **_k):
        return self

    def select(self, *_a, **_k):
        return self

    def eq(self, *_a, **_k):
        return self

    def order(self, *_a, **_k):
        return self

    def execute(self):
        class R:
            pass

        r = R()
        r.data = self._rows
        return r


def _slugs(sections):
    return [s["slug"] for s in sections]


def _row(slug, *, visible=True, body=None, image=""):
    return {
        "slug": slug,
        "title": {"en": slug.title()},
        "body": body or {},
        "image_url": image,
        "visible": visible,
        "position": 1,
    }


class TestClassicPages:
    def test_a_visible_section_with_text_appears(self):
        rows = [_row("programme", body={"en": "Doors at nine."})]
        assert "programme" in _slugs(_site_sections(_Fake(rows), "e1", "en"))

    def test_a_hidden_section_never_appears(self):
        rows = [_row("programme", visible=False, body={"en": "Doors at nine."})]
        assert _slugs(_site_sections(_Fake(rows), "e1", "en")) == []

    def test_a_visible_but_empty_section_does_not_appear(self):
        # A tab leading to a blank page reads as a page that failed to load.
        rows = [_row("programme")]
        assert _slugs(_site_sections(_Fake(rows), "e1", "en")) == []


class TestBlockPages:
    def test_a_page_composed_in_blocks_appears_even_with_no_classic_body(self):
        rows = [_row("programme")]  # visible, no body, no image
        out = _site_sections(_Fake(rows), "e1", "en", layout_pages=["programme"])
        assert "programme" in _slugs(out)

    def test_a_block_page_with_no_section_row_at_all_still_appears(self):
        # The organizer composed it before the section row existed.
        out = _site_sections(_Fake([]), "e1", "en", layout_pages=["programme"])
        assert "programme" in _slugs(out)

    def test_a_hidden_page_stays_hidden_even_with_blocks(self):
        rows = [_row("programme", visible=False)]
        out = _site_sections(_Fake(rows), "e1", "en", layout_pages=["programme"])
        assert "programme" not in _slugs(out)

    def test_a_block_page_is_not_duplicated_when_it_also_has_a_body(self):
        rows = [_row("programme", body={"en": "Doors at nine."})]
        out = _site_sections(_Fake(rows), "e1", "en", layout_pages=["programme"])
        assert _slugs(out).count("programme") == 1

    def test_an_unknown_slug_is_ignored(self):
        out = _site_sections(_Fake([]), "e1", "en", layout_pages=["not-a-section"])
        assert _slugs(out) == []

    def test_a_block_page_carries_a_title_for_its_tab(self):
        out = _site_sections(_Fake([]), "e1", "en", layout_pages=["programme"])
        assert out[0]["title"]
