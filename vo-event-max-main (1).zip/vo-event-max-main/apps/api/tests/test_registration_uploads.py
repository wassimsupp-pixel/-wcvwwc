"""
Tests for accepting a file from a stranger (§9).

This is the least trusted input the system has: an endpoint that takes a file
from somebody with no account, no session and no prior relationship with us.
Nearly every test below asserts a REFUSAL, which is what an upload validator
mostly is.

The one that matters most is the disagreement case. A .jpg whose bytes say
`<!DOCTYPE html` is not a photo, whatever the browser labelled it — and
checking only the extension is checking the attacker's own claim about their
own file.
"""

import pytest

from services import registration_uploads as U


JPEG = b"\xff\xd8\xff\xe0" + b"\x00" * 200
PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 200
PDF = b"%PDF-1.7\n" + b"0" * 200
HEIC = b"\x00\x00\x00\x18ftypheic" + b"\x00" * 200


# ===========================================================================
# What the bytes actually are
# ===========================================================================

class TestSniffing:

    @pytest.mark.parametrize("content,expected", [
        (JPEG, "jpeg"), (PNG, "png"), (PDF, "pdf"), (HEIC, "heic"),
    ])
    def test_it_recognises_what_we_accept(self, content, expected):
        assert U.sniff(content) == expected

    def test_it_recognises_nothing_in_an_empty_file(self):
        assert U.sniff(b"") == ""

    def test_html_is_not_mistaken_for_an_image(self):
        assert U.sniff(b"<!DOCTYPE html><html>") == ""


class TestTheExtensionMustMatchTheContent:

    def test_html_renamed_to_jpg_is_refused(self):
        # The whole point: the browser's label is the uploader's claim.
        with pytest.raises(U.UploadRefused):
            U.validate(U.PHOTO, "passeport.jpg", b"<!DOCTYPE html><script>x</script>")

    def test_a_pdf_renamed_to_png_is_refused(self):
        with pytest.raises(U.UploadRefused) as err:
            U.validate(U.PHOTO, "photo.png", PDF)
        assert "extension" in str(err.value)

    def test_a_zip_renamed_to_jpg_is_refused(self):
        # A .docx is a zip, and a zip is a thing that unpacks.
        with pytest.raises(U.UploadRefused):
            U.validate(U.PHOTO, "photo.jpg", b"PK\x03\x04" + b"\x00" * 100)

    def test_an_executable_is_refused(self):
        with pytest.raises(U.UploadRefused):
            U.validate(U.PASSPORT, "scan.pdf", b"MZ\x90\x00" + b"\x00" * 100)

    def test_an_svg_is_refused_even_though_it_is_an_image(self):
        # SVG is markup that executes. It is not on any allowlist here, and it
        # is caught on its bytes as well as on its extension.
        with pytest.raises(U.UploadRefused):
            U.validate(U.PHOTO, "photo.png", b"<svg xmlns='http://www.w3.org/2000/svg'>")

    def test_a_genuine_jpeg_is_accepted(self):
        out = U.validate(U.PHOTO, "photo.jpg", JPEG)
        assert out["detected_type"] == "jpeg"
        assert out["content_type"] == "image/jpeg"


class TestWhatEachKindAccepts:

    def test_a_passport_may_be_a_pdf(self):
        assert U.validate(U.PASSPORT, "scan.pdf", PDF)["detected_type"] == "pdf"

    def test_a_photo_may_not_be_a_pdf(self):
        # A "photo" that is a PDF is a misfiled document, and the badge printer
        # will not thank anybody.
        with pytest.raises(U.UploadRefused):
            U.validate(U.PHOTO, "photo.pdf", PDF)

    def test_a_heic_from_a_phone_is_accepted(self):
        assert U.validate(U.PHOTO, "IMG_0042.HEIC", HEIC)["detected_type"] == "heic"

    def test_an_unknown_kind_is_refused(self):
        # An upload field that accepts anything becomes a filing cabinet.
        with pytest.raises(U.UploadRefused):
            U.validate("contract", "x.pdf", PDF)

    @pytest.mark.parametrize("name", ["scan.docx", "scan.zip", "scan.exe", "scan", "scan.svg"])
    def test_formats_outside_the_allowlist_are_refused(self, name):
        with pytest.raises(U.UploadRefused):
            U.validate(U.PASSPORT, name, PDF)


class TestSize:

    def test_an_empty_file_is_refused(self):
        with pytest.raises(U.UploadRefused) as err:
            U.validate(U.PHOTO, "photo.jpg", b"")
        assert "vide" in str(err.value)

    def test_a_file_over_the_cap_is_refused_with_advice(self):
        oversized = JPEG + b"\x00" * U.MAX_BYTES
        with pytest.raises(U.UploadRefused) as err:
            U.validate(U.PHOTO, "photo.jpg", oversized)
        assert "8 Mo" in str(err.value)

    def test_a_normal_scan_fits_comfortably(self):
        assert U.MAX_BYTES >= 5 * 1024 * 1024


# ===========================================================================
# The visitor's filename is a label, never a path
# ===========================================================================

class TestFilenames:

    @pytest.mark.parametrize("name", [
        "../../../etc/passwd.jpg",
        "..\\..\\windows\\system32\\x.jpg",
        "/absolute/path.jpg",
    ])
    def test_a_traversal_attempt_survives_as_a_harmless_label(self, name):
        label = U.safe_label(name)
        assert "/" not in label and "\\" not in label and ".." not in label

    def test_accents_are_folded(self):
        assert U.safe_label("passeport_bénédicte.jpg") == "passeport_benedicte.jpg"

    def test_an_empty_name_still_produces_one(self):
        assert U.safe_label("") == "fichier"

    def test_a_very_long_name_is_bounded(self):
        assert len(U.safe_label("x" * 500 + ".jpg")) <= 100

    def test_the_storage_key_owes_nothing_to_the_visitor(self):
        # Not the directory, not the name, not the extension.
        descriptor = U.validate(U.PHOTO, "../../evil.jpg", JPEG)
        path = U.storage_path("event-1", descriptor)
        assert path.startswith("event-1/registrations/")
        assert "evil" not in path
        assert ".." not in path

    def test_two_uploads_of_the_same_name_do_not_collide(self):
        descriptor = U.validate(U.PHOTO, "photo.jpg", JPEG)
        a = U.storage_path("event-1", descriptor)
        b = U.storage_path("event-1", descriptor)
        assert a != b


class TestTheContentTypeIsOurs:

    def test_the_browsers_claim_is_ignored(self):
        # A client controls the header it sends, and that header decides how
        # anything downstream renders the file.
        out = U.validate(U.PHOTO, "photo.jpg", JPEG, declared_type="text/html")
        assert out["content_type"] == "image/jpeg"


# ===========================================================================
# What the event asks for
# ===========================================================================

class TestWhatIsRequested:

    def _fields(self, **states):
        return [
            {"key": key, "enabled": enabled, "required": required}
            for key, (enabled, required) in states.items()
        ]

    def test_nothing_is_asked_for_by_default(self):
        # An event that does not need a passport scan must not ask three
        # hundred people for one.
        assert U.requested(self._fields(passport_scan=(False, False))) == []

    def test_an_enabled_kind_is_offered_with_its_formats(self):
        out = U.requested(self._fields(passport_scan=(True, False)))
        assert out[0]["kind"] == U.PASSPORT
        assert ".pdf" in out[0]["accept"]
        assert out[0]["max_bytes"] == U.MAX_BYTES

    def test_ordinary_form_fields_are_not_attachments(self):
        assert U.requested(self._fields(phone=(True, True))) == []

    def test_a_malformed_configuration_does_not_crash_the_form(self):
        assert U.requested(["nonsense", None, 42]) == []

    def test_a_required_document_that_is_missing_is_reported(self):
        wanted = U.requested(self._fields(passport_scan=(True, True)))
        assert U.missing_required(wanted, []) == ["Copie du passeport"]

    def test_a_supplied_document_satisfies_it(self):
        wanted = U.requested(self._fields(passport_scan=(True, True)))
        assert U.missing_required(wanted, [{"kind": U.PASSPORT, "id": "x"}]) == []

    def test_an_optional_document_is_never_reported_missing(self):
        wanted = U.requested(self._fields(photo=(True, False)))
        assert U.missing_required(wanted, []) == []

    def test_a_malformed_attachment_list_does_not_satisfy_anything(self):
        wanted = U.requested(self._fields(passport_scan=(True, True)))
        assert U.missing_required(wanted, ["nope", None]) == ["Copie du passeport"]
