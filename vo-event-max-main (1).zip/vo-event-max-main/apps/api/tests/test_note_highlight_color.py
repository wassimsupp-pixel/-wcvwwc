"""
Tests for colouring a master-list row by note category (point 14).

"Notes presets" already meant something concrete in this codebase: a note
already carries one of five fixed categories (§8) — general, accommodation,
flight, transfer, activity. This is the other half: choosing one category to
colour a participant's row by, and never the note body itself, which stays
behind the participant page the same way every other note field does.
"""

from services import note_service as N


def _note(category):
    return {"category": category}


class TestNoNotesAtAll:

    def test_an_empty_list_has_no_colour(self):
        assert N.highlight_category([]) is None


class TestOneCategory:

    def test_it_wins_outright(self):
        assert N.highlight_category([_note("accommodation")]) == "accommodation"

    def test_a_general_only_note_still_colours(self):
        # A general remark is the muted colour, not no colour at all.
        assert N.highlight_category([_note("general")]) == "general"


class TestPriorityWhenSeveralCategoriesArePresent:
    """A note actually about logistics is more useful to see at a glance
    than a general remark, so those win first."""

    def test_a_logistics_category_beats_general(self):
        got = N.highlight_category([_note("general"), _note("flight")])
        assert got == "flight"

    def test_the_fixed_order_is_accommodation_flight_transfer_activity(self):
        assert N.highlight_category([_note("transfer"), _note("accommodation")]) == "accommodation"
        assert N.highlight_category([_note("activity"), _note("flight")]) == "flight"
        assert N.highlight_category([_note("activity"), _note("transfer")]) == "transfer"

    def test_general_is_the_fallback_never_the_tiebreaker(self):
        for cat in ("accommodation", "flight", "transfer", "activity"):
            assert N.highlight_category([_note("general"), _note(cat)]) == cat


class TestUnknownOrMissingCategoriesFallBackSafely:

    def test_an_unrecognised_category_is_treated_as_general(self):
        assert N.highlight_category([_note("made-up-category")]) == "general"

    def test_a_missing_category_field_is_treated_as_general(self):
        # A real row always has other keys (id, participant_id, ...) even
        # when category itself is null — not the bare {} an empty dict would
        # be, which highlight_category correctly treats as no note at all.
        assert N.highlight_category([{"participant_id": "p1", "category": None}]) == "general"


class TestEveryCategoryHasAColour:

    def test_all_five_categories_have_a_colour(self):
        for category in N.CATEGORIES:
            assert category in N.CATEGORY_COLORS
            assert N.CATEGORY_COLORS[category].startswith("#")

    def test_general_is_the_muted_one(self):
        # Not asserting an exact hex — just that it is visually distinct from
        # every logistics colour, which is the actual requirement.
        colors = N.CATEGORY_COLORS
        assert colors[N.GENERAL] not in (
            colors[N.ACCOMMODATION], colors[N.FLIGHT],
            colors[N.TRANSFER], colors[N.ACTIVITY],
        )

    def test_every_logistics_colour_is_distinct(self):
        logistics = [N.ACCOMMODATION, N.FLIGHT, N.TRANSFER, N.ACTIVITY]
        values = [N.CATEGORY_COLORS[c] for c in logistics]
        assert len(set(values)) == len(values)
