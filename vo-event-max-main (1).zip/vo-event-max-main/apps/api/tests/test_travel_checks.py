"""
Tests for the operational alerts of feedback §18.

These are not "a box is empty" checks — the engine already had those. They are
"two facts contradict each other" checks, and the line between a contradiction
and a normal shape of travel is the whole difficulty:

  * two flights the same day is a connection; two flights whose times OVERLAP
    is one of the files being wrong;
  * a cancelled flight overlapping its replacement is a rebooking, not an error;
  * one person appearing twice in an imported transfer file is one seat.

Getting any of those wrong turns the alerts screen into wallpaper, which is the
failure mode §18 exists to avoid.
"""

import pytest
from datetime import date

from services import travel_checks as T


def _flight(pid="p1", number="SN2145", dep="2027-03-01T08:00", arr="2027-03-01T11:00", **over):
    base = {
        "participant_id": pid, "flight_number": number,
        "departure_time": dep, "arrival_time": arr, "status": "confirmed",
    }
    base.update(over)
    return base


def _transfer(pid="p1", vehicle="van", place="IST", time="2027-03-01T12:00", **over):
    base = {
        "participant_id": pid, "vehicle_type": vehicle,
        "pickup_location": place, "pickup_time": time, "status": "scheduled",
    }
    base.update(over)
    return base


FLEET = [
    {"name": "Taxi", "capacity": 3},
    {"name": "Van", "capacity": 7},
    {"name": "Bus", "capacity": 50},
]


# ===========================================================================
# Conflicting flight
# ===========================================================================

class TestConflictingFlights:

    def test_two_overlapping_segments_are_a_conflict(self):
        out = T.conflicting_flights([
            _flight(number="SN2145", dep="2027-03-01T08:00", arr="2027-03-01T11:00"),
            _flight(number="TK1938", dep="2027-03-01T09:00", arr="2027-03-01T13:00"),
        ])
        assert len(out) == 1
        assert set(out[0]["flights"]) == {"SN2145", "TK1938"}

    def test_a_connection_is_not_a_conflict(self):
        # Brussels → Istanbul then Istanbul → Ankara is how travel works.
        out = T.conflicting_flights([
            _flight(number="SN2145", dep="2027-03-01T08:00", arr="2027-03-01T11:00"),
            _flight(number="TK7", dep="2027-03-01T12:30", arr="2027-03-01T13:40"),
        ])
        assert out == []

    def test_a_segment_touching_the_next_is_not_a_conflict(self):
        out = T.conflicting_flights([
            _flight(number="A", dep="2027-03-01T08:00", arr="2027-03-01T11:00"),
            _flight(number="B", dep="2027-03-01T11:00", arr="2027-03-01T13:00"),
        ])
        assert out == []

    def test_the_same_segment_imported_twice_is_not_a_conflict(self):
        out = T.conflicting_flights([_flight(), _flight()])
        assert out == []

    def test_a_cancelled_segment_overlapping_its_replacement_is_a_rebooking(self):
        out = T.conflicting_flights([
            _flight(number="SN2145", status="cancelled"),
            _flight(number="SN2147", dep="2027-03-01T09:00", arr="2027-03-01T12:00"),
        ])
        assert out == []

    def test_two_people_are_never_in_conflict_with_each_other(self):
        out = T.conflicting_flights([
            _flight(pid="p1", number="A"),
            _flight(pid="p2", number="B", dep="2027-03-01T09:00"),
        ])
        assert out == []

    def test_a_segment_with_no_times_is_skipped_rather_than_guessed(self):
        assert T.conflicting_flights([_flight(dep=None, arr=None), _flight(number="B")]) == []

    def test_a_malformed_timestamp_does_not_take_the_pass_down(self):
        assert T.conflicting_flights([_flight(dep="not-a-time"), _flight(number="B")]) == []

    def test_a_timezone_aware_row_compares_with_a_naive_one(self):
        # Real imports mix the two, and Python refuses to compare them.
        out = T.conflicting_flights([
            _flight(number="A", dep="2027-03-01T08:00:00+00:00", arr="2027-03-01T11:00:00+00:00"),
            _flight(number="B", dep="2027-03-01T09:00", arr="2027-03-01T12:00"),
        ])
        assert len(out) == 1


# ===========================================================================
# A round trip entered backwards
# ===========================================================================
#
# The overlap check above compares two clocks and never looks at an airport,
# which is all it needs to prove nobody is on two planes at once. But it can
# only fire when the two windows actually overlap, and the commonest way to
# enter a round trip backwards produces no overlap at all: the return departs,
# lands, and is over before the outbound takes off.
#
# Athens 2026 is where that bit. Six itineraries were broken, five of them
# physically impossible, and the engine raised three cards — the three whose
# hours happened to collide. The two silent ones are the fixtures below.


class TestEventAirport:

    def test_the_airport_everyone_touches_wins(self):
        # A hundred home airports, one destination. That asymmetry IS the hub.
        flights = [
            _flight(pid=f"p{i}", departure_airport=f"H{i:02d}", arrival_airport="ATH")
            for i in range(12)
        ]
        assert T.event_airport(flights) == "ATH"

    def test_thin_data_gets_no_hub_rather_than_a_guess(self):
        assert T.event_airport([
            _flight(pid="p1", departure_airport="BRU", arrival_airport="ATH"),
        ]) is None

    def test_scattered_data_gets_no_hub(self):
        # Twenty segments and no airport repeats: nominating one from this
        # would call every itinerary in the event broken.
        assert T.event_airport([
            _flight(pid=f"p{i}", departure_airport=f"A{i:02d}", arrival_airport=f"B{i:02d}")
            for i in range(20)
        ]) is None

    def test_flights_carrying_no_airport_at_all(self):
        assert T.event_airport([_flight(pid="p1")]) is None


class TestReversedItinerary:

    def trip(self, pid, out_dep, out_arr, back_dep, back_arr, home="JFK"):
        """A round trip: home -> ATH, then ATH -> home."""
        return [
            _flight(pid=pid, number="OUT", dep=out_dep, arr=out_arr,
                    departure_airport=home, arrival_airport="ATH"),
            _flight(pid=pid, number="BACK", dep=back_dep, arr=back_arr,
                    departure_airport="ATH", arrival_airport=home),
        ]

    def broken(self, pid="p1", home="JFK"):
        """EDWARDS/EMILIO: lands in Athens 05/09 at 17:00, and his return left
        Athens 04/09 at 07:00. No overlap anywhere — the return is finished a
        day before the outbound takes off."""
        return self.trip(pid, "2026-09-05T14:00", "2026-09-05T17:00",
                         "2026-09-04T07:00", "2026-09-04T10:00", home=home)

    def test_a_return_that_is_over_before_the_arrival_begins(self):
        gaps = T.reversed_itinerary(self.broken(), hub="ATH")
        assert [g["participant_id"] for g in gaps] == ["p1"]
        assert gaps[0]["flights"] == ["BACK", "OUT"]
        assert gaps[0]["hub"] == "ATH"

    def test_the_overlap_check_alone_never_sees_it(self):
        # The reason this rule exists at all.
        assert T.conflicting_flights(self.broken()) == []

    def test_a_normal_round_trip_is_silent(self):
        assert T.reversed_itinerary(
            self.trip("p1", "2026-09-01T06:00", "2026-09-01T09:00",
                      "2026-09-05T18:00", "2026-09-05T21:00"), hub="ATH") == []

    def test_a_same_day_round_trip_is_silent(self):
        # COHEN/KATIA: lands 12:05, leaves again 13:10. Absurd for an event,
        # but chronologically fine, and this rule only reports impossibilities.
        assert T.reversed_itinerary(
            self.trip("p1", "2026-09-05T09:20", "2026-09-05T12:05",
                      "2026-09-05T13:10", "2026-09-05T16:05"), hub="ATH") == []

    def test_a_one_way_out_of_the_hub_is_not_reversed(self):
        # Leaves and never comes back. That is missing_return's question, and
        # answering it here too would put two cards on one fact.
        assert T.reversed_itinerary([
            _flight(pid="p1", number="A", dep="2026-09-04T07:00", arr="2026-09-04T10:00",
                    departure_airport="ATH", arrival_airport="JFK"),
            _flight(pid="p1", number="B", dep="2026-09-06T07:00", arr="2026-09-06T09:00",
                    departure_airport="JFK", arrival_airport="BOS"),
        ], hub="ATH") == []

    def test_a_connection_on_the_way_in_is_not_reversed(self):
        assert T.reversed_itinerary([
            _flight(pid="p1", number="A", dep="2026-09-01T06:00", arr="2026-09-01T08:00",
                    departure_airport="JFK", arrival_airport="FRA"),
            _flight(pid="p1", number="B", dep="2026-09-01T09:00", arr="2026-09-01T12:00",
                    departure_airport="FRA", arrival_airport="ATH"),
        ], hub="ATH") == []

    def test_a_cancelled_leg_is_ignored_like_everywhere_else(self):
        legs = self.broken()
        legs[1]["status"] = "cancelled"
        assert T.reversed_itinerary(legs, hub="ATH") == []

    def test_a_segment_with_no_airport_is_skipped_rather_than_guessed(self):
        legs = self.broken()
        legs[1]["departure_airport"] = ""
        assert T.reversed_itinerary(legs, hub="ATH") == []

    def test_case_and_padding_do_not_decide(self):
        legs = self.broken()
        legs[1]["departure_airport"] = " ath "
        legs[0]["arrival_airport"] = "Ath"
        assert len(T.reversed_itinerary(legs, hub="ath")) == 1

    def test_two_people_are_judged_separately(self):
        fine = self.trip("p2", "2026-09-01T06:00", "2026-09-01T09:00",
                         "2026-09-05T18:00", "2026-09-05T21:00", home="MAD")
        gaps = T.reversed_itinerary(self.broken() + fine, hub="ATH")
        assert [g["participant_id"] for g in gaps] == ["p1"]

    def test_two_segments_are_not_a_population_to_infer_a_hub_from(self):
        # No hub passed, and nothing to read one off: silence beats a guess.
        assert T.reversed_itinerary(self.broken()) == []

    def test_the_hub_can_be_read_off_a_real_sized_event(self):
        flights = []
        for i in range(12):
            flights += self.trip(f"ok{i}", "2026-09-01T06:00", "2026-09-01T09:00",
                                 "2026-09-05T18:00", "2026-09-05T21:00", home=f"H{i:02d}")
        flights += self.broken(home="JFK")
        assert [g["participant_id"] for g in T.reversed_itinerary(flights)] == ["p1"]

    def test_an_overlapping_reversal_is_seen_by_both_rules(self):
        # TORRES/TOMAS: leaves ATH 04/09 11:00, lands at ATH 04/09 15:00. The
        # windows DO overlap here, so both rules fire — which is exactly why
        # the caller de-duplicates on participant_id before writing cards.
        legs = self.trip("p1", "2026-09-04T12:00", "2026-09-04T15:00",
                         "2026-09-04T11:00", "2026-09-04T14:00", home="FRA")
        assert len(T.conflicting_flights(legs)) == 1
        assert len(T.reversed_itinerary(legs, hub="ATH")) == 1

    def test_the_message_names_the_two_days_and_the_place(self):
        gap = T.reversed_itinerary(self.broken(), hub="ATH")[0]
        text = T.describe_reversed_itinerary("Emilio Edwards", gap)
        assert "04/09" in text and "05/09" in text
        assert "ATH" in text
        assert "Emilio Edwards" in text


# ===========================================================================
# Missing return flight
# ===========================================================================

class TestMissingReturn:

    END = date(2027, 3, 5)

    def test_somebody_who_only_flew_in_is_reported(self):
        out = T.missing_return([_flight(dep="2027-03-01T08:00")], self.END)
        assert out[0]["participant_id"] == "p1"

    def test_somebody_with_a_return_after_the_event_is_not(self):
        out = T.missing_return([
            _flight(number="A", dep="2027-03-01T08:00"),
            _flight(number="B", dep="2027-03-05T18:00", arr="2027-03-05T21:00"),
        ], self.END)
        assert out == []

    def test_a_connection_on_the_way_in_is_not_a_return(self):
        out = T.missing_return([
            _flight(number="A", dep="2027-03-01T08:00"),
            _flight(number="B", dep="2027-03-01T12:30"),
        ], self.END)
        assert len(out) == 1
        assert out[0]["segments"] == 2

    def test_without_an_event_end_only_the_unambiguous_case_is_reported(self):
        assert T.missing_return([_flight()], None)[0]["segments"] == 1
        assert T.missing_return([_flight(number="A"), _flight(number="B")], None) == []

    def test_a_cancelled_only_participant_is_not_reported_as_one_way(self):
        assert T.missing_return([_flight(status="cancelled")], self.END) == []


# ===========================================================================
# Flight changed
# ===========================================================================

class TestChangedFlights:

    def test_a_changed_flight_is_reported(self):
        assert T.changed_flights([_flight(status="changed")])[0]["flight_number"] == "SN2145"

    def test_a_cancelled_flight_is_reported(self):
        assert T.changed_flights([_flight(status="cancelled")])[0]["status"] == "cancelled"

    def test_a_confirmed_flight_is_not(self):
        assert T.changed_flights([_flight()]) == []

    def test_a_flight_belonging_to_nobody_is_skipped(self):
        # An orphan flight is already its own exception; it is not a person's
        # itinerary being disrupted.
        assert T.changed_flights([_flight(pid=None, status="changed")]) == []

    def test_the_message_says_what_to_re_check(self):
        gap = T.changed_flights([_flight(status="changed")])[0]
        line = T.describe_changed_flight("Sophie", gap)
        assert "transfert" in line and "nuit" in line


# ===========================================================================
# Transfers
# ===========================================================================

class TestTransferRequestedButNotAssigned:

    def _p(self, pid="p1", **over):
        base = {"id": pid, "first_name": "Sophie", "last_name": "Marceau",
                "has_flight": True, "transfer_needed": None}
        base.update(over)
        return base

    def test_a_ticked_box_with_no_transfer_is_reported(self):
        out = T.transfer_requested_not_assigned([self._p(transfer_needed="Yes")], [])
        assert out[0]["name"] == "Sophie Marceau"

    def test_a_ticked_box_with_a_transfer_is_not(self):
        out = T.transfer_requested_not_assigned(
            [self._p(transfer_needed="Yes")], [_transfer()]
        )
        assert out == []

    def test_an_empty_box_is_not_a_request(self):
        # Otherwise every participant of an event that never asked the question
        # is flagged.
        assert T.transfer_requested_not_assigned([self._p()], []) == []

    def test_an_explicit_no_is_not_a_request(self):
        assert T.transfer_requested_not_assigned([self._p(transfer_needed="No")], []) == []

    @pytest.mark.parametrize("value", ["Yes", "oui", "JA", "true", "1", "x"])
    def test_the_usual_ways_of_writing_yes_all_count(self, value):
        assert len(T.transfer_requested_not_assigned([self._p(transfer_needed=value)], [])) == 1


class TestFlightWithoutTransfer:

    def _p(self, pid="p1", **over):
        base = {"id": pid, "first_name": "Sophie", "last_name": "Marceau",
                "has_flight": True, "transfer_needed": None}
        base.update(over)
        return base

    def test_a_landing_nobody_is_meeting_is_reported(self):
        assert T.flight_without_transfer([self._p()], [])[0]["participant_id"] == "p1"

    def test_somebody_without_a_flight_is_not(self):
        assert T.flight_without_transfer([self._p(has_flight=False)], []) == []

    def test_somebody_who_declined_is_left_alone(self):
        # Declining is an answer. Re-asking it every consolidation is how an
        # alert list becomes wallpaper.
        assert T.flight_without_transfer([self._p(transfer_needed="No")], []) == []

    def test_somebody_already_assigned_is_not_reported(self):
        assert T.flight_without_transfer([self._p()], [_transfer()]) == []

    def test_the_message_says_the_consequence(self):
        assert "aéroport" in T.describe_flight_no_transfer("Sophie")


# ===========================================================================
# Vehicle capacity
# ===========================================================================

class TestCapacityExceeded:

    def _van(self, n, place="IST", time="2027-03-01T12:00"):
        return [_transfer(pid=f"p{i}", place=place, time=time) for i in range(n)]

    def test_more_passengers_than_seats_is_reported(self):
        out = T.capacity_exceeded(self._van(9), FLEET)
        assert out[0]["over_by"] == 2
        assert out[0]["capacity"] == 7

    def test_a_full_vehicle_is_not_an_alert(self):
        assert T.capacity_exceeded(self._van(7), FLEET) == []

    def test_one_person_imported_twice_is_one_seat(self):
        rows = self._van(7) + [_transfer(pid="p0")]
        assert T.capacity_exceeded(rows, FLEET) == []

    def test_two_pickup_points_are_two_vehicles(self):
        rows = self._van(5, place="IST") + self._van(5, place="SAW")
        assert T.capacity_exceeded(rows, FLEET) == []

    def test_pickups_an_hour_apart_are_two_runs(self):
        rows = (self._van(5, time="2027-03-01T12:00")
                + [_transfer(pid=f"q{i}", time="2027-03-01T14:00") for i in range(5)])
        assert T.capacity_exceeded(rows, FLEET) == []

    def test_pickups_within_the_window_share_a_vehicle(self):
        rows = (self._van(5, time="2027-03-01T12:05")
                + [_transfer(pid=f"q{i}", time="2027-03-01T12:40") for i in range(5)])
        assert T.capacity_exceeded(rows, FLEET)[0]["passengers"] == 10

    def test_a_vehicle_type_nobody_declared_is_skipped_not_assumed(self):
        # Inventing a capacity would either cry wolf or stay silent about a
        # genuinely overloaded coach.
        rows = [_transfer(pid=f"p{i}", vehicle="limousine") for i in range(40)]
        assert T.capacity_exceeded(rows, FLEET) == []

    def test_an_empty_fleet_reports_nothing(self):
        assert T.capacity_exceeded(self._van(99), []) == []

    def test_a_transfer_with_no_time_is_skipped(self):
        assert T.capacity_exceeded([_transfer(time=None)] * 20, FLEET) == []

    def test_the_message_names_the_shortfall(self):
        line = T.describe_capacity(T.capacity_exceeded(self._van(9), FLEET)[0])
        assert "9 passagers" in line and "2 de trop" in line
