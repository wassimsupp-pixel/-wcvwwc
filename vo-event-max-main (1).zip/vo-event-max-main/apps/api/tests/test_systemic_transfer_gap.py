"""
Tests for the "vol sans transfert" alert when it covers everybody (§18).

A hundred cards all saying the same sentence are not a hundred findings. They
are one finding about the event — the transfer file was never imported, or its
participant column went to the wrong field — and the codebase already has a
name for that shape (``_is_systemic``, used by the coverage cards since the
2026-07 incident: 600 transfer rows, 0 transfers linked).

This checks that the per-person cards still exist for gaps somebody can fix one
at a time, and collapse into a single actionable card when they cannot.
"""

import pytest

from services import travel_checks
from services.exception_service import _is_systemic


def _people(n, *, with_flight=True, assigned=0):
    return [
        {
            "id": f"p{i:03d}",
            "first_name": "Test",
            "last_name": f"Person{i}",
            "has_flight": with_flight,
        }
        for i in range(n)
    ]


def _transfers(ids):
    return [{"participant_id": i} for i in ids]


class TestWhenItIsAGenuineHandfulOfGaps:

    def test_three_people_out_of_forty_stay_three_separate_cards(self):
        people = _people(40)
        covered = [p["id"] for p in people[3:]]
        gaps = travel_checks.flight_without_transfer(people, _transfers(covered))
        assert len(gaps) == 3
        # Below the ratio: each one is somebody a coordinator can chase.
        assert not _is_systemic(len(gaps), 40)

    def test_each_card_names_the_person(self):
        people = _people(40)
        gaps = travel_checks.flight_without_transfer(
            people, _transfers([p["id"] for p in people[1:]])
        )
        message = travel_checks.describe_flight_no_transfer(gaps[0]["name"])
        assert "Test Person0" in message


class TestWhenItIsEverybody:

    def test_a_whole_event_with_no_transfers_is_one_finding(self):
        people = _people(120)
        gaps = travel_checks.flight_without_transfer(people, [])
        assert len(gaps) == 120
        assert _is_systemic(len(gaps), 120)

    def test_it_stays_systemic_with_a_few_transfers_linked(self):
        # The failure mode is rarely perfectly clean: a handful match by luck.
        people = _people(120)
        gaps = travel_checks.flight_without_transfer(
            people, _transfers([p["id"] for p in people[:5]])
        )
        assert _is_systemic(len(gaps), 120)

    def test_the_message_points_at_the_import_not_at_the_people(self):
        # Naming three hundred participants would send somebody to fix three
        # hundred fiches by hand instead of one column mapping.
        message = travel_checks.describe_flight_no_transfer_systemic(118, 120)
        assert "118" in message and "120" in message
        assert "import" in message.lower()
        assert "mapp" in message.lower()

    def test_a_small_event_is_never_called_systemic(self):
        # Ten people with no transfers may simply be ten people with no
        # transfers; the threshold needs a population to mean anything.
        people = _people(10)
        gaps = travel_checks.flight_without_transfer(people, [])
        assert len(gaps) == 10
        assert not _is_systemic(len(gaps), 10)


class TestWhoIsCountedAtAll:

    def test_somebody_without_a_flight_is_not_a_gap(self):
        people = _people(5, with_flight=False)
        assert travel_checks.flight_without_transfer(people, []) == []

    def test_somebody_who_declined_a_transfer_is_left_alone(self):
        # Declining is an answer. Re-asking it every consolidation is how an
        # alert list becomes wallpaper.
        people = _people(3)
        for p in people:
            p["transfer_needed"] = "non"
        assert travel_checks.flight_without_transfer(people, []) == []

    def test_somebody_who_never_answered_is_still_a_gap(self):
        # Unknown is not "no": nobody is meeting them either way.
        people = _people(3)
        for p in people:
            p["transfer_needed"] = ""
        assert len(travel_checks.flight_without_transfer(people, [])) == 3
