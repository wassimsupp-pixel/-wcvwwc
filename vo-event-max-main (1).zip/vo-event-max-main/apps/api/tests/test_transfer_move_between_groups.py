"""
Tests for dropping a passenger into another vehicle.

A group is not a row in a table — it is every transfer that happens to share a
direction, a route, a time and a vehicle. So "move this person into that van"
is a PATCH that rewrites all five of those fields at once, and the one that is
easy to forget is the direction: leave it behind and the person shows up as
arriving, in a vehicle whose whole itinerary says it is going to the airport.

The direction is also the only field here the database constrains, so it is the
only one that can be refused rather than merely wrong.
"""

from unittest.mock import AsyncMock, patch

import pytest
from fastapi import HTTPException

from models.schemas import TransferUpdate
from routers.transfers import update_transfer


class _Query:
    def __init__(self, table):
        self.t = table
        self.rows = list(table.rows)
        self._single = False

    def select(self, *_a, **_k):
        return self

    def eq(self, col, val):
        self.rows = [r for r in self.rows if str(r.get(col)) == str(val)]
        return self

    def single(self):
        self._single = True
        return self

    def update(self, payload):
        self.t.captured_update = payload
        for row in self.t.rows:
            if row in self.rows:
                row.update(payload)
        return self

    def execute(self):
        data = self.rows[0] if self._single else self.rows
        return type("Res", (), {"data": data})()


class _Table:
    def __init__(self, rows):
        self.rows = rows
        self.captured_update = None


class FakeSupabase:
    def __init__(self, transfers):
        self.transfers = _Table(list(transfers))

    def table(self, _name):
        return _Query(self.transfers)


TRANSFER_ID = "11111111-1111-1111-1111-111111111111"
EVENT_ID = "22222222-2222-2222-2222-222222222222"


def _arrival(**over):
    base = {
        "id": TRANSFER_ID, "event_id": EVENT_ID,
        "participant_id": "33333333-3333-3333-3333-333333333333",
        "transfer_type": "arrival", "pickup_location": "BRU",
        "dropoff_location": "Hôtel Athenaeum", "pickup_time": "2026-08-29T15:00:00",
        "vehicle_type": "Van", "status": "scheduled",
        "created_at": "2026-08-01T10:00:00",
    }
    base.update(over)
    return base


@pytest.mark.asyncio
@patch("routers.transfers.verify_event_access", new_callable=AsyncMock)
@patch("routers.transfers.log_change")
class TestMovingSomeoneIntoAnotherVehicle:

    async def test_the_direction_travels_with_the_move(self, _log, _verify):
        # An arrival dropped into a departure group. Without transfer_type on
        # the patch this person stayed an "arrival" in a van driving to the
        # airport, and disappeared from the departure list they were dropped
        # into.
        sb = FakeSupabase([_arrival()])
        body = TransferUpdate(
            transfer_type="departure",
            pickup_location="Hôtel Athenaeum",
            dropoff_location="BRU",
            pickup_time="2026-09-02T09:00:00",
            vehicle_type="Minibus",
        )
        await update_transfer(TRANSFER_ID, body, {"id": "u-1"}, sb)
        row = sb.transfers.rows[0]
        assert row["transfer_type"] == "departure"
        assert row["pickup_location"] == "Hôtel Athenaeum"
        assert row["dropoff_location"] == "BRU"
        assert row["vehicle_type"] == "Minibus"

    async def test_moving_within_the_same_direction_still_works(self, _log, _verify):
        sb = FakeSupabase([_arrival()])
        body = TransferUpdate(
            transfer_type="arrival", pickup_location="CRL",
            pickup_time="2026-08-29T16:00:00", vehicle_type="Taxi",
        )
        await update_transfer(TRANSFER_ID, body, {"id": "u-1"}, sb)
        row = sb.transfers.rows[0]
        assert row["transfer_type"] == "arrival"
        assert row["pickup_location"] == "CRL"

    @pytest.mark.parametrize("bad", ["Arrivée", "ARRIVAL", "shuttle", "", "  "])
    async def test_a_direction_that_is_not_one_of_the_two_is_refused(self, _log, _verify, bad):
        # Refused, not coerced: storing a third value would make the person
        # vanish from both lists, which is worse than an error message.
        sb = FakeSupabase([_arrival()])
        body = TransferUpdate(transfer_type=bad)
        with pytest.raises(HTTPException) as raised:
            await update_transfer(TRANSFER_ID, body, {"id": "u-1"}, sb)
        assert raised.value.status_code == 422
        assert sb.transfers.rows[0]["transfer_type"] == "arrival"

    async def test_an_edit_that_says_nothing_about_direction_leaves_it_alone(self, _log, _verify):
        # exclude_none: editing only the vehicle must not blank the direction.
        sb = FakeSupabase([_arrival()])
        body = TransferUpdate(vehicle_type="Bus")
        await update_transfer(TRANSFER_ID, body, {"id": "u-1"}, sb)
        assert "transfer_type" not in (sb.transfers.captured_update or {})
        assert sb.transfers.rows[0]["transfer_type"] == "arrival"
