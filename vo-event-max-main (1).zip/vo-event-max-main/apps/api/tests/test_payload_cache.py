"""
Tests for the public form's cache.

A cache is a correctness feature pretending to be a performance one. The
failure that matters here is not a slow page — it is a stale one: an organizer
closes registrations, and the form goes on accepting people because a copy from
fifty seconds ago says it is open. So most of what follows is about dropping
entries, not keeping them.

The other half is that a cache must never be able to break the page it speeds
up. An unknown token still has to 404, a bot walking the namespace must not be
able to grow this without limit, and two visitors must never see each other's
event.
"""

import threading
import time

import pytest

from services.payload_cache import PayloadCache, cached_or_build, form_key


@pytest.fixture
def cache():
    return PayloadCache(ttl=60.0, max_entries=100)


class TestItServesTheSameThingTwice:

    def test_a_hit_returns_the_stored_value(self, cache):
        cache.put("k", "event-1", {"nom": "Athens"})
        assert cache.get("k") == {"nom": "Athens"}

    def test_a_miss_is_none_not_an_error(self, cache):
        assert cache.get("jamais-vu") is None

    def test_build_runs_once_across_many_callers(self, cache):
        calls = []

        def build():
            calls.append(1)
            return {"payload": len(calls)}

        first, cached_first = cached_or_build("k", "event-1", build, cache)
        assert (first, cached_first) == ({"payload": 1}, False)

        for _ in range(499):
            value, was_cached = cached_or_build("k", "event-1", build, cache)
            assert was_cached
            assert value == {"payload": 1}

        # Five hundred visitors, one build. That is the whole point.
        assert len(calls) == 1

    def test_an_expired_entry_is_rebuilt(self):
        cache = PayloadCache(ttl=0.05)
        cache.put("k", "event-1", "vieux")
        time.sleep(0.06)
        assert cache.get("k") is None


class TestStalenessIsTheRealRisk:

    def test_invalidating_an_event_drops_all_its_entries(self, cache):
        for lang in ("fr", "nl", "en"):
            cache.put(form_key("tok", lang, None), "event-1", lang)
        assert cache.invalidate("event-1") == 3
        for lang in ("fr", "nl", "en"):
            assert cache.get(form_key("tok", lang, None)) is None

    def test_invalidating_one_event_leaves_the_others_alone(self, cache):
        cache.put("a", "event-1", "un")
        cache.put("b", "event-2", "deux")
        cache.invalidate("event-1")
        assert cache.get("a") is None
        assert cache.get("b") == "deux"

    def test_invalidating_something_never_cached_is_harmless(self, cache):
        assert cache.invalidate("event-inconnu") == 0

    def test_an_event_can_be_invalidated_twice(self, cache):
        cache.put("a", "event-1", "un")
        cache.invalidate("event-1")
        assert cache.invalidate("event-1") == 0

    def test_re_caching_after_an_invalidation_works(self, cache):
        cache.put("a", "event-1", "avant")
        cache.invalidate("event-1")
        cache.put("a", "event-1", "après")
        assert cache.get("a") == "après"
        # And the owner index was rebuilt, so it can be dropped again.
        assert cache.invalidate("event-1") == 1


class TestTheKeySeparatesWhatDiffers:

    def test_language_changes_the_key(self):
        assert form_key("tok", "fr", None) != form_key("tok", "nl", None)

    def test_badge_changes_the_key(self):
        assert form_key("tok", "fr", None) != form_key("tok", "fr", "vip")

    def test_token_changes_the_key(self):
        assert form_key("a", "fr", None) != form_key("b", "fr", None)

    def test_no_badge_and_empty_badge_are_the_same_request(self):
        assert form_key("tok", "fr", None) == form_key("tok", "fr", "")

    def test_two_events_never_collide(self, cache):
        cache.put(form_key("tok-a", "fr", None), "event-1", "Athens")
        cache.put(form_key("tok-b", "fr", None), "event-2", "Istambul")
        assert cache.get(form_key("tok-a", "fr", None)) == "Athens"
        assert cache.get(form_key("tok-b", "fr", None)) == "Istambul"


class TestItCannotGrowWithoutLimit:

    def test_entries_are_capped(self):
        # A bot walking tokens must not be able to fill memory.
        cache = PayloadCache(ttl=60.0, max_entries=10)
        for i in range(200):
            cache.put("k%d" % i, "event-%d" % i, i)
        assert len(cache._entries) <= 10

    def test_the_owner_index_does_not_leak_after_eviction(self):
        cache = PayloadCache(ttl=60.0, max_entries=5)
        for i in range(50):
            cache.put("k%d" % i, "event-%d" % i, i)
        # Every remaining key is still reachable from its owner, and no owner
        # points at a key that is gone.
        for owner, keys in cache._by_owner.items():
            assert keys, "un propriétaire sans clé devrait avoir été supprimé"
            for key in keys:
                assert key in cache._entries

    def test_overwriting_a_key_does_not_count_as_growth(self):
        cache = PayloadCache(ttl=60.0, max_entries=3)
        for _ in range(20):
            cache.put("même-clé", "event-1", "valeur")
        assert len(cache._entries) == 1


class TestItNeverBreaksThePage:

    def test_a_failing_build_propagates_and_caches_nothing(self, cache):
        class Boom(Exception):
            pass

        def build():
            raise Boom("jeton inconnu")

        with pytest.raises(Boom):
            cached_or_build("k", "event-1", build, cache)
        assert cache.get("k") is None

    def test_concurrent_callers_do_not_corrupt_it(self, cache):
        # Sync FastAPI handlers run in a threadpool, so this really happens.
        errors = []

        def hammer(n):
            try:
                for i in range(200):
                    cache.put("k%d" % (i % 20), "event-%d" % (i % 5), n)
                    cache.get("k%d" % (i % 20))
                    if i % 50 == 0:
                        cache.invalidate("event-%d" % (i % 5))
            except Exception as exc:                # noqa: BLE001
                errors.append(exc)

        threads = [threading.Thread(target=hammer, args=(n,)) for n in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert errors == []


class TestStats:

    def test_hits_and_misses_are_counted(self, cache):
        cache.get("absent")
        cache.put("k", "event-1", 1)
        cache.get("k")
        cache.get("k")
        stats = cache.stats()
        assert stats["hits"] == 2
        assert stats["misses"] == 1
        assert stats["hit_rate"] == round(2 / 3, 3)

    def test_an_untouched_cache_reports_a_zero_rate_not_a_crash(self, cache):
        assert cache.stats()["hit_rate"] == 0.0
