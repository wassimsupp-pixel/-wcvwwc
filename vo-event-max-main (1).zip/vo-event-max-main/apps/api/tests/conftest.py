"""Test-wide isolation from live AI providers.

``ai_service`` reads its provider keys from the environment at call time, and
``main.py`` loads a ``.env`` when it is imported — which the API tests do. So a
developer with real keys in their ``.env`` was running a different suite from
CI: every test that exercises a "no provider answered" path would quietly make
live network calls, take minutes, and pass or fail on someone's quota.

Every AI-dependent test patches exactly what it needs, so nothing here should
ever reach a provider for real. This makes that a property of the suite rather
than a property of the machine it runs on.
"""

import os

import pytest


@pytest.fixture(autouse=True, scope="session")
def _no_live_ai_providers():
    for var in ("NVIDIA_API_KEY", "OPENAI_API_KEY", "GEMINI_API_KEY"):
        os.environ.pop(var, None)
    # GEMINI_AVAILABLE is decided at import time from the key, so clearing the
    # environment alone would leave a client behind.
    from services import ai_service
    ai_service.GEMINI_AVAILABLE = False
    ai_service._gemini_client = None
    os.environ.pop("ANTHROPIC_API_KEY", None)
    yield


@pytest.fixture(autouse=True)
def _fresh_process_caches():
    """Reset the caches that outlive a single request.

    The public form's cache is module-level on purpose — one instance per
    uvicorn worker, shared across every request, which is what makes a mailshot
    cost one database read instead of five hundred. A test suite is one process
    too, so without this the second test to use a token is served the first
    test's payload.

    Claude's client is memoised the same way, and `_anthropic_disabled` latches
    for the life of the process once a key is rejected — so one test
    exercising that path would quietly disable Claude for every test after it.
    """
    from services import ai_service, payload_cache

    payload_cache.public_form.clear()
    ai_service._anthropic_client = None
    ai_service._anthropic_disabled = False
    yield
    payload_cache.public_form.clear()
