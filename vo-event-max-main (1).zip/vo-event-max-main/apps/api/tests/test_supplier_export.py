"""
Tests for supplier exports (feedback §6).

One property matters more than every other case here and has its own class:
**no profile, and no column selection, can put a sensitive field in a file that
leaves the company.** Everything else — column order, empty cells, file names —
is comfort. That one is the reason the module exists.

It is tested as a denial rather than as an absence, because the two fail
differently. An absent column is a decision somebody can undo by editing a
list, and nobody would notice until a coach operator was holding a hundred
passport numbers.
"""

import re

import pytest

from services import supplier_export as S


class TestNothingSensitiveEverLeaves:
    def test_no_fixed_profile_ships_a_sensitive_column(self):
        for profile in (S.HOTEL, S.TRANSFER, S.ACTIVITY, S.FLIGHT):
            keys = {key for _label, key in S.columns_for(profile)}
            assert not keys & S.SENSITIVE_KEYS, profile

    def test_the_custom_catalogue_offers_nothing_sensitive(self):
        choices = {c["key"] for c in S.available_profiles()[-1]["choices"]}
        assert not choices & S.SENSITIVE_KEYS

    @pytest.mark.parametrize("key", sorted(S.SENSITIVE_KEYS))
    def test_asking_for_a_sensitive_column_by_name_gets_you_nothing(self, key):
        # The whole attack surface: an organizer ticking a box, a stale
        # frontend, a hand-crafted API call.
        keys = {k for _label, k in S.columns_for(S.CUSTOM, [key])}
        assert key not in keys

    def test_a_sensitive_column_hidden_among_legitimate_ones_is_still_dropped(self):
        cols = S.columns_for(S.CUSTOM, ["last_name", "passport_number", "hotel_checkin"])
        assert [k for _l, k in cols] == ["last_name", "hotel_checkin"]

    def test_the_denial_covers_what_the_feedback_names_explicitly(self):
        # "une compagnie de transfert n'a pas besoin de recevoir : les numeros
        # de passeport, les donnees personnelles completes, les preferences
        # alimentaires, certaines remarques internes."
        for key in ("passport_number", "dietary_requirements", "medical_info", "remarks"):
            assert key in S.SENSITIVE_KEYS, key

    def test_the_transfer_sheet_carries_none_of_them(self):
        keys = {key for _label, key in S.columns_for(S.TRANSFER)}
        for key in ("passport_number", "dietary_requirements", "medical_info",
                    "remarks", "emergency_contact_phone"):
            assert key not in keys

    def test_the_guard_actually_fires_when_given_something_sensitive(self):
        # A test that only proves the guard is present, not that it works, is
        # worse than no test. This is the mutation check.
        with pytest.raises(S.SensitiveColumnError):
            S._assert_safe("bricolage", ["last_name", "passport_number"])

    def test_the_guard_stays_quiet_on_a_clean_list(self):
        S._assert_safe("bricolage", ["last_name", "hotel_checkin"])


class TestProfilesMatchTheFeedback:
    def test_the_hotel_sheet_holds_what_a_hotel_works_from(self):
        labels = [label for label, _key in S.columns_for(S.HOTEL)]
        for expected in ("Check-in", "Check-out", "Type de chambre", "Roommate",
                         "N° de chambre"):
            assert expected in labels, expected

    def test_the_transfer_sheet_holds_what_a_coach_company_works_from(self):
        labels = [label for label, _key in S.columns_for(S.TRANSFER)]
        for expected in ("N° de vol", "Heure d'arrivée", "Transfert assigné",
                         "Heure de prise en charge"):
            assert expected in labels, expected

    def test_the_activity_sheet_holds_the_schedule(self):
        labels = [label for label, _key in S.columns_for(S.ACTIVITY)]
        assert "Activité" in labels and "Horaire" in labels

    def test_the_flight_sheet_covers_both_legs(self):
        labels = [label for label, _key in S.columns_for(S.FLIGHT)]
        assert any("aller" in l.lower() for l in labels)
        assert any("retour" in l.lower() for l in labels)

    def test_every_sheet_starts_with_a_name(self):
        # A supplier sheet whose first column is not a person is unreadable.
        for profile in (S.HOTEL, S.TRANSFER, S.ACTIVITY, S.FLIGHT):
            assert S.columns_for(profile)[0][0] == "Nom"

    def test_an_unknown_profile_is_refused(self):
        with pytest.raises(ValueError):
            S.columns_for("marketing")


class TestCustomSelection:
    def test_the_chosen_columns_come_back_in_the_order_asked_for(self):
        cols = S.columns_for(S.CUSTOM, ["hotel_checkin", "last_name", "company"])
        assert [k for _l, k in cols] == ["hotel_checkin", "last_name", "company"]

    def test_an_unknown_key_is_dropped_silently(self):
        cols = S.columns_for(S.CUSTOM, ["last_name", "salaire"])
        assert [k for _l, k in cols] == ["last_name"]

    def test_choosing_nothing_still_produces_a_readable_file(self):
        # Not an empty sheet of blank rows.
        assert [k for _l, k in S.columns_for(S.CUSTOM, [])] == ["last_name", "first_name"]

    def test_choosing_only_forbidden_columns_falls_back_the_same_way(self):
        cols = S.columns_for(S.CUSTOM, ["passport_number", "medical_info"])
        assert [k for _l, k in cols] == ["last_name", "first_name"]

    def test_every_offered_choice_can_actually_be_chosen(self):
        choices = [c["key"] for c in S.available_profiles()[-1]["choices"]]
        cols = {k for _l, k in S.columns_for(S.CUSTOM, choices)}
        assert cols == set(choices)


class TestRowBuilding:
    ROWS = [
        {"first_name": "Tina", "last_name": "Fey", "hotel_checkin": "01/09/2026",
         "hotel_room_type": "twin", "roommate_name": "Leslie Knope",
         "passport_number": "X1234567", "dietary_requirements": "vegan"},
        {"first_name": "Leslie", "last_name": "Knope"},
    ]

    def test_the_file_contains_only_the_agreed_columns(self):
        headers, values = S.build_rows(S.HOTEL, self.ROWS)
        assert len(headers) == len(S.columns_for(S.HOTEL))
        assert all(len(row) == len(headers) for row in values)

    def test_the_sensitive_values_are_not_in_the_output_at_all(self):
        _headers, values = S.build_rows(S.HOTEL, self.ROWS)
        flat = " ".join(str(v) for row in values for v in row)
        assert "X1234567" not in flat
        assert "vegan" not in flat

    def test_a_column_the_master_row_lacks_is_blank_not_missing(self):
        # The sheet's shape is a promise to the supplier: it must not change
        # because one event has no room numbers yet.
        headers, values = S.build_rows(S.HOTEL, self.ROWS)
        assert len(values[1]) == len(headers)
        assert values[1][headers.index("N° de chambre")] == ""

    def test_a_missing_value_is_an_empty_cell_never_the_word_none(self):
        _headers, values = S.build_rows(S.HOTEL, [{"last_name": "Fey"}])
        assert all(v != "None" and v is not None for v in values[0])

    def test_a_boolean_is_written_in_french_not_as_true(self):
        _headers, values = S.build_rows(S.CUSTOM, [{"last_name": True}], ["last_name"])
        assert values[0][0] == "Oui"

    def test_no_participants_gives_headers_and_no_rows(self):
        headers, values = S.build_rows(S.TRANSFER, [])
        assert headers and values == []


class TestFileName:
    @pytest.mark.parametrize("profile,expected", [
        (S.HOTEL, "hotel"), (S.TRANSFER, "transferts"),
        (S.ACTIVITY, "activites"), (S.FLIGHT, "vols"), (S.CUSTOM, "personnalise"),
    ])
    def test_it_says_which_supplier_it_is_for(self, profile, expected):
        name = S.filename_for(profile, "istanbul-summit", "20260815")
        assert name.startswith(expected + "_")

    def test_it_names_the_event_and_the_day(self):
        name = S.filename_for(S.HOTEL, "istanbul-summit", "20260815")
        assert "istanbul-summit" in name and "20260815" in name
        assert name.endswith(".xlsx")


class TestGeneratedWorkbook:
    def test_it_opens_and_holds_exactly_the_expected_grid(self):
        from io import BytesIO
        from openpyxl import load_workbook
        from services import export_service

        headers, values = S.build_rows(S.HOTEL, TestRowBuilding.ROWS)
        data = export_service.generate_simple_sheet("Hôtel", headers, values)
        ws = load_workbook(BytesIO(data)).active
        assert [c.value for c in ws[1]] == headers
        assert ws.max_row == len(values) + 1

    def test_a_value_that_looks_like_a_formula_is_written_as_inert_text(self):
        # A participant whose company is literally "=cmd|..." must not become a
        # live formula in a coach operator's Excel.
        from io import BytesIO
        from openpyxl import load_workbook
        from services import export_service

        data = export_service.generate_simple_sheet(
            "Test", ["Nom"], [["=cmd|' /c calc'!A0"]])
        ws = load_workbook(BytesIO(data)).active
        assert ws.cell(row=2, column=1).data_type == "s"

    def test_the_sheet_title_survives_excels_31_character_limit(self):
        from io import BytesIO
        from openpyxl import load_workbook
        from services import export_service

        data = export_service.generate_simple_sheet("x" * 60, ["A"], [["1"]])
        ws = load_workbook(BytesIO(data)).active
        assert len(ws.title) <= 31


class TestProfileListing:
    def test_the_columns_are_listed_with_each_profile(self):
        # Somebody about to email a file to an outside company should see what
        # is in it before it leaves, not after.
        for entry in S.available_profiles():
            if entry["profile"] != S.CUSTOM:
                assert entry["columns"], entry["profile"]

    def test_every_profile_has_a_human_label(self):
        for entry in S.available_profiles():
            assert entry["label"] and not re.match(r"^[a-z_]+$", entry["label"])

    def test_the_custom_profile_offers_choices_rather_than_fixed_columns(self):
        custom = S.available_profiles()[-1]
        assert custom["profile"] == S.CUSTOM
        assert custom["columns"] == []
        assert len(custom["choices"]) > 10
