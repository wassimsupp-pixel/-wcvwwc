"""
Tests for registering a supplier export (§6).

These cover a bug that made the feature fail every single time it was used:
``exports.run_id`` is NOT NULL in the schema, and the supplier export inserted
``None`` into it. The file uploaded fine, the row was rejected, and the screen
said "Export televerse mais enregistrement echoue" — with an unreachable file
left in Storage on each attempt.
"""

import pytest

from routers.exports import _latest_completed_run


class _Query:
    def __init__(self, rows, fail=False):
        self.rows = list(rows)
        self.fail = fail

    def select(self, *_a, **_k):
        return self

    def eq(self, col, val):
        self.rows = [r for r in self.rows if str(r.get(col)) == str(val)]
        return self

    def order(self, col, desc=False):
        self.rows = sorted(
            self.rows, key=lambda r: str(r.get(col) or ""), reverse=bool(desc)
        )
        return self

    def limit(self, n):
        self.rows = self.rows[:n]
        return self

    def execute(self):
        if self.fail:
            raise RuntimeError("postgrest is down")
        return type("Res", (), {"data": self.rows})()


class FakeSupabase:
    def __init__(self, rows=None, fail=False):
        self.rows = rows or []
        self.fail = fail

    def table(self, _name):
        return _Query(self.rows, self.fail)


def _run(**over):
    base = {
        "id": "run-1",
        "event_id": "ev-1",
        "status": "completed",
        "started_at": "2026-08-01T10:00:00+00:00",
    }
    base.update(over)
    return base


class TestFindingTheRunTheExportReflects:

    def test_the_completed_run_is_found(self):
        assert _latest_completed_run(FakeSupabase([_run()]), "ev-1") == "run-1"

    def test_the_most_recent_one_wins(self):
        sb = FakeSupabase([
            _run(id="old", started_at="2026-07-01T10:00:00+00:00"),
            _run(id="new", started_at="2026-08-15T10:00:00+00:00"),
        ])
        assert _latest_completed_run(sb, "ev-1") == "new"

    def test_a_run_still_going_is_not_used(self):
        # Exporting a half-built master list would ship a supplier a file that
        # contradicts the next one by a few hundred rows.
        sb = FakeSupabase([_run(status="running")])
        assert _latest_completed_run(sb, "ev-1") is None

    def test_another_event_s_run_is_never_used(self):
        assert _latest_completed_run(FakeSupabase([_run(event_id="ev-2")]), "ev-1") is None

    def test_an_event_never_consolidated_has_none(self):
        # The caller refuses with "lancez d'abord une consolidation" BEFORE
        # uploading, so no orphan file is created.
        assert _latest_completed_run(FakeSupabase([]), "ev-1") is None

    def test_a_query_failure_is_not_an_outage(self):
        assert _latest_completed_run(FakeSupabase([_run()], fail=True), "ev-1") is None


class TestTheRecordIsInsertable:
    """The regression itself: the schema declares run_id NOT NULL."""

    def test_the_run_id_is_never_none_when_an_export_is_registered(self):
        run_id = _latest_completed_run(FakeSupabase([_run()]), "ev-1")
        record = {
            "id": "exp-1",
            "run_id": run_id,
            "event_id": "ev-1",
            "storage_path": "exports/ev-1/exp-1/f.xlsx",
            "filename": "f.xlsx",
            "created_by": "u-1",
        }
        assert record["run_id"] is not None
        for column in ("run_id", "event_id", "storage_path", "filename", "created_by"):
            assert record[column], f"{column} is NOT NULL in the schema"
