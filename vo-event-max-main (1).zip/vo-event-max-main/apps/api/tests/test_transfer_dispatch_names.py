"""
Tests for routers.transfers._attach_names (feedback §1).

dispatch_service stays pure — dicts in, dicts out, no database — so a proposed
group only ever carries participant_ids. An organizer deciding whether to move
somebody out of a van needs to see WHO is in it, not a UUID and a head count.
_attach_names resolves that, once, for every group in a proposal at once.
"""

from routers.transfers import _attach_names


class _Query:
    def __init__(self, rows):
        self.rows = list(rows)

    def select(self, *_a, **_k):
        return self

    def in_(self, col, values):
        wanted = set(values)
        self.rows = [r for r in self.rows if r.get(col) in wanted]
        return self

    def execute(self):
        return type("Res", (), {"data": self.rows})()


class FakeSupabase:
    def __init__(self, participants=None, fail=False):
        self.participants = participants or []
        self.fail = fail

    def table(self, _name):
        if self.fail:
            raise RuntimeError("postgrest down")
        return _Query(self.participants)


def _group(*ids, **over):
    base = {"direction": "arrival", "participant_ids": list(ids)}
    base.update(over)
    return base


class TestResolvingNames:

    def test_each_group_gets_a_participants_list(self):
        sb = FakeSupabase([{"id": "p1", "first_name": "Tina", "last_name": "Fey"}])
        proposals = [_group("p1")]
        _attach_names(sb, proposals)
        assert proposals[0]["participants"] == [{"id": "p1", "name": "Tina Fey"}]

    def test_the_order_matches_participant_ids(self):
        sb = FakeSupabase([
            {"id": "p1", "first_name": "Tina", "last_name": "Fey"},
            {"id": "p2", "first_name": "Leslie", "last_name": "Knope"},
        ])
        proposals = [_group("p2", "p1")]
        _attach_names(sb, proposals)
        assert [p["id"] for p in proposals[0]["participants"]] == ["p2", "p1"]

    def test_every_group_in_the_proposal_is_resolved_from_one_lookup(self):
        sb = FakeSupabase([
            {"id": "p1", "first_name": "Tina", "last_name": "Fey"},
            {"id": "p2", "first_name": "Leslie", "last_name": "Knope"},
        ])
        proposals = [_group("p1"), _group("p2", direction="departure")]
        _attach_names(sb, proposals)
        assert proposals[0]["participants"][0]["name"] == "Tina Fey"
        assert proposals[1]["participants"][0]["name"] == "Leslie Knope"

    def test_a_missing_participant_falls_back_to_their_id(self):
        # Deleted between the flight import and this call, or a data glitch —
        # either way the group must still render rather than lose the person.
        sb = FakeSupabase([])
        proposals = [_group("ghost-id")]
        _attach_names(sb, proposals)
        assert proposals[0]["participants"] == [{"id": "ghost-id", "name": "ghost-id"}]

    def test_a_lookup_failure_falls_back_to_ids_rather_than_crashing(self):
        sb = FakeSupabase(fail=True)
        proposals = [_group("p1")]
        _attach_names(sb, proposals)
        assert proposals[0]["participants"] == [{"id": "p1", "name": "p1"}]

    def test_an_empty_proposal_list_is_a_no_op(self):
        sb = FakeSupabase([])
        _attach_names(sb, [])  # must not raise

    def test_a_participant_with_no_name_on_file_falls_back_to_their_id(self):
        sb = FakeSupabase([{"id": "p1", "first_name": None, "last_name": None}])
        proposals = [_group("p1")]
        _attach_names(sb, proposals)
        assert proposals[0]["participants"] == [{"id": "p1", "name": "p1"}]

    def test_large_proposals_are_chunked_rather_than_dropped(self):
        # 150 is the chunk size in _attach_names; this crosses two chunks.
        ids = [f"p{i}" for i in range(220)]
        sb = FakeSupabase([
            {"id": pid, "first_name": "T", "last_name": str(i)}
            for i, pid in enumerate(ids)
        ])
        proposals = [_group(*ids)]
        _attach_names(sb, proposals)
        assert len(proposals[0]["participants"]) == 220
        assert all(p["name"] != p["id"] for p in proposals[0]["participants"])
