"""
Tests for the mini event site above the registration form (§11).

One property dominates all the others: **this text is rendered on a page open
to the world with no login**. An organizer account that could store markup in it
would be a stored-XSS vector against every participant of the event, so most of
what follows is about what does NOT survive being stored.

After that, the rules are about not showing a participant a broken page: a
heading over nothing, a section in a language they do not read, an image URL
that a browser blocks.
"""

import pytest

from services import event_site as S


def _section(slug="welcome", **over):
    base = {
        "slug": slug,
        "title": {"fr": "Bienvenue"},
        "body": {"fr": "Bonjour et bienvenue."},
        "image_url": "",
        "visible": True,
    }
    base.update(over)
    return base


# ===========================================================================
# Nothing executable survives
# ===========================================================================

class TestTheBodyIsTextNotMarkup:

    def test_a_script_tag_does_not_survive(self):
        cleaned = S.clean_text("<script>alert(1)</script>Bonjour")
        assert "<" not in cleaned and "script" not in cleaned.lower()
        assert "Bonjour" in cleaned

    def test_an_event_handler_attribute_goes_with_its_tag(self):
        cleaned = S.clean_text('<img src=x onerror="alert(1)">Texte')
        assert "onerror" not in cleaned
        assert "Texte" in cleaned

    def test_tags_are_stripped_not_escaped(self):
        # An organizer who pastes <b> and sees it vanish learns the rule
        # immediately; markup that half-works teaches nothing.
        assert "&lt;" not in S.clean_text("<b>gras</b>")
        assert S.clean_text("<b>gras</b>") == "gras"

    def test_it_survives_a_body_that_is_only_markup(self):
        assert S.clean_text("<div><span></span></div>") == ""

    def test_a_very_long_body_is_truncated_rather_than_stored(self):
        assert len(S.clean_text("a" * 50_000)) == S.MAX_BODY

    def test_the_title_has_its_own_shorter_limit(self):
        assert len(S.clean_text("a" * 500, S.MAX_TITLE)) == S.MAX_TITLE


class TestImageUrls:

    def test_an_https_url_is_accepted(self):
        assert S.clean_image("https://cdn.example.com/a.jpg") == "https://cdn.example.com/a.jpg"

    def test_an_empty_url_is_fine(self):
        assert S.clean_image("") == ""
        assert S.clean_image(None) == ""

    @pytest.mark.parametrize("url", [
        "javascript:alert(1)",
        "data:image/svg+xml;base64,PHN2Zz48c2NyaXB0Pg==",
        "http://cdn.example.com/a.jpg",
        'https://x.com/a.jpg" onload="alert(1)',
    ])
    def test_anything_else_is_refused(self, url):
        with pytest.raises(S.EventSiteError):
            S.clean_image(url)


# ===========================================================================
# What gets stored
# ===========================================================================

class TestSanitising:

    def test_an_unknown_section_is_refused(self):
        with pytest.raises(S.EventSiteError):
            S.sanitise_section(_section(slug="pricing"))

    def test_the_position_comes_from_the_catalogue_not_the_client(self):
        # §11 lists the sections in a deliberate order; letting a client
        # reorder them would put Conditions above Welcome.
        assert S.sanitise_section(_section("conditions"))["position"] > \
               S.sanitise_section(_section("welcome"))["position"]

    def test_an_empty_language_is_dropped_rather_than_stored_blank(self):
        out = S.sanitise_section(_section(body={"fr": "Bonjour", "nl": "   "}))
        assert out["body"] == {"fr": "Bonjour"}

    def test_the_same_section_twice_keeps_the_last(self):
        out = S.sanitise_all([
            _section(body={"fr": "premier"}),
            _section(body={"fr": "second"}),
        ])
        assert len(out) == 1
        assert out[0]["body"]["fr"] == "second"

    def test_sections_come_back_in_the_catalogue_order(self):
        out = S.sanitise_all([_section("destination"), _section("welcome")])
        assert [s["slug"] for s in out] == ["welcome", "destination"]

    def test_an_empty_site_is_valid(self):
        assert S.sanitise_all([]) == []


# ===========================================================================
# What the visitor sees
# ===========================================================================

class TestRendering:

    def test_a_section_renders_its_title_and_paragraphs(self):
        out = S.render([_section(body={"fr": "Un.\n\nDeux."})], "fr")
        assert out[0]["title"] == "Bienvenue"
        assert out[0]["paragraphs"] == ["Un.", "Deux."]

    def test_a_hidden_section_is_not_shown(self):
        assert S.render([_section(visible=False)], "fr") == []

    def test_a_section_with_neither_text_nor_image_is_dropped(self):
        # A heading over nothing reads as a page that failed to load.
        assert S.render([_section(body={})], "fr") == []

    def test_a_section_with_only_an_image_is_kept(self):
        out = S.render([_section(body={}, image_url="https://x/a.jpg")], "fr")
        assert out[0]["image_url"] == "https://x/a.jpg"

    def test_an_unknown_slug_in_the_database_is_ignored(self):
        assert S.render([_section(slug="pricing")], "fr") == []

    def test_the_order_follows_the_catalogue_not_the_rows(self):
        rows = [_section("conditions"), _section("welcome"), _section("programme")]
        assert [s["slug"] for s in S.render(rows, "fr")] == \
               ["welcome", "programme", "conditions"]


class TestLanguages:

    def test_a_dutch_visitor_gets_the_dutch_text(self):
        rows = [_section(body={"fr": "Bonjour", "nl": "Hallo"})]
        assert S.render(rows, "nl")[0]["paragraphs"] == ["Hallo"]

    def test_an_untranslated_section_falls_back_rather_than_disappearing(self):
        # A participant reading a French paragraph on a Dutch page still reads
        # something; an empty section teaches them the site is broken.
        rows = [_section(body={"fr": "Bonjour"})]
        assert S.render(rows, "nl")[0]["paragraphs"] == ["Bonjour"]

    def test_a_missing_title_falls_back_to_the_catalogue_in_that_language(self):
        rows = [_section(title={}, body={"fr": "x"})]
        assert S.render(rows, "en")[0]["title"] == "Welcome"
        assert S.render(rows, "nl")[0]["title"] == "Welkom"

    def test_an_unsupported_language_resolves_to_french(self):
        rows = [_section(title={}, body={"fr": "x"})]
        assert S.render(rows, "de")[0]["title"] == "Bienvenue"

    def test_a_plain_string_title_from_an_older_row_still_renders(self):
        rows = [_section(title="Titre libre", body={"fr": "x"})]
        assert S.render(rows, "fr")[0]["title"] == "Titre libre"

    def test_every_catalogue_section_has_a_label_in_every_language(self):
        for code in ("fr", "nl", "en"):
            labels = {entry["label"] for entry in S.describe(code)}
            assert len(labels) == len(S.SECTIONS), code


# ===========================================================================
# What the organizer sees before sending the link
# ===========================================================================

class TestSummary:

    def test_it_counts_what_is_actually_written_per_language(self):
        rows = [
            _section("welcome", body={"fr": "Bonjour", "nl": "Hallo"}),
            _section("programme", body={"fr": "Programme"}),
        ]
        summary = S.summarise(rows)
        assert summary["written"] == {"fr": 2, "nl": 1, "en": 0}

    def test_rendered_counts_include_the_fallbacks(self):
        # Rendered equals written only when everything is translated — the two
        # numbers together are what tell an organizer there is work left.
        rows = [_section("welcome", body={"fr": "Bonjour"})]
        summary = S.summarise(rows)
        assert summary["rendered"]["nl"] == 1
        assert summary["written"]["nl"] == 0

    def test_it_counts_the_images(self):
        rows = [_section(image_url="https://x/a.jpg"), _section("programme")]
        assert S.summarise(rows)["with_image"] == 1

    def test_an_empty_site_summarises_without_crashing(self):
        assert S.summarise([])["sections"] == 0


# ===========================================================================
# Arranging the page (point 13)
# ===========================================================================

class TestSectionOrderIsTheOrganizersOwn:
    """The catalogue's order used to be the ONLY order: `position` was
    overwritten with it on every save, so moving Programme above Bienvenue
    was impossible. It is a default now, not a rule."""

    def test_a_supplied_position_is_kept(self):
        from services import event_site
        out = event_site.sanitise_all([
            {"slug": "programme", "position": 0, "body": {"fr": "P"}},
            {"slug": "welcome", "position": 1, "body": {"fr": "W"}},
        ])
        assert [s["slug"] for s in out] == ["programme", "welcome"]

    def test_without_a_position_the_catalogue_order_still_applies(self):
        from services import event_site
        out = event_site.sanitise_all([
            {"slug": "programme", "body": {"fr": "P"}},
            {"slug": "welcome", "body": {"fr": "W"}},
        ])
        assert [s["slug"] for s in out] == ["welcome", "programme"]

    @pytest.mark.parametrize("bad", ["x", None, -1, 1000, [], {}])
    def test_an_unusable_position_falls_back_to_the_catalogue(self, bad):
        # Falling back to 0 would pile every broken section at the top.
        from services import event_site
        out = event_site.sanitise_all([{"slug": "programme", "position": bad, "body": {"fr": "P"}}])
        assert out[0]["position"] == event_site._ORDER["programme"]

    def test_two_sections_claiming_the_same_slot_stay_stable(self):
        # Otherwise the page reshuffles itself on every save.
        from services import event_site
        payload = [
            {"slug": "conditions", "position": 3, "body": {"fr": "C"}},
            {"slug": "welcome", "position": 3, "body": {"fr": "W"}},
        ]
        first = [s["slug"] for s in event_site.sanitise_all(payload)]
        second = [s["slug"] for s in event_site.sanitise_all(list(reversed(payload)))]
        assert first == second == ["welcome", "conditions"]

    def test_the_public_page_honours_the_saved_order(self):
        from services import event_site
        rows = event_site.sanitise_all([
            {"slug": "programme", "position": 0, "body": {"fr": "P"}},
            {"slug": "welcome", "position": 1, "body": {"fr": "W"}},
        ])
        assert [s["slug"] for s in event_site.render(rows)] == ["programme", "welcome"]


class TestWhereThePhotoSits:
    def test_it_defaults_to_above_the_text(self):
        from services import event_site
        out = event_site.sanitise_all([{"slug": "welcome", "body": {"fr": "W"}}])
        assert out[0]["image_position"] == "above"

    def test_below_is_kept(self):
        from services import event_site
        out = event_site.sanitise_all([
            {"slug": "welcome", "body": {"fr": "W"}, "image_position": "below"}
        ])
        assert out[0]["image_position"] == "below"

    @pytest.mark.parametrize("bad", ["left", "", None, 42, "ABOVE "])
    def test_anything_else_falls_back_rather_than_breaking_the_page(self, bad):
        from services import event_site
        out = event_site.sanitise_all([
            {"slug": "welcome", "body": {"fr": "W"}, "image_position": bad}
        ])
        assert out[0]["image_position"] in event_site.IMAGE_POSITIONS

    def test_the_public_page_carries_it(self):
        from services import event_site
        rows = event_site.sanitise_all([
            {"slug": "welcome", "body": {"fr": "W"}, "image_url": "https://x/y.jpg",
             "image_position": "below"}
        ])
        assert event_site.render(rows)[0]["image_position"] == "below"

    def test_a_row_saved_before_migration_029_still_renders(self):
        # No image_position key at all — the page must not blank out.
        from services import event_site
        rendered = event_site.render([
            {"slug": "welcome", "body": {"fr": "W"}, "visible": True, "position": 0}
        ])
        assert rendered[0]["image_position"] == "above"
