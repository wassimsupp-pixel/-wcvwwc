"""
Tests for the provider chain, now that Claude sits at the front of it.

Adding a provider to a gateway four callers already depend on is the kind of
change that breaks things nowhere near itself. Three properties matter more
than any single call working:

  * **Nothing changes until it is configured.** With no ANTHROPIC_API_KEY, the
    chain must behave exactly as it did before — NVIDIA first, then OpenAI,
    then Gemini.
  * **A failure falls through, it does not surface.** Every provider here
    returns None rather than raising, because these calls sit behind screens an
    organizer is looking at.
  * **`model_override` is not forwarded blindly.** It already exists, and every
    caller passes an NVIDIA model id through it. Handing
    "nvidia/nemotron-3-nano-30b-a3b" to the Anthropic API 404s on every call —
    silently, since a 404 just falls through to the next provider, so the only
    symptom would be Claude never answering.
"""

import pytest

from services import ai_service as A


class _Response:
    """The shape `messages.create` returns, reduced to what the gateway reads."""

    def __init__(self, blocks, stop_reason="end_turn", stop_details=None):
        self.content = blocks
        self.stop_reason = stop_reason
        self.stop_details = stop_details


class _Block:
    def __init__(self, type_, text=""):
        self.type = type_
        self.text = text


class _Client:
    """Records what it was asked for, answers what it was told to."""

    def __init__(self, answer=None, raises=None):
        self.answer, self.raises = answer, raises
        self.calls = []

    def with_options(self, **kwargs):
        self.calls.append({"options": kwargs})
        return self

    @property
    def messages(self):
        return self

    def create(self, **kwargs):
        self.calls[-1].update(kwargs)
        if self.raises:
            raise self.raises
        return self.answer


@pytest.fixture(autouse=True)
def _clean(monkeypatch):
    """Every test starts with no provider configured and Claude re-enabled."""
    for key in ("ANTHROPIC_API_KEY", "NVIDIA_API_KEY", "OPENAI_API_KEY", "GEMINI_API_KEY"):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setattr(A, "_anthropic_disabled", False)
    monkeypatch.setattr(A, "_anthropic_client", None)


def use_claude(monkeypatch, client):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
    monkeypatch.setattr(A, "ANTHROPIC_SDK_AVAILABLE", True)
    monkeypatch.setattr(A, "_anthropic_client", client)
    return client


class TestNothingChangesUntilItIsConfigured:

    def test_without_a_key_claude_is_skipped_immediately(self):
        assert A._anthropic_complete("bonjour", None, None) is None

    def test_without_a_key_the_chain_is_the_old_one(self, monkeypatch):
        seen = []
        monkeypatch.setattr(A, "_nvidia_complete", lambda *a, **k: seen.append("nvidia") or "de nvidia")
        monkeypatch.setattr(A, "_openai_complete", lambda *a, **k: seen.append("openai"))
        monkeypatch.setattr(A, "_gemini_complete", lambda *a, **k: seen.append("gemini"))
        assert A.ai_text("bonjour") == "de nvidia"
        assert seen == ["nvidia"]

    def test_ai_available_counts_claude(self, monkeypatch):
        assert not A.ai_available()
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        monkeypatch.setattr(A, "ANTHROPIC_SDK_AVAILABLE", True)
        assert A.ai_available()

    def test_a_missing_sdk_reads_as_no_key(self, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        monkeypatch.setattr(A, "ANTHROPIC_SDK_AVAILABLE", False)
        assert A._anthropic_key() is None
        assert A._anthropic_complete("bonjour", None, None) is None


class TestClaudeGoesFirst:

    def test_it_answers_before_nvidia_is_asked(self, monkeypatch):
        use_claude(monkeypatch, _Client(_Response([_Block("text", "de claude")])))
        monkeypatch.setattr(A, "_nvidia_complete", lambda *a, **k: pytest.fail("NVIDIA ne doit pas être appelé"))
        assert A.ai_text("bonjour") == "de claude"

    def test_when_it_fails_nvidia_takes_over(self, monkeypatch):
        use_claude(monkeypatch, _Client(raises=RuntimeError("502")))
        monkeypatch.setattr(A, "_nvidia_complete", lambda *a, **k: "de nvidia")
        assert A.ai_text("bonjour") == "de nvidia"

    def test_thinking_blocks_never_reach_the_caller(self, monkeypatch):
        # The callers parse this text as JSON. Reasoning concatenated in front
        # of it would break every one of them.
        use_claude(monkeypatch, _Client(_Response([
            _Block("thinking", "je réfléchis..."),
            _Block("text", '{"ok": true}'),
        ])))
        assert A.ai_text("bonjour") == '{"ok": true}'

    def test_an_empty_answer_falls_through_rather_than_returning_blank(self, monkeypatch):
        use_claude(monkeypatch, _Client(_Response([_Block("text", "   ")])))
        monkeypatch.setattr(A, "_nvidia_complete", lambda *a, **k: "de nvidia")
        assert A.ai_text("bonjour") == "de nvidia"

    def test_a_refusal_falls_through_rather_than_returning_nothing(self, monkeypatch):
        use_claude(monkeypatch, _Client(_Response([], stop_reason="refusal")))
        monkeypatch.setattr(A, "_nvidia_complete", lambda *a, **k: "de nvidia")
        assert A.ai_text("bonjour") == "de nvidia"


class TestTheOverrideTrap:

    def test_an_nvidia_model_id_is_not_forwarded_to_anthropic(self, monkeypatch):
        client = use_claude(monkeypatch, _Client(_Response([_Block("text", "ok")])))
        A._anthropic_complete("bonjour", None, None, 30.0, "nvidia/nemotron-3-nano-30b-a3b")
        assert client.calls[-1]["model"] == A._ANTHROPIC_MODEL

    def test_a_claude_model_id_is_honoured(self, monkeypatch):
        client = use_claude(monkeypatch, _Client(_Response([_Block("text", "ok")])))
        A._anthropic_complete("bonjour", None, None, 30.0, "claude-haiku-4-5")
        assert client.calls[-1]["model"] == "claude-haiku-4-5"

    def test_nvidia_still_receives_its_own_override(self, monkeypatch):
        use_claude(monkeypatch, _Client(raises=RuntimeError("indisponible")))
        seen = {}

        def nvidia(prompt, image, mime, timeout=None, model_override=None):
            seen["model"] = model_override
            return "de nvidia"

        monkeypatch.setattr(A, "_nvidia_complete", nvidia)
        A.ai_text("bonjour", model_override="nvidia/nemotron-3-nano-30b-a3b")
        assert seen["model"] == "nvidia/nemotron-3-nano-30b-a3b"


class TestTheRequestItself:

    def test_the_callers_timeout_is_respected(self, monkeypatch):
        client = use_claude(monkeypatch, _Client(_Response([_Block("text", "ok")])))
        A._anthropic_complete("bonjour", None, None, 12.5)
        assert client.calls[-1]["options"]["timeout"] == 12.5

    def test_an_image_is_sent_as_a_base64_block(self, monkeypatch):
        client = use_claude(monkeypatch, _Client(_Response([_Block("text", "une affiche")])))
        A._anthropic_complete("que vois-tu ?", b"\x89PNG fake", "image/jpeg")
        content = client.calls[-1]["messages"][0]["content"]
        image = next(b for b in content if b["type"] == "image")
        assert image["source"]["type"] == "base64"
        assert image["source"]["media_type"] == "image/jpeg"
        assert "\x89PNG" not in image["source"]["data"]      # encoded, not raw

    def test_an_image_without_a_type_defaults_to_png(self, monkeypatch):
        client = use_claude(monkeypatch, _Client(_Response([_Block("text", "ok")])))
        A._anthropic_complete("?", b"data", None)
        content = client.calls[-1]["messages"][0]["content"]
        assert next(b for b in content if b["type"] == "image")["source"]["media_type"] == "image/png"

    def test_effort_is_sent_and_configurable(self, monkeypatch):
        client = use_claude(monkeypatch, _Client(_Response([_Block("text", "ok")])))
        A._anthropic_complete("bonjour", None, None)
        assert client.calls[-1]["output_config"] == {"effort": A._ANTHROPIC_EFFORT}


class TestABadKeyStopsAsking:

    def test_authentication_failure_disables_claude_for_the_process(self, monkeypatch):
        import anthropic

        error = anthropic.AuthenticationError(
            "clé refusée", response=_FakeHTTP(401), body=None,
        )
        use_claude(monkeypatch, _Client(raises=error))
        assert A._anthropic_complete("bonjour", None, None) is None
        assert A._anthropic_disabled is True
        # And a second call does not even build a request.
        assert A._anthropic_key() is None


class _FakeHTTP:
    """Enough of an httpx response for the SDK's error constructors."""

    def __init__(self, status_code):
        self.status_code = status_code
        self.headers = {}
        self.request = None
