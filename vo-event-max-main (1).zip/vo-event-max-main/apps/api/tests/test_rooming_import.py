"""
Tests for reading the hotel's own file back in, and for the default room type
that replaced the starting number on screen.

The property under test throughout is that a wrong guess is impossible to make
silently. Every one of these could be "solved" by a scoring function that
always returns an answer, and every one of those answers would be a person
knocking on the wrong door at midnight. So:

  * a line that fits two fiches fits neither;
  * a line the file names twice is reported, not overwritten;
  * a column we are unsure about is refused rather than assumed;
  * and nothing at all is written by the reading step.
"""

import io

import pytest

from services import rooming_import as I
from services import room_service, rooming_plan


def _p(pid, first, last, **over):
    base = {
        "id": pid, "first_name": first, "last_name": last, "email": "",
        "room_number": None, "room_type": None, "roommate_participant_id": None,
    }
    base.update(over)
    return base


def _csv(text: str) -> bytes:
    return text.encode("utf-8")


# ===========================================================================
# Reading what a hotel actually sends
# ===========================================================================

class TestColumnsAreRecognised:
    """Three countries, three vocabularies, one rooming list."""

    def test_french_headers(self):
        found = I.detect_columns(["Nom", "Prénom", "N° de chambre", "Type de chambre"])
        assert found["last_name"] == "Nom"
        assert found["first_name"] == "Prénom"
        assert found["room_number"] == "N° de chambre"
        assert found["room_type"] == "Type de chambre"

    def test_english_headers(self):
        found = I.detect_columns(["Guest name", "Room number", "Room type", "Email"])
        assert found["full_name"] == "Guest name"
        assert found["room_number"] == "Room number"
        assert found["room_type"] == "Room type"
        assert found["email"] == "Email"

    def test_dutch_headers(self):
        found = I.detect_columns(["Achternaam", "Voornaam", "Kamernummer"])
        assert found["last_name"] == "Achternaam"
        assert found["first_name"] == "Voornaam"
        assert found["room_number"] == "Kamernummer"

    def test_the_type_column_does_not_steal_the_number_column(self):
        """"Type de chambre" contains "chambre". Reading it as the room number
        would put the word "double" on every door in the hotel."""
        found = I.detect_columns(["Nom", "Type de chambre", "Chambre"])
        assert found["room_number"] == "Chambre"
        assert found["room_type"] == "Type de chambre"

    def test_prenom_is_not_read_as_nom(self):
        """"prenom" ends in "nom", and a substring match alone swaps the two."""
        found = I.detect_columns(["Prénom", "Nom", "Chambre"])
        assert found["first_name"] == "Prénom"
        assert found["last_name"] == "Nom"

    def test_a_column_is_claimed_once(self):
        found = I.detect_columns(["Name", "Room"])
        assert len({found["full_name"], found["room_number"]}) == 2


class TestValuesAreCleaned:
    def test_excel_float_becomes_a_room_number(self):
        """Excel decides a column of 304s is numeric; a driver knocking on
        "304.0" is a support call."""
        assert I.clean_number("304.0") == "304"

    def test_a_hotels_own_labels_survive(self):
        assert I.clean_number("B-12") == "B-12"
        assert I.clean_number("1204a") == "1204a"

    def test_blanks_read_as_nothing(self):
        for value in (None, "", "  ", "nan", "N/A", "-"):
            assert I.clean_number(value) == ""

    def test_types_are_mapped_where_we_know_them(self):
        assert I.clean_type("Twin room") == "twin"
        assert I.clean_type("DBL") == "double"
        assert I.clean_type("Chambre individuelle") == "single"

    def test_an_unknown_type_is_kept_rather_than_dropped(self):
        assert I.clean_type("Deluxe King") == "Deluxe King"


class TestReadingTheFile:
    def test_a_csv_becomes_rows_that_know_their_line_number(self):
        rows, mapping = I.read_file(
            _csv("Nom,Prénom,Chambre\nFey,Tina,304\nKnope,Leslie,305\n"),
            "hotel.csv",
        )
        assert [r["row"] for r in rows] == [2, 3]
        assert rows[0]["last_name"] == "Fey"
        assert rows[0]["room_number"] == "304"
        assert mapping["room_number"] == "Chambre"

    def test_a_full_name_column_is_split(self):
        rows, _ = I.read_file(_csv("Guest,Room\nTina Fey,304\n"), "hotel.csv")
        assert rows[0]["first_name"] == "Tina"
        assert rows[0]["last_name"] == "Fey"

    def test_an_empty_name_cell_does_not_become_a_guest_called_nan(self):
        """Found on the live event. pandas str-casts an empty cell to "nan";
        the line matched the right person by email and the preview labelled
        them nan, which is unrecognisable to whoever has to check the list."""
        rows, _ = I.read_file(
            _csv("Guest,Room,Email\n,410,natalie.bailey@livanova.com\n"),
            "hotel.csv",
        )
        assert rows[0]["first_name"] == ""
        assert rows[0]["last_name"] == ""
        assert rows[0]["email"] == "natalie.bailey@livanova.com"

    def test_an_empty_email_cell_is_empty_not_nan(self):
        rows, _ = I.read_file(_csv("Guest,Room,Email\nTina Fey,304,\n"), "hotel.csv")
        assert rows[0]["email"] == ""

    def test_a_line_with_only_an_email_still_matches(self):
        """The whole point of tolerating the blank name."""
        rows, _ = I.read_file(
            _csv("Guest,Room,Email\n,410,tina@x.com\n"), "hotel.csv"
        )
        out = I.match(rows, [_p("t", "Tina", "Fey", email="tina@x.com")])
        assert out["lines"][0]["status"] == I.MATCHED
        assert out["lines"][0]["name"] == ""

    def test_a_file_without_a_room_column_is_refused(self):
        with pytest.raises(I.RoomingImportError):
            I.read_file(_csv("Nom,Prénom\nFey,Tina\n"), "hotel.csv")

    def test_a_file_without_a_name_or_email_is_refused(self):
        """A column of room numbers and nothing else says which rooms exist,
        not who is in them."""
        with pytest.raises(I.RoomingImportError):
            I.read_file(_csv("Chambre,Étage\n304,3\n"), "hotel.csv")


# ===========================================================================
# Matching — where a wrong answer is worse than no answer
# ===========================================================================

class TestMatching:
    def test_an_email_matches(self):
        rows = [{"row": 2, "first_name": "", "last_name": "", "email": "tina@x.com",
                 "room_number": "304", "room_type": ""}]
        out = I.match(rows, [_p("t", "Tina", "Fey", email="tina@x.com")])
        assert out["lines"][0]["status"] == I.MATCHED
        assert out["lines"][0]["participant_id"] == "t"

    def test_a_name_matches(self):
        rows = [{"row": 2, "first_name": "Tina", "last_name": "Fey", "email": "",
                 "room_number": "304", "room_type": ""}]
        out = I.match(rows, [_p("t", "Tina", "Fey")])
        assert out["lines"][0]["status"] == I.MATCHED

    def test_a_reversed_name_matches(self):
        """The hotel writes "FEY Tina"; the registration file wrote "Tina Fey".
        Which half is the surname is a property of the file, not the person."""
        rows = [{"row": 2, "first_name": "Fey", "last_name": "Tina", "email": "",
                 "room_number": "304", "room_type": ""}]
        out = I.match(rows, [_p("t", "Tina", "Fey")])
        assert out["lines"][0]["status"] == I.MATCHED
        assert out["lines"][0]["participant_id"] == "t"

    def test_accents_and_case_do_not_break_a_match(self):
        rows = [{"row": 2, "first_name": "jose", "last_name": "GARCIA", "email": "",
                 "room_number": "304", "room_type": ""}]
        out = I.match(rows, [_p("g", "José", "García")])
        assert out["lines"][0]["status"] == I.MATCHED

    def test_two_fiches_with_the_same_name_match_neither(self):
        rows = [{"row": 2, "first_name": "Tina", "last_name": "Fey", "email": "",
                 "room_number": "304", "room_type": ""}]
        out = I.match(rows, [_p("a", "Tina", "Fey"), _p("b", "Tina", "Fey")])
        assert out["lines"][0]["status"] == I.AMBIGUOUS
        assert out["lines"][0]["participant_id"] == ""

    def test_a_stranger_is_reported_not_invented(self):
        rows = [{"row": 2, "first_name": "Ron", "last_name": "Swanson", "email": "",
                 "room_number": "304", "room_type": ""}]
        out = I.match(rows, [_p("t", "Tina", "Fey")])
        assert out["lines"][0]["status"] == I.UNKNOWN

    def test_the_same_person_twice_is_a_duplicate_not_an_overwrite(self):
        """A split stay listed as two lines would otherwise write the second
        number over the first, silently and in that order."""
        rows = [
            {"row": 2, "first_name": "Tina", "last_name": "Fey", "email": "",
             "room_number": "304", "room_type": ""},
            {"row": 3, "first_name": "Tina", "last_name": "Fey", "email": "",
             "room_number": "410", "room_type": ""},
        ]
        out = I.match(rows, [_p("t", "Tina", "Fey")])
        assert [l["status"] for l in out["lines"]] == [I.MATCHED, I.DUPLICATE]

    def test_a_number_already_on_the_fiche_is_not_a_change(self):
        rows = [{"row": 2, "first_name": "Tina", "last_name": "Fey", "email": "",
                 "room_number": "304", "room_type": ""}]
        out = I.match(rows, [_p("t", "Tina", "Fey", room_number="304")])
        assert out["lines"][0]["status"] == I.UNCHANGED

    def test_the_same_number_with_a_new_type_is_still_a_change(self):
        rows = [{"row": 2, "first_name": "Tina", "last_name": "Fey", "email": "",
                 "room_number": "304", "room_type": "double"}]
        out = I.match(rows, [_p("t", "Tina", "Fey", room_number="304", room_type="single")])
        assert out["lines"][0]["status"] == I.MATCHED

    def test_a_line_with_no_number_is_unusable(self):
        rows = [{"row": 2, "first_name": "Tina", "last_name": "Fey", "email": "",
                 "room_number": "", "room_type": ""}]
        out = I.match(rows, [_p("t", "Tina", "Fey")])
        assert out["lines"][0]["status"] == I.INVALID

    def test_the_summary_counts_every_line(self):
        rows = [
            {"row": 2, "first_name": "Tina", "last_name": "Fey", "email": "",
             "room_number": "304", "room_type": ""},
            {"row": 3, "first_name": "Ron", "last_name": "Swanson", "email": "",
             "room_number": "305", "room_type": ""},
        ]
        out = I.match(rows, [_p("t", "Tina", "Fey")])
        assert out["summary"]["rows"] == 2
        assert out["summary"][I.MATCHED] == 1
        assert out["summary"][I.UNKNOWN] == 1


# ===========================================================================
# The default room type — the option that replaced the starting number
# ===========================================================================

class TestDefaultRoomType:
    """The one option on that screen with an invoice attached."""

    def test_a_lone_participant_defaults_to_single(self):
        rooms = room_service.occupancy([_p("a", "Ada", "Lovelace")])
        assert rooms[0]["room_type"] == "single"

    def test_a_lone_participant_can_default_to_double(self):
        rooms = room_service.occupancy(
            [_p("a", "Ada", "Lovelace")], default_room_type="double"
        )
        assert rooms[0]["room_type"] == "double"

    def test_a_declared_type_is_never_overridden(self):
        rooms = room_service.occupancy(
            [_p("a", "Ada", "Lovelace", room_type="suite")], default_room_type="double"
        )
        assert rooms[0]["room_type"] == "suite"

    def test_two_roommates_are_never_booked_as_a_single(self):
        """The default answers "what for somebody who never told us". A
        confirmed pair has already told us something it cannot contradict."""
        pair = [
            _p("a", "Tina", "Fey", roommate_participant_id="b"),
            _p("b", "Leslie", "Knope", roommate_participant_id="a"),
        ]
        rooms = room_service.occupancy(pair, default_room_type="single")
        assert rooms[0]["occupancy"] == 2
        assert rooms[0]["room_type"] == "twin"

    def test_the_planner_passes_it_through(self):
        out = rooming_plan.plan(
            [_p("a", "Ada", "Lovelace")], default_room_type="double"
        )
        assert out["rooms"][0]["room_type"] == "double"

    def test_the_generated_list_still_gets_its_numbers(self):
        """Removing the input from the screen must not remove the numbering."""
        out = rooming_plan.plan([_p("a", "Ada", "Lovelace")], default_room_type="double")
        assert out["rooms"][0]["room_number"] == "101"


class TestPresetsCarryTheType:
    def test_a_saved_preset_keeps_its_room_type(self):
        presets = rooming_plan.resolve_presets(
            [{"name": "Hôtel B", "start_number": 301, "prefix": "B-", "room_type": "double"}]
        )
        assert presets[0]["room_type"] == "double"

    def test_a_preset_saved_before_the_option_existed_still_loads(self):
        """It meant "single" — that was the only behaviour available."""
        presets = rooming_plan.resolve_presets(
            [{"name": "Hôtel A", "start_number": 101, "prefix": ""}]
        )
        assert presets[0]["room_type"] == "single"

    def test_a_nonsense_type_falls_back_rather_than_dropping_the_preset(self):
        presets = rooming_plan.resolve_presets(
            [{"name": "X", "start_number": 101, "prefix": "", "room_type": "yurt"}]
        )
        assert presets[0]["room_type"] == "single"


# ===========================================================================
# Whose number is it, after a generation has written its own back
# ===========================================================================

class TestGeneratingDoesNotForgetWhoseNumbersTheseAre:
    """The distinction the whole of regeneration rests on.

    A generation writes its numbers onto the fiches. On the next read the fiche
    carries a number and looks, to a test that only asks "is there a number
    here?", exactly like a fiche the hotel numbered. Room 101 came back
    `generated` in the stored version and `hotel` when re-derived one second
    later: "Numéros de l'hôtel" reported 81 on an event where the hotel had
    given none, and `renumber` would have refused to renumber anything at all,
    permanently — it declines to touch the hotel's numbers, and by then they
    were all "the hotel's".
    """

    def _first_pass(self, people):
        out = rooming_plan.plan(people)
        # What the real code does next: the numbers land on the fiches.
        by_id = {p["id"]: p for p in people}
        for pid, number in rooming_plan.assignments(out).items():
            by_id[pid]["room_number"] = number
        return out

    def test_a_number_we_generated_is_still_ours_on_the_next_read(self):
        people = [_p("a", "Ada", "Lovelace")]
        first = self._first_pass(people)
        again = rooming_plan.plan(people, previous=first)
        assert again["rooms"][0]["origin"] == rooming_plan.GENERATED
        assert again["summary"]["hotel_numbers"] == 0
        assert again["summary"]["generated_numbers"] == 1

    def test_a_number_the_hotel_really_gave_is_still_theirs(self):
        people = [_p("a", "Ada", "Lovelace", room_number="B-12")]
        out = rooming_plan.plan(people)
        assert out["rooms"][0]["origin"] == rooming_plan.FROM_HOTEL
        again = rooming_plan.plan(people, previous=out)
        assert again["rooms"][0]["origin"] == rooming_plan.FROM_HOTEL

    def test_a_hotel_number_overwriting_ours_reads_as_the_hotels(self):
        """The import wrote a real number over one of ours. It is theirs now."""
        people = [_p("a", "Ada", "Lovelace")]
        first = self._first_pass(people)
        people[0]["room_number"] = "412"
        again = rooming_plan.plan(people, previous=first)
        assert again["rooms"][0]["origin"] == rooming_plan.FROM_HOTEL

    def test_renumbering_still_moves_our_own_numbers(self):
        """The consequence that mattered: with everything reading as the
        hotel's, this option had quietly become a no-op."""
        people = [_p("a", "Ada", "Lovelace")]
        first = self._first_pass(people)
        out = rooming_plan.plan(people, previous=first, start_number=301, renumber=True)
        assert out["rooms"][0]["origin"] == rooming_plan.GENERATED


class TestTheHotelColumnIsFilled:
    """Every row read "—". Nothing ever put a name there: rooms take
    `hotel_name` off the participant, participants have no such column, and the
    nights that DO know the hotel were fetched without their `hotel_id`."""

    def _night(self, pid, day, hotel):
        return {"participant_id": pid, "night_date": day, "hotel_id": hotel}

    def test_the_name_comes_from_the_nights(self):
        rooms = room_service.occupancy(
            [_p("a", "Ada", "Lovelace")],
            [self._night("a", "2026-09-01", "h1")],
            hotel_names={"h1": "Ibis Athens"},
        )
        assert rooms[0]["hotel_name"] == "Ibis Athens"

    def test_without_a_map_it_is_empty_rather_than_wrong(self):
        rooms = room_service.occupancy(
            [_p("a", "Ada", "Lovelace")], [self._night("a", "2026-09-01", "h1")]
        )
        assert rooms[0]["hotel_name"] == ""

    def test_two_hotels_land_on_the_right_rooms(self):
        rooms = room_service.occupancy(
            [_p("a", "Ada", "L"), _p("b", "Bob", "M")],
            [self._night("a", "2026-09-01", "h1"), self._night("b", "2026-09-01", "h2")],
            hotel_names={"h1": "Ibis", "h2": "Hilton"},
        )
        got = {r["occupants"][0]["name"]: r["hotel_name"] for r in rooms}
        assert got == {"Ada L": "Ibis", "Bob M": "Hilton"}

    def test_roommates_share_their_hotel(self):
        pair = [
            _p("a", "Tina", "Fey", roommate_participant_id="b"),
            _p("b", "Leslie", "Knope", roommate_participant_id="a"),
        ]
        rooms = room_service.occupancy(
            pair, [self._night("a", "2026-09-01", "h1"), self._night("b", "2026-09-01", "h1")],
            hotel_names={"h1": "Ibis"},
        )
        assert rooms[0]["occupancy"] == 2
        assert rooms[0]["hotel_name"] == "Ibis"


class TestTheTwoCountsAccountForEveryRoom:
    """They are a pair, and a pair that does not add up is worse than either
    number alone: the screen shows both beside a room total."""

    def test_ours_plus_theirs_is_every_room(self):
        people = [
            _p("a", "Ada", "Lovelace"),
            _p("b", "Bob", "Martin", room_number="B-12"),
        ]
        out = rooming_plan.plan(people)
        s = out["summary"]
        assert s["generated_numbers"] + s["hotel_numbers"] == s["rooms"] == 2

    def test_it_still_adds_up_on_the_second_generation(self):
        people = [_p("a", "Ada", "Lovelace")]
        first = rooming_plan.plan(people)
        for pid, number in rooming_plan.assignments(first).items():
            people[0]["room_number"] = number
        again = rooming_plan.plan(people, previous=first)
        s = again["summary"]
        assert s["generated_numbers"] + s["hotel_numbers"] == s["rooms"] == 1

    def test_how_many_this_run_invented_is_reported_separately(self):
        people = [_p("a", "Ada", "Lovelace")]
        first = rooming_plan.plan(people)
        assert first["summary"]["newly_numbered"] == 1
        for pid, number in rooming_plan.assignments(first).items():
            people[0]["room_number"] = number
        again = rooming_plan.plan(people, previous=first)
        assert again["summary"]["newly_numbered"] == 0
        assert again["summary"]["generated_numbers"] == 1


class TestTheBannerCanAlwaysExplainItself:
    """"Les données ont changé depuis la version 1 — Aucun changement."

    Seen live. Staleness is decided on the fingerprint, which covers the hotel
    and the room type; the diff only knew about who moved and who shared with
    whom. So the screen announced a change and then listed none, which teaches
    a reader to stop believing the banner.
    """

    def _payload(self, **over):
        room = {
            "room_number": "101", "room_type": "single", "hotel_name": "Ibis",
            "occupants": [{"participant_id": "a", "name": "Ada Lovelace"}],
        }
        room.update(over)
        return {"rooms": [room]}

    def test_a_changed_hotel_is_reported(self):
        got = rooming_plan.differences(self._payload(), self._payload(hotel_name="Hilton"))
        assert [c["kind"] for c in got] == ["hotel_changed"]
        assert got[0]["from"] == "Ibis" and got[0]["to"] == "Hilton"

    def test_a_changed_type_is_reported(self):
        got = rooming_plan.differences(self._payload(), self._payload(room_type="double"))
        assert [c["kind"] for c in got] == ["type_changed"]

    def test_a_move_still_outranks_them(self):
        """Somebody changing room matters more than the label on the room."""
        got = rooming_plan.differences(
            self._payload(), self._payload(room_number="204", hotel_name="Hilton")
        )
        assert [c["kind"] for c in got] == ["moved"]

    def test_an_unchanged_list_still_reports_nothing(self):
        assert rooming_plan.differences(self._payload(), self._payload()) == []

    def test_the_sentence_names_them(self):
        got = rooming_plan.differences(self._payload(), self._payload(hotel_name="Hilton"))
        assert "hôtel" in rooming_plan.describe(got)


class TestTheListLeadsWithTheRoomsThatSaySomething:
    """Sorting on the hotel name alone put the empty string first, so the
    document opened with the twenty-one people nobody has housed — no hotel,
    no dates, no nights — and the real rooming list started a screen down."""

    def _people(self):
        return [
            _p("a", "Ada", "Lovelace"),      # housed
            _p("b", "Bob", "Martin"),        # not housed
        ]

    def test_a_housed_room_comes_before_an_unhoused_one(self):
        out = rooming_plan.plan(
            self._people(),
            [{"participant_id": "a", "night_date": "2026-09-01", "hotel_id": "h1"}],
            hotel_names={"h1": "Ibis"},
        )
        assert [r["occupants"][0]["name"] for r in out["rooms"]] == ["Ada Lovelace", "Bob Martin"]

    def test_hotels_still_group_together_and_number_in_order(self):
        people = [_p(x, x.upper(), "X") for x in ("a", "b", "c")]
        nights = [
            {"participant_id": "a", "night_date": "2026-09-01", "hotel_id": "h2"},
            {"participant_id": "b", "night_date": "2026-09-01", "hotel_id": "h1"},
            {"participant_id": "c", "night_date": "2026-09-01", "hotel_id": "h1"},
        ]
        out = rooming_plan.plan(people, nights, hotel_names={"h1": "Alpha", "h2": "Beta"})
        assert [r["hotel_name"] for r in out["rooms"]] == ["Alpha", "Alpha", "Beta"]
