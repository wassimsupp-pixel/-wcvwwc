"""
Tests for detecting people whose flights fall outside the programme's dates.

This is NOT the same question as "no return flight". These people HAVE a
return — it simply leaves after the event is over, or they land before it
starts. Either way there are nights the client never booked, and if nobody
decides who is paying for them the hotel invoice decides it by default.

The dangerous failure here is a false positive: telling an organiser that
forty people are on a private holiday when in fact the event's dates were
never filled in. So the check refuses to run at all without programme dates.
"""

from datetime import date

import pytest

from services import travel_checks as TC

P1 = "p0000000-0000-0000-0000-000000000001"
P2 = "p0000000-0000-0000-0000-000000000002"

START = date(2026, 8, 26)
END = date(2026, 8, 28)


def flight(pid, day, status="scheduled"):
    return {"participant_id": pid, "departure_time": f"{day}T10:00:00", "status": status}


class TestNothingToReport:
    def test_somebody_on_the_programme_dates_is_not_flagged(self):
        got = TC.staying_at_own_expense(
            [flight(P1, "2026-08-26"), flight(P1, "2026-08-28")], START, END
        )
        assert got == []

    @pytest.mark.parametrize("start,end", [
        (None, END), (START, None), (None, None),
        # An end that is not after the start is not a programme, it is a typo.
        (date(2026, 8, 28), date(2026, 8, 26)),
        (START, START),
    ])
    def test_without_usable_programme_dates_nothing_is_reported(self, start, end):
        # The false positive this avoids is the expensive one: announcing that
        # everybody is on a private holiday because nobody set the dates.
        got = TC.staying_at_own_expense(
            [flight(P1, "2026-09-15")], start, end
        )
        assert got == []

    def test_no_flights_means_nothing(self):
        assert TC.staying_at_own_expense([], START, END) == []

    def test_a_cancelled_late_return_is_not_a_stay(self):
        got = TC.staying_at_own_expense(
            [flight(P1, "2026-08-26"), flight(P1, "2026-09-02", status="cancelled")],
            START, END,
        )
        assert got == []

    def test_a_participant_with_only_cancelled_segments_is_skipped(self):
        got = TC.staying_at_own_expense(
            [flight(P1, "2026-09-02", status="cancelled")], START, END
        )
        assert got == []

    def test_a_segment_with_no_usable_date_is_skipped(self):
        got = TC.staying_at_own_expense(
            [{"participant_id": P1, "departure_time": None, "status": "scheduled"}],
            START, END,
        )
        assert got == []


class TestStayingLate:
    def test_a_return_after_the_end_is_flagged(self):
        got = TC.staying_at_own_expense(
            [flight(P1, "2026-08-26"), flight(P1, "2026-08-31")], START, END
        )
        assert len(got) == 1
        assert got[0]["stays_late_days"] == 3
        assert got[0]["arrives_early_days"] == 0
        assert got[0]["extra_nights"] == 3
        assert got[0]["last_departure"] == "2026-08-31"

    def test_the_day_the_event_ends_is_not_late(self):
        # The programme runs to its end day; leaving on it is being on time.
        got = TC.staying_at_own_expense(
            [flight(P1, "2026-08-26"), flight(P1, "2026-08-28")], START, END
        )
        assert got == []


class TestArrivingEarly:
    def test_an_arrival_before_the_start_is_the_same_question(self):
        # A night before the programme is as much "a night nobody booked" as
        # a night after it.
        got = TC.staying_at_own_expense(
            [flight(P1, "2026-08-24"), flight(P1, "2026-08-28")], START, END
        )
        assert got[0]["arrives_early_days"] == 2
        assert got[0]["stays_late_days"] == 0
        assert got[0]["extra_nights"] == 2

    def test_both_ends_are_counted_together(self):
        got = TC.staying_at_own_expense(
            [flight(P1, "2026-08-24"), flight(P1, "2026-08-30")], START, END
        )
        assert got[0]["arrives_early_days"] == 2
        assert got[0]["stays_late_days"] == 2
        assert got[0]["extra_nights"] == 4


class TestSeveralPeople:
    def test_each_person_is_assessed_on_their_own_flights(self):
        got = TC.staying_at_own_expense(
            [
                flight(P1, "2026-08-26"), flight(P1, "2026-08-31"),
                flight(P2, "2026-08-26"), flight(P2, "2026-08-28"),
            ],
            START, END,
        )
        assert [g["participant_id"] for g in got] == [P1]


class TestWording:
    def test_the_individual_message_names_the_person_and_the_nights(self):
        gap = TC.staying_at_own_expense(
            [flight(P1, "2026-08-26"), flight(P1, "2026-08-31")], START, END
        )[0]
        text = TC.describe_staying("Gavin Griffiths", gap)
        assert "Gavin Griffiths" in text
        assert "3 nuit(s)" in text

    def test_an_early_arrival_reads_as_an_arrival_not_a_departure(self):
        gap = TC.staying_at_own_expense(
            [flight(P1, "2026-08-24"), flight(P1, "2026-08-28")], START, END
        )[0]
        text = TC.describe_staying("Kristina Tomas", gap)
        assert "avant le début" in text
        assert "après la fin" not in text

    def test_the_systemic_message_says_it_once_for_the_group(self):
        text = TC.describe_staying_systemic(40, 44, 92)
        assert "40" in text and "44" in text and "92" in text
        assert "leurs frais" in text
