"""
Tests for making the change log readable (feedback §19).

Two properties carry the feature, and both are about honesty rather than
features:

  * an origin that was RECORDED and one that was RECONSTRUCTED must never look
    alike on screen — only the first settles an argument about who changed a
    passport number;
  * an audit trail must not become a second copy of the sensitive data it
    audits (§23).
"""

import pytest

from services import history_service as H


def _row(**over):
    base = {
        "id": "c1", "changed_at": "2027-03-01T10:00:00Z",
        "user_id": "u1", "entity_type": "participant", "entity_id": "p1",
        "field_name": "phone", "old_value": "+3210", "new_value": "+3211",
        "change_reason": "manual_edit", "source": None,
    }
    base.update(over)
    return base


USERS = {"u1": "Marie Dupont"}
PEOPLE = {"p1": "Sophie Marceau"}


# ===========================================================================
# Where a change came from
# ===========================================================================

class TestOrigin:

    def test_a_recorded_origin_is_used_as_is(self):
        assert H.infer(_row(source="fcm_upload")) == ("fcm_upload", False)

    def test_a_recorded_origin_is_never_second_guessed(self):
        # The writer knew more than we can reconstruct afterwards, even when
        # the reason code suggests something else.
        row = _row(source="hotel_file", change_reason="manual_edit")
        assert H.infer(row) == ("hotel_file", False)

    def test_an_old_row_is_reconstructed_and_says_so(self):
        assert H.infer(_row()) == ("manual_update", True)

    def test_a_reason_nobody_mapped_stays_unknown(self):
        # "import" alone cannot tell an FCM export from a hotel spreadsheet.
        # A confident wrong word in an audit trail is worse than no word.
        assert H.infer(_row(change_reason="import")) == ("unknown", True)

    def test_an_unrecognised_stored_value_renders_rather_than_crashes(self):
        origin, inferred = H.infer(_row(source="something_new"))
        assert origin == "unknown"
        assert inferred is False
        assert H.LABELS[origin]

    @pytest.mark.parametrize("reason,expected", [
        ("manual_edit", "manual_update"),
        ("human_arbitration", "manual_update"),
        ("lock", "manual_update"),
        ("unlock", "manual_update"),
        ("email_agent", "ai_suggestion"),
        ("rooming_list_generated", "system"),
    ])
    def test_the_reason_codes_the_codebase_writes_are_all_mapped(self, reason, expected):
        assert H.infer(_row(change_reason=reason))[0] == expected

    def test_every_file_kind_maps_to_one_of_the_feedbacks_sources(self):
        for source_type, origin in H.FROM_SOURCE_TYPE.items():
            assert origin in H.LABELS, source_type


# ===========================================================================
# What appears on screen
# ===========================================================================

class TestReadableLines:

    def test_it_names_the_user_and_the_participant(self):
        line = H.readable([_row()], USERS, PEOPLE)[0]
        assert line["user"] == "Marie Dupont"
        assert line["participant"] == "Sophie Marceau"

    def test_an_unknown_user_falls_back_to_the_id_not_to_nothing(self):
        # A line that names nobody is not an audit line.
        line = H.readable([_row(user_id="u9")], USERS, PEOPLE)[0]
        assert line["user"] == "u9"

    def test_the_field_gets_a_human_label(self):
        assert H.readable([_row()])[0]["field_label"] == "Téléphone"

    def test_a_lock_reads_as_a_lock_not_as_a_field_change(self):
        line = H.readable([_row(field_name="locked_fields.email")])[0]
        assert line["field_label"] == "Verrou — Adresse email"

    def test_the_source_carries_its_label_and_its_confidence(self):
        line = H.readable([_row(source="fcm_upload")])[0]
        assert line["source_label"] == "Import FCM"
        assert line["source_inferred"] is False

    def test_both_values_are_shown_for_an_ordinary_field(self):
        line = H.readable([_row()])[0]
        assert (line["old_value"], line["new_value"]) == ("+3210", "+3211")


class TestSensitiveValuesAreNotReprinted:
    """The log holds a passport number because that is what changed. A screen
    that reprints it makes a second copy of the data (§23)."""

    @pytest.mark.parametrize("field", [
        "passport_number", "date_of_birth", "medical_info",
        "dietary_requirements", "emergency_contact_phone",
    ])
    def test_the_value_is_masked(self, field):
        line = H.readable([_row(field_name=field, old_value="AB123", new_value="CD456")])[0]
        assert line["old_value"] == "•••"
        assert line["new_value"] == "•••"
        assert line["masked"] is True

    def test_the_change_itself_is_still_reported(self):
        line = H.readable([_row(field_name="passport_number")])[0]
        assert line["field_label"] == "Numéro de passeport"
        assert line["user"]

    def test_an_empty_value_stays_empty_rather_than_becoming_dots(self):
        # "was blank, now •••" reads as a change; "•••  →  •••" hides that the
        # field was filled in for the first time.
        line = H.readable([_row(field_name="passport_number", old_value="", new_value="X")])[0]
        assert line["old_value"] == ""
        assert line["new_value"] == "•••"

    def test_masking_follows_the_field_through_a_lock(self):
        line = H.readable([_row(field_name="locked_fields.passport_number", new_value="true")])[0]
        assert line["new_value"] == "•••"

    def test_an_ordinary_field_is_not_masked(self):
        assert H.readable([_row()])[0]["masked"] is False


# ===========================================================================
# The summary
# ===========================================================================

class TestSummary:

    def _lines(self):
        return H.readable([
            _row(id="a", source="fcm_upload"),
            _row(id="b", source="fcm_upload", field_name="email"),
            _row(id="c", change_reason="manual_edit"),
            _row(id="d", entity_id="p2", source="hotel_file"),
        ], USERS, PEOPLE)

    def test_it_counts_by_origin(self):
        summary = H.summarise(self._lines())
        assert summary["by_source"] == {
            "fcm_upload": 2, "hotel_file": 1, "manual_update": 1,
        }

    def test_it_says_how_much_of_the_history_is_reconstructed(self):
        # The number that tells you how far back the trail can be relied on.
        assert H.summarise(self._lines())["inferred"] == 1

    def test_it_counts_the_people_touched_not_the_lines(self):
        assert H.summarise(self._lines())["people"] == 2

    def test_an_empty_log_summarises_without_crashing(self):
        assert H.summarise([])["changes"] == 0

    def test_the_filter_list_covers_every_origin(self):
        keys = {entry["key"] for entry in H.describe_sources()}
        assert keys == set(H.LABELS)
