"""
Tests for the transfer dispatcher (feedback §1).

The rule the whole module exists to honour is that it PROPOSES. So alongside
the arithmetic — who shares a vehicle, which vehicle, what time — the class
that matters most is TestProposingWritesNothing: a planner that quietly booked
what it computed would be the exact thing the feedback asks us not to build.

The feedback's own worked examples are here as tests, by name:
  * two flights landing at 14h15 and 14h30 with 15 and 8 people become one
    bus of 23 leaving at 15h00;
  * a flight at 14h00 with a three-hour margin means leaving at 11h00.
"""

from datetime import datetime

import pytest

from services import dispatch_service as D


def _flight(pid, arrival=None, departure=None, number=""):
    return {
        "participant_id": pid, "flight_number": number,
        "arrival_time": arrival, "departure_time": departure,
    }


class TestSettingsResolution:
    def test_an_unconfigured_event_gets_the_fleet_the_feedback_lists(self):
        got = D.resolve_settings(None)
        assert [(v["name"], v["capacity"]) for v in got["vehicles"]] == [
            ("Taxi", 3), ("Van", 7), ("Minibus", 18), ("Bus", 50)]
        assert got["min_hours_before_flight"] == 3.0
        assert got["grouping_window_minutes"] == 45

    def test_the_fleet_comes_back_sorted_by_capacity(self):
        got = D.resolve_settings({"vehicles": [
            {"name": "Bus", "capacity": 50}, {"name": "Taxi", "capacity": 3}]})
        assert [v["capacity"] for v in got["vehicles"]] == [3, 50]

    @pytest.mark.parametrize("vehicles", [
        [{"name": "Ghost", "capacity": 0}],
        [{"name": "", "capacity": 10}],
        [{"name": "Bad", "capacity": "seven"}],
        [{"name": "Neg", "capacity": -4}],
        ["Bus"],
        [],
    ])
    def test_an_unusable_fleet_falls_back_instead_of_breaking_the_planner(self, vehicles):
        # A zero-seat vehicle would make choose_vehicles loop forever.
        got = D.resolve_settings({"vehicles": vehicles})
        assert got["vehicles"] == [dict(v) for v in D.DEFAULT_FLEET]

    def test_a_usable_vehicle_survives_beside_an_unusable_one(self):
        got = D.resolve_settings({"vehicles": [
            {"name": "Van", "capacity": 7}, {"name": "Ghost", "capacity": 0}]})
        assert got["vehicles"] == [{"name": "Van", "capacity": 7}]

    @pytest.mark.parametrize("margin", [0, -1, 30, "three", None])
    def test_an_impossible_margin_falls_back(self, margin):
        assert D.resolve_settings(
            {"min_hours_before_flight": margin})["min_hours_before_flight"] == 3.0

    @pytest.mark.parametrize("window", [0, -30, 99999, "hour", None])
    def test_an_impossible_window_falls_back(self, window):
        assert D.resolve_settings(
            {"grouping_window_minutes": window})["grouping_window_minutes"] == 45

    @pytest.mark.parametrize("stored", [None, "", [], 42, "vehicles"])
    def test_a_malformed_config_is_survivable(self, stored):
        assert D.resolve_settings(stored)["vehicles"]

    def test_a_valid_custom_fleet_is_kept_as_given(self):
        got = D.resolve_settings({
            "vehicles": [{"name": "Berline", "capacity": 4}],
            "min_hours_before_flight": 2.5, "grouping_window_minutes": 90,
        })
        assert got["vehicles"] == [{"name": "Berline", "capacity": 4}]
        assert got["min_hours_before_flight"] == 2.5
        assert got["grouping_window_minutes"] == 90


class TestVehicleChoice:
    FLEET = [dict(v) for v in D.DEFAULT_FLEET]

    @pytest.mark.parametrize("pax,expected", [
        (1, ["Taxi"]), (3, ["Taxi"]),
        (4, ["Van"]), (7, ["Van"]),
        (8, ["Minibus"]), (18, ["Minibus"]),
        (19, ["Bus"]), (50, ["Bus"]),
    ])
    def test_the_smallest_vehicle_that_fits_wins(self, pax, expected):
        assert [v["name"] for v in D.choose_vehicles(pax, self.FLEET)] == expected

    def test_twenty_three_people_are_one_bus_not_two_minibuses(self):
        # The feedback's own example. Booking two vehicles where one does is
        # both more expensive and not what MAX would do.
        assert [v["name"] for v in D.choose_vehicles(23, self.FLEET)] == ["Bus"]

    def test_a_group_larger_than_the_biggest_vehicle_is_split(self):
        got = D.choose_vehicles(120, self.FLEET)
        assert [v["name"] for v in got] == ["Bus", "Bus", "Bus"]
        assert sum(v["seats_used"] for v in got) == 120

    def test_the_remainder_is_rounded_up_to_one_vehicle_not_scattered(self):
        # 54 = one bus + four people. Four people are a van, not two taxis.
        got = D.choose_vehicles(54, self.FLEET)
        assert [v["name"] for v in got] == ["Bus", "Van"]

    def test_seats_used_never_exceeds_capacity(self):
        for pax in range(1, 200):
            for v in D.choose_vehicles(pax, self.FLEET):
                assert v["seats_used"] <= v["capacity"]

    def test_every_passenger_is_seated(self):
        for pax in range(1, 200):
            assert sum(v["seats_used"] for v in D.choose_vehicles(pax, self.FLEET)) == pax

    @pytest.mark.parametrize("pax", [0, -5])
    def test_nobody_needs_no_vehicle(self, pax):
        assert D.choose_vehicles(pax, self.FLEET) == []

    def test_no_fleet_means_no_invented_vehicle(self):
        assert D.choose_vehicles(10, []) == []


class TestArrivalGrouping:
    SETTINGS = D.resolve_settings(None)

    def test_the_feedbacks_own_example(self):
        # SN123 lands 14h15 with 15 people, LH456 lands 14h30 with 8.
        # Expected: one transfer, 23 people, leaving at 15h00, a bus.
        flights = (
            [_flight("p%d" % i, arrival="2026-09-01T14:15:00", number="SN123") for i in range(15)]
            + [_flight("q%d" % i, arrival="2026-09-01T14:30:00", number="LH456") for i in range(8)]
        )
        got = D.propose_arrivals(flights, self.SETTINGS)
        assert len(got) == 1
        assert got[0]["passengers"] == 23
        assert got[0]["vehicle"]["name"] == "Bus"
        assert got[0]["pickup_time"] == "2026-09-01T15:00:00"
        assert got[0]["flight_numbers"] == ["LH456", "SN123"]

    def test_the_pickup_waits_for_the_last_plane_of_the_window(self):
        # Leaving at the start of the window would mean driving off before the
        # 14h30 arrivals have landed.
        got = D.propose_arrivals(
            [_flight("a", arrival="2026-09-01T14:15:00")], self.SETTINGS)
        assert got[0]["pickup_time"] == "2026-09-01T15:00:00"

    def test_arrivals_in_different_windows_do_not_share(self):
        got = D.propose_arrivals([
            _flight("a", arrival="2026-09-01T09:10:00"),
            _flight("b", arrival="2026-09-01T18:40:00"),
        ], self.SETTINGS)
        assert len(got) == 2

    def test_a_ninety_minute_window_really_is_ninety_minutes(self):
        # Anchoring to the arrival's own hour silently collapses back to
        # hourly buckets for any window that does not divide 60 — two flights
        # twenty minutes apart then land in slots an hour apart.
        settings = D.resolve_settings({"grouping_window_minutes": 90})
        got = D.propose_arrivals([
            _flight("a", arrival="2026-09-01T13:50:00"),
            _flight("b", arrival="2026-09-01T14:10:00"),
        ], settings)
        assert len(got) == 1

    def test_a_window_larger_than_any_vehicle_splits_into_several(self):
        flights = [_flight("p%d" % i, arrival="2026-09-01T14:15:00") for i in range(60)]
        got = D.propose_arrivals(flights, self.SETTINGS)
        assert len(got) == 2
        assert sum(g["passengers"] for g in got) == 60
        assert {g["pickup_time"] for g in got} == {"2026-09-01T15:00:00"}
        assert [g["sequence"] for g in got] == [1, 2]

    def test_nobody_is_in_two_vehicles_at_once(self):
        flights = [_flight("p%d" % i, arrival="2026-09-01T14:15:00") for i in range(60)]
        seated = [p for g in D.propose_arrivals(flights, self.SETTINGS) for p in g["participant_ids"]]
        assert len(seated) == len(set(seated)) == 60

    def test_the_same_person_on_two_segments_is_counted_once(self):
        got = D.propose_arrivals([
            _flight("a", arrival="2026-09-01T14:15:00", number="SN1"),
            _flight("a", arrival="2026-09-01T14:20:00", number="SN2"),
        ], self.SETTINGS)
        assert got[0]["passengers"] == 1

    @pytest.mark.parametrize("bad", [None, "", "soon", "not-a-date"])
    def test_a_flight_with_no_usable_landing_time_is_left_out(self, bad):
        assert D.propose_arrivals([_flight("a", arrival=bad)], self.SETTINGS) == []

    def test_a_flight_with_no_participant_is_left_out(self):
        assert D.propose_arrivals(
            [_flight(None, arrival="2026-09-01T14:15:00")], self.SETTINGS) == []

    def test_no_flights_means_no_groups(self):
        assert D.propose_arrivals([], self.SETTINGS) == []

    def test_without_a_fleet_a_group_still_reports_its_head_count(self):
        settings = dict(D.resolve_settings(None), vehicles=[])
        got = D.propose_arrivals(
            [_flight("a", arrival="2026-09-01T14:15:00")], settings)
        assert got[0]["vehicle"] is None
        assert got[0]["passengers"] == 1


class TestDepartureGrouping:
    SETTINGS = D.resolve_settings(None)

    def test_the_feedbacks_own_example(self):
        # "Vol : 14h00, temps de securite 3 heures -> depart hotel 11h00." Pinned
        # to a 60-minute window on purpose: this is checking the MARGIN math
        # (departure - 3h), not the current default grouping window, and 60 is
        # the one window that lands exactly on the feedback's literal 11h00.
        settings = D.resolve_settings({"grouping_window_minutes": 60})
        got = D.propose_departures(
            [_flight("a", departure="2026-09-05T14:00:00")], settings)
        assert got[0]["pickup_time"] == "2026-09-05T11:00:00"

    def test_the_margin_is_configurable(self):
        settings = D.resolve_settings({"min_hours_before_flight": 2})
        got = D.propose_departures(
            [_flight("a", departure="2026-09-05T14:00:00")], settings)
        assert got[0]["pickup_time"] == "2026-09-05T12:00:00"

    def test_a_departure_leaves_at_the_start_of_its_window(self):
        # Leaving early is inconvenient; leaving late means missing a plane.
        # Target is 11h40 (14h40 - 3h); the 45-minute grid's nearest boundary
        # at or before that is 11h15, which is what "start of window" means.
        got = D.propose_departures(
            [_flight("a", departure="2026-09-05T14:40:00")], self.SETTINGS)
        assert got[0]["pickup_time"] == "2026-09-05T11:15:00"

    def test_passengers_on_nearby_flights_share_a_vehicle(self):
        # 30 minutes apart, same as before; chosen so both land in the same
        # 45-minute bucket ([11h15, 12h00)) rather than straddling its edge.
        got = D.propose_departures([
            _flight("a", departure="2026-09-05T14:20:00"),
            _flight("b", departure="2026-09-05T14:50:00"),
        ], self.SETTINGS)
        assert len(got) == 1
        assert got[0]["passengers"] == 2

    def test_the_direction_and_the_endpoints_are_reversed(self):
        got = D.propose_departures(
            [_flight("a", departure="2026-09-05T14:00:00")], self.SETTINGS,
            airport="IST", origin="Grand Hotel")
        assert got[0]["direction"] == "departure"
        assert got[0]["pickup_location"] == "Grand Hotel"
        assert got[0]["dropoff_location"] == "IST"

    def test_a_return_flight_with_no_time_is_surfaced_not_dropped(self):
        # Somebody with a return flight and no time still needs a car. Silence
        # is how they end up standing outside the hotel without one.
        got = D.propose_departures([_flight("a", departure=None)], self.SETTINGS)
        assert len(got) == 1
        assert got[0]["needs_attention"] == "no_flight_time"
        assert got[0]["pickup_time"] is None
        assert got[0]["participant_ids"] == ["a"]

    def test_the_flagged_group_does_not_absorb_the_scheduled_ones(self):
        got = D.propose_departures([
            _flight("a", departure="2026-09-05T14:00:00"),
            _flight("b", departure=None),
        ], self.SETTINGS)
        assert len(got) == 2
        assert sum(1 for g in got if g.get("needs_attention")) == 1


class TestProposingWritesNothing:
    """The rule the module exists to honour: it proposes, the organizer
    decides. A planner that booked what it computed would be exactly what the
    feedback asks us not to build."""

    def test_the_functions_take_no_database_at_all(self):
        # Not a stylistic point: a pure function CANNOT write, so this is
        # enforced by the signature rather than by anybody remembering.
        import inspect
        for fn in (D.propose_arrivals, D.propose_departures, D.choose_vehicles,
                   D.resolve_settings, D.summarise):
            params = set(inspect.signature(fn).parameters)
            assert not params & {"supabase", "db", "client"}, fn.__name__

    def test_the_input_flights_are_not_mutated(self):
        flights = [_flight("a", arrival="2026-09-01T14:15:00", number="SN1")]
        before = [dict(f) for f in flights]
        D.propose_arrivals(flights, D.resolve_settings(None))
        assert flights == before

    def test_two_identical_calls_give_identical_plans(self):
        flights = [_flight("p%d" % i, arrival="2026-09-01T14:15:00") for i in range(30)]
        settings = D.resolve_settings(None)
        assert D.propose_arrivals(flights, settings) == D.propose_arrivals(flights, settings)

    def test_the_plan_does_not_depend_on_the_order_the_flights_arrive_in(self):
        flights = [_flight("p%d" % i, arrival="2026-09-01T14:15:00") for i in range(30)]
        settings = D.resolve_settings(None)
        assert D.propose_arrivals(flights, settings) == D.propose_arrivals(
            list(reversed(flights)), settings)


class TestSummary:
    def test_it_counts_people_once_across_every_group(self):
        settings = D.resolve_settings(None)
        plan = (
            D.propose_arrivals([_flight("a", arrival="2026-09-01T14:15:00")], settings)
            + D.propose_departures([_flight("a", departure="2026-09-05T14:00:00")], settings)
        )
        got = D.summarise(plan)
        assert got["groups"] == 2
        assert got["participants"] == 1
        assert got["arrivals"] == 1
        assert got["departures"] == 1

    def test_it_reports_how_many_groups_need_a_human(self):
        plan = D.propose_departures([_flight("a", departure=None)], D.resolve_settings(None))
        assert D.summarise(plan)["needs_attention"] == 1

    def test_an_empty_plan_summarises_to_zeroes(self):
        assert D.summarise([]) == {
            "groups": 0, "participants": 0, "arrivals": 0,
            "departures": 0, "needs_attention": 0,
        }
