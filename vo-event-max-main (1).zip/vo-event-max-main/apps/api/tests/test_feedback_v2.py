"""
Tests for the MAX / LivaNova feedback work: per-event field policy (§10),
roommates (§4), nights derived from flights (§2) and personal extensions (§3).

Two properties matter more than any individual case here and each has its own
class:

  * **Nothing changes until somebody configures it.** Every default is a
    compatibility contract with the engine as it behaved on 2026-08-12, not a
    design opinion, so an unconfigured event must produce byte-for-byte the
    same alerts and the same score. ``TestDefaultsChangeNothing`` is that guard.
  * **Nothing breaks before the migrations run.** Deployments apply SQL by
    hand, so every new step probes for its columns and degrades to a no-op.
    ``TestDegradesWithoutMigrations`` is that guard.

The rule modules are pure by design — dates and dicts in, dates and dicts out —
so most of what follows is a table of cases rather than a fixture.
"""

from datetime import date
from types import SimpleNamespace

import pytest


# ---------------------------------------------------------------------------
# A Supabase stand-in rich enough for the new steps: they probe, select, upsert
# and update, where the older fake only ever selected and updated.
# ---------------------------------------------------------------------------

_AUTO_ID = iter(f"auto-{n}" for n in range(1, 10_000))


class _Query:
    def __init__(self, table, fail: bool = False):
        self._t = table
        self._rows = list(table.rows)
        self._patch = None
        self._delete = False
        self._single = False
        self._fail = fail

    def select(self, *_a, **_k):
        return self

    def update(self, patch):
        self._patch = patch
        return self

    def insert(self, rows):
        rows = rows if isinstance(rows, list) else [rows]
        # Postgres fills the primary key on insert and PostgREST returns the
        # stored row — code that reads `.data[0]["id"]` back is relying on
        # that, so the fake has to do it too.
        rows = [{**r, "id": r.get("id") or next(_AUTO_ID)} for r in rows]
        self._t.rows.extend(rows)
        self._t.inserted.extend(rows)
        self._rows = rows
        return self

    def upsert(self, rows):
        rows = rows if isinstance(rows, list) else [rows]
        for row in rows:
            for i, existing in enumerate(self._t.rows):
                if existing.get("id") == row.get("id"):
                    self._t.rows[i] = row
                    break
            else:
                self._t.rows.append(row)
        self._t.upserted.extend(rows)
        return self

    def delete(self):
        self._delete = True
        return self

    def eq(self, col, val):
        if self._patch is not None:
            for r in self._t.rows:
                if r.get(col) == val:
                    r.update(self._patch)
                    self._t.updated.append((r.get("id"), dict(self._patch)))
            self._rows = []
            return self
        if self._delete:
            self._t.rows = [r for r in self._t.rows if r.get(col) != val]
            return self
        self._rows = [r for r in self._rows if r.get(col) == val]
        return self

    def in_(self, col, vals):
        vals = set(vals)
        if self._patch is not None:
            for r in self._t.rows:
                if r.get(col) in vals:
                    r.update(self._patch)
                    self._t.updated.append((r.get("id"), dict(self._patch)))
            self._rows = []
            return self
        self._rows = [r for r in self._rows if r.get(col) in vals]
        return self

    def range(self, start, end):
        self._rows = self._rows[start:end + 1]
        return self

    def limit(self, n):
        self._rows = self._rows[:n]
        return self

    def single(self):
        self._single = True
        return self

    def execute(self):
        if self._fail:
            raise RuntimeError('column "night_kind" does not exist')
        if self._single:
            return SimpleNamespace(data=self._rows[0] if self._rows else None, count=len(self._rows))
        return SimpleNamespace(data=self._rows, count=len(self._rows))


class _Table:
    def __init__(self, rows):
        self.rows = list(rows)
        self.inserted: list[dict] = []
        self.updated: list[tuple] = []
        self.upserted: list[dict] = []


class FakeDB:
    """``missing`` names tables whose every query raises, standing in for a
    column the migration has not created yet."""

    def __init__(self, missing: tuple[str, ...] = (), **tables):
        self.tables = {name: _Table(rows) for name, rows in tables.items()}
        self.missing = set(missing)

    def table(self, name):
        return _Query(self.tables.setdefault(name, _Table([])), fail=name in self.missing)

    def rows(self, name):
        return self.tables.setdefault(name, _Table([])).rows


EV = "e0000000-0000-0000-0000-000000000001"


def _participant(pid, first="Ada", last="Lovelace", **over):
    base = {
        "id": pid, "event_id": EV, "first_name": first, "last_name": last,
        "email": None, "phone": None, "nationality": None,
        "dietary_requirements": None, "locked_fields": {},
        "room_type": None, "roommate_name": None, "roommate_participant_id": None,
    }
    base.update(over)
    return base


# ===========================================================================
# §10 — the field policy itself
# ===========================================================================

class TestFieldPolicyResolution:
    def test_unconfigured_event_requires_exactly_what_the_engine_already_alerted_on(self):
        from services import field_policy
        policy = field_policy.resolve(None)
        for key in ("first_name", "email", "phone", "nationality"):
            assert policy[key] == field_policy.REQUIRED, key

    def test_a_blank_diet_is_an_answer_not_a_gap(self):
        # Changed deliberately on 2026-08-21. A blank dietary field means the
        # person eats everything, which is what the caterer needs to know —
        # not a hole in the file. Required by default, it produced 69 alerts
        # out of 82 participants on a live event and 98 out of 105 on another:
        # 236 cards whose whole content was "no restriction", drowning the six
        # real problems underneath. An event with a plated dinner turns it on.
        from services import field_policy
        assert field_policy.resolve(None)["dietary_requirements"] == field_policy.OPTIONAL

    def test_an_unknown_key_is_dropped_rather_than_stored(self):
        from services import field_policy
        assert "favourite_sweet" not in field_policy.resolve({"favourite_sweet": "required"})

    def test_an_invalid_state_falls_back_to_the_default_instead_of_raising(self):
        from services import field_policy
        assert field_policy.resolve({"email": "mandatory"})["email"] == field_policy.REQUIRED

    def test_both_the_string_and_the_object_form_are_accepted(self):
        from services import field_policy
        assert field_policy.resolve({"phone": "not_used"})["phone"] == field_policy.NOT_USED
        assert field_policy.resolve({"phone": {"state": "not_used"}})["phone"] == field_policy.NOT_USED

    @pytest.mark.parametrize("stored", [None, "", [], 0, "required", {"email": None}])
    def test_a_malformed_policy_never_takes_consolidation_down(self, stored):
        from services import field_policy
        policy = field_policy.resolve(stored)
        assert policy["email"] == field_policy.REQUIRED

    def test_optional_is_tracked_but_not_required(self):
        from services import field_policy
        policy = field_policy.resolve({"nationality": "optional"})
        assert field_policy.is_tracked(policy, "nationality")
        assert not field_policy.is_required(policy, "nationality")

    def test_not_used_is_neither(self):
        from services import field_policy
        policy = field_policy.resolve({"nationality": "not_used"})
        assert not field_policy.is_tracked(policy, "nationality")
        assert not field_policy.is_required(policy, "nationality")

    def test_fetch_returns_none_when_the_column_does_not_exist(self):
        from services import field_policy
        assert field_policy.fetch(FakeDB(missing=("events",)), EV) is None

    def test_for_event_still_yields_a_usable_policy_without_the_migration(self):
        from services import field_policy
        policy = field_policy.for_event(FakeDB(missing=("events",)), EV)
        assert policy["email"] == field_policy.REQUIRED


class TestPolicySilencesTheAlertsItShould:
    """"si l'événement n'a pas besoin de nationalité, on ne doit pas avoir 150
    participants en alerte Nationality missing" (feedback §10)."""

    def _detect(self, policy_stored, participants):
        from services import exception_service, field_policy
        got: list[dict] = []
        exception_service._detect_missing_profile_fields(
            EV, "run", FakeDB(participants=participants), got,
            total_participants=len(participants),
            policy=field_policy.resolve(policy_stored),
        )
        return got

    def _people(self, n=3):
        return [_participant(f"p{i}", email=f"a{i}@x.com", phone="123",
                             dietary_requirements="none") for i in range(n)]

    def test_a_not_used_field_produces_no_card_at_all(self):
        cards = self._detect({"nationality": "not_used"}, self._people())
        assert cards == []

    def test_an_optional_field_produces_no_card_either(self):
        cards = self._detect({"nationality": "optional"}, self._people())
        assert cards == []

    def test_the_same_field_left_required_does_produce_one_card_per_person(self):
        # The mutation check for the two above: without the policy change these
        # three people are reported, so the silence really is the policy's doing.
        cards = self._detect({"nationality": "required"}, self._people())
        assert len(cards) == 3
        assert all("nationality" in c["context_data"]["missing_fields"] for c in cards)

    def test_a_not_used_field_missing_on_everyone_raises_no_systemic_warning(self):
        # 30 people, all missing it: without the policy this is the loudest
        # possible signal. With it, an unused field being blank is the expected
        # state, not an anomaly.
        cards = self._detect({"nationality": "not_used"}, self._people(30))
        assert not any(c["context_data"].get("systemic_anomaly") for c in cards)

    def test_when_nothing_is_required_the_detector_short_circuits(self):
        off = {k: "not_used" for k in
               ("first_name", "email", "phone", "nationality", "dietary_requirements")}
        assert self._detect(off, self._people(50)) == []

    def test_a_person_with_no_name_is_still_not_double_reported(self):
        people = [_participant("p1", first="", last="", email=None)]
        assert self._detect({"email": "required"}, people) == []


class TestQualityScoreFollowsPolicy:
    def _score(self, policy_stored, rows):
        from services import master_list_service
        db = FakeDB(events=[{"id": EV, "field_policy": policy_stored}])
        original = master_list_service.build_master_rows
        master_list_service.build_master_rows = lambda *_a, **_k: rows
        try:
            return master_list_service.build_analysis(db, EV)
        finally:
            master_list_service.build_master_rows = original

    def _complete_row(self, **over):
        base = {
            "email": "a@x.com", "phone": "123", "dietary_requirements": "none",
            "passport_number": "X1", "has_flight": True, "has_hotel": True,
            "completeness_status": "complete", "region": "EU",
            "attendee_category": "guest", "job_title": "dev", "passport_expiry": None,
            "has_transfer": True, "has_activities": True,
        }
        base.update(over)
        return base

    def test_a_fully_complete_event_scores_100(self):
        assert self._score(None, [self._complete_row()])["quality_score"] == 100

    def test_dropping_a_dimension_keeps_a_complete_event_at_100(self):
        # Renormalisation, not a hole: turning passport off must not cap the
        # score at 85.
        got = self._score({"passport_number": "not_used"}, [self._complete_row()])
        assert got["quality_score"] == 100

    def test_a_dimension_the_event_does_not_require_stops_costing_it_points(self):
        # 83, not 85: the diet left the default weighting on 2026-08-21, so the
        # passport's 0.15 is now renormalised over 0.90 rather than 1.00 —
        # 100 - 15/90 = 83. The number the test is really about is the second
        # one, and it is still a clean 100.
        rows = [self._complete_row(passport_number=None)]
        with_passport = self._score(None, rows)["quality_score"]
        without = self._score({"passport_number": "not_used"}, rows)["quality_score"]
        assert with_passport == 83
        assert without == 100

    def test_an_event_that_requires_nothing_scores_zero_rather_than_crashing(self):
        off = {k: "not_used" for k in
               ("email", "phone", "flight", "hotel", "dietary_requirements", "passport_number")}
        assert self._score(off, [self._complete_row()])["quality_score"] == 0

    def test_a_dimension_that_costs_no_points_is_not_drawn_either(self):
        # This reverses an earlier decision, deliberately. The reasoning then
        # was that an organizer might still want to see where they stand on a
        # dimension the event does not require. What the dashboard actually
        # does with the number is draw a bar COLOURED BY ITS VALUE, directly
        # under the score circle — so "Régime 14 %" rendered red, next to five
        # green ones, contributing nothing to the score beside it. That is not
        # "where you stand", it is an alert about people who eat everything,
        # and it is the last place the diet was still reported as a problem.
        got = self._score({"passport_number": "not_used"}, [self._complete_row()])
        assert set(got["dimensions"]) == {
            "identite", "contact", "voyage", "hebergement"
        }
        assert "passeport" not in got["dimensions"]
        # The diet leaves for the same reason: OPTIONAL by default since
        # 2026-08-21, so it is not weighted and must not be drawn.
        assert "regime" not in got["dimensions"]


class TestAdviceFollowsPolicyToo:
    """The recommendations list is the one an organizer actually reads.

    The quality score has followed the field policy since §10; this list never
    did. So an event that had already been told a blank diet is normal was
    still greeted, on its own dashboard, by "236 participant(s) sans régime
    alimentaire renseigné" — the same alert under a different heading.
    """

    def _advice(self, policy_stored, rows):
        from services import master_list_service
        db = FakeDB(events=[{"id": EV, "field_policy": policy_stored}])
        original = master_list_service.build_master_rows
        master_list_service.build_master_rows = lambda *_a, **_k: rows
        try:
            got = master_list_service.build_analysis(db, EV)
        finally:
            master_list_service.build_master_rows = original
        return [r["text"] for r in got["recommendations"]]

    def _blank_row(self, **over):
        base = {
            "email": "a@x.com", "phone": "123", "dietary_requirements": None,
            "passport_number": "X1", "has_flight": True, "has_hotel": True,
            "completeness_status": "complete", "region": "EU",
            "attendee_category": "guest", "job_title": "dev", "passport_expiry": None,
            "has_transfer": True, "has_activities": False,
        }
        base.update(over)
        return base

    def test_a_blank_diet_produces_no_advice_by_default(self):
        texts = self._advice(None, [self._blank_row() for _ in range(10)])
        assert not any("régime" in t for t in texts)

    def test_an_event_that_needs_every_answer_is_still_told(self):
        """The plated-dinner case. Turning it on must still work — otherwise
        this is not a policy, it is a removal."""
        texts = self._advice(
            {"dietary_requirements": "required"}, [self._blank_row() for _ in range(10)]
        )
        assert any("régime" in t for t in texts)

    def test_activities_are_silent_unless_the_event_requires_them(self):
        """Same defect, same field: 'activity' is OPTIONAL by default and ten
        people with no excursion booked is not a to-do list."""
        texts = self._advice(None, [self._blank_row() for _ in range(10)])
        assert not any("activité" in t for t in texts)

    def test_a_missing_flight_is_still_reported(self):
        """The rule must not swallow the alerts that matter: flight, hotel and
        transfer are REQUIRED by default and this is what the page is for."""
        texts = self._advice(None, [self._blank_row(has_flight=False) for _ in range(3)])
        assert any("vol" in t for t in texts)

    def test_a_conflict_is_reported_whatever_the_policy_says(self):
        """A conflict is data we HAVE and it is wrong. No policy makes two
        files disagreeing about the same person uninteresting."""
        off = {k: "not_used" for k in
               ("email", "phone", "flight", "hotel", "dietary_requirements", "passport_number")}
        texts = self._advice(off, [self._blank_row(completeness_status="conflict")])
        assert any("conflit" in t for t in texts)


# ===========================================================================
# §4 — roommates
# ===========================================================================

def _norm(s):
    from services.consolidation_service import _norm_name
    return _norm_name(s)


def _same(a, b):
    from services.consolidation_service import _same_person_name
    return _same_person_name(a, b)


def _pairs(participants):
    from services import rooming_service
    return rooming_service.resolve_pairs(participants, same_person_name=_same, norm_name=_norm)


class TestWantsSharing:
    @pytest.mark.parametrize("value", [
        "twin", "Twin", "TWIN ROOM", "double", "Double Room", "DBL",
        "chambre double", "shared", "Twin/Double",
    ])
    def test_room_types_that_imply_a_second_occupant(self, value):
        from services import rooming_service
        assert rooming_service.wants_sharing(value)

    @pytest.mark.parametrize("value", ["single", "Single", "suite", "", None, "   "])
    def test_room_types_that_do_not(self, value):
        from services import rooming_service
        assert not rooming_service.wants_sharing(value)


class TestRoommatePairing:
    def test_two_people_naming_each_other_are_linked_both_ways(self):
        tina = _participant("t", "Tina", "Fey", room_type="twin", roommate_name="Leslie Knope")
        leslie = _participant("l", "Leslie", "Knope", room_type="twin", roommate_name="Tina Fey")
        links, unresolved = _pairs([tina, leslie])
        assert links == {"t": "l", "l": "t"}
        assert unresolved == []

    def test_one_side_filling_the_box_is_enough_when_the_other_named_nobody(self):
        # The common case: a couple registers and only one of them bothers.
        tina = _participant("t", "Tina", "Fey", room_type="twin", roommate_name="Leslie Knope")
        leslie = _participant("l", "Leslie", "Knope", room_type="twin")
        links, unresolved = _pairs([tina, leslie])
        assert links == {"t": "l", "l": "t"}
        assert unresolved == []

    def test_a_chain_of_three_links_nobody(self):
        a = _participant("a", "Ann", "Perkins", room_type="twin", roommate_name="Ben Wyatt")
        b = _participant("b", "Ben", "Wyatt", room_type="twin", roommate_name="Chris Traeger")
        c = _participant("c", "Chris", "Traeger", room_type="twin", roommate_name="Ann Perkins")
        links, unresolved = _pairs([a, b, c])
        assert not any(links.values())
        assert {u["reason"] for u in unresolved} == {"contradicted"}

    def test_a_name_matching_two_people_links_neither(self):
        asker = _participant("x", "Tom", "Haverford", room_type="twin", roommate_name="Jean Dupont")
        one = _participant("d1", "Jean", "Dupont", room_type="twin")
        two = _participant("d2", "Jean", "Dupont", room_type="twin")
        links, unresolved = _pairs([asker, one, two])
        assert links.get("x") in (None, )
        assert any(u["reason"] == "ambiguous_name" for u in unresolved)

    def test_a_name_matching_nobody_is_reported_with_the_text_as_written(self):
        asker = _participant("x", "Tom", "Haverford", room_type="twin",
                             roommate_name="Jean-Michel Absent")
        _, unresolved = _pairs([asker])
        assert unresolved[0]["reason"] == "unknown_name"
        assert unresolved[0]["written_name"] == "Jean-Michel Absent"

    def test_a_twin_with_an_empty_box_is_reported(self):
        _, unresolved = _pairs([_participant("x", room_type="twin")])
        assert [u["reason"] for u in unresolved] == ["no_name"]

    def test_a_single_room_with_an_empty_box_is_not(self):
        _, unresolved = _pairs([_participant("x", room_type="single")])
        assert unresolved == []

    def test_naming_yourself_resolves_to_nobody(self):
        me = _participant("x", "Tom", "Haverford", room_type="twin",
                          roommate_name="Tom Haverford")
        links, unresolved = _pairs([me])
        assert not links.get("x")
        assert unresolved[0]["reason"] == "unknown_name"

    def test_a_partial_name_never_resolves_to_a_longer_different_one(self):
        # The "Lin Lin" / "Chenyang Lin" lesson, applied here: a single token
        # must not pull in somebody whose name merely contains it.
        asker = _participant("x", "Tom", "Haverford", room_type="twin", roommate_name="Lin")
        other = _participant("y", "Chenyang", "Lin", room_type="twin")
        links, unresolved = _pairs([asker, other])
        assert not links.get("x")
        assert unresolved[0]["reason"] == "unknown_name"

    def test_a_longer_spelling_of_the_same_person_still_resolves(self):
        asker = _participant("x", "Tom", "Haverford", room_type="twin",
                             roommate_name="Melcy Romero")
        other = _participant("y", "Melcy", "Romero Trujillo", room_type="twin")
        links, _ = _pairs([asker, other])
        assert links.get("x") == "y"

    def test_a_stored_link_that_no_longer_holds_is_cleared(self):
        lone = _participant("x", room_type="single", roommate_participant_id="gone")
        links, _ = _pairs([lone])
        assert links == {"x": None}

    def test_a_linked_person_is_never_also_reported_as_unresolved(self):
        tina = _participant("t", "Tina", "Fey", room_type="twin", roommate_name="Leslie Knope")
        leslie = _participant("l", "Leslie", "Knope", room_type="twin")
        links, unresolved = _pairs([tina, leslie])
        linked = {pid for pid, target in links.items() if target}
        assert not {u["participant_id"] for u in unresolved} & linked


class TestRoommatesAreNeverMerged:
    """Two people in a twin share a booking email, often one contact number,
    and on a family trip a surname — the exact signature the phone-merge pass
    added on 2026-08-12 looks for."""

    def _run(self, participants):
        from services.consolidation_service import merge_same_phone_duplicates
        db = FakeDB(participants=participants)
        merged = merge_same_phone_duplicates(EV, db)
        return merged, db

    def _mother_and_daughter(self, linked: bool):
        # Same digits written two ways -- the exact production shape the phone
        # pass was built for ("(+1) 2142931656" / "+12142931656"). Here it is a
        # mother and daughter sharing a name, a mobile and a twin room.
        return [
            _participant("m", "Marie", "Dupont", phone="(+32) 470112233",
                         email="marie@x.com", room_type="twin",
                         roommate_participant_id="d" if linked else None),
            _participant("d", "Marie", "Dupont", phone="+32470112233",
                         email="marie@x.com", room_type="twin",
                         roommate_participant_id="m" if linked else None),
        ]

    def test_a_linked_pair_is_left_alone(self):
        merged, _ = self._run(self._mother_and_daughter(linked=True))
        assert merged == 0

    def test_without_the_link_the_very_same_pair_is_merged(self):
        # The mutation check: this is what the veto is preventing, so the two
        # tests only mean something together.
        merged, _ = self._run(self._mother_and_daughter(linked=False))
        assert merged == 1

    def test_the_veto_is_empty_and_harmless_before_the_migration(self):
        from services.consolidation_service import roommate_veto
        assert roommate_veto(EV, FakeDB(missing=("participants",))) == set()

    def test_the_veto_ignores_a_fiche_pointing_at_itself(self):
        from services.consolidation_service import roommate_veto
        db = FakeDB(participants=[_participant("a", roommate_participant_id="a")])
        assert roommate_veto(EV, db) == set()


class TestRoommateExceptions:
    def _cards(self, unresolved, policy_stored=None):
        from services import exception_service, field_policy
        got: list[dict] = []
        exception_service._detect_roommate_gaps(
            EV, "run", FakeDB(), got, unresolved=unresolved,
            policy=field_policy.resolve(policy_stored),
        )
        return got

    def _gap(self, reason, written=""):
        return {
            "participant_id": "p1", "reason": reason, "written_name": written,
            "participant": {"first_name": "Tina", "last_name": "Fey", "room_type": "twin"},
        }

    @pytest.mark.parametrize("reason", ["no_name", "unknown_name", "ambiguous_name", "contradicted"])
    def test_every_reason_produces_one_card_in_the_roommate_category(self, reason):
        cards = self._cards([self._gap(reason, "Leslie")])
        assert len(cards) == 1
        assert cards[0]["context_data"]["category"] == "roommate"
        assert cards[0]["context_data"]["reason"] == reason
        assert "Tina Fey" in cards[0]["message"]

    def test_an_unknown_reason_is_ignored_rather_than_rendered_as_a_template(self):
        assert self._cards([self._gap("something_new")]) == []

    def test_an_event_that_does_not_track_roommates_sees_none_of_them(self):
        assert self._cards([self._gap("no_name")], {"roommate": "not_used"}) == []

    def test_no_gaps_means_no_cards(self):
        assert self._cards([]) == []


class TestRoommateColumnMapping:
    def _suggest(self, header, values):
        from services.mapping_service import suggest_mapping
        rows = [{header: v} for v in values]
        return suggest_mapping([header], rows)[header]["suggested_field"]

    @pytest.mark.parametrize("header", [
        "Roommate", "Room mate", "Sharing with", "Roommate Name",
        "Partage chambre avec", "Kamergenoot",
    ])
    def test_the_usual_spellings_all_reach_the_roommate_field(self, header):
        assert self._suggest(header, ["Leslie Knope", "Tina Fey"]) == "roommate"

    def test_a_roommate_column_never_becomes_the_persons_own_surname(self):
        # It holds a real person's name, just not THIS person's — left alone it
        # would win last_name on a rooming list and give everyone their
        # neighbour's surname.
        assert self._suggest("Roommate", ["Knope", "Fey"]) != "last_name"

    def test_sharing_with_does_not_become_a_first_name_either(self):
        assert self._suggest("Sharing with", ["Leslie", "Tina"]) not in ("first_name", "last_name")


# ===========================================================================
# §2 / §3 — nights from flights, programme vs extension
# ===========================================================================

class TestTravelDateParsing:
    @pytest.mark.parametrize("value,expected", [
        ("2026-09-01T14:15:00Z", date(2026, 9, 1)),
        ("2026-09-01T14:15:00+02:00", date(2026, 9, 1)),
        ("2026-09-01 14:15:00", date(2026, 9, 1)),
        ("2026-09-01", date(2026, 9, 1)),
        (date(2026, 9, 1), date(2026, 9, 1)),
    ])
    def test_every_shape_the_flights_table_actually_holds(self, value, expected):
        from services.accommodation_service import as_day
        assert as_day(value) == expected

    @pytest.mark.parametrize("value", [None, "", "   ", "not a date", 0, "TK 81"])
    def test_garbage_returns_none_instead_of_raising(self, value):
        from services.accommodation_service import as_day
        assert as_day(value) is None


class TestTravelWindow:
    def _f(self, dep, arr):
        return {"departure_time": dep, "arrival_time": arr}

    def test_a_return_trip_gives_the_landing_day_and_the_flight_home_day(self):
        from services.accommodation_service import travel_window
        got = travel_window([
            self._f("2026-09-01T08:00:00Z", "2026-09-01T11:00:00Z"),
            self._f("2026-09-05T18:00:00Z", "2026-09-05T21:00:00Z"),
        ])
        assert got == (date(2026, 9, 1), date(2026, 9, 5))

    def test_a_stopover_does_not_confuse_the_extremes(self):
        from services.accommodation_service import travel_window
        got = travel_window([
            self._f("2026-09-01T08:00:00Z", "2026-09-01T10:00:00Z"),
            self._f("2026-09-01T12:00:00Z", "2026-09-01T15:00:00Z"),
            self._f("2026-09-05T18:00:00Z", "2026-09-05T21:00:00Z"),
        ])
        assert got == (date(2026, 9, 1), date(2026, 9, 5))

    def test_a_one_way_booking_yields_no_departure_rather_than_an_invented_one(self):
        from services.accommodation_service import travel_window
        assert travel_window([self._f("2026-09-01T08:00:00Z", "2026-09-01T11:00:00Z farbage")])[1] is None

    def test_no_flights_at_all(self):
        from services.accommodation_service import travel_window
        assert travel_window([]) == (None, None)


class TestNightsBetween:
    def test_the_feedbacks_own_example(self):
        # "Arrivée 1er septembre, départ 5 septembre → 4 nuitées."
        from services.accommodation_service import nights_between
        got = nights_between(date(2026, 9, 1), date(2026, 9, 5))
        assert len(got) == 4
        assert got[0] == date(2026, 9, 1)
        assert got[-1] == date(2026, 9, 4)

    def test_you_do_not_sleep_there_the_night_you_leave(self):
        from services.accommodation_service import nights_between
        assert date(2026, 9, 5) not in nights_between(date(2026, 9, 1), date(2026, 9, 5))

    @pytest.mark.parametrize("arrival,departure", [
        (date(2026, 9, 1), date(2026, 9, 1)),
        (date(2026, 9, 5), date(2026, 9, 1)),
        (None, date(2026, 9, 5)),
        (date(2026, 9, 1), None),
        (None, None),
    ])
    def test_no_stay_is_derived_from_a_window_that_makes_no_sense(self, arrival, departure):
        from services.accommodation_service import nights_between
        assert nights_between(arrival, departure) == []

    def test_an_absurd_span_is_refused_rather_than_written(self):
        # A mis-parsed year would otherwise book hundreds of nights, which is a
        # far louder failure than booking none.
        from services.accommodation_service import nights_between
        assert nights_between(date(2026, 1, 1), date(2027, 1, 1)) == []

    def test_the_longest_plausible_stay_is_still_derived(self):
        from services.accommodation_service import nights_between, MAX_DERIVED_NIGHTS
        from datetime import timedelta
        start = date(2026, 1, 1)
        got = nights_between(start, start + timedelta(days=MAX_DERIVED_NIGHTS))
        assert len(got) == MAX_DERIVED_NIGHTS


class TestProgrammeVersusExtension:
    START, END = date(2026, 9, 1), date(2026, 9, 3)

    def test_the_feedbacks_own_example(self):
        # Programme 1→3, flights 1→5: two nights covered, two personal.
        from services.accommodation_service import nights_between, split_nights
        nights = nights_between(date(2026, 9, 1), date(2026, 9, 5))
        split = split_nights(nights, self.START, self.END)
        assert len(split["program"]) == 2
        assert len(split["extension"]) == 2
        assert split["extension"] == [date(2026, 9, 3), date(2026, 9, 4)]

    def test_arriving_early_is_an_extension_too(self):
        from services.accommodation_service import classify_night
        assert classify_night(date(2026, 8, 31), self.START, self.END) == "extension"

    def test_the_night_the_programme_ends_is_not_covered_by_it(self):
        from services.accommodation_service import classify_night
        assert classify_night(self.END, self.START, self.END) == "extension"

    @pytest.mark.parametrize("start,end", [
        (None, None), (START, None), (None, END),
        (date(2026, 9, 3), date(2026, 9, 1)),
        (date(2026, 9, 1), date(2026, 9, 1)),
    ])
    def test_without_usable_programme_dates_nothing_is_called_an_extension(self, start, end):
        # An event that never set its dates must not report that everybody is
        # on a private holiday.
        from services.accommodation_service import classify_night
        assert classify_night(date(2026, 9, 4), start, end) == "program"


class TestAccommodationMismatch:
    def _days(self, *days):
        return [date(2026, 9, d) for d in days]

    def test_four_nights_of_flights_against_three_booked(self):
        from services.accommodation_service import mismatch
        got = mismatch(self._days(1, 2, 3, 4), self._days(1, 2, 3))
        assert got["delta"] == 1
        assert got["missing"] == ["2026-09-04"]
        assert got["extra"] == []

    def test_agreement_is_silence(self):
        from services.accommodation_service import mismatch
        assert mismatch(self._days(1, 2), self._days(1, 2)) is None

    def test_the_right_count_on_the_wrong_dates_is_still_reported(self):
        from services.accommodation_service import mismatch
        got = mismatch(self._days(1, 2), self._days(2, 3))
        assert got["delta"] == 0
        assert got["missing"] == ["2026-09-01"]
        assert got["extra"] == ["2026-09-03"]

    def test_the_hotel_holding_more_than_the_flights_imply(self):
        from services.accommodation_service import mismatch
        assert mismatch(self._days(1), self._days(1, 2))["delta"] == -1

    @pytest.mark.parametrize("derived,booked", [([], [1]), ([1], []), ([], [])])
    def test_nothing_is_claimed_when_one_side_is_empty(self, derived, booked):
        from services.accommodation_service import mismatch
        d = [date(2026, 9, x) for x in derived]
        b = [date(2026, 9, x) for x in booked]
        assert mismatch(d, b) is None

    def test_the_message_names_the_person_and_both_counts(self):
        from services.accommodation_service import describe_mismatch, mismatch
        gap = mismatch(self._days(1, 2, 3, 4), self._days(1, 2, 3))
        msg = describe_mismatch("John Smith", gap)
        assert "John Smith" in msg and "4" in msg and "3" in msg


class TestNightDerivationEndToEnd:
    P1, P2 = "p1", "p2"

    def _db(self, **over):
        tables = {
            "participants": [_participant(self.P1, "John", "Smith")],
            "flights": [{
                "event_id": EV, "participant_id": self.P1,
                "departure_time": "2026-09-01T08:00:00Z", "arrival_time": "2026-09-01T11:00:00Z",
            }, {
                "event_id": EV, "participant_id": self.P1,
                "departure_time": "2026-09-05T18:00:00Z", "arrival_time": "2026-09-05T21:00:00Z",
            }],
            "hotels": [{"id": "h1", "event_id": EV, "name": "Grand Hotel"}],
            "hotel_nights": [],
        }
        tables.update(over)
        return FakeDB(**tables)

    def test_a_participant_with_flights_and_no_rooming_row_gets_a_stay(self):
        from services.consolidation_service import derive_nights_from_flights
        db = self._db()
        got = derive_nights_from_flights(EV, db, "2026-09-01", "2026-09-03")
        assert got["derived"] == 1
        assert len(db.rows("hotel_nights")) == 4

    def test_the_derived_nights_are_marked_as_inferred_not_confirmed(self):
        from services.consolidation_service import derive_nights_from_flights
        db = self._db()
        derive_nights_from_flights(EV, db, "2026-09-01", "2026-09-03")
        assert {n["source"] for n in db.rows("hotel_nights")} == {"derived_from_flights"}
        assert {n["status"] for n in db.rows("hotel_nights")} == {"requested"}

    def test_the_programme_dates_split_the_derived_nights(self):
        from services.consolidation_service import derive_nights_from_flights
        db = self._db()
        got = derive_nights_from_flights(EV, db, "2026-09-01", "2026-09-03")
        kinds = sorted(n["night_kind"] for n in db.rows("hotel_nights"))
        assert kinds == ["extension", "extension", "program", "program"]
        assert got["extension_nights"] == 2

    def test_an_imported_rooming_list_is_never_overwritten(self):
        from services.consolidation_service import derive_nights_from_flights
        booked = [{
            "id": f"n{d}", "hotel_id": "h1", "event_id": EV, "participant_id": self.P1,
            "night_date": f"2026-09-0{d}", "room_type": "twin",
            "status": "confirmed", "night_kind": "program", "source": "imported",
        } for d in (1, 2, 3)]
        db = self._db(hotel_nights=booked)
        got = derive_nights_from_flights(EV, db, "2026-09-01", "2026-09-03")
        assert got["derived"] == 0
        assert len(db.rows("hotel_nights")) == 3
        assert {n["source"] for n in db.rows("hotel_nights")} == {"imported"}

    def test_and_the_gap_against_the_flights_is_reported_instead(self):
        from services.consolidation_service import derive_nights_from_flights
        booked = [{
            "id": f"n{d}", "hotel_id": "h1", "event_id": EV, "participant_id": self.P1,
            "night_date": f"2026-09-0{d}", "room_type": "twin",
            "status": "confirmed", "night_kind": "program", "source": "imported",
        } for d in (1, 2, 3)]
        db = self._db(hotel_nights=booked)
        got = derive_nights_from_flights(EV, db, "2026-09-01", "2026-09-03")
        assert len(got["mismatches"]) == 1
        assert got["mismatches"][0]["delta"] == 1
        assert got["mismatches"][0]["participant_name"] == "John Smith"

    def test_a_participant_with_no_flights_gets_nothing(self):
        from services.consolidation_service import derive_nights_from_flights
        db = self._db(participants=[_participant(self.P2, "No", "Flights")], flights=[])
        got = derive_nights_from_flights(EV, db, "2026-09-01", "2026-09-03")
        assert got["derived"] == 0
        assert db.rows("hotel_nights") == []

    def test_several_properties_means_the_target_is_ambiguous_so_nothing_is_derived(self):
        from services.consolidation_service import derive_nights_from_flights
        db = self._db(hotels=[{"id": "h1", "event_id": EV, "name": "A"},
                              {"id": "h2", "event_id": EV, "name": "B"}])
        got = derive_nights_from_flights(EV, db, "2026-09-01", "2026-09-03")
        assert got["derived"] == 0

    def test_an_event_with_no_property_yet_gets_a_placeholder_one(self):
        from services.consolidation_service import derive_nights_from_flights
        db = self._db(hotels=[])
        got = derive_nights_from_flights(EV, db, "2026-09-01", "2026-09-03")
        assert got["derived"] == 1
        assert len(db.rows("hotels")) == 1

    def test_without_programme_dates_every_derived_night_is_programme(self):
        from services.consolidation_service import derive_nights_from_flights
        db = self._db()
        got = derive_nights_from_flights(EV, db, None, None)
        assert got["extension_nights"] == 0
        assert {n["night_kind"] for n in db.rows("hotel_nights")} == {"program"}


class TestNightMismatchExceptions:
    def _cards(self, mismatches, policy_stored=None):
        from services import exception_service, field_policy
        got: list[dict] = []
        exception_service._detect_night_mismatches(
            EV, "run", FakeDB(), got, mismatches=mismatches,
            policy=field_policy.resolve(policy_stored),
        )
        return got

    def _gap(self):
        return {
            "participant_id": "p1", "participant_name": "John Smith",
            "derived_nights": 4, "booked_nights": 3,
            "missing": ["2026-09-04"], "extra": [], "delta": 1,
        }

    def test_one_card_per_mismatch_in_its_own_category(self):
        cards = self._cards([self._gap()])
        assert len(cards) == 1
        assert cards[0]["context_data"]["category"] == "accommodation_mismatch"
        assert cards[0]["severity"] == "warning"

    def test_an_event_that_does_not_track_hotels_sees_none(self):
        assert self._cards([self._gap()], {"hotel": "not_used"}) == []

    def test_no_mismatch_means_no_card(self):
        assert self._cards([]) == []


# ===========================================================================
# The two properties that matter more than any single case
# ===========================================================================

class TestDefaultsChangeNothing:
    """An unconfigured event must behave exactly as the engine did before any
    of this existed. Every default in field_policy is a compatibility contract,
    and this class is what holds it to that."""

    def test_the_engine_alerts_on_every_profile_field_the_event_requires(self):
        # Four of the five by default since the diet became optional; the
        # catalogue and the detector must still agree on which those are.
        from services import exception_service, field_policy
        policy = field_policy.resolve(None)
        tracked = field_policy.required_keys(policy, exception_service._MISSING_PROFILE_FIELDS)
        assert tracked == ["first_name", "email", "phone", "nationality"]
        assert set(tracked) <= set(exception_service._MISSING_PROFILE_FIELDS)

    def test_every_scored_dimension_except_the_diet_is_required_by_default(self):
        # The diet left this set on purpose (see test_a_blank_diet_is_an_answer
        # _not_a_gap). Its 10% weight is renormalised across the others, so an
        # event with no dietary answers stops losing points for a question
        # whose blank IS the answer — the score went UP on all three live
        # events, which is the intended direction.
        from services import field_policy
        policy = field_policy.resolve(None)
        for key in ("email", "phone", "flight", "hotel", "passport_number"):
            assert field_policy.is_required(policy, key), key
        assert not field_policy.is_required(policy, "dietary_requirements")

    def test_the_three_coverage_cards_are_all_still_raised_by_default(self):
        from services import field_policy
        policy = field_policy.resolve(None)
        assert all(field_policy.is_required(policy, k) for k in ("flight", "hotel", "transfer"))

    def test_detect_all_still_works_when_called_the_old_way(self):
        # The new arguments are keyword-only with defaults; an older caller
        # (or a queued job mid-deploy) must not break.
        from services import exception_service
        db = FakeDB(participants=[], uploaded_files=[], exceptions=[])
        assert exception_service.detect_all(EV, "run", db) == 0


class TestDegradesWithoutMigrations:
    """Migrations are applied by hand in the Supabase console, so a deployment
    running new code against an old schema is the normal state for a while, not
    an edge case."""

    def test_roommate_resolution_is_a_clean_no_op(self):
        from services.consolidation_service import resolve_roommates
        got = resolve_roommates(EV, FakeDB(missing=("participants",)))
        assert got == {"linked": 0, "unresolved": [], "available": False}

    def test_night_derivation_is_a_clean_no_op(self):
        from services.consolidation_service import derive_nights_from_flights
        got = derive_nights_from_flights(EV, FakeDB(missing=("hotel_nights",)))
        assert got["available"] is False
        assert got["derived"] == 0
        assert got["mismatches"] == []

    def test_night_derivation_writes_nothing_at_all_in_that_case(self):
        from services.consolidation_service import derive_nights_from_flights
        db = FakeDB(missing=("hotel_nights",), participants=[_participant("p1")])
        derive_nights_from_flights(EV, db)
        assert db.rows("hotel_nights") == []
        assert db.tables["participants"].updated == []

    def test_the_quality_score_survives_a_missing_policy_column(self):
        from services import master_list_service
        db = FakeDB(missing=("events",))
        original = master_list_service.build_master_rows
        master_list_service.build_master_rows = lambda *_a, **_k: [{
            "email": "a@x.com", "phone": "1", "dietary_requirements": "none",
            "passport_number": "X", "has_flight": True, "has_hotel": True,
            "completeness_status": "complete", "passport_expiry": None,
        }]
        try:
            assert master_list_service.build_analysis(db, EV)["quality_score"] == 100
        finally:
            master_list_service.build_master_rows = original
