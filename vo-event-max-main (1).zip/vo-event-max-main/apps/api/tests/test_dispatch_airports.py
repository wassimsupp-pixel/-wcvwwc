"""
Tests that a transfer leaves from where its passengers actually landed.

The bug these guard against is quiet and expensive. A single `airport` string
for the whole event meant two things at once: every sheet printed the same
pickup point, and — worse — two people landing ten minutes apart at two
different airports were put in the same car. Nobody sees that on screen; it
surfaces at 14:15 when a van is waiting at Brussels for somebody standing at
Charleroi.

So the airport is part of what defines a group, not a setting alongside it.
"""

import pytest

from services import dispatch_service as D


def settings(**overrides):
    base = D.resolve_settings({})
    base.update(overrides)
    return base


def arrival(pid, when, airport, number="XX000"):
    return {
        "participant_id": pid, "flight_number": number,
        "arrival_time": when, "arrival_airport": airport,
    }


def departure(pid, when, airport, number="XX000"):
    return {
        "participant_id": pid, "flight_number": number,
        "departure_time": when, "departure_airport": airport,
    }


class TestArrivalsLeaveFromTheirOwnAirport:

    def test_two_airports_never_share_a_vehicle(self):
        groups = D.propose_arrivals([
            arrival("p1", "2026-09-01T14:00:00", "BRU"),
            arrival("p2", "2026-09-01T14:10:00", "CRL"),
        ], settings())
        assert len(groups) == 2
        assert {g["pickup_location"] for g in groups} == {"BRU", "CRL"}
        for group in groups:
            assert len(group["participant_ids"]) == 1

    def test_the_same_airport_in_the_same_window_still_shares(self):
        groups = D.propose_arrivals([
            arrival("p1", "2026-09-01T14:00:00", "BRU"),
            arrival("p2", "2026-09-01T14:10:00", "BRU"),
        ], settings())
        assert len(groups) == 1
        assert groups[0]["participant_ids"] == ["p1", "p2"]
        assert groups[0]["pickup_location"] == "BRU"

    def test_a_flight_with_no_airport_falls_back_instead_of_vanishing(self):
        # A row missing its airport is still somebody who needs collecting.
        groups = D.propose_arrivals(
            [arrival("p1", "2026-09-01T14:00:00", "")], settings()
        )
        assert len(groups) == 1
        assert groups[0]["pickup_location"] == "Aéroport"
        assert groups[0]["participant_ids"] == ["p1"]

    def test_the_caller_can_still_name_a_default_airport(self):
        groups = D.propose_arrivals(
            [arrival("p1", "2026-09-01T14:00:00", "")], settings(), airport="BRU"
        )
        assert groups[0]["pickup_location"] == "BRU"


class TestDeparturesGoToTheirOwnAirport:

    def test_two_airports_never_share_a_vehicle(self):
        groups = D.propose_departures([
            departure("p1", "2026-09-05T18:00:00", "BRU"),
            departure("p2", "2026-09-05T18:05:00", "CRL"),
        ], settings())
        assert len(groups) == 2
        assert {g["dropoff_location"] for g in groups} == {"BRU", "CRL"}

    def test_the_pickup_is_the_hotel_and_the_dropoff_the_airport(self):
        groups = D.propose_departures(
            [departure("p1", "2026-09-05T18:00:00", "BRU")],
            settings(hotel_name="Hôtel Athenaeum"),
        )
        assert groups[0]["pickup_location"] == "Hôtel Athenaeum"
        assert groups[0]["dropoff_location"] == "BRU"

    def test_a_return_without_a_time_still_names_its_airport(self):
        # This group is the one an organizer has to arrange by hand, so it is
        # the one that most needs to say where the car is going.
        groups = D.propose_departures(
            [{"participant_id": "p1", "flight_number": "SN2", "departure_airport": "BRU"}],
            settings(),
        )
        assert len(groups) == 1
        assert groups[0]["needs_attention"] == "no_flight_time"
        assert groups[0]["dropoff_location"] == "BRU"


class TestTheHotelIsWrittenOnce:

    def test_it_survives_a_round_trip_through_the_settings(self):
        assert D.resolve_settings({"hotel_name": "  Hôtel Athenaeum  "})["hotel_name"] == "Hôtel Athenaeum"

    def test_an_unset_hotel_reads_as_the_generic_word(self):
        groups = D.propose_arrivals(
            [arrival("p1", "2026-09-01T14:00:00", "BRU")], settings()
        )
        assert groups[0]["dropoff_location"] == "Hôtel"

    def test_it_is_used_by_arrivals_and_departures_alike(self):
        config = settings(hotel_name="Hôtel Athenaeum")
        inbound = D.propose_arrivals([arrival("p1", "2026-09-01T14:00:00", "BRU")], config)
        outbound = D.propose_departures([departure("p1", "2026-09-05T18:00:00", "BRU")], config)
        assert inbound[0]["dropoff_location"] == "Hôtel Athenaeum"
        assert outbound[0]["pickup_location"] == "Hôtel Athenaeum"

    @pytest.mark.parametrize("bad", [None, 42, {"a": 1}, ["x"], ""])
    def test_a_malformed_hotel_falls_back_rather_than_raising(self, bad):
        assert D.resolve_settings({"hotel_name": bad})["hotel_name"] == ""

    def test_an_absurdly_long_hotel_is_trimmed_not_rejected(self):
        out = D.resolve_settings({"hotel_name": "H" * 500})["hotel_name"]
        assert len(out) == 120
