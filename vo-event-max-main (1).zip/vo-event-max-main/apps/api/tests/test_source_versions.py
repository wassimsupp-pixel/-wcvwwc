"""
Tests for Add/Update Source vs Replace Source (feedback §20).

The engine has always merged a weekly re-export correctly. What it could not do
is tell two intentions apart, and the whole risk of adding the second one is a
single failure mode: **somebody disappearing because a spreadsheet was
re-exported**. Sophie registered in Week 1, has a room booked and a transfer
assigned, and does not appear in Week 3 because she moved teams. She is still
going on the trip.

So the tests below are mostly about who gets NAMED rather than removed, and
about not reporting three hundred false changes that bury the four real ones.
"""

import pytest

from services import source_versions as SV
from services.consolidation_service import _norm_name


def _rec(rid="r1", pid="p1", **data):
    base = {"first_name": "Sophie", "last_name": "Marceau", "email": "sophie@x.com"}
    base.update(data)
    return {"id": rid, "participant_id": pid, "normalized_data": base}


def _impact(old, new):
    return SV.impact(old, new, _norm_name)


# ===========================================================================
# Following a person between two versions of one file
# ===========================================================================

class TestIdentity:

    def test_email_identifies_a_row(self):
        assert SV.person_key(_rec(), _norm_name) == "email:sophie@x.com"

    def test_a_row_without_email_falls_back_to_the_name(self):
        key = SV.person_key(_rec(email=None), _norm_name)
        assert key == "name:sophie marceau"

    def test_a_row_with_neither_cannot_be_followed(self):
        assert SV.person_key(_rec(email=None, first_name=None, last_name=None), _norm_name) == ""

    def test_an_unfollowable_row_is_neither_an_arrival_nor_a_departure(self):
        # Pretending we can follow it would produce a phantom departure and a
        # phantom arrival for the same person.
        blank = _rec(email=None, first_name=None, last_name=None)
        report = _impact([blank], [])
        assert report["removed"] == []
        assert report["untracked"] == 1

    def test_a_renamed_person_keeps_their_email_identity(self):
        report = _impact([_rec()], [_rec(last_name="Marceau-Dupont")])
        assert report["removed"] == [] and report["added"] == []
        assert report["changed"][0]["fields"][0]["field"] == "last_name"

    def test_a_case_difference_in_the_email_is_the_same_person(self):
        report = _impact([_rec(email="Sophie@X.com")], [_rec(email="sophie@x.com")])
        assert report["removed"] == [] and report["added"] == []


# ===========================================================================
# What replacing would change
# ===========================================================================

class TestImpact:

    def test_somebody_only_in_the_old_file_is_a_departure(self):
        report = _impact([_rec()], [])
        assert [r["name"] for r in report["removed"]] == ["Sophie Marceau"]

    def test_somebody_only_in_the_new_file_is_an_arrival(self):
        report = _impact([], [_rec()])
        assert [r["name"] for r in report["added"]] == ["Sophie Marceau"]

    def test_a_changed_field_names_both_values(self):
        report = _impact([_rec(phone="+3210")], [_rec(phone="+3299")])
        assert report["changed"][0]["fields"] == [
            {"field": "phone", "old": "+3210", "new": "+3299"}
        ]

    def test_an_identical_re_export_reports_nothing(self):
        report = _impact([_rec()], [_rec(rid="r9")])
        assert (report["added"], report["removed"], report["changed"]) == ([], [], [])
        assert report["unchanged"] == 1

    def test_a_field_nobody_compares_is_not_a_change(self):
        # A re-export renumbers its own rows and reformats its dates. Reporting
        # that for three hundred people buries the four that matter.
        report = _impact([_rec(row_index=1)], [_rec(rid="r9", row_index=57)])
        assert report["changed"] == []

    def test_a_duplicate_inside_one_file_does_not_double_count(self):
        report = _impact([_rec(rid="a"), _rec(rid="b")], [_rec(rid="c")])
        assert report["removed"] == [] and report["unchanged"] == 1

    def test_the_sentence_leads_with_the_departures(self):
        report = _impact([_rec(), _rec(rid="r2", pid="p2", email="b@x.com")], [_rec()])
        line = SV.describe(report)
        assert line.startswith("1 disparition(s)")

    def test_no_difference_says_so_plainly(self):
        assert SV.describe(_impact([_rec()], [_rec()])) == "Aucune différence entre les deux fichiers."


# ===========================================================================
# Nobody vanishes
# ===========================================================================

class TestOrphans:
    """The question that actually matters before pressing Replace."""

    def test_somebody_backed_only_by_the_replaced_file_is_named(self):
        assert SV.orphaned([_rec(pid="p1")], []) == ["p1"]

    def test_somebody_also_present_in_another_live_file_is_not(self):
        other = [_rec(rid="z", pid="p1")]
        assert SV.orphaned([_rec(pid="p1")], other) == []

    def test_a_row_linked_to_nobody_cannot_orphan_anybody(self):
        assert SV.orphaned([_rec(pid=None)], []) == []

    def test_several_orphans_come_back_sorted_and_deduplicated(self):
        old = [_rec(rid="a", pid="p2"), _rec(rid="b", pid="p1"), _rec(rid="c", pid="p1")]
        assert SV.orphaned(old, []) == ["p1", "p2"]


# ===========================================================================
# Which file can replace which
# ===========================================================================

class TestCandidates:

    def _f(self, fid, kind="fcm", when="2027-01-02", **over):
        base = {"id": fid, "source_type": kind, "imported_at": when,
                "original_filename": f"{fid}.xlsx", "superseded_at": None}
        base.update(over)
        return base

    def test_an_earlier_file_of_the_same_kind_is_offered(self):
        files = [self._f("w1", when="2027-01-01"), self._f("w2", when="2027-01-08")]
        assert [c["id"] for c in SV.candidates(files, files[1])] == ["w1"]

    def test_a_different_source_type_is_never_offered(self):
        # A hotel list never replaces an FCM export however similar the
        # filenames look; offering it lets somebody retire the wrong file.
        files = [self._f("h1", kind="hotel", when="2027-01-01"), self._f("w2", when="2027-01-08")]
        assert SV.candidates(files, files[1]) == []

    def test_a_later_file_is_not_offered(self):
        files = [self._f("w1", when="2027-01-01"), self._f("w3", when="2027-01-15")]
        assert SV.candidates(files, files[0]) == []

    def test_an_already_superseded_file_is_not_offered_again(self):
        files = [
            self._f("w1", when="2027-01-01", superseded_at="2027-01-09"),
            self._f("w2", when="2027-01-08"),
            self._f("w3", when="2027-01-15"),
        ]
        assert [c["id"] for c in SV.candidates(files, files[2])] == ["w2"]

    def test_a_file_never_offers_itself(self):
        files = [self._f("w1")]
        assert SV.candidates(files, files[0]) == []

    def test_the_most_recent_candidate_comes_first(self):
        files = [
            self._f("w1", when="2027-01-01"),
            self._f("w2", when="2027-01-08"),
            self._f("w3", when="2027-01-15"),
        ]
        assert [c["id"] for c in SV.candidates(files, files[2])] == ["w2", "w1"]
