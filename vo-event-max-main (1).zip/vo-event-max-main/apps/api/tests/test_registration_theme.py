"""
Tests for how the public registration form looks.

The thing being guarded is narrower than it appears. The theme drives a page
open to the world with no login, so the interesting question is never "does the
dark surface work" — it is "can anything an organizer types reach that page as
anything other than a key this codebase defined". Most of what follows is that
question asked in different ways.

The rest guards the property the renderer depends on: `resolve` always returns
a WHOLE theme. A page that has to merge against defaults is a page that renders
without an accent colour the day somebody forgets.
"""

import pytest

from services import registration_theme as T


class TestDefaults:

    def test_an_event_that_configured_nothing_gets_a_complete_theme(self):
        theme = T.resolve(None)
        assert theme == T.default_theme()
        assert set(theme) == {"font", "accent", "surface", "corners", "background_image", "header"}
        assert set(theme["header"]) == {
            "style", "image_url", "title", "subtitle", "align", "height",
        }

    def test_the_update_model_does_not_drop_the_background_image(self):
        """The bug this guards: the endpoint's Pydantic model had no
        `background_image`, so every save silently discarded the photo the
        organizer had just uploaded. A key the service stores must be a key the
        model names, or it never reaches sanitize()."""
        from models.schemas import RegistrationThemeUpdate

        body = RegistrationThemeUpdate(background_image="https://cdn.example.com/bg.jpg")
        stored = T.sanitize(body.model_dump())
        assert stored["background_image"] == "https://cdn.example.com/bg.jpg"

    def test_background_image_defaults_empty_and_is_https_only(self):
        assert T.default_theme()["background_image"] == ""
        assert T.sanitize({"background_image": "https://cdn.example.com/bg.jpg"})["background_image"].startswith("https://")
        assert T.sanitize({"background_image": "http://insecure/bg.jpg"})["background_image"] == ""
        assert T.sanitize({"background_image": 'https://x/"><script>'})["background_image"] == ""

    @pytest.mark.parametrize("stored", [None, {}, [], "", 0, "a string", {"font": None}])
    def test_nothing_stored_is_ever_a_hole_in_the_output(self, stored):
        theme = T.resolve(stored)
        assert theme["font"] in T.FONTS
        assert theme["surface"] in T.SURFACES
        assert theme["corners"] in T.CORNERS
        assert theme["header"]["style"] in T.HEADER_STYLES
        assert T.clean_colour(theme["accent"]) == theme["accent"]

    def test_is_default_tells_untouched_from_deliberately_neutral(self):
        assert T.is_default(None)
        assert T.is_default(T.default_theme())
        assert not T.is_default({"accent": "#ff0000"})

    def test_a_partial_row_from_an_older_deploy_is_completed(self):
        # A row written before `corners` existed is exactly as partial as a
        # hand-crafted payload, and gets the same treatment.
        theme = T.resolve({"font": "serif", "accent": "#123456"})
        assert theme["font"] == "serif"
        assert theme["accent"] == "#123456"
        assert theme["corners"] == T.DEFAULT_CORNERS


class TestNothingBecomesCss:

    @pytest.mark.parametrize("attack", [
        "comic-sans; } body { display: none",
        "sans</style><script>alert(1)</script>",
        "../../etc/passwd",
        "SANS ",
        "",
        None,
        12,
        ["sans"],
    ])
    def test_a_font_that_is_not_in_the_set_falls_back(self, attack):
        assert T.sanitize({"font": attack})["font"] in T.FONTS

    @pytest.mark.parametrize("attack", [
        "red; background: url(https://evil.example/pixel)",
        "javascript:alert(1)",
        "#12345",
        "#1234567",
        "rgb(1,2,3)",
        "expression(alert(1))",
        "var(--color-accent)",
    ])
    def test_a_colour_that_is_not_a_hex_falls_back(self, attack):
        assert T.sanitize({"accent": attack})["accent"] == T.DEFAULT_ACCENT

    @pytest.mark.parametrize("given,expected", [
        ("#aabbcc", "#aabbcc"),
        ("#AABBCC", "#aabbcc"),
        ("  #AaBbCc  ", "#aabbcc"),
        ("aabbcc", "#aabbcc"),          # a pasted brand guideline drops the #
        ("#abc", "#aabbcc"),            # and shorthand is what a designer writes
        ("ABC", "#aabbcc"),
    ])
    def test_the_shapes_a_colour_actually_arrives_in(self, given, expected):
        assert T.sanitize({"accent": given})["accent"] == expected

    def test_markup_in_a_heading_is_removed_not_escaped(self):
        # Same rule as event_site.clean_text: an organizer who pastes a tag and
        # sees it vanish learns the rule; one who sees it printed learns
        # nothing, and one whose tag WORKS is an XSS vector.
        header = T.sanitize({"header": {"title": "<script>alert(1)</script>Bienvenue"}})["header"]
        assert "<" not in header["title"]
        assert "script" not in header["title"].lower()
        assert "Bienvenue" in header["title"]

    def test_a_heading_is_one_line(self):
        title = T.sanitize({"header": {"title": "Deux\nlignes\r\net demie"}})["header"]["title"]
        assert "\n" not in title
        assert title == "Deux lignes et demie"

    def test_headings_are_capped(self):
        long = "a" * 5000
        header = T.sanitize({"header": {"title": long, "subtitle": long}})["header"]
        assert len(header["title"]) == T.MAX_TITLE
        assert len(header["subtitle"]) == T.MAX_SUBTITLE

    @pytest.mark.parametrize("attack", [
        "http://example.com/x.png",                 # plaintext on a TLS page
        "javascript:alert(1)",
        "data:image/png;base64,AAAA",
        'https://x/y.png" onload="alert(1)',
        "https://x/y.png\n<script>",
        "//example.com/x.png",
        "",
    ])
    def test_a_header_image_that_is_not_a_plain_https_url_is_dropped(self, attack):
        assert T.sanitize({"header": {"image_url": attack}})["header"]["image_url"] == ""

    def test_a_real_https_url_survives(self):
        url = "https://mmbkfinzqsxczdjvhrge.supabase.co/storage/v1/object/public/x/y.jpg"
        assert T.sanitize({"header": {"image_url": url}})["header"]["image_url"] == url

    def test_an_unknown_key_is_not_stored_at_all(self):
        clean = T.sanitize({"font": "sans", "custom_css": "body{display:none}", "x": 1})
        assert "custom_css" not in clean
        assert "x" not in clean


class TestTheHeaderAlwaysRendersSomething:

    def test_a_photo_header_without_a_photo_falls_back_to_the_title(self):
        # Otherwise the visitor's first impression is a blank band.
        for style in ("image", "banner"):
            header = T.sanitize({"header": {"style": style}})["header"]
            assert header["style"] == "title"

    def test_a_photo_header_with_a_photo_is_kept(self):
        header = T.sanitize({
            "header": {"style": "banner", "image_url": "https://x/y.jpg"},
        })["header"]
        assert header["style"] == "banner"

    def test_a_photo_dropped_for_being_unsafe_takes_the_style_with_it(self):
        header = T.sanitize({
            "header": {"style": "banner", "image_url": "javascript:alert(1)"},
        })["header"]
        assert header["style"] == "title"
        assert header["image_url"] == ""


class TestSanitizeAndResolveAgree:

    def test_what_is_stored_reads_back_identical(self):
        # The renderer runs `resolve` over what `sanitize` wrote. If the two
        # ever disagreed, a saved theme would preview differently from the way
        # it actually shipped.
        for payload in (
            {},
            {"font": "slab", "accent": "#ff0000", "surface": "dark", "corners": "sharp"},
            {"header": {"style": "banner", "image_url": "https://x/y.jpg",
                        "title": "Convention 2027", "align": "left", "height": "tall"}},
            {"font": "nope", "accent": "nope", "header": {"style": "nope"}},
        ):
            stored = T.sanitize(payload)
            assert T.resolve(stored) == stored


class TestFetch:

    class _Supabase:
        def __init__(self, rows=None, boom=False):
            self.rows, self.boom = rows, boom

        def table(self, _):
            return self

        def select(self, _):
            if self.boom:
                raise RuntimeError("column events.registration_theme does not exist")
            return self

        def eq(self, *_):
            return self

        def limit(self, _):
            return self

        def execute(self):
            return type("R", (), {"data": self.rows})()

    def test_a_missing_column_reads_as_never_configured(self):
        # Migration 030 not applied: the form must keep rendering, not 500.
        assert T.fetch(self._Supabase(boom=True), "e1") is None
        assert T.resolve(T.fetch(self._Supabase(boom=True), "e1")) == T.default_theme()

    def test_an_event_with_no_row_reads_as_never_configured(self):
        assert T.fetch(self._Supabase(rows=[]), "e1") is None

    def test_a_null_column_reads_as_never_configured(self):
        assert T.fetch(self._Supabase(rows=[{"registration_theme": None}]), "e1") is None

    def test_a_stored_theme_comes_back(self):
        stored = {"font": "serif"}
        assert T.fetch(self._Supabase(rows=[{"registration_theme": stored}]), "e1") == stored
