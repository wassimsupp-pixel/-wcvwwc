"""
Tests that the public form cannot go out half-translated.

The failure this guards against is not a crash — it is a form that opens in
Dutch, asks four questions in Dutch, and then asks for a passport number in
French. Nobody notices while writing the code, because the fallback works
perfectly: an untranslated label simply comes back in French and the page
renders. The only way it surfaces is a participant giving up on it.

So the coverage is asserted rather than trusted. Adding a field to the
catalogue without translating it fails here, at the moment it is added, on the
machine of whoever added it.
"""

import pytest

from services import registration_form, registration_i18n as i18n


CATALOGUE_KEYS = [entry[0] for entry in registration_form._CATALOGUE]
CATALOGUE_GROUPS = sorted({entry[2] for entry in registration_form._CATALOGUE})
OTHER_LOCALES = [code for code in i18n.SUPPORTED if code != i18n.DEFAULT]


class TestEveryFieldIsTranslated:

    @pytest.mark.parametrize("locale", OTHER_LOCALES)
    def test_no_catalogue_field_is_left_in_french(self, locale):
        missing = [
            key for key in CATALOGUE_KEYS
            if not i18n._LABELS.get(key, {}).get(locale)
        ]
        assert missing == [], (
            f"Champs sans libellé {locale} : {missing}. "
            f"Ajoutez-les dans registration_i18n._LABELS."
        )

    @pytest.mark.parametrize("locale", OTHER_LOCALES)
    def test_no_section_heading_is_left_in_french(self, locale):
        missing = [
            group for group in CATALOGUE_GROUPS
            if not i18n._GROUPS.get(group, {}).get(locale)
        ]
        assert missing == [], f"Sections sans traduction {locale} : {missing}."

    @pytest.mark.parametrize("locale", i18n.SUPPORTED)
    def test_every_server_sentence_exists_in_every_language(self, locale):
        missing = [key for key, per_locale in i18n._MESSAGES.items()
                   if not per_locale.get(locale)]
        assert missing == [], f"Messages sans traduction {locale} : {missing}."

    def test_no_translation_is_left_behind_by_a_removed_field(self):
        # A label for a key the catalogue no longer has is dead weight that
        # reads as coverage — and hides the field that really is missing.
        orphans = [key for key in i18n._LABELS if key not in CATALOGUE_KEYS]
        assert orphans == [], f"Libellés orphelins : {orphans}."


class TestFallbackNeverShowsAKey:

    def test_an_unknown_field_falls_back_to_its_french_label(self):
        assert i18n.label("field_invented_today", "Champ inventé", "nl") == "Champ inventé"

    def test_an_unsupported_language_is_served_in_french(self):
        assert i18n.normalise("de") == "fr"
        assert i18n.label("first_name", "Prénom", i18n.normalise("de")) == "Prénom"

    @pytest.mark.parametrize("given,expected", [
        ("nl-BE", "nl"), ("NL", "nl"), ("en_GB", "en"), ("fr-FR", "fr"),
        ("", "fr"), (None, "fr"), (42, "fr"),
    ])
    def test_a_regional_or_malformed_code_still_resolves(self, given, expected):
        assert i18n.normalise(given) == expected

    def test_translating_the_catalogue_keeps_keys_and_flags_untouched(self):
        fields = [{"key": "first_name", "label": "Prénom", "group": "Identité",
                   "enabled": True, "required": True}]
        out = i18n.translate_fields(fields, "nl")
        assert out[0]["key"] == "first_name"
        assert out[0]["label"] == "Voornaam"
        assert out[0]["group"] == "Identiteit"
        assert out[0]["required"] is True
