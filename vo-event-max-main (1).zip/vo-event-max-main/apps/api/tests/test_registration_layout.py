"""
Tests for WHERE things sit on the public registration form — now per page.

A layout is a MAP of pages: "home" (the registration page, the only one that
carries the form) plus one entry per mini-site section, each arranged in its
own blocks. The central question is unchanged and asked many ways: can anything
an organizer arranges reach a login-less, crowd-loaded page as anything other
than a block type, an enum key, a validated hex, a bounded line, or an https
URL this codebase defined.

The rest guards the invariants the renderer leans on: the registration page
always carries exactly one form block, a content page never carries one, a bare
list (a row written before the multi-page change) still means the registration
page, and an event that never opted in resolves to {} — "classic everywhere".
"""

import pytest

from services import registration_layout as L


def home(payload):
    """The registration page's blocks after sanitizing `payload`."""
    return L.sanitize(payload)["home"]


def _types(blocks):
    return [b["type"] for b in blocks]


class TestOptIn:
    def test_never_configured_resolves_to_empty_map(self):
        assert L.resolve(None) == {}

    def test_empty_list_resolves_to_empty_map(self):
        assert L.resolve([]) == {}

    def test_empty_dict_resolves_to_empty_map(self):
        assert L.resolve({}) == {}

    def test_non_container_resolves_to_empty_map(self):
        assert L.resolve("nonsense") == {}
        assert L.resolve(42) == {}

    def test_a_stored_list_is_the_registration_page(self):
        # Backward compatibility: a pre-multi-page row was a bare list.
        out = L.resolve([{"type": "title", "text": "Bonjour"}])
        assert "home" in out
        assert "title" in _types(out["home"])

    def test_a_stored_page_map_comes_back_per_page(self):
        out = L.resolve({"home": [{"type": "title", "text": "x"}],
                         "programme": [{"type": "text", "text": "au programme"}]})
        assert set(out) == {"home", "programme"}
        assert "text" in _types(out["programme"])


class TestFormIsHomeOnly:
    def test_home_with_no_form_gets_one(self):
        out = home([{"type": "title", "text": "Hi"}])
        assert _types(out).count("form") == 1

    def test_home_with_several_forms_keeps_the_first(self):
        out = home([
            {"type": "form", "button": "A"},
            {"type": "title", "text": "mid"},
            {"type": "form", "button": "B"},
        ])
        assert _types(out).count("form") == 1
        assert next(b for b in out if b["type"] == "form")["button"]["fr"] == "A"

    def test_an_empty_home_still_has_a_form(self):
        assert _types(L.sanitize({"home": []})["home"]) == ["form"]

    def test_a_content_page_drops_every_form_block(self):
        out = L.sanitize({"home": [], "programme": [
            {"type": "form", "button": "nope"},
            {"type": "title", "text": "Programme"},
        ]})
        assert "form" not in _types(out["programme"])
        assert "title" in _types(out["programme"])

    def test_a_content_page_that_is_only_a_form_disappears(self):
        # Nothing survives the form-strip, so the page is left classic.
        out = L.sanitize({"home": [], "programme": [{"type": "form"}]})
        assert "programme" not in out


class TestPages:
    def test_home_is_always_present(self):
        assert "home" in L.sanitize({"infos": [{"type": "title", "text": "x"}]})

    def test_a_bad_page_key_is_dropped(self):
        out = L.sanitize({"home": [], "Not A Slug!": [{"type": "title", "text": "x"}]})
        assert set(out) == {"home"}

    def test_an_empty_content_page_is_not_stored(self):
        out = L.sanitize({"home": [], "programme": []})
        assert "programme" not in out

    def test_the_page_count_is_bounded(self):
        many = {"page-%d" % i: [{"type": "title", "text": str(i)}] for i in range(100)}
        many["home"] = []
        out = L.sanitize(many)
        assert len(out) <= L.MAX_PAGES

    def test_a_list_payload_becomes_the_home_page(self):
        out = L.sanitize([{"type": "title", "text": "x"}])
        assert set(out) == {"home"}
        assert "title" in _types(out["home"])


class TestUnknownIsDropped:
    def test_unknown_block_type_is_discarded(self):
        out = home([{"type": "iframe", "src": "evil"}, {"type": "title", "text": "ok"}])
        assert "iframe" not in _types(out)
        assert "title" in _types(out)

    def test_a_non_dict_block_is_discarded(self):
        out = home(["just a string", 42, None, {"type": "title", "text": "ok"}])
        assert "title" in _types(out)


class TestSecurity:
    def test_a_title_cannot_carry_markup(self):
        out = home([{"type": "title", "text": "<script>alert(1)</script>Bonjour"}])
        title = next(b for b in out if b["type"] == "title")
        assert "<" not in title["text"]["fr"]

    def test_markup_is_stripped_in_every_language(self):
        out = home([{"type": "title", "text": {
            "fr": "<b>Bonjour</b>", "nl": "<i>Hallo</i>", "en": "<u>Hi</u>"}}])
        text = next(b for b in out if b["type"] == "title")["text"]
        assert all("<" not in v for v in text.values())
        assert set(text) == {"fr", "nl", "en"}

    def test_a_paragraph_strips_tags_but_keeps_line_breaks(self):
        out = home([{"type": "text", "text": "Ligne 1\nLigne 2<b>x</b>"}])
        text = next(b for b in out if b["type"] == "text")["text"]["fr"]
        assert "<" not in text
        assert "\n" in text

    def test_an_image_url_must_be_https(self):
        out = home([{"type": "image", "image_url": "http://insecure/x.jpg"}])
        assert next(b for b in out if b["type"] == "image")["image_url"] == ""

    def test_an_image_url_cannot_carry_quotes_or_brackets(self):
        out = home([{"type": "image", "image_url": 'https://x/"><script>'}])
        assert next(b for b in out if b["type"] == "image")["image_url"] == ""

    def test_a_button_href_must_be_https(self):
        out = home([{"type": "button", "label": "Go", "href": "javascript:alert(1)"}])
        assert next(b for b in out if b["type"] == "button")["href"] == ""

    def test_a_bad_colour_becomes_the_default_not_the_string(self):
        out = home([{"type": "button", "label": "x", "bg": "red; background:url(evil)"}])
        assert next(b for b in out if b["type"] == "button")["bg"] == L.DEFAULT_BUTTON_BG

    def test_an_optional_colour_left_blank_stays_blank(self):
        out = home([{"type": "title", "text": "x"}])
        assert next(b for b in out if b["type"] == "title")["color"] == ""

    def test_an_optional_colour_that_is_garbage_becomes_blank(self):
        out = home([{"type": "title", "text": "x", "color": "chartreuse"}])
        assert next(b for b in out if b["type"] == "title")["color"] == ""


class TestEnumFallback:
    def test_unknown_font_falls_back(self):
        out = home([{"type": "title", "text": "x", "font": "comic-sans"}])
        assert next(b for b in out if b["type"] == "title")["font"] in L.FONTS

    def test_unknown_variant_falls_back(self):
        out = home([{"type": "image", "variant": "carousel"}])
        assert next(b for b in out if b["type"] == "image")["variant"] in L.IMAGE_VARIANTS

    def test_unknown_column_falls_back_to_full(self):
        out = home([{"type": "title", "text": "x", "col": "diagonal"}])
        assert next(b for b in out if b["type"] == "title")["col"] == "full"

    def test_alignment_admits_right(self):
        out = home([{"type": "title", "text": "x", "align": "right"}])
        assert next(b for b in out if b["type"] == "title")["align"] == "right"

    def test_divider_thickness_is_clamped(self):
        out = home([{"type": "divider", "thickness": 99}])
        assert next(b for b in out if b["type"] == "divider")["thickness"] in L.DIVIDER_THICKNESS

    def test_divider_thickness_non_numeric_is_safe(self):
        out = home([{"type": "divider", "thickness": "thick"}])
        assert next(b for b in out if b["type"] == "divider")["thickness"] == 1


class TestImageRules:
    def test_a_real_photo_clears_the_preset(self):
        out = home([{"type": "image", "image_url": "https://cdn.example.com/a.jpg", "preset": "violet"}])
        img = next(b for b in out if b["type"] == "image")
        assert img["image_url"].startswith("https://")
        assert img["preset"] == ""

    def test_no_photo_keeps_a_preset(self):
        out = home([{"type": "image", "preset": "forest"}])
        assert next(b for b in out if b["type"] == "image")["preset"] == "forest"


class TestIds:
    def test_a_good_id_is_kept(self):
        out = home([{"id": "b12ab34c", "type": "title", "text": "x"}])
        assert next(b for b in out if b["type"] == "title")["id"] == "b12ab34c"

    def test_a_malformed_id_is_regenerated(self):
        out = home([{"id": "../../etc/passwd", "type": "title", "text": "x"}])
        assert L._ID_RE.match(next(b for b in out if b["type"] == "title")["id"])

    def test_duplicate_ids_are_made_unique(self):
        out = home([
            {"id": "dup", "type": "title", "text": "a"},
            {"id": "dup", "type": "text", "text": "b"},
        ])
        ids = [b["id"] for b in out]
        assert len(ids) == len(set(ids))


class TestBounds:
    def test_the_block_count_is_capped(self):
        out = home([{"type": "title", "text": str(i)} for i in range(200)])
        assert len(out) <= L.MAX_BLOCKS

    def test_a_capped_home_still_has_its_form(self):
        out = home([{"type": "title", "text": str(i)} for i in range(200)])
        assert _types(out).count("form") == 1

    def test_a_heading_is_truncated(self):
        out = home([{"type": "image", "heading": "x" * 500}])
        assert len(next(b for b in out if b["type"] == "image")["heading"]["fr"]) <= L.MAX_HEADING


class TestDefault:
    def test_default_layout_is_a_map_with_a_home_page(self):
        out = L.default_layout("MAX Barcelona")
        assert set(out) == {"home"}
        assert _types(out["home"]).count("form") == 1

    def test_default_layout_seeds_the_event_name(self):
        out = L.default_layout("MAX Barcelona 2026")
        assert any(b.get("heading", {}).get("fr") == "MAX Barcelona 2026" for b in out["home"])


class TestMultilingual:
    def test_a_bare_string_is_read_as_the_default_language(self):
        out = home([{"type": "title", "text": "Bonjour"}])
        assert next(b for b in out if b["type"] == "title")["text"] == {"fr": "Bonjour"}

    def test_each_language_is_kept(self):
        out = home([{"type": "text", "text": {"fr": "Bonjour", "nl": "Hallo", "en": "Hello"}}])
        assert next(b for b in out if b["type"] == "text")["text"] == {
            "fr": "Bonjour", "nl": "Hallo", "en": "Hello"}

    def test_empty_languages_are_dropped(self):
        out = home([{"type": "title", "text": {"fr": "Bonjour", "nl": "", "en": "   "}}])
        assert next(b for b in out if b["type"] == "title")["text"] == {"fr": "Bonjour"}

    def test_the_form_button_falls_back_when_untranslated(self):
        out = home([{"type": "form", "button": {}}])
        assert next(b for b in out if b["type"] == "form")["button"] == {"fr": "Je m'inscris"}


class TestFetch:
    class _Boom:
        def table(self, *_a, **_k):
            raise RuntimeError("no such column")

    class _Fake:
        def __init__(self, rows):
            self._rows = rows

        def table(self, *_a, **_k):
            return self

        def select(self, *_a, **_k):
            return self

        def eq(self, *_a, **_k):
            return self

        def limit(self, *_a, **_k):
            return self

        def execute(self):
            class R:
                pass

            r = R()
            r.data = self._rows
            return r

    def test_a_missing_column_reads_as_none(self):
        assert L.fetch(self._Boom(), "e1") is None

    def test_a_null_value_reads_as_none(self):
        assert L.fetch(self._Fake([{"registration_layout": None}]), "e1") is None

    def test_a_stored_list_comes_back(self):
        rows = [{"registration_layout": [{"type": "title", "text": "hi"}]}]
        assert isinstance(L.fetch(self._Fake(rows), "e1"), list)

    def test_a_stored_map_comes_back(self):
        rows = [{"registration_layout": {"home": [{"type": "title", "text": "hi"}]}}]
        assert isinstance(L.fetch(self._Fake(rows), "e1"), dict)
