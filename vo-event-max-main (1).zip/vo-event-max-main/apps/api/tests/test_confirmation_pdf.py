"""
Tests for the participant confirmation PDF (feedback §16).

The document goes through an airport in somebody's hand, which sets the bar for
what may appear on it and for how much of it there has to be. Three rules carry
everything:

  * **never invent** — a section with nothing behind it is omitted, not printed
    empty, because a traveller reading "Transfer: —" concludes there is no
    transfer and one reading a document without a transfer section asks;
  * **the check-out date is the morning after the last night**, which is the
    off-by-one that has people turning up to a room released at 11;
  * **it is their document** — named after them, and carrying the booking
    reference and the hotel's phone number rather than a tidy summary they then
    have to supplement with three emails.
"""

import pytest

from services import confirmation_pdf as P


FACTS = {
    "participant_name": "Sophie Marceau",
    "event_name": "Sales Convention 2027",
    "event_location": "Istanbul",
    "event_start_date": "2027-03-01",
    "event_end_date": "2027-03-05",
    "email": "sophie@example.com",
    "phone": "+32 470 00 00 00",
    "company": "LivaNova",
    "flights": [{
        "flight_number": "SN2145", "airline": "Brussels Airlines",
        "pnr_code": "X7HK2P", "departure_airport": "BRU",
        "arrival_airport": "IST", "departure_time": "2027-03-01T08:15",
        "arrival_time": "2027-03-01T13:05", "baggage_info": "1 x 23kg",
    }],
    "hotel_nights": [
        {"hotel": "Radisson Blu", "night_date": "2027-03-01", "room_type": "Twin",
         "hotel_address": "Cumhuriyet Cd. 12", "hotel_city": "Istanbul",
         "hotel_contact": "+90 212 000 00 00"},
        {"hotel": "Radisson Blu", "night_date": "2027-03-02"},
        {"hotel": "Radisson Blu", "night_date": "2027-03-03"},
    ],
    "room_number": "304",
    "roommate_name": "Leslie Knope",
    "transfers": [{
        "pickup_location": "IST", "dropoff_location": "Radisson Blu",
        "pickup_time": "2027-03-01T13:45", "vehicle_type": "Van",
    }],
    "activities": [{
        "name": "Bosphorus dinner cruise", "date_time": "2027-03-03T19:00",
        "location": "Kabatas pier",
    }],
}


def _titles(facts, locale="fr"):
    return [s["title"] for s in P.sections(facts, locale)]


def _rows(facts, title, locale="fr"):
    """Every (label, value) of a section, blocks flattened."""
    for section in P.sections(facts, locale):
        if section["title"] == title:
            return [r for block in section["blocks"] for r in block["rows"]]
    return []


def _headings(facts, title, locale="fr"):
    for section in P.sections(facts, locale):
        if section["title"] == title:
            return [b.get("heading", "") for b in section["blocks"]]
    return []


# ===========================================================================
# Nights become a stay
# ===========================================================================

class TestStays:

    def test_three_nights_become_one_stay(self):
        out = P.stays(FACTS["hotel_nights"])
        assert len(out) == 1
        assert out[0]["nights"] == 3

    def test_the_check_out_is_the_morning_after_the_last_night(self):
        assert P.stays(FACTS["hotel_nights"])[0]["check_out"] == "2027-03-04"

    def test_the_check_in_is_the_first_night(self):
        assert P.stays(FACTS["hotel_nights"])[0]["check_in"] == "2027-03-01"

    def test_two_hotels_are_two_stays(self):
        out = P.stays([
            {"hotel": "Radisson", "night_date": "2027-03-01"},
            {"hotel": "Hilton", "night_date": "2027-03-02"},
        ])
        assert [s["hotel"] for s in out] == ["Radisson", "Hilton"]

    def test_a_gap_does_not_split_one_reservation(self):
        # A night spent elsewhere mid-trip is still one booking at the hotel.
        # Two check-ins would have the guest queue at reception twice.
        out = P.stays([
            {"hotel": "Radisson", "night_date": "2027-03-01"},
            {"hotel": "Radisson", "night_date": "2027-03-04"},
        ])
        assert len(out) == 1
        assert (out[0]["check_in"], out[0]["check_out"]) == ("2027-03-01", "2027-03-05")

    def test_a_night_with_no_date_is_dropped_rather_than_guessed(self):
        assert P.stays([{"hotel": "Radisson"}]) == []

    def test_a_malformed_date_does_not_crash_the_document(self):
        out = P.stays([{"hotel": "R", "night_date": "not-a-date"}])
        assert out[0]["check_out"] == "not-a-date"

    def test_the_address_and_phone_survive_from_whichever_night_carries_them(self):
        stay = P.stays(FACTS["hotel_nights"])[0]
        assert stay["address"] == "Cumhuriyet Cd. 12"
        assert stay["contact"] == "+90 212 000 00 00"

    def test_extension_nights_are_counted_separately(self):
        out = P.stays([
            {"hotel": "R", "night_date": "2027-03-01"},
            {"hotel": "R", "night_date": "2027-03-02", "night_kind": "extension"},
        ])
        assert out[0]["nights"] == 2
        assert out[0]["extension_nights"] == 1


# ===========================================================================
# Dates a human reads
# ===========================================================================

class TestDates:

    def test_a_date_is_written_out_not_left_ambiguous(self):
        # 03/03/2027 means two different days depending on who reads it.
        assert P.day("2027-03-03") == "3 mars 2027"
        assert P.day("2027-03-03", "en") == "3 March 2027"
        assert P.day("2027-03-03", "nl") == "3 maart 2027"

    def test_a_time_is_added_when_there_is_one(self):
        assert P.moment("2027-03-01T08:15") == "1 mars 2027 · 08:15"

    def test_midnight_is_not_printed_as_a_time(self):
        # A date stored as a timestamp is not an appointment at 00:00.
        assert P.moment("2027-03-01T00:00") == "1 mars 2027"

    def test_an_unparseable_value_is_printed_rather_than_dropped(self):
        # "Tuesday morning" from a source file is still actionable; a blank
        # where a fact exists is not.
        assert P.day("mardi matin") == "mardi matin"

    def test_an_empty_value_stays_empty(self):
        assert P.day(None) == ""


# ===========================================================================
# Never invent
# ===========================================================================

class TestOnlyWhatIsKnownAppears:

    def test_a_full_file_gets_every_section(self):
        assert _titles(FACTS) == [
            "Vos coordonnées", "Vols", "Hébergement", "Transferts", "Activités",
        ]

    def test_a_missing_transfer_is_omitted_not_printed_empty(self):
        facts = {k: v for k, v in FACTS.items() if k != "transfers"}
        assert "Transferts" not in _titles(facts)

    def test_an_empty_list_counts_as_missing(self):
        assert "Vols" not in _titles({**FACTS, "flights": []})

    def test_a_participant_with_nothing_booked_yields_no_sections(self):
        assert P.sections({"participant_name": "Ada"}) == []

    def test_needs_only_appear_when_declared(self):
        assert "Vos besoins particuliers" not in _titles(FACTS)
        assert "Vos besoins particuliers" in _titles(
            {**FACTS, "dietary_requirements": "Halal"}
        )

    def test_dietary_requirements_reach_the_participants_own_copy(self):
        # Sensitive, but this document goes to the person it is about, and
        # knowing what the kitchen was told is the point of having it.
        rows = _rows({**FACTS, "dietary_requirements": "Halal"}, "Vos besoins particuliers")
        assert ("Régime alimentaire", "Halal") in rows


# ===========================================================================
# The detail that makes it usable at a desk
# ===========================================================================

class TestFlightsCarryTheBookingDetail:

    def test_the_heading_is_the_flight_and_its_route(self):
        assert _headings(FACTS, "Vols") == [
            "SN2145 · Brussels Airport (BRU) → Istanbul Airport (IST)"
        ]

    def test_the_booking_reference_is_on_the_document(self):
        # The one thing an airline desk actually asks for.
        assert ("Référence", "X7HK2P") in _rows(FACTS, "Vols")

    def test_the_airline_and_baggage_are_there_too(self):
        rows = dict(_rows(FACTS, "Vols"))
        assert rows["Compagnie"] == "Brussels Airlines"
        assert rows["Bagages"] == "1 x 23kg"

    def test_departure_and_arrival_are_named_not_arrowed(self):
        rows = dict(_rows(FACTS, "Vols"))
        assert rows["Décollage"] == "1 mars 2027 · 08:15"
        assert rows["Atterrissage"] == "1 mars 2027 · 13:05"

    def test_a_cancelled_flight_says_so_in_its_heading(self):
        facts = {**FACTS, "flights": [{**FACTS["flights"][0], "status": "cancelled"}]}
        assert _headings(facts, "Vols")[0].startswith("[ANNULÉ]")

    def test_a_changed_flight_says_so_too(self):
        facts = {**FACTS, "flights": [{**FACTS["flights"][0], "status": "changed"}]}
        assert _headings(facts, "Vols")[0].startswith("[MODIFIÉ]")

    def test_a_flight_with_only_a_number_still_produces_a_block(self):
        facts = {"flights": [{"flight_number": "SN2145"}]}
        assert _headings(facts, "Vols") == ["SN2145"]


class TestTheHotelBlockGetsSomebodyThere:

    def test_the_address_and_phone_are_printed(self):
        rows = dict(_rows(FACTS, "Hébergement"))
        assert rows["Adresse"] == "Cumhuriyet Cd. 12, Istanbul"
        assert rows["Téléphone"] == "+90 212 000 00 00"

    def test_both_dates_and_the_count_are_shown(self):
        rows = _rows(FACTS, "Hébergement")
        assert ("Arrivée", "1 mars 2027") in rows
        assert ("Départ", "4 mars 2027") in rows
        assert ("", "3 nuit(s)") in rows

    def test_the_room_number_and_the_room_type_are_different_rows(self):
        # Two rows both labelled "Chambre" is how somebody reads 304 as a type.
        rows = dict(_rows(FACTS, "Hébergement"))
        assert rows["N° de chambre"] == "304"
        assert rows["Type de chambre"] == "Twin"

    def test_the_roommate_is_named(self):
        # The one piece of somebody else's data that belongs here: they are
        # about to share a room and need to recognise the name at reception.
        assert ("Avec", "Leslie Knope") in _rows(FACTS, "Hébergement")

    def test_a_room_number_without_a_booked_night_still_appears(self):
        facts = {"room_number": "304"}
        assert ("N° de chambre", "304") in _rows(facts, "Hébergement")

    def test_an_extension_is_flagged_on_the_stay(self):
        facts = {**FACTS, "hotel_nights": FACTS["hotel_nights"] + [
            {"hotel": "Radisson Blu", "night_date": "2027-03-04", "night_kind": "extension"},
        ]}
        values = [v for _, v in _rows(facts, "Hébergement")]
        assert any("extension personnelle" in v for v in values)


class TestTransfersAndActivities:

    def test_a_transfer_shows_its_route_and_pickup(self):
        assert _headings(FACTS, "Transferts") == ["IST → Radisson Blu"]
        assert ("Prise en charge", "1 mars 2027 · 13:45") in _rows(FACTS, "Transferts")

    def test_an_activity_shows_when_and_where(self):
        rows = dict(_rows(FACTS, "Activités"))
        assert rows["Quand"] == "3 mars 2027 · 19:00"
        assert rows["Lieu"] == "Kabatas pier"


class TestTheParticipantsOwnDetails:

    def test_their_contact_details_are_on_the_document(self):
        # A wrong phone number nobody ever showed them stays wrong until the
        # airport.
        rows = dict(_rows(FACTS, "Vos coordonnées"))
        assert rows["Email"] == "sophie@example.com"
        assert rows["Téléphone"] == "+32 470 00 00 00"

    def test_the_block_disappears_when_nothing_is_known(self):
        assert "Vos coordonnées" not in _titles({"participant_name": "Ada"})


class TestLanguages:

    def test_the_titles_follow_the_language(self):
        assert _titles(FACTS, "en")[1:3] == ["Flights", "Accommodation"]
        assert _titles(FACTS, "nl")[1:3] == ["Vluchten", "Accommodatie"]

    def test_an_unknown_language_falls_back_to_french(self):
        assert _titles(FACTS, "de")[1] == "Vols"

    def test_check_in_is_labelled_in_the_chosen_language(self):
        assert ("Check-in", "1 March 2027") in _rows(FACTS, "Accommodation", "en")


# ===========================================================================
# The file itself
# ===========================================================================

class TestRendering:

    def test_it_produces_a_pdf(self):
        data = P.build(FACTS, "fr", organiser="VO Event\nevents@vo.be")
        assert data.startswith(b"%PDF")
        assert len(data) > 1000

    def test_a_nearly_empty_participant_still_produces_a_valid_document(self):
        assert P.build({"participant_name": "Ada"}).startswith(b"%PDF")

    def test_a_long_file_spills_onto_a_second_page_rather_than_off_the_first(self):
        import pymupdf
        facts = {**FACTS, "activities": [
            {"name": f"Activity {i}", "location": "X"} for i in range(90)
        ]}
        doc = pymupdf.open(stream=P.build(facts), filetype="pdf")
        assert doc.page_count > 1
        doc.close()

    def test_everything_that_matters_is_actually_on_the_page(self):
        import pymupdf
        doc = pymupdf.open(stream=P.build(FACTS), filetype="pdf")
        text = "".join(page.get_text() for page in doc)
        doc.close()
        for expected in ("Sophie Marceau", "SN2145", "X7HK2P", "Radisson Blu",
                         "Cumhuriyet Cd. 12", "304", "Leslie Knope",
                         "Bosphorus dinner cruise"):
            assert expected in text, expected

    def test_the_organiser_block_appears_only_when_there_is_one(self):
        import pymupdf
        for organiser, expected in (("VO Event", True), ("", False)):
            doc = pymupdf.open(stream=P.build(FACTS, organiser=organiser), filetype="pdf")
            # Every page: the document now runs to two, and the contact block
            # sits at the end of it.
            text = "".join(page.get_text() for page in doc)
            doc.close()
            assert ("Contact organisation" in text) is expected

    def test_the_generation_date_is_stamped_when_given(self):
        import pymupdf
        doc = pymupdf.open(stream=P.build(FACTS, generated_on="2026-08-16"), filetype="pdf")
        text = "".join(page.get_text() for page in doc)
        doc.close()
        # Two versions of the same confirmation are unarguable without it.
        assert "16 août 2026" in text

    def test_pages_are_numbered_once_there_is_more_than_one(self):
        import pymupdf
        doc = pymupdf.open(stream=P.build(FACTS), filetype="pdf")
        pages, text = doc.page_count, "".join(p.get_text() for p in doc)
        doc.close()
        assert pages > 1
        assert f"Page 1/{pages}" in text

    def test_a_one_page_document_is_not_numbered(self):
        import pymupdf
        doc = pymupdf.open(stream=P.build({"participant_name": "Ada"}), filetype="pdf")
        text = doc[0].get_text()
        doc.close()
        assert "Page 1/1" not in text


class TestCharactersHelveticaCannotDraw:
    """A row of blank boxes on a document somebody carries through an airport
    is worse than a name missing its diacritic."""

    def test_an_unrepresentable_name_is_transliterated_rather_than_blanked(self):
        import pymupdf
        doc = pymupdf.open(
            stream=P.build({"participant_name": "Στέφανος Παπαδόπουλος"}), filetype="pdf"
        )
        text = doc[0].get_text()
        doc.close()
        assert "�" not in text
        assert text.strip()

    def test_ordinary_french_accents_are_untouched(self):
        assert P._latin("Régime végétarien") == "Régime végétarien"

    def test_an_arrow_becomes_something_rather_than_nothing(self):
        # Dropping it turns "BRU → IST" into "BRU IST", which says nothing
        # about which way the person is flying.
        assert P._latin("BRU → IST") == "BRU > IST"

    def test_typographic_punctuation_survives_as_its_plain_twin(self):
        assert P._latin("l’événement — “oui”…") == "l'événement - \"oui\"..."

    def test_a_name_that_survives_nothing_still_renders_something(self):
        assert P._latin("日本語") == "?"


# ===========================================================================
# It is their document
# ===========================================================================

class TestTheDayByDayItinerary:
    """Every other section is filed by category, which is how an organizer
    thinks. A traveller reads Tuesday."""

    def _days(self, facts=None, locale="fr"):
        return P.itinerary(facts or FACTS, locale)

    def test_each_day_that_holds_something_gets_an_entry(self):
        assert [d["date"] for d in self._days()] == [
            "2027-03-01", "2027-03-03", "2027-03-04",
        ]

    def test_the_day_is_labelled_in_words(self):
        assert self._days()[0]["label"] == "1 mars 2027"

    def test_everything_of_a_day_is_in_chronological_order(self):
        times = [t for t, _ in self._days()[0]["entries"] if t]
        assert times == sorted(times)

    def test_flights_transfers_and_hotels_all_appear_together(self):
        texts = " | ".join(text for _, text in self._days()[0]["entries"])
        assert "SN2145" in texts
        assert "Prise en charge" in texts
        assert "Radisson Blu" in texts

    def test_a_hotel_check_in_lands_at_the_END_of_its_day(self):
        # Sorting it at 00:00 puts "arrive at the Radisson" above an 08:15
        # take-off, which is the day read backwards.
        entries = self._days()[0]["entries"]
        assert "Arrivée" in entries[-1][1]
        assert entries[-1][0] == ""            # no invented hour

    def test_a_hotel_check_out_lands_at_the_START_of_its_day(self):
        facts = {**FACTS, "flights": [{
            "flight_number": "SN2146", "departure_time": "2027-03-04T18:40",
        }]}
        entries = [d for d in P.itinerary(facts) if d["date"] == "2027-03-04"][0]["entries"]
        assert "Départ" in entries[0][1]

    def test_an_undated_item_does_not_appear_here(self):
        # It still gets printed in its own section below; what it cannot do is
        # claim a place in a chronology.
        facts = {"activities": [{"name": "Dinner"}]}
        assert P.itinerary(facts) == []

    def test_a_cancelled_flight_is_marked_in_the_timeline_too(self):
        facts = {"flights": [{
            "flight_number": "SN2145", "departure_time": "2027-03-01T08:15",
            "status": "cancelled",
        }]}
        assert "ANNULÉ" in P.itinerary(facts)[0]["entries"][0][1]

    def test_it_speaks_the_chosen_language(self):
        assert "Check-in" in " ".join(
            t for _, t in self._days(locale="en")[0]["entries"]
        )

    def test_a_single_day_trip_still_produces_a_day(self):
        facts = {"flights": [{"flight_number": "X", "departure_time": "2027-03-01T08:15"}]}
        assert len(P.itinerary(facts)) == 1


class TestFlightDetail:

    def test_the_airport_code_becomes_a_place(self):
        # Three letters are what a booking system stores and nobody reads.
        assert P.airport("IST").startswith("Istanbul")
        assert "(IST)" in P.airport("IST")

    def test_an_unknown_code_is_left_alone(self):
        assert P.airport("ZZZ") == "ZZZ"

    def test_an_empty_code_stays_empty(self):
        assert P.airport("") == ""
        assert P.airport(None) == ""

    def test_the_flight_duration_is_computed(self):
        assert P.duration("2027-03-01T08:15", "2027-03-01T13:05") == "4h50"

    def test_a_whole_number_of_hours_reads_cleanly(self):
        assert P.duration("2027-03-01T08:00", "2027-03-01T11:00") == "3h"

    def test_a_negative_duration_is_refused_rather_than_printed(self):
        # It means one of the two timestamps is wrong, and "-3h" on a
        # confirmation is worse than nothing.
        assert P.duration("2027-03-01T13:00", "2027-03-01T08:00") == ""

    def test_an_absurd_duration_is_refused(self):
        assert P.duration("2027-03-01T08:00", "2027-03-09T08:00") == ""

    def test_a_missing_end_gives_no_duration(self):
        assert P.duration("2027-03-01T08:00", None) == ""

    def test_the_duration_reaches_the_flight_block(self):
        assert ("Durée", "4h50") in _rows(FACTS, "Vols")

    def test_the_route_uses_the_full_airport_names(self):
        assert "Istanbul" in _headings(FACTS, "Vols")[0]


class TestTransferAndActivityDetail:

    def test_a_transfer_says_which_leg_it_is(self):
        facts = {**FACTS, "transfers": [
            {**FACTS["transfers"][0], "transfer_type": "arrival"},
        ]}
        assert ("Type", "vers l'hôtel") in _rows(facts, "Transferts")

    def test_an_unknown_leg_is_left_unlabelled_rather_than_guessed(self):
        facts = {**FACTS, "transfers": [
            {**FACTS["transfers"][0], "transfer_type": "other"},
        ]}
        assert "Type" not in dict(_rows(facts, "Transferts"))

    def test_a_waiting_list_is_never_shown_as_a_booking(self):
        # Somebody who turns up believing it was one has been misled by their
        # own confirmation.
        facts = {**FACTS, "activities": [
            {**FACTS["activities"][0], "status": "waitlisted"},
        ]}
        assert _headings(facts, "Activités")[0].startswith("[LISTE D'ATTENTE]")

    def test_a_registered_activity_carries_no_marker(self):
        facts = {**FACTS, "activities": [
            {**FACTS["activities"][0], "status": "registered"},
        ]}
        assert _headings(facts, "Activités")[0] == "Bosphorus dinner cruise"


class TestGatheringSurvivesAMissingColumn:
    """The second half of the same bug report.

    PostgREST fails the WHOLE select when ONE column is absent. Asking for
    room_number and badge_name together, on a database that has the first and
    not the second, returns nothing — and the confirmation comes back without a
    room number that exists, with no error anywhere.
    """

    class _Fake:
        """Refuses any select naming a column this deployment does not have."""

        HAS = {"id", "event_id", "first_name", "last_name", "email", "company",
               "phone", "nationality", "dietary_requirements",
               "room_number", "room_type", "roommate_name",
               "roommate_participant_id"}

        def __init__(self):
            self.asked: list[str] = []

        def table(self, name):
            self._table = name
            return self

        def select(self, columns="*", **_kw):
            self._columns = columns
            if self._table == "participants":
                self.asked.append(columns)
                wanted = {c.strip() for c in columns.split(",")}
                missing = wanted - self.HAS
                if missing and columns != "*":
                    raise RuntimeError(f"column does not exist: {sorted(missing)[0]}")
            return self

        def eq(self, *_a):
            return self

        def maybe_single(self):
            return self

        def execute(self):
            from types import SimpleNamespace
            if self._table != "participants":
                return SimpleNamespace(data=[])
            row = {
                "id": "p1", "event_id": "e1",
                "first_name": "Sophie", "last_name": "Marceau",
                "room_number": "304", "room_type": "Twin",
                "roommate_name": "Leslie Knope",
                "roommate_participant_id": None,
            }
            keep = {c.strip() for c in self._columns.split(",")}
            data = {k: v for k, v in row.items() if k in keep}
            return SimpleNamespace(data=data if self._is_single() else [data])

        def _is_single(self):
            return "event_id" in self._columns

    def test_the_room_number_survives_a_column_that_does_not_exist(self):
        from services import confirmation_service

        fake = self._Fake()
        facts = confirmation_service.facts_for(fake, "p1")
        # It asked for the wide set first, was refused, and narrowed — rather
        # than giving up and returning a fiche with no room.
        assert len(fake.asked) > 2
        assert facts["room_number"] == "304"
        assert facts["roommate_name"] == "Leslie Knope"


class TestFilename:

    def test_the_person_comes_before_the_event(self):
        # Forty of these land in one folder; a name starting with the event
        # sorts them into an indistinguishable block.
        assert P.filename_for(FACTS) == \
            "Confirmation_Sophie_Marceau_Sales_Convention_2027.pdf"

    def test_accents_are_folded_rather_than_mangled(self):
        name = P.filename_for({"participant_name": "Bénédicte Müller"})
        assert name == "Confirmation_Benedicte_Muller.pdf"

    def test_it_survives_a_name_full_of_punctuation(self):
        name = P.filename_for({"participant_name": "O'Brien / Smith*", "event_name": "A:B"})
        assert "/" not in name and "*" not in name and ":" not in name
        assert name.endswith(".pdf")

    def test_it_has_a_fallback_when_nothing_is_known(self):
        assert P.filename_for({}) == "Confirmation.pdf"

    def test_it_never_runs_away_in_length(self):
        assert len(P.filename_for({"participant_name": "x" * 400})) <= 114

    def test_the_header_carries_both_spellings_of_the_name(self):
        header = P.content_disposition({"participant_name": "Bénédicte Müller"})
        # ASCII for every client, UTF-8 for the ones made this century.
        assert 'filename="Confirmation_Benedicte_Muller.pdf"' in header
        assert "filename*=UTF-8''" in header
        assert "B%C3%A9n%C3%A9dicte" in header

    def test_the_header_is_pure_ascii(self):
        # A raw accented byte in a header is mangled or rejected outright.
        header = P.content_disposition({"participant_name": "Bénédicte Müller"})
        header.encode("ascii")

    def test_the_browser_is_allowed_to_read_the_header(self):
        """The bug this pins: the API sends the right filename and the browser
        hides it.

        Only a handful of response headers are visible to a page's own
        JavaScript cross-origin, and the frontend lives on vercel.app while the
        API lives on railway.app. Without an explicit expose_headers the reader
        gets null and silently falls back — every download named
        "confirmation.pdf", with nothing in the console to say why.
        """
        from main import app
        from fastapi.middleware.cors import CORSMiddleware

        cors = [m for m in app.user_middleware if m.cls is CORSMiddleware]
        assert cors, "the API must send CORS headers at all"
        exposed = cors[0].kwargs.get("expose_headers") or []
        assert "Content-Disposition" in exposed
