"""
Tests for an event's own logo on the public registration form (point 11).

The form always showed the same MAX wordmark. _event_logo is read separately
from _find_event_by_token's select on purpose: PostgREST fails the WHOLE
query when one column is absent, and the public form must keep working on a
deployment that has not applied migration 026 yet.
"""

from routers.public_registration import _event_logo


class _Query:
    def __init__(self, row):
        self.row = row

    def select(self, *_a, **_k):
        return self

    def eq(self, *_a, **_k):
        return self

    def maybe_single(self):
        return self

    def execute(self):
        return type("Res", (), {"data": self.row})()


class FakeSupabase:
    def __init__(self, row=None, fail=False):
        self.row = row
        self.fail = fail

    def table(self, _name):
        if self.fail:
            raise RuntimeError('column "logo_url" does not exist')
        return _Query(self.row)


class TestEventLogo:

    def test_a_configured_logo_is_returned(self):
        sb = FakeSupabase({"logo_url": "https://example.public/ev-1/abc.png"})
        assert _event_logo(sb, "ev-1") == "https://example.public/ev-1/abc.png"

    def test_an_event_with_no_logo_returns_none(self):
        sb = FakeSupabase({"logo_url": None})
        assert _event_logo(sb, "ev-1") is None

    def test_an_unknown_event_returns_none(self):
        sb = FakeSupabase(row=None)
        assert _event_logo(sb, "ev-x") is None

    def test_missing_migration_026_is_a_no_op_not_a_500(self):
        sb = FakeSupabase(fail=True)
        assert _event_logo(sb, "ev-1") is None
