"""
Tests for the registration form work (feedback §9), modelled on the reference
form MAX already runs for Coca-Cola (base.timetoreconnect.eu).

Migration 007 made the CATALOGUE configurable — which known fields an event
shows and insists on. What the reference form proved is that a catalogue is
not enough on its own: it asks for a favourite sweet, a favourite song, and it
carries a cancellation policy with a hard date. Fifty built-in fields still
cannot ask the one question this particular trip needs.

So most of what follows is about what a PUBLIC form must refuse. This endpoint
takes JSON from anybody, and whatever it accepts reaches the master list and
every supplier export.
"""

from types import SimpleNamespace

import pytest

EV = "e0000000-0000-0000-0000-000000000001"


class _Query:
    def __init__(self, table, fail=False):
        self._rows = list(table)
        self._fail = fail

    def select(self, *_a, **_k):
        return self

    def eq(self, col, val):
        self._rows = [r for r in self._rows if r.get(col) == val]
        return self

    def limit(self, n):
        self._rows = self._rows[:n]
        return self

    def execute(self):
        if self._fail:
            raise RuntimeError('column "registration_custom_fields" does not exist')
        return SimpleNamespace(data=self._rows)


class FakeDB:
    def __init__(self, missing=(), **tables):
        self.tables = dict(tables)
        self.missing = set(missing)

    def table(self, name):
        return _Query(self.tables.get(name, []), fail=name in self.missing)


# ---------------------------------------------------------------------------
# The catalogue
# ---------------------------------------------------------------------------

class TestRegistrationCatalogue:
    def test_the_fields_that_feed_the_new_engine_are_askable(self):
        # The point of asking at the source: an answer here reaches the pairing
        # step and the extension split without any file ever being imported.
        from services import registration_form
        for key in ("room_type", "roommate", "extension_requested",
                    "extension_start", "extension_end", "extension_hotel"):
            assert key in registration_form.FIELD_KEYS, key

    def test_the_reference_forms_own_blocks_are_covered(self):
        from services import registration_form
        for key in ("civility", "birth_place", "address", "postal_code", "city",
                    "company_vat", "company_address", "company_city",
                    "emergency_contact_country", "shirt_size",
                    "transfer_needed", "arrival_flight", "arrival_airport"):
            assert key in registration_form.FIELD_KEYS, key

    def test_identity_is_still_the_only_thing_no_event_can_switch_off(self):
        from services import registration_form
        assert set(registration_form.LOCKED_KEYS) == {"first_name", "last_name", "email"}

    def test_a_new_field_is_shown_by_default_and_never_required(self):
        # Adding a field to the catalogue must not silently start blocking
        # submissions on events that never asked for it.
        from services import registration_form
        resolved = {f["key"]: f for f in registration_form.resolve(None)}
        assert resolved["roommate"]["enabled"] is True
        assert resolved["roommate"]["required"] is False

    def test_every_field_belongs_to_a_named_section(self):
        from services import registration_form
        assert all(f["group"] for f in registration_form.resolve(None))

    def test_a_field_that_is_off_can_never_be_required(self):
        # That combination makes a form impossible to submit.
        from services import registration_form
        clean = registration_form.sanitize({"roommate": {"enabled": False, "required": True}})
        assert clean["roommate"]["enabled"] is False
        assert clean["roommate"]["required"] is False


# ---------------------------------------------------------------------------
# The organizer's own questions
# ---------------------------------------------------------------------------

class TestOrganizerOwnQuestions:
    def _resolve(self, stored):
        from services import registration_form
        return registration_form.resolve_custom(stored)

    def test_a_plain_question_survives(self):
        got = self._resolve([{"key": "favourite_sweet", "label": "Bonbon prefere"}])
        assert got == [{"key": "favourite_sweet", "label": "Bonbon prefere",
                        "type": "text", "required": False, "options": []}]

    def test_a_label_alone_is_enough_to_derive_a_key(self):
        got = self._resolve([{"label": "Chanson preferee"}])
        assert got[0]["key"] == "chanson_preferee"

    def test_a_key_colliding_with_a_catalogue_field_is_refused(self):
        # Otherwise a custom question would overwrite the email a participant
        # typed into the real field.
        assert self._resolve([{"key": "email", "label": "Votre email"}]) == []

    def test_the_same_key_twice_only_lands_once(self):
        got = self._resolve([{"key": "size", "label": "A"}, {"key": "size", "label": "B"}])
        assert len(got) == 1
        assert got[0]["label"] == "A"

    def test_a_select_keeps_its_options(self):
        got = self._resolve([{"key": "k", "label": "L", "type": "select",
                              "options": ["Rouge", "Bleu"]}])
        assert got[0]["type"] == "select"
        assert got[0]["options"] == ["Rouge", "Bleu"]

    def test_a_select_with_no_options_degrades_to_free_text(self):
        # An empty dropdown is a dead end a visitor cannot get past.
        got = self._resolve([{"key": "k", "label": "L", "type": "select", "options": []}])
        assert got[0]["type"] == "text"

    def test_an_unknown_type_falls_back_to_text(self):
        got = self._resolve([{"key": "k", "label": "L", "type": "rocket"}])
        assert got[0]["type"] == "text"

    @pytest.mark.parametrize("stored", [None, {}, "questions", [None], [42], [{}],
                                        [{"label": "   "}], [{"key": "   "}]])
    def test_a_malformed_definition_never_renders_a_broken_form(self, stored):
        assert self._resolve(stored) == []

    def test_the_number_of_questions_is_bounded(self):
        got = self._resolve([{"key": "q%d" % i, "label": "Q%d" % i} for i in range(200)])
        assert len(got) == 30

    def test_a_very_long_label_is_truncated_rather_than_rejected(self):
        got = self._resolve([{"key": "k", "label": "x" * 5000}])
        assert len(got[0]["label"]) == 200

    def test_a_required_question_left_blank_is_reported_by_its_label(self):
        from services import registration_form
        custom = self._resolve([{"key": "sweet", "label": "Bonbon prefere", "required": True}])
        assert registration_form.missing_custom(custom, {}) == ["Bonbon prefere"]
        assert registration_form.missing_custom(custom, {"sweet": "   "}) == ["Bonbon prefere"]
        assert registration_form.missing_custom(custom, {"sweet": "carambar"}) == []

    def test_an_optional_question_is_never_reported(self):
        from services import registration_form
        custom = self._resolve([{"key": "sweet", "label": "Bonbon"}])
        assert registration_form.missing_custom(custom, {}) == []

    def test_an_answer_to_a_question_the_event_never_asked_is_dropped(self):
        # The endpoint is public and this dict reaches the master list and
        # every supplier export.
        from services import registration_form
        custom = self._resolve([{"key": "sweet", "label": "Bonbon"}])
        kept = registration_form.keep_custom_answers(
            custom, {"sweet": "carambar", "injected": "payload", "email": "x@y.z"}
        )
        assert kept == {"sweet": "carambar"}

    def test_a_blank_answer_is_not_stored_as_an_empty_string(self):
        from services import registration_form
        custom = self._resolve([{"key": "sweet", "label": "Bonbon"}])
        assert registration_form.keep_custom_answers(custom, {"sweet": "   "}) == {}

    @pytest.mark.parametrize("answers", [None, "carambar", 42, []])
    def test_a_malformed_answers_payload_yields_nothing(self, answers):
        from services import registration_form
        custom = self._resolve([{"key": "sweet", "label": "Bonbon"}])
        assert registration_form.keep_custom_answers(custom, answers) == {}


# ---------------------------------------------------------------------------
# The contractual tick-boxes
# ---------------------------------------------------------------------------

class TestContractualConfirmations:
    def _resolve(self, stored):
        from services import registration_form
        return registration_form.resolve_confirmations(stored)

    def test_the_organizers_wording_is_kept_verbatim(self):
        text = ("Je confirme ma participation definitive et ne pourrai pas participer "
                "a l'incentive 2026 si j'annule apres le 15 juillet.")
        got = self._resolve([{"key": "cancel", "label": "Politique d'annulation", "text": text}])
        assert got[0]["text"] == text

    def test_a_label_with_no_separate_wording_is_kept_not_dropped(self):
        # Terse, but present. Silently dropping a confirmation an organizer
        # believes they added is the far worse failure: they would think the
        # cancellation policy is on the form when it is not.
        got = self._resolve([{"key": "k", "label": "Politique d'annulation"}])
        assert got[0]["text"] == "Politique d'annulation"

    def test_a_confirmation_with_neither_label_nor_wording_is_dropped(self):
        # Nothing to show and nothing to agree to.
        assert self._resolve([{"key": "k"}]) == []

    def test_the_label_falls_back_to_the_wording_when_absent(self):
        got = self._resolve([{"key": "k", "text": "Je confirme."}])
        assert got[0]["label"] == "Je confirme."

    def test_every_confirmation_must_be_ticked(self):
        from services import registration_form
        confs = self._resolve([
            {"key": "a", "label": "Annulation", "text": "..."},
            {"key": "b", "label": "Contact commercial", "text": "..."},
        ])
        assert registration_form.missing_confirmations(confs, {}) == [
            "Annulation", "Contact commercial"]
        assert registration_form.missing_confirmations(confs, {"a": True}) == [
            "Contact commercial"]
        assert registration_form.missing_confirmations(confs, {"a": True, "b": True}) == []

    @pytest.mark.parametrize("value", ["true", 1, "on", "yes", None, 0, False, "True"])
    def test_only_a_real_boolean_true_counts_as_agreement(self, value):
        # A contractual box is not something to accept on a truthy string.
        from services import registration_form
        confs = self._resolve([{"key": "a", "label": "Annulation", "text": "..."}])
        assert registration_form.missing_confirmations(confs, {"a": value}) == ["Annulation"]

    @pytest.mark.parametrize("stored", [None, {}, [None], [{}], "yes", [42]])
    def test_a_malformed_definition_yields_nothing_to_confirm(self, stored):
        assert self._resolve(stored) == []

    @pytest.mark.parametrize("ticked", [None, "yes", 42, []])
    def test_a_malformed_tick_payload_confirms_nothing(self, ticked):
        from services import registration_form
        confs = self._resolve([{"key": "a", "label": "Annulation", "text": "..."}])
        assert registration_form.missing_confirmations(confs, ticked) == ["Annulation"]


# ---------------------------------------------------------------------------
# Before migration 010
# ---------------------------------------------------------------------------

class TestRegistrationExtrasDegradeWithoutMigration:
    def test_fetch_extras_returns_two_empty_lists(self):
        from services import registration_form
        assert registration_form.fetch_extras(FakeDB(missing=("events",)), EV) == ([], [])

    def test_an_event_that_defined_nothing_looks_exactly_the_same(self):
        from services import registration_form
        db = FakeDB(events=[{"id": EV, "registration_custom_fields": None,
                             "registration_confirmations": None}])
        assert registration_form.fetch_extras(db, EV) == ([], [])

    def test_the_field_catalogue_is_unaffected_by_the_missing_column(self):
        # fetch_extras and fetch() are separate selects precisely so one
        # missing column cannot take the other down.
        from services import registration_form
        assert registration_form.fetch(FakeDB(missing=("events",)), EV) is None
        assert len(registration_form.resolve(None)) == len(registration_form.FIELD_KEYS)


# ---------------------------------------------------------------------------
# Field order (point 13, v1)
# ---------------------------------------------------------------------------

class TestFieldOrder:
    def test_no_stored_order_keeps_catalogue_order(self):
        from services import registration_form
        resolved = registration_form.resolve(None)
        assert [f["key"] for f in resolved] == list(registration_form.FIELD_KEYS)

    def test_a_stored_order_is_applied(self):
        from services import registration_form
        resolved = registration_form.resolve({"_order": ["email", "roommate", "first_name"]})
        keys = [f["key"] for f in resolved]
        assert keys.index("email") < keys.index("roommate") < keys.index("first_name")

    def test_fields_left_out_of_the_order_are_appended_not_dropped(self):
        # An order saved before a field existed must not make that field
        # vanish from the form.
        from services import registration_form
        resolved = registration_form.resolve({"_order": ["email"]})
        assert len(resolved) == len(registration_form.FIELD_KEYS)
        assert resolved[0]["key"] == "email"

    def test_an_unknown_key_in_the_order_is_dropped(self):
        from services import registration_form
        resolved = registration_form.resolve({"_order": ["email", "not_a_real_field"]})
        assert "not_a_real_field" not in [f["key"] for f in resolved]
        assert len(resolved) == len(registration_form.FIELD_KEYS)

    @pytest.mark.parametrize("order", [None, "email", 42, {"a": 1}])
    def test_a_malformed_order_falls_back_to_catalogue_order(self, order):
        from services import registration_form
        resolved = registration_form.resolve({"_order": order})
        assert [f["key"] for f in resolved] == list(registration_form.FIELD_KEYS)

    def test_sanitize_keeps_a_valid_order(self):
        from services import registration_form
        clean = registration_form.sanitize({"_order": ["email", "roommate"]})
        assert clean["_order"] == ["email", "roommate"]

    def test_sanitize_drops_unknown_keys_from_the_order(self):
        from services import registration_form
        clean = registration_form.sanitize({"_order": ["email", "not_real"]})
        assert clean["_order"] == ["email"]

    def test_sanitize_with_no_order_omits_the_key_entirely(self):
        # Nothing to fall back to at read time except the plain catalogue —
        # resolve() already handles that when _order is simply absent.
        from services import registration_form
        clean = registration_form.sanitize({})
        assert "_order" not in clean


# ---------------------------------------------------------------------------
# Badges (point 13, v1)
# ---------------------------------------------------------------------------

class TestBadgeVisibility:
    def test_a_field_with_no_badges_is_visible_to_every_badge(self):
        from services import registration_form
        resolved = registration_form.resolve({"roommate": {"enabled": True}}, badge="vip")
        assert "roommate" in [f["key"] for f in resolved]

    def test_a_field_restricted_to_a_badge_is_hidden_from_another(self):
        from services import registration_form
        config = {"shirt_size": {"enabled": True, "badges": ["vip"]}}
        assert "shirt_size" in [f["key"] for f in registration_form.resolve(config, badge="vip")]
        assert "shirt_size" not in [f["key"] for f in registration_form.resolve(config, badge="staff")]

    def test_no_badge_requested_shows_every_field_regardless_of_restriction(self):
        # The organizer's own dashboard view — nothing is filtered there.
        from services import registration_form
        config = {"shirt_size": {"enabled": True, "badges": ["vip"]}}
        assert "shirt_size" in [f["key"] for f in registration_form.resolve(config)]

    def test_a_locked_identity_field_ignores_badge_restriction(self):
        from services import registration_form
        config = {"email": {"badges": ["vip"]}}
        resolved = {f["key"]: f for f in registration_form.resolve(config, badge="staff")}
        assert resolved["email"]["enabled"] is True
        assert resolved["email"]["badges"] == []

    def test_a_field_may_belong_to_several_badges(self):
        from services import registration_form
        config = {"shirt_size": {"enabled": True, "badges": ["vip", "staff"]}}
        assert "shirt_size" in [f["key"] for f in registration_form.resolve(config, badge="staff")]

    def test_sanitize_keeps_a_valid_badge_list_on_a_field(self):
        from services import registration_form
        clean = registration_form.sanitize({"shirt_size": {"badges": ["vip", "vip", "  "]}})
        assert clean["shirt_size"]["badges"] == ["vip"]

    def test_sanitize_forces_a_locked_field_to_have_no_badges(self):
        from services import registration_form
        clean = registration_form.sanitize({"email": {"badges": ["vip"]}})
        assert clean["email"]["badges"] == []

    def test_a_malformed_badge_list_on_a_field_yields_visible_to_everyone(self):
        from services import registration_form
        config = {"shirt_size": {"enabled": True, "badges": "vip"}}
        assert "shirt_size" in [f["key"] for f in registration_form.resolve(config, badge="staff")]


class TestBadgeCatalogue:
    def test_a_plain_badge_survives(self):
        from services import registration_form
        got = registration_form.resolve_badges([{"id": "vip", "name": "VIP"}])
        assert got == [{"id": "vip", "name": "VIP"}]

    def test_a_name_alone_is_enough_to_derive_an_id(self):
        from services import registration_form
        got = registration_form.resolve_badges([{"name": "Staff Général"}])
        assert got[0]["id"] == "staff-général"

    def test_two_badges_that_slugify_the_same_get_distinct_ids(self):
        from services import registration_form
        got = registration_form.resolve_badges([{"name": "VIP"}, {"name": "VIP"}])
        ids = [b["id"] for b in got]
        assert len(ids) == len(set(ids)) == 2

    def test_a_badge_with_no_name_is_dropped(self):
        from services import registration_form
        assert registration_form.resolve_badges([{"id": "x", "name": "  "}]) == []

    @pytest.mark.parametrize("stored", [None, {}, "vip", [None], [42], [{}]])
    def test_a_malformed_badge_list_never_renders_a_broken_form(self, stored):
        from services import registration_form
        assert registration_form.resolve_badges(stored) == []

    def test_the_number_of_badges_is_bounded(self):
        from services import registration_form
        got = registration_form.resolve_badges([{"name": "B%d" % i} for i in range(50)])
        assert len(got) == registration_form._MAX_BADGES

    def test_a_very_long_name_is_truncated_rather_than_rejected(self):
        from services import registration_form
        got = registration_form.resolve_badges([{"name": "x" * 500}])
        assert len(got[0]["name"]) == registration_form._BADGE_NAME_MAX


class TestSlugify:
    def test_spaces_become_hyphens(self):
        from services import registration_form
        assert registration_form._slugify("Staff Général") == "staff-général"

    def test_repeated_separators_collapse(self):
        from services import registration_form
        assert registration_form._slugify("VIP   ++  Gold") == "vip-gold"

    def test_leading_and_trailing_hyphens_are_stripped(self):
        from services import registration_form
        assert registration_form._slugify("--VIP--") == "vip"


class TestFetchBadges:
    def test_fetch_badges_returns_empty_list_before_migration_027(self):
        from services import registration_form
        assert registration_form.fetch_badges(FakeDB(missing=("events",)), EV) == []

    def test_an_event_that_defined_nothing_looks_exactly_the_same(self):
        from services import registration_form
        db = FakeDB(events=[{"id": EV, "registration_badges": None}])
        assert registration_form.fetch_badges(db, EV) == []

    def test_an_events_own_badges_are_returned_resolved(self):
        from services import registration_form
        db = FakeDB(events=[{"id": EV, "registration_badges": [{"id": "vip", "name": "VIP"}]}])
        assert registration_form.fetch_badges(db, EV) == [{"id": "vip", "name": "VIP"}]
