"""
Tests for column-mapping memory scoped to the project (points 5+6).

column_mapping_templates already remembered a confirmed mapping so an
identical file layout skipped review next time. It was scoped to the
ORGANISATION: an agency running two different clients under one org could
have one client's confirmed column meaning silently applied to the other's
file, purely because both happened to export a similarly-shaped spreadsheet.

These tests cover the fix: project_id is now the actual scoping key, and
without it there is no match — no signal is safer than a signal that might
be wrong.
"""

from services import consolidation_service as C


class _Query:
    def __init__(self, table):
        self.t = table
        self.rows = list(table.rows)
        self._single = False
        self._updating = None
        self.inserted = None

    def select(self, *_a, **_k):
        return self

    def eq(self, col, val):
        self.rows = [r for r in self.rows if str(r.get(col)) == str(val)]
        return self

    def limit(self, n):
        self.rows = self.rows[:n]
        return self

    def single(self):
        self._single = True
        return self

    def update(self, patch):
        self._updating = patch
        return self

    def insert(self, row):
        self.inserted = row
        self.t.rows.append(dict(row, id=f"tpl-{len(self.t.rows)}"))
        return self

    def execute(self):
        if self._updating is not None:
            for row in self.t.rows:
                if row in self.rows:
                    row.update(self._updating)
            return type("Res", (), {"data": self.rows})()
        data = self.rows[0] if self._single else self.rows
        return type("Res", (), {"data": data})()


class _Table:
    def __init__(self, rows):
        self.rows = rows


class FakeSupabase:
    def __init__(self, templates=None, events=None):
        self.templates = _Table(list(templates or []))
        self.events = _Table(list(events or []))

    def table(self, name):
        if name == "column_mapping_templates":
            return _Query(self.templates)
        if name == "events":
            return _Query(self.events)
        return _Query(_Table([]))


def _template(**over):
    base = {
        "id": "tpl-1", "org_id": "org-1", "project_id": "proj-1",
        "template_name": "sig-abc", "mapping": {"Nom": "last_name"},
    }
    base.update(over)
    return base


class TestEventProjectId:

    def test_resolves_the_project_from_the_event(self):
        sb = FakeSupabase(events=[{"id": "ev-1", "project_id": "proj-1"}])
        assert C.event_project_id(sb, "ev-1") == "proj-1"

    def test_an_unknown_event_resolves_to_none(self):
        sb = FakeSupabase(events=[])
        assert C.event_project_id(sb, "ev-x") is None


class TestKnownFormatMappingIsProjectScoped:

    def test_a_match_in_the_same_project_is_found(self):
        sb = FakeSupabase(templates=[_template()])
        got = C.known_format_mapping(sb, "org-1", "proj-1", "sig-abc")
        assert got == {"Nom": "last_name"}

    def test_the_same_signature_in_a_different_project_does_not_match(self):
        # This is the exact leak being fixed: two clients, same org, same
        # file shape, must never share a mapping.
        sb = FakeSupabase(templates=[_template(project_id="proj-1")])
        got = C.known_format_mapping(sb, "org-1", "proj-2", "sig-abc")
        assert got is None

    def test_no_project_id_at_all_never_matches(self):
        # No signal is safer than a signal that might be wrong.
        sb = FakeSupabase(templates=[_template()])
        assert C.known_format_mapping(sb, "org-1", None, "sig-abc") is None

    def test_a_row_saved_before_the_migration_has_no_project_and_never_matches(self):
        sb = FakeSupabase(templates=[_template(project_id=None)])
        assert C.known_format_mapping(sb, "org-1", "proj-1", "sig-abc") is None

    def test_a_lookup_failure_is_not_an_outage(self):
        sb = FakeSupabase(templates=[_template()])
        sb.table = lambda _n: (_ for _ in ()).throw(RuntimeError("down"))
        assert C.known_format_mapping(sb, "org-1", "proj-1", "sig-abc") is None


class TestRememberingAFormat:

    def test_a_new_project_signature_is_inserted(self):
        sb = FakeSupabase(templates=[])
        C.remember_format(sb, "org-1", "proj-1", "fcm", "sig-new", {"A": "first_name"}, "u-1")
        assert len(sb.templates.rows) == 1
        assert sb.templates.rows[0]["project_id"] == "proj-1"
        assert sb.templates.rows[0]["mapping"] == {"A": "first_name"}

    def test_the_same_project_signature_updates_rather_than_duplicates(self):
        sb = FakeSupabase(templates=[_template(mapping={"Nom": "last_name"})])
        C.remember_format(sb, "org-1", "proj-1", "fcm", "sig-abc", {"Nom": "first_name"}, "u-1")
        assert len(sb.templates.rows) == 1
        assert sb.templates.rows[0]["mapping"] == {"Nom": "first_name"}

    def test_the_same_signature_in_another_project_is_a_separate_row(self):
        sb = FakeSupabase(templates=[_template(project_id="proj-1")])
        C.remember_format(sb, "org-1", "proj-2", "fcm", "sig-abc", {"Nom": "last_name"}, "u-1")
        assert len(sb.templates.rows) == 2

    def test_without_a_project_id_nothing_is_written(self):
        sb = FakeSupabase(templates=[])
        C.remember_format(sb, "org-1", None, "fcm", "sig-abc", {"Nom": "last_name"}, "u-1")
        assert sb.templates.rows == []

    def test_without_a_mapping_nothing_is_written(self):
        sb = FakeSupabase(templates=[])
        C.remember_format(sb, "org-1", "proj-1", "fcm", "sig-abc", {}, "u-1")
        assert sb.templates.rows == []
