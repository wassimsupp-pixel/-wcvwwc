"""
Tests for deciding which way a flight is going.

The flights table carries no direction marker, so the dispatcher infers it. For
somebody with two segments that is easy — earliest is the way there, latest the
way home. For somebody with ONE segment it used to be assumed to be an arrival,
always.

That assumption was wrong for the people whose file holds only their way home,
and it stayed invisible for as long as every transfer took a single hardcoded
pickup location: the sheet said "BRU airport" for everybody, so a wrong
direction produced a wrong-but-plausible line. Reading the airport off each
person's own flight made it visible — three people in the live data, one
segment each, ATH->WAW, ATH->BRU and IST->IAH, for whom the plan proposed a van
waiting at Warsaw to drive them to a hotel in Athens, while the departure
transfer they actually needed was never proposed at all.

A lone segment is now placed by where it goes.
"""

import pytest

from routers.transfers import _event_hub, _split_legs


def leg(pid, dep_apt, arr_apt, when, number="XX000"):
    return {
        "participant_id": pid, "flight_number": number,
        "departure_airport": dep_apt, "arrival_airport": arr_apt,
        "departure_time": when, "arrival_time": when,
    }


def athens_crowd():
    """Enough round trips through ATH for the hub to be unambiguous."""
    out = []
    for i, home in enumerate(["BRU", "MAD", "FRA", "LHR", "CDG", "MXP"]):
        out.append(leg(f"p{i}", home, "ATH", f"2026-09-0{1}T08:00:00"))
        out.append(leg(f"p{i}", "ATH", home, "2026-09-09T18:00:00"))
    return out


class TestFindingTheEventAirport:

    def test_the_airport_everybody_passes_through_wins(self):
        assert _event_hub(athens_crowd()) == "ATH"

    def test_nothing_dominant_means_no_hub_rather_than_a_guess(self):
        # Four unrelated one-way legs: no airport repeats enough to be an
        # event hub, and inventing one would misroute all four.
        flights = [
            leg("p1", "BRU", "MAD", "2026-09-01T08:00:00"),
            leg("p2", "FRA", "LHR", "2026-09-01T09:00:00"),
            leg("p3", "CDG", "MXP", "2026-09-01T10:00:00"),
            leg("p4", "LIS", "OPO", "2026-09-01T11:00:00"),
        ]
        assert _event_hub(flights) == ""

    def test_flights_with_no_airports_at_all_do_not_crash_it(self):
        assert _event_hub([{"participant_id": "p1"}]) == ""
        assert _event_hub([]) == ""

    def test_case_and_padding_do_not_split_the_count(self):
        flights = athens_crowd()
        flights[0]["arrival_airport"] = "  ath  "
        assert _event_hub(flights) == "ATH"


class TestALoneSegmentIsPlacedByWhereItGoes:

    def test_a_lone_leg_leaving_the_event_airport_is_a_way_home(self):
        # The live case: one segment, ATH -> WAW. This person needs a van TO
        # the airport, not one waiting for them in Warsaw.
        flights = athens_crowd() + [leg("solo", "ATH", "WAW", "2026-09-09T15:55:00")]
        inbound, outbound = _split_legs(flights)
        assert not any(f["participant_id"] == "solo" for f in inbound)
        assert any(f["participant_id"] == "solo" for f in outbound)

    def test_a_lone_leg_arriving_at_the_event_airport_is_still_a_way_there(self):
        flights = athens_crowd() + [leg("solo", "WAW", "ATH", "2026-09-01T09:00:00")]
        inbound, outbound = _split_legs(flights)
        assert any(f["participant_id"] == "solo" for f in inbound)
        assert not any(f["participant_id"] == "solo" for f in outbound)

    def test_with_no_identifiable_hub_a_lone_leg_stays_an_arrival(self):
        # The old assumption, kept where it is still the better guess.
        flights = [leg("solo", "BRU", "MAD", "2026-09-01T08:00:00")]
        inbound, outbound = _split_legs(flights)
        assert len(inbound) == 1
        assert outbound == []

    def test_a_lone_leg_touching_neither_end_of_the_hub_is_an_arrival(self):
        flights = athens_crowd() + [leg("solo", "BRU", "MAD", "2026-09-01T08:00:00")]
        inbound, _ = _split_legs(flights)
        assert any(f["participant_id"] == "solo" for f in inbound)


class TestTwoSegmentsAreUnchanged:

    def test_earliest_is_the_way_there_and_latest_the_way_home(self):
        inbound, outbound = _split_legs(athens_crowd())
        assert len(inbound) == 6
        assert len(outbound) == 6
        assert all(f["arrival_airport"] == "ATH" for f in inbound)
        assert all(f["departure_airport"] == "ATH" for f in outbound)

    def test_a_middle_segment_is_neither(self):
        # Somebody with a stopover booked as its own row: only the first and
        # last legs drive a transfer.
        flights = athens_crowd() + [
            leg("hop", "JFK", "CDG", "2026-09-01T06:00:00"),
            leg("hop", "CDG", "ATH", "2026-09-01T12:00:00"),
            leg("hop", "ATH", "JFK", "2026-09-09T19:00:00"),
        ]
        inbound, outbound = _split_legs(flights)
        theirs_in = [f for f in inbound if f["participant_id"] == "hop"]
        theirs_out = [f for f in outbound if f["participant_id"] == "hop"]
        assert len(theirs_in) == 1 and theirs_in[0]["departure_airport"] == "JFK"
        assert len(theirs_out) == 1 and theirs_out[0]["arrival_airport"] == "JFK"

    def test_nobody_is_dropped_or_counted_twice(self):
        flights = athens_crowd() + [
            leg("solo_out", "ATH", "WAW", "2026-09-09T15:55:00"),
            leg("solo_in", "WAW", "ATH", "2026-09-01T09:00:00"),
        ]
        inbound, outbound = _split_legs(flights)
        people = {f["participant_id"] for f in flights}
        placed = {f["participant_id"] for f in inbound} | {f["participant_id"] for f in outbound}
        assert placed == people
        for pid in people:
            assert sum(1 for f in inbound if f["participant_id"] == pid) <= 1
            assert sum(1 for f in outbound if f["participant_id"] == pid) <= 1


class TestTheWholePlanEndsUpAtOneAirport:

    def test_every_arrival_is_collected_at_the_hub(self):
        from services import dispatch_service as D
        flights = athens_crowd() + [leg("solo", "ATH", "WAW", "2026-09-09T15:55:00")]
        inbound, outbound = _split_legs(flights)
        settings = D.resolve_settings({"hotel_name": "Hôtel Athenaeum"})
        arrivals = D.propose_arrivals(inbound, settings)
        departures = D.propose_departures(outbound, settings)
        assert {g["pickup_location"] for g in arrivals} == {"ATH"}
        assert {g["dropoff_location"] for g in departures} == {"ATH"}
        assert {g["dropoff_location"] for g in arrivals} == {"Hôtel Athenaeum"}


@pytest.mark.parametrize("missing", [None, "", "   "])
def test_a_flight_with_no_departure_airport_is_treated_as_an_arrival(missing):
    flights = athens_crowd() + [leg("solo", missing, "ATH", "2026-09-01T09:00:00")]
    inbound, _ = _split_legs(flights)
    assert any(f["participant_id"] == "solo" for f in inbound)
