"""
Tests that the "Champs manquants" cards name the field in French.

The dietary check never stopped running — 69 exceptions on one live event, 98
on another, at the moment this was written. What it stopped doing was looking
like itself: the per-person card interpolated the raw column name, so somebody
hunting for their dietary alert read

    Fiche de « Johanna Stenqvist » incomplète — champ(s) manquant(s) : dietary_requirements.

and concluded the feature had been removed. The systemic warning right beside
it already said "régime alimentaire", because the labels existed — they were
just declared halfway down the function, after the per-person loop had already
run.

A check nobody recognises is a check nobody acts on, which is the same outcome
as not having it.
"""

from unittest.mock import patch

import pytest

from services import exception_service as E
from services import field_policy


class FakeQuery:
    def __init__(self, rows):
        self.rows = rows

    def select(self, *_a, **_k):
        return self

    def eq(self, *_a, **_k):
        return self

    def execute(self):
        return type("Res", (), {"data": self.rows})()


class FakeDB:
    def __init__(self, participants):
        self.participants = participants

    def table(self, _name):
        return FakeQuery(self.participants)


def person(n, **over):
    base = {
        "id": f"p{n}", "first_name": f"Prénom{n}", "last_name": f"Nom{n}",
        "email": f"p{n}@x.com", "phone": "+32 400", "nationality": "Belge",
        "dietary_requirements": "Aucun",
    }
    base.update(over)
    return base


# An event that does insist on knowing everyone's diet — a plated dinner. Used
# by the cases about the dietary LABEL, which are only reachable once the field
# is required; the default (blank is normal) is asserted separately below.
STRICT = field_policy.resolve({"dietary_requirements": field_policy.REQUIRED})


def run(participants, total=None, policy=None):
    """The detector, with the insert captured rather than performed."""
    captured = []
    with patch.object(E, "_insert_exception",
                      side_effect=lambda **kw: captured.append(kw)):
        E._detect_missing_profile_fields(
            "ev-1", "run-1", FakeDB(participants), [],
            total_participants=total if total is not None else len(participants),
            policy=policy if policy is not None else field_policy.resolve(None),
        )
    return captured


class TestTheCardNamesTheFieldAsAHumanWouldSayIt:

    def test_a_missing_diet_reads_regime_alimentaire(self):
        cards = run([person(1, dietary_requirements="")], policy=STRICT)
        assert len(cards) == 1
        assert "régime alimentaire" in cards[0]["message"]
        assert "dietary_requirements" not in cards[0]["message"]

    @pytest.mark.parametrize("field,label", [
        ("email", "email"),
        ("phone", "téléphone"),
        ("nationality", "nationalité"),
        ("first_name", "prénom"),
        ("dietary_requirements", "régime alimentaire"),
    ])
    def test_every_tracked_field_has_a_french_label(self, field, label):
        # first_name blank alone still produces a card as long as last_name is
        # there — a fiche with NO name at all is reported as critical elsewhere.
        # STRICT so the dietary case is reachable: by default a blank diet is
        # not a gap at all, which its own test below asserts.
        cards = run([person(1, **{field: ""})], policy=STRICT)
        assert len(cards) == 1
        assert label in cards[0]["message"]

    def test_several_missing_fields_are_all_named(self):
        cards = run([person(1, dietary_requirements="", nationality="")], policy=STRICT)
        message = cards[0]["message"]
        assert "nationalité" in message and "régime alimentaire" in message

    def test_no_label_is_missing_from_the_table(self):
        # The table and the tracked list must not drift apart: a field added to
        # one and not the other reintroduces the raw column name on the card.
        assert set(E._MISSING_PROFILE_FIELDS) <= set(E._FIELD_LABELS)


class TestTheMachineReadablePartIsUnchanged:

    def test_context_data_still_carries_the_raw_keys(self):
        # The label is for the human; the UI groups by the key, so translating
        # context_data would drop the person out of their sub-category.
        cards = run([person(1, dietary_requirements="")], policy=STRICT)
        assert cards[0]["context_data"]["missing_fields"] == ["dietary_requirements"]
        assert cards[0]["context_data"]["category"] == "missing_field"

    def test_a_complete_fiche_produces_nothing(self):
        assert run([person(1)]) == []

    def test_a_fiche_with_no_name_at_all_is_left_to_the_critical_check(self):
        cards = run([person(1, first_name="", last_name="", dietary_requirements="")])
        assert cards == []


class TestTheSystemicWarningStillFires:

    def test_a_field_blank_on_nearly_everybody_gets_its_own_warning(self):
        # 20 of 20 without a diet: that is a mapping problem, not 20 people
        # forgetting the same box.
        people = [person(n, dietary_requirements="") for n in range(1, 21)]
        cards = run(people, total=20, policy=STRICT)
        systemic = [c for c in cards if c["severity"] == "warning"]
        assert len(systemic) == 1
        assert "régime alimentaire" in systemic[0]["message"]
        assert "mapping" in systemic[0]["message"].lower()


class TestABlankDietIsNormal:
    """A missing dietary requirement is the answer, not a gap.

    Most people eat everything, so a blank field means "nothing special" —
    which is exactly what the organizer needs to know. Treating it as an
    anomaly produced 69 cards out of 82 participants on one live event and 98
    out of 105 on another: 236 alerts whose entire content was "this person
    has no dietary restriction", burying the handful of real problems
    underneath them.
    """

    def test_it_is_not_required_by_default(self):
        assert field_policy.resolve(None)["dietary_requirements"] == field_policy.OPTIONAL

    def test_a_blank_diet_alone_raises_nothing(self):
        assert run([person(1, dietary_requirements="")]) == []

    def test_a_whole_event_without_diets_raises_nothing(self):
        people = [person(n, dietary_requirements="") for n in range(1, 21)]
        assert run(people, total=20) == []

    def test_a_real_gap_beside_it_is_still_reported_alone(self):
        cards = run([person(1, dietary_requirements="", email="")])
        assert len(cards) == 1
        assert "email" in cards[0]["message"]
        assert "régime" not in cards[0]["message"]
        assert cards[0]["context_data"]["missing_fields"] == ["email"]

    def test_an_event_that_asks_for_it_still_gets_its_alerts(self):
        # The escape hatch: a plated dinner that needs everyone's answer.
        cards = run([person(1, dietary_requirements="")], policy=STRICT)
        assert len(cards) == 1
        assert "régime alimentaire" in cards[0]["message"]
