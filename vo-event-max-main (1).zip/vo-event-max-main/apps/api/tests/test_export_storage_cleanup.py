"""
Tests for the export files left behind when an event is deleted.

Found on 2026-08-18 by listing the bucket: 63 unreachable objects, the oldest
from 9 July. ``delete_event`` removes the ``exports`` ROWS and
``_remove_event_storage`` only ever read ``uploaded_files``, so every deleted
event abandoned its export files — and the paths went with the rows, which is
what makes them unreachable rather than merely untidy.

A master list carries passport numbers, dietary requirements and medical
information. An unreachable copy of one is the worst kind of object to leave in
a bucket: nothing can show it, and nothing can find it to delete it either.
"""

import pytest

from services import deletion_service as D


class _Query:
    def __init__(self, table):
        self.t = table
        self.rows = list(table.rows)
        self._deleting = False

    def select(self, *_a, **_k):
        return self

    def delete(self):
        self._deleting = True
        return self

    def eq(self, col, val):
        self.rows = [r for r in self.rows if str(r.get(col)) == str(val)]
        return self

    def execute(self):
        if self._deleting:
            self.t.rows = [r for r in self.t.rows if r not in self.rows]
        return type("Res", (), {"data": self.rows})()


class _Table:
    def __init__(self, rows):
        self.rows = rows


class _Storage:
    def __init__(self, tree=None):
        self.removed: list[str] = []
        self.tree = tree or {}

    def from_(self, _bucket):
        return self

    def remove(self, keys):
        self.removed.extend(keys)

    def list(self, prefix):
        return self.tree.get(prefix, [])


class FakeSupabase:
    def __init__(self, exports=None, tree=None):
        self.t = _Table(list(exports or []))
        self.storage = _Storage(tree)

    def table(self, _name):
        return _Query(self.t)


def _export(**over):
    base = {
        "id": "exp-1",
        "event_id": "ev-1",
        "storage_path": "exports/ev-1/exp-1/master-list_Istambul_20260812.xlsx",
    }
    base.update(over)
    return base


class TestCollectingThePathsBeforeTheyAreLost:
    """Read while the rows still exist — afterwards there is nothing to read."""

    def test_the_paths_of_an_event_are_returned(self):
        sb = FakeSupabase([_export()])
        assert D._export_storage_paths(sb, "ev-1") == [
            "exports/ev-1/exp-1/master-list_Istambul_20260812.xlsx"
        ]

    def test_another_event_s_exports_are_not_touched(self):
        sb = FakeSupabase([_export(event_id="ev-2")])
        assert D._export_storage_paths(sb, "ev-1") == []

    def test_a_row_without_a_path_is_skipped(self):
        sb = FakeSupabase([_export(storage_path=None)])
        assert D._export_storage_paths(sb, "ev-1") == []

    def test_an_event_with_no_exports_yields_nothing(self):
        assert D._export_storage_paths(FakeSupabase([]), "ev-1") == []


class TestSweepingTheRedactedCopiesToo:
    """A download by anybody below admin/pm writes a second, role-redacted copy
    that no row has ever pointed at. It holds the same people."""

    def _tree(self):
        return {
            "exports/ev-1": [{"name": "exp-1"}],
            "exports/ev-1/exp-1": [
                {"name": "master-list.xlsx", "id": "o1"},
                {"name": "redacted-viewer-abc"},
            ],
            "exports/ev-1/exp-1/redacted-viewer-abc": [
                {"name": "master-list.xlsx", "id": "o2"},
            ],
        }

    def test_the_registered_file_is_found(self):
        keys = D._storage_keys_under(FakeSupabase(tree=self._tree()), "exports/ev-1")
        assert "exports/ev-1/exp-1/master-list.xlsx" in keys

    def test_the_redacted_copy_is_found_too(self):
        keys = D._storage_keys_under(FakeSupabase(tree=self._tree()), "exports/ev-1")
        assert "exports/ev-1/exp-1/redacted-viewer-abc/master-list.xlsx" in keys

    def test_folders_are_not_mistaken_for_files(self):
        # A folder entry has no id; deleting the name would remove nothing and
        # hide the fact that the real objects survived.
        keys = D._storage_keys_under(FakeSupabase(tree=self._tree()), "exports/ev-1")
        assert "exports/ev-1/exp-1/redacted-viewer-abc" not in keys

    def test_the_walk_is_bounded(self):
        # A surprising layout must not turn a delete into a crawl.
        deep = {f"exports/ev-1{'/x' * i}": [{"name": "x"}] for i in range(10)}
        keys = D._storage_keys_under(FakeSupabase(tree=deep), "exports/ev-1")
        assert isinstance(keys, list)

    def test_a_storage_failure_is_not_an_outage(self):
        class Broken(FakeSupabase):
            def __init__(self):
                super().__init__()
                self.storage.list = self._boom

            def _boom(self, _prefix):
                raise RuntimeError("storage down")

        assert D._storage_keys_under(Broken(), "exports/ev-1") == []


class TestRemoval:

    def test_both_the_rows_paths_and_the_swept_ones_go(self):
        tree = {
            "exports/ev-1": [{"name": "exp-1"}],
            "exports/ev-1/exp-1": [{"name": "redacted-viewer-a"}],
            "exports/ev-1/exp-1/redacted-viewer-a": [{"name": "f.xlsx", "id": "o1"}],
        }
        sb = FakeSupabase(tree=tree)
        D._remove_export_storage(sb, ["exports/ev-1/exp-1/f.xlsx"], "ev-1")
        assert "exports/ev-1/exp-1/f.xlsx" in sb.storage.removed
        assert "exports/ev-1/exp-1/redacted-viewer-a/f.xlsx" in sb.storage.removed

    def test_a_key_is_never_deleted_twice(self):
        sb = FakeSupabase(tree={"exports/ev-1": []})
        D._remove_export_storage(sb, ["a/b.xlsx", "a/b.xlsx"], "ev-1")
        assert sb.storage.removed == ["a/b.xlsx"]

    def test_nothing_to_remove_costs_no_call(self):
        sb = FakeSupabase(tree={"exports/ev-1": []})
        D._remove_export_storage(sb, [], "ev-1")
        assert sb.storage.removed == []
