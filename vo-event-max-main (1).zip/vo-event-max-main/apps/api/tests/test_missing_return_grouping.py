"""
Tests for grouping "no return flight" when it covers a whole cohort (§18/16a).

A handful of people with no return flight is worth asking about individually.
Forty is very rarely forty separate mistakes — it is a group extending their
stay at their own expense, or a delegation booked one-way on purpose. Flagging
each of them as a gap misreads an expected pattern as a problem.
"""

import pytest

from services import travel_checks
from services.exception_service import _is_systemic


def _flight(pid, departure, status="confirmed"):
    return {"participant_id": pid, "departure_time": departure, "status": status}


class TestAHandfulStaysIndividual:

    def test_three_out_of_forty_stay_three_separate_cards(self):
        # 40 participants, all departing on or after the event ends — a real
        # return flight — except 3 who only have an early departure recorded.
        flights = [_flight(f"p{i}", "2026-09-07T10:00:00") for i in range(37)]
        flights += [_flight(f"p{i}", "2026-09-01T10:00:00") for i in range(37, 40)]
        gaps = travel_checks.missing_return(flights, event_end=__import__("datetime").date(2026, 9, 6))
        assert len(gaps) == 3
        assert not _is_systemic(len(gaps), 40)


class TestAWholeCohortIsOneCard:

    def test_forty_out_of_forty_is_systemic(self):
        import datetime
        flights = [_flight(f"p{i}", "2026-09-01T10:00:00") for i in range(40)]
        gaps = travel_checks.missing_return(flights, event_end=datetime.date(2026, 9, 6))
        assert len(gaps) == 40
        assert _is_systemic(len(gaps), 40)

    def test_the_message_names_the_expected_reason_not_a_data_problem(self):
        # Unlike the transfer-mapping case, this one must NOT tell the
        # organiser to check their column mapping — that is the wrong fix for
        # a group of people who are simply staying longer.
        message = travel_checks.describe_missing_return_systemic(38, 40)
        assert "38" in message and "40" in message
        assert "mapping" not in message.lower()
        assert "prolong" in message.lower() or "aller simple" in message.lower()

    def test_a_small_cohort_is_never_called_systemic(self):
        import datetime
        flights = [_flight(f"p{i}", "2026-09-01T10:00:00") for i in range(8)]
        gaps = travel_checks.missing_return(flights, event_end=datetime.date(2026, 9, 6))
        assert len(gaps) == 8
        assert not _is_systemic(len(gaps), 8)
