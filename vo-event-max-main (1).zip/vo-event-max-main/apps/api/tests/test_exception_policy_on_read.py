"""
Tests for the field policy binding when the page is READ, not only when the
consolidation runs.

The bug these pin is not a wrong rule, it is a rule that arrives too late.
``dietary_requirements`` stopped being required on 2026-08-21 and the fix was
deployed. On 2026-08-25 the live event still showed sixty-nine "Régime
alimentaire" cards, because exceptions are written by a consolidation run and
the last one was from 2026-08-20. Nothing rewrites the table, so the change
would have taken effect only for whoever happened to re-consolidate — while the
person who had been told it was fixed opened the page and counted them.

So the policy is applied again on the way out. Three properties matter:

  * a card about a field the event no longer requires is not shown;
  * a card that ALSO names a field still required survives, minus the part
    that no longer applies;
  * nothing that is not a missing-field card is touched, because a conflict
    between two files is our records disagreeing, not a question we chose to
    ask.
"""

from datetime import datetime, timedelta, timezone

import pytest

from services import exception_service
from services.exception_service import apply_policy as _apply_policy
from services import field_policy


def _policy(**over):
    """A resolved policy: real defaults, with any overrides applied."""
    return field_policy.resolve(over or None)


def _card(*fields, name="Filip Maciąg", **over):
    base = {
        "id": "e1",
        "event_id": "ev1",
        "exception_type": "MISSING_REQUIRED_FIELD",
        "severity": "info",
        "message": (
            f"Fiche de « {name} » incomplète — champ(s) manquant(s) : "
            + ", ".join(fields)
            + "."
        ),
        "participant_id": "p1",
        "context_data": {
            "category": "missing_field",
            "missing_fields": list(fields),
            "participant_name": name,
        },
        "resolved": False,
    }
    base.update(over)
    return base


class TestACardTheEventNoLongerAsksFor:
    def test_a_diet_only_card_is_dropped(self):
        """The exact live case: 69 of these, four days after the rule changed."""
        assert _apply_policy(_card("dietary_requirements"), _policy()) is None

    def test_turning_the_field_back_on_brings_it_straight_back(self):
        """Hidden, never deleted. An event with a plated dinner really does
        need everyone's answer, and switching it on must restore the cards
        rather than require a fresh consolidation to rebuild them."""
        got = _apply_policy(
            _card("dietary_requirements"), _policy(dietary_requirements="required")
        )
        assert got is not None
        assert got["context_data"]["missing_fields"] == ["dietary_requirements"]

    def test_a_card_naming_only_required_fields_is_untouched(self):
        card = _card("email", "nationality")
        got = _apply_policy(card, _policy())
        assert got == card


class TestACardThatNamesBoth:
    """The half-and-half case. Dropping the whole card would take a real gap
    with it; keeping it whole would show a field the event does not ask for."""

    def test_the_unrequired_field_is_removed_and_the_card_stays(self):
        got = _apply_policy(_card("nationality", "dietary_requirements"), _policy())
        assert got is not None
        assert got["context_data"]["missing_fields"] == ["nationality"]

    def test_the_message_is_rewritten_to_match_its_own_data(self):
        """A card reading "régime alimentaire" while its data says otherwise is
        worse than either version alone — the UI sorts by the data and the
        human reads the sentence."""
        got = _apply_policy(_card("nationality", "dietary_requirements"), _policy())
        assert "régime" not in got["message"]
        assert "nationalité" in got["message"]

    def test_the_original_row_is_not_mutated(self):
        """It is a database row that other code may still be holding."""
        card = _card("nationality", "dietary_requirements")
        _apply_policy(card, _policy())
        assert card["context_data"]["missing_fields"] == [
            "nationality", "dietary_requirements"
        ]


class TestEverythingElsePassesThrough:
    def test_a_conflict_is_never_filtered(self):
        """Two files disagreeing about one person is not a question we asked."""
        card = {
            "id": "e2", "event_id": "ev1", "exception_type": "DATA_CONFLICT",
            "severity": "warning", "message": "Deux valeurs pour « email ».",
            "participant_id": "p1", "resolved": False,
            "context_data": {"category": "conflict", "field": "email"},
        }
        off = {k: "not_used" for k in field_policy.FIELD_KEYS}
        assert _apply_policy(card, field_policy.resolve(off)) == card

    def test_a_card_with_no_context_survives(self):
        card = {
            "id": "e3", "event_id": "ev1", "exception_type": "MISSING_REQUIRED_FIELD",
            "severity": "info", "message": "…", "resolved": False, "context_data": None,
        }
        assert _apply_policy(card, _policy()) == card

    def test_a_missing_field_card_with_an_empty_list_survives(self):
        """Malformed rather than filtered: hiding a card we cannot read would
        make a data problem invisible instead of visible."""
        card = _card()
        card["context_data"]["missing_fields"] = []
        assert _apply_policy(card, _policy()) == card

    def test_a_context_that_is_not_a_dict_does_not_crash(self):
        card = _card("dietary_requirements", context_data="oops")
        assert _apply_policy(card, _policy()) == card


# ===========================================================================
# The badge and the page, counting the same thing
# ===========================================================================

class TestTheCountMatchesTheList:
    """The defect this endpoint exists for.

    The badge used to count rows straight out of Supabase from the browser, so
    no server-side rule could reach it: the Exceptions page listed 14 and the
    navigation beside it said 77. A navigation that contradicts the page it
    links to is worse than a wrong number — the reader cannot tell which one
    to believe, so they believe neither.
    """

    def _rows(self):
        old = (datetime.now(timezone.utc) - timedelta(days=4)).isoformat()
        fresh = datetime.now(timezone.utc).isoformat()
        return (
            [_card("dietary_requirements", created_at=old) for _ in range(69)]
            + [_card("nationality", created_at=old) for _ in range(6)]
            + [_card("phone", created_at=fresh)]
        )

    def test_only_what_the_page_shows_is_counted(self):
        shown = exception_service.visible(self._rows(), _policy())
        assert len(shown) == 7          # 6 nationalité + 1 téléphone
        assert len(self._rows()) == 76  # what a raw table count would report

    def test_the_overdue_subset_is_counted_the_same_way(self):
        """The banner reading "77 alertes ouvertes depuis plus de 24 h" was the
        same table count wearing a different hat."""
        cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
        shown = exception_service.visible(self._rows(), _policy())
        overdue = sum(
            1 for r in shown
            if datetime.fromisoformat(str(r["created_at"])) < cutoff
        )
        assert overdue == 6             # the fresh phone card is not late

    def test_turning_the_field_on_restores_the_full_count(self):
        shown = exception_service.visible(
            self._rows(), _policy(dietary_requirements="required")
        )
        assert len(shown) == 76


# ===========================================================================
# A card that names a field the fiche has since answered
# ===========================================================================

class TestTheFicheIsCheckedAgain:
    """The second reason a named field drops out: somebody filled it in.

    Cards are written by a consolidation run; the fiches move on without one.
    On the live event that showed as six "nationalité" cards sitting beside a
    priorities line reading 5 — the counters are computed live and the cards
    were not, so the page contradicted itself.
    """

    def _answered(self, **by_person):
        return {pid: set(fields) for pid, fields in by_person.items()}

    def test_a_field_since_filled_in_stops_being_named(self):
        card = _card("nationality")
        got = _apply_policy(card, _policy(), self._answered(p1=["nationality"]))
        assert got is None

    def test_a_field_still_empty_is_still_named(self):
        card = _card("nationality")
        got = _apply_policy(card, _policy(), self._answered(p1=["email"]))
        assert got is not None
        assert got["context_data"]["missing_fields"] == ["nationality"]

    def test_only_the_answered_half_of_a_card_drops(self):
        card = _card("phone", "nationality")
        got = _apply_policy(card, _policy(), self._answered(p1=["phone"]))
        assert got["context_data"]["missing_fields"] == ["nationality"]
        assert "téléphone" not in got["message"]

    def test_another_persons_answer_does_not_clear_this_card(self):
        card = _card("nationality")
        got = _apply_policy(card, _policy(), self._answered(p2=["nationality"]))
        assert got is not None

    def test_emptying_the_field_again_brings_the_card_back(self):
        """Hidden, never deleted — the same contract the policy filter has."""
        card = _card("nationality")
        assert _apply_policy(card, _policy(), self._answered(p1=["nationality"])) is None
        assert _apply_policy(card, _policy(), self._answered(p1=[])) is not None

    def test_no_fiche_data_leaves_every_card_standing(self):
        """The read that builds this can fail; the page must then behave
        exactly as it did before the check existed."""
        card = _card("nationality")
        assert _apply_policy(card, _policy(), {}) is not None
        assert _apply_policy(card, _policy(), None) is not None

    def test_a_conflict_card_is_untouched_by_it(self):
        card = {
            "id": "e2", "event_id": "ev1", "exception_type": "DATA_CONFLICT",
            "severity": "warning", "message": "Deux valeurs.", "participant_id": "p1",
            "resolved": False, "context_data": {"category": "conflict", "field": "email"},
        }
        assert _apply_policy(card, _policy(), self._answered(p1=["email"])) == card


class TestAnsweredFieldsIsBuiltFromTheFiches:
    def test_blank_and_whitespace_do_not_count_as_answered(self):
        got = exception_service.answered_fields([
            {"id": "p1", "nationality": "  ", "phone": None, "email": "a@x.com"},
        ])
        assert got["p1"] == {"email"}

    def test_a_row_with_no_id_is_skipped_rather_than_crashing(self):
        assert exception_service.answered_fields([{"nationality": "BE"}]) == {}


class TestOneColumnListForEveryReader:
    """The badge, the page and the dashboard must ask the same question.

    They did not: the count endpoint's select omitted ``participant_id``, so
    every card it read belonged to nobody, no answered field ever cleared one,
    and the navigation showed 13 beside a page listing 12. Three readers, three
    hand-written column lists, one of them wrong.
    """

    class _FakeDB:
        def __init__(self, rows):
            self.rows = rows
            self.asked = None

        def table(self, _name):
            return self

        def select(self, columns):
            self.asked = columns
            return self

        def eq(self, *_a):
            return self

        def range(self, *_a):
            return self

        def execute(self):
            return type("R", (), {"data": self.rows})()

    def test_the_fetch_asks_for_the_id_and_every_tracked_field(self):
        db = self._FakeDB([])
        exception_service.fetch_answered(db, "ev1")
        for column in ("id",) + exception_service._MISSING_PROFILE_FIELDS:
            assert column in db.asked, f"{column} manque dans le select"

    def test_it_maps_people_to_the_fields_they_have_answered(self):
        db = self._FakeDB([
            {"id": "p1", "nationality": "BE", "phone": None, "email": "a@x.com",
             "first_name": "Ada", "dietary_requirements": ""},
        ])
        got = exception_service.fetch_answered(db, "ev1")
        assert got["p1"] == {"nationality", "email", "first_name"}

    def test_a_database_that_refuses_leaves_every_card_standing(self):
        class Broken:
            def table(self, _n):
                raise RuntimeError("nope")
        assert exception_service.fetch_answered(Broken(), "ev1") == {}


# ===========================================================================
# Aggregate cards, re-counted
# ===========================================================================

def _aggregate(flag, ids, count=None, msg=None):
    n = count if count is not None else len(ids)
    return {
        "id": "agg", "event_id": "ev1", "exception_type": "MISSING_REQUIRED_FIELD",
        "severity": "warning", "participant_id": None, "resolved": False,
        "message": msg or f"{n} participants sur {n} ont un vol sans aucun transfert.",
        "context_data": {
            "aggregate": True, "systemic_anomaly": True, "coverage_flag": flag,
            "participant_ids": list(ids), "count": n, "category": "flight_without_transfer",
        },
    }


class TestAnAggregateCardRecounts:
    """The live case, exactly.

    "65 participants sur 65 ont un vol sans aucun transfert" sat at the top of
    the page while all 65 had been given one — the card states a count from the
    run that wrote it, the KPI beside it is computed live, and the loudest of
    the two numbers was the false one.
    """

    def test_a_card_nobody_is_missing_any_more_disappears(self):
        answered = {p: {"has_transfer"} for p in ("a", "b", "c")}
        assert _apply_policy(_aggregate("has_transfer", "abc"), _policy(), answered) is None

    def test_a_card_still_true_for_everyone_is_untouched(self):
        card = _aggregate("has_transfer", "abc")
        answered = {p: set() for p in ("a", "b", "c")}
        assert _apply_policy(card, _policy(), answered) == card

    def test_a_partly_fixed_card_reports_the_number_that_is_left(self):
        card = _aggregate("has_transfer", "abc")
        answered = {"a": {"has_transfer"}, "b": set(), "c": set()}
        got = _apply_policy(card, _policy(), answered)
        assert got["context_data"]["count"] == 2
        assert got["context_data"]["participant_ids"] == ["b", "c"]
        assert got["message"].startswith("2 participants")

    def test_the_other_numbers_in_the_sentence_are_left_alone(self):
        """"sur 65" counts something else — the people who HAVE a flight."""
        card = _aggregate("has_transfer", "abc",
                          msg="3 participants sur 65 ont un vol sans aucun transfert.")
        answered = {"a": {"has_transfer"}, "b": set(), "c": set()}
        got = _apply_policy(card, _policy(), answered)
        assert got["message"] == "2 participants sur 65 ont un vol sans aucun transfert."

    def test_a_different_flag_does_not_clear_it(self):
        card = _aggregate("has_transfer", "abc")
        answered = {p: {"has_flight"} for p in ("a", "b", "c")}
        assert _apply_policy(card, _policy(), answered) == card

    def test_with_no_fiches_to_check_the_card_stands(self):
        card = _aggregate("has_transfer", "abc")
        assert _apply_policy(card, _policy(), {}) == card
        assert _apply_policy(card, _policy(), None) == card

    def test_a_card_with_no_ids_is_left_as_written(self):
        """Malformed rather than filtered: hiding a card we cannot read would
        make a data problem invisible instead of visible."""
        card = _aggregate("has_transfer", [])
        assert _apply_policy(card, _policy(), {"a": {"has_transfer"}}) == card


class TestCoverageFlagsReachTheMap:
    def test_a_true_flag_counts_as_answered(self):
        got = exception_service.answered_fields([
            {"id": "p1", "has_flight": True, "has_transfer": False, "email": "a@x.com"},
        ])
        assert "has_flight" in got["p1"]
        assert "has_transfer" not in got["p1"]

    def test_the_fetch_asks_for_them(self):
        class Fake:
            asked = None
            def table(self, _n): return self
            def select(self, c):
                Fake.asked = c
                return self
            def eq(self, *_a): return self
            def range(self, *_a): return self
            def execute(self): return type("R", (), {"data": []})()
        exception_service.fetch_answered(Fake(), "ev1")
        for flag in exception_service.COVERAGE_FLAGS:
            assert flag in Fake.asked


class TestPeopleWhoAreNoLongerThere:
    """A merged or deleted fiche must not read as an unsolved gap.

    The live card listed 65 ids; one of them had been merged away as a
    duplicate since the run. Absent from the fiches, it counted as "still
    missing a transfer" and held the card open at "1 participants sur 65" when
    every real person had one.
    """

    def test_an_id_that_no_longer_exists_is_not_counted(self):
        card = _aggregate("has_transfer", ["a", "b", "disparu"])
        answered = {"a": {"has_transfer"}, "b": {"has_transfer"}}
        assert _apply_policy(card, _policy(), answered) is None

    def test_a_real_gap_beside_a_ghost_still_reports(self):
        card = _aggregate("has_transfer", ["a", "b", "disparu"])
        answered = {"a": {"has_transfer"}, "b": set()}
        got = _apply_policy(card, _policy(), answered)
        assert got["context_data"]["count"] == 1
        assert got["context_data"]["participant_ids"] == ["b"]


# ===========================================================================
# A one-way booking is not a gap
# ===========================================================================

def _return_card(name="Filip Maciąg", **over):
    base = {
        "id": "r1", "event_id": "ev1", "exception_type": "MISSING_REQUIRED_FIELD",
        "severity": "warning", "participant_id": "p1", "resolved": False,
        "message": f"« {name} » n'a pas de vol retour : le dernier segment connu "
                   "part le 2026-09-09, avant la fin de l'événement.",
        "context_data": {
            "category": "missing_return_flight", "participant_name": name,
            "segments": 2, "last_departure": "2026-09-09",
        },
    }
    base.update(over)
    return base


class TestAMissingReturnIsNotAnAnomalyByDefault:
    """Five cards on the live event, and the two loudest were false.

    Filip Maciąg was reported as having no way home while holding a 09/09
    Athens→Warsaw booking; Inès Bakkali's single segment WAS her return. Both
    were written before the event had dates and nothing re-checked them. The
    rest were real one-way bookings — which is a normal thing for a person to
    have, not a hole in our file.
    """

    def test_it_is_silent_unless_the_event_asks_for_it(self):
        assert _apply_policy(_return_card(), _policy()) is None

    def test_a_chartered_group_can_still_turn_it_on(self):
        """An event that really does fly everybody home together wants the
        question asked — so this is a policy, not a removal."""
        got = _apply_policy(_return_card(), _policy(return_flight="required"))
        assert got is not None
        assert got["context_data"]["category"] == "missing_return_flight"

    def test_the_aggregate_version_goes_quiet_too(self):
        card = _return_card(participant_id=None, context_data={
            "category": "missing_return_flight", "aggregate": True, "count": 40,
            "participant_ids": ["p1", "p2"], "total_participants": 65,
        })
        assert _apply_policy(card, _policy()) is None

    def test_turning_it_off_does_not_silence_the_other_flight_cards(self):
        """`flight` stays required: "17 participants sans vol" is a real gap
        and must survive this change."""
        card = {
            "id": "f1", "event_id": "ev1", "exception_type": "PARTICIPANT_NO_FLIGHT",
            "severity": "info", "participant_id": None, "resolved": False,
            "message": "17 participant(s) sans vol enregistré.",
            "context_data": {"aggregate": True, "coverage_flag": "has_flight",
                             "participant_ids": ["p1"], "count": 1},
        }
        assert _apply_policy(card, _policy(), {"p1": set()}) == card


class TestTheCatalogueGainedIt:
    def test_return_flight_is_known_and_optional(self):
        assert "return_flight" in field_policy.FIELD_KEYS
        assert not field_policy.is_required(field_policy.resolve(None), "return_flight")

    def test_it_has_a_label_the_settings_screen_can_show(self):
        assert field_policy.label("return_flight") == "Vol retour"

    def test_flight_itself_is_untouched(self):
        assert field_policy.is_required(field_policy.resolve(None), "flight")


# ===========================================================================
# Staying past the end of the event
# ===========================================================================

class TestOutsideTheProgrammeDates:
    """Not a question asked once per person — a fact about the invoice.

    Measured on the live event: 36 of the 64 people with a flight travel
    outside the programme dates, 141 nights in total. At 56% that sits under
    the systemic ratio, so the engine would have written thirty-six separate
    cards each ending in a question mark.
    """

    def _flights(self, n):
        out = []
        for i in range(n):
            out.append({"participant_id": f"p{i}", "departure_time": "2026-09-01T08:00:00Z"})
            out.append({"participant_id": f"p{i}", "departure_time": "2026-09-09T18:00:00Z"})
        return out

    def test_the_check_finds_them(self):
        from datetime import date
        from services import travel_checks
        got = travel_checks.staying_at_own_expense(
            self._flights(3), date(2026, 9, 1), date(2026, 9, 4)
        )
        assert len(got) == 3
        assert all(g["stays_late_days"] == 5 for g in got)
        assert all(g["extra_nights"] == 5 for g in got)

    def test_somebody_exactly_on_the_dates_is_not_flagged(self):
        from datetime import date
        from services import travel_checks
        flights = [
            {"participant_id": "p", "departure_time": "2026-09-01T08:00:00Z"},
            {"participant_id": "p", "departure_time": "2026-09-04T20:00:00Z"},
        ]
        assert travel_checks.staying_at_own_expense(
            flights, date(2026, 9, 1), date(2026, 9, 4)
        ) == []

    def test_arriving_early_counts_as_much_as_leaving_late(self):
        from datetime import date
        from services import travel_checks
        flights = [
            {"participant_id": "p", "departure_time": "2026-08-26T08:00:00Z"},
            {"participant_id": "p", "departure_time": "2026-09-08T20:00:00Z"},
        ]
        got = travel_checks.staying_at_own_expense(
            flights, date(2026, 9, 1), date(2026, 9, 4)
        )[0]
        assert got["arrives_early_days"] == 6
        assert got["stays_late_days"] == 4
        assert got["extra_nights"] == 10

    def test_a_cancelled_late_return_is_not_a_stay(self):
        from datetime import date
        from services import travel_checks
        flights = [
            {"participant_id": "p", "departure_time": "2026-09-01T08:00:00Z"},
            {"participant_id": "p", "departure_time": "2026-09-09T18:00:00Z", "status": "cancelled"},
        ]
        assert travel_checks.staying_at_own_expense(
            flights, date(2026, 9, 1), date(2026, 9, 4)
        ) == []

    def test_without_programme_dates_nothing_is_announced(self):
        """An event that never set its dates must not suddenly declare that
        everybody is on a private holiday."""
        from services import travel_checks
        assert travel_checks.staying_at_own_expense(self._flights(3), None, None) == []


class TestItIsOneLineWhenItIsACrowd:
    def test_a_handful_is_still_named_one_by_one(self):
        assert 3 <= exception_service._STAYING_INDIVIDUAL_MAX

    def test_thirty_six_of_sixty_four_groups(self):
        """The live proportion. It is under the systemic ratio, which is why
        the dedicated ceiling exists."""
        assert not exception_service._is_systemic(36, 64)
        assert 36 > exception_service._STAYING_INDIVIDUAL_MAX


# ===========================================================================
# "Outside the event window" is not a date problem
# ===========================================================================

def _window_card(*issues, **over):
    base = {
        "id": "d1", "event_id": "ev1", "exception_type": "DATE_INCOHERENCE",
        "severity": "warning", "participant_id": None, "resolved": False,
        "message": "Source record e042b312 has date issues: " + "; ".join(issues) + ".",
        "context_data": {"issues": list(issues)},
    }
    base.update(over)
    return base


_OUTSIDE = "departure_date (2026-09-08) falls outside event window 2026-09-01–2026-09-04"
_REVERSED = "departure_date (2026-09-08) is after return_date (2026-09-02)"


class TestOutOfWindowCardsGoQuiet:
    """One per source row, in English, against a UUID, saying that a departure
    after the event is a date problem. It is not: it is somebody on their own
    nights, which `staying_at_own_expense` reports by name and by night."""

    def test_a_card_that_only_says_outside_the_window_disappears(self):
        assert _apply_policy(_window_card(_OUTSIDE), _policy()) is None

    def test_several_out_of_window_dates_still_disappear(self):
        card = _window_card(_OUTSIDE, _OUTSIDE.replace("departure", "return"))
        assert _apply_policy(card, _policy()) is None

    def test_a_real_contradiction_survives(self):
        """Leaving before arriving is a genuine problem and nothing else
        reports it."""
        card = _window_card(_REVERSED)
        assert _apply_policy(card, _policy()) == card

    def test_a_card_carrying_both_survives(self):
        card = _window_card(_REVERSED, _OUTSIDE)
        assert _apply_policy(card, _policy()) == card

    def test_another_exception_type_is_untouched(self):
        card = _window_card(_OUTSIDE, exception_type="DATA_CONFLICT")
        assert _apply_policy(card, _policy()) == card

    def test_a_malformed_card_is_left_visible(self):
        """Hiding one we cannot read would make a data problem invisible."""
        assert _apply_policy(_window_card(), _policy()) is not None


class TestEveryReaderAsksForTheSameColumns:
    """Got wrong twice, the same way both times.

    First the count endpoint's select omitted `participant_id`, so every card
    it read belonged to nobody and no answered field cleared one: 13 in the
    navigation beside a page listing 12. Then it omitted `exception_type`, so
    the out-of-window filter never matched: 49 beside a page listing 9. Three
    readers, three hand-typed column lists.
    """

    def test_the_shared_list_carries_what_every_rule_reads(self):
        for column in ("exception_type", "participant_id", "context_data",
                       "severity", "created_at", "resolved"):
            assert column in exception_service.READ_COLUMNS, f"{column} manque"

    def test_the_count_endpoint_uses_it(self):
        import inspect
        from routers import consolidation
        src = inspect.getsource(consolidation.count_event_exceptions)
        assert "exception_service.READ_COLUMNS" in src

    def test_the_dashboard_alert_block_uses_it(self):
        import inspect
        from services import dashboard_service
        src = inspect.getsource(dashboard_service._alerts)
        assert "exception_service.READ_COLUMNS" in src

    def test_a_card_read_without_its_type_is_not_silently_kept(self):
        """What the bug looked like from the inside: the filter simply never
        matched, and the card sailed through."""
        card = _window_card(_OUTSIDE)
        del card["exception_type"]
        assert _apply_policy(card, _policy()) is not None


class TestTheSentenceAgreesWithItsOwnNumber:
    """These messages carry a count that the read-time re-count can change
    after the fact — a card written for thirty-six can end up saying one — so
    the agreement has to follow the number rather than be baked in. The live
    card read "1 participants sur 65 ont un vol sans aucun transfert"."""

    def test_one_person_is_singular(self):
        from services import travel_checks
        for text in (
            travel_checks.describe_staying_systemic(1, 65, 5),
            travel_checks.describe_missing_return_systemic(1, 65),
            travel_checks.describe_flight_no_transfer_systemic(1, 65),
        ):
            assert text.startswith("1 participant sur"), text[:40]
            assert "1 participants" not in text

    def test_several_stay_plural(self):
        from services import travel_checks
        for text in (
            travel_checks.describe_staying_systemic(36, 65, 141),
            travel_checks.describe_missing_return_systemic(36, 65),
            travel_checks.describe_flight_no_transfer_systemic(36, 65),
        ):
            assert text.startswith("36 participants sur"), text[:40]

    def test_the_verb_follows_too(self):
        from services import travel_checks
        assert " a des vols" in travel_checks.describe_staying_systemic(1, 65, 5)
        assert " ont des vols" in travel_checks.describe_staying_systemic(2, 65, 5)
        assert "n'a pas de vol" in travel_checks.describe_missing_return_systemic(1, 65)
        assert "n'ont pas de vol" in travel_checks.describe_missing_return_systemic(2, 65)


class TestTheRewrittenSentenceAgreesToo:
    """The re-count changes the number in a sentence somebody else wrote.

    A card written for thirty-six people, re-counted down to one, read
    "1 participants sur 65 ont un vol sans aucun transfert" on the live event.
    """

    def _card(self, n, msg):
        return _aggregate("has_transfer", [f"p{i}" for i in range(n)], count=n, msg=msg)

    def test_falling_to_one_makes_the_subject_and_verb_singular(self):
        card = self._card(3, "3 participants sur 65 ont un vol sans aucun transfert.")
        answered = {"p0": set(), "p1": {"has_transfer"}, "p2": {"has_transfer"}}
        got = _apply_policy(card, _policy(), answered)
        assert got["message"] == "1 participant sur 65 a un vol sans aucun transfert."

    def test_the_negative_form_too(self):
        card = self._card(3, "3 participants sur 65 n'ont pas de vol retour identifié.")
        answered = {"p0": set(), "p1": {"has_transfer"}, "p2": {"has_transfer"}}
        got = _apply_policy(card, _policy(), answered)
        assert got["message"] == "1 participant sur 65 n'a pas de vol retour identifié."

    def test_falling_to_several_stays_plural(self):
        card = self._card(3, "3 participants sur 65 ont un vol sans aucun transfert.")
        answered = {"p0": set(), "p1": set(), "p2": {"has_transfer"}}
        got = _apply_policy(card, _policy(), answered)
        assert got["message"].startswith("2 participants sur 65 ont ")

    def test_a_sentence_shaped_differently_is_left_alone(self):
        """Only the opening subject is ours; the rest belongs to whoever wrote
        the message."""
        card = self._card(3, "3 chambres sur 40 sont vides.")
        answered = {"p0": set(), "p1": {"has_transfer"}, "p2": {"has_transfer"}}
        got = _apply_policy(card, _policy(), answered)
        assert got["message"] == "1 chambres sur 40 sont vides."

    def test_only_the_first_number_moves(self):
        card = self._card(3, "3 participants sur 65 ont un vol. Seuil : 3.")
        answered = {"p0": set(), "p1": {"has_transfer"}, "p2": {"has_transfer"}}
        got = _apply_policy(card, _policy(), answered)
        assert got["message"].endswith("Seuil : 3.")
