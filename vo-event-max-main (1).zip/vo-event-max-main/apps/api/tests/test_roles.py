"""
Tests for the access ladder (§21).

Almost every assertion here is about something NOT being allowed, which is the
nature of an authorisation model: the interesting cases are the ones where a
plausible-looking grant has to be refused anyway.

Two properties carry the rest:

  * denial happens BEFORE membership is consulted, so a participant with a
    stray project_members row is still refused;
  * an unknown role resolves DOWN, not up. A typo in the database must not
    become an escalation.
"""

import pytest

from services import roles as R


class TestNormalising:

    @pytest.mark.parametrize("value", ["admin", "ADMIN", " Admin ", "pm"])
    def test_a_known_role_survives_its_formatting(self, value):
        assert R.normalise(value) in (R.ADMIN, R.PM)

    @pytest.mark.parametrize("value", ["superuser", "", None, 42, "Admin!"])
    def test_an_unknown_role_resolves_to_the_least_privileged(self, value):
        # A typo in the database must not become an outage, and it must
        # certainly not become an escalation.
        assert R.normalise(value) == R.VIEWER

    def test_the_fallback_is_not_privileged(self):
        assert not R.sees_every_project(R.normalise("nonsense"))
        assert not R.can_write(R.normalise("nonsense"))
        assert not R.can_manage_access(R.normalise("nonsense"))


class TestWhoSeesEverything:

    def test_the_administrator_does(self):
        assert R.sees_every_project(R.ADMIN)

    def test_the_project_manager_keeps_the_access_they_have_today(self):
        # Narrowing pm would lock out, silently and immediately, every project
        # manager relying on org-wide access. §21 asks for the architecture to
        # allow the levels, not for the team to be reorganised on a Tuesday.
        assert R.sees_every_project(R.PM)

    def test_a_project_user_does_not(self):
        assert not R.sees_every_project(R.PROJECT_USER)

    def test_a_freelancer_does_not(self):
        assert not R.sees_every_project(R.FREELANCER)


class TestWhoIsRefusedOutright:
    """Checked before membership: a stray project_members row must not open a
    door the role closed."""

    def test_a_participant_has_no_internal_access(self):
        # §21: their registration link and their mini event site, nothing else.
        assert not R.has_operational_access(R.PARTICIPANT)

    @pytest.mark.parametrize("role", [R.ADMIN, R.PM, R.PROJECT_USER, R.FREELANCER, R.VIEWER])
    def test_everybody_internal_does(self, role):
        assert R.has_operational_access(role)


class TestTheClientRole:
    """§21 says a client has no operational access. Taken literally that is a
    migration, not a code change: it removes the application from whatever
    client accounts already exist. So the default keeps them reading, and the
    strict reading is one environment variable away."""

    def test_by_default_a_client_still_reads(self):
        # Nobody is locked out by deploying the ladder.
        assert R.has_operational_access(R.CLIENT) is R.CLIENT_OPERATIONAL_ACCESS
        assert R.CLIENT_OPERATIONAL_ACCESS is True

    def test_a_client_never_writes(self):
        # This half of §21 is unconditional: read access is not edit access.
        assert not R.can_write(R.CLIENT)

    def test_a_client_never_administers_access(self):
        assert not R.can_manage_access(R.CLIENT)

    def test_the_strict_reading_is_one_variable_away(self, monkeypatch):
        monkeypatch.setenv("CLIENT_OPERATIONAL_ACCESS", "0")
        import importlib

        strict = importlib.reload(R)
        try:
            assert strict.CLIENT_OPERATIONAL_ACCESS is False
            assert not strict.has_operational_access(strict.CLIENT)
        finally:
            # Other tests in this file read the module-level frozensets.
            monkeypatch.delenv("CLIENT_OPERATIONAL_ACCESS", raising=False)
            importlib.reload(R)

    @pytest.mark.parametrize("value", ["0", "false", "no", "off", "FALSE"])
    def test_the_off_switch_accepts_the_obvious_spellings(self, monkeypatch, value):
        monkeypatch.setenv("CLIENT_OPERATIONAL_ACCESS", value)
        import importlib

        strict = importlib.reload(R)
        try:
            assert strict.CLIENT_OPERATIONAL_ACCESS is False
        finally:
            monkeypatch.delenv("CLIENT_OPERATIONAL_ACCESS", raising=False)
            importlib.reload(R)


class TestWriting:

    @pytest.mark.parametrize("role", [R.ADMIN, R.PM, R.PROJECT_USER, R.FREELANCER])
    def test_the_working_roles_may_write(self, role):
        assert R.can_write(role)

    def test_a_viewer_may_not(self):
        assert not R.can_write(R.VIEWER)

    @pytest.mark.parametrize("role", [R.CLIENT, R.PARTICIPANT])
    def test_a_role_with_no_access_certainly_may_not(self, role):
        assert not R.can_write(role)

    def test_writing_implies_operational_access_for_every_role(self):
        # A role that may change data but may not reach the app is a
        # contradiction the two sets must never encode.
        assert R.CAN_WRITE <= R.OPERATIONAL


class TestManagingAccess:

    @pytest.mark.parametrize("role", [R.ADMIN, R.PM])
    def test_the_org_wide_roles_may(self, role):
        # For them it is not an escalation: they already see every project, so
        # granting themselves access gains them nothing.
        assert R.can_manage_access(role)

    @pytest.mark.parametrize("role", [R.PROJECT_USER, R.FREELANCER, R.VIEWER, R.CLIENT])
    def test_anybody_scoped_by_membership_may_not(self, role):
        # They could otherwise grant themselves the projects they cannot see,
        # which turns every level in this ladder into a suggestion.
        assert not R.can_manage_access(role)

    def test_managing_access_implies_seeing_everything(self):
        assert R.CAN_SHARE <= R.ORG_WIDE


class TestFreelancerScope:

    def test_a_freelancer_on_a_whole_project_is_flagged(self):
        # Not an error — sometimes that is the arrangement — but it is almost
        # always somebody clicking through a dialog rather than deciding.
        assert R.is_over_scoped(R.FREELANCER, {"event_ids": []})
        assert R.is_over_scoped(R.FREELANCER, {"event_ids": None})

    def test_a_freelancer_scoped_to_events_is_not(self):
        assert not R.is_over_scoped(R.FREELANCER, {"event_ids": ["e1"]})

    def test_other_roles_are_never_flagged(self):
        assert not R.is_over_scoped(R.PROJECT_USER, {"event_ids": []})

    def test_a_missing_membership_is_not_flagged_as_over_scoped(self):
        assert not R.is_over_scoped(R.FREELANCER, None)


class TestTheLadderIsPresentable:

    def test_it_lists_every_level_in_the_order_the_feedback_names_them(self):
        assert [entry["role"] for entry in R.describe()] == [
            R.ADMIN, R.PM, R.PROJECT_USER, R.FREELANCER,
            R.VIEWER, R.CLIENT, R.PARTICIPANT,
        ]

    def test_every_level_has_a_label_and_an_explanation(self):
        for entry in R.describe():
            assert entry["label"] and entry["description"]

    def test_the_flags_agree_with_the_functions(self):
        for entry in R.describe():
            role = entry["role"]
            assert entry["operational"] is R.has_operational_access(role)
            assert entry["can_write"] is R.can_write(role)
            assert entry["sees_every_project"] is R.sees_every_project(role)
