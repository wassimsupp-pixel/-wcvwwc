"""
Tests for conversations that survive a page reload.

The assistant already took a history — the browser carried it, so closing the
tab threw away the thread of reasoning behind four questions. Storing it raises
three questions that are not about storage at all:

  * whose conversation is it? (the person's, not the team's)
  * what may a transcript contain? (prose, never the participant rows)
  * who decides what the assistant read as context? (the server, not the
    caller — a client that supplies the history can supply a fabricated one)
"""

import asyncio
import uuid
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

import routers.chatbot as C
from services import chat_history as H


EVENT = "11111111-1111-1111-1111-111111111111"
MINE = {"id": "user-1", "role": "pm"}
THEIRS = {"id": "user-2", "role": "pm"}


# ===========================================================================
# The pure part
# ===========================================================================

class TestTitles:

    def test_the_title_is_the_question_itself(self):
        # Not an AI summary: a list whose labels approximate what you asked is
        # a list you have to open every row of.
        assert H.title_for("Qui n'a pas de vol ?") == "Qui n'a pas de vol ?"

    def test_a_long_question_is_trimmed_with_an_ellipsis(self):
        title = H.title_for("x" * 200)
        assert len(title) <= H.MAX_TITLE
        assert title.endswith("…")

    def test_whitespace_is_collapsed(self):
        assert H.title_for("  Qui   n'a\npas de vol ?  ") == "Qui n'a pas de vol ?"

    def test_an_empty_question_still_gets_a_label(self):
        assert H.title_for("") == "Nouvelle conversation"


class TestContextWindow:

    def _messages(self, n):
        return [
            {"role": "user" if i % 2 == 0 else "assistant", "content": f"m{i}"}
            for i in range(n)
        ]

    def test_a_turn_is_shaped_the_way_the_assistant_filters_on(self):
        # ChatTurn carries `question` and nothing else. A role/content pair
        # would be dropped without a word — no error, no context, and a
        # follow-up quietly answered as though it were a fresh question.
        turns = H.as_turns([{"role": "user", "content": "x", "intent": "y"}])
        assert turns == [{"question": "x"}]

    def test_the_assistants_own_answers_are_not_context(self):
        # They are what it already concluded; feeding them back invites it to
        # build on its own output.
        assert H.as_turns([{"role": "assistant", "content": "x"}]) == []

    def test_an_empty_message_is_dropped(self):
        assert H.as_turns([{"role": "user", "content": "   "}]) == []

    def test_an_unknown_role_is_dropped(self):
        assert H.as_turns([{"role": "system", "content": "x"}]) == []

    def test_only_the_tail_is_given_to_the_assistant(self):
        # A follow-up resolves against what was just asked. Forty turns back
        # does not make it more accurate; it lets an old question change what a
        # new one means.
        assert len(H.recent(self._messages(40))) == H.CONTEXT_TURNS

    def test_the_tail_is_the_most_recent_and_stays_in_order(self):
        recent = H.recent(self._messages(40), turns=2)
        assert [m["question"] for m in recent] == ["m36", "m38"]

    def test_a_short_thread_is_given_whole(self):
        assert len(H.recent(self._messages(2))) == 1


class TestSummary:

    def test_it_counts_the_questions_not_the_messages(self):
        messages = [
            {"role": "user", "content": "a"}, {"role": "assistant", "content": "b"},
            {"role": "user", "content": "c"}, {"role": "assistant", "content": "d"},
        ]
        assert H.summarise({"id": "x", "title": "t"}, messages)["questions"] == 2

    def test_refusals_are_surfaced(self):
        # A thread full of them is somebody repeatedly asking something the
        # data cannot support — the useful signal in this list.
        messages = [
            {"role": "assistant", "content": "non", "answered": False},
            {"role": "assistant", "content": "oui", "answered": True},
        ]
        assert H.summarise({"id": "x", "title": "t"}, messages)["unanswered"] == 1

    def test_an_untitled_conversation_still_has_a_label(self):
        assert H.summarise({"id": "x", "title": None}, [])["title"] == "Nouvelle conversation"


# ===========================================================================
# The endpoints
# ===========================================================================

class _DB:
    """Enough PostgREST for the chat endpoints, with per-table absence."""

    def __init__(self, missing=(), **tables):
        self._missing = set(missing)
        self.tables = {name: list(rows) for name, rows in tables.items()}

    def table(self, name):
        return _Q(self, name)


class _Q:
    def __init__(self, db, name):
        self._db, self._name = db, name
        self._rows = list(db.tables.setdefault(name, []))
        self._filters: list[tuple[str, object]] = []
        self._patch = None
        self._delete = False

    def _check(self):
        if self._name in self._db._missing:
            raise RuntimeError(f'relation "{self._name}" does not exist')

    def select(self, *_a, **_k):
        self._check()
        return self

    def insert(self, rows):
        self._check()
        rows = rows if isinstance(rows, list) else [rows]
        stored = self._db.tables[self._name]
        for row in rows:
            # Real UUIDs: the response models parse them, and an id shaped
            # like "chat_conversations-1" would only ever fail here.
            row.setdefault("id", str(uuid.uuid4()))
            row.setdefault("created_at", "2027-03-01T10:00:00Z")
            row.setdefault("updated_at", "2027-03-01T10:00:00Z")
            stored.append(row)
        self._rows = rows
        return self

    def update(self, patch):
        self._check()
        self._patch = patch
        return self

    def delete(self):
        self._check()
        self._delete = True
        return self

    def eq(self, col, val):
        self._filters.append((col, val))
        self._rows = [r for r in self._rows if r.get(col) == val]
        return self

    def in_(self, col, vals):
        self._rows = [r for r in self._rows if r.get(col) in set(vals)]
        return self

    def order(self, *_a, **_k):
        return self

    def limit(self, n):
        self._rows = self._rows[:n]
        return self

    def execute(self):
        if self._delete:
            keep = [r for r in self._db.tables[self._name] if r not in self._rows]
            self._db.tables[self._name] = keep
            return SimpleNamespace(data=self._rows)
        if self._patch is not None:
            for row in self._rows:
                row.update(self._patch)
            return SimpleNamespace(data=self._rows)
        return SimpleNamespace(data=self._rows)


@pytest.fixture(autouse=True)
def _stub(monkeypatch):
    async def _ok(*_a, **_k):
        return True
    monkeypatch.setattr(C, "verify_event_access", _ok)

    def _answer(question, event_id, supabase, user_role="viewer", history=None):
        _answer.seen_history = list(history or [])
        return {
            "answer": f"réponse à « {question} »", "rows": [{"id": 1}],
            "references": [], "intent": "test", "answered": True,
        }
    _answer.seen_history = []
    monkeypatch.setattr(C.chatbot_service, "answer_question", _answer)
    return _answer


def _ask(db, question, user=MINE, conversation_id=None):
    from models.schemas import ChatQuestion
    body = ChatQuestion(question=question, conversation_id=conversation_id)
    return asyncio.run(C.ask(EVENT, body, current_user=user, supabase=db))


class TestAThreadSurvives:

    def test_a_first_question_opens_a_conversation(self):
        db = _DB(chat_conversations=[], chat_messages=[])
        answer = _ask(db, "Qui n'a pas de vol ?")
        assert answer.conversation_id
        assert len(db.tables["chat_conversations"]) == 1

    def test_the_exchange_is_stored_both_ways(self):
        db = _DB(chat_conversations=[], chat_messages=[])
        _ask(db, "Qui n'a pas de vol ?")
        roles = [m["role"] for m in db.tables["chat_messages"]]
        assert roles == ["user", "assistant"]

    def test_a_follow_up_stays_in_the_same_thread(self):
        db = _DB(chat_conversations=[], chat_messages=[])
        first = _ask(db, "Qui n'a pas de vol ?")
        second = _ask(db, "Et sans hôtel ?", conversation_id=first.conversation_id)
        assert second.conversation_id == first.conversation_id
        assert len(db.tables["chat_conversations"]) == 1
        assert len(db.tables["chat_messages"]) == 4

    def test_the_title_comes_from_the_first_question_only(self):
        db = _DB(chat_conversations=[], chat_messages=[])
        first = _ask(db, "Qui n'a pas de vol ?")
        _ask(db, "Et sans hôtel ?", conversation_id=first.conversation_id)
        assert db.tables["chat_conversations"][0]["title"] == "Qui n'a pas de vol ?"


class TestTheServerDecidesTheContext:

    def test_a_follow_up_reads_its_context_from_the_record(self, _stub):
        db = _DB(chat_conversations=[], chat_messages=[])
        first = _ask(db, "Qui n'a pas de vol ?")
        _ask(db, "Et sans hôtel ?", conversation_id=first.conversation_id)
        assert _stub.seen_history == [{"question": "Qui n'a pas de vol ?"}]

    def test_a_supplied_history_is_ignored_once_a_thread_exists(self, _stub):
        """A caller who can send the history can send a fabricated one."""
        from models.schemas import ChatQuestion

        db = _DB(chat_conversations=[], chat_messages=[])
        first = _ask(db, "Qui n'a pas de vol ?")
        body = ChatQuestion(
            question="Et sans hôtel ?",
            conversation_id=first.conversation_id,
            history=[{"question": "INVENTÉ"}],
        )
        asyncio.run(C.ask(EVENT, body, current_user=MINE, supabase=db))
        assert all(t["question"] != "INVENTÉ" for t in _stub.seen_history)

    def test_a_first_question_has_no_context(self, _stub):
        db = _DB(chat_conversations=[], chat_messages=[])
        _ask(db, "Qui n'a pas de vol ?")
        assert _stub.seen_history == []


class TestOwnership:

    def _thread_of(self, owner):
        db = _DB(chat_conversations=[], chat_messages=[])
        answer = _ask(db, "Qui n'a pas de vol ?", user=owner)
        return db, str(answer.conversation_id)

    def test_the_list_only_returns_my_own(self):
        db, _ = self._thread_of(MINE)
        _ask(db, "Autre chose ?", user=THEIRS)
        # limit passed explicitly: calling the endpoint function directly
        # bypasses FastAPI, so its Query() default arrives as the Query object.
        mine = asyncio.run(
            C.list_conversations(EVENT, limit=30, current_user=MINE, supabase=db)
        )
        assert len(mine) == 1
        assert mine[0].title == "Qui n'a pas de vol ?"

    def test_somebody_elses_thread_is_not_found_rather_than_forbidden(self):
        # Saying "forbidden" would confirm that a colleague asked something,
        # on this event, at this id.
        db, thread = self._thread_of(MINE)
        with pytest.raises(HTTPException) as err:
            asyncio.run(C.get_conversation(thread, current_user=THEIRS, supabase=db))
        assert err.value.status_code == 404

    def test_continuing_somebody_elses_thread_starts_a_new_one(self):
        db, thread = self._thread_of(MINE)
        answer = _ask(db, "Et sans hôtel ?", user=THEIRS, conversation_id=thread)
        assert str(answer.conversation_id) != thread

    def test_i_can_read_my_own_transcript(self):
        db, thread = self._thread_of(MINE)
        out = asyncio.run(C.get_conversation(thread, current_user=MINE, supabase=db))
        assert [m.role for m in out.messages] == ["user", "assistant"]

    def test_deleting_takes_the_messages_with_it(self):
        db, thread = self._thread_of(MINE)
        asyncio.run(C.delete_conversation(thread, current_user=MINE, supabase=db))
        assert db.tables["chat_conversations"] == []

    def test_i_cannot_delete_somebody_elses(self):
        db, thread = self._thread_of(MINE)
        with pytest.raises(HTTPException) as err:
            asyncio.run(C.delete_conversation(thread, current_user=THEIRS, supabase=db))
        assert err.value.status_code == 404
        assert len(db.tables["chat_conversations"]) == 1


class TestATranscriptIsNotACopyOfTheMasterList:

    def test_the_answers_rows_are_never_stored(self):
        # They are names and dietary requirements. A transcript holding them is
        # a second copy of the master list nobody is managing (§23).
        db = _DB(chat_conversations=[], chat_messages=[])
        _ask(db, "Qui n'a pas de vol ?")
        assistant = [m for m in db.tables["chat_messages"] if m["role"] == "assistant"][0]
        assert "rows" not in assistant
        # The count survives, so the thread can say "1 participant" without
        # holding the participant.
        assert assistant["row_count"] == 1


class TestItDegradesInsteadOfBreaking:

    def test_the_assistant_still_answers_without_the_tables(self):
        # Losing the transcript is survivable. Losing the assistant is not.
        db = _DB(missing=("chat_conversations", "chat_messages"))
        answer = _ask(db, "Qui n'a pas de vol ?")
        assert answer.answered is True
        assert answer.conversation_id is None

    def test_the_list_comes_back_empty_rather_than_erroring(self):
        db = _DB(missing=("chat_conversations", "chat_messages"))
        assert asyncio.run(
            C.list_conversations(EVENT, limit=30, current_user=MINE, supabase=db)
        ) == []

    def test_an_unknown_thread_id_starts_a_new_one_instead_of_404ing(self):
        # The question is still answerable; emptying the user's screen over a
        # stale id in their browser would not help them.
        db = _DB(chat_conversations=[], chat_messages=[])
        answer = _ask(db, "Qui n'a pas de vol ?",
                      conversation_id="99999999-9999-9999-9999-999999999999")
        assert answer.conversation_id
        assert answer.answered is True
