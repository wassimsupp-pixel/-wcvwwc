"""
Tests for named internal notes (note presets).

The team writes the same remarks constantly — "Super VIP", "cadeau dans la
chambre". A preset is that remark named once, with a colour the team picks,
so applying it is one click and the master-list row is coloured by a choice
somebody made rather than by whichever logistics category it fell into.

What matters here is mostly what happens when things are WRONG: a colour that
is not a colour, a preset deleted after notes were written from it, a
deployment where migration 028 never ran. All three have to degrade to the
behaviour notes had before presets existed, never to a blank screen.
"""

from types import SimpleNamespace

import pytest

EV = "e0000000-0000-0000-0000-000000000001"


class _Query:
    def __init__(self, table, fail=False):
        self._rows = list(table)
        self._fail = fail

    def select(self, *_a, **_k):
        return self

    def eq(self, col, val):
        self._rows = [r for r in self._rows if r.get(col) == val]
        return self

    def limit(self, n):
        self._rows = self._rows[:n]
        return self

    def execute(self):
        if self._fail:
            raise RuntimeError('column "note_presets" does not exist')
        return SimpleNamespace(data=self._rows)


class FakeDB:
    def __init__(self, missing=(), **tables):
        self.tables = dict(tables)
        self.missing = set(missing)

    def table(self, name):
        return _Query(self.tables.get(name, []), fail=name in self.missing)


class TestResolvingPresets:
    def test_a_plain_preset_survives(self):
        from services import note_presets
        got = note_presets.resolve([
            {"id": "vip", "name": "Super VIP", "body": "Cadeau chambre", "color": "#FF0000"}
        ])
        assert got == [{
            "id": "vip", "name": "Super VIP", "body": "Cadeau chambre",
            "color": "#FF0000", "category": "general",
        }]

    def test_a_name_alone_is_enough(self):
        # The body defaults to the name: a preset called "Super VIP" with no
        # separate wording is a note that says "Super VIP".
        from services import note_presets
        got = note_presets.resolve([{"name": "Super VIP"}])
        assert got[0]["id"] == "super-vip"
        assert got[0]["body"] == "Super VIP"
        assert got[0]["color"] == note_presets.DEFAULT_COLOR

    def test_a_preset_with_no_name_is_dropped(self):
        from services import note_presets
        assert note_presets.resolve([{"name": "   ", "body": "x"}]) == []

    def test_two_presets_that_slugify_the_same_get_distinct_ids(self):
        from services import note_presets
        got = note_presets.resolve([{"name": "VIP"}, {"name": "VIP"}])
        assert len({p["id"] for p in got}) == 2

    @pytest.mark.parametrize("color", ["red", "#GGGGGG", "", "rgb(1,2,3)", "#12345", None, 42])
    def test_anything_that_is_not_a_hex_colour_falls_back(self, color):
        # A silently-wrong colour is a silently-wrong signal; refuse rather
        # than coerce into something nobody picked.
        from services import note_presets
        got = note_presets.resolve([{"name": "X", "color": color}])
        assert got[0]["color"] == note_presets.DEFAULT_COLOR

    @pytest.mark.parametrize("color", ["#fff", "#FFF", "#a1b2c3", "#A1B2C3"])
    def test_both_hex_shapes_are_accepted(self, color):
        from services import note_presets
        assert note_presets.resolve([{"name": "X", "color": color}])[0]["color"] == color

    def test_an_unknown_category_falls_back_to_general(self):
        from services import note_presets
        got = note_presets.resolve([{"name": "X", "category": "rocket"}])
        assert got[0]["category"] == "general"

    @pytest.mark.parametrize("stored", [None, {}, "vip", [None], [42], [{}]])
    def test_a_malformed_list_never_blanks_the_screen(self, stored):
        from services import note_presets
        assert note_presets.resolve(stored) == []

    def test_the_number_of_presets_is_bounded(self):
        from services import note_presets
        got = note_presets.resolve([{"name": f"P{i}"} for i in range(200)])
        assert len(got) == note_presets.MAX_PRESETS

    def test_a_very_long_name_is_truncated_rather_than_rejected(self):
        from services import note_presets
        got = note_presets.resolve([{"name": "x" * 500}])
        assert len(got[0]["name"]) == note_presets.NAME_MAX


class TestFetching:
    def test_returns_empty_before_migration_028(self):
        from services import note_presets
        assert note_presets.fetch(FakeDB(missing=("events",)), EV) == []

    def test_an_event_that_defined_nothing_looks_the_same(self):
        from services import note_presets
        db = FakeDB(events=[{"id": EV, "note_presets": None}])
        assert note_presets.fetch(db, EV) == []

    def test_saved_presets_come_back_resolved(self):
        from services import note_presets
        db = FakeDB(events=[{"id": EV, "note_presets": [{"name": "VIP", "color": "#FF0000"}]}])
        got = note_presets.fetch(db, EV)
        assert got[0]["name"] == "VIP" and got[0]["color"] == "#FF0000"


class TestRowColour:
    def test_no_notes_means_no_colour(self):
        from services import note_presets
        assert note_presets.highlight_color([], []) == (None, None)

    def test_a_preset_note_is_coloured_by_its_preset(self):
        from services import note_presets
        presets = note_presets.resolve([{"id": "vip", "name": "Super VIP", "color": "#FF0000"}])
        colour, label = note_presets.highlight_color(
            [{"category": "general", "preset_id": "vip"}], presets
        )
        assert (colour, label) == ("#FF0000", "Super VIP")

    def test_a_preset_beats_a_plain_note_of_another_category(self):
        # Somebody who deliberately tagged this person "Super VIP" wants to
        # see that, not the generic colour of a logistics category.
        from services import note_presets
        presets = note_presets.resolve([{"id": "vip", "name": "Super VIP", "color": "#FF0000"}])
        colour, label = note_presets.highlight_color(
            [{"category": "accommodation"}, {"category": "general", "preset_id": "vip"}],
            presets,
        )
        assert (colour, label) == ("#FF0000", "Super VIP")

    def test_a_note_whose_preset_was_deleted_falls_back_to_its_category(self):
        # Deleting a preset must never blank a row or crash the list; the
        # note keeps its text and the row keeps a colour.
        from services import note_presets, note_service
        colour, label = note_presets.highlight_color(
            [{"category": "accommodation", "preset_id": "gone"}], []
        )
        assert colour == note_service.CATEGORY_COLORS["accommodation"]
        assert label == note_service.CATEGORY_LABELS["accommodation"]

    def test_without_presets_the_behaviour_is_exactly_what_it_was_before(self):
        from services import note_presets, note_service
        colour, label = note_presets.highlight_color([{"category": "transfer"}], [])
        assert colour == note_service.CATEGORY_COLORS["transfer"]
        assert label == note_service.CATEGORY_LABELS["transfer"]

    def test_a_note_with_no_preset_id_key_at_all_is_fine(self):
        # Exactly what rows look like before migration 028.
        from services import note_presets
        presets = note_presets.resolve([{"id": "vip", "name": "VIP", "color": "#FF0000"}])
        colour, _ = note_presets.highlight_color([{"category": "flight"}], presets)
        assert colour is not None
