"""
The Master List export is a single sheet now, by request.

It used to carry five more tabs — quality analysis, advice, exceptions,
summary, change log — plus a conditional UPDATES tab. All of that still exists
as its own screen inside the app (Rapports, Exceptions, Historique); only the
duplication into the file somebody forwards to a hotel or a client was
removed. This locks that shape down so a future change to the workbook
assembly doesn't quietly bring a sheet back.
"""

import pytest
from openpyxl import load_workbook

from services import export_service


class _Query:
    def __init__(self, rows):
        self.rows = list(rows)

    def select(self, *_a, **_k):
        return self

    def eq(self, *_a, **_k):
        return self

    def order(self, *_a, **_k):
        return self

    def limit(self, n):
        self.rows = self.rows[:n]
        return self

    def single(self):
        return self

    def execute(self):
        return type("Res", (), {"data": self.rows})()


class FakeSupabase:
    """Every table this function might touch returns an empty result — the
    point of the test is the sheet SHAPE, not the data in it."""

    def table(self, _name):
        return _Query([])


@pytest.fixture(autouse=True)
def _no_real_data(monkeypatch):
    monkeypatch.setattr(
        export_service.master_list_service, "build_master_rows", lambda *_a, **_k: []
    )


class TestTheWorkbookHasExactlyOneSheet:

    @pytest.mark.asyncio
    async def test_only_master_list_is_present(self):
        raw = await export_service.generate_excel(
            event_id="ev-1", run_id="run-1", user_id="u-1",
            supabase=FakeSupabase(), role="admin",
        )
        wb = load_workbook(__import__("io").BytesIO(raw))
        assert wb.sheetnames == ["Master List"]

    @pytest.mark.asyncio
    async def test_none_of_the_retired_sheets_come_back(self):
        raw = await export_service.generate_excel(
            event_id="ev-1", run_id="run-1", user_id="u-1",
            supabase=FakeSupabase(), role="viewer",
        )
        wb = load_workbook(__import__("io").BytesIO(raw))
        retired = {
            "Analyse Qualité", "Conseils", "Exceptions",
            "Résumé", "Historique des modifications", "UPDATES",
        }
        assert not (retired & set(wb.sheetnames))

    @pytest.mark.asyncio
    async def test_it_still_produces_a_readable_file_for_every_role(self):
        # The single-sheet cut must not depend on the dietary-visibility gate.
        for role in ("admin", "pm", "viewer", "client"):
            raw = await export_service.generate_excel(
                event_id="ev-1", run_id="run-1", user_id="u-1",
                supabase=FakeSupabase(), role=role,
            )
            assert load_workbook(__import__("io").BytesIO(raw)).sheetnames == ["Master List"]


class TestTheLiveScreensAreUntouched:
    """The removal was scoped to the FILE. The in-app analysis these sheets
    used to mirror must still work."""

    def test_build_analysis_is_still_exported_by_master_list_service(self):
        from services import master_list_service

        assert callable(master_list_service.build_analysis)

    def test_the_sheet_builder_helpers_still_exist_for_reuse(self):
        # Not called by generate_excel any more, but not deleted either: they
        # are directly unit-tested elsewhere and are where a sheet would be
        # added back if a specific export profile ever needs one.
        for name in (
            "_build_quality_sheet", "_build_advice_sheet",
            "_build_exceptions_sheet", "_build_summary_sheet",
            "_build_change_log_sheet",
        ):
            assert hasattr(export_service, name)
