"""
Tests for the last three structural gaps: rooms (§5), internal notes (§8) and
the UPDATES tab (§7).

Each has one property that matters more than the rest, and each gets its own
class for it:

  * a rooming list must never contradict itself between its two views;
  * a note must never leave the building unless somebody said so, note by note,
    AND its category points at that exact supplier;
  * a supplier must learn about a cancellation, because an absent row
    communicates nothing and they keep the room.
"""

import pytest

from services import export_diff as DIFF
from services import note_service as N
from services import room_service as R


def _p(pid, first="Ada", last="Lovelace", **over):
    base = {
        "id": pid, "first_name": first, "last_name": last,
        "room_type": None, "room_number": None, "roommate_participant_id": None,
    }
    base.update(over)
    return base


# ===========================================================================
# §5 — rooms
# ===========================================================================

class TestTheTwoViewsNeverDisagree:
    """The room view and the participant view are computed from one set of
    links. A rooming list that contradicts itself between two tabs is worse
    than one that is merely incomplete."""

    def _pair(self):
        return [
            _p("t", "Tina", "Fey", room_type="twin", room_number="304",
               roommate_participant_id="l"),
            _p("l", "Leslie", "Knope", room_type="twin", room_number="304",
               roommate_participant_id="t"),
        ]

    def test_a_pair_is_one_room_not_two(self):
        rooms = R.occupancy(self._pair())
        assert len(rooms) == 1
        assert rooms[0]["occupancy"] == 2

    def test_the_participant_view_still_has_a_line_each(self):
        lines = R.participant_view(R.occupancy(self._pair()))
        assert len(lines) == 2

    def test_both_lines_carry_the_same_room_number(self):
        lines = R.participant_view(R.occupancy(self._pair()))
        assert {l["room_number"] for l in lines} == {"304"}

    def test_each_line_names_the_other_occupant(self):
        lines = {l["name"]: l for l in R.participant_view(R.occupancy(self._pair()))}
        assert lines["Tina Fey"]["roommate"] == "Leslie Knope"
        assert lines["Leslie Knope"]["roommate"] == "Tina Fey"

    def test_every_participant_appears_exactly_once_across_the_rooms(self):
        people = [_p("a", roommate_participant_id="b"), _p("b", roommate_participant_id="a"),
                  _p("c"), _p("d", roommate_participant_id="e"), _p("e", roommate_participant_id="d")]
        occupants = [o["participant_id"] for r in R.occupancy(people) for o in r["occupants"]]
        assert sorted(occupants) == ["a", "b", "c", "d", "e"]
        assert len(occupants) == len(set(occupants))

    def test_the_head_counts_agree_between_the_views(self):
        people = [_p("a", roommate_participant_id="b"), _p("b", roommate_participant_id="a"), _p("c")]
        rooms = R.occupancy(people)
        assert sum(r["occupancy"] for r in rooms) == len(R.participant_view(rooms)) == 3


class TestRoomComposition:
    def test_somebody_alone_is_a_single(self):
        assert R.occupancy([_p("a")])[0]["room_type"] == "single"

    def test_a_pair_with_no_declared_type_is_a_twin(self):
        rooms = R.occupancy([_p("a", roommate_participant_id="b"),
                             _p("b", roommate_participant_id="a")])
        assert rooms[0]["room_type"] == "twin"

    def test_a_declared_type_wins_over_the_head_count(self):
        rooms = R.occupancy([_p("a", room_type="suite", roommate_participant_id="b"),
                             _p("b", roommate_participant_id="a")])
        assert rooms[0]["room_type"] == "suite"

    def test_two_different_numbers_on_one_room_are_surfaced_not_merged(self):
        # The hotel gave two answers about one room. Picking one silently
        # would be inventing an answer nobody gave.
        rooms = R.occupancy([
            _p("a", room_number="304", roommate_participant_id="b"),
            _p("b", room_number="305", roommate_participant_id="a"),
        ])
        assert rooms[0]["conflict"] == "room_number_mismatch"
        assert rooms[0]["room_numbers"] == ["304", "305"]

    def test_a_link_pointing_at_nobody_leaves_a_single(self):
        rooms = R.occupancy([_p("a", roommate_participant_id="ghost")])
        assert len(rooms) == 1 and rooms[0]["occupancy"] == 1

    def test_rooms_are_ordered_numerically_not_alphabetically(self):
        rooms = R.occupancy([_p("a", room_number="10"), _p("b", room_number="9")])
        assert [r["room_number"] for r in rooms] == ["9", "10"]

    def test_unnumbered_rooms_come_last(self):
        rooms = R.occupancy([_p("a"), _p("b", room_number="12")])
        assert [r["room_number"] for r in rooms] == ["12", ""]

    def test_nobody_gives_no_rooms(self):
        assert R.occupancy([]) == []


class TestStayDates:
    def test_the_stay_spans_both_occupants_nights(self):
        nights = [
            {"participant_id": "a", "night_date": "2026-09-01"},
            {"participant_id": "b", "night_date": "2026-09-03"},
        ]
        rooms = R.occupancy([_p("a", roommate_participant_id="b"),
                             _p("b", roommate_participant_id="a")], nights)
        assert rooms[0]["check_in"] == "2026-09-01"
        assert rooms[0]["check_out"] == "2026-09-03"

    def test_a_room_with_no_nights_reports_none_rather_than_a_guess(self):
        rooms = R.occupancy([_p("a")], [])
        assert rooms[0]["nights"] == 0
        assert rooms[0]["check_in"] == ""


class TestRoomSummary:
    def test_it_counts_what_you_phone_the_hotel_about(self):
        got = R.summarise(R.occupancy([
            _p("a", room_number="1", roommate_participant_id="b"),
            _p("b", room_number="1", roommate_participant_id="a"),
            _p("c"),
        ]))
        assert got["rooms"] == 2
        assert got["participants"] == 3
        assert got["unassigned"] == 1
        assert got["by_type"] == {"single": 1, "twin": 1}

    def test_it_reports_conflicts(self):
        got = R.summarise(R.occupancy([
            _p("a", room_number="304", roommate_participant_id="b"),
            _p("b", room_number="305", roommate_participant_id="a"),
        ]))
        assert got["conflicts"] == 1


# ===========================================================================
# §8 — internal notes
# ===========================================================================

class TestNothingLeavesUnlessSomebodySaidSo:
    """The failure mode is not a remark nobody shared. It is a coach company
    reading "difficult client, handle carefully" about somebody in their van."""

    def test_a_note_is_internal_by_default(self):
        assert N.clean("Super VIP", "general", False)["include_in_export"] is False

    def test_an_unflagged_note_reaches_no_supplier(self):
        notes = [{"participant_id": "p1", "category": "accommodation",
                  "body": "Cadeau dans la chambre", "include_in_export": False}]
        assert N.for_export(notes, "hotel") == {}

    def test_a_flagged_note_reaches_its_own_supplier(self):
        notes = [{"participant_id": "p1", "category": "accommodation",
                  "body": "Cadeau dans la chambre", "include_in_export": True}]
        assert N.for_export(notes, "hotel") == {"p1": "Cadeau dans la chambre"}

    def test_a_flagged_note_reaches_nobody_else(self):
        # The mutation check for the one above: flagging is necessary, not
        # sufficient. A flight remark on a rooming list is exactly the kind of
        # leak a single careless tick would otherwise cause.
        notes = [{"participant_id": "p1", "category": "flight",
                  "body": "A change de vol", "include_in_export": True}]
        assert N.for_export(notes, "hotel") == {}
        assert N.for_export(notes, "flight") == {"p1": "A change de vol"}

    def test_a_general_note_can_never_be_shared_at_all(self):
        # It has no stated destination, so it has no business on anybody's
        # sheet, whatever it says.
        cleaned = N.clean("Super VIP", "general", True)
        assert cleaned["include_in_export"] is False
        for profile in ("hotel", "transfer", "flight", "activity"):
            assert N.for_export([{"participant_id": "p", **cleaned}], profile) == {}

    def test_an_unknown_category_falls_back_to_the_one_that_never_exports(self):
        assert N.normalise_category("gossip") == N.GENERAL
        assert N.clean("x", "gossip", True)["include_in_export"] is False

    @pytest.mark.parametrize("body", ["", "   ", None])
    def test_an_empty_note_is_not_stored(self, body):
        assert N.clean(body, "general", False) is None

    def test_a_very_long_note_is_truncated_rather_than_refused(self):
        assert len(N.clean("x" * 5000, "general", False)["body"]) == N.MAX_BODY

    def test_several_shared_notes_on_one_person_are_joined_not_dropped(self):
        notes = [
            {"participant_id": "p1", "category": "accommodation", "body": "Etage eleve",
             "include_in_export": True},
            {"participant_id": "p1", "category": "accommodation", "body": "Lit double",
             "include_in_export": True},
        ]
        assert N.for_export(notes, "hotel") == {"p1": "Etage eleve · Lit double"}

    def test_every_category_declares_whether_it_can_ever_be_shared(self):
        described = {c["key"]: c for c in N.describe_categories()}
        assert described["general"]["exportable_to"] is None
        assert described["accommodation"]["exportable_to"] == "hotel"
        assert set(described) == set(N.CATEGORIES)


# ===========================================================================
# §7 — UPDATES between two exports
# ===========================================================================

class TestSuppliersLearnAboutCancellations:
    """A supplier who never learns somebody cancelled keeps a seat, a room and
    a meal for them. An absent row communicates nothing."""

    def test_a_departure_is_reported_not_silently_omitted(self):
        before = DIFF.snapshot([{"participant_id": "p1", "first_name": "Tina", "last_name": "Fey"}])
        after = DIFF.snapshot([])
        changes = DIFF.diff(before, after)
        assert [c["status"] for c in changes] == [DIFF.CANCELLED]
        assert changes[0]["participant_name"] == "Tina Fey"

    def test_a_new_participant_is_reported(self):
        # Against a real previous file, not an empty one: an empty snapshot is
        # indistinguishable from "no previous export", and that case is
        # deliberately silent (see test_a_first_export_declares_nothing).
        before = DIFF.snapshot([{"participant_id": "p1", "last_name": "Fey"}])
        after = DIFF.snapshot([
            {"participant_id": "p1", "last_name": "Fey"},
            {"participant_id": "p2", "first_name": "Leslie", "last_name": "Knope"},
        ])
        changes = DIFF.diff(before, after)
        assert [c["status"] for c in changes] == [DIFF.NEW]
        assert changes[0]["participant_name"] == "Leslie Knope"

    def test_a_changed_value_names_the_field_and_both_sides(self):
        before = DIFF.snapshot([{"participant_id": "p1", "last_name": "Fey",
                                 "outbound_flight_number": "SN123"}])
        after = DIFF.snapshot([{"participant_id": "p1", "last_name": "Fey",
                                "outbound_flight_number": "SN456"}])
        change = DIFF.diff(before, after)[0]
        assert change["status"] == DIFF.UPDATED
        assert change["label"] == "Vol aller"
        assert (change["old"], change["new"]) == ("SN123", "SN456")


class TestDiffBehaviour:
    def test_a_first_export_declares_nothing_rather_than_everything_new(self):
        # Two hundred rows saying NEW would be true and useless.
        after = DIFF.snapshot([{"participant_id": "p%d" % i} for i in range(200)])
        assert DIFF.diff(None, after) == []
        assert DIFF.diff({}, after) == []

    def test_an_unchanged_file_reports_nothing(self):
        rows = [{"participant_id": "p1", "last_name": "Fey", "hotel_name": "Grand"}]
        snap = DIFF.snapshot(rows)
        assert DIFF.diff(snap, DIFF.snapshot(rows)) == []

    @pytest.mark.parametrize("before,after", [(None, ""), ("", "   "), (None, "   ")])
    def test_the_absence_of_a_value_is_not_a_change(self, before, after):
        # None, "" and "  " all mean "we do not know", and reporting a change
        # between them is noise a supplier learns to ignore.
        b = DIFF.snapshot([{"participant_id": "p1", "hotel_name": before}])
        a = DIFF.snapshot([{"participant_id": "p1", "hotel_name": after}])
        assert DIFF.diff(b, a) == []

    def test_filling_in_a_blank_IS_a_change(self):
        b = DIFF.snapshot([{"participant_id": "p1", "hotel_name": ""}])
        a = DIFF.snapshot([{"participant_id": "p1", "hotel_name": "Grand Hotel"}])
        assert len(DIFF.diff(b, a)) == 1

    def test_a_renamed_participant_is_one_update_not_a_departure_and_an_arrival(self):
        # Keyed by id precisely for this: a maiden name or a corrected spelling
        # would otherwise report one person leaving and a stranger arriving.
        b = DIFF.snapshot([{"participant_id": "p1", "last_name": "Sezgin"}])
        a = DIFF.snapshot([{"participant_id": "p1", "last_name": "Sezgin Stuart"}])
        changes = DIFF.diff(b, a)
        assert [c["status"] for c in changes] == [DIFF.UPDATED]

    def test_a_row_with_no_id_is_skipped_rather_than_crashing_the_export(self):
        assert DIFF.snapshot([{"last_name": "Nobody"}]) == {}

    def test_the_id_field_is_accepted_as_well_as_participant_id(self):
        assert list(DIFF.snapshot([{"id": "p1", "last_name": "Fey"}])) == ["p1"]

    def test_changes_are_grouped_new_then_updated_then_cancelled(self):
        before = DIFF.snapshot([
            {"participant_id": "p1", "last_name": "Aa", "hotel_name": "X"},
            {"participant_id": "p2", "last_name": "Bb"},
        ])
        after = DIFF.snapshot([
            {"participant_id": "p1", "last_name": "Aa", "hotel_name": "Y"},
            {"participant_id": "p3", "last_name": "Cc"},
        ])
        statuses = [c["status"] for c in DIFF.diff(before, after)]
        assert statuses == sorted(statuses, key=lambda s: {DIFF.NEW: 0, DIFF.UPDATED: 1, DIFF.CANCELLED: 2}[s])

    def test_two_identical_diffs_are_identical(self):
        b = DIFF.snapshot([{"participant_id": "p%d" % i, "hotel_name": "X"} for i in range(20)])
        a = DIFF.snapshot([{"participant_id": "p%d" % i, "hotel_name": "Y"} for i in range(20)])
        assert DIFF.diff(b, a) == DIFF.diff(b, a)


class TestUpdatesSummary:
    def test_it_counts_people_not_rows(self):
        # One person with three changed fields is one updated participant, not
        # three.
        b = DIFF.snapshot([{"participant_id": "p1", "hotel_name": "A",
                            "hotel_checkin": "01/09", "roommate_name": "X"}])
        a = DIFF.snapshot([{"participant_id": "p1", "hotel_name": "B",
                            "hotel_checkin": "02/09", "roommate_name": "Y"}])
        changes = DIFF.diff(b, a)
        got = DIFF.summarise(changes)
        assert got["updated"] == 1
        assert got["changes"] == 3

    def test_an_empty_diff_summarises_to_zeroes(self):
        assert DIFF.summarise([]) == {"new": 0, "updated": 0, "cancelled": 0, "changes": 0}


class TestUpdatesSheetShape:
    def test_the_columns_are_the_ones_the_feedback_asks_for(self):
        assert DIFF.UPDATES_HEADERS == [
            "Statut", "Participant", "Information", "Ancienne valeur", "Nouvelle valeur"]

    def test_every_row_matches_the_header_width(self):
        b = DIFF.snapshot([{"participant_id": "p1", "hotel_name": "A"},
                           {"participant_id": "p2", "last_name": "Gone"}])
        a = DIFF.snapshot([{"participant_id": "p1", "hotel_name": "B"},
                           {"participant_id": "p3", "last_name": "New"}])
        rows = DIFF.as_sheet_rows(DIFF.diff(b, a))
        assert rows and all(len(r) == len(DIFF.UPDATES_HEADERS) for r in rows)

    def test_the_status_is_the_first_thing_read(self):
        b = DIFF.snapshot([{"participant_id": "p1", "hotel_name": "A"}])
        a = DIFF.snapshot([{"participant_id": "p1", "hotel_name": "B"}])
        assert DIFF.as_sheet_rows(DIFF.diff(b, a))[0][0] == DIFF.UPDATED
