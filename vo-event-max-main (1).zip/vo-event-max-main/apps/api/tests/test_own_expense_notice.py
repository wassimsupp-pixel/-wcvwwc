"""
Tests for telling somebody their extra nights are their own.

This is a grouped send of individual letters, and almost every test below is
about that word "individual". Thirty-six people on the live event are in this
position; the failure mode that matters is not a crash, it is a letter that
mentions the other thirty-five, or that names a number of nights the organizer
never saw on screen.
"""

import pytest

from services import own_expense_notice as N


EVENT = ("Athens", "2026-09-01", "2026-09-04")


def _p(pid, first="Ada", last="Lovelace", **over):
    base = {"id": pid, "first_name": first, "last_name": last,
            "email": f"{pid}@x.com", "language": "fr"}
    base.update(over)
    return base


def _stay(pid, early=0, late=5, first="2026-09-01", last="2026-09-09"):
    return {
        "participant_id": pid,
        "arrives_early_days": early,
        "stays_late_days": late,
        "first_departure": first,
        "last_departure": last,
        "extra_nights": early + late,
    }


# ===========================================================================
# Who gets a letter
# ===========================================================================

class TestWhoIsWrittenTo:
    def test_somebody_outside_the_dates_gets_one(self):
        notices, skipped = N.plan_notices([_p("a")], [_stay("a")])
        assert len(notices) == 1
        assert notices[0]["nights"] == 5
        assert skipped == []

    def test_no_email_means_no_letter_and_a_named_reason(self):
        """"36 prepared" is only honest with the ones that were not, and this
        is the reason the send itself cannot fix."""
        notices, skipped = N.plan_notices([_p("a", email="")], [_stay("a")])
        assert notices == []
        assert skipped[0]["reason"] == "no_email"
        assert skipped[0]["name"] == "Ada Lovelace"

    def test_a_threshold_keeps_a_single_late_night_quiet(self):
        """One night outside the dates is usually a late flight rather than an
        extension, and a letter about it reads as pedantic."""
        notices, skipped = N.plan_notices(
            [_p("a")], [_stay("a", late=1)], min_nights=2
        )
        assert notices == []
        assert skipped[0]["reason"] == "below_threshold"

    def test_the_threshold_can_never_be_zero(self):
        """Nobody with no extra nights should ever receive this."""
        notices, _ = N.plan_notices([_p("a")], [_stay("a", late=0)], min_nights=0)
        assert notices == []

    def test_a_subset_can_be_chosen(self):
        notices, _ = N.plan_notices(
            [_p("a"), _p("b", "Bob")], [_stay("a"), _stay("b")], only=["b"]
        )
        assert [n["participant_id"] for n in notices] == ["b"]

    def test_somebody_no_longer_on_the_event_is_reported_not_written_to(self):
        notices, skipped = N.plan_notices([], [_stay("disparu")])
        assert notices == []
        assert skipped[0]["reason"] == "unknown_participant"

    def test_the_longest_stay_comes_first(self):
        """The biggest bill is the one worth reading first."""
        notices, _ = N.plan_notices(
            [_p("a"), _p("b", "Bob")], [_stay("a", late=2), _stay("b", late=9)]
        )
        assert [n["participant_id"] for n in notices] == ["b", "a"]


# ===========================================================================
# What the letter says
# ===========================================================================

class TestTheLetterItself:
    def _compose(self, stay, person=None, **kw):
        notices, _ = N.plan_notices([person or _p("a")], [stay])
        return N.compose(notices[0], *EVENT, **kw)

    def test_it_names_the_person_and_their_own_nights(self):
        subject, body = self._compose(_stay("a", late=5))
        assert "Ada" in body
        assert "5 nuit(s) en dehors du programme" in body

    def test_it_shows_the_dates_it_is_reasoning_from(self):
        """"You have extra nights" is an assertion they cannot check. "You
        leave on the 9th, five days after the end" is."""
        _, body = self._compose(_stay("a", late=5, last="2026-09-09"))
        assert "09/09/2026" in body
        assert "5 jour(s) après la fin" in body

    def test_it_shows_an_early_arrival_the_same_way(self):
        _, body = self._compose(_stay("a", early=3, late=0, first="2026-08-29"))
        assert "29/08/2026" in body
        assert "3 jour(s) avant le début" in body
        # Nothing about a departure they are not making.
        assert "après la fin" not in body

    def test_it_says_the_nights_are_theirs(self):
        _, body = self._compose(_stay("a"))
        assert "à votre charge" in body

    def test_it_invites_the_correction(self):
        """Our file may simply be out of date, and the person most likely to
        receive this is the one who already changed their return."""
        _, body = self._compose(_stay("a"))
        assert "répondez à ce message" in body

    def test_it_quotes_no_price(self):
        """We do not know the hotel's rate, and inventing one is worse than
        saying nothing."""
        _, body = self._compose(_stay("a"))
        assert "€" not in body and "EUR" not in body

    def test_the_programme_dates_are_stated(self):
        _, body = self._compose(_stay("a"))
        assert "01/09/2026" in body and "04/09/2026" in body

    def test_the_sender_signs_it(self):
        _, body = self._compose(_stay("a"), sender="VO Communication Group")
        assert body.rstrip().endswith("VO Communication Group")


class TestNobodyElseIsInIt:
    """The rule that makes a grouped send acceptable."""

    def test_no_other_participant_is_named(self):
        people = [_p("a"), _p("b", "Bob", "Martin"), _p("c", "Cleo", "Nash")]
        stays = [_stay("a"), _stay("b"), _stay("c")]
        notices, _ = N.plan_notices(people, stays)
        for notice in notices:
            _, body = N.compose(notice, *EVENT)
            others = {"Bob", "Martin", "Cleo", "Nash", "Ada", "Lovelace"} - set(
                notice["name"].split()
            )
            for name in others:
                assert name not in body, f"{name} apparaît dans le mail de {notice['name']}"

    def test_the_total_across_the_event_is_never_mentioned(self):
        people = [_p(x) for x in ("a", "b", "c")]
        notices, _ = N.plan_notices(people, [_stay(x, late=5) for x in ("a", "b", "c")])
        _, body = N.compose(notices[0], *EVENT)
        assert "15" not in body      # 3 × 5 nights
        assert "3 participant" not in body


class TestEachInTheirOwnLanguage:
    def test_dutch(self):
        notices, _ = N.plan_notices([_p("a", language="nl")], [_stay("a")])
        subject, body = N.compose(notices[0], *EVENT)
        assert "buiten het programma" in subject
        assert "eigen rekening" in body

    def test_english(self):
        notices, _ = N.plan_notices([_p("a", language="en")], [_stay("a")])
        subject, body = N.compose(notices[0], *EVENT)
        assert "outside the programme" in subject
        assert "at your own expense" in body

    def test_an_unknown_language_falls_back_to_french(self):
        notices, _ = N.plan_notices([_p("a", language="pt")], [_stay("a")])
        _, body = N.compose(notices[0], *EVENT)
        assert "à votre charge" in body


class TestTheSummaryTheOrganizerReads:
    def test_it_counts_letters_nights_and_languages(self):
        people = [_p("a"), _p("b", "Bob", language="nl"), _p("c", "Cleo", email="")]
        stays = [_stay("a", late=5), _stay("b", late=3), _stay("c", late=2)]
        notices, skipped = N.plan_notices(people, stays)
        got = N.summarise(notices, skipped)
        assert got["notices"] == 2
        assert got["nights"] == 8
        assert got["by_language"] == {"fr": 1, "nl": 1}
        assert got["skipped"] == 1
        assert got["skipped_reasons"] == {"no_email": 1}
