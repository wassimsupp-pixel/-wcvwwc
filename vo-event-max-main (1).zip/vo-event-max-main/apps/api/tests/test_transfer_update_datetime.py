"""
Regression test for updating a transfer's pickup_time.

create_transfer already carries the comment: ".model_dump() alone leaves
UUID/datetime fields as non-JSON-serializable objects" — and uses
model_dump(mode="json") to avoid it. update_transfer had the identical field
(TransferUpdate.pickup_time is a datetime) and the identical bug, just never
triggered: nothing called PATCH /transfers/{id} with a pickup_time until the
transfers list grew an edit button and immediately hit it in production
("An unexpected internal error occurred").

json.dumps is used as the check because that IS what breaks: the Supabase
client serialises the update payload to JSON internally, and a raw
`datetime` object raises exactly the same TypeError.
"""

import json
from unittest.mock import AsyncMock, patch

import pytest

from models.schemas import TransferUpdate
from routers.transfers import update_transfer


class _Query:
    def __init__(self, table):
        self.t = table
        self.rows = list(table.rows)
        self._single = False
        self.captured_update = None

    def select(self, *_a, **_k):
        return self

    def eq(self, col, val):
        self.rows = [r for r in self.rows if str(r.get(col)) == str(val)]
        return self

    def single(self):
        self._single = True
        return self

    def update(self, payload):
        self.t.captured_update = payload
        for row in self.t.rows:
            if row in self.rows:
                row.update(payload)
        return self

    def execute(self):
        data = self.rows[0] if self._single else self.rows
        return type("Res", (), {"data": data})()


class _Table:
    def __init__(self, rows):
        self.rows = rows
        self.captured_update = None


class FakeSupabase:
    def __init__(self, transfers):
        self.transfers = _Table(list(transfers))

    def table(self, _name):
        return _Query(self.transfers)


TRANSFER_ID = "11111111-1111-1111-1111-111111111111"
EVENT_ID = "22222222-2222-2222-2222-222222222222"
PARTICIPANT_ID = "33333333-3333-3333-3333-333333333333"


def _transfer(**over):
    base = {
        "id": TRANSFER_ID, "event_id": EVENT_ID, "participant_id": PARTICIPANT_ID,
        "transfer_type": "arrival", "pickup_location": "Aéroport",
        "dropoff_location": "Hôtel", "pickup_time": "2026-08-29T15:00:00",
        "vehicle_type": "Taxi", "status": "scheduled",
        "created_at": "2026-08-01T10:00:00",
    }
    base.update(over)
    return base


@pytest.mark.asyncio
@patch("routers.transfers.verify_event_access", new_callable=AsyncMock)
@patch("routers.transfers.log_change")
class TestUpdatingAPickupTime:

    async def test_the_update_payload_is_json_serialisable(self, _log, _verify):
        # This is the exact failure mode: a raw datetime object in the payload
        # raises inside the Supabase client's own JSON encoding, which is what
        # produced "An unexpected internal error occurred" for every edit.
        sb = FakeSupabase([_transfer()])
        body = TransferUpdate(pickup_time="2026-08-29T15:00:00")
        await update_transfer(TRANSFER_ID, body, {"id": "u-1"}, sb)
        json.dumps(sb.transfers.captured_update)  # must not raise

    async def test_the_new_time_is_actually_written(self, _log, _verify):
        sb = FakeSupabase([_transfer()])
        body = TransferUpdate(pickup_time="2026-08-30T09:00:00")
        result = await update_transfer(TRANSFER_ID, body, {"id": "u-1"}, sb)
        assert result.pickup_time.isoformat() == "2026-08-30T09:00:00"

    async def test_a_plain_field_still_updates_alongside_the_time(self, _log, _verify):
        sb = FakeSupabase([_transfer()])
        body = TransferUpdate(pickup_time="2026-08-30T09:00:00", vehicle_type="Van")
        await update_transfer(TRANSFER_ID, body, {"id": "u-1"}, sb)
        assert sb.transfers.rows[0]["vehicle_type"] == "Van"

    async def test_an_untouched_field_is_not_sent_at_all(self, _log, _verify):
        # exclude_none=True: editing only the time must not overwrite
        # pickup_location with None.
        sb = FakeSupabase([_transfer()])
        body = TransferUpdate(pickup_time="2026-08-30T09:00:00")
        await update_transfer(TRANSFER_ID, body, {"id": "u-1"}, sb)
        assert "pickup_location" not in sb.transfers.captured_update
