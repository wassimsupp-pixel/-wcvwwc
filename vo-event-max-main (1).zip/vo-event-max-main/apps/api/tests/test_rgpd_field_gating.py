"""
Tests for what a non-staff account is allowed to read.

The application is about to be handed to a client for a trial, which means
accounts that are not `admin` and not `pm` are about to exist for the first
time. Everything below is about the payload rather than the screen: the master
list table has never displayed a passport number, and the API returned one to
every role anyway. A leak in a response nobody renders is still a leak — it is
one network tab away, and it is in every export built from the same rows.
"""

import pytest

from routers.participants import STAFF_ONLY_FIELDS


def _row(**over):
    """A master-list row carrying everything sensitive at once."""
    base = {
        "id": "p1", "first_name": "Ada", "last_name": "Lovelace",
        "email": "ada@x.com", "company": "ACME",
        "dietary_requirements": "végétarien",
        "food_allergy_info": "arachides",
        "medical_info": "épilepsie",
        "passport_number": "X1234567",
        "passport_expiry": "2030-01-01",
        "date_of_birth": "1815-12-10",
        "has_flight": True,
    }
    base.update(over)
    return base


def _strip(rows, role):
    """Exactly what the endpoint does, applied to a list of rows."""
    if role not in ("admin", "pm"):
        for r in rows:
            for field in STAFF_ONLY_FIELDS:
                r.pop(field, None)
    return rows


class TestHealthDataIsStaffOnly:
    @pytest.mark.parametrize("role", ["viewer", "client", "project_user", "freelancer", "participant", ""])
    def test_no_other_role_sees_it(self, role):
        got = _strip([_row()], role)[0]
        assert "dietary_requirements" not in got
        assert "food_allergy_info" not in got
        assert "medical_info" not in got

    @pytest.mark.parametrize("role", ["admin", "pm"])
    def test_staff_still_see_it(self, role):
        got = _strip([_row()], role)[0]
        assert got["dietary_requirements"] == "végétarien"
        assert got["medical_info"] == "épilepsie"


class TestIdentityDocumentsAreStaffOnly:
    """The gap this file was written for.

    Until 2026-08-25 the master list stripped the food fields and handed every
    viewer account a passport number in the same response.
    """

    @pytest.mark.parametrize("role", ["viewer", "client", "project_user", "freelancer"])
    def test_no_passport_number_for_anybody_else(self, role):
        got = _strip([_row()], role)[0]
        assert "passport_number" not in got

    @pytest.mark.parametrize("role", ["viewer", "client", "project_user", "freelancer"])
    def test_no_expiry_and_no_date_of_birth_either(self, role):
        """A passport expiry is passport data, and a date of birth identifies
        somebody on its own."""
        got = _strip([_row()], role)[0]
        assert "passport_expiry" not in got
        assert "date_of_birth" not in got

    @pytest.mark.parametrize("role", ["admin", "pm"])
    def test_staff_still_see_them(self, role):
        got = _strip([_row()], role)[0]
        assert got["passport_number"] == "X1234567"
        assert got["date_of_birth"] == "1815-12-10"


class TestTheRestOfTheRowSurvives:
    def test_a_viewer_still_gets_a_usable_master_list(self):
        """Gating must not empty the page: a client trialling the product has
        to see their own event."""
        got = _strip([_row()], "viewer")[0]
        assert got["first_name"] == "Ada"
        assert got["email"] == "ada@x.com"
        assert got["company"] == "ACME"
        assert got["has_flight"] is True

    def test_a_row_missing_the_sensitive_fields_does_not_crash(self):
        """Not every event collects them, and `.pop` must tolerate that."""
        assert _strip([{"id": "p1", "first_name": "Ada"}], "viewer") == [
            {"id": "p1", "first_name": "Ada"}
        ]

    def test_every_row_is_stripped_not_only_the_first(self):
        rows = _strip([_row(), _row(id="p2"), _row(id="p3")], "viewer")
        assert all("passport_number" not in r for r in rows)


class TestTheListItselfIsTheContract:
    def test_it_names_both_families(self):
        for field in ("dietary_requirements", "food_allergy_info", "medical_info",
                      "passport_number", "passport_expiry", "date_of_birth"):
            assert field in STAFF_ONLY_FIELDS, f"{field} n'est plus protégé"

    def test_it_does_not_gate_something_the_page_needs(self):
        """A field in here disappears for every non-staff account, so the list
        is deliberately short. Identity and logistics must never join it."""
        for field in ("first_name", "last_name", "email", "company",
                      "has_flight", "has_hotel", "completeness_status"):
            assert field not in STAFF_ONLY_FIELDS
