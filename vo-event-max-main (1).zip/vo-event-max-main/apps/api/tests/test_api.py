"""
tests/test_api.py — FastAPI integration tests using TestClient.

Tests use dependency overrides to mock Supabase and JWT verification so
no real credentials are needed in CI.

Test groups:
  - Health check
  - File upload validation (format, size, confirmation gate)
  - Column mapping confirmation gate
  - Participant access control (dietary field restriction)
  - Consolidation service unit tests (matching engine)
"""

from __future__ import annotations

import io
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient

# ---------------------------------------------------------------------------
# Minimal environment setup (no real Supabase needed for unit tests)
# ---------------------------------------------------------------------------
import os
os.environ.setdefault("SUPABASE_URL", "https://test.supabase.co")
os.environ.setdefault("SUPABASE_SERVICE_ROLE_KEY", "test-service-role-key")
os.environ.setdefault("SECRET_KEY", "test-secret-key")
os.environ.setdefault("ALLOWED_ORIGINS", "http://localhost:3000")

from main import app
from dependencies import get_current_user, get_supabase_client


# ---------------------------------------------------------------------------
# Fixtures and mocks
# ---------------------------------------------------------------------------

MOCK_ADMIN_USER = {
    "id": "00000000-0000-0000-0000-000000000001",
    "org_id": "00000000-0000-0000-0000-000000000010",
    "email": "admin@test.com",
    "full_name": "Test Admin",
    "role": "admin",
    "preferred_language": "fr",
}

MOCK_VIEWER_USER = {
    "id": "00000000-0000-0000-0000-000000000002",
    "org_id": "00000000-0000-0000-0000-000000000010",
    "email": "viewer@test.com",
    "full_name": "Test Viewer",
    "role": "viewer",
    "preferred_language": "fr",
}


def _mock_supabase() -> MagicMock:
    """Return a MagicMock that mimics the Supabase client interface."""
    mock = MagicMock()
    # Default: all table queries return empty data
    mock.table.return_value.select.return_value.eq.return_value.single.return_value.execute.return_value.data = None
    mock.table.return_value.select.return_value.execute.return_value.data = []
    return mock


def _admin_client() -> TestClient:
    """TestClient with admin user injected."""
    app.dependency_overrides[get_current_user] = lambda: MOCK_ADMIN_USER
    app.dependency_overrides[get_supabase_client] = _mock_supabase
    return TestClient(app, raise_server_exceptions=False)


def _viewer_client() -> TestClient:
    """TestClient with viewer user injected."""
    app.dependency_overrides[get_current_user] = lambda: MOCK_VIEWER_USER
    app.dependency_overrides[get_supabase_client] = _mock_supabase
    return TestClient(app, raise_server_exceptions=False)


def _unauthenticated_client() -> TestClient:
    """TestClient with no dependency overrides (real auth attempted)."""
    app.dependency_overrides = {}
    return TestClient(app, raise_server_exceptions=False)


# ---------------------------------------------------------------------------
# 1. Health check
# ---------------------------------------------------------------------------

class TestHealthCheck:
    def test_health_check_returns_200(self):
        """GET /health should return 200 with status=ok."""
        client = TestClient(app)
        response = client.get("/health")
        assert response.status_code == 200

    def test_health_check_body(self):
        """GET /health should return correct JSON body."""
        client = TestClient(app)
        body = client.get("/health").json()
        assert body["status"] == "ok"
        assert "version" in body

    def test_health_check_no_auth_required(self):
        """GET /health must be accessible without Authorization header."""
        client = _unauthenticated_client()
        response = client.get("/health")
        # Should NOT return 401 (no auth required for health)
        assert response.status_code != 401


# ---------------------------------------------------------------------------
# 2. File upload — format validation
# ---------------------------------------------------------------------------

class TestFileUpload:
    EVENT_ID = "00000000-0000-0000-0000-000000000099"

    def _make_file(self, content: bytes, filename: str, content_type: str):
        return ("file", (filename, io.BytesIO(content), content_type))

    def test_upload_rejects_pdf(self):
        """
        POST /api/files/upload with a .pdf file must return 415 Unsupported Media Type.

        The API only accepts .xlsx, .xls, and .csv files.
        """
        client = _admin_client()
        response = client.post(
            "/api/files/upload",
            data={"event_id": self.EVENT_ID, "source_type": "registration"},
            files=[self._make_file(b"%PDF-1.4 test content", "participants.pdf", "application/pdf")],
        )
        assert response.status_code == 415, f"Expected 415, got {response.status_code}: {response.text}"

    def test_upload_rejects_docx(self):
        """
        POST /api/files/upload with a .docx file must return 415.
        """
        client = _admin_client()
        response = client.post(
            "/api/files/upload",
            data={"event_id": self.EVENT_ID, "source_type": "registration"},
            files=[self._make_file(b"PK fake docx", "report.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")],
        )
        assert response.status_code == 415

    def test_upload_rejects_oversized_file(self):
        """
        POST /api/files/upload with a file > 50 MB must return 413 Request Entity Too Large.
        """
        client = _admin_client()
        large_content = b"a" * (51 * 1024 * 1024)  # 51 MB
        response = client.post(
            "/api/files/upload",
            data={"event_id": self.EVENT_ID, "source_type": "registration"},
            files=[self._make_file(large_content, "big.csv", "text/csv")],
        )
        assert response.status_code == 413

    def test_upload_rejects_txt(self):
        """
        POST /api/files/upload with a .txt file must return 415.
        """
        client = _admin_client()
        response = client.post(
            "/api/files/upload",
            data={"event_id": self.EVENT_ID, "source_type": "registration"},
            files=[self._make_file(b"plain text", "data.txt", "text/plain")],
        )
        assert response.status_code == 415

    @patch("routers.files.verify_event_access")
    def test_delete_file_success(self, mock_verify):
        """DELETE /api/files/{file_id} should succeed if file exists and access is allowed."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        file_id = "00000000-0000-0000-0000-000000000088"

        # Mock metadata response
        mock_supabase.table.return_value.select.return_value.eq.return_value.single.return_value.execute.return_value.data = {
            "id": file_id,
            "event_id": self.EVENT_ID,
            "storage_path": f"{self.EVENT_ID}/{file_id}/test.csv",
        }

        response = client.delete(f"/api/files/{file_id}")
        assert response.status_code == 200
        assert response.json()["message"] == "File deleted successfully."

    @patch("routers.files.verify_event_access")
    def test_delete_file_not_found(self, mock_verify):
        """DELETE /api/files/{file_id} returns 404 if file does not exist."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        file_id = "00000000-0000-0000-0000-000000000088"

        # Mock metadata response as empty
        mock_supabase.table.return_value.select.return_value.eq.return_value.single.return_value.execute.return_value.data = None

        response = client.delete(f"/api/files/{file_id}")
        assert response.status_code == 404


# ---------------------------------------------------------------------------
# 3. Column mapping — confirmation gate
# ---------------------------------------------------------------------------

class TestColumnMapping:
    FILE_ID = "00000000-0000-0000-0000-000000000088"

    def test_column_mapping_requires_confirmation_true(self):
        """
        POST /api/files/{file_id}/map-columns with confirmed=false must be rejected.

        The ``confirmed`` field is a hard gate: the frontend must set it to
        ``true`` only after a human has reviewed the mapping.
        """
        client = _admin_client()
        payload = {
            "mapping": {"Nom": "last_name", "Prénom": "first_name"},
            "confirmed": False,
        }
        response = client.post(
            f"/api/files/{self.FILE_ID}/map-columns",
            json=payload,
        )
        # Pydantic validator raises 422 when confirmed is False
        assert response.status_code in (400, 422), (
            f"Expected 400 or 422, got {response.status_code}: {response.text}"
        )

    def test_column_mapping_rejects_missing_confirmed_field(self):
        """
        POST /api/files/{file_id}/map-columns without the ``confirmed`` field must return 422.
        """
        client = _admin_client()
        payload = {
            "mapping": {"Nom": "last_name"},
            # 'confirmed' field absent
        }
        response = client.post(
            f"/api/files/{self.FILE_ID}/map-columns",
            json=payload,
        )
        assert response.status_code == 422

    def test_column_mapping_schema_validates_confirmed_false(self):
        """
        Unit test: ColumnMappingRequest Pydantic model should raise ValueError for confirmed=False.
        """
        from models.schemas import ColumnMappingRequest
        import pydantic

        with pytest.raises((pydantic.ValidationError, ValueError)):
            ColumnMappingRequest(
                mapping={"A": "last_name"},
                confirmed=False,
            )

    def test_column_mapping_schema_accepts_confirmed_true(self):
        """
        Unit test: ColumnMappingRequest should succeed with confirmed=True.
        """
        from models.schemas import ColumnMappingRequest

        req = ColumnMappingRequest(
            mapping={"Nom": "last_name", "Prénom": "first_name"},
            confirmed=True,
        )
        assert req.confirmed is True
        assert req.mapping["Nom"] == "last_name"


# ---------------------------------------------------------------------------
# 4. Participant access — dietary field restriction
# ---------------------------------------------------------------------------

class TestParticipantDietaryRestriction:
    def test_dietary_stripped_from_schemas_for_viewer(self):
        """
        Unit test: ParticipantResponse for a viewer role should have dietary=None
        after the router strips it (simulated by the _strip_dietary helper).
        """
        from routers.participants import _strip_dietary

        participant = {
            "id": "00000000-0000-0000-0000-000000000001",
            "dietary_requirements": "Halal",
            "first_name": "Alice",
            "last_name": "Martin",
        }
        stripped = _strip_dietary(participant, "viewer")
        assert stripped.get("dietary_requirements") is None

    def test_dietary_retained_for_admin(self):
        """
        Unit test: Admin role should retain the dietary_requirements field.
        """
        from routers.participants import _strip_dietary

        participant = {
            "id": "00000000-0000-0000-0000-000000000001",
            "dietary_requirements": "Vegan",
        }
        retained = _strip_dietary(participant, "admin")
        assert retained.get("dietary_requirements") == "Vegan"

    def test_dietary_retained_for_pm(self):
        """
        Unit test: PM role should retain the dietary_requirements field.
        """
        from routers.participants import _strip_dietary

        participant = {"dietary_requirements": "Gluten-free"}
        retained = _strip_dietary(participant, "pm")
        assert retained.get("dietary_requirements") == "Gluten-free"

    def test_dietary_stripped_for_client(self):
        """Client role should NOT see dietary_requirements."""
        from routers.participants import _strip_dietary

        participant = {"dietary_requirements": "Kosher"}
        stripped = _strip_dietary(participant, "client")
        assert stripped.get("dietary_requirements") is None


class TestParticipantFieldAllowlist:
    """PATCH /participants/{id} and POST .../lock/{field} used to take an
    IMMUTABLE_FIELDS BLOCKLIST (only id/event_id/created_at/updated_at/
    registration_source_id/fcm_source_id refused) -- every OTHER column,
    including engine-managed ones (completeness_status, locked_fields,
    has_flight/has_hotel/has_transfer/has_activities, verification_note),
    was writable by any user with write access to the event. A client-role
    "editor" could e.g. lock dietary_requirements against future re-imports
    with a value never actually reviewed, or fake has_flight/has_hotel for
    reporting. Fixed by flipping to an ALLOWLIST matching exactly what the
    participant edit form exposes (apps/web EDITABLE_FIELDS)."""

    def test_engine_managed_fields_not_in_allowlist(self):
        from routers.participants import CLIENT_EDITABLE_FIELDS
        for field in ("completeness_status", "locked_fields", "has_flight",
                      "has_hotel", "has_transfer", "has_activities",
                      "verification_note", "id", "event_id"):
            assert field not in CLIENT_EDITABLE_FIELDS, field

    def test_allowlist_matches_frontend_editable_fields(self):
        from routers.participants import CLIENT_EDITABLE_FIELDS
        # apps/web/.../participants/[participantId]/page.tsx EDITABLE_FIELDS
        frontend_fields = {"first_name", "last_name", "email", "company", "phone", "nationality", "dietary_requirements"}
        assert CLIENT_EDITABLE_FIELDS == frontend_fields

    @patch("routers.participants.verify_event_access")
    def test_patch_rejects_engine_managed_field(self, mock_verify):
        mock_verify.return_value = None
        client = _admin_client()
        mock_supabase = MagicMock()
        mock_supabase.table.return_value.select.return_value.eq.return_value.single.return_value.execute.return_value.data = {
            "id": "p1", "event_id": "e1", "completeness_status": "incomplete",
        }
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        response = client.patch(
            "/api/participants/p1",
            json={"field": "completeness_status", "value": "complete", "reason": "test"},
        )
        assert response.status_code == 400

    @patch("routers.participants.verify_event_access")
    def test_lock_rejects_engine_managed_field(self, mock_verify):
        mock_verify.return_value = None
        client = _admin_client()
        mock_supabase = MagicMock()
        mock_supabase.table.return_value.select.return_value.eq.return_value.single.return_value.execute.return_value.data = {
            "id": "p1", "event_id": "e1", "locked_fields": {},
        }
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        response = client.post("/api/participants/p1/lock/has_flight")
        assert response.status_code == 400


class TestParticipantListPhoneField:
    """2026-07-28: the participants list table renders a Téléphone column
    (apps/web/.../participants/page.tsx renders p.phone), but
    PARTICIPANT_LIST_SELECT and ParticipantListItem never included phone --
    a phone number saved correctly (visible on the detail fiche, which uses
    PARTICIPANT_FULL_SELECT) still showed as "—" in the list because the
    list query never fetched it and the response model would have stripped
    it out even if it had."""

    def test_phone_is_selected_in_list_query(self):
        from routers.participants import PARTICIPANT_LIST_SELECT
        columns = [c.strip() for c in PARTICIPANT_LIST_SELECT.split(",")]
        assert "phone" in columns

    def test_phone_is_a_list_item_field(self):
        from models.schemas import ParticipantListItem
        assert "phone" in ParticipantListItem.model_fields


class TestEmailAgentAccessControl:
    """The Email Agent router had NO ownership check at all (2026-07-21 audit):
    any authenticated user, any org, could list another org's email
    proposals (sender addresses, message bodies, proposed dietary_requirements
    changes) and apply/reject them, writing to a participant they don't own.
    These tests prove verify_event_access is actually wired in and rejects a
    cross-org event with 404, matching the pattern used by every other
    endpoint in this codebase (see dependencies.verify_event_access)."""

    FOREIGN_EVENT_ID = "00000000-0000-0000-0000-0000000000ff"
    PROPOSAL_ID = "00000000-0000-0000-0000-000000000123"

    def _client_with_org_mismatch(self):
        """A supabase mock whose events lookup finds nothing -- simulates the
        event belonging to a DIFFERENT org than current_user.org_id, which is
        exactly what verify_event_access's real query filters on
        (.eq("projects.org_id", org_id)). No proposal-specific behaviour is
        stubbed: reaching this table at all proves the org check ran first."""
        client = _admin_client()
        mock_supabase = MagicMock()
        events_mock = MagicMock()
        events_mock.select.return_value.eq.return_value.eq.return_value.single.return_value.execute.side_effect = Exception("no row")
        mock_supabase.table.side_effect = lambda name: events_mock if name == "events" else MagicMock()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        return client

    def test_list_proposals_rejects_foreign_org_event(self):
        client = self._client_with_org_mismatch()
        response = client.get(f"/api/events/{self.FOREIGN_EVENT_ID}/email-agent")
        assert response.status_code == 404

    def test_analyze_rejects_foreign_org_event(self):
        client = self._client_with_org_mismatch()
        response = client.post(
            f"/api/events/{self.FOREIGN_EVENT_ID}/email-agent/analyze",
            json={"sender": "x@y.com", "subject": "s", "body": "b"},
        )
        assert response.status_code == 404

    @patch("routers.email_agent.EmailAgentService.get_proposal")
    def test_apply_rejects_proposal_from_foreign_org_event(self, mock_get_proposal):
        mock_get_proposal.return_value = {
            "id": self.PROPOSAL_ID, "event_id": self.FOREIGN_EVENT_ID,
            "status": "pending", "participant_id": "p1", "proposed_changes": {"phone": "+1"},
        }
        client = self._client_with_org_mismatch()
        response = client.post(f"/api/email-agent/{self.PROPOSAL_ID}/apply")
        assert response.status_code == 404

    @patch("routers.email_agent.EmailAgentService.get_proposal")
    def test_reject_rejects_proposal_from_foreign_org_event(self, mock_get_proposal):
        mock_get_proposal.return_value = {
            "id": self.PROPOSAL_ID, "event_id": self.FOREIGN_EVENT_ID, "status": "pending",
        }
        client = self._client_with_org_mismatch()
        response = client.post(f"/api/email-agent/{self.PROPOSAL_ID}/reject")
        assert response.status_code == 404

    @patch("routers.email_agent.EmailAgentService.get_proposal")
    def test_apply_404s_when_proposal_does_not_exist(self, mock_get_proposal):
        mock_get_proposal.return_value = None
        client = _admin_client()
        client.app.dependency_overrides[get_supabase_client] = lambda: _mock_supabase()
        response = client.post(f"/api/email-agent/{self.PROPOSAL_ID}/apply")
        assert response.status_code == 404


class TestDeleteFileConcurrencyGuard:
    """DELETE /files/{id} used to have no guard against a concurrent
    consolidation run on the same event: deletion snapshots the file's
    source_record ids up front, deletes exactly those, then deletes the
    uploaded_files row -- but a concurrent consolidation re-parses this same
    file mid-run and inserts FRESH source_records for it, which survive the
    cleanup and are then permanently orphaned once the parent uploaded_files
    row is gone. Fixed by reusing the same is_consolidation_running() guard
    trigger_consolidation already uses to reject an overlapping run."""

    FILE_ID = "00000000-0000-0000-0000-000000000077"

    def _mocked_client(self, running_data):
        mock_supabase = MagicMock()
        files_mock = MagicMock()
        files_mock.select.return_value.eq.return_value.single.return_value.execute.return_value.data = {
            "id": self.FILE_ID, "event_id": "e1", "storage_path": "e1/f1/x.xlsx",
        }
        runs_mock = MagicMock()
        runs_mock.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = running_data

        def table_side_effect(name):
            if name == "uploaded_files":
                return files_mock
            if name == "consolidation_runs":
                return runs_mock
            return MagicMock()

        mock_supabase.table.side_effect = table_side_effect
        return mock_supabase

    @patch("routers.files.verify_event_access")
    def test_delete_rejected_while_consolidation_running(self, mock_verify):
        from datetime import datetime, timezone
        mock_verify.return_value = None
        client = _admin_client()
        recent = datetime.now(timezone.utc).isoformat()
        mock_supabase = self._mocked_client([{"id": "run1", "started_at": recent}])
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        response = client.delete(f"/api/files/{self.FILE_ID}")
        assert response.status_code == 409
        # 2026-08-03: the user hit this and saw only "Erreur lors de la
        # suppression du fichier." — the frontend now shows `detail` verbatim,
        # so this string IS the user-facing message: French, and it must say
        # the block is temporary rather than leaving them stuck.
        detail = response.json()["detail"]
        assert "consolidation est en cours" in detail
        assert "Réessayez" in detail

    @patch("routers.files.deletion_service")
    @patch("routers.files.verify_event_access")
    def test_delete_allowed_when_no_run_in_progress(self, mock_verify, mock_deletion):
        mock_verify.return_value = None
        client = _admin_client()
        mock_supabase = self._mocked_client([])
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        response = client.delete(f"/api/files/{self.FILE_ID}")
        assert response.status_code == 200


class TestConsolidationConcurrencyGuard:
    """POST /consolidate must refuse a second run while one is already in
    flight: the pipeline wipes and rebuilds the event's exceptions (and
    re-links source_records) starting from its very first step, so two
    concurrent runs stomp on each other's writes. This is what emptied a
    real export's Exceptions sheet on 2026-07-20 (a race, not a code bug in
    the export itself) -- see export_service.py's exceptions query fix."""

    EVENT_ID = "00000000-0000-0000-0000-000000000001"

    def _mocked_client(self, uploaded_files_data, runs_select_data, runs_insert_data=None):
        mock_supabase = MagicMock()
        uploaded_files_mock = MagicMock()
        uploaded_files_mock.select.return_value.eq.return_value.in_.return_value.execute.return_value.data = uploaded_files_data
        runs_mock = MagicMock()
        runs_mock.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = runs_select_data
        if runs_insert_data is not None:
            runs_mock.insert.return_value.execute.return_value.data = runs_insert_data

        def table_side_effect(name):
            if name == "uploaded_files":
                return uploaded_files_mock
            if name == "consolidation_runs":
                return runs_mock
            return MagicMock()

        mock_supabase.table.side_effect = table_side_effect
        return mock_supabase

    @patch("routers.consolidation.verify_event_access")
    def test_rejects_when_run_already_in_progress(self, mock_verify):
        from datetime import datetime, timezone
        mock_verify.return_value = None
        client = _admin_client()
        recent = datetime.now(timezone.utc).isoformat()
        mock_supabase = self._mocked_client(
            uploaded_files_data=[{"id": "f1"}],
            runs_select_data=[{"id": "run1", "started_at": recent}],
        )
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        response = client.post(f"/api/events/{self.EVENT_ID}/consolidate")
        assert response.status_code == 409

    @patch("routers.consolidation.verify_event_access")
    def test_conflict_detail_is_actionable_french(self, mock_verify):
        """2026-08-03: the user hit this 409 (validating a mapping
        auto-starts a run) and the UI showed 'Vérifiez la connexion API' --
        the API's explanation never reached them. The frontend now surfaces
        `detail` verbatim, so this string IS the user-facing message: it must
        be French and say what to do, not just what went wrong."""
        from datetime import datetime, timezone
        mock_verify.return_value = None
        client = _admin_client()
        mock_supabase = self._mocked_client(
            uploaded_files_data=[{"id": "f1"}],
            runs_select_data=[{"id": "run1", "started_at": datetime.now(timezone.utc).isoformat()}],
        )
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        detail = client.post(f"/api/events/{self.EVENT_ID}/consolidate").json()["detail"]
        assert "déjà en cours" in detail
        assert "Patientez" in detail

    @patch("routers.consolidation.verify_event_access")
    def test_no_mapped_files_detail_is_actionable_french(self, mock_verify):
        mock_verify.return_value = None
        client = _admin_client()
        mock_supabase = self._mocked_client(uploaded_files_data=[], runs_select_data=[])
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        response = client.post(f"/api/events/{self.EVENT_ID}/consolidate")
        assert response.status_code == 422
        detail = response.json()["detail"]
        assert "Aucun fichier" in detail
        assert "mapping" in detail

    @patch("routers.consolidation.verify_event_access")
    def test_allows_when_no_run_in_progress(self, mock_verify):
        from datetime import datetime, timezone
        mock_verify.return_value = None
        client = _admin_client()
        mock_supabase = self._mocked_client(
            uploaded_files_data=[{"id": "f1"}],
            runs_select_data=[],
            runs_insert_data=[{
                "id": "00000000-0000-0000-0000-000000000099",
                "event_id": self.EVENT_ID,
                "triggered_by": MOCK_ADMIN_USER["id"],
                "status": "running",
                "stats": None,
                "started_at": datetime.now(timezone.utc).isoformat(),
                "completed_at": None,
            }],
        )
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        response = client.post(f"/api/events/{self.EVENT_ID}/consolidate")
        assert response.status_code == 202

    @patch("routers.consolidation.verify_event_access")
    def test_allows_when_previous_run_is_stale(self, mock_verify):
        """A 'running' row older than the staleness window (a hard-crashed
        process that never reached the pipeline's own try/except 'failed'
        handler) must not permanently lock the event out of consolidation."""
        from datetime import datetime, timezone, timedelta
        mock_verify.return_value = None
        client = _admin_client()
        stale = (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()
        mock_supabase = self._mocked_client(
            uploaded_files_data=[{"id": "f1"}],
            runs_select_data=[{"id": "run_old", "started_at": stale}],
            runs_insert_data=[{
                "id": "00000000-0000-0000-0000-000000000099",
                "event_id": self.EVENT_ID,
                "triggered_by": MOCK_ADMIN_USER["id"],
                "status": "running",
                "stats": None,
                "started_at": datetime.now(timezone.utc).isoformat(),
                "completed_at": None,
            }],
        )
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        response = client.post(f"/api/events/{self.EVENT_ID}/consolidate")
        assert response.status_code == 202


class TestMatchCandidateResolveRace:
    """PUT /match-candidates/{id} used to check status != "resolved", run the
    merge, and only THEN write status="resolved" -- a plain read-then-write
    with no atomicity. Two concurrent requests for the same candidate_id
    (double-click "confirmer la fusion") could both pass the check and both
    proceed: the second one merges against rows the first already
    repointed/deleted, silently no-ops, but still logs a misleading "merge"
    change_log entry and re-marks an already-resolved candidate. Fixed by
    atomically claiming the candidate (UPDATE ... WHERE status='pending')
    BEFORE merging, with a revert-to-pending on merge failure so a genuine
    single-request failure can still be retried."""

    CANDIDATE_ID = "cand-1"

    def _mock_supabase(self, claim_data, cand_row):
        mock_supabase = MagicMock()
        candidates_mock = MagicMock()
        candidates_mock.select.return_value.eq.return_value.single.return_value.execute.return_value.data = cand_row
        candidates_mock.update.return_value.eq.return_value.eq.return_value.execute.return_value.data = claim_data
        # The revert path only chains a single .eq(), not .eq().eq() -- a
        # distinct attribute path on the same mock tree, configured separately.
        candidates_mock.update.return_value.eq.return_value.execute.return_value.data = claim_data

        participants_mock = MagicMock()

        def table_side_effect(name):
            if name == "match_candidates":
                return candidates_mock
            if name == "participants":
                return participants_mock
            return MagicMock()

        mock_supabase.table.side_effect = table_side_effect
        return mock_supabase, candidates_mock

    @patch("routers.matching.verify_event_access")
    def test_second_concurrent_resolve_is_rejected(self, mock_verify):
        """Simulates the race directly: the claim's conditional UPDATE
        (.eq("status", "pending")) matches zero rows because a first request
        already flipped status to "resolved" -- the loser must 409, not
        proceed to merge."""
        mock_verify.return_value = None
        client = _admin_client()
        cand_row = {
            "id": self.CANDIDATE_ID, "event_id": "e1", "status": "pending",
            "participant_a_id": "loser", "participant_b_id": "winner",
        }
        mock_supabase, candidates_mock = self._mock_supabase(claim_data=[], cand_row=cand_row)
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        response = client.put(f"/api/match-candidates/{self.CANDIDATE_ID}", json={"decision": "fusionner"})
        assert response.status_code == 409

    @patch("routers.matching.consolidation_service._merge_participant_into")
    @patch("routers.matching.verify_event_access")
    def test_failed_merge_reverts_claim_to_pending(self, mock_verify, mock_merge):
        """A genuine (non-race) merge failure must revert the atomic claim
        so the candidate can still be retried, not get permanently stuck
        "resolved" with no merge having actually happened."""
        mock_verify.return_value = None
        mock_merge.return_value = False
        client = _admin_client()
        cand_row = {
            "id": self.CANDIDATE_ID, "event_id": "e1", "status": "pending",
            "participant_a_id": "loser", "participant_b_id": "winner",
        }
        mock_supabase, candidates_mock = self._mock_supabase(claim_data=[{"id": self.CANDIDATE_ID}], cand_row=cand_row)
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        response = client.put(f"/api/match-candidates/{self.CANDIDATE_ID}", json={"decision": "fusionner"})
        assert response.status_code == 500
        # Two update() calls on match_candidates: the initial claim, then the revert.
        assert candidates_mock.update.call_count == 2
        revert_payload = candidates_mock.update.call_args_list[1].args[0]
        assert revert_payload["status"] == "pending"


# ---------------------------------------------------------------------------
# 5. Matching engine unit tests
# ---------------------------------------------------------------------------

class TestMatchingEngine:
    """Unit tests for the consolidation matching engine (no Supabase needed)."""

    def _reg(self, first: str, last: str, email: str, source_id: str = "reg-1") -> Any:
        from services.consolidation_service import ParticipantRecord
        return ParticipantRecord(source_id, {
            "first_name": first, "last_name": last, "email": email
        })

    def _fcm(self, first: str, last: str, email: str, source_id: str = "fcm-1") -> Any:
        from services.consolidation_service import ParticipantRecord
        return ParticipantRecord(source_id, {
            "first_name": first, "last_name": last, "email": email
        })

    def test_exact_email_match_is_certain(self):
        """Matching FCM → registration via exact email should be CERTAIN."""
        from services.consolidation_service import match_sources

        reg  = self._reg("Alice", "Martin", "alice@example.com", "reg-1")
        fcm  = self._fcm("Alice", "Martin", "alice@example.com", "fcm-1")
        results = match_sources([reg], [fcm])

        assert len(results) == 1
        assert results[0].decision == "certain"
        assert results[0].score == 100.0

    def test_name_match_without_email_is_probable(self):
        """
        High name similarity without email should be at least PROBABLE.
        (Score ≥ 75 but < 95 threshold when no email available on FCM side.)
        """
        from services.consolidation_service import match_sources

        reg  = self._reg("Alice", "Martin", "alice@example.com", "reg-1")
        fcm  = self._fcm("Alice", "Martin", "",                 "fcm-1")  # no email in FCM
        results = match_sources([reg], [fcm])

        assert len(results) == 1
        assert results[0].decision in ("certain", "probable")

    def test_no_match_returns_not_found(self):
        """Completely different names without email overlap → NOT_FOUND."""
        from services.consolidation_service import match_sources

        reg  = self._reg("Alice", "Martin", "alice@example.com", "reg-1")
        fcm  = self._fcm("Zoltan", "Kovacs", "zoltan@example.com", "fcm-1")
        results = match_sources([reg], [fcm])

        assert len(results) == 1
        assert results[0].decision in ("not_found", "to_verify")

    def test_merge_skips_locked_fields(self):
        """
        merge_participant_fields must not overwrite fields that are locked.
        """
        from services.consolidation_service import merge_participant_fields

        existing = {"id": "p1", "first_name": "Alice", "company": "OriginalCo"}
        new_data  = {"first_name": "Alyce",  "company": "NewCo"}
        locked    = {"company": True}  # company is locked

        merged = merge_participant_fields(existing, new_data, locked)
        # company must not be overwritten
        assert merged["company"] == "OriginalCo"
        # first_name (not locked) should be updated
        assert merged["first_name"] == "Alyce"

    def test_merge_does_not_overwrite_with_empty(self):
        """
        merge_participant_fields must not overwrite a value with None or empty string.
        """
        from services.consolidation_service import merge_participant_fields

        existing = {"company": "ExistingCo", "phone": "+32 2 000 0000"}
        new_data  = {"company": None, "phone": ""}
        locked    = {}

        merged = merge_participant_fields(existing, new_data, locked)
        assert merged["company"] == "ExistingCo"
        assert merged["phone"] == "+32 2 000 0000"

    def test_exact_score_tie_is_broken_by_list_order_not_by_any_other_signal(self):
        """2026-07-21/22 audit (PROP-002): documents the CURRENT tie-break
        behaviour of match_sources -- when two registration records score
        identically against one FCM record, the first one encountered in
        `registrations` wins (`if name_score > best_score`, strict >).
        This is deterministic GIVEN a fixed list order, but the caller in
        run_consolidation builds that list from `.select().in_(chunk)` after
        an `.upsert()` -- neither guarantees the DB returns rows in input
        order, so the same real-world tie could resolve to a different
        winner across separate consolidation runs of identical source data.
        This test pins today's behaviour (order-dependent) so a future fix
        for the ordering bug is provable, and so any change to the
        tie-break rule itself is a deliberate, visible diff."""
        from services.consolidation_service import match_sources

        fcm = self._fcm("Marie", "Laurent", "", "fcm-1")
        reg_a = self._reg("Marie", "Laurent", "", "reg-a")  # identical name, no email either side
        reg_b = self._reg("Marie", "Laurent", "", "reg-b")

        results_ab = match_sources([reg_a, reg_b], [fcm])
        results_ba = match_sources([reg_b, reg_a], [fcm])

        assert results_ab[0].score == results_ba[0].score == 100.0  # genuine tie
        assert results_ab[0].reg_record.source_record_id == "reg-a"
        assert results_ba[0].reg_record.source_record_id == "reg-b"
        # Same two people, same tie score, opposite input order -> opposite
        # winner. Proves the outcome depends on list order, not on any
        # property of the data itself.


class TestSafeStorageFilename:
    """A client-controlled upload filename becomes a Supabase Storage path
    segment (routers/files.py create_upload). Path-traversal or control
    characters must never reach it, even though the {event_id}/{file_id}/
    prefix is always server-generated."""

    def test_path_traversal_stripped(self):
        from routers.files import _safe_storage_filename
        assert ".." not in _safe_storage_filename("../../../etc/passwd")
        assert "/" not in _safe_storage_filename("../../other-event/x.xlsx")

    def test_bare_dot_dot_rejected(self):
        """A bare ".." has no separator for os.path.basename to strip and
        survives it unchanged -- still a real traversal segment once joined
        into storage_path ("{event_id}/{file_id}/.." resolves upward)."""
        from routers.files import _safe_storage_filename
        assert _safe_storage_filename("..") == "upload"
        assert _safe_storage_filename(".") == "upload"
        assert _safe_storage_filename("...") == "upload"

    def test_backslash_traversal_stripped(self):
        from routers.files import _safe_storage_filename
        result = _safe_storage_filename("..\\..\\windows\\system32\\x.xlsx")
        assert "\\" not in result and "/" not in result

    def test_normal_filename_mostly_preserved(self):
        from routers.files import _safe_storage_filename
        assert _safe_storage_filename("Participants Q3.xlsx") == "Participants_Q3.xlsx"

    def test_empty_filename_falls_back(self):
        from routers.files import _safe_storage_filename
        assert _safe_storage_filename("") == "upload"

    def test_original_filename_field_left_untouched(self):
        """original_filename (DB field, shown in UI, used for extension
        detection on re-download) must stay the user's real name -- only the
        STORAGE PATH segment is sanitised."""
        import inspect
        from routers import files
        src = inspect.getsource(files)
        assert '"original_filename": filename' in src
        assert "original_filename=filename" in src


class TestMailConnectionWriteCheck:
    """routers/mail_connection.py had `str(event_id, write=True)` -- write=True
    landed inside str()'s call, not verify_event_access's, which raises
    TypeError before the access check ever runs. POST .../mail/sync and
    .../mail/disconnect always 500'd (fails closed, but the intended
    write-access check never executed). Fixed by moving write=True onto
    verify_event_access itself."""

    EVENT_ID = "00000000-0000-0000-0000-000000000001"

    @patch("routers.mail_connection.verify_event_access")
    @patch("routers.mail_connection.mail")
    def test_sync_no_longer_raises_typeerror(self, mock_mail, mock_verify):
        from unittest.mock import AsyncMock
        mock_verify.return_value = {"id": self.EVENT_ID}
        mock_mail.sync_inbox = AsyncMock(return_value={"synced": 0})
        client = _admin_client()
        response = client.post(f"/api/events/{self.EVENT_ID}/mail/sync?provider=gmail")
        assert response.status_code == 200
        # write=True must reach verify_event_access, not str()
        _, kwargs = mock_verify.call_args
        assert kwargs.get("write") is True

    @patch("routers.mail_connection.verify_event_access")
    @patch("routers.mail_connection.mail")
    def test_disconnect_no_longer_raises_typeerror(self, mock_mail, mock_verify):
        mock_verify.return_value = {"id": self.EVENT_ID}
        mock_mail.disconnect = MagicMock()
        client = _admin_client()
        response = client.post(f"/api/events/{self.EVENT_ID}/mail/disconnect?provider=gmail")
        assert response.status_code == 200
        _, kwargs = mock_verify.call_args
        assert kwargs.get("write") is True


class TestFormulaInjectionNoVisibleArtifact:
    """The Excel/CSV formula-injection guard (CWE-1236) went through TWO
    versions. v1 prefixed any string starting with =/+/-/@ with an
    apostrophe. Caught before push: verified via raw OOXML inspection that
    openpyxl writes NO quotePrefix attribute, so that apostrophe becomes a
    LITERAL, VISIBLE character in the exported file -- every phone number
    ("+33...") would show up as "'+33..." in the master list, a core MVP
    deliverable. v2 (this one) root-caused the ACTUAL mechanism: only "="
    gets auto-promoted by openpyxl to a real <f> formula element Excel
    evaluates on open; +/-/@ already stay a plain string (data_type='s'),
    which Excel never re-parses as a formula because OOXML cell types are
    explicit metadata (unlike raw CSV). _neutralize_formula forces
    data_type back to 's' only when openpyxl actually set it to 'f',
    preserving the value byte-for-byte."""

    def test_formula_neutralised_no_live_formula(self):
        from services.export_service import _neutralize_formula
        from openpyxl import Workbook
        ws = Workbook().active
        cell = _neutralize_formula(ws.cell(row=1, column=1, value="=cmd|'/c calc'!A1"))
        assert cell.data_type == "s"
        assert cell.value == "=cmd|'/c calc'!A1"

    def test_ordinary_plus_minus_at_values_completely_unchanged(self):
        """The regression this test exists to prevent: MUST show exactly
        as typed, no apostrophe, no artifact of any kind."""
        from services.export_service import _neutralize_formula
        from openpyxl import Workbook
        ws = Workbook().active
        for v in ("+33612345678", "-5", "@handle", "Jean-Paul"):
            cell = _neutralize_formula(ws.cell(row=1, column=1, value=v))
            assert cell.value == v, f"value mutated: {cell.value!r} != {v!r}"
            assert cell.data_type == "s"

    def test_master_list_phone_column_shows_exact_value(self):
        from services.export_service import _build_master_list_sheet
        from openpyxl import Workbook
        ws = Workbook().active
        row = {
            "id": "p1", "last_name": "Dupont", "first_name": "Marie",
            "phone": "+33612345678", "completeness_status": "complete",
        }
        _build_master_list_sheet(ws, [row], set())
        data_row = [c.value for c in ws[2]]
        assert data_row[4] == "+33612345678"  # Phone column

    def test_malicious_formula_neutralised_end_to_end(self):
        from services.export_service import _build_master_list_sheet
        from openpyxl import Workbook
        ws = Workbook().active
        row = {
            "id": "p1", "last_name": "=cmd|'/c calc'!A1", "first_name": "Jean",
            "completeness_status": "complete",
        }
        _build_master_list_sheet(ws, [row], set())
        assert ws.cell(row=2, column=1).data_type == "s"
        assert ws.cell(row=2, column=1).value == "=cmd|'/c calc'!A1"


class TestExportDietaryRBAC:
    """The export endpoint (routers/exports.py create_export) only called
    verify_event_access with no role check, so ANY role that can read the
    event (including client/viewer) got dietary_requirements and
    food_allergy_info in the generated Excel -- bypassing the RGPD-sensitive
    gate enforced everywhere else (participants.py's _strip_dietary). Fixed
    by threading the caller's role into export_service.generate_excel /
    _build_master_list_sheet, defaulting to the LEAST privileged role so a
    caller that forgets to pass it fails closed."""

    def _rows(self):
        return [{
            "id": "p1", "last_name": "Dupont", "first_name": "Marie",
            "dietary_requirements": "Allergie aux arachides",
            "food_allergy_info": "Anaphylaxie severe",
            "completeness_status": "complete",
        }]

    def _sheet(self, include_dietary):
        """Return {header: value} for the single data row — looked up by header
        NAME, not by position: fixed indices made this test fail the day a
        column was inserted earlier in the sheet, which says nothing about the
        RGPD gate it is meant to protect."""
        from services.export_service import _build_master_list_sheet
        from openpyxl import Workbook
        ws = Workbook().active
        _build_master_list_sheet(ws, self._rows(), set(), include_dietary=include_dietary)
        headers = [c.value for c in ws[1]]
        return dict(zip(headers, [c.value for c in ws[2]]))

    def test_dietary_included_for_admin(self):
        row = self._sheet(include_dietary=True)
        assert row["Régime Alimentaire"] == "Allergie aux arachides"
        assert row["Allergies / Alimentation"] == "Anaphylaxie severe"

    def test_dietary_stripped_for_non_privileged_role(self):
        row = self._sheet(include_dietary=False)
        assert row["Régime Alimentaire"] is None
        assert row["Allergies / Alimentation"] is None
        # Only the sensitive columns are affected -- everything else survives.
        assert row["Nom"] == "Dupont"
        assert row["Prénom"] == "Marie"

    def test_health_info_follows_the_same_gate(self):
        """"Epilepsy, DTD or OSA?" is health data — at least as sensitive as
        the food columns, so it must never ship to a client/viewer export."""
        rows = self._rows()
        rows[0]["medical_info"] = "Epilepsy"
        from services.export_service import _build_master_list_sheet
        from openpyxl import Workbook

        def _val(include):
            ws = Workbook().active
            _build_master_list_sheet(ws, rows, set(), include_dietary=include)
            headers = [c.value for c in ws[1]]
            return dict(zip(headers, [c.value for c in ws[2]]))["Info Médicale"]

        assert _val(True) == "Epilepsy"
        assert _val(False) is None

    def test_generate_excel_defaults_to_least_privileged_role(self):
        """A caller that forgets to pass `role=` must fail CLOSED (dietary
        stripped), not open -- a permission parameter defaulting to full
        access is exactly the bug class this test guards against."""
        import inspect
        from services.export_service import generate_excel
        role_param = inspect.signature(generate_excel).parameters["role"]
        assert role_param.default not in ("admin", "pm")

    def _changes(self):
        return [
            {"changed_at": "2026-07-21T00:00:00Z", "user_id": "u1", "entity_type": "participant",
             "entity_id": "p1", "field_name": "dietary_requirements",
             "old_value": "", "new_value": "Halal", "change_reason": "manual"},
            {"changed_at": "2026-07-21T00:01:00Z", "user_id": "u1", "entity_type": "participant",
             "entity_id": "p1", "field_name": "phone",
             "old_value": "", "new_value": "+33612345678", "change_reason": "manual"},
        ]

    def test_change_log_dietary_redacted_for_non_privileged_role(self):
        """The Master List sheet strips the CURRENT dietary value for
        non-admin/pm, but every HISTORICAL edit to that field was still
        written verbatim to the Change Log sheet regardless of role --
        the same RGPD-sensitive value leaking through the audit trail."""
        from services.export_service import _build_change_log_sheet
        from openpyxl import Workbook
        ws = Workbook().active
        _build_change_log_sheet(ws, self._changes(), include_dietary=False)
        dietary_row = [c.value for c in ws[2]]
        phone_row = [c.value for c in ws[3]]
        assert dietary_row[5] is None and dietary_row[6] is None  # old/new value
        assert dietary_row[4] == "dietary_requirements"  # field name itself still shown
        # untouched by the DIETARY redaction, and exactly as-typed: the
        # formula-injection guard neutralises "="-leading VALUES at the
        # cell-type level (see _neutralize_formula), it never mutates the
        # visible content, so a phone number is never shown with an
        # artifact prefix.
        assert phone_row[5] == "" and phone_row[6] == "+33612345678"

    def test_change_log_dietary_included_for_admin(self):
        from services.export_service import _build_change_log_sheet
        from openpyxl import Workbook
        ws = Workbook().active
        _build_change_log_sheet(ws, self._changes(), include_dietary=True)
        dietary_row = [c.value for c in ws[2]]
        assert dietary_row[6] == "Halal"


class TestExportDownloadRoleRedaction:
    """The dietary RBAC fix (commit 27a7c76) only gated export GENERATION:
    create_export threaded role into generate_excel, but download_export
    only checked verify_event_access (read-level, no role condition) before
    minting a signed URL for the ORIGINAL stored file. A viewer/client could
    still download an admin-generated export and get the raw dietary
    columns baked into that file -- see 2026-07-21 audit finding #1. Fixed
    by regenerating a role-appropriate copy at download time for any
    non-admin/pm role instead of serving the original."""

    EXPORT_ID = "00000000-0000-0000-0000-000000000042"

    def _mock_supabase_for_export(self, export_row):
        mock_supabase = MagicMock()
        exports_mock = MagicMock()
        exports_mock.select.return_value.eq.return_value.single.return_value.execute.return_value.data = export_row

        def table_side_effect(name):
            if name == "exports":
                return exports_mock
            return MagicMock()

        mock_supabase.table.side_effect = table_side_effect
        mock_supabase.storage.from_.return_value.create_signed_url.return_value = {"signedURL": "https://signed.example/x"}
        mock_supabase.storage.from_.return_value.upload.return_value = None
        return mock_supabase

    @patch("routers.exports.verify_event_access")
    @patch("routers.exports.export_service.generate_excel")
    def test_admin_download_serves_original_no_regeneration(self, mock_generate, mock_verify):
        mock_verify.return_value = None
        export_row = {
            "id": self.EXPORT_ID, "event_id": "e1", "run_id": "r1",
            "storage_path": "exports/e1/orig/file.xlsx", "filename": "file.xlsx", "created_by": "u1",
        }
        mock_supabase = self._mock_supabase_for_export(export_row)
        client = _admin_client()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        response = client.get(f"/api/exports/{self.EXPORT_ID}/download")
        assert response.status_code == 200
        mock_generate.assert_not_called()
        called_path = mock_supabase.storage.from_.return_value.create_signed_url.call_args.kwargs["path"]
        assert called_path == "exports/e1/orig/file.xlsx"

    @patch("routers.exports.verify_event_access")
    @patch("routers.exports.export_service.generate_excel")
    def test_viewer_download_regenerates_redacted_copy(self, mock_generate, mock_verify):
        mock_verify.return_value = None
        mock_generate.return_value = b"fake-redacted-bytes"
        export_row = {
            "id": self.EXPORT_ID, "event_id": "e1", "run_id": "r1",
            "storage_path": "exports/e1/orig/file.xlsx", "filename": "file.xlsx", "created_by": "u1",
        }
        mock_supabase = self._mock_supabase_for_export(export_row)
        client = _viewer_client()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        response = client.get(f"/api/exports/{self.EXPORT_ID}/download")
        assert response.status_code == 200
        mock_generate.assert_called_once()
        # regenerated with the DOWNLOADING user's role, not the original creator's
        assert mock_generate.call_args.kwargs["role"] == "viewer"
        called_path = mock_supabase.storage.from_.return_value.create_signed_url.call_args.kwargs["path"]
        assert called_path != "exports/e1/orig/file.xlsx"
        assert "redacted-viewer" in called_path


# ---------------------------------------------------------------------------
# 6. Normalisation unit tests
# ---------------------------------------------------------------------------

class TestNormalisation:
    def test_email_lowercased(self):
        """Emails must be lowercased during normalisation."""
        from services.mapping_service import normalise_fields
        result = normalise_fields({"email": "Alice.MARTIN@Example.COM"})
        assert result["email"] == "alice.martin@example.com"

    def test_whitespace_stripped(self):
        """Leading/trailing whitespace must be stripped from all string fields."""
        from services.mapping_service import normalise_fields
        result = normalise_fields({"first_name": "  Alice  ", "last_name": " Martin "})
        assert result["first_name"] == "Alice"
        assert result["last_name"] == "Martin"

    def test_empty_string_becomes_none(self):
        """Empty strings after strip must become None."""
        from services.mapping_service import normalise_fields
        result = normalise_fields({"phone": "   "})
        assert result["phone"] is None

    def test_date_parsed_to_iso8601(self):
        """European date format dd/mm/yyyy must be converted to yyyy-mm-dd."""
        from services.mapping_service import normalise_fields
        result = normalise_fields({"departure_date": "15/06/2025"})
        assert result["departure_date"] == "2025-06-15"

    def test_apply_mapping_drops_unmapped_columns(self):
        """apply_mapping must discard source columns not in the mapping."""
        from services.mapping_service import apply_mapping
        raw = {"Nom": "Martin", "Prénom": "Alice", "Irrelevant": "xyz"}
        mapping = {"Nom": "last_name", "Prénom": "first_name"}
        result = apply_mapping(raw, mapping)
        assert "last_name"  in result
        assert "first_name" in result
        assert "Irrelevant" not in result
        assert "Nom" not in result
        assert "Prénom" not in result


# ---------------------------------------------------------------------------
# 7. Phase 2 integration tests
# ---------------------------------------------------------------------------

class TestFlights:
    @patch("routers.flights.verify_event_access")
    def test_list_flights(self, mock_verify):
        """GET /api/events/{event_id}/flights should return list of flights."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        
        mock_supabase.table.return_value.select.return_value.eq.return_value.execute.return_value.data = [
            {
                "id": "00000000-0000-0000-0000-000000000005",
                "event_id": "00000000-0000-0000-0000-000000000001",
                "flight_number": "SN3715",
                "departure_airport": "BRU",
                "arrival_airport": "BCN",
                "departure_time": "2025-11-10T10:00:00Z",
                "arrival_time": "2025-11-10T12:00:00Z",
                "status": "confirmed",
                "created_at": "2026-07-08T12:00:00Z",
                "participants": {"first_name": "John", "last_name": "Doe"}
            }
        ]
        
        response = client.get("/api/events/00000000-0000-0000-0000-000000000001/flights")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["flight_number"] == "SN3715"
        assert data[0]["participant_name"] == "John Doe"


class TestHotels:
    @patch("routers.hotels.verify_event_access")
    def test_list_hotels(self, mock_verify):
        """GET /api/events/{event_id}/hotels should return list of hotels."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        
        mock_supabase.table.return_value.select.return_value.eq.return_value.execute.return_value.data = [
            {
                "id": "00000000-0000-0000-0000-000000000006",
                "event_id": "00000000-0000-0000-0000-000000000001",
                "name": "Hotel Arts Barcelona",
                "city": "Barcelona",
                "created_at": "2026-07-08T12:00:00Z"
            }
        ]
        
        response = client.get("/api/events/00000000-0000-0000-0000-000000000001/hotels")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["name"] == "Hotel Arts Barcelona"


class TestTransfers:
    @patch("routers.transfers.verify_event_access")
    def test_list_transfers(self, mock_verify):
        """GET /api/events/{event_id}/transfers should return list of transfers."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        
        mock_supabase.table.return_value.select.return_value.eq.return_value.execute.return_value.data = [
            {
                "id": "00000000-0000-0000-0000-000000000007",
                "event_id": "00000000-0000-0000-0000-000000000001",
                "participant_id": "00000000-0000-0000-0000-000000000002",
                "transfer_type": "arrival",
                "pickup_location": "BCN Airport T1",
                "dropoff_location": "Hotel Arts BCN",
                "pickup_time": "2025-11-10T12:30:00Z",
                "status": "scheduled",
                "created_at": "2026-07-08T12:00:00Z",
                "participants": {"first_name": "Jane", "last_name": "Smith"},
                "flights": {"flight_number": "SN3715"}
            }
        ]
        
        response = client.get("/api/events/00000000-0000-0000-0000-000000000001/transfers")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["pickup_location"] == "BCN Airport T1"
        assert data[0]["participant_name"] == "Jane Smith"
        assert data[0]["flight_number"] == "SN3715"


class TestAutoGroupShuttlesFixes:
    """2026-07-21 audit: the shuttle dispatcher (routers.transfers.auto_group_shuttles)
    had two independent bugs, both confirmed against real production data before
    the fix — see verify_transfer_roundtrip.py in the session scratchpad."""

    EVENT_ID = "00000000-0000-0000-0000-00000000ee01"
    PART_ID = "00000000-0000-0000-0000-00000000ee02"

    def _mocked_client(self, flights_data, transfers_exist_check_data=None):
        mock_supabase = MagicMock()
        flights_mock = MagicMock()
        flights_mock.select.return_value.eq.return_value.execute.return_value.data = flights_data

        transfers_mock = MagicMock()
        # existing_res: no imported (flight_id-less) transfers to preserve
        transfers_mock.select.return_value.eq.return_value.execute.return_value.data = []
        # per-flight "already grouped?" check: nothing exists yet -> insert branch
        transfers_mock.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = (
            transfers_exist_check_data or []
        )
        transfers_mock.insert.return_value.execute.return_value.data = [{"id": "new-transfer"}]

        participants_mock = MagicMock()

        def table_side_effect(name):
            if name == "flights":
                return flights_mock
            if name == "transfers":
                return transfers_mock
            if name == "participants":
                return participants_mock
            return MagicMock()

        mock_supabase.table.side_effect = table_side_effect
        client = _admin_client()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        return client, transfers_mock

    @patch("routers.transfers.verify_event_access")
    def test_return_flight_not_treated_as_arrival(self, mock_verify):
        """A participant with an outbound (Aller) AND return (Retour) flight
        segment must only get ONE computed shuttle, for the outbound arrival.
        Before the fix, every flight row was treated as an event arrival, so
        the return leg's landing (back home, days later) also spawned a
        bogus airport-to-hotel shuttle. Confirmed live: 1,156 such bogus
        transfers already existed in production for one event alone."""
        mock_verify.return_value = None
        outbound = {
            "id": "flight-aller", "participant_id": self.PART_ID,
            "departure_time": "2026-02-05T08:00:00Z", "arrival_time": "2026-02-05T10:00:00Z",
            "flight_number": "SN100",
        }
        retour = {
            "id": "flight-retour", "participant_id": self.PART_ID,
            "departure_time": "2026-02-09T14:00:00Z", "arrival_time": "2026-02-09T16:00:00Z",
            "flight_number": "SN200",
        }
        client, transfers_mock = self._mocked_client([outbound, retour])

        response = client.post(f"/api/events/{self.EVENT_ID}/transfers/group")
        assert response.status_code == 200
        assert transfers_mock.insert.call_count == 1
        inserted_payload = transfers_mock.insert.call_args_list[0][0][0]
        assert inserted_payload["flight_id"] == "flight-aller"

    @patch("routers.transfers.verify_event_access")
    def test_window_grouping_consistent_for_non_divisor_window(self, mock_verify):
        """A 90-minute ('1h30') window must group two arrivals only 20
        minutes apart into the SAME shuttle slot, even when they straddle a
        clock-hour boundary. Before the fix, the rounding reset every clock
        hour regardless of window_minutes, so 09:50 and 10:10 landed a full
        hour apart (10:30 vs 11:30) instead of together — the 90/120-minute
        options silently behaved as plain hourly buckets."""
        mock_verify.return_value = None
        part_a = "00000000-0000-0000-0000-00000000ee03"
        part_b = "00000000-0000-0000-0000-00000000ee04"
        flight_a = {
            "id": "flight-a", "participant_id": part_a,
            "departure_time": "2026-02-05T06:00:00Z", "arrival_time": "2026-02-05T09:50:00Z",
            "flight_number": "SN300",
        }
        flight_b = {
            "id": "flight-b", "participant_id": part_b,
            "departure_time": "2026-02-05T06:20:00Z", "arrival_time": "2026-02-05T10:10:00Z",
            "flight_number": "SN400",
        }
        client, transfers_mock = self._mocked_client([flight_a, flight_b])

        response = client.post(f"/api/events/{self.EVENT_ID}/transfers/group?window_minutes=90")
        assert response.status_code == 200
        assert transfers_mock.insert.call_count == 2
        pickup_by_participant = {
            call[0][0]["participant_id"]: call[0][0]["pickup_time"]
            for call in transfers_mock.insert.call_args_list
        }
        assert pickup_by_participant[part_a] == pickup_by_participant[part_b]


class TestActivities:
    @patch("routers.activities.verify_event_access")
    def test_list_activities(self, mock_verify):
        """GET /api/events/{event_id}/activities should return activities list."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        
        mock_supabase.table.return_value.select.return_value.eq.return_value.execute.return_value.data = [
            {
                "id": "00000000-0000-0000-0000-000000000008",
                "event_id": "00000000-0000-0000-0000-000000000001",
                "name": "Barcelona Gothic Quarter Walk",
                "created_at": "2026-07-08T12:00:00Z"
            }
        ]
        mock_supabase.table.return_value.select.return_value.eq.return_value.eq.return_value.execute.return_value.count = 5
        
        response = client.get("/api/events/00000000-0000-0000-0000-000000000001/activities")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["name"] == "Barcelona Gothic Quarter Walk"
        assert data[0]["registrations_count"] == 5


class TestReports:
    @patch("routers.reports.verify_event_access")
    def test_get_report_summary(self, mock_verify):
        """GET /api/events/{event_id}/reports/summary should return report aggregate counts."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        mock_supabase.table.return_value.select.return_value.eq.return_value.execute.return_value.data = [
            {"id": "p1", "has_flight": True, "has_hotel": False, "has_transfer": True},
            {"id": "p2", "has_flight": False, "has_hotel": True, "has_transfer": False},
        ]

        response = client.get("/api/events/00000000-0000-0000-0000-000000000001/reports/summary")
        assert response.status_code == 200
        data = response.json()
        assert data["total_registered"] == 2
        assert data["missing_flight"] == 1
        assert data["missing_hotel"] == 1
        assert data["missing_transfer"] == 1


class TestGlobalParticipants:
    def test_get_participant_history(self):
        """GET /api/participants/history should return cross-event presence history for a participant."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        mock_supabase.table.return_value.select.return_value.ilike.return_value.eq.return_value.execute.return_value.data = [
            {
                "email": "alice@test.com",
                "first_name": "Alice",
                "last_name": "Martin",
                "dietary_requirements": "Vegetarian",
                "events": {
                    "name": "Barcelona Kick-off 2025",
                    "start_date": "2025-11-10",
                }
            }
        ]

        response = client.get("/api/global-participants/history?email=alice@test.com")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["email"] == "alice@test.com"
        assert data[0]["history"][0]["event_name"] == "Barcelona Kick-off 2025"
        assert data[0]["history"][0]["dietary_requirements"] == "Vegetarian"

    def _participant_rows(self):
        return [
            {
                "email": "alice@test.com", "first_name": "Alice", "last_name": "Martin",
                "dietary_requirements": "Vegetarian",
                "events": {
                    "id": "event-shared", "project_id": "proj-1",
                    "name": "Shared Event", "start_date": "2025-11-10",
                },
            },
            {
                "email": "alice@test.com", "first_name": "Alice", "last_name": "Martin",
                "dietary_requirements": "Vegetarian",
                "events": {
                    "id": "event-not-shared", "project_id": "proj-1",
                    "name": "Not Shared Event", "start_date": "2025-12-01",
                },
            },
        ]

    def _mocked_client(self, membership_data):
        client = _viewer_client()
        mock_supabase = MagicMock()
        participants_mock = MagicMock()
        participants_mock.select.return_value.ilike.return_value.eq.return_value.execute.return_value.data = self._participant_rows()
        members_mock = MagicMock()
        members_mock.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = membership_data

        def table_side_effect(name):
            if name == "participants":
                return participants_mock
            if name == "project_members":
                return members_mock
            return MagicMock()

        mock_supabase.table.side_effect = table_side_effect
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        return client

    def test_dietary_stripped_for_non_staff_role(self):
        """A client/viewer sharing event-shared must not see dietary_requirements
        in cross-event history, even for the event they DO have access to --
        same RGPD gate as participants.py's _strip_dietary."""
        client = self._mocked_client([{"id": "m1", "access_level": "viewer", "event_ids": ["event-shared"]}])
        response = client.get("/api/global-participants/history?email=alice@test.com")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        for entry in data[0]["history"]:
            assert entry["dietary_requirements"] is None

    def test_event_excluded_when_not_shared_with_non_staff(self):
        """A client shared ONLY on event-shared must not see history for
        event-not-shared, even though both belong to the same org/project."""
        client = self._mocked_client([{"id": "m1", "access_level": "viewer", "event_ids": ["event-shared"]}])
        response = client.get("/api/global-participants/history?email=alice@test.com")
        assert response.status_code == 200
        data = response.json()
        event_names = {h["event_name"] for h in data[0]["history"]}
        assert event_names == {"Shared Event"}
        assert "Not Shared Event" not in event_names

    def test_no_membership_excludes_all_events_for_non_staff(self):
        """A non-staff user with no project_members row at all (never shared
        on this project) must see nothing, not the full org history."""
        client = self._mocked_client([])
        response = client.get("/api/global-participants/history?email=alice@test.com")
        assert response.status_code == 200
        assert response.json() == []


class TestEvents:
    @patch("routers.events.require_role")
    def test_create_event(self, mock_role):
        """POST /api/events should insert and return new event."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        mock_supabase.table.return_value.select.return_value.eq.return_value.eq.return_value.single.return_value.execute.return_value.data = {"id": "p1"}
        mock_supabase.table.return_value.insert.return_value.execute.return_value.data = [
            {
                "id": "00000000-0000-0000-0000-000000000003",
                "project_id": "00000000-0000-0000-0000-000000000002",
                "name": "New Blank Event",
                "created_at": "2026-07-09T10:00:00Z",
                "updated_at": "2026-07-09T10:00:00Z",
            }
        ]

        payload = {
            "project_id": "00000000-0000-0000-0000-000000000002",
            "name": "New Blank Event"
        }
        response = client.post("/api/events", json=payload)
        assert response.status_code == 201
        assert response.json()["name"] == "New Blank Event"

    def test_list_events(self):
        """GET /api/events should return list of organization events."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        # The list is ordered (most recently touched first) so signing in never
        # lands on a stale empty event -- the mock has to mirror that chain.
        (mock_supabase.table.return_value.select.return_value.eq.return_value
         .order.return_value.order.return_value.execute.return_value.data) = [
            {
                "id": "00000000-0000-0000-0000-000000000003",
                "project_id": "00000000-0000-0000-0000-000000000002",
                "name": "Event One",
                "created_at": "2026-07-09T10:00:00Z",
                "updated_at": "2026-07-09T10:00:00Z",
            }
        ]

        response = client.get("/api/events")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["name"] == "Event One"


class TestEmailAgentApplyProposalSafety:
    """apply_proposal (services/email_agent_service.py) wrote AI-proposed
    `changes` verbatim -- the prompt's "Allowed fields" list was never
    enforced in code, so a crafted/injected email could get the model to
    propose event_id/locked_fields/id and have them applied. It also had a
    read-then-write TOCTOU race: two concurrent applies for the same
    proposal_id could both pass the pending check before either wrote
    status="applied", doubling every change_log entry."""

    def _proposal(self, changes):
        return {
            "id": "prop-1", "event_id": "e1", "participant_id": "p1",
            "status": "pending", "proposed_changes": changes,
        }

    def _mock_sb(self, claim_data):
        mock_sb = MagicMock()
        proposals_mock = MagicMock()
        proposals_mock.update.return_value.eq.return_value.eq.return_value.execute.return_value.data = claim_data
        participants_mock = MagicMock()
        participants_mock.select.return_value.eq.return_value.execute.return_value.data = [
            {"id": "p1", "locked_fields": [], "first_name": "Old"}
        ]
        change_log_mock = MagicMock()

        def table_side_effect(name):
            if name == "email_proposals":
                return proposals_mock
            if name == "participants":
                return participants_mock
            if name == "change_log":
                return change_log_mock
            return MagicMock()

        mock_sb.table.side_effect = table_side_effect
        return mock_sb, participants_mock, change_log_mock

    @pytest.mark.asyncio
    async def test_disallowed_fields_filtered_before_apply(self):
        from services.email_agent_service import EmailAgentService
        service = EmailAgentService(MagicMock())
        service.get_proposal = AsyncMock(return_value=self._proposal({
            "first_name": "Marie", "event_id": "other-event-id",
            "locked_fields": [], "id": "different-participant",
        }))
        mock_sb, participants_mock, _ = self._mock_sb(claim_data=[{"id": "prop-1"}])
        service.sb = mock_sb

        result = await service.apply_proposal("prop-1", "u1")
        assert result is True
        applied_payload = participants_mock.update.call_args.args[0]
        assert applied_payload.get("first_name") == "Marie"
        for forbidden in ("event_id", "locked_fields", "id"):
            assert forbidden not in applied_payload or forbidden == "locked_fields"
        # locked_fields IS a real key in the payload (the lock-merge logic),
        # but its VALUE must never come from attacker-supplied changes --
        # only "first_name" (the one allowlisted field) is on it.
        assert applied_payload["locked_fields"] == ["first_name"]

    @pytest.mark.asyncio
    async def test_only_allowlisted_fields_survive_when_all_disallowed(self):
        from services.email_agent_service import EmailAgentService
        service = EmailAgentService(MagicMock())
        service.get_proposal = AsyncMock(return_value=self._proposal({
            "event_id": "other-event-id", "locked_fields": [], "id": "x",
        }))
        mock_sb, _, _ = self._mock_sb(claim_data=[{"id": "prop-1"}])
        service.sb = mock_sb

        result = await service.apply_proposal("prop-1", "u1")
        # Nothing allowlisted survives -> changes is empty -> no-op, not applied.
        assert result is False

    @pytest.mark.asyncio
    async def test_double_apply_second_call_is_rejected(self):
        """Simulates the race: the SECOND concurrent call's conditional
        UPDATE (.eq("status", "pending")) matches zero rows because the
        first call already flipped status to "applied", proving the claim
        is the actual gate -- not the earlier plain status read."""
        from services.email_agent_service import EmailAgentService
        service = EmailAgentService(MagicMock())
        service.get_proposal = AsyncMock(return_value=self._proposal({"first_name": "Marie"}))
        mock_sb, participants_mock, change_log_mock = self._mock_sb(claim_data=[])  # 0 rows affected
        service.sb = mock_sb

        result = await service.apply_proposal("prop-1", "u1")
        assert result is False
        participants_mock.update.assert_not_called()
        change_log_mock.insert.assert_not_called()


class TestEmailAgent:
    def test_list_proposals(self):
        """GET /api/events/{event_id}/email-agent should return email proposals."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        mock_supabase.table.return_value.select.return_value.eq.return_value.order.return_value.execute.return_value.data = [
            {
                "id": "00000000-0000-0000-0000-000000000009",
                "event_id": "00000000-0000-0000-0000-000000000001",
                "sender": "test@sender.com",
                "subject": "Dietary request",
                "body": "I am vegan",
                "received_at": "2026-07-09T10:00:00Z",
                "participant_id": None,
                "status": "pending",
                "proposed_changes": {"dietary_requirements": "Végétalien"},
                "ai_explanation": "Vegan request",
                "created_at": "2026-07-09T10:00:00Z",
                "participants": None
            }
        ]

        response = client.get("/api/events/00000000-0000-0000-0000-000000000001/email-agent")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["sender"] == "test@sender.com"
        assert data[0]["proposed_changes"]["dietary_requirements"] == "Végétalien"

    def test_analyze_email(self):
        """POST /api/events/{event_id}/email-agent/analyze should parse and return proposal."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        # Mock participant lookup -> no match
        mock_supabase.table.return_value.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = []
        mock_supabase.table.return_value.select.return_value.eq.return_value.execute.return_value.data = []

        # Mock insert proposal
        mock_supabase.table.return_value.insert.return_value.execute.return_value.data = [
            {
                "id": "00000000-0000-0000-0000-000000000009",
                "event_id": "00000000-0000-0000-0000-000000000001",
                "sender": "test@sender.com",
                "subject": "Change request",
                "body": "Please make me vegetarian",
                "received_at": "2026-07-09T10:00:00Z",
                "participant_id": None,
                "status": "pending",
                "proposed_changes": {"dietary_requirements": "Végétarien"},
                "ai_explanation": "Vegetarian requested",
                "created_at": "2026-07-09T10:00:00Z",
                "participants": None
            }
        ]

        payload = {
            "sender": "test@sender.com",
            "subject": "Change request",
            "body": "Please make me vegetarian"
        }
        response = client.post("/api/events/00000000-0000-0000-0000-000000000001/email-agent/analyze", json=payload)
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "pending"
        assert data["proposed_changes"]["dietary_requirements"] == "Végétarien"


# ---------------------------------------------------------------------------
# 6. Quality engine and source validations
# ---------------------------------------------------------------------------

class TestQualityEngineAndMatchingCorrections:
    def test_possible_duplicate_detection(self):
        """
        Verify that _detect_possible_duplicates correctly flags two participants
        with very similar names but different email addresses.
        """
        from services.exception_service import _detect_possible_duplicates
        from unittest.mock import MagicMock

        # Mock supabase response with similar names, different emails
        mock_supabase = MagicMock()
        mock_supabase.table.return_value.select.return_value.eq.return_value.execute.return_value.data = [
            {"id": "p1", "first_name": "Kris", "last_name": "Brown", "email": "kris.brown@dieteren.com", "company": "D'Ieteren"},
            {"id": "p2", "first_name": "Kris", "last_name": "Brown", "email": "kris.brown@dieteren.be", "company": "D'Ieteren"},
            {"id": "p3", "first_name": "Els", "last_name": "Bertrand", "email": "els.bertrand@cfegroup.be", "company": "CFE"},
            {"id": "p4", "first_name": "Els", "last_name": "Comrtrand", "email": "els.comrtrand1@cfegroup.com", "company": "CFE"},
            {"id": "p5", "first_name": "Different", "last_name": "Name", "email": "diff@test.com", "company": "Test"}
        ]

        exceptions = []
        count = _detect_possible_duplicates(
            event_id="test_event",
            run_id="test_run",
            supabase=mock_supabase,
            exceptions_list=exceptions
        )

        # Should find Kris Brown duplicate and Els Bertrand/Comrtrand duplicate
        assert count == 2
        assert len(exceptions) == 2
        assert any(e["exception_type"] == "POSSIBLE_DUPLICATE" and "Kris Brown" in e["message"] for e in exceptions)
        assert any(e["exception_type"] == "POSSIBLE_DUPLICATE" and "Els Bertrand" in e["message"] for e in exceptions)

    def test_name_mismatch_between_sources_detection(self):
        """
        Verify that _detect_name_mismatches_between_sources correctly flags
        conflicting names between registration and FCM files.
        """
        from services.exception_service import _detect_name_mismatches_between_sources
        from unittest.mock import MagicMock

        mock_supabase = MagicMock()
        
        # Mock participants list return
        mock_supabase.table.return_value.select.return_value.eq.return_value.not_.is_.return_value.not_.is_.return_value.execute.return_value.data = [
            {
                "id": "p1",
                "first_name": "Sebastien",
                "last_name": "Perrin",
                "registration_source_id": "reg1",
                "fcm_source_id": "fcm1"
            }
        ]

        # Mock source records response
        mock_supabase.table.return_value.select.return_value.in_.return_value.execute.return_value.data = [
            {"id": "reg1", "normalized_data": {"first_name": "Sebastien", "last_name": "Perrin"}},
            {"id": "fcm1", "normalized_data": {"first_name": "Sébastien", "last_name": "Pérrin"}}  # minor accents/case diffs count as mismatch
        ]

        exceptions = []
        count = _detect_name_mismatches_between_sources(
            event_id="test_event",
            run_id="test_run",
            supabase=mock_supabase,
            exceptions_list=exceptions
        )

        assert count == 1
        assert len(exceptions) == 1
        # NAME_DIVERGENCE is the ENUM-valid type for registration-vs-FCM
        # name mismatches (NAME_MISMATCH_BETWEEN_SOURCES 22P02-failed inserts).
        assert exceptions[0]["exception_type"] == "NAME_DIVERGENCE"
        assert "Sébastien" in exceptions[0]["message"]

    def test_source_type_never_in_nationality_validation(self):
        """
        Verify that mapping logic doesn't allow source_type values 
        (like registration, fcm, or Excel imports) to leak into nationality.
        """
        from services.mapping_service import apply_mapping, normalise_fields

        # Test with incorrect mapping of "Source" (containing Formulaire web) to "nationality"
        raw_row = {
            "Nom": "Moreau",
            "Prénom": "Olivier",
            "Email": "olivier.moreau@recticel.be",
            "Source": "Formulaire web"
        }

        # If mapping incorrectly maps "Source" to "nationality"
        mapping = {
            "Nom": "last_name",
            "Prénom": "first_name",
            "Email": "email",
            "Source": "nationality"
        }

        mapped = apply_mapping(raw_row, mapping)
        normalised = normalise_fields(mapped)

        nationality_val = normalised.get("nationality")
        
        invalid_source_types = ["formulaire web", "import excel", "email direct", "assistant", "registration", "fcm"]
        if nationality_val and nationality_val.strip().lower() in invalid_source_types:
            is_valid = False
        else:
            is_valid = True

        assert is_valid is False


# ---------------------------------------------------------------------------
# Test Mapping Suggestions
# ---------------------------------------------------------------------------

class TestMappingSuggestions:
    def test_normalize_column_name(self):
        """Verify _normalize_column_name correctly normalizes column names."""
        from services.mapping_service import _normalize_column_name
        assert _normalize_column_name("Prénom") == "prenom"
        assert _normalize_column_name("E-mail Address") == "emailaddress"
        assert _normalize_column_name("Nom de Famille") == "nomdefamille"
        assert _normalize_column_name("Flight_No.") == "flightno"
        assert _normalize_column_name("check-in/date") == "checkindate"

    def test_suggest_mapping_email(self):
        """Verify suggest_mapping identifies email fields by content and name."""
        from services.mapping_service import suggest_mapping
        columns = ["Mail"]
        sample_rows = [
            {"Mail": "jean@dupont.com"},
            {"Mail": "alice@martin.be"},
            {"Mail": "bob@test.org"},
        ]
        sug = suggest_mapping(columns, sample_rows)
        assert "Mail" in sug
        assert sug["Mail"]["suggested_field"] == "email"
        assert sug["Mail"]["confidence"] >= 0.9

    def test_suggest_mapping_date(self):
        """Verify suggest_mapping identifies date fields by content and name."""
        from services.mapping_service import suggest_mapping
        columns = ["Date Entrée"]
        sample_rows = [
            {"Date Entrée": "12/11/2025"},
            {"Date Entrée": "13-11-2025"},
            {"Date Entrée": "2025-11-14"},
        ]
        sug = suggest_mapping(columns, sample_rows)
        assert "Date Entrée" in sug
        assert sug["Date Entrée"]["suggested_field"] == "check_in_date"
        assert sug["Date Entrée"]["confidence"] >= 0.9

    def test_suggest_mapping_flight(self):
        """Verify suggest_mapping identifies flight fields by content and name."""
        from services.mapping_service import suggest_mapping
        columns = ["Vol"]
        sample_rows = [
            {"Vol": "SN1234"},
            {"Vol": "LH456"},
            {"Vol": "AA9876"},
        ]
        sug = suggest_mapping(columns, sample_rows)
        assert "Vol" in sug
        assert sug["Vol"]["suggested_field"] == "flight_number"
        assert sug["Vol"]["confidence"] >= 0.9

    def test_suggest_mapping_weak_no_suggestion(self):
        """Verify suggest_mapping returns None and 0.0 confidence when no matches are found."""
        from services.mapping_service import suggest_mapping
        columns = ["Inconnu"]
        sample_rows = [
            {"Inconnu": "abc"},
            {"Inconnu": "xyz"},
            {"Inconnu": "123"},
        ]
        sug = suggest_mapping(columns, sample_rows)
        assert "Inconnu" in sug
        assert sug["Inconnu"]["suggested_field"] is None
        assert sug["Inconnu"]["confidence"] == 0.0


# ---------------------------------------------------------------------------
# Test Participant Lookup
# ---------------------------------------------------------------------------

class TestParticipantLookup:
    @patch("routers.participants.verify_event_access")
    def test_lookup_participants(self, mock_verify):
        """GET /api/events/{event_id}/participants/lookup should return list of lookup items."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase

        mock_supabase.table.return_value.select.return_value.eq.return_value.order.return_value.order.return_value.range.return_value.execute.return_value.data = [
            {
                "id": "00000000-0000-0000-0000-000000000005",
                "first_name": "Jean",
                "last_name": "Dupont",
                "completeness_status": "complete",
            }
        ]

        response = client.get("/api/events/00000000-0000-0000-0000-000000000001/participants/lookup")
        assert response.status_code == 200, response.text
        data = response.json()
        assert len(data) == 1
        assert data[0]["first_name"] == "Jean"
        assert data[0]["last_name"] == "Dupont"
        assert data[0]["completeness_status"] == "complete"

    @patch("routers.participants.verify_event_access")
    def test_lookup_participants_raises_404_if_no_access(self, mock_verify):
        """GET /api/events/{event_id}/participants/lookup raises 404 if no access."""
        from fastapi import HTTPException
        mock_verify.side_effect = HTTPException(status_code=404, detail="Event not found.")
        client = _admin_client()
        
        response = client.get("/api/events/00000000-0000-0000-0000-000000000001/participants/lookup")
        assert response.status_code == 404


# ---------------------------------------------------------------------------
# Event / Project deletion
# ---------------------------------------------------------------------------

class TestEventProjectDeletion:
    EVENT_ID = "00000000-0000-0000-0000-000000000001"
    PROJECT_ID = "00000000-0000-0000-0000-000000000002"

    @patch("routers.events.verify_event_access")
    @patch("routers.events.deletion_service.delete_event")
    def test_delete_event_success(self, mock_delete, mock_verify):
        """DELETE /api/events/{id} deletes cascade and returns success (admin)."""
        client = _admin_client()
        response = client.delete(f"/api/events/{self.EVENT_ID}")
        assert response.status_code == 200, response.text
        assert response.json()["message"] == "Event deleted successfully."
        mock_delete.assert_called_once()

    def test_delete_event_forbidden_for_viewer(self):
        """A viewer must not be able to delete an event (403)."""
        client = _viewer_client()
        response = client.delete(f"/api/events/{self.EVENT_ID}")
        assert response.status_code == 403

    @patch("routers.events.deletion_service.delete_project")
    def test_delete_project_success(self, mock_delete):
        """DELETE /api/projects/{id} deletes the project after org check (admin)."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        # Project ownership check: table.select.eq.eq.single.execute.data truthy
        mock_supabase.table.return_value.select.return_value.eq.return_value.eq.return_value.single.return_value.execute.return_value.data = {"id": self.PROJECT_ID}

        response = client.delete(f"/api/projects/{self.PROJECT_ID}")
        assert response.status_code == 200, response.text
        assert response.json()["message"] == "Project deleted successfully."
        mock_delete.assert_called_once()

    def test_delete_project_not_found(self):
        """DELETE /api/projects/{id} returns 404 when the project is not in the org."""
        client = _admin_client()
        mock_supabase = _mock_supabase()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        mock_supabase.table.return_value.select.return_value.eq.return_value.eq.return_value.single.return_value.execute.return_value.data = None

        response = client.delete(f"/api/projects/{self.PROJECT_ID}")
        assert response.status_code == 404

    def test_delete_project_forbidden_for_viewer(self):
        """A viewer must not be able to delete a project (403)."""
        client = _viewer_client()
        response = client.delete(f"/api/projects/{self.PROJECT_ID}")
        assert response.status_code == 403


class TestModelDumpJSONSerializable:
    """2026-07-22: assigning a hotel night crashed with a 500 on every single
    attempt ("Failed to fetch" in the browser — the crash path lost the CORS
    header, so the browser reported a network error instead of a readable
    error). Railway logs pinned it down: routers/hotels.py's
    assign_rooming_night built its Supabase insert payload with a bare
    `body.model_dump()`, which leaves UUID/date fields as UUID/date Python
    objects — the postgrest/httpx JSON encoder can't serialize those and
    raises TypeError before any request even reaches Supabase.

    The same bare-.model_dump() pattern existed in 3 other insert/update call
    sites (all fixed to model_dump(mode="json")). These tests assert directly
    on the models: any payload built this way must be json.dumps()-safe.
    """

    def test_hotel_night_create_dump_is_json_safe(self):
        import json
        from models.schemas import HotelNightCreate

        model = HotelNightCreate(
            hotel_id="00000000-0000-0000-0000-000000000001",
            participant_id="00000000-0000-0000-0000-000000000002",
            night_date="2027-06-15",
        )
        # The bug: bare model_dump() leaves UUID/date objects that crash here.
        with pytest.raises(TypeError):
            json.dumps(model.model_dump())
        # The fix: mode="json" converts them to plain strings.
        payload = model.model_dump(mode="json")
        json.dumps(payload)  # must not raise
        assert isinstance(payload["hotel_id"], str)
        assert isinstance(payload["participant_id"], str)
        assert isinstance(payload["night_date"], str)

    def test_hotel_night_update_dump_is_json_safe(self):
        import json
        from models.schemas import HotelNightUpdate

        model = HotelNightUpdate(hotel_id="00000000-0000-0000-0000-000000000001")
        with pytest.raises(TypeError):
            json.dumps(model.model_dump(exclude_none=True))
        payload = model.model_dump(mode="json", exclude_none=True)
        json.dumps(payload)
        assert isinstance(payload["hotel_id"], str)

    def test_transfer_create_dump_is_json_safe(self):
        import json
        from models.schemas import TransferCreate

        model = TransferCreate(
            participant_id="00000000-0000-0000-0000-000000000002",
            transfer_type="arrival",
            pickup_location="BCN Airport T1",
            dropoff_location="Hotel Arts BCN",
            pickup_time="2027-06-15T12:30:00Z",
        )
        with pytest.raises(TypeError):
            json.dumps(model.model_dump())
        payload = model.model_dump(mode="json")
        json.dumps(payload)
        assert isinstance(payload["participant_id"], str)
        assert isinstance(payload["pickup_time"], str)

    def test_activity_create_dump_is_json_safe(self):
        import json
        from models.schemas import ActivityCreate

        model = ActivityCreate(name="Visite guidée", date_time="2027-06-15T09:00:00Z")
        with pytest.raises(TypeError):
            json.dumps(model.model_dump())
        payload = model.model_dump(mode="json")
        json.dumps(payload)
        assert isinstance(payload["date_time"], str)


class TestDeletionServiceCascade:
    """2026-07-22: deleting an event/project 500'd whenever the event had any
    row in `communications` (confirmation/campaign emails) — that table has no
    ON DELETE CASCADE (docs/migrations/002_communications.sql), and
    deletion_service.delete_event() never cleared it before deleting
    participants/the event itself, so Postgres raised a foreign-key violation.
    """

    def test_delete_event_clears_communications_before_deleting_the_event(self):
        from services import deletion_service

        event_id = "00000000-0000-0000-0000-000000000001"
        called_tables: list[str] = []

        def table_side_effect(name):
            called_tables.append(name)
            m = MagicMock()
            m.select.return_value.eq.return_value.range.return_value.execute.return_value.data = []
            m.select.return_value.eq.return_value.execute.return_value.data = []
            m.delete.return_value.eq.return_value.execute.return_value.data = []
            m.delete.return_value.in_.return_value.execute.return_value.data = []
            m.update.return_value.eq.return_value.execute.return_value.data = []
            return m

        mock_supabase = MagicMock()
        mock_supabase.table.side_effect = table_side_effect

        deletion_service.delete_event(mock_supabase, event_id)

        assert "communications" in called_tables, (
            "communications rows must be cleared during event deletion — that "
            "table has no ON DELETE CASCADE and blocks the participants/events delete otherwise"
        )
        # "participants" is queried (SELECT ids) early and deleted later — the
        # communications cleanup must happen before that final DELETE, i.e.
        # before the *last* time the participants table is touched.
        last_participants_call = len(called_tables) - 1 - called_tables[::-1].index("participants")
        assert called_tables.index("communications") < last_participants_call
        assert called_tables.index("communications") < called_tables.index("events")


class TestTransferExtractionRecognizesReturnDateAsARealDate:
    """2026-07-22: after the mapping fix (rule 6b) was deployed, a real
    event's transfer import stopped showing "date illisible" exceptions --
    but the transfer count still didn't move (still 0 transfers created for
    500 fully-linked, fully-populated source_records). Root cause: the
    file's single "Date" column fuzzy-matched `return_date` (a flight-only
    synonym, SYNONYMS["return_date"]) instead of departure_date/
    arrival_date/date. The date it carries is genuinely real -- confirmed
    directly in the database (normalized_data had "return_date":
    "2026-08-20" on every row) -- but the transfer-extraction gate's
    _has_real_date() call only checked pickup_date/departure_date/
    arrival_date/date/pickup_time/departure_time, so a real date sitting
    right there was invisible to it and every transfer was silently
    dropped as "undated"."""

    def test_has_real_date_recognizes_return_date_when_asked(self):
        from services.consolidation_service import _has_real_date
        data = {"return_date": "2026-08-20", "pickup_time": "14:49"}
        assert _has_real_date(
            data, "pickup_date", "departure_date", "arrival_date", "date",
            "return_date", "pickup_time", "departure_time",
        ) is True

    def test_transfer_extraction_gate_includes_return_date(self):
        """Guards the actual call site inside run_consolidation, not just
        the standalone helper: greps the source for the exact field list
        passed to _has_real_date in the transfer-extraction block, so a
        future edit that drops return_date again fails this test even
        though the code is embedded in a much larger function that isn't
        practically unit-testable in isolation."""
        import inspect
        from services import consolidation_service
        source = inspect.getsource(consolidation_service)
        # Anchor on the transfer-specific field list (not the flight extraction's
        # earlier, differently-worded _has_real_date call a few hundred lines up).
        anchor = '"pickup_date", "departure_date", "arrival_date", "date",'
        gate_call = source[source.index(anchor):][:200]
        assert '"return_date"' in gate_call


class TestRepairStoredMappingsTransferRules:
    """2026-07-21 audit: a transfer file's "Date" column got mapped to
    check_in_date (a hotel-only field) by mistake once, was "remembered"
    org-wide (column_mapping_templates), and was then silently reapplied
    verbatim to a real event's real transfer import — 0 of 600 rows
    extracted, because check_in_date is never checked as a date source by
    the transfer-extraction gate, and the file's only airport column
    ("Aéroport", unqualified) was left unmapped for the same underlying
    reason (no synonym recognizes a bare "Aéroport"). Rules 6 and 7 in
    repair_stored_mappings (services/mapping_service.py) self-heal both,
    the same way rules 1-5 already self-heal older mis-mapping classes."""

    EVENT_ID = "00000000-0000-0000-0000-00000000ff01"

    def _mocked_client(self, files_data, source_records_data=None):
        mock_supabase = MagicMock()
        files_mock = MagicMock()
        files_mock.select.return_value.eq.return_value.execute.return_value.data = files_data
        files_mock.update.return_value.eq.return_value.execute.return_value.data = [{"id": "ok"}]

        records_mock = MagicMock()
        records_mock.select.return_value.eq.return_value.limit.return_value.execute.return_value.data = (
            source_records_data or []
        )

        def table_side_effect(name):
            if name == "uploaded_files":
                return files_mock
            if name == "source_records":
                return records_mock
            return MagicMock()

        mock_supabase.table.side_effect = table_side_effect
        return mock_supabase, files_mock

    def test_hotel_only_date_field_redirected_to_travel_date(self):
        from services.mapping_service import repair_stored_mappings
        file_row = {
            "id": "file-1",
            "source_type": "transfer",
            "column_mapping": {
                "Vol": "flight_number", "Date": "check_in_date", "Type": "transfer_type",
                "Aeroport": "arrival_airport",
            },
        }
        mock_supabase, files_mock = self._mocked_client([file_row])

        fixed = repair_stored_mappings(self.EVENT_ID, mock_supabase)

        assert fixed == 1
        new_mapping = files_mock.update.call_args_list[0][0][0]["column_mapping"]
        assert new_mapping["Date"] == "departure_date"

    def test_hotel_name_column_redirected_to_dropoff_location_not_a_date_field(self):
        """2026-07-22 regression: rule 6 used to treat every _HOTEL_ONLY_FIELDS
        member the same way and redirect it to departure_date/arrival_date.
        hotel_name is TEXT-shaped (a venue name like "VOAI Diamond Head
        Conference Hotel"), not date-shaped -- stuffing it into departure_date
        produced an unparseable "date de départ illisible" exception on every
        row, while the real pickup/dropoff field it should have gone to
        stayed empty, so transfers kept failing has_location_signal and the
        "sans transfert" count never moved despite the file being imported."""
        from services.mapping_service import repair_stored_mappings
        file_row = {
            "id": "file-1b",
            "source_type": "transfer",
            "column_mapping": {
                "Vol": "flight_number", "Type": "transfer_type",
                "Hotel": "hotel_name",
            },
        }
        mock_supabase, files_mock = self._mocked_client([file_row])

        fixed = repair_stored_mappings(self.EVENT_ID, mock_supabase)

        assert fixed == 1
        new_mapping = files_mock.update.call_args_list[0][0][0]["column_mapping"]
        assert new_mapping["Hotel"] == "dropoff_location"
        assert new_mapping["Hotel"] not in ("departure_date", "arrival_date")

    def test_hotel_room_type_column_demoted_to_custom_field(self):
        """room_type has no reliable transfer equivalent to redirect to --
        must be demoted to a custom field, never guessed onto a date field
        either."""
        from services.mapping_service import repair_stored_mappings
        file_row = {
            "id": "file-1c",
            "source_type": "transfer",
            "column_mapping": {
                "Vol": "flight_number", "Type": "transfer_type",
                "Room": "room_type",
            },
        }
        mock_supabase, files_mock = self._mocked_client([file_row])

        fixed = repair_stored_mappings(self.EVENT_ID, mock_supabase)

        assert fixed == 1
        new_mapping = files_mock.update.call_args_list[0][0][0]["column_mapping"]
        assert new_mapping["Room"] == "Room"

    def test_departure_date_column_full_of_venue_names_redirected_retroactively(self):
        """The exact retroactive case: a PAST run of the old, broken rule 6
        already corrupted this file's stored mapping to "Hotel": "departure_date"
        before today's fix existed. Rule 6 alone can't see that anymore --
        departure_date is a normal target -- so this must be caught by
        sampling the column's actual raw values and noticing they don't
        parse as dates at all."""
        from services.mapping_service import repair_stored_mappings
        file_row = {
            "id": "file-1d",
            "source_type": "transfer",
            "column_mapping": {
                "Vol": "flight_number", "Type": "transfer_type",
                "Hotel": "departure_date",
            },
        }
        sample = [
            {"raw_data": {"Hotel": "VOAI Diamond Head Conference Hotel"}},
            {"raw_data": {"Hotel": "VOAI Pacific Grand Honolulu"}},
        ]
        mock_supabase, files_mock = self._mocked_client([file_row], source_records_data=sample)

        fixed = repair_stored_mappings(self.EVENT_ID, mock_supabase)

        assert fixed == 1
        new_mapping = files_mock.update.call_args_list[0][0][0]["column_mapping"]
        assert new_mapping["Hotel"] == "dropoff_location"

    def test_real_departure_date_column_left_alone(self):
        """A genuine departure_date column, whose sampled raw values DO parse
        as dates, must never be touched by the retroactive venue-name check."""
        from services.mapping_service import repair_stored_mappings
        file_row = {
            "id": "file-1e",
            "source_type": "transfer",
            "column_mapping": {
                "Vol": "flight_number", "Type": "transfer_type",
                "Date": "departure_date",
            },
        }
        sample = [
            {"raw_data": {"Date": "15/06/2027"}},
            {"raw_data": {"Date": "16/06/2027"}},
        ]
        mock_supabase, files_mock = self._mocked_client([file_row], source_records_data=sample)

        fixed = repair_stored_mappings(self.EVENT_ID, mock_supabase)

        assert fixed == 0
        files_mock.update.assert_not_called()

    def test_bare_airport_column_mapped_when_no_other_location_field(self):
        from services.mapping_service import repair_stored_mappings
        file_row = {
            "id": "file-2",
            "source_type": "transfer",
            "column_mapping": {
                "Vol": "flight_number", "Date": "departure_date", "Type": "transfer_type",
                "Aeroport": "Aeroport",  # left unmapped (self-mapped custom field)
            },
        }
        mock_supabase, files_mock = self._mocked_client([file_row])

        fixed = repair_stored_mappings(self.EVENT_ID, mock_supabase)

        assert fixed == 1
        new_mapping = files_mock.update.call_args_list[0][0][0]["column_mapping"]
        assert new_mapping["Aeroport"] == "arrival_airport"

    def test_bare_airport_column_left_alone_when_real_location_field_present(self):
        """If the file already has a proper pickup_location/dropoff_location
        column that is ACTUALLY POPULATED, a bare "Aéroport" is genuinely
        extra info -- must not be overwritten (avoids stomping a deliberate
        custom-field choice)."""
        from services.mapping_service import repair_stored_mappings
        file_row = {
            "id": "file-3",
            "source_type": "transfer",
            "column_mapping": {
                "Vol": "flight_number", "Date": "departure_date", "Type": "transfer_type",
                "Aeroport": "Aeroport", "Lieu de Prise en charge": "pickup_location",
            },
        }
        sample = [{"raw_data": {"Lieu de Prise en charge": "Conference Hotel"}}]
        mock_supabase, files_mock = self._mocked_client([file_row], source_records_data=sample)

        fixed = repair_stored_mappings(self.EVENT_ID, mock_supabase)

        assert fixed == 0
        files_mock.update.assert_not_called()

    def test_bare_airport_redirected_when_mapped_location_column_is_empty(self):
        """The exact real-world case: 'Destination'/'Lieu de Prise en charge'
        WERE mapped to dropoff_location/pickup_location, but every one of the
        600 real rows left them blank -- 'Aéroport' was the only column
        actually carrying data. Being MAPPED is not enough; it must be
        POPULATED, or the extraction gate still silently drops every row."""
        from services.mapping_service import repair_stored_mappings
        file_row = {
            "id": "file-4",
            "source_type": "transfer",
            "column_mapping": {
                "Vol": "flight_number", "Date": "departure_date", "Type": "transfer_type",
                "Aeroport": "Aeroport",
                "Destination": "dropoff_location", "Lieu de Prise en charge": "pickup_location",
            },
        }
        sample = [
            {"raw_data": {"Aeroport": "New York JFK", "Destination": None, "Lieu de Prise en charge": ""}},
            {"raw_data": {"Aeroport": "Tokyo NRT", "Destination": "", "Lieu de Prise en charge": None}},
        ]
        mock_supabase, files_mock = self._mocked_client([file_row], source_records_data=sample)

        fixed = repair_stored_mappings(self.EVENT_ID, mock_supabase)

        assert fixed == 1
        new_mapping = files_mock.update.call_args_list[0][0][0]["column_mapping"]
        assert new_mapping["Aeroport"] == "arrival_airport"

    def test_bare_country_column_redirected_to_nationality_when_unmapped(self):
        """Real case: a registration file's "Country" column (300/300 rows
        populated with "Turquie", "Japon"...) was captured under the unused
        `country` rich field -- the export never shows it -- while
        `nationality`, the field that drives Missing Fields / Data Complete,
        stayed empty for all 300 participants (2026-07-21 audit)."""
        from services.mapping_service import repair_stored_mappings
        file_row = {
            "id": "file-5",
            "source_type": "registration",
            "column_mapping": {
                "First Name": "first_name", "Last Name": "last_name",
                "Email Address": "email", "Country": "country",
            },
        }
        mock_supabase, files_mock = self._mocked_client([file_row])

        fixed = repair_stored_mappings(self.EVENT_ID, mock_supabase)

        assert fixed == 1
        new_mapping = files_mock.update.call_args_list[0][0][0]["column_mapping"]
        assert new_mapping["Country"] == "nationality"

    def test_country_column_left_alone_when_nationality_already_mapped(self):
        """A file that genuinely distinguishes the two (a separate,
        POPULATED "Nationalité" column) must not have its "Country" column
        stolen away from the `country` rich field."""
        from services.mapping_service import repair_stored_mappings
        file_row = {
            "id": "file-6",
            "source_type": "registration",
            "column_mapping": {
                "First Name": "first_name", "Last Name": "last_name",
                "Country": "country", "Nationalité": "nationality",
            },
        }
        sample = [{"raw_data": {"Nationalité": "Française"}}]
        mock_supabase, files_mock = self._mocked_client([file_row], source_records_data=sample)

        fixed = repair_stored_mappings(self.EVENT_ID, mock_supabase)

        assert fixed == 0
        files_mock.update.assert_not_called()

    def test_country_column_redirected_when_mapped_nationality_column_is_a_ghost(self):
        """The exact real-world case: the stored mapping already had a
        'Nationalité' -> nationality entry, but it was a STALE leftover from
        an earlier org template -- no such column exists in this file at
        all, so it never carries real data. Being MAPPED is not enough; it
        must be POPULATED, exactly like the bare-airport rule above."""
        from services.mapping_service import repair_stored_mappings
        file_row = {
            "id": "file-7",
            "source_type": "registration",
            "column_mapping": {
                "First Name": "first_name", "Last Name": "last_name",
                "Country": "country", "Nationalité": "nationality",
            },
        }
        sample = [{"raw_data": {"Country": "Turquie"}}]  # no 'Nationalité' key at all
        mock_supabase, files_mock = self._mocked_client([file_row], source_records_data=sample)

        fixed = repair_stored_mappings(self.EVENT_ID, mock_supabase)

        assert fixed == 1
        new_mapping = files_mock.update.call_args_list[0][0][0]["column_mapping"]
        assert new_mapping["Country"] == "nationality"


class TestInferEventCity:
    """2026-07-21 audit: there is no UI to set events.location_city, so the
    arrival_airport fallback that depends on it silently left EVERY flight's
    arrival_airport empty for a real file whose 2-sheet Arrival/Departure
    layout never states an explicit arrival airport at all (600/600 flights,
    real event). _infer_event_city derives it from departure_airport
    frequency instead: every attendee's return leg departs FROM the event
    city, so it dominates the frequency count."""

    def _record(self, departure_airport):
        return {"normalized_data": {"departure_airport": departure_airport}}

    def test_dominant_airport_inferred(self):
        from services.consolidation_service import _infer_event_city
        records = (
            [self._record("BARCELONE BCN")] * 300
            + [self._record("SEOUL ICN")] * 23
            + [self._record("STOCKHOLM ARN")] * 19
            + [self._record("MEXICO MEX")] * 17
        )
        assert _infer_event_city(records) == "BARCELONE BCN"

    def test_no_dominant_airport_returns_none(self):
        """No single city clearly dominates (e.g. only outbound legs exist
        so far, roughly evenly spread across distinct home cities) -- must
        not guess."""
        from services.consolidation_service import _infer_event_city
        records = (
            [self._record("PARIS CDG")] * 10
            + [self._record("LONDON LHR")] * 10
            + [self._record("BERLIN BER")] * 10
            + [self._record("MADRID MAD")] * 10
            + [self._record("ROME FCO")] * 10
        )
        assert _infer_event_city(records) is None

    def test_too_few_records_returns_none_even_if_unanimous(self):
        from services.consolidation_service import _infer_event_city
        records = [self._record("BARCELONE BCN")] * 5
        assert _infer_event_city(records) is None

    def test_no_departure_airport_data_returns_none(self):
        from services.consolidation_service import _infer_event_city
        records = [{"normalized_data": {}}, {"raw_data": {}}]
        assert _infer_event_city(records) is None

    def test_falls_back_to_raw_data_when_normalized_missing(self):
        from services.consolidation_service import _infer_event_city
        records = [{"raw_data": {"departure_airport": "BARCELONE BCN"}}] * 15
        assert _infer_event_city(records) == "BARCELONE BCN"


class TestFallbackArrivalAirport:
    """2026-07-21 audit, same real event: once the event city was known
    (either from events.location_city or _infer_event_city above), the
    arrival_airport fallback was applied unconditionally -- including to the
    RETURN leg, which already departs FROM the event city. Real result:
    300/600 flights showed "BARCELONE BCN -> BARCELONE BCN", a self-round-trip
    that makes no sense on a master list a client will actually read."""

    def test_outbound_leg_gets_event_city_as_arrival(self):
        from services.consolidation_service import _fallback_arrival_airport
        assert _fallback_arrival_airport("MILAN MXP", "BARCELONE BCN") == "BARCELONE BCN"

    def test_return_leg_does_not_get_event_city_stamped_twice(self):
        from services.consolidation_service import _fallback_arrival_airport
        assert _fallback_arrival_airport("BARCELONE BCN", "BARCELONE BCN") == ""

    def test_return_leg_matches_case_insensitively_and_by_substring(self):
        """events.location_city may hold just the city name ("Barcelone")
        while departure_airport holds "city + code" ("Barcelone BCN") --
        must still recognise it as the same place."""
        from services.consolidation_service import _fallback_arrival_airport
        assert _fallback_arrival_airport("Barcelone BCN", "barcelone") == ""
        assert _fallback_arrival_airport("barcelone", "Barcelone BCN") == ""

    def test_no_event_city_returns_empty(self):
        from services.consolidation_service import _fallback_arrival_airport
        assert _fallback_arrival_airport("MILAN MXP", "") == ""

    def test_no_departure_airport_still_falls_back_to_event_city(self):
        from services.consolidation_service import _fallback_arrival_airport
        assert _fallback_arrival_airport(None, "BARCELONE BCN") == "BARCELONE BCN"


# ---------------------------------------------------------------------------
# Public registration form (routers/public_registration.py)
# ---------------------------------------------------------------------------

class TestPublicRegistration:
    """The public, unauthenticated per-event registration form: a submission
    becomes a source_records row under a single per-event virtual
    uploaded_files row, then fires a background-thread consolidation run so
    it reuses the existing matching/dedup pipeline instead of a parallel
    one, without the visitor's browser waiting on it."""

    TOKEN = "11111111-1111-1111-1111-111111111111"
    EVENT_ID = "00000000-0000-0000-0000-0000000000e1"
    PROJECT_ID = "00000000-0000-0000-0000-0000000000p1"
    OWNER_ID = "00000000-0000-0000-0000-0000000000u1"

    def _event_row(self, is_open=True):
        return {
            "id": self.EVENT_ID,
            "name": "Conference 2027",
            "project_id": self.PROJECT_ID,
            "registration_open": is_open,
        }

    def _base_payload(self, **overrides):
        payload = {
            "first_name": "Ana", "last_name": "Kaya", "email": "ana.kaya@example.com",
            "company": "", "phone": "", "nationality": "", "dietary_requirements": "",
            "date_of_birth": "", "passport_number": "", "passport_expiry": "",
            "job_title": "", "badge_name": "", "language": "",
            "food_allergy_info": "", "special_requests": "", "room_preference": "",
            "pmr_needs": "", "remarks": "", "emergency_contact_name": "",
            "emergency_contact_phone": "", "consent": True, "website": "",
        }
        payload.update(overrides)
        return payload

    def _mocked_client(self, event_row, *, existing_file=None, recent_records=None, source_record_count=0):
        events_mock = MagicMock()
        events_mock.select.return_value.eq.return_value.single.return_value.execute.return_value.data = event_row
        # _event_logo (point 11) reads the SAME table with a different chain
        # (.maybe_single() instead of .single()) — stubbed separately since
        # MagicMock does not distinguish calls by their arguments.
        events_mock.select.return_value.eq.return_value.maybe_single.return_value.execute.return_value.data = {
            "logo_url": event_row.get("logo_url")
        }

        projects_mock = MagicMock()
        projects_mock.select.return_value.eq.return_value.single.return_value.execute.return_value.data = {
            "created_by": self.OWNER_ID
        }

        files_mock = MagicMock()
        # _get_or_create_form_file chain: select→eq×3→order→execute. When no
        # file exists yet, the first read returns [] and the post-insert
        # re-read (racer-convergence) returns the new row.
        files_select_exec = (
            files_mock.select.return_value.eq.return_value.eq.return_value
            .eq.return_value.order.return_value.execute
        )
        if existing_file:
            files_select_exec.return_value.data = [{"id": existing_file}]
        else:
            empty, created = MagicMock(), MagicMock()
            empty.data, created.data = [], [{"id": "file-new-1"}]
            files_select_exec.side_effect = [empty, created, created, created]
        files_mock.insert.return_value.execute.return_value.data = [{"id": existing_file or "file-new-1"}]

        records_mock = MagicMock()
        records_mock.select.return_value.eq.return_value.gte.return_value.execute.return_value.data = (
            recent_records or []
        )
        records_mock.select.return_value.eq.return_value.execute.return_value.count = source_record_count
        records_mock.insert.return_value.execute.return_value.data = [{"id": "sr-new-1"}]

        runs_mock = MagicMock()
        runs_mock.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = []  # not running
        runs_mock.insert.return_value.execute.return_value.data = [{"id": "run-new-1"}]

        mocks = {
            "events": events_mock, "projects": projects_mock, "uploaded_files": files_mock,
            "source_records": records_mock, "consolidation_runs": runs_mock,
        }

        mock_supabase = MagicMock()
        mock_supabase.table.side_effect = lambda name: mocks.get(name, MagicMock())
        return mock_supabase, mocks

    def teardown_method(self):
        app.dependency_overrides.pop(get_supabase_client, None)

    def test_get_info_valid_token(self):
        mock_supabase, _ = self._mocked_client(self._event_row())
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        response = client.get(f"/api/public/register/{self.TOKEN}")

        assert response.status_code == 200, response.text
        body = response.json()
        assert body["event_name"] == "Conference 2027"
        assert body["is_open"] is True

    def test_get_info_invalid_token_returns_404(self):
        mock_supabase = MagicMock()
        mock_supabase.table.return_value.select.return_value.eq.return_value.single.return_value.execute.side_effect = Exception("not found")
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        response = client.get(f"/api/public/register/{self.TOKEN}")

        assert response.status_code == 404

    def test_submit_success_creates_source_record(self):
        mock_supabase, mocks = self._mocked_client(self._event_row())
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        response = client.post(f"/api/public/register/{self.TOKEN}", json=self._base_payload())

        assert response.status_code == 201, response.text
        mocks["source_records"].insert.assert_called_once()
        # A submission inserts a LIST of rows: one for the registrant, and a
        # second when a companion came with them (§9). These tests are about
        # what the registrant's row CONTAINS, so they read the first.
        inserted = mocks["source_records"].insert.call_args[0][0][0]
        assert inserted["raw_data"]["first_name"] == "Ana"
        assert inserted["raw_data"]["email"] == "ana.kaya@example.com"
        assert inserted["event_id"] == self.EVENT_ID

    def test_submit_triggers_background_consolidation_thread(self):
        """2026-07-26: a real submission took ~58s to respond because
        FastAPI's BackgroundTasks awaits the consolidation coroutine on the
        same event loop that still has to flush the response. The fix is a
        real OS thread (routers.public_registration._trigger_background_consolidation)
        that runs fully independently -- verify it's invoked with the right
        event/user without actually spinning up a thread in this test."""
        mock_supabase, mocks = self._mocked_client(self._event_row())
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        with patch("routers.public_registration._trigger_background_consolidation") as mock_trigger:
            response = client.post(f"/api/public/register/{self.TOKEN}", json=self._base_payload())

        assert response.status_code == 201, response.text
        mock_trigger.assert_called_once_with(self.EVENT_ID, self.OWNER_ID)
        mocks["consolidation_runs"].insert.assert_not_called()

    def test_submit_background_thread_runs_start_and_run_consolidation(self):
        """The thread target itself (not the trigger wrapper) must build its
        own Supabase client and call the same start_and_run_consolidation
        used by mapped Excel uploads -- catches a regression where the
        thread silently no-ops or calls the wrong function."""
        from routers.public_registration import _run_consolidation_in_thread

        with patch("dependencies._build_supabase_client") as mock_build, \
             patch("services.consolidation_service.start_and_run_consolidation", new_callable=AsyncMock) as mock_start:
            mock_client = MagicMock()
            mock_build.return_value = mock_client

            _run_consolidation_in_thread(self.EVENT_ID, self.OWNER_ID)

            mock_build.assert_called_once()
            mock_start.assert_awaited_once_with(self.EVENT_ID, self.OWNER_ID, mock_client)

    def test_submit_background_thread_swallows_consolidation_errors(self):
        """A failed background consolidation must not surface anywhere the
        (long-gone) HTTP client could see it -- just log and move on."""
        from routers.public_registration import _run_consolidation_in_thread

        with patch("dependencies._build_supabase_client", side_effect=RuntimeError("boom")):
            _run_consolidation_in_thread(self.EVENT_ID, self.OWNER_ID)  # must not raise

    def test_submit_closed_event_is_rejected(self):
        mock_supabase, mocks = self._mocked_client(self._event_row(is_open=False))
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        response = client.post(f"/api/public/register/{self.TOKEN}", json=self._base_payload())

        assert response.status_code == 403
        mocks["source_records"].insert.assert_not_called()

    def test_submit_invalid_token_returns_404(self):
        mock_supabase = MagicMock()
        mock_supabase.table.return_value.select.return_value.eq.return_value.single.return_value.execute.side_effect = Exception("not found")
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        response = client.post(f"/api/public/register/{self.TOKEN}", json=self._base_payload())

        assert response.status_code == 404

    def test_submit_missing_consent_is_rejected(self):
        mock_supabase, mocks = self._mocked_client(self._event_row())
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        response = client.post(f"/api/public/register/{self.TOKEN}", json=self._base_payload(consent=False))

        assert response.status_code == 422
        mocks["source_records"].insert.assert_not_called()

    def test_submit_phone_without_country_code_is_rejected(self):
        """Server-side backstop for the form's own requirement (the UI
        forces a dial-code select) — a client that skips the browser form
        must not be able to save a bare local number."""
        mock_supabase, mocks = self._mocked_client(self._event_row())
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        response = client.post(f"/api/public/register/{self.TOKEN}", json=self._base_payload(phone="0465191575"))

        assert response.status_code == 422
        mocks["source_records"].insert.assert_not_called()

    def test_submit_phone_with_country_code_is_accepted(self):
        mock_supabase, mocks = self._mocked_client(self._event_row())
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        response = client.post(f"/api/public/register/{self.TOKEN}", json=self._base_payload(phone="+32 465191575"))

        assert response.status_code == 201, response.text
        # A submission inserts a LIST of rows: one for the registrant, and a
        # second when a companion came with them (§9). These tests are about
        # what the registrant's row CONTAINS, so they read the first.
        inserted = mocks["source_records"].insert.call_args[0][0][0]
        assert inserted["raw_data"]["phone"] == "+32 465191575"

    def test_submit_honeypot_filled_returns_success_without_writing(self):
        """A bot that fills every field it finds, including the hidden
        honeypot, gets a plain success response -- so it learns nothing --
        but nothing is written to the database."""
        mock_supabase, mocks = self._mocked_client(self._event_row())
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        response = client.post(f"/api/public/register/{self.TOKEN}", json=self._base_payload(website="http://spam.example"))

        assert response.status_code == 201
        mocks["source_records"].insert.assert_not_called()
        mocks["uploaded_files"].insert.assert_not_called()

    def test_submit_throttled_after_repeated_same_email(self):
        recent = [{"raw_data": {"email": "ana.kaya@example.com"}} for _ in range(3)]
        mock_supabase, mocks = self._mocked_client(self._event_row(), existing_file="file-existing-1", recent_records=recent)
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        response = client.post(f"/api/public/register/{self.TOKEN}", json=self._base_payload())

        assert response.status_code == 429
        mocks["source_records"].insert.assert_not_called()

    def test_submit_extra_fields_pass_through_as_custom_data(self):
        """special_requests / room_preference / pmr_needs / remarks have no
        canonical field (yet) -- they must still reach normalized_data so
        nothing the client asked for is silently dropped."""
        mock_supabase, mocks = self._mocked_client(self._event_row())
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        payload = self._base_payload(
            special_requests="Fauteuil roulant a l'aeroport",
            room_preference="Lit double",
            pmr_needs="Acces rez-de-chaussee",
            remarks="Arrive la veille",
        )
        response = client.post(f"/api/public/register/{self.TOKEN}", json=payload)

        assert response.status_code == 201, response.text
        # A submission inserts a LIST of rows: one for the registrant, and a
        # second when a companion came with them (§9). These tests are about
        # what the registrant's row CONTAINS, so they read the first.
        inserted = mocks["source_records"].insert.call_args[0][0][0]
        assert inserted["normalized_data"]["special_requests"] == "Fauteuil roulant a l'aeroport"
        assert inserted["normalized_data"]["room_preference"] == "Lit double"
        assert inserted["normalized_data"]["pmr_needs"] == "Acces rez-de-chaussee"
        assert inserted["normalized_data"]["remarks"] == "Arrive la veille"

    def test_submit_travel_and_emergency_contact_fields_reach_normalized_data(self):
        """date_of_birth/passport_number/passport_expiry/job_title/badge_name/
        language are canonical fields elsewhere in the app but were never
        captured at registration time; emergency_contact_name/phone have no
        canonical field at all. Both groups must reach normalized_data."""
        mock_supabase, mocks = self._mocked_client(self._event_row())
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        payload = self._base_payload(
            date_of_birth="1990-05-12",
            passport_number="X1234567",
            passport_expiry="2030-01-01",
            job_title="Directrice Marketing",
            badge_name="Ana K.",
            language="Français",
            emergency_contact_name="Deniz Kaya",
            emergency_contact_phone="+90 5321234567",
        )
        response = client.post(f"/api/public/register/{self.TOKEN}", json=payload)

        assert response.status_code == 201, response.text
        # A submission inserts a LIST of rows: one for the registrant, and a
        # second when a companion came with them (§9). These tests are about
        # what the registrant's row CONTAINS, so they read the first.
        inserted = mocks["source_records"].insert.call_args[0][0][0]
        nd = inserted["normalized_data"]
        assert nd["date_of_birth"] == "1990-05-12"
        assert nd["passport_number"] == "X1234567"
        assert nd["passport_expiry"] == "2030-01-01"
        assert nd["job_title"] == "Directrice Marketing"
        assert nd["badge_name"] == "Ana K."
        assert nd["language"] == "Français"
        assert nd["emergency_contact_name"] == "Deniz Kaya"
        assert nd["emergency_contact_phone"] == "+90 5321234567"

    def test_submit_emergency_phone_without_country_code_is_rejected(self):
        mock_supabase, mocks = self._mocked_client(self._event_row())
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        payload = self._base_payload(emergency_contact_phone="0475123456")
        response = client.post(f"/api/public/register/{self.TOKEN}", json=payload)

        assert response.status_code == 422
        mocks["source_records"].insert.assert_not_called()


class TestIsPublicFormFile:
    """2026-07-26: a form submission's raw source data reached the
    participant's fiche (via the separate orphan-record linking step) but
    company/phone/nationality/dietary_requirements never merged into the
    participant record itself. Root cause: the virtual uploaded_files row
    (routers/public_registration.py) has no column_mapping, so the empty-
    mapping guard in run_consolidation's file loop skipped it every run --
    its already-inserted source_records never became ParticipantRecords, so
    they never reached merge_participant_fields. _is_public_form_file is the
    predicate that now routes this "file" to a different branch instead."""

    def test_recognizes_the_exact_path_public_registration_uses(self):
        from services.consolidation_service import _is_public_form_file
        event_id = "00000000-0000-0000-0000-000000000001"
        assert _is_public_form_file({"storage_path": f"public-form/{event_id}"}) is True

    def test_does_not_match_a_real_uploaded_file_path(self):
        from services.consolidation_service import _is_public_form_file
        assert _is_public_form_file({"storage_path": "evt-1/file-1/registrations.xlsx"}) is False

    def test_handles_missing_storage_path(self):
        from services.consolidation_service import _is_public_form_file
        assert _is_public_form_file({}) is False


class TestPublicFormPurgeSafety:
    """2026-08-01 audit: the stale-copy purge (cleanup_stale_source_records)
    deletes any source_record whose file was parsed this run but whose id
    wasn't (re)read by it. Public-form rows are inserted exactly once by the
    router and never re-inserted -- so a submission landing DURING a run
    (after step 3 read the virtual file, before the purge) looked exactly
    like a stray and was permanently deleted: a visitor's registration
    silently destroyed. Same fate for rows beyond the unpaginated read's
    1000-row PostgREST cap. The fix: public-form files are excluded from the
    purge scope, the read is paginated, and the end of each run counts the
    file's rows again to chain a follow-up run for late arrivals."""

    EVENT_ID = "00000000-0000-0000-0000-0000000000e1"

    def test_purge_scope_excludes_public_form_files(self):
        from services.consolidation_service import _purge_scope
        mapped_files = [
            {"id": "f-excel", "storage_path": "evt/f-excel/reg.xlsx"},
            {"id": "f-form", "storage_path": f"public-form/{self.EVENT_ID}"},
        ]
        scope = _purge_scope(mapped_files, {"f-excel", "f-form"})
        assert scope == {"f-excel"}

    def test_purge_scope_keeps_normal_files_untouched(self):
        from services.consolidation_service import _purge_scope
        mapped_files = [{"id": "f1", "storage_path": "evt/f1/a.xlsx"}]
        assert _purge_scope(mapped_files, {"f1", "f2"}) == {"f1", "f2"}

    def test_load_public_form_record_ids_paginates_past_1000(self):
        from services.consolidation_service import _load_public_form_record_ids

        page1 = [{"id": f"sr-{i}"} for i in range(1000)]
        page2 = [{"id": "sr-1000"}, {"id": "sr-1001"}]
        mock_supabase = MagicMock()
        chain = mock_supabase.table.return_value.select.return_value.eq.return_value.order.return_value.order.return_value.range.return_value.execute
        chain.side_effect = [MagicMock(data=page1), MagicMock(data=page2)]

        ids = _load_public_form_record_ids(mock_supabase, "f-form")

        assert len(ids) == 1002
        assert ids[0] == "sr-0" and ids[-1] == "sr-1001"

    def test_late_submissions_detected_when_count_grew(self):
        from services.consolidation_service import _late_public_form_submissions

        mock_supabase = MagicMock()
        files_exec = mock_supabase.table.return_value.select.return_value.eq.return_value.eq.return_value.execute
        files_exec.return_value.data = [{"id": "f-form"}]
        count_exec = mock_supabase.table.return_value.select.return_value.eq.return_value.limit.return_value.execute
        count_exec.return_value.count = 5

        assert _late_public_form_submissions(mock_supabase, self.EVENT_ID, {"f-form": 3}) is True
        assert _late_public_form_submissions(mock_supabase, self.EVENT_ID, {"f-form": 5}) is False

    def test_late_submissions_detected_for_file_created_mid_run(self):
        """First-ever submission arriving mid-run creates the virtual file
        itself -- it was never in mapped_files, so its count baseline is 0."""
        from services.consolidation_service import _late_public_form_submissions

        mock_supabase = MagicMock()
        files_exec = mock_supabase.table.return_value.select.return_value.eq.return_value.eq.return_value.execute
        files_exec.return_value.data = [{"id": "f-brand-new"}]
        count_exec = mock_supabase.table.return_value.select.return_value.eq.return_value.limit.return_value.execute
        count_exec.return_value.count = 1

        assert _late_public_form_submissions(mock_supabase, self.EVENT_ID, {}) is True

    def test_late_submissions_check_failure_is_not_fatal(self):
        from services.consolidation_service import _late_public_form_submissions

        mock_supabase = MagicMock()
        mock_supabase.table.side_effect = RuntimeError("db down")
        assert _late_public_form_submissions(mock_supabase, self.EVENT_ID, {}) is False


class TestSystemicMappingAnomalyDetection:
    """Mapping-health phase 1 (2026-08-01): when a coverage gap or missing
    profile field hits >= 90% of an event's participants (min 20), it is
    almost never real data -- it's a column mapping that silently routed the
    data to the wrong field (the July incidents: 600 transfer rows -> 0
    transfers; a Country column -> 300 blank nationalities, zero signal
    either time). Such gaps escalate from an info card to a warning that
    tells the organizer to check the source file's mapping, and carry a
    context_data.systemic_anomaly marker the frontend routes to a dedicated
    'Anomalie de mapping suspectée' filter chip."""

    EVENT_ID = "00000000-0000-0000-0000-0000000000e1"

    # -- _is_systemic threshold arithmetic ---------------------------------
    def test_is_systemic_above_ratio_and_population(self):
        from services.exception_service import _is_systemic
        assert _is_systemic(19, 20) is True      # 95%
        assert _is_systemic(270, 300) is True    # 90% exactly

    def test_not_systemic_below_ratio(self):
        from services.exception_service import _is_systemic
        assert _is_systemic(10, 100) is False    # 10%
        assert _is_systemic(267, 300) is False   # 89%

    def test_not_systemic_on_tiny_events(self):
        """A 5-person test event with 5/5 missing hotels is normal setup
        noise, not a mapping alarm."""
        from services.exception_service import _is_systemic
        assert _is_systemic(19, 19) is False
        assert _is_systemic(5, 5) is False

    # -- coverage detector escalation --------------------------------------
    def _coverage_supabase(self, people):
        mock_supabase = MagicMock()
        mock_supabase.table.return_value.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = people
        return mock_supabase

    def _people(self, n):
        return [{"id": f"p{i}", "first_name": "A", "last_name": f"B{i}"} for i in range(n)]

    def test_coverage_gap_on_everyone_escalates_to_warning(self):
        from services.exception_service import _aggregate_coverage_exception

        collected: list[dict] = []
        _aggregate_coverage_exception(
            self.EVENT_ID, "run-1", self._coverage_supabase(self._people(285)), collected,
            flag="has_transfer", exception_type="MISSING_REQUIRED_FIELD",
            message_fr="{count} participant(s) n'ont pas encore de transfert.",
            total_participants=300,
        )

        assert len(collected) == 1
        exc = collected[0]
        assert exc["severity"] == "warning"
        assert exc["context_data"]["systemic_anomaly"] is True
        assert exc["context_data"]["total_participants"] == 300
        assert "mapping" in exc["message"]

    def test_normal_coverage_gap_stays_info(self):
        from services.exception_service import _aggregate_coverage_exception

        collected: list[dict] = []
        _aggregate_coverage_exception(
            self.EVENT_ID, "run-1", self._coverage_supabase(self._people(30)), collected,
            flag="has_transfer", exception_type="MISSING_REQUIRED_FIELD",
            message_fr="{count} participant(s) n'ont pas encore de transfert.",
            total_participants=300,
        )

        assert len(collected) == 1
        exc = collected[0]
        assert exc["severity"] == "info"
        assert "systemic_anomaly" not in (exc["context_data"] or {})
        assert "mapping" not in exc["message"]

    def test_full_gap_on_tiny_event_stays_info(self):
        from services.exception_service import _aggregate_coverage_exception

        collected: list[dict] = []
        _aggregate_coverage_exception(
            self.EVENT_ID, "run-1", self._coverage_supabase(self._people(5)), collected,
            flag="has_hotel", exception_type="PARTICIPANT_NO_HOTEL",
            message_fr="{count} participant(s) n'ont pas encore d'hébergement.",
            total_participants=5,
        )

        assert collected[0]["severity"] == "info"

    # -- missing-profile-field detector escalation --------------------------
    def test_field_missing_on_everyone_adds_one_aggregate_warning(self):
        from services.exception_service import _detect_missing_profile_fields

        # 25 participants, every one of them with a name+email but NO
        # nationality -- the exact shape of the July "Country column routed
        # to an internal field" incident.
        participants = [
            {"id": f"p{i}", "first_name": "A", "last_name": f"B{i}",
             "email": f"a{i}@x.com", "phone": "+32 1", "nationality": "",
             "dietary_requirements": "aucun"}
            for i in range(25)
        ]
        mock_supabase = MagicMock()
        mock_supabase.table.return_value.select.return_value.eq.return_value.execute.return_value.data = participants

        collected: list[dict] = []
        _detect_missing_profile_fields(
            self.EVENT_ID, "run-1", mock_supabase, collected, total_participants=25
        )

        systemic = [e for e in collected if (e.get("context_data") or {}).get("systemic_anomaly")]
        individual = [e for e in collected if not (e.get("context_data") or {}).get("systemic_anomaly")]
        assert len(individual) == 25  # per-person cards unchanged
        assert len(systemic) == 1
        agg = systemic[0]
        assert agg["severity"] == "warning"
        assert agg["context_data"]["field"] == "nationality"
        assert agg["context_data"]["missing_count"] == 25
        assert agg["participant_id"] is None
        assert "mapping" in agg["message"]

    def test_scattered_missing_fields_add_no_aggregate(self):
        from services.exception_service import _detect_missing_profile_fields

        # 25 participants, only 3 missing a phone: normal life, no alarm.
        participants = [
            {"id": f"p{i}", "first_name": "A", "last_name": f"B{i}",
             "email": f"a{i}@x.com", "phone": "" if i < 3 else "+32 1",
             "nationality": "BE", "dietary_requirements": "aucun"}
            for i in range(25)
        ]
        mock_supabase = MagicMock()
        mock_supabase.table.return_value.select.return_value.eq.return_value.execute.return_value.data = participants

        collected: list[dict] = []
        _detect_missing_profile_fields(
            self.EVENT_ID, "run-1", mock_supabase, collected, total_participants=25
        )

        assert not [e for e in collected if (e.get("context_data") or {}).get("systemic_anomaly")]
        assert len(collected) == 3


class TestAIArbitrationNeverAutoMerges:
    """PROP-001 (applied 2026-08-01, explicit go-ahead in chat): the AI
    arbitration step used to call _merge_participant_into directly for
    'fusionner' verdicts with self-declared confidence >= 75 -- a
    destructive, irreversible merge (the losing fiche is DELETEd) with no
    human in the loop, violating the audit brief's non-negotiable 'the AI
    never autonomously decides participant data outcomes'. Every
    non-'separer' verdict must now land in the match_candidates queue for
    side-by-side human review, whatever the confidence."""

    EVENT_ID = "00000000-0000-0000-0000-0000000000e1"

    def _two_ambiguous_participants(self):
        # token_set_ratio('jean dupont', 'jean dupond') ~= 90.9: inside the
        # ambiguous band [78, 93) so the pair reaches the LLM arbitration.
        return [
            {"id": "p-a", "first_name": "Jean", "last_name": "Dupont", "email": "",
             "phone": "", "company": "", "nationality": "", "has_flight": True,
             "has_hotel": False, "has_transfer": False, "has_activities": False,
             "registration_source_id": "sr-1"},
            {"id": "p-b", "first_name": "Jean", "last_name": "Dupond", "email": "",
             "phone": "", "company": "", "nationality": "", "has_flight": False,
             "has_hotel": False, "has_transfer": False, "has_activities": False,
             "registration_source_id": None},
        ]

    def _mocked_supabase(self):
        mock_supabase = MagicMock()
        participants_page = MagicMock()
        participants_page.data = self._two_ambiguous_participants()
        mock_supabase.table.return_value.select.return_value.eq.return_value.range.return_value.execute.return_value = participants_page
        return mock_supabase

    def test_high_confidence_fusionner_is_queued_not_merged(self):
        from services import consolidation_service

        with patch("services.arbitration_service.arbitrate_pair") as mock_arb, \
             patch("services.arbitration_service.create_candidate") as mock_queue, \
             patch("services.consolidation_service._merge_participant_into") as mock_merge:
            mock_arb.return_value = {"decision": "fusionner", "confidence": 99.0, "justification": "quasi certain"}
            mock_queue.return_value = True

            result = consolidation_service.detect_ambiguous_duplicate_participants(
                self.EVENT_ID, "run-1", "user-1", self._mocked_supabase()
            )

        mock_merge.assert_not_called()
        mock_queue.assert_called_once()
        assert result == {"auto_merged": 0, "candidates": 1}

    def test_separer_verdict_is_dropped_without_queueing(self):
        from services import consolidation_service

        with patch("services.arbitration_service.arbitrate_pair") as mock_arb, \
             patch("services.arbitration_service.create_candidate") as mock_queue, \
             patch("services.consolidation_service._merge_participant_into") as mock_merge:
            mock_arb.return_value = {"decision": "separer", "confidence": 90.0, "justification": "deux personnes"}

            result = consolidation_service.detect_ambiguous_duplicate_participants(
                self.EVENT_ID, "run-1", "user-1", self._mocked_supabase()
            )

        mock_merge.assert_not_called()
        mock_queue.assert_not_called()
        assert result == {"auto_merged": 0, "candidates": 0}


class TestPublicFormDebounce:
    """Anti-burst pacing for the per-submission consolidation trigger: runs
    stay >= 60s apart during a registration wave instead of one full
    master-list rebuild per submission."""

    def test_no_wait_when_no_previous_run(self):
        from routers.public_registration import _debounce_wait_seconds
        from datetime import datetime, timezone
        assert _debounce_wait_seconds(None, datetime.now(timezone.utc)) == 0.0

    def test_no_wait_when_previous_run_is_old(self):
        from routers.public_registration import _debounce_wait_seconds
        from datetime import datetime, timezone, timedelta
        now = datetime.now(timezone.utc)
        old = (now - timedelta(minutes=10)).isoformat()
        assert _debounce_wait_seconds(old, now) == 0.0

    def test_waits_out_the_remainder_when_previous_run_is_fresh(self):
        from routers.public_registration import _debounce_wait_seconds
        from datetime import datetime, timezone, timedelta
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(seconds=20)).isoformat()
        wait = _debounce_wait_seconds(recent, now)
        assert 39.0 < wait <= 40.0

    def test_future_timestamp_from_clock_skew_means_no_wait(self):
        from routers.public_registration import _debounce_wait_seconds
        from datetime import datetime, timezone, timedelta
        now = datetime.now(timezone.utc)
        future = (now + timedelta(seconds=30)).isoformat()
        assert _debounce_wait_seconds(future, now) == 0.0

    def test_unparsable_timestamp_means_no_wait(self):
        from routers.public_registration import _debounce_wait_seconds
        from datetime import datetime, timezone
        assert _debounce_wait_seconds("not-a-date", datetime.now(timezone.utc)) == 0.0


class TestGlobalExceptionHandlerCors:
    """Starlette serves the catch-all Exception handler from
    ServerErrorMiddleware, OUTSIDE CORSMiddleware -- so unhandled 500s used
    to reach the browser without CORS headers and surface as an opaque
    'Failed to fetch' (exactly what obscured the 2026-07 hotel 500).
    _cors_headers_for echoes the origin iff the middleware would allow it."""

    def _request_with_origin(self, origin):
        req = MagicMock()
        req.headers = {"origin": origin} if origin else {}
        return req

    def test_allowed_origin_is_echoed(self):
        from main import _cors_headers_for
        headers = _cors_headers_for(self._request_with_origin("https://web-beta-seven-wurgbjii1c.vercel.app"))
        assert headers["Access-Control-Allow-Origin"] == "https://web-beta-seven-wurgbjii1c.vercel.app"
        assert headers["Access-Control-Allow-Credentials"] == "true"

    def test_localhost_dev_origin_is_echoed(self):
        from main import _cors_headers_for
        headers = _cors_headers_for(self._request_with_origin("http://localhost:3000"))
        assert headers.get("Access-Control-Allow-Origin") == "http://localhost:3000"

    def test_unknown_origin_gets_no_cors_headers(self):
        from main import _cors_headers_for
        assert _cors_headers_for(self._request_with_origin("https://evil.example.com")) == {}

    def test_no_origin_header_gets_no_cors_headers(self):
        from main import _cors_headers_for
        assert _cors_headers_for(self._request_with_origin(None)) == {}

    def test_regex_does_not_match_lookalike_suffix_domain(self):
        """fullmatch, not search: 'https://x.vercel.app.evil.com' must NOT pass."""
        from main import _cors_headers_for
        assert _cors_headers_for(self._request_with_origin("https://x.vercel.app.evil.com")) == {}



# ---------------------------------------------------------------------------
# Project-scoped conversational assistant (Feedback V1 §7)
# ---------------------------------------------------------------------------

class TestChatbotAssistant:
    """The client's hard constraint for §7 is that the assistant answers ONLY
    from project data and says so when something is unavailable -- it must
    never invent. These tests pin that down: figures come from the database,
    the LLM is confined to routing (it never sees data and never phrases an
    answer), unknown questions are refused outright, and an ambiguous name is
    never silently resolved to the closest stranger."""

    EVENT_ID = "00000000-0000-0000-0000-0000000000e1"

    def _people(self):
        def p(pid, first, last, flight, hotel, transfer, activity, **kw):
            return {
                "id": pid, "first_name": first, "last_name": last,
                "email": kw.get("email", f"{first.lower()}@x.com"),
                "company": kw.get("company", "ACME"), "phone": kw.get("phone", "+32 1"),
                "nationality": kw.get("nationality", "BE"),
                "dietary_requirements": kw.get("dietary", "halal"),
                "completeness_status": "complete",
                "has_flight": flight, "has_hotel": hotel,
                "has_transfer": transfer, "has_activities": activity,
            }
        return [
            p("p1", "Ana", "Kaya", True, True, False, True),      # vol sans transfert
            p("p2", "Bruno", "Costa", True, False, True, True),   # sans hebergement
            p("p3", "Chloe", "Nilsson", False, True, True, False, phone=""),
        ]

    def _supabase(self, *, exceptions=None, communications=None, candidates=None,
                  communications_raises=False):
        mock = MagicMock()
        people = self._people()

        participants_mock = MagicMock()
        participants_mock.select.return_value.eq.return_value.order.return_value.order.return_value.range.return_value.execute.return_value.data = people

        exceptions_mock = MagicMock()
        exc = exceptions if exceptions is not None else []
        # per-participant chain: select -> eq -> eq -> eq -> order -> execute
        exceptions_mock.select.return_value.eq.return_value.eq.return_value.eq.return_value.order.return_value.execute.return_value.data = exc
        # conflicts chain: select -> eq -> eq -> eq -> execute
        exceptions_mock.select.return_value.eq.return_value.eq.return_value.eq.return_value.execute.return_value.data = exc
        # today-actions chain: select -> eq -> eq -> execute
        exceptions_mock.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = exc

        comms_mock = MagicMock()
        if communications_raises:
            comms_mock.select.return_value.eq.return_value.neq.return_value.execute.side_effect = RuntimeError("no table")
        else:
            comms_mock.select.return_value.eq.return_value.neq.return_value.execute.return_value.data = communications or []

        cand_mock = MagicMock()
        cand_mock.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = candidates or []

        tables = {
            "participants": participants_mock, "exceptions": exceptions_mock,
            "communications": comms_mock, "match_candidates": cand_mock,
        }
        mock.table.side_effect = lambda name: tables.get(name, MagicMock())
        return mock

    def _ask(self, question, role="admin", **kw):
        from services import chatbot_service
        return chatbot_service.answer_question(
            question, self.EVENT_ID, self._supabase(**kw), user_role=role
        )

    # -- figures come from the data, not from a model ----------------------
    def test_without_flight_counts_real_rows(self):
        r = self._ask("Quels participants n'ont pas de vol ?")
        assert r["answered"] is True
        assert r["intent"] == "participants_without_flight"
        assert "1 participant" in r["answer"]
        assert [row["nom"] for row in r["rows"]] == ["Chloe Nilsson"]

    def test_without_hotel_counts_real_rows(self):
        r = self._ask("Quels participants n'ont pas encore d'hotel ?")
        assert r["intent"] == "participants_without_hotel"
        assert [row["nom"] for row in r["rows"]] == ["Bruno Costa"]

    def test_flight_but_no_transfer_is_a_real_cross_check(self):
        r = self._ask("Quels participants ont un vol mais aucun transfert ?")
        assert r["intent"] == "participants_with_flight_no_transfer"
        assert [row["nom"] for row in r["rows"]] == ["Ana Kaya"]

    def test_without_activity_counts_real_rows(self):
        r = self._ask("Quels participants n'ont pas d'activite ?")
        assert r["intent"] == "participants_without_activity"
        assert [row["nom"] for row in r["rows"]] == ["Chloe Nilsson"]

    # -- the refusal path is the whole point -------------------------------
    def test_out_of_scope_question_is_refused_not_guessed(self):
        from services import chatbot_service
        with patch("services.ai_service.ai_json", return_value=None):
            r = chatbot_service.answer_question(
                "Quelle est la capitale du Japon ?", self.EVENT_ID, self._supabase()
            )
        assert r["answered"] is False
        assert r["intent"] is None
        assert r["rows"] == []
        assert "ne peux pas" in r["answer"]

    def test_llm_may_not_invent_an_intent_outside_the_registry(self):
        """A routing model that hallucinates an intent name must be ignored,
        not trusted into a KeyError or an arbitrary query."""
        from services import chatbot_service
        with patch("services.ai_service.ai_json",
                   return_value={"intent": "delete_everything", "participant_name": ""}):
            r = chatbot_service.answer_question(
                "fais un truc bizarre", self.EVENT_ID, self._supabase()
            )
        assert r["answered"] is False
        assert r["intent"] is None

    def test_unknown_participant_is_reported_not_approximated(self):
        r = self._ask("Quelles informations manquent pour Zbigniew Nowak ?")
        assert r["answered"] is True
        assert "ne trouve aucun participant" in r["answer"]
        assert r["rows"] == []

    def test_missing_data_source_is_admitted_not_filled_in(self):
        """Communications table absent (migration not applied) -> say so."""
        r = self._ask("Quels clients doivent encore recevoir un e-mail ?",
                      communications_raises=True)
        assert "pas acc" in r["answer"]      # "n'ai pas acces"
        assert r["rows"] == []

    # -- per-participant answers -------------------------------------------
    def test_missing_info_for_a_named_participant(self):
        r = self._ask("Quelles informations manquent pour Chloe Nilsson ?")
        assert r["intent"] == "participant_missing_info"
        assert "Chloe Nilsson" in r["answer"]
        assert "phone" in r["answer"] or "l" in r["answer"]  # telephone listed
        assert "vol" in r["answer"]

    def test_participant_exceptions_reads_the_exceptions_table(self):
        excs = [{"exception_type": "DATA_CONFLICT", "severity": "warning",
                 "message": "Nom divergent entre deux sources", "created_at": "2026-08-01"}]
        r = self._ask("Pourquoi Ana Kaya est-elle signalee en exception ?", exceptions=excs)
        assert r["intent"] == "participant_exceptions"
        assert "1 exception" in r["answer"]
        assert r["rows"][0]["message"] == "Nom divergent entre deux sources"

    # -- RGPD: the assistant must not become a side channel ----------------
    def test_dietary_is_hidden_from_non_staff_roles(self):
        r = self._ask("Donne-moi la fiche de Ana Kaya", role="client")
        assert r["intent"] == "participant_detail"
        assert all("dietary_requirements" not in row for row in r["rows"])

    def test_dietary_is_visible_to_staff(self):
        r = self._ask("Donne-moi la fiche de Ana Kaya", role="pm")
        assert r["rows"][0]["dietary_requirements"] == "halal"

    # -- routing behaviour --------------------------------------------------
    def test_canonical_questions_answer_without_any_provider(self):
        """Every suggestion chip must still answer when no AI provider is
        reachable. The filter chips route offline through _keyword_route; the
        advisory chip falls back to the computed digest. Either way a chip
        never depends on a model being up."""
        from services import chatbot_service
        with patch("services.ai_service.ai_json", return_value=None), \
             patch("services.ai_service.ai_text", return_value=None):
            for q in chatbot_service.SUGGESTED_QUESTIONS:
                r = chatbot_service.answer_question(q, self.EVENT_ID, self._supabase())
                assert r["answered"] is True, q
                assert r["intent"] is not None, q

    def test_filter_chips_still_need_no_model_at_all(self):
        """The narrower invariant: the filter chips must not even reach the
        routing model — no latency, no provider in the path."""
        from services import chatbot_service
        filter_chips = [q for q in chatbot_service.SUGGESTED_QUESTIONS
                        if not chatbot_service._looks_advisory(q)]
        assert len(filter_chips) >= 5
        with patch("services.ai_service.ai_json",
                   side_effect=AssertionError("LLM must not be called")):
            for q in filter_chips:
                r = chatbot_service.answer_question(q, self.EVENT_ID, self._supabase())
                assert r["answered"] is True, q
                assert r["intent"] is not None, q

    def test_llm_routing_is_used_for_free_form_phrasings(self):
        from services import chatbot_service
        with patch("services.ai_service.ai_json",
                   return_value={"intent": "event_overview", "participant_name": ""}) as mock_ai:
            r = chatbot_service.answer_question(
                "dis moi ou on en est globalement", self.EVENT_ID, self._supabase()
            )
        mock_ai.assert_called_once()
        assert r["intent"] == "event_overview"
        assert r["rows"][0]["participants"] == 3

    def test_every_answer_cites_its_sources(self):
        from services import chatbot_service
        for q in chatbot_service.SUGGESTED_QUESTIONS:
            r = chatbot_service.answer_question(q, self.EVENT_ID, self._supabase())
            assert r["references"], q

    def test_today_actions_rolls_up_real_counts(self):
        r = self._ask("Quelles actions doivent etre realisees aujourd'hui ?",
                      candidates=[{"id": "c1"}])
        assert r["intent"] == "today_actions"
        actions = {row["action"]: row["nombre"] for row in r["rows"]}
        assert any("sans vol" in a for a in actions)
        assert any("sans h" in a for a in actions)            # sans hébergement
        assert any("fusions" in a for a in actions)           # pending match candidate
        assert all(isinstance(n, int) and n > 0 for n in actions.values())

    def test_a_failing_query_never_produces_a_confident_answer(self):
        from services import chatbot_service
        broken = MagicMock()
        broken.table.side_effect = RuntimeError("db down")
        r = chatbot_service.answer_question(
            "Quels participants n'ont pas de vol ?", self.EVENT_ID, broken
        )
        assert r["answered"] is False
        assert r["rows"] == []


class TestConsolidationStepOrdering:
    """2026-08-03, Sales Convention 2027: a first consolidation reported
    "300 participants sans hebergement" and "300 sans transfert" as suspected
    mapping anomalies, while the database had all 300 correctly covered.

    Cause: exception detection ran BEFORE extract_domain_data_from_sources,
    which is the step that sets has_flight/has_hotel/has_transfer/
    has_activities -- so the coverage detectors read flags that were still
    all-false and about to be filled one step later. Harmless-looking noise
    until those gaps started escalating to warnings that tell the organizer
    to go re-check a mapping that was fine; a false alarm of that kind is
    worse than no alarm, because it teaches people to ignore the real ones.

    Extraction now runs first. _update_completeness_statuses still runs last,
    since it depends on the DATA_CONFLICT exceptions detection writes."""

    def _source_order(self):
        import inspect
        from services import consolidation_service
        src = inspect.getsource(consolidation_service.run_consolidation)
        return (
            src.index("extract_domain_data_from_sources(event_id, supabase)"),
            src.index("exception_service.detect_all("),
            src.index("_update_completeness_statuses(event_id, supabase)"),
        )

    def test_domain_extraction_runs_before_exception_detection(self):
        extract_at, detect_at, _ = self._source_order()
        assert extract_at < detect_at, (
            "extract_domain_data_from_sources must run before detect_all, "
            "otherwise the coverage detectors read stale has_* flags"
        )

    def test_completeness_update_runs_after_exception_detection(self):
        _, detect_at, completeness_at = self._source_order()
        assert detect_at < completeness_at, (
            "_update_completeness_statuses reads the DATA_CONFLICT exceptions "
            "that detect_all writes, so it must stay after it"
        )


class TestChatbotQueryPlanner:
    """Tier 2 of the assistant: the model translates a free-form question into
    a STRUCTURED filter spec, which this code validates and executes over real
    rows. That is what lets it answer combinations nobody hard-coded, without
    ever letting it state a fact.

    The tests that matter most here are the negative ones: an invented field,
    an invented operator, or a phrased answer containing a number that is not
    in the computed facts must all be rejected rather than served."""

    EVENT_ID = "00000000-0000-0000-0000-0000000000e1"

    def _people(self):
        def p(pid, first, last, nat, comp, flight, hotel, transfer, activity):
            return {
                "id": pid, "first_name": first, "last_name": last,
                "email": f"{first.lower()}@x.com", "company": comp, "phone": "+32 1",
                "nationality": nat, "dietary_requirements": "halal",
                "completeness_status": "complete", "has_flight": flight,
                "has_hotel": hotel, "has_transfer": transfer, "has_activities": activity,
            }
        return [
            p("p1", "Ana", "Kaya", "Belgique", "ACME", True, True, False, True),
            p("p2", "Bruno", "Costa", "France", "ACME", True, False, True, True),
            p("p3", "Chloe", "Nilsson", "Belgique", "Zenith", False, True, True, False),
            p("p4", "Dan", "Meyer", "France", "Zenith", True, True, False, False),
        ]

    def _supabase(self):
        mock = MagicMock()
        pm = MagicMock()
        pm.select.return_value.eq.return_value.order.return_value.order.return_value.range.return_value.execute.return_value.data = self._people()
        mock.table.side_effect = lambda name: pm if name == "participants" else MagicMock()
        return mock

    # -- validation: the allowlist is the safety boundary -------------------
    def test_valid_plan_is_accepted(self):
        from services.chatbot_service import _validate_plan
        plan = _validate_plan(
            {"filters": [{"field": "has_transfer", "op": "is", "value": False}],
             "output": "count"}, "admin")
        assert plan is not None
        assert plan["filters"][0]["field"] == "has_transfer"

    def test_invented_field_is_rejected(self):
        from services.chatbot_service import _validate_plan
        assert _validate_plan(
            {"filters": [{"field": "salary", "op": "is", "value": 1}]}, "admin") is None

    def test_invented_operator_is_rejected(self):
        from services.chatbot_service import _validate_plan
        assert _validate_plan(
            {"filters": [{"field": "nationality", "op": "DROP TABLE", "value": "x"}]},
            "admin") is None

    def test_garbage_plan_is_rejected(self):
        from services.chatbot_service import _validate_plan
        for junk in (None, [], "hello", {"filters": "nope"}, {"filters": [42]}):
            assert _validate_plan(junk, "admin") is None

    def test_group_by_must_also_be_an_allowed_field(self):
        from services.chatbot_service import _validate_plan
        assert _validate_plan({"filters": [], "output": "group",
                               "group_by": "secret"}, "admin") is None
        assert _validate_plan({"filters": [], "output": "group",
                               "group_by": "nationality"}, "admin") is not None

    def test_dietary_is_not_plannable_for_non_staff(self):
        """RGPD: the planner must not become a way to filter on a field the
        rest of the app hides from this role."""
        from services.chatbot_service import _validate_plan
        spec = {"filters": [{"field": "dietary_requirements", "op": "contains", "value": "halal"}]}
        assert _validate_plan(spec, "client") is None
        assert _validate_plan(spec, "pm") is not None

    # -- execution: real filtering over real rows ---------------------------
    def _run(self, plan, role="admin"):
        from services.chatbot_service import _execute_plan, _validate_plan
        validated = _validate_plan(plan, role)
        assert validated is not None, plan
        return _execute_plan(validated, self._people(), role)

    def test_combined_filters_are_applied(self):
        r = self._run({"filters": [
            {"field": "has_flight", "op": "is", "value": True},
            {"field": "has_transfer", "op": "is", "value": False},
        ], "logic": "and", "output": "list"})
        assert r["total"] == 2
        assert {row["nom"] for row in r["rows"]} == {"Ana Kaya", "Dan Meyer"}

    def test_or_logic_is_applied(self):
        r = self._run({"filters": [
            {"field": "nationality", "op": "is", "value": "France"},
            {"field": "company", "op": "is", "value": "Zenith"},
        ], "logic": "or", "output": "list"})
        assert r["total"] == 3           # Bruno, Dan (FR) + Chloe (Zenith)

    def test_in_operator(self):
        r = self._run({"filters": [
            {"field": "nationality", "op": "in", "value": ["France", "Belgique"]},
        ], "output": "count"})
        assert r["total"] == 4

    def test_grouping_counts_real_buckets(self):
        r = self._run({"filters": [], "output": "group", "group_by": "nationality"})
        assert r["kind"] == "group"
        assert {b["nationality"]: b["participants"] for b in r["rows"]} == {
            "Belgique": 2, "France": 2}

    def test_execution_strips_dietary_for_non_staff(self):
        r = self._run({"filters": [{"field": "has_flight", "op": "is", "value": True}],
                       "output": "list"}, role="client")
        assert all("dietary_requirements" not in row for row in r["rows"])

    # -- the phrasing guard -------------------------------------------------
    def test_generated_answer_with_an_invented_number_is_discarded(self):
        """The whole point: if the phrasing model drifts into a figure that is
        not in the computed facts, we serve the deterministic template."""
        from services import chatbot_service
        with patch("services.ai_service.ai_text", return_value="Il y a 47 participants concernés."):
            out = chatbot_service._phrase("combien ?", {"resultats": 2}, "2 participant(s).")
        assert out == "2 participant(s)."

    def test_generated_answer_with_grounded_numbers_is_kept(self):
        from services import chatbot_service
        with patch("services.ai_service.ai_text", return_value="2 participants sont concernés."):
            out = chatbot_service._phrase("combien ?", {"resultats": 2}, "fallback")
        assert out == "2 participants sont concernés."

    def test_phrasing_without_numbers_is_kept(self):
        from services import chatbot_service
        with patch("services.ai_service.ai_text", return_value="Personne n'est concerné."):
            out = chatbot_service._phrase("combien ?", {"resultats": 0}, "fallback")
        assert out == "Personne n'est concerné."

    def test_phrasing_failure_falls_back_to_template(self):
        from services import chatbot_service
        for bad in (None, "", "   "):
            with patch("services.ai_service.ai_text", return_value=bad):
                assert chatbot_service._phrase("q", {"resultats": 1}, "template") == "template"
        with patch("services.ai_service.ai_text", side_effect=RuntimeError("provider down")):
            assert chatbot_service._phrase("q", {"resultats": 1}, "template") == "template"

    def test_numbers_are_grounded_helper(self):
        from services.chatbot_service import _numbers_are_grounded
        assert _numbers_are_grounded("il y en a 12", '{"n": 12}')
        assert not _numbers_are_grounded("il y en a 13", '{"n": 12}')
        assert _numbers_are_grounded("aucun resultat", '{"n": 0}')

    # -- end to end through answer_question ---------------------------------
    def test_complex_question_is_answered_via_the_planner(self):
        from services import chatbot_service
        plan_json = ('{"filters":[{"field":"nationality","op":"is","value":"Belgique"},'
                     '{"field":"has_transfer","op":"is","value":false}],'
                     '"logic":"and","output":"list"}')
        # First ai_text call is the planner; the second is the phrasing, which
        # we let fail so the deterministic template is used.
        with patch("services.ai_service.ai_json", return_value=None), \
             patch("services.ai_service.ai_text", side_effect=[plan_json, None]):
            r = chatbot_service.answer_question(
                "les belges qui n'ont pas de transfert", self.EVENT_ID, self._supabase(),
                user_role="admin")
        assert r["answered"] is True
        assert r["intent"] == "query_plan"
        assert [row["nom"] for row in r["rows"]] == ["Ana Kaya"]
        assert r["references"]

    def test_concept_question_becomes_an_in_filter_over_real_values(self):
        """"Combien viennent d'Europe" only works if the model is shown the
        country names this dataset actually uses — otherwise it has to guess
        spellings. The catalogue is what makes concept questions answerable."""
        from services import chatbot_service
        plan_json = ('{"filters":[{"field":"nationality","op":"in",'
                     '"value":["Belgique","France"]}],"output":"count"}')
        with patch("services.ai_service.ai_json", return_value=None), \
             patch("services.ai_service.ai_text", side_effect=[plan_json, None]) as mock_text:
            r = chatbot_service.answer_question(
                "combien viennent d'europe", self.EVENT_ID, self._supabase(), user_role="admin")
        prompt = mock_text.call_args_list[0][0][0]
        assert "Belgique" in prompt and "France" in prompt   # catalogue was supplied
        assert r["answered"] is True
        assert r["rows"] and len(r["rows"]) == 4

    def test_value_catalogue_lists_real_values_only(self):
        from services.chatbot_service import _value_catalogue
        cat = _value_catalogue(self._people(), "admin")
        assert set(cat["nationality"]) == {"Belgique", "France"}
        assert set(cat["company"]) == {"ACME", "Zenith"}

    def test_value_catalogue_hides_dietary_from_non_staff(self):
        from services.chatbot_service import _value_catalogue
        assert "dietary_requirements" not in _value_catalogue(self._people(), "client")

    def test_unsupported_question_still_refuses(self):
        from services import chatbot_service
        with patch("services.ai_service.ai_json",
                   return_value={"filters": [], "output": "unsupported"}):
            r = chatbot_service.answer_question(
                "quelle est la capitale du Japon ?", self.EVENT_ID, self._supabase())
        assert r["answered"] is False
        assert r["rows"] == []

    def test_planner_hallucinating_a_field_ends_in_a_refusal_not_a_crash(self):
        from services import chatbot_service
        with patch("services.ai_service.ai_json",
                   return_value={"filters": [{"field": "salaire", "op": "is", "value": 1}]}):
            r = chatbot_service.answer_question(
                "qui gagne le plus ?", self.EVENT_ID, self._supabase())
        assert r["answered"] is False

    def test_provider_outage_says_so_instead_of_blaming_the_question(self):
        """2026-08-03: NVIDIA timed out and Gemini was out of credit, and the
        assistant answered "je ne peux pas répondre à cette question" — telling
        the user their perfectly valid question was out of scope. A provider
        outage is temporary and unrelated to what was asked; conflating the two
        sends people rewriting a question that was never the problem."""
        from services import chatbot_service
        with patch("services.ai_service.ai_json", return_value=None), \
             patch("services.ai_service.ai_text", return_value=None):
            r = chatbot_service.answer_question(
                "combien viennent d'europe", self.EVENT_ID, self._supabase())
        assert r["answered"] is False
        assert "service d'analyse" in r["answer"]
        assert "Réessayez" in r["answer"]
        assert "ce n'est pas elle qui pose problème" in r["answer"]

    def test_out_of_scope_question_still_lists_capabilities(self):
        """The other branch: the model understood and said it is unsupported.
        Retrying will never help, so say what IS answerable instead."""
        from services import chatbot_service
        with patch("services.ai_service.ai_json", return_value=None), \
             patch("services.ai_service.ai_text",
                   return_value='{"filters":[],"output":"unsupported"}'):
            r = chatbot_service.answer_question(
                "quelle est la capitale du Japon ?", self.EVENT_ID, self._supabase())
        assert r["answered"] is False
        assert "Je réponds sur" in r["answer"]
        assert "service d'analyse" not in r["answer"]

    def test_canonical_questions_still_bypass_the_planner(self):
        """Tier 1 must keep answering offline — the planner is a fallback, not
        a replacement, so the common questions stay instant."""
        from services import chatbot_service
        with patch("services.ai_service.ai_json", side_effect=AssertionError("no AI expected")), \
             patch("services.ai_service.ai_text", side_effect=AssertionError("no AI expected")):
            r = chatbot_service.answer_question(
                "Quels participants n'ont pas de vol ?", self.EVENT_ID, self._supabase())
        assert r["answered"] is True
        assert r["intent"] == "participants_without_flight"


class TestCompoundQuestionsNeverSilentlyLoseCriteria:
    """The worst failure mode this assistant can have is not a refusal — it is
    answering a narrower question than the one asked, confidently. "Les belges
    qui n'ont pas de transfert" contains the canonical phrase "pas de
    transfert", and tier-1 keyword routing used to seize it and reply with the
    full no-transfert list, silently dropping "belges". These pin the guard
    that sends such questions to the planner instead."""

    def test_extra_criteria_defeat_keyword_routing(self):
        from services.chatbot_service import _keyword_route
        assert _keyword_route("les belges qui n'ont pas de transfert") is None
        assert _keyword_route("participants de chez ACME sans hotel") is None
        assert _keyword_route("qui n'a pas de vol chez Zenith ?") is None

    def test_plain_canonical_questions_still_route_offline(self):
        from services.chatbot_service import _keyword_route
        assert _keyword_route("Quels participants n'ont pas de vol ?") == "participants_without_flight"
        assert _keyword_route("participants sans hebergement") == "participants_without_hotel"
        assert _keyword_route("qui n'a pas encore de transfert ?") == "participants_without_transfer"

    def test_every_suggested_question_still_routes_offline(self):
        """Each chip must reach its tier without a model deciding where it
        goes: the filter chips through _keyword_route, the advisory chip
        through _looks_advisory. A chip that matched neither would depend on
        the routing model being up."""
        from services import chatbot_service
        for q in chatbot_service.SUGGESTED_QUESTIONS:
            assert (chatbot_service._keyword_route(q) is not None
                    or chatbot_service._looks_advisory(q)), q

    def test_named_participant_questions_keep_their_extra_words(self):
        """A person's name IS extra text, and is the point — these intents
        must not be diverted by the compound check."""
        from services.chatbot_service import _keyword_route
        assert _keyword_route("Pourquoi Ana Kaya est-elle signalee en exception ?") == "participant_exceptions"
        assert _keyword_route("Quelles informations manquent pour Chloe Nilsson ?") == "participant_missing_info"


class TestCoverageCombinationsAnsweredWithoutAI:
    """2026-08-03: "ya combien de personne sans vols et sans hebergement" was
    answered with the plain no-flight list (62 people), silently dropping
    "sans hebergement". Two separate flaws:

      * domain vocabulary lived in ONE global filler set, so "hebergement"
        counted as noise even when the matched intent was about flights —
        the compound guard saw nothing left over and let it through;
      * "participants_with_flight_no_transfer" (pattern "vol ... sans ...
        transfert") also matches "SANS vol et sans transfert", answering the
        exact opposite of the question.

    Negating several coverage dimensions now composes locally, before any
    intent matching and without a model, so the commonest compound question
    is both correct and instant."""

    def _fields(self, question):
        from services.chatbot_service import _compose_coverage_plan
        composed = _compose_coverage_plan(question)
        return [f["field"] for f in composed[0]["filters"]] if composed else None

    def test_the_reported_question_composes_both_criteria(self):
        assert self._fields("ya combien de personne sans vols et sans hebergement") == [
            "has_flight", "has_hotel"]

    def test_sans_vol_et_sans_transfert_is_not_the_flight_but_no_transfer_intent(self):
        from services.chatbot_service import _keyword_route
        assert _keyword_route("combien sans vol et sans transfert") is None
        assert self._fields("combien sans vol et sans transfert") == [
            "has_flight", "has_transfer"]

    def test_ni_x_ni_y_construction(self):
        assert self._fields("qui n'a ni hotel ni activite") == ["has_hotel", "has_activities"]

    def test_three_dimensions(self):
        assert self._fields("sans vol, sans hotel et sans transfert") == [
            "has_flight", "has_hotel", "has_transfer"]

    def test_single_dimension_does_not_compose(self):
        assert self._fields("Quels participants n'ont pas de vol ?") is None
        assert self._fields("participants sans hebergement") is None

    def test_composition_outranks_keyword_routing(self):
        from services.chatbot_service import _keyword_route
        assert _keyword_route("sans vol et sans hebergement") is None

    def test_single_dimension_questions_still_route_offline(self):
        from services.chatbot_service import _keyword_route
        assert _keyword_route("Quels participants n'ont pas de vol ?") == "participants_without_flight"
        assert _keyword_route("participants sans hebergement") == "participants_without_hotel"

    def test_own_words_are_scoped_to_their_own_intent(self):
        """The root cause, pinned directly: a domain word belonging to another
        dimension must count as a leftover criterion."""
        from services.chatbot_service import _leftover_terms
        flight_words = {"vol", "vols"}
        # "sans vol" removed (span 0-8); "hebergement" must survive as a criterion
        assert "hebergement" in _leftover_terms("sans vol et sans hebergement", (0, 8), flight_words)
        # its own word does not
        assert _leftover_terms("sans vol", (0, 8), flight_words) == []

    def test_end_to_end_returns_both_criteria_and_needs_no_ai(self):
        from services import chatbot_service
        people = [
            {"id": "p1", "first_name": "A", "last_name": "X", "email": "a@x.com",
             "company": "", "phone": "", "nationality": "", "dietary_requirements": "",
             "completeness_status": "incomplete",
             "has_flight": False, "has_hotel": False, "has_transfer": True, "has_activities": True},
            {"id": "p2", "first_name": "B", "last_name": "Y", "email": "b@x.com",
             "company": "", "phone": "", "nationality": "", "dietary_requirements": "",
             "completeness_status": "incomplete",
             "has_flight": False, "has_hotel": True, "has_transfer": True, "has_activities": True},
        ]
        mock = MagicMock()
        pm = MagicMock()
        pm.select.return_value.eq.return_value.order.return_value.order.return_value.range.return_value.execute.return_value.data = people
        mock.table.side_effect = lambda n: pm if n == "participants" else MagicMock()

        with patch("services.ai_service.ai_json", side_effect=AssertionError("no AI expected")),              patch("services.ai_service.ai_text", side_effect=AssertionError("no AI expected")):
            r = chatbot_service.answer_question(
                "ya combien de personne sans vols et sans hebergement",
                "00000000-0000-0000-0000-0000000000e1", mock, user_role="admin")

        assert r["answered"] is True
        assert r["intent"] == "coverage_combination"
        assert len(r["rows"]) == 1 and r["rows"][0]["nom"] == "A X"   # only p1 lacks both
        assert "ni vol ni" in r["answer"]


class TestAirportColumnAutoMapping:
    """An "Aeroport" column with no direction in its header used to be a coin
    flip: values like "Paris CDG" were not recognised as airports at all (the
    detector only accepted a bare 3-letter code), so the column was dropped
    entirely; and when it WAS recognised, it always went to departure_airport
    regardless of what the file described. Two transfer files with the same
    column got two different fates in production (2026-08-03)."""

    def _map(self, columns, rows):
        from services.mapping_service import suggest_mapping
        return {c: v["suggested_field"] for c, v in suggest_mapping(columns, rows).items()}

    # -- fix 1: recognise "City CODE", not just "CODE" ---------------------
    def test_city_plus_code_is_recognised_as_an_airport(self):
        m = self._map(["Aeroport", "Type"],
                      [{"Aeroport": "Paris CDG", "Type": "Arrivee"}] * 4)
        assert m["Aeroport"] in ("arrival_airport", "departure_airport")

    def test_multiword_city_plus_code(self):
        m = self._map(["Aeroport", "Type"],
                      [{"Aeroport": "SAO PAULO GRU", "Type": "Arrivee"}] * 4)
        assert m["Aeroport"] == "arrival_airport"

    def test_bare_code_still_recognised(self):
        m = self._map(["Aeroport", "Vol"], [{"Aeroport": "CDG", "Vol": "AF123"}] * 4)
        assert m["Aeroport"] in ("arrival_airport", "departure_airport")

    # -- fix 2: direction comes from the file's own rows -------------------
    def test_arrival_file_maps_to_arrival_airport(self):
        m = self._map(["Aeroport", "Type"],
                      [{"Aeroport": "Paris CDG", "Type": "Arrivee"}] * 4)
        assert m["Aeroport"] == "arrival_airport"

    def test_departure_file_maps_to_departure_airport(self):
        m = self._map(["Aeroport", "Type"],
                      [{"Aeroport": "Paris CDG", "Type": "Depart"}] * 4)
        assert m["Aeroport"] == "departure_airport"

    def test_direction_hint_reads_the_dominant_value(self):
        from services.mapping_service import _transfer_direction_hint
        rows = [{"Type": "Arrivee"}] * 3 + [{"Type": "Depart"}]
        assert _transfer_direction_hint(["Type"], rows) == "arrival"
        rows = [{"Type": "Depart"}] * 3 + [{"Type": "Arrivee"}]
        assert _transfer_direction_hint(["Type"], rows) == "departure"

    def test_no_direction_column_yields_no_hint(self):
        from services.mapping_service import _transfer_direction_hint
        assert _transfer_direction_hint(["Vol"], [{"Vol": "AF123"}] * 3) is None

    # -- nothing else may change -------------------------------------------
    def test_explicit_headers_are_untouched_and_still_win(self):
        m = self._map(["Aeroport Arrivee", "Aeroport Depart"],
                      [{"Aeroport Arrivee": "CDG", "Aeroport Depart": "JFK"}] * 4)
        assert m["Aeroport Arrivee"] == "arrival_airport"
        assert m["Aeroport Depart"] == "departure_airport"

    def test_free_text_column_with_an_acronym_is_not_an_airport(self):
        """The guard that keeps a Notes column out of the flight data: the
        loose form requires a location-ish header. ("Remarques" is now
        recognised as the `comments` field — that is the point of the guard,
        that it lands anywhere BUT on an airport.)"""
        m = self._map(["Remarques", "Nom"],
                      [{"Remarques": "VIP GUEST", "Nom": "Ana Kaya"}] * 4)
        assert m["Remarques"] not in ("departure_airport", "arrival_airport")

    def test_unnamed_column_does_not_accept_the_loose_form(self):
        """A bare code is distinctive enough to stand alone on an unnamed
        column; a code embedded in text is not."""
        m = self._map(["", "Nom"], [{"": "Paris CDG", "Nom": "Ana"}] * 4)
        assert m[""] is None

    def test_looks_like_airport_label_helper(self):
        from services.mapping_service import _looks_like_airport_label
        assert _looks_like_airport_label("CDG")
        assert _looks_like_airport_label("Paris CDG")
        assert _looks_like_airport_label("SAO PAULO GRU")
        assert not _looks_like_airport_label("Paris")
        assert not _looks_like_airport_label("x" * 60 + " CDG")


class TestPlannerFastModelWithFallback:
    """The planner tries a small fast model first and re-runs the flagship when
    the fast answer fails validation. Speed must never be traded against
    correctness: a bad fast plan is rejected and retried, not served."""

    def test_fast_model_is_tried_first(self):
        from services import chatbot_service, ai_service
        good = '{"filters":[{"field":"has_flight","op":"is","value":false}],"output":"count"}'
        with patch("services.ai_service.ai_text", return_value=good) as mock:
            plan, reason = chatbot_service._plan_query("qui n a pas de vol", "admin", None, {})
        assert reason == "ok" and plan is not None
        assert mock.call_args_list[0].kwargs["model_override"] == ai_service.NVIDIA_FAST_MODEL

    def test_invalid_fast_answer_falls_back_to_the_flagship(self):
        from services import chatbot_service
        bad = '{"filters":[{"field":"salaire","op":"is","value":1}]}'
        good = '{"filters":[{"field":"has_hotel","op":"is","value":false}],"output":"count"}'
        with patch("services.ai_service.ai_text", side_effect=[bad, good]) as mock:
            plan, reason = chatbot_service._plan_query("q", "admin", None, {})
        assert reason == "ok"
        assert plan["filters"][0]["field"] == "has_hotel"
        assert len(mock.call_args_list) == 2
        assert mock.call_args_list[1].kwargs["model_override"] is None   # flagship

    def test_both_models_failing_reports_unsupported_not_outage(self):
        from services import chatbot_service
        bad = '{"filters":[{"field":"inexistant","op":"is","value":1}]}'
        with patch("services.ai_service.ai_text", side_effect=[bad, bad]):
            plan, reason = chatbot_service._plan_query("q", "admin", None, {})
        assert plan is None and reason == "unsupported"

    def test_no_provider_at_all_reports_an_outage(self):
        from services import chatbot_service
        with patch("services.ai_service.ai_text", return_value=None):
            plan, reason = chatbot_service._plan_query("q", "admin", None, {})
        assert plan is None and reason == "ai_unavailable"


class TestPlannerPhrasingIgnoresDisplayCap:
    """Asked "les informations sont-elles completes ?", the assistant replied
    "non, seuls 50 resultats sur 300 sont presentes" — a remark about the table
    below, not an answer to the question. The row cap is no longer handed to
    the phrasing model."""

    def test_display_cap_is_not_in_the_phrasing_facts(self):
        import inspect
        from services import chatbot_service
        src = inspect.getsource(chatbot_service._answer_by_plan)
        body = src.split('facts = {"resultats"')[1].split("}")[0]
        assert "affiches" not in body, "the display cap must stay out of the facts"

    def test_template_still_mentions_the_cap_to_the_user(self):
        import inspect
        from services import chatbot_service
        src = inspect.getsource(chatbot_service._answer_by_plan)
        assert "premiers sont listes ci-dessous" in src.replace("é", "e")


class TestSamePersonAcrossFiles:
    """THE behaviour the product exists for: one person listed in two files —
    the phone in one, the email in the other — must end up on ONE fiche
    carrying both.

    It ran inside run_consolidation with no test of its own, which meant the
    most important guarantee in the application was the least protected. These
    drive find_matching_participant, the real decision, plus
    merge_participant_fields, which decides what survives the merge."""

    def _index(self, participants):
        """The two lookups run_consolidation maintains while it walks the rows."""
        from services.consolidation_service import _name_key
        by_email, by_name = {}, {}
        for p in participants:
            if p.get("email"):
                by_email[p["email"].strip().lower()] = p
            key = _name_key(p.get("first_name"), p.get("last_name"))
            if key:
                by_name.setdefault(key, p)
        return by_email, by_name

    def _match(self, record, known):
        from services.consolidation_service import find_matching_participant, _name_key_sorted
        by_email, by_name = self._index(known)
        by_sorted = {}
        for p in known:
            key = _name_key_sorted(p.get("first_name"), p.get("last_name"))
            if key:
                by_sorted.setdefault(key, p)
        return find_matching_participant(record, by_email, by_name, by_sorted)

    def _crowd(self, first_person, size):
        """One real person among `size` others — enough to switch off the
        fuzzy scan, which is capped for cost."""
        return [first_person] + [
            {"id": f"x{i}", "first_name": f"Prenom{i}", "last_name": f"Nom{i}",
             "email": f"x{i}@acme.com"}
            for i in range(size)
        ]

    # -- the reversal every airline export produces -------------------------
    def test_family_name_first_is_the_same_person(self):
        """FCM and hotel exports write "DUPONT Jean"; the registration file
        writes "Jean Dupont". Same human being."""
        known = [{"id": "p1", "first_name": "Dupont", "last_name": "Jean", "email": None}]
        row = {"first_name": "Jean", "last_name": "Dupont", "email": "jd@acme.com"}
        assert self._match(row, known)["id"] == "p1"

    def test_the_reversal_still_merges_on_a_large_event(self):
        """2026-08-08: it did not. The only thing catching a reversed name was
        a fuzzy scan disabled past 400 known names — so the guarantee held on a
        30-person test event and broke silently on the 500-person one, which is
        exactly where nobody re-reads the master list by hand."""
        known = self._crowd(
            {"id": "p1", "first_name": "Dupont", "last_name": "Jean", "email": None}, 450
        )
        row = {"first_name": "Jean", "last_name": "Dupont", "email": "jd@acme.com"}
        assert self._match(row, known)["id"] == "p1"

    def test_a_reversed_name_with_a_conflicting_email_is_still_two_people(self):
        known = self._crowd(
            {"id": "p1", "first_name": "Dupont", "last_name": "Jean", "email": "a@acme.com"}, 450
        )
        row = {"first_name": "Jean", "last_name": "Dupont", "email": "b@acme.com"}
        assert self._match(row, known) is None

    # -- the scenario, in both directions ----------------------------------
    def test_phone_only_row_finds_the_email_only_participant(self):
        known = [{"id": "p1", "first_name": "Jean", "last_name": "Dupont",
                  "email": "jean.dupont@acme.com", "phone": None}]
        row = {"first_name": "Jean", "last_name": "Dupont", "phone": "+32 470 11 22 33"}
        assert self._match(row, known)["id"] == "p1"

    def test_email_only_row_finds_the_phone_only_participant(self):
        known = [{"id": "p1", "first_name": "Jean", "last_name": "Dupont",
                  "email": None, "phone": "+32 470 11 22 33"}]
        row = {"first_name": "Jean", "last_name": "Dupont", "email": "jean.dupont@acme.com"}
        assert self._match(row, known)["id"] == "p1"

    def test_the_merged_fiche_carries_both(self):
        """Matching is half the job: the merge must fill the gap without
        overwriting what is already known."""
        from services.consolidation_service import merge_participant_fields
        existing = {"id": "p1", "first_name": "Jean", "last_name": "Dupont",
                    "email": None, "phone": "+32 470 11 22 33", "company": "ACME"}
        incoming = {"first_name": "Jean", "last_name": "Dupont",
                    "email": "jean.dupont@acme.com", "phone": "", "company": None}
        merged = merge_participant_fields(existing, incoming, {})
        assert merged["email"] == "jean.dupont@acme.com"   # gap filled
        assert merged["phone"] == "+32 470 11 22 33"       # NOT wiped by ""
        assert merged["company"] == "ACME"                 # NOT wiped by None

    # -- writing conventions differ from one file to the next --------------
    def test_case_and_accents_do_not_split_a_person_in_two(self):
        known = [{"id": "p1", "first_name": "Jérôme", "last_name": "Lévêque", "email": None}]
        row = {"first_name": "JEROME", "last_name": "LEVEQUE", "email": "j.leveque@acme.com"}
        assert self._match(row, known)["id"] == "p1"

    def test_extra_spacing_does_not_split_a_person_in_two(self):
        known = [{"id": "p1", "first_name": " Jean ", "last_name": "Dupont", "email": None}]
        row = {"first_name": "Jean", "last_name": " Dupont", "email": "jd@acme.com"}
        assert self._match(row, known)["id"] == "p1"

    def test_a_typo_in_the_name_still_merges(self):
        """Files are typed by hand; one letter must not create a second fiche."""
        known = [{"id": "p1", "first_name": "Jean", "last_name": "Dupont", "email": None}]
        row = {"first_name": "Jean", "last_name": "Duponnt", "email": "jd@acme.com"}
        assert self._match(row, known) is not None

    # -- and the far more expensive mistake: merging two DIFFERENT people ---
    def test_two_emails_that_disagree_are_two_people(self):
        known = [{"id": "p1", "first_name": "Jean", "last_name": "Dupont",
                  "email": "jean.dupont@acme.com"}]
        row = {"first_name": "Jean", "last_name": "Dupont", "email": "jean.dupont@other.com"}
        assert self._match(row, known) is None

    def test_a_different_name_is_not_merged(self):
        known = [{"id": "p1", "first_name": "Jean", "last_name": "Dupont", "email": None}]
        row = {"first_name": "Marie", "last_name": "Lefevre", "email": "ml@acme.com"}
        assert self._match(row, known) is None

    def test_a_row_without_a_name_or_email_matches_nothing(self):
        known = [{"id": "p1", "first_name": "Jean", "last_name": "Dupont", "email": None}]
        assert self._match({"phone": "+32 470 11 22 33"}, known) is None

    def test_email_wins_over_a_name_that_looks_like_someone_else(self):
        """Two people, and the incoming row carries the second one's email:
        the email decides, not the alphabetical accident of the name index."""
        known = [
            {"id": "p1", "first_name": "Jean", "last_name": "Dupont", "email": "a@acme.com"},
            {"id": "p2", "first_name": "Jean", "last_name": "Dupont", "email": "b@acme.com"},
        ]
        row = {"first_name": "Jean", "last_name": "Dupont", "email": "b@acme.com"}
        assert self._match(row, known)["id"] == "p2"


class TestSplitNameCatchUp:
    """Consolidation stopped splitting a reversed name across two fiches, but
    the ones already written stay: the registration file holds the email, the
    airline export holds the phone, and the email-based merge above can never
    compare two fiches that share no address.

    This runs on every consolidation to fold them back. It deletes a row, so
    the tests that matter most are the ones proving when it refuses to."""

    EVENT_ID = "00000000-0000-0000-0000-0000000000e1"

    def _supabase(self, participants):
        table = MagicMock()
        table.select.return_value.eq.return_value.range.return_value.execute.return_value.data = participants
        mock = MagicMock()
        mock.table.side_effect = lambda name: table
        return mock

    def _run(self, participants):
        from services import consolidation_service
        merges = []
        with patch.object(consolidation_service, "_merge_participant_into",
                          side_effect=lambda sb, loser, winner: merges.append((loser, winner)) or True):
            count = consolidation_service.merge_split_name_duplicates(
                self.EVENT_ID, self._supabase(participants)
            )
        return count, merges

    def _p(self, pid, first, last, email=None, phone=None, **kw):
        return {"id": pid, "first_name": first, "last_name": last, "email": email,
                "phone": phone, "company": kw.get("company"),
                "nationality": kw.get("nationality"),
                "registration_source_id": kw.get("registration_source_id")}

    def test_folds_the_reversed_pair_back_together(self):
        count, merges = self._run([
            self._p("p1", "Jean", "Dupont", email="jd@acme.com"),
            self._p("p2", "Dupont", "Jean", phone="+32 470 11 22 33"),
        ])
        assert count == 1
        loser, winner = merges[0]
        # The fiche carrying the email is the richer one and survives.
        assert winner == "p1" and loser == "p2"

    def test_leaves_two_people_who_share_a_name_alone(self):
        """Two distinct addresses in one bucket: there is no way to tell which
        of them an address-less third fiche belongs to, and being wrong here
        deletes somebody's flight."""
        count, merges = self._run([
            self._p("p1", "Jean", "Dupont", email="jean.dupont@acme.com"),
            self._p("p2", "Dupont", "Jean", email="j.dupont@other.com"),
            self._p("p3", "Jean", "Dupont", phone="+32 470 11 22 33"),
        ])
        assert count == 0 and merges == []

    def test_leaves_different_names_alone(self):
        count, merges = self._run([
            self._p("p1", "Jean", "Dupont", email="jd@acme.com"),
            self._p("p2", "Marie", "Lefevre", phone="+32 470 11 22 33"),
        ])
        assert count == 0 and merges == []

    def test_a_single_token_name_is_not_folded_into_a_longer_one(self):
        """rapidfuzz scores "Lin Lin" 100 % against "Chenyang Lin";
        _same_person_name is what refuses it."""
        count, merges = self._run([
            self._p("p1", "Lin", "Lin", email="lin@acme.com"),
            self._p("p2", "Lin", "Lin"),
            self._p("p3", "Chenyang", "Lin"),
        ])
        # p1/p2 are the same person; p3 is not folded into them.
        assert all(loser != "p3" for loser, _ in merges)

    def test_nothing_to_do_is_not_an_error(self):
        count, merges = self._run([self._p("p1", "Jean", "Dupont", email="jd@acme.com")])
        assert count == 0 and merges == []

    def test_it_runs_on_every_consolidation(self):
        """A catch-up nobody calls is not a catch-up."""
        import inspect
        from services import consolidation_service
        src = inspect.getsource(consolidation_service.run_consolidation)
        assert "merge_split_name_duplicates(event_id, supabase)" in src


class TestDashboardService:
    """The dashboard used to fill a gap with a constant: the "Comms" slice of
    its chart was the literal 90, shown as data on every event. These tests
    pin the rule that replaced it — a figure that cannot be computed comes
    back as null so the page omits it — plus the three things the page was
    missing: the countdown, the trend already sitting in
    consolidation_runs.stats, and the per-company breakdown."""

    EVENT_ID = "00000000-0000-0000-0000-0000000000e1"

    def _people(self):
        def p(pid, company, flight, hotel, transfer, status="complete"):
            return {"id": pid, "company": company, "completeness_status": status,
                    "has_flight": flight, "has_hotel": hotel,
                    "has_transfer": transfer, "has_activities": False}
        return [
            p("p1", "ACME", True, True, False),
            p("p2", "ACME", False, True, False, status="incomplete"),
            p("p3", "Zenith", True, True, True),
        ]

    def _supabase(self, *, communications="ok", runs=None, exceptions=None):
        participants = MagicMock()
        participants.select.return_value.eq.return_value.range.return_value.execute.return_value.data = self._people()

        comms = MagicMock()
        if communications == "absent":
            comms.select.return_value.eq.return_value.eq.return_value.execute.side_effect = RuntimeError("no table")
        else:
            comms.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = [
                {"participant_id": "p1", "status": "sent"},
                {"participant_id": "p1", "status": "sent"},   # same person twice
            ]
        # _event_snapshot also reads communications with a .neq chain.
        comms.select.return_value.eq.return_value.neq.return_value.execute.return_value.data = []

        exc = MagicMock()
        exc_rows = exceptions if exceptions is not None else []
        exc.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = exc_rows

        runs_mock = MagicMock()
        runs_mock.select.return_value.eq.return_value.eq.return_value.order.return_value.limit.return_value.execute.return_value.data = runs or []

        files = MagicMock()
        files.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = []
        files.select.return_value.eq.return_value.execute.return_value.data = []

        events = MagicMock()
        events.select.return_value.eq.return_value.limit.return_value.execute.return_value.data = [
            {"name": "Conference 2027", "start_date": "2099-03-14", "location_city": "Lisbonne"}
        ]

        tables = {
            "participants": participants, "communications": comms, "exceptions": exc,
            "consolidation_runs": runs_mock, "uploaded_files": files, "events": events,
        }
        mock = MagicMock()
        mock.table.side_effect = lambda name: tables.get(name, MagicMock())
        return mock

    def _build(self, **kw):
        from services import dashboard_service
        return dashboard_service.build_dashboard(self._supabase(**kw), self.EVENT_ID)

    def test_communications_are_counted_per_person_not_per_message(self):
        d = self._build()
        # p1 received two emails; that is one participant contacted out of three.
        assert d["communications"]["participants_contacted"] == 1
        assert d["communications"]["pct"] == 33

    def test_an_unavailable_table_yields_null_not_a_number(self):
        """The whole point: the old code shipped 90 here."""
        d = self._build(communications="absent")
        assert d["communications"]["participants_contacted"] is None
        assert d["communications"]["pct"] is None

    def test_countdown_comes_from_the_event_date(self):
        d = self._build()
        assert d["event"]["start_date"] == "2099-03-14"
        assert isinstance(d["event"]["days_until_start"], int)
        assert d["event"]["days_until_start"] > 0

    def test_trend_reads_the_stats_runs_have_always_written(self):
        runs = [
            {"id": "r2", "started_at": "2026-08-02T10:00:00Z", "completed_at": "2026-08-02T10:05:00Z",
             "status": "completed", "stats": {"participants_total": 300, "exceptions_count": 12}},
            {"id": "r1", "started_at": "2026-08-01T10:00:00Z", "completed_at": "2026-08-01T10:05:00Z",
             "status": "completed", "stats": {"participants_total": 288, "exceptions_count": 20}},
        ]
        d = self._build(runs=runs)
        assert [p["stats"]["participants_total"] for p in d["trend"]["points"]] == [288, 300]  # oldest first
        assert d["trend"]["delta"]["changes"] == {"participants_total": 12, "exceptions_count": -8}

    def test_delta_compares_against_yesterday_not_the_previous_run(self):
        """Consolidate three times in an hour and "since the previous run"
        covers four minutes — the progress reads as zero. The baseline is the
        most recent run at least ~20 h old."""
        from datetime import datetime, timedelta, timezone
        now = datetime.now(timezone.utc)
        runs = [
            {"id": "r3", "started_at": now.isoformat(), "completed_at": now.isoformat(),
             "status": "completed", "stats": {"participants_total": 300}},
            {"id": "r2", "started_at": (now - timedelta(minutes=4)).isoformat(),
             "completed_at": (now - timedelta(minutes=4)).isoformat(),
             "status": "completed", "stats": {"participants": 299}},
            {"id": "r1", "started_at": (now - timedelta(days=1)).isoformat(),
             "completed_at": (now - timedelta(days=1)).isoformat(),
             "status": "completed", "stats": {"participants_total": 250}},
        ]
        d = self._build(runs=runs)
        # Against the run 4 minutes ago this would read +1.
        assert d["trend"]["delta"]["changes"] == {"participants_total": 50}

    def test_delta_falls_back_to_the_previous_run_when_none_is_old_enough(self):
        from datetime import datetime, timedelta, timezone
        now = datetime.now(timezone.utc)
        runs = [
            {"id": "r2", "started_at": now.isoformat(), "completed_at": now.isoformat(),
             "status": "completed", "stats": {"participants_total": 300}},
            {"id": "r1", "started_at": (now - timedelta(hours=2)).isoformat(),
             "completed_at": (now - timedelta(hours=2)).isoformat(),
             "status": "completed", "stats": {"participants_total": 288}},
        ]
        d = self._build(runs=runs)
        assert d["trend"]["delta"]["changes"] == {"participants_total": 12}

    def test_trend_survives_a_run_from_an_older_version(self):
        """stats is free-form JSONB; a run missing keys must contribute fewer
        series, not break the chart."""
        runs = [
            {"id": "r2", "started_at": "2026-08-02T10:00:00Z", "status": "completed",
             "stats": {"participants_total": 300, "note": "texte"}},
            {"id": "r1", "started_at": "2026-08-01T10:00:00Z", "status": "completed", "stats": None},
        ]
        d = self._build(runs=runs)
        assert d["trend"]["points"][0]["stats"] == {}
        assert "note" not in d["trend"]["points"][1]["stats"]
        assert d["trend"]["delta"] is None or d["trend"]["delta"]["changes"] == {}

    def test_companies_are_ranked_by_how_much_they_still_owe(self):
        d = self._build()
        assert d["companies"][0]["company"] == "ACME"     # 1 no flight + 2 no transfer + 1 incomplete
        assert d["companies"][0]["participants"] == 2
        assert d["companies"][0]["without_transfer"] == 2

    def test_overdue_alerts_are_counted_by_age(self):
        from datetime import datetime, timedelta, timezone
        now = datetime.now(timezone.utc)
        exceptions = [
            {"severity": "critical", "created_at": (now - timedelta(hours=40)).isoformat()},
            {"severity": "info", "created_at": (now - timedelta(hours=2)).isoformat()},
            {"severity": "info", "created_at": "pas une date"},      # never guessed
        ]
        d = self._build(exceptions=exceptions)
        assert d["alerts"]["open"] == 3
        assert d["alerts"]["overdue"] == 1
        assert d["alerts"]["critical"] == 1
        assert d["alerts"]["oldest_age_hours"] >= 40

    def test_priorities_use_the_assistant_ranking(self):
        """Not a second copy of it: the page and the assistant must not
        disagree about what matters most."""
        import inspect
        from services import chatbot_service, dashboard_service
        src = inspect.getsource(dashboard_service.build_dashboard)
        # Checked by call, not by exact spelling: the argument list grew a
        # policy on 2026-08-25 and the old literal assertion broke on a change
        # that made the two agree MORE, not less.
        assert "ranked_findings(snapshot" in src
        assert dashboard_service.ranked_findings is chatbot_service._advisory_findings

    def test_the_assistant_ranks_with_the_same_policy_as_the_page(self):
        """Same function is not enough — same ARGUMENTS too.

        The dashboard filters its priorities through the event's field policy.
        An assistant calling the same function without one would answer "81
        participants sans activité" about a page that has stopped saying it.
        """
        import inspect
        from services import chatbot_service
        src = inspect.getsource(chatbot_service._answer_advisory)
        assert "_advisory_findings(snapshot, field_policy" in src


class TestCoverageEndpoint:
    """The Vols, Hébergements and Exceptions pages need one thing from the
    participant list — who is missing a flight, a hotel, a transfer or an
    activity — and used to get it by loading the full master list, which merges
    ten tables (including every source_records.normalized_data blob) before the
    page threw all of it away to filter a boolean.

    This endpoint reads three small ones, in parallel, and the test that
    matters is the second: it holds the read to a named list, because the
    moment someone "enriches" this response the pages are back to paying
    master-list prices.

    It was one table until 2026-08-25, when the same three pages needed to
    know who is travelling outside the programme's dates — a fact derived from
    flights and the event's own dates, so it cannot come from `participants`.
    Two extra reads of one indexed column each, started together with the
    first, is a different order of thing from re-merging ten tables."""

    EVENT_ID = "00000000-0000-0000-0000-0000000000e1"

    def _client(self, rows):
        participants_mock = MagicMock()
        participants_mock.select.return_value.eq.return_value.order.return_value.order.return_value.range.return_value.execute.return_value.data = rows
        tables = {"participants": participants_mock}
        touched: list[str] = []

        def table(name):
            touched.append(name)
            return tables.get(name, MagicMock())

        mock_supabase = MagicMock()
        mock_supabase.table.side_effect = table
        client = _admin_client()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        return client, touched

    @patch("routers.participants.verify_event_access")
    def test_returns_identity_and_coverage_flags(self, mock_verify):
        mock_verify.return_value = None
        client, _ = self._client([
            {"id": "p1", "first_name": "Ana", "last_name": "Kaya", "email": "a@x.com",
             "company": "ACME", "completeness_status": "complete",
             "has_flight": True, "has_hotel": False, "has_transfer": True, "has_activities": False},
        ])

        response = client.get(f"/api/events/{self.EVENT_ID}/participants/coverage")

        assert response.status_code == 200, response.text
        body = response.json()
        assert body["total"] == 1
        row = body["items"][0]
        assert row["last_name"] == "Kaya" and row["has_hotel"] is False
        # Exactly the columns the pages display — no dietary_requirements.
        assert "dietary_requirements" not in row

    @patch("routers.participants.verify_event_access")
    def test_reads_only_its_three_named_tables(self, mock_verify):
        """The guardrail, restated. Each name here earns its place; anything
        else means this endpoint is drifting back into the master list."""
        mock_verify.return_value = None
        client, touched = self._client([])

        client.get(f"/api/events/{self.EVENT_ID}/participants/coverage")

        allowed = {
            "participants",   # the flags themselves
            "flights",        # one column, to place people against the dates
            "events",         # the programme's dates, one row
        }
        assert set(touched) <= allowed, (
            "coverage must stay a small, bounded read; it touched "
            f"{sorted(set(touched) - allowed)} on top of the allowed set"
        )

    @patch("routers.participants.verify_event_access")
    def test_it_never_reads_a_source_record(self, mock_verify):
        """The specific thing that made the old page slow: every
        `normalized_data` blob on the event, loaded to filter a boolean."""
        mock_verify.return_value = None
        client, touched = self._client([])

        client.get(f"/api/events/{self.EVENT_ID}/participants/coverage")

        assert "source_records" not in touched


class TestRegistrationFormFields:
    """The public form asked every participant the same twenty questions,
    passport number included, whatever the event. It is now configured per
    event — which questions are shown, and which answers are mandatory.

    Three things must hold. Identity (first/last name, email) cannot be
    switched off, because it is what the consolidation engine matches people
    on. A required answer is enforced server-side, since the endpoint is public
    and takes JSON. And an event with no configuration — every event that
    predates this, and any deployment where migration 007 has not run — behaves
    exactly as the form did before."""

    TOKEN = "11111111-1111-1111-1111-111111111111"
    EVENT_ID = "00000000-0000-0000-0000-0000000000e1"

    def test_no_configuration_shows_every_field(self):
        from services import registration_form
        resolved = registration_form.resolve(None)
        assert len(resolved) == len(registration_form.FIELD_KEYS)
        assert all(f["enabled"] for f in resolved)
        required = {f["key"] for f in resolved if f["required"]}
        assert required == set(registration_form.LOCKED_KEYS)

    def test_identity_fields_cannot_be_switched_off(self):
        from services import registration_form
        clean = registration_form.sanitize(
            {key: {"enabled": False, "required": False} for key in registration_form.FIELD_KEYS}
        )
        for key in registration_form.LOCKED_KEYS:
            assert clean[key]["enabled"] is True, key
            assert clean[key]["required"] is True, key
        assert clean["passport_number"]["enabled"] is False

    def test_a_hidden_field_is_never_required(self):
        """The pair would make the form impossible to submit."""
        from services import registration_form
        clean = registration_form.sanitize({"passport_number": {"enabled": False, "required": True}})
        assert clean["passport_number"]["enabled"] is False
        assert clean["passport_number"]["required"] is False

    def test_unknown_keys_are_dropped(self):
        from services import registration_form
        clean = registration_form.sanitize({"salaire": {"enabled": True, "required": True}})
        assert "salaire" not in clean

    def test_a_broken_stored_config_falls_back_to_defaults(self):
        """Hand-edited in the Supabase console, or written by an older version:
        the public form must not go down with it."""
        from services import registration_form
        for junk in ("nonsense", 42, [], {"phone": "yes"}):
            resolved = registration_form.resolve(junk)
            assert all(f["enabled"] for f in resolved)

    def test_missing_column_reads_as_not_configured(self):
        """Migration 007 unapplied — PostgREST errors on the column. The form
        shows its defaults rather than 500ing."""
        from services import registration_form
        broken = MagicMock()
        broken.table.return_value.select.side_effect = Exception("column does not exist")
        assert registration_form.fetch(broken, self.EVENT_ID) is None

    def _supabase(self, stored):
        events_mock = MagicMock()
        events_mock.select.return_value.eq.return_value.single.return_value.execute.return_value.data = {
            "id": self.EVENT_ID, "name": "Conference 2027",
            "project_id": "00000000-0000-0000-0000-0000000000c1",
            "registration_open": True,
        }
        events_mock.select.return_value.eq.return_value.limit.return_value.execute.return_value.data = [
            {"registration_fields": stored}
        ]
        # _event_logo (point 11) reads the same table with a different chain.
        events_mock.select.return_value.eq.return_value.maybe_single.return_value.execute.return_value.data = {
            "logo_url": None
        }
        mock = MagicMock()
        mock.table.side_effect = lambda name: events_mock if name == "events" else MagicMock()
        return mock

    def teardown_method(self):
        app.dependency_overrides.pop(get_supabase_client, None)

    def test_public_form_info_carries_the_configuration(self):
        mock_supabase = self._supabase({"passport_number": {"enabled": False, "required": False}})
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        response = client.get(f"/api/public/register/{self.TOKEN}")

        assert response.status_code == 200, response.text
        fields = {f["key"]: f for f in response.json()["fields"]}
        assert fields["passport_number"]["enabled"] is False
        assert fields["email"]["locked"] is True
        assert fields["company"]["enabled"] is True

    def test_a_required_answer_left_empty_is_refused(self):
        from tests.test_api import TestPublicRegistration as _Reg
        mock_supabase = self._supabase({"company": {"enabled": True, "required": True}})
        app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        client = TestClient(app)

        payload = _Reg()._base_payload(company="")
        response = client.post(f"/api/public/register/{self.TOKEN}", json=payload)

        assert response.status_code == 422, response.text
        assert "Société" in response.json()["detail"]


class TestManualReturnLegKeepsItsOutbound:
    """The manual upsert matched on (event, participant, flight number) with no
    date, while the extraction path keys on the departure DAY. Adding a return
    leg that reuses the outbound's number — a shuttle route, a same-number
    rotation — silently UPDATED the outbound row instead of inserting, and one
    of the two segments vanished."""

    def test_the_day_is_part_of_the_identity(self):
        import inspect
        from routers import flights
        src = inspect.getsource(flights)
        assert "departure_day" in src, "the upsert ignores the date again"
        assert 'str(row.get("departure_time") or "")[:10] == departure_day' in src

    def test_two_days_are_two_segments(self):
        """The filter the route applies, on the rows Supabase hands back."""
        departure_day = "2026-06-26"
        rows = [
            {"id": "outbound", "departure_time": "2026-06-22T14:05:00+00:00"},
            {"id": "return", "departure_time": "2026-06-26T20:30:00+00:00"},
        ]
        same_day = [r for r in rows if str(r.get("departure_time") or "")[:10] == departure_day]
        assert [r["id"] for r in same_day] == ["return"]

    def test_the_same_segment_twice_still_updates(self):
        departure_day = "2026-06-22"
        rows = [{"id": "outbound", "departure_time": "2026-06-22T14:05:00+00:00"}]
        same_day = [r for r in rows if str(r.get("departure_time") or "")[:10] == departure_day]
        assert len(same_day) == 1

class TestManualFlightCreation:
    """Adding a flight by hand from the Flights page, the counterpart of the
    rooming form on the hébergements page: a participant whose travel arrives
    by email instead of in the FCM export has no way in otherwise.

    What matters here is that a manual flight is indistinguishable from an
    extracted one downstream -- same table, same shape, and above all the same
    has_flight flag, so the master list, the coverage KPI and the "sans vol"
    exception agree the moment it is saved rather than at the next
    consolidation."""

    EVENT_ID = "00000000-0000-0000-0000-0000000000e1"
    PARTICIPANT_ID = "00000000-0000-0000-0000-00000000a001"
    FLIGHT_ID = "00000000-0000-0000-0000-00000000f001"

    def _payload(self, **overrides):
        payload = {
            "participant_id": self.PARTICIPANT_ID,
            "flight_number": "sn2103",
            "departure_airport": "BRU",
            "arrival_airport": "LIS",
            "departure_time": "2027-03-14T08:00:00Z",
            "arrival_time": "2027-03-14T10:30:00Z",
            "airline": "Brussels Airlines",
        }
        payload.update(overrides)
        return payload

    def _row(self):
        return {
            "id": self.FLIGHT_ID, "event_id": self.EVENT_ID, "participant_id": self.PARTICIPANT_ID,
            "flight_number": "SN2103", "departure_airport": "BRU", "arrival_airport": "LIS",
            "departure_time": "2027-03-14T08:00:00Z", "arrival_time": "2027-03-14T10:30:00Z",
            "status": "confirmed", "created_at": "2026-08-07T10:00:00Z",
        }

    def _client(self, *, participant_found=True, existing_flight=None):
        participants_mock = MagicMock()
        participants_mock.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = (
            [{"id": self.PARTICIPANT_ID}] if participant_found else []
        )

        flights_mock = MagicMock()
        flights_mock.select.return_value.eq.return_value.eq.return_value.eq.return_value.execute.return_value.data = (
            # The route now selects `id, departure_time` and keeps only the
            # rows departing the SAME DAY, so a return leg reusing the
            # outbound's number inserts instead of overwriting it.
            [{"id": existing_flight, "departure_time": self._payload()["departure_time"]}]
            if existing_flight else []
        )
        flights_mock.insert.return_value.execute.return_value.data = [self._row()]
        flights_mock.update.return_value.eq.return_value.execute.return_value.data = [self._row()]

        tables = {"participants": participants_mock, "flights": flights_mock}
        mock_supabase = MagicMock()
        mock_supabase.table.side_effect = lambda name: tables.get(name, MagicMock())

        client = _admin_client()
        client.app.dependency_overrides[get_supabase_client] = lambda: mock_supabase
        return client, tables

    @patch("routers.flights.verify_event_access")
    def test_creating_a_flight_marks_the_participant_as_covered(self, mock_verify):
        mock_verify.return_value = None
        client, tables = self._client()

        response = client.post(f"/api/events/{self.EVENT_ID}/flights", json=self._payload())

        assert response.status_code == 201, response.text
        tables["flights"].insert.assert_called_once()
        inserted = tables["flights"].insert.call_args[0][0]
        assert inserted["event_id"] == self.EVENT_ID
        assert inserted["flight_number"] == "SN2103"      # normalised, like the extractor
        tables["participants"].update.assert_called_once_with({"has_flight": True})

    @patch("routers.flights.verify_event_access")
    def test_participant_from_another_event_is_refused(self, mock_verify):
        mock_verify.return_value = None
        client, tables = self._client(participant_found=False)

        response = client.post(f"/api/events/{self.EVENT_ID}/flights", json=self._payload())

        assert response.status_code == 404
        tables["flights"].insert.assert_not_called()
        tables["participants"].update.assert_not_called()

    @patch("routers.flights.verify_event_access")
    def test_arrival_before_departure_is_refused(self, mock_verify):
        mock_verify.return_value = None
        client, tables = self._client()

        response = client.post(
            f"/api/events/{self.EVENT_ID}/flights",
            json=self._payload(arrival_time="2027-03-14T06:00:00Z"),
        )

        assert response.status_code == 422
        tables["flights"].insert.assert_not_called()

    @patch("routers.flights.verify_event_access")
    def test_resubmitting_the_same_segment_updates_it(self, mock_verify):
        """Otherwise the same leg entered twice is counted twice in the flight
        KPI — the extraction path already de-duplicates this way."""
        mock_verify.return_value = None
        client, tables = self._client(existing_flight=self.FLIGHT_ID)

        response = client.post(f"/api/events/{self.EVENT_ID}/flights", json=self._payload())

        assert response.status_code == 201, response.text
        tables["flights"].insert.assert_not_called()
        tables["flights"].update.assert_called_once()

    def test_a_viewer_cannot_add_a_flight(self):
        """write=True on verify_event_access is what enforces this; the test
        exists so a refactor that drops the flag fails loudly."""
        import inspect
        from routers import flights as flights_router
        src = inspect.getsource(flights_router.create_flight)
        assert "write=True" in src


class TestChatbotAdvisory:
    """2026-08-05: "tu penses que je peux encore ameliorer l'evenement et
    l'organisation ?" was answered with a refusal and a list of what the
    assistant could do instead. The data answers that question perfectly well;
    refusing it was a missing feature dressed up as rigour.

    Tier 3 answers it from an AGGREGATE snapshot -- counts, percentages, gaps,
    exception tallies -- and the same guarantee holds as everywhere else: the
    model reasons, the figures stay ours. These tests pin the three properties
    that make that safe: no individual ever reaches the model, an answer
    containing an unaccounted number is thrown away, and a question that is
    genuinely not about the event is still refused."""

    EVENT_ID = "00000000-0000-0000-0000-0000000000e1"

    def _people(self):
        def p(pid, first, last, flight, hotel, transfer, activity, **kw):
            return {
                "id": pid, "first_name": first, "last_name": last,
                "email": kw.get("email", f"{first.lower()}@x.com"),
                "company": "ACME", "phone": kw.get("phone", "+32 1"),
                "nationality": "BE", "dietary_requirements": "halal",
                "completeness_status": "complete",
                "has_flight": flight, "has_hotel": hotel,
                "has_transfer": transfer, "has_activities": activity,
            }
        return [
            p("p1", "Ana", "Kaya", True, True, False, True),
            p("p2", "Bruno", "Costa", True, False, True, True),
            p("p3", "Chloe", "Nilsson", False, True, True, False, phone=""),
        ]

    def _supabase(self, *, exceptions=None, candidates=None, communications_raises=False):
        mock = MagicMock()

        participants_mock = MagicMock()
        participants_mock.select.return_value.eq.return_value.order.return_value.order.return_value.range.return_value.execute.return_value.data = self._people()

        exceptions_mock = MagicMock()
        exceptions_mock.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = exceptions or []

        comms_mock = MagicMock()
        if communications_raises:
            comms_mock.select.return_value.eq.return_value.neq.return_value.execute.side_effect = RuntimeError("no table")
        else:
            comms_mock.select.return_value.eq.return_value.neq.return_value.execute.return_value.data = []

        cand_mock = MagicMock()
        cand_mock.select.return_value.eq.return_value.eq.return_value.execute.return_value.data = candidates or []

        tables = {
            "participants": participants_mock, "exceptions": exceptions_mock,
            "communications": comms_mock, "match_candidates": cand_mock,
        }
        mock.table.side_effect = lambda name: tables.get(name, MagicMock())
        return mock

    def _snapshot(self, **kw):
        from services import chatbot_service
        supabase = self._supabase(**kw)
        return chatbot_service._event_snapshot(
            self.EVENT_ID, supabase, chatbot_service._fetch_participants(supabase, self.EVENT_ID)
        )

    # -- the question that started this ------------------------------------
    def test_the_organisation_question_is_answered_not_refused(self):
        from services import chatbot_service
        with patch("services.ai_service.ai_text", return_value=None):
            r = chatbot_service.answer_question(
                "tu pense que je peux encore ameliorer l'evenement et l'organisation",
                self.EVENT_ID, self._supabase(), user_role="admin",
            )
        assert r["answered"] is True
        assert r["intent"] == "event_advisory"
        assert "ne peux pas r" not in r["answer"]
        assert "3 participants" in r["answer"]
        assert r["rows"], "the concrete points must come with the answer"

    def test_digest_ranks_real_gaps_and_cites_where_to_fix_them(self):
        from services import chatbot_service
        snap = self._snapshot()
        findings = chatbot_service._advisory_findings(snap)
        points = {f["point"]: f for f in findings}
        assert points["Participants sans vol"]["nombre"] == 1
        assert points["Participants sans vol"]["où"] == "Page Vols"
        assert points["Fiches sans téléphone"]["nombre"] == 1
        assert all(isinstance(f["nombre"], int) and f["nombre"] > 0 for f in findings)

    def test_a_mapping_anomaly_outranks_a_larger_but_softer_gap(self):
        """Sorting on the raw count buried the one line that means an import is
        broken under forty missing phone numbers."""
        from services import chatbot_service
        snap = {
            "participants_total": 300,
            "qualite_des_donnees": {"anomalies_de_mapping_suspectees": 1, "critiques": 0,
                                    "contradictions_entre_fichiers": 0},
            "couverture": {}, "fiches_sans_donnee": {"téléphone": 40},
        }
        findings = chatbot_service._advisory_findings(snap)
        assert findings[0]["point"] == "Anomalies de mapping suspectées"

    # -- the model never sees a person -------------------------------------
    def test_no_participant_ever_reaches_the_model(self):
        """The snapshot is the model's entire world in this tier, so it must
        carry statistics about people and never people themselves."""
        from services import chatbot_service
        seen = {}

        def capture(prompt, *a, **kw):
            seen["prompt"] = prompt
            return "Tout va bien."

        with patch("services.ai_service.ai_text", side_effect=capture):
            chatbot_service.answer_question(
                "quel est ton avis sur l'organisation ?", self.EVENT_ID,
                self._supabase(), user_role="admin",
            )
        prompt = seen["prompt"]
        for leak in ("Kaya", "Nilsson", "ana@x.com", "halal", "+32 1"):
            assert leak not in prompt, f"{leak} leaked into the advisory prompt"

    def test_snapshot_carries_no_personal_field(self):
        import json
        snap = self._snapshot()
        blob = json.dumps(snap, ensure_ascii=False)
        for leak in ("Kaya", "Nilsson", "ana@x.com", "halal", "p1"):
            assert leak not in blob

    # -- the grounding guard still applies ---------------------------------
    def test_an_invented_figure_is_thrown_away_for_the_computed_digest(self):
        from services import chatbot_service
        invented = ("Votre événement se présente bien : 187 participants sont sans transfert "
                    "et 42 sans hôtel, ce qui reste gérable.")
        with patch("services.ai_service.ai_text", return_value=invented):
            r = chatbot_service.answer_question(
                "je peux encore ameliorer quoi ?", self.EVENT_ID,
                self._supabase(), user_role="admin",
            )
        assert r["answered"] is True
        assert "187" not in r["answer"] and "42" not in r["answer"]
        assert "3 participants" in r["answer"]          # the computed digest

    def test_a_grounded_answer_is_kept_verbatim(self):
        from services import chatbot_service
        grounded = ("Sur les 3 participants consolidés, la couverture est de 67 % pour le vol. "
                    "Deux points méritent votre attention avant le départ.")
        with patch("services.ai_service.ai_text", return_value=grounded):
            r = chatbot_service.answer_question(
                "je peux encore ameliorer quoi ?", self.EVENT_ID,
                self._supabase(), user_role="admin",
            )
        assert r["answer"] == grounded

    # -- an off-topic question is still refused ----------------------------
    def test_off_topic_question_is_still_refused(self):
        from services import chatbot_service
        with patch("services.ai_service.ai_json", return_value=None), \
             patch("services.ai_service.ai_text", return_value="HORS_SUJET"):
            r = chatbot_service.answer_question(
                "Quelle est la capitale du Japon ?", self.EVENT_ID, self._supabase()
            )
        assert r["answered"] is False
        assert r["intent"] is None
        assert r["rows"] == []

    def test_off_topic_question_gets_no_digest_during_an_outage(self):
        """No provider at all: an advisory-shaped question still gets the
        computed digest, but an unrelated one must not — a digest is an answer
        to a question that was not asked."""
        from services import chatbot_service
        with patch("services.ai_service.ai_json", return_value=None), \
             patch("services.ai_service.ai_text", return_value=None):
            r = chatbot_service.answer_question(
                "Quelle est la capitale du Japon ?", self.EVENT_ID, self._supabase()
            )
        assert r["answered"] is False

    # -- unavailable tables are omitted, never reported as zero ------------
    def test_an_unavailable_table_is_left_out_rather_than_counted_as_zero(self):
        snap = self._snapshot(communications_raises=True)
        assert "communications_pas_encore_envoyees" not in snap
        assert "fusions_en_attente_de_validation" in snap        # this one answered

    def test_snapshot_counts_come_from_the_rows(self):
        snap = self._snapshot(exceptions=[
            {"severity": "critical", "exception_type": "DATA_CONFLICT", "context_data": {}},
            {"severity": "warning", "exception_type": "MISSING_REQUIRED_FIELD",
             "context_data": {"systemic_anomaly": True}},
        ])
        quality = snap["qualite_des_donnees"]
        assert quality["exceptions_non_resolues"] == 2
        assert quality["critiques"] == 1
        assert quality["contradictions_entre_fichiers"] == 1
        assert quality["anomalies_de_mapping_suspectees"] == 1
        assert snap["couverture"]["vol"] == {"avec": 2, "sans": 1, "couverture_pct": 67}

    def test_advisory_markers_do_not_hijack_filter_questions(self):
        from services import chatbot_service
        for q in ("Quels participants n'ont pas de vol ?",
                  "combien viennent d'Europe",
                  "ya combien de personne sans vols et sans hebergement",
                  "Quels participants ont un vol mais aucun transfert ?"):
            assert not chatbot_service._looks_advisory(q), q


# ===========================================================================
# The fiche must show what the sources hold
# ===========================================================================

class _FakeQuery:
    """Just enough PostgREST for the backfill: select / eq / in_ / range /
    limit / execute over a list of dicts, plus update().eq()."""

    def __init__(self, table):
        self._t = table
        self._rows = list(table.rows)
        self._patch = None

    def select(self, *_a, **_k):
        return self

    def update(self, patch):
        self._patch = patch
        return self

    def insert(self, rows):
        self._t.inserted.extend(rows if isinstance(rows, list) else [rows])
        return self

    def eq(self, col, val):
        if self._patch is not None:
            for r in self._t.rows:
                if r.get(col) == val:
                    r.update(self._patch)
                    self._t.updated.append((r.get("id"), dict(self._patch)))
            self._rows = []
            return self
        self._rows = [r for r in self._rows if r.get(col) == val]
        return self

    def in_(self, col, vals):
        self._rows = [r for r in self._rows if r.get(col) in set(vals)]
        return self

    def range(self, start, end):
        self._rows = self._rows[start:end + 1]
        return self

    def limit(self, n):
        self._rows = self._rows[:n]
        return self

    def single(self):
        self._single = True
        return self

    def execute(self):
        if getattr(self, "_single", False):
            return SimpleNamespace(data=self._rows[0] if self._rows else None)
        return SimpleNamespace(data=self._rows)


class _FakeTable:
    def __init__(self, rows):
        self.rows = rows
        self.updated = []
        self.inserted = []


class _FakeSupabase:
    def __init__(self, **tables):
        self.tables = {name: _FakeTable(rows) for name, rows in tables.items()}

    def table(self, name):
        return _FakeQuery(self.tables.setdefault(name, _FakeTable([])))


class TestFicheShowsWhatTheSourcesHold:
    """The complaint that started this: a fiche showing five empty fields while
    its own source rows -- printed a few centimetres below on the same page --
    carried the business unit, the country and the phone number.

    Measured on the Istanbul event (2026-08-11): 99 fiches of 108 had no
    Societe while 101 rows carried "Business Unit / Corporate Function", and
    103 had no nationality while their flight rows carried the country."""

    EV = "11111111-1111-1111-1111-111111111111"
    P1 = "22222222-2222-2222-2222-222222222222"
    P2 = "33333333-3333-3333-3333-333333333333"

    def _run(self, participants, records):
        from services.consolidation_service import enrich_participants_from_sources
        sb = _FakeSupabase(participants=participants, source_records=records)
        n = enrich_participants_from_sources(self.EV, sb)
        return n, {p["id"]: p for p in sb.tables["participants"].rows}

    def _fiche(self, **over):
        base = {"id": self.P1, "event_id": self.EV, "email": None, "phone": None,
                "company": None, "nationality": None, "dietary_requirements": None,
                "locked_fields": {}}
        base.update(over)
        return base

    def _row(self, pid=None, **nd):
        return {"participant_id": pid or self.P1, "normalized_data": nd}

    # -- the headline case --------------------------------------------------
    def test_the_business_unit_column_reaches_the_societe_field(self):
        """The client's company column is called "Business Unit / Corporate
        Function" and mapped to `function` -- a real canonical field that is
        NOT a participants column, so the value stopped in source_records."""
        n, byid = self._run([self._fiche()], [self._row(function="Innovation")])
        assert n == 1
        assert byid[self.P1]["company"] == "Innovation"

    def test_the_country_on_a_flight_row_reaches_the_fiche(self):
        _, byid = self._run([self._fiche()], [self._row(country="UNITED KINGDOM")])
        assert byid[self.P1]["nationality"] == "UNITED KINGDOM"

    def test_a_phone_only_the_flight_export_carries_reaches_the_fiche(self):
        _, byid = self._run([self._fiche()], [self._row(phone="+491724672014")])
        assert byid[self.P1]["phone"] == "+491724672014"

    # -- what must NOT happen ----------------------------------------------
    def test_an_existing_value_is_never_overwritten(self):
        _, byid = self._run([self._fiche(company="ACME")],
                            [self._row(function="Innovation")])
        assert byid[self.P1]["company"] == "ACME"

    def test_a_locked_field_wins_over_every_source(self):
        _, byid = self._run([self._fiche(locked_fields={"company": True})],
                            [self._row(function="Innovation")])
        assert byid[self.P1]["company"] is None

    def test_a_shared_booking_email_is_refused(self):
        """A travel file's email column is often the BOOKER's address. Yasmin
        Sezgin booked for Robert Radloff, so his flight rows carry her address
        -- stamping it on him would mislabel him AND make the identity engine
        merge the two of them on the next run."""
        _, byid = self._run(
            [self._fiche(id=self.P2, email="yasmin.sezgin@livanova.com"), self._fiche()],
            [self._row(email="yasmin.sezgin@livanova.com")],
        )
        assert byid[self.P1]["email"] is None

    def test_two_empty_fiches_cannot_both_claim_the_same_email(self):
        _, byid = self._run(
            [self._fiche(), self._fiche(id=self.P2)],
            [self._row(email="shared@livanova.com"),
             self._row(pid=self.P2, email="shared@livanova.com")],
        )
        claimed = [p for p in byid.values() if p["email"] == "shared@livanova.com"]
        assert len(claimed) == 1

    def test_a_yes_no_answer_never_becomes_a_dietary_requirement(self):
        """"Do you have any dietary requirements?" is a yes/no question; the
        requirement itself lives in the follow-up column. Copying the ANSWER
        would write "no" onto 83 fiches and count them as documented."""
        _, byid = self._run([self._fiche()], [self._row(food_allergy_info="no")])
        assert byid[self.P1]["dietary_requirements"] is None

    def test_a_real_allergy_text_does_come_through(self):
        _, byid = self._run([self._fiche()],
                            [self._row(food_allergy_info="Shellfish, nuts")])
        assert byid[self.P1]["dietary_requirements"] == "Shellfish, nuts"

    def test_a_redaction_marker_is_not_a_value(self):
        _, byid = self._run([self._fiche()], [self._row(phone="SECURED DATA")])
        assert byid[self.P1]["phone"] is None

    def test_only_the_persons_own_rows_are_read(self):
        _, byid = self._run(
            [self._fiche(), self._fiche(id=self.P2)],
            [self._row(pid=self.P2, function="Innovation")],
        )
        assert byid[self.P1]["company"] is None
        assert byid[self.P2]["company"] == "Innovation"

    def test_a_complete_fiche_costs_no_write(self):
        n, _ = self._run(
            [self._fiche(email="a@b.c", phone="1", company="X",
                         nationality="FR", dietary_requirements="rien")],
            [self._row(function="Innovation")],
        )
        assert n == 0


class TestTrendReadsAKeyTheRunActuallyWrites:
    """The trend line charted stats["participants"] and the delta labelled it —
    a key run_consolidation has never written, in the code or in production.
    The tests were green because the fixture invented it: the sparkline was
    always empty, and the only delta that ever showed was
    participants_created, a PER-RUN counter. Subtracting two of those made the
    dashboard announce "-13 nouveaux participants" (production, 2026-08-12)."""

    def test_every_state_metric_is_written_by_a_run(self):
        import inspect
        from services import consolidation_service
        from services.dashboard_service import STATE_METRICS
        src = inspect.getsource(consolidation_service.run_consolidation)
        for key in STATE_METRICS:
            assert f'stats["{key}"]' in src, f"{key} is differenced but never written"

    def test_per_run_counters_are_not_differenced(self):
        """Subtracting a counter that resets every run is meaningless."""
        from services.dashboard_service import STATE_METRICS
        for counter in ("participants_created", "participants_updated",
                        "matched_certain", "matched_probable",
                        "stale_records_purged", "total_source_records"):
            assert counter not in STATE_METRICS

    def test_a_counter_that_dropped_produces_no_change(self):
        from services.dashboard_service import _delta
        points = [
            {"at": "2026-08-10T10:00:00+00:00",
             "stats": {"participants_created": 13, "participants_total": 108}},
            {"at": "2026-08-12T10:00:00+00:00",
             "stats": {"participants_created": 0, "participants_total": 121}},
        ]
        changes = _delta(points)["changes"]
        assert "participants_created" not in changes
        assert changes["participants_total"] == 13

class TestDashboardAndAssistantReadTheSameColumns:
    """The dashboard's "Priorités" panel announced 108 fiches with no email on
    an event where 106 had one — and 108 with no phone, and 108 with no
    nationality — while the master list two clicks away showed them all.

    Cause: _event_snapshot computes the gaps off the `people` list its CALLER
    hands it, and the dashboard selected only `company` plus the coverage
    flags. A column the snapshot reads but the caller never fetched does not
    read as "unknown" — it reads as "missing on every single participant". The
    product was accusing itself of having no data."""

    def test_the_dashboard_selects_every_column_the_snapshot_reads(self):
        from services.chatbot_service import SNAPSHOT_PARTICIPANT_COLS, _PROFILE_GAP_FIELDS
        selected = {c.strip() for c in SNAPSHOT_PARTICIPANT_COLS.split(",")}
        for field, _label in _PROFILE_GAP_FIELDS:
            assert field in selected, f"{field} is read by the snapshot but never selected"
        for flag in ("has_flight", "has_hotel", "has_transfer", "has_activities"):
            assert flag in selected

    def test_the_dashboard_does_not_keep_its_own_column_list(self):
        """The two must share ONE constant. Two lists that happen to agree
        today is how they came to disagree in the first place."""
        import inspect
        from services import dashboard_service
        src = inspect.getsource(dashboard_service._participants)
        assert "SNAPSHOT_PARTICIPANT_COLS" in src
        assert "has_flight" not in src, "the column list is duplicated again"

    def test_a_filled_field_is_not_reported_as_a_gap(self):
        from services.chatbot_service import _PROFILE_GAP_FIELDS
        people = [{"id": "1", "email": "a@b.c", "phone": "+3222", "nationality": "FR",
                   "company": None, "completeness_status": "complete",
                   "has_flight": True, "has_hotel": True,
                   "has_transfer": True, "has_activities": True}]
        gaps = {}
        for field, label in _PROFILE_GAP_FIELDS:
            n = sum(1 for p in people if not str(p.get(field) or "").strip())
            if n:
                gaps[label] = n
        assert gaps == {"société": 1}

class TestSamePersonTwoEmailAddresses:
    """The MVP's own promise, failing in production (2026-08-12): four people —
    Adam Birge, Ernest Oakes, Ahmet Tezel, Sujay Mashru — each sat on TWO
    fiches carrying the SAME mobile number written two ways, with two email
    addresses. Every merge pass refuses a bucket holding two distinct emails,
    because two people can share a name. But a differing email has an innocent
    explanation the engine never used: a travel export's address is often the
    BOOKER's, and a corporate directory carries both eoakes@ and
    ernest.oakes@. An identical phone number settles it."""

    EV = "44444444-4444-4444-4444-444444444444"

    def _run(self, participants):
        from services import consolidation_service as cs
        sb = _FakeSupabase(participants=participants)
        merged = []

        def fake_merge(_sb, loser_id, winner_id):
            merged.append((loser_id, winner_id))
            return True

        original = cs._merge_participant_into
        cs._merge_participant_into = fake_merge
        try:
            n = cs.merge_same_phone_duplicates(self.EV, sb)
        finally:
            cs._merge_participant_into = original
        return n, merged

    def _p(self, pid, first, last, email, phone):
        return {"id": pid, "event_id": self.EV, "first_name": first, "last_name": last,
                "email": email, "phone": phone, "company": None, "nationality": None,
                "registration_source_id": None}

    def test_the_same_number_written_two_ways_is_one_person(self):
        n, merged = self._run([
            self._p("a", "Ernest", "Oakes", "eoakes@livanova.com", "(+1) 2142931656"),
            self._p("b", "Ernest", "Oakes", "ernest.oakes@livanova.com", "+12142931656"),
        ])
        assert n == 1 and len(merged) == 1

    def test_a_bookers_address_does_not_keep_the_traveller_apart(self):
        n, _ = self._run([
            self._p("a", "Ahmet", "Tezel", "yasmin.sezgin@livanova.com", "(+1) (862) 272 1646"),
            self._p("b", "Ahmet", "Tezel", "ahmet.tezel@livanova.com", "+18622721646"),
        ])
        assert n == 1

    # -- what must NOT be merged -------------------------------------------
    def test_two_namesakes_on_different_numbers_stay_apart(self):
        n, _ = self._run([
            self._p("a", "Jean", "Dupont", "j.dupont@acme.com", "+32470112233"),
            self._p("b", "Jean", "Dupont", "jean.dupont@other.com", "+32470999999"),
        ])
        assert n == 0

    def test_different_people_sharing_a_switchboard_number_stay_apart(self):
        n, _ = self._run([
            self._p("a", "Jean", "Dupont", "j@acme.com", "+3223334444"),
            self._p("b", "Marie", "Curie", "m@acme.com", "+3223334444"),
        ])
        assert n == 0

    def test_a_too_short_number_is_not_evidence(self):
        """A truncated or placeholder value must never bring strangers together."""
        n, _ = self._run([
            self._p("a", "Jean", "Dupont", "j.dupont@acme.com", "1234"),
            self._p("b", "Jean", "Dupont", "jean.dupont@other.com", "1234"),
        ])
        assert n == 0

    def test_a_fiche_without_a_phone_is_left_alone(self):
        n, _ = self._run([
            self._p("a", "Jean", "Dupont", "j.dupont@acme.com", None),
            self._p("b", "Jean", "Dupont", "jean.dupont@other.com", None),
        ])
        assert n == 0

    def test_a_maiden_name_on_one_side_still_merges(self):
        """The pair that survived the first version of this pass: same mobile,
        one fiche carrying a name the other omits ("Yasmin Sezgin" vs "Yasmin
        Sezgin Stuart"). Bucketing on the name AND the number demanded the two
        spellings match exactly, so they were never even compared."""
        n, _ = self._run([
            self._p("a", "Yasmin", "Sezgin", "yasmin.sezgin@livanova.com", "(+44) 7554 331654"),
            self._p("b", "Yasmin", "Sezgin Stuart", None, "+447554331654"),
        ])
        assert n == 1

    def test_the_bucket_is_the_number_not_the_name(self):
        import inspect
        from services import consolidation_service
        src = inspect.getsource(consolidation_service.merge_same_phone_duplicates)
        assert "buckets.setdefault(digits, [])" in src, "the name is back in the bucket key"

    def test_a_shared_number_still_needs_the_names_to_agree(self):
        """Bucketing on the number alone puts strangers together — the name
        check is what must keep them apart."""
        n, _ = self._run([
            self._p("a", "Jean", "Dupont", "j@acme.com", "+3223334444"),
            self._p("b", "Marie", "Curie", "m@acme.com", "+3223334444"),
            self._p("c", "Paul", "Martin", "p@acme.com", "+3223334444"),
        ])
        assert n == 0

    def test_the_pass_runs_inside_a_consolidation(self):
        import inspect
        from services import consolidation_service
        src = inspect.getsource(consolidation_service.run_consolidation)
        assert "merge_same_phone_duplicates" in src

class TestMeetingReferenceIsNotAnActivity:
    """The Activities page listed 17 activities where the files describe 3.
    A travel export carries the MEETING the trip was booked under — FCM names
    the column "Meetinf name" (sic) — and it maps to activity_name by name
    similarity, so every booking reference became an activity: "BLANK" with 8
    attendees, "0", "AA11", and seven spellings of the summit's own name. It
    also inflated the dashboard's activity coverage, since a participant
    "had an activity" merely because their ticket carried a meeting code
    (production, 2026-08-12)."""

    def _f(self, value, event_name=""):
        from services.consolidation_service import _is_real_activity
        return _is_real_activity(value, event_name)

    # -- the three real activities in the client's files --------------------
    def test_the_genuine_activities_are_kept(self):
        for name in ("Istanbul Old Town tour with tastings",
                     "Boat racing on the Golden Horn",
                     "Free time", "Dîner de gala", "Visite du Bosphore"):
            assert self._f(name), name

    # -- the fourteen phantoms it produced ---------------------------------
    def test_every_spelling_of_the_meeting_reference_is_refused(self):
        for name in ("2026INNOVATIONSUMMIT", "026INNOVATIONSUMMIT",
                     "INNOVATION SUMMIT", "INNOVATION SUMMIT 2026",
                     "2026 INNOVATION SUMMIT", "GLOBAL INNOVATION SUMMIT",
                     "2026 GLOBAL INNOVATION SUMMIT", "GLOBAL INNOVATION MEETING",
                     "INNOVATION SUMMIT ISTANBUL", "INNOVATION SUMMIT 26 ISTANBUL",
                     "INNOVATION COMMUNITY"):
            assert not self._f(name), name

    def test_a_placeholder_never_becomes_an_activity(self):
        for name in ("BLANK", "blank", "0", "N/A", "-", "", None, "aucune"):
            assert not self._f(name), repr(name)

    def test_a_bare_booking_code_is_refused(self):
        assert not self._f("AA11")

    def test_the_event_is_not_one_of_its_own_activities(self):
        assert not self._f("Istambul summit", "Istambul summit")

    def test_a_real_activity_survives_a_matching_event_name(self):
        assert self._f("Boat racing on the Golden Horn", "Istambul summit")

    def test_the_extractor_uses_the_filter(self):
        import inspect
        from services import consolidation_service
        src = inspect.getsource(consolidation_service.extract_domain_data_from_sources)
        assert "_is_real_activity(act_name" in src

class TestExportFilenameCarriesTheEventName:
    """An export called "export_8c805e54_20260812.xlsx" — eight characters of a
    UUID — is meaningless the moment the file leaves the app and lands in a
    client's Downloads folder beside a dozen others."""

    def _slug(self, name, event_id="8c805e54-858b-4534-bda9-4b1415adc362"):
        from routers.exports import _export_slug
        sb = _FakeSupabase(events=[{"id": event_id, "name": name}])
        return _export_slug(event_id, sb)

    def test_the_event_name_is_in_the_filename(self):
        assert self._slug("Istambul summit") == "master-list_Istambul-summit"

    def test_accents_are_folded(self):
        """A Storage path and a Content-Disposition header both mishandle them."""
        assert self._slug("Séminaire Été 2026") == "master-list_Seminaire-Ete-2026"

    def test_path_breaking_characters_are_dropped(self):
        """A slash would create a phantom folder in Storage; a quote breaks the
        download header."""
        out = self._slug('LivaNova / Réunion "clients" (VIP)')
        assert "/" not in out and '"' not in out and " " not in out
        assert out == "master-list_LivaNova-Reunion-clients-VIP"

    def test_a_very_long_name_is_truncated(self):
        out = self._slug("A" * 200)
        assert len(out) <= len("master-list_") + 60

    def test_a_nameless_event_still_exports(self):
        """A cosmetic detail must never be what makes an export fail."""
        assert self._slug("   ") == "export_8c805e54"

    def test_an_unreadable_event_still_exports(self):
        from routers.exports import _export_slug

        class Boom:
            def table(self, _n):
                raise RuntimeError("database down")

        assert _export_slug("8c805e54-858b-4534-bda9-4b1415adc362", Boom()) == "export_8c805e54"

class TestSigningInOpensAWorkedOnEvent:
    """lib/landing.ts sends the user to events[0] after signing in, and the
    query had no ORDER BY — Postgres returned whatever order it liked. On a
    real account that opened an EMPTY event created days earlier while the one
    being worked on sat second: a dashboard reading 0 participants, 0 sources,
    as the first screen after login (2026-08-12)."""

    def test_the_event_list_is_ordered_most_recent_first(self):
        import inspect
        from routers import events
        src = inspect.getsource(events.list_events)
        assert '.order("updated_at", desc=True)' in src
        assert '.order("created_at", desc=True)' in src, "created_at breaks the tie"

    def test_the_landing_page_takes_the_first_event(self):
        """The ordering above only matters because of this. If landing.ts stops
        using events[0], this test should be updated, not deleted."""
        from pathlib import Path
        web = Path(__file__).resolve().parents[2] / "web" / "src" / "lib" / "landing.ts"
        if not web.exists():
            import pytest
            pytest.skip("frontend not checked out beside the API")
        assert "events[0].id" in web.read_text(encoding="utf-8")

class TestRoundTripMasterfile:
    """A client masterfile puts BOTH legs on one row: "Airline / Flight Number
    / Depart Date / Depart Time" for the outbound, then "Airline3 / Flight
    Number4 / Depart Date6 / Depart Time7 / Arrive City" for the way home.
    Only the first block was ever read -- the return flight of 94 of that
    file's 124 travellers did not exist in the app."""

    def _map(self, columns, rows):
        from services.mapping_service import suggest_mapping
        return {c: v["suggested_field"] for c, v in suggest_mapping(columns, rows).items()}

    COLS = ["Airline", "Flight Number", "Depart Date", "Depart Time",
            "Depart Airport", "Depart City", "Arrive Date", "Arrive Time",
            "Airline3", "Flight Number4", "Depart Date6", "Depart Time7", "Arrive City"]
    ROW = {"Airline": "SINGAPORE AIRLINES", "Flight Number": "0392",
           "Depart Date": "2026-06-22", "Depart Time": "2:15 AM",
           "Depart Airport": "SIN", "Depart City": "SINGAPORE",
           "Arrive Date": "2026-06-22", "Arrive Time": "8:30 AM",
           "Airline3": "SINGAPORE AIRLINES", "Flight Number4": "0391",
           "Depart Date6": "2026-06-26", "Depart Time7": "1:10 PM",
           "Arrive City": "SINGAPORE"}

    def test_the_second_block_maps_to_the_return_leg(self):
        m = self._map(self.COLS, [self.ROW] * 6)
        assert m["Airline3"] == "return_airline"
        assert m["Flight Number4"] == "return_flight_number"
        assert m["Depart Date6"] == "return_departure_date"
        assert m["Depart Time7"] == "return_departure_time"

    def test_the_trailing_arrive_city_belongs_to_the_return_leg(self):
        """It sits AFTER the return block and names where the traveller goes
        home to. Read as the outbound's arrival it turned "SIN -> Istanbul"
        into the nonsense "SIN -> SINGAPORE"."""
        m = self._map(self.COLS, [self.ROW] * 6)
        assert m["Arrive City"] == "return_arrival_city"

    def test_the_first_block_is_untouched(self):
        m = self._map(self.COLS, [self.ROW] * 6)
        assert m["Airline"] == "airline"
        assert m["Flight Number"] == "flight_number"
        assert m["Depart Date"] == "departure_date"
        assert m["Arrive Time"] == "arrival_time"

    def test_a_differently_named_column_is_not_treated_as_a_second_leg(self):
        """The rule keys on the SAME header repeated, not on any competitor:
        "Carrier Name" beside "Airline" must not silently become the return
        leg."""
        m = self._map(["Airline", "Carrier Name", "Flight Number", "Depart Date"],
                      [{"Airline": "TK", "Carrier Name": "Turkish",
                        "Flight Number": "TK1", "Depart Date": "2026-06-22"}] * 6)
        assert m["Carrier Name"] != "return_airline"

    def test_a_single_leg_file_gains_no_return_fields(self):
        m = self._map(["Airline", "Flight Number", "Depart Date", "Arrive City"],
                      [{"Airline": "TK", "Flight Number": "TK1",
                        "Depart Date": "2026-06-22", "Arrive City": "ISTANBUL"}] * 6)
        assert not any(str(v).startswith("return_") for v in m.values())
        assert m["Arrive City"] == "arrival_city"

    def test_the_return_block_becomes_a_second_flight(self):
        """The mapping is only half of it: extraction has to emit two
        segments, or the return leg is mapped and then thrown away."""
        import inspect
        from services import consolidation_service
        src = inspect.getsource(consolidation_service.extract_domain_data_from_sources)
        assert "return_flight_number" in src
        assert "segments" in src


class TestClientMasterfileColumns:
    """Every column of the real file the client sent on 2026-08-11 must land
    somewhere named, not in the custom-field catch-all."""

    def _map(self, columns, rows):
        from services.mapping_service import suggest_mapping
        return {c: v["suggested_field"] for c, v in suggest_mapping(columns, rows).items()}

    def test_the_real_headers_map_to_their_fields(self):
        cols = ["Date \nLast Change", "Email Address", "First Name", "Last Name",
                "VIPs", "Mobile Phone", "Badge Name (first name + last name)",
                "Business Unit / Corporate Function", "Epilepsy, DTD or OSA?",
                "Diet restrictions", "Activity", "Shirt size"]
        row = {"Date \nLast Change": "2026-05-13", "Email Address": "a.b@livanova.com",
               "First Name": "Deborah", "Last Name": "Audano", "VIPs": "ELT",
               "Mobile Phone": "(+39) 3406062499",
               "Badge Name (first name + last name)": "Deborah Audano",
               "Business Unit / Corporate Function": "Innovation",
               "Epilepsy, DTD or OSA?": "OSA", "Diet restrictions": "Vegetarian",
               "Activity": "Istanbul Old Town tour", "Shirt size": "M"}
        m = self._map(cols, [row] * 6)
        assert m["Email Address"] == "email"
        assert m["Mobile Phone"] == "phone"
        assert m["Badge Name (first name + last name)"] == "badge_name"
        assert m["Business Unit / Corporate Function"] == "business_unit"
        assert m["Epilepsy, DTD or OSA?"] == "medical_info"
        assert m["Diet restrictions"] == "dietary_requirements"
        assert m["Shirt size"] == "shirt_size"
        assert m["VIPs"] == "vip_status"

    def test_an_administrative_date_never_steals_the_phone_column(self):
        """"tel" sits inside "da-tel-astchange": the interior substring match
        gave "Date Last Change" a 0.60 phone score, it beat the real "Mobile
        Phone" column on file order, and the phone column was dropped."""
        m = self._map(["Date \nLast Change", "Mobile Phone"],
                      [{"Date \nLast Change": "2026-05-13",
                        "Mobile Phone": "(+39) 3406062499"}] * 6)
        assert m["Mobile Phone"] == "phone"
        assert m["Date \nLast Change"] != "phone"

    def test_an_anchored_short_synonym_still_matches(self):
        """The length floor applies to INTERIOR matches only -- a column
        literally named "Tel" must keep working."""
        m = self._map(["Tel", "Nom"], [{"Tel": "0470112233", "Nom": "Ana Kaya"}] * 6)
        assert m["Tel"] == "phone"

    def test_a_parenthesised_international_number_is_recognised_by_content(self):
        from services.mapping_service import _PHONE_RE
        assert _PHONE_RE.match("(+65) 83881281")
        assert _PHONE_RE.match("+39 340 606 2499")

    def test_the_mapping_does_not_change_from_one_call_to_the_next(self):
        """CANONICAL_FIELDS is a set: an unbroken score tie was resolved by the
        set's iteration order, which Python randomises per process. The same
        file mapped differently from one run to the next."""
        cols = ["Badge Name (first name + last name)", "Email Address"]
        rows = [{"Badge Name (first name + last name)": "Ana Kaya",
                 "Email Address": "a@b.com"}] * 6
        assert len({str(sorted(self._map(cols, rows).items())) for _ in range(5)}) == 1


class TestRoomingGridYear:
    """A rooming grid names a day and a month, never a year. It used to take
    the year from events.start_date — which no event in production has ever
    had set — so every stay fell back to the hardcoded "2025-11-10" and 431
    nights were booked in June 2025, a year before the event, printed in the
    master list beside flights dated 2026 (found in the browser, 2026-08-12)."""

    def _rec(self, **nd):
        return {"normalized_data": nd}

    def test_the_year_comes_from_the_travel_dates(self):
        from services.consolidation_service import _infer_night_year
        records = [self._rec(departure_date="2026-06-22", arrival_date="2026-06-22")] * 5
        assert _infer_night_year(records, "2025-11-10") == 2026

    def test_the_most_frequent_year_wins_over_a_stray_one(self):
        """One person extending into the next year must not move everyone."""
        from services.consolidation_service import _infer_night_year
        records = [self._rec(departure_date="2026-06-22")] * 9 + [self._rec(departure_date="2027-01-03")]
        assert _infer_night_year(records, "2025-11-10") == 2026

    def test_it_falls_back_to_the_event_date_without_travel_dates(self):
        from services.consolidation_service import _infer_night_year
        assert _infer_night_year([self._rec(hotel_name="Conrad")], "2029-03-01") == 2029

    def test_it_never_returns_the_hardcoded_fallback_when_the_file_knows_better(self):
        from services.consolidation_service import _infer_night_year
        assert _infer_night_year([self._rec(arrival_date="2026-06-20")], "2025-11-10") != 2025

    def test_a_grid_year_reaches_the_nights(self):
        from services.consolidation_service import _parse_night_columns
        ci, co = _parse_night_columns({"20-juin": 1, "21-juin": 1}, 2026)
        assert ci.startswith("2026") and co.startswith("2026")

class TestRoomingGridWithoutAHotelName:
    """An event where everyone sleeps in the same hotel names it nowhere: the
    rooming grid is one column per night with a 1 in the cells. Requiring a
    hotel name discarded the whole grid, so every participant read "pas
    d'hotel" however complete the file was."""

    def test_the_night_columns_are_read(self):
        from services.consolidation_service import _parse_night_columns
        raw = {"20-juin": None, "21-juin": 1, "22-juin": 1, "23-juin": 1, "24-juin": None}
        assert _parse_night_columns(raw, 2026) == ("2026-06-21", "2026-06-24")

    def test_a_grid_with_no_night_booked_stays_empty(self):
        from services.consolidation_service import _parse_night_columns
        assert _parse_night_columns({"20-juin": 0, "21-juin": "no"}, 2026) == (None, None)

    def test_a_date_header_does_not_take_the_sheet_down_with_it(self):
        """A rooming grid's per-night columns are very often real Excel DATES,
        not text. `datetime.lower()` raised, the exception bubbled to
        _auto_sheet_mapping's catch-all, and the ENTIRE sheet was dropped
        without a word."""
        from datetime import datetime
        from services.mapping_service import suggest_mapping, _normalize_column_name
        assert _normalize_column_name(datetime(2026, 6, 20)) == "20260620000000"
        cols = ["Email Address", datetime(2026, 6, 20), datetime(2026, 6, 21)]
        rows = [{cols[0]: "a@b.com", cols[1]: 1, cols[2]: 1}] * 4
        sug = suggest_mapping(cols, rows)          # must not raise
        assert sug[cols[0]]["suggested_field"] == "email"

    def test_the_placeholder_property_is_explicit_about_being_unnamed(self):
        from services.consolidation_service import _UNNAMED_HOTEL
        assert "non" in _UNNAMED_HOTEL.lower()

    def test_a_renamed_placeholder_is_reused_not_recreated(self):
        """The hotel is looked up by NAME. Rename the placeholder on the hotels
        page and the next consolidation stops finding it, creates
        _UNNAMED_HOTEL a second time and moves the whole stay onto it — the
        rename silently undone and 431 nights split across two properties."""
        import inspect
        from services import consolidation_service
        src = inspect.getsource(consolidation_service.extract_domain_data_from_sources)
        # The choice is made ONCE before the loop (hotel_map grows inside it),
        # then read by name in the loop.
        assert "_nameless_hotel = next(iter(hotel_map)) if len(hotel_map) == 1" in src
        head = src.split('hotel_name = data.get("hotel_name")')[1][:2000]
        assert "hotel_name = _nameless_hotel" in head

    def test_a_nameless_grid_no_longer_short_circuits_the_hotel_extraction(self):
        import inspect
        from services import consolidation_service
        src = inspect.getsource(consolidation_service.extract_domain_data_from_sources)
        head = src.split('hotel_name = data.get("hotel_name")')[1][:1600]
        # The old short-circuit was an unconditional `continue` on a missing
        # name. It must now first look for a rooming grid.
        assert "_parse_night_columns" in head
        assert "_UNNAMED_HOTEL" in head
