"""
Tests for what deleting a transfer does to participants.has_transfer.

Found while wiring a delete button into the (previously read-only) transfers
list: delete_transfer removed the row and left the flag exactly as it was.
Deleting somebody's only transfer left them reading as "has a transfer" on the
coverage card and the master list, vouching for a booking that no longer
existed.
"""

from unittest.mock import AsyncMock, patch

import pytest

from routers.transfers import delete_transfer


class _Query:
    def __init__(self, table, name):
        self.t = table
        self.name = name
        self.rows = list(table.rows)
        self._single = False
        self._count = False
        self._updating = None
        self._deleting = False

    def select(self, *_a, **kwargs):
        self._count = kwargs.get("count") == "exact"
        return self

    def eq(self, col, val):
        self.rows = [r for r in self.rows if str(r.get(col)) == str(val)]
        return self

    def single(self):
        self._single = True
        return self

    def update(self, patch):
        self._updating = patch
        return self

    def delete(self):
        self._deleting = True
        return self

    def execute(self):
        if self._updating is not None:
            for row in self.t.rows:
                if row in self.rows:
                    row.update(self._updating)
            return type("Res", (), {"data": self.rows})()
        if self._deleting:
            kept = [r for r in self.t.rows if r not in self.rows]
            self.t.rows = kept
            return type("Res", (), {"data": []})()
        data = self.rows[0] if self._single else self.rows
        return type("Res", (), {"data": data, "count": len(self.rows)})()


class _Table:
    def __init__(self, rows):
        self.rows = rows


class FakeSupabase:
    def __init__(self, transfers=None, participants=None):
        self.transfers = _Table(list(transfers or []))
        self.participants = _Table(list(participants or []))

    def table(self, name):
        if name == "transfers":
            return _Query(self.transfers, name)
        if name == "participants":
            return _Query(self.participants, name)
        return _Query(_Table([]), name)


def _transfer(**over):
    base = {
        "id": "tr-1", "event_id": "ev-1", "participant_id": "p-1",
        "transfer_type": "arrival", "pickup_time": "2026-09-01T14:00:00",
    }
    base.update(over)
    return base


@pytest.mark.asyncio
@patch("routers.transfers.verify_event_access", new_callable=AsyncMock)
class TestDeletingATransferUpdatesTheFlag:

    async def test_the_only_transfer_clears_the_flag(self, _verify):
        sb = FakeSupabase(
            transfers=[_transfer()],
            participants=[{"id": "p-1", "has_transfer": True}],
        )
        await delete_transfer("tr-1", {"id": "u-1"}, sb)
        assert sb.participants.rows[0]["has_transfer"] is False

    async def test_a_remaining_second_transfer_keeps_the_flag(self, _verify):
        # Rare, but possible if one was booked twice by hand.
        sb = FakeSupabase(
            transfers=[_transfer(), _transfer(id="tr-2")],
            participants=[{"id": "p-1", "has_transfer": True}],
        )
        await delete_transfer("tr-1", {"id": "u-1"}, sb)
        assert sb.participants.rows[0]["has_transfer"] is True

    async def test_another_participant_s_flag_is_untouched(self, _verify):
        sb = FakeSupabase(
            transfers=[_transfer(), _transfer(id="tr-2", participant_id="p-2")],
            participants=[
                {"id": "p-1", "has_transfer": True},
                {"id": "p-2", "has_transfer": True},
            ],
        )
        await delete_transfer("tr-1", {"id": "u-1"}, sb)
        by_id = {p["id"]: p["has_transfer"] for p in sb.participants.rows}
        assert by_id == {"p-1": False, "p-2": True}

    async def test_the_row_itself_is_gone(self, _verify):
        sb = FakeSupabase(
            transfers=[_transfer()],
            participants=[{"id": "p-1", "has_transfer": True}],
        )
        await delete_transfer("tr-1", {"id": "u-1"}, sb)
        assert sb.transfers.rows == []
