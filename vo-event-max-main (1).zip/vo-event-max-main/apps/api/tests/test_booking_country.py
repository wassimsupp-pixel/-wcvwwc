"""
Tests for differentiating booking_country from nationality in mapping (point 15).

nationality's synonym list carried a bare "pays" — French for "country" — which
matched ANY column with "pays" anywhere in its name at 0.60+ confidence. A real
file's "Pays de réservation" (booking country) scored as nationality before
country or booking_country ever got a look-in, because neither of their own,
more specific synonyms is a substring of "pays". A bare "Pays" column scored
0.90 (exact match) — citizenship, guessed from a header that almost never
means citizenship.
"""

from services.mapping_service import suggest_mapping, CANONICAL_FIELDS
from services.master_list_service import RICH_FIELDS


def _suggest(col: str, values: list[str] | None = None):
    rows = [{col: v} for v in (values or [])]
    return suggest_mapping([col], rows)[col]


class TestBookingCountryIsARealField:

    def test_it_is_a_canonical_field(self):
        assert "booking_country" in CANONICAL_FIELDS

    def test_it_is_surfaced_in_the_master_list(self):
        assert "booking_country" in RICH_FIELDS


class TestABareCountryHeaderNoLongerGuessesNationality:
    """The actual bug: a column literally named "Pays" almost never means
    citizenship, and matching it there swallowed the two fields that
    actually mean something more specific."""

    def test_a_bare_pays_column_does_not_suggest_nationality(self):
        got = _suggest("Pays")
        assert got["suggested_field"] != "nationality"

    def test_a_bare_country_column_does_not_suggest_nationality(self):
        got = _suggest("Country")
        assert got["suggested_field"] != "nationality"


class TestBookingCountryIsRecognisedByItsOwnHeaders:

    def test_pays_de_reservation_suggests_booking_country(self):
        got = _suggest("Pays de réservation")
        assert got["suggested_field"] == "booking_country"

    def test_booking_country_header_suggests_booking_country(self):
        got = _suggest("Booking Country")
        assert got["suggested_field"] == "booking_country"

    def test_country_of_booking_suggests_booking_country(self):
        got = _suggest("Country of Booking")
        assert got["suggested_field"] == "booking_country"

    def test_it_is_never_confused_with_country_of_residence(self):
        # country's own synonyms are unrelated strings, this is just a
        # sanity check the two never collide going forward.
        got = _suggest("Pays de résidence")
        assert got["suggested_field"] != "booking_country"


class TestNationalityStillWorksForActualCitizenshipHeaders:
    """The fields that legitimately mean citizenship are untouched — only the
    dangerously generic "pays" token was removed."""

    def test_nationality_header_still_matches(self):
        assert _suggest("Nationality")["suggested_field"] == "nationality"

    def test_nationalite_header_still_matches(self):
        assert _suggest("Nationalité")["suggested_field"] == "nationality"

    def test_citizenship_header_still_matches(self):
        assert _suggest("Citizenship")["suggested_field"] == "nationality"
