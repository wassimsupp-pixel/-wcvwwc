"""
Tests for a rooming list that is MADE rather than derived.

The property under test throughout is stability. A derived view may change
whenever the data changes — that is what derived means. A generated document
may not, because it has been printed, sent to a hotel, and referred to by
number for three weeks. Everything below exists to pin one of three promises:

  * a number the hotel gave is never touched, by anything, ever;
  * a number we generated survives a regeneration as long as the room still
    holds the same people;
  * what a regeneration would change is knowable BEFORE pressing the button.
"""

import pytest

from services import rooming_plan as P


def _p(pid, first="Ada", last="Lovelace", **over):
    base = {
        "id": pid, "first_name": first, "last_name": last,
        "room_type": None, "room_number": None, "roommate_participant_id": None,
    }
    base.update(over)
    return base


def _pair(a="t", b="l", **over):
    return [
        _p(a, "Tina", "Fey", room_type="twin", roommate_participant_id=b, **over),
        _p(b, "Leslie", "Knope", room_type="twin", roommate_participant_id=a, **over),
    ]


def _night(pid, date, hotel="h1"):
    return {"participant_id": pid, "night_date": date, "hotel_id": hotel}


# ===========================================================================
# Numbering
# ===========================================================================

class TestNumbersGetAssigned:
    """The point of generating: a room with no number comes back with one."""

    def test_a_pair_becomes_one_numbered_room(self):
        out = P.plan(_pair())
        assert len(out["rooms"]) == 1
        assert out["rooms"][0]["room_number"] == "101"
        assert out["rooms"][0]["origin"] == P.GENERATED

    def test_numbering_starts_where_it_is_told_to(self):
        out = P.plan(_pair(), start_number=201)
        assert out["rooms"][0]["room_number"] == "201"

    def test_a_prefix_is_honoured(self):
        out = P.plan(_pair(), prefix="A-")
        assert out["rooms"][0]["room_number"] == "A-101"

    def test_singles_each_get_their_own_number(self):
        people = [_p("a", "Ann"), _p("b", "Bob"), _p("c", "Cy")]
        numbers = [r["room_number"] for r in P.plan(people)["rooms"]]
        assert numbers == ["101", "102", "103"]
        assert len(set(numbers)) == 3

    def test_two_hotels_do_not_share_one_pool(self):
        # Room 101 exists in every hotel on earth; sharing a pool across two
        # hotels wastes numbers and confuses everybody reading either list.
        people = [
            _p("a", "Ann", hotel_name="Ibis"),
            _p("b", "Bob", hotel_name="Mercure"),
        ]
        rooms = P.plan(people)["rooms"]
        assert {r["hotel_name"]: r["room_number"] for r in rooms} == {
            "Ibis": "101", "Mercure": "101",
        }

    def test_the_same_input_always_produces_the_same_list(self):
        people = [_p("a", "Ann"), _p("b", "Bob"), _p("c", "Cy")]
        first = P.plan(people)
        second = P.plan([dict(p) for p in reversed(people)])
        assert first["fingerprint"] == second["fingerprint"]


class TestTheHotelsNumbersAreNotOurs:
    """A number the hotel gave is a fact about a physical room."""

    def test_an_existing_number_is_kept_and_marked_as_theirs(self):
        out = P.plan(_pair(room_number="304"))
        assert out["rooms"][0]["room_number"] == "304"
        assert out["rooms"][0]["origin"] == P.FROM_HOTEL

    def test_we_never_hand_out_a_number_the_hotel_is_using(self):
        people = _pair() + [_p("x", "Xavier", room_number="101")]
        rooms = P.plan(people)["rooms"]
        assigned = [r["room_number"] for r in rooms if r["origin"] == P.GENERATED]
        assert "101" not in assigned

    def test_renumbering_still_leaves_the_hotels_numbers_alone(self):
        people = _pair() + [_p("x", "Xavier", room_number="304")]
        rooms = P.plan(people, renumber=True)["rooms"]
        theirs = [r for r in rooms if r["origin"] == P.FROM_HOTEL]
        assert [r["room_number"] for r in theirs] == ["304"]


# ===========================================================================
# Regeneration
# ===========================================================================

class TestRegenerationDoesNotMoveEverybody:
    """One cancellation must not shift ninety numbers and force a reprint."""

    def _three_singles(self):
        return [_p("a", "Ann"), _p("b", "Bob"), _p("c", "Cy")]

    def test_a_room_keeps_its_number_when_nobody_moved(self):
        first = P.plan(self._three_singles())
        again = P.plan(self._three_singles(), previous=first)
        assert _numbers(again) == _numbers(first)

    def test_a_departure_does_not_renumber_the_survivors(self):
        first = P.plan(self._three_singles())
        after = P.plan([_p("a", "Ann"), _p("c", "Cy")], previous=first)
        assert after["rooms"][0]["room_number"] == _numbers(first)["a"]
        assert after["rooms"][1]["room_number"] == _numbers(first)["c"]

    def test_a_newcomer_reuses_the_number_a_departure_freed(self):
        first = P.plan(self._three_singles())          # a=101 b=102 c=103
        after = P.plan(
            [_p("a", "Ann"), _p("c", "Cy"), _p("d", "Dee")], previous=first
        )
        assert _numbers(after)["d"] == "102"

    def test_a_broken_pair_does_not_leave_two_people_in_one_room(self):
        # The number belonged to the ROOM, not to either of them. Letting both
        # inherit it would print one number against two separate rooms.
        first = P.plan(_pair())
        assert len(first["rooms"]) == 1
        split = [_p("t", "Tina", "Fey"), _p("l", "Leslie", "Knope")]
        after = P.plan(split, previous=first)
        assert len(after["rooms"]) == 2
        assert after["rooms"][0]["room_number"] != after["rooms"][1]["room_number"]

    def test_a_pair_that_re_forms_gets_its_old_number_back(self):
        first = P.plan(_pair() + [_p("x", "Xavier")])
        pair_number = _numbers(first)["t"]
        split = P.plan(
            [_p("t", "Tina", "Fey"), _p("l", "Leslie", "Knope"), _p("x", "Xavier")],
            previous=first,
        )
        again = P.plan(_pair() + [_p("x", "Xavier")], previous=split)
        assert _numbers(again)["t"] == _numbers(again)["l"]

    def test_renumber_lays_our_own_numbers_out_again(self):
        first = P.plan(self._three_singles())
        after = P.plan(
            [_p("a", "Ann"), _p("c", "Cy")], previous=first, renumber=True
        )
        assert _numbers(after) == {"a": "101", "c": "102"}

    def test_a_generation_without_the_previous_one_starts_over(self):
        first = P.plan(self._three_singles())
        blind = P.plan([_p("c", "Cy")], previous=None)
        assert blind["rooms"][0]["room_number"] == "101"
        assert _numbers(first)["c"] == "103"


class TestStaleness:
    """The system reports the drift; a human resolves it."""

    def test_an_unchanged_event_keeps_its_fingerprint(self):
        first = P.plan(_pair())
        assert P.plan(_pair(), previous=first)["fingerprint"] == first["fingerprint"]

    def test_a_departure_changes_the_fingerprint(self):
        first = P.plan(_pair())
        after = P.plan([_p("t", "Tina", "Fey")], previous=first)
        assert after["fingerprint"] != first["fingerprint"]

    def test_a_new_night_changes_the_fingerprint(self):
        people = _pair()
        first = P.plan(people, [_night("t", "2027-03-01")])
        after = P.plan(people, [_night("t", "2027-03-01"), _night("t", "2027-03-02")],
                       previous=first)
        assert after["fingerprint"] != first["fingerprint"]


# ===========================================================================
# Knowing before pressing
# ===========================================================================

class TestTheDiffIsReadableBeforeGenerating:

    def test_a_first_generation_reports_nothing(self):
        # Every line would say "new", which is true and useless.
        assert P.differences(None, P.plan(_pair())) == []
        assert P.differences({"rooms": []}, P.plan(_pair())) == []

    def test_a_departure_is_reported_as_a_departure(self):
        first = P.plan(_pair())
        after = P.plan([_p("t", "Tina", "Fey")], previous=first)
        kinds = {c["participant_id"]: c["kind"] for c in P.differences(first, after)}
        assert kinds["l"] == "removed"

    def test_an_arrival_is_reported_with_its_room(self):
        first = P.plan([_p("a", "Ann")])
        after = P.plan([_p("a", "Ann"), _p("b", "Bob")], previous=first)
        added = [c for c in P.differences(first, after) if c["kind"] == "added"]
        assert added[0]["participant_id"] == "b"
        assert added[0]["to"] == "102"

    def test_a_move_reports_both_numbers(self):
        first = P.plan([_p("a", "Ann"), _p("b", "Bob")])
        after = P.plan([_p("b", "Bob")], previous=first, renumber=True)
        moved = [c for c in P.differences(first, after) if c["kind"] == "moved"]
        assert moved[0] == {
            "participant_id": "b", "name": "Bob Lovelace",
            "kind": "moved", "from": "102", "to": "101",
        }

    def test_a_new_roommate_in_the_same_room_is_reported(self):
        first = P.plan(_pair())
        swapped = [
            _p("t", "Tina", "Fey", room_type="twin", roommate_participant_id="z"),
            _p("z", "Zoe", "Barnes", room_type="twin", roommate_participant_id="t"),
        ]
        after = P.plan(swapped, previous=first)
        kinds = {c["participant_id"]: c["kind"] for c in P.differences(first, after)}
        assert kinds["t"] == "roommate_changed"

    def test_the_sentence_reads_in_french_and_counts_correctly(self):
        first = P.plan([_p("a", "Ann"), _p("b", "Bob")])
        after = P.plan([_p("a", "Ann"), _p("c", "Cy")], previous=first)
        line = P.describe(P.differences(first, after))
        assert "1 départ(s)" in line
        assert "1 arrivée(s)" in line

    def test_no_change_says_so(self):
        assert P.describe([]) == "Aucun changement."


# ===========================================================================
# What gets written back
# ===========================================================================

class TestWriteBack:

    def test_only_the_numbers_we_generated_are_written(self):
        people = _pair() + [_p("x", "Xavier", room_number="304")]
        out = P.plan(people)
        assert P.assignments(out) == {"t": "101", "l": "101"}

    def test_both_roommates_get_the_same_number(self):
        out = P.plan(_pair())
        assert len(set(P.assignments(out).values())) == 1


# ===========================================================================
# Refusals
# ===========================================================================

class TestItRefusesRatherThanEmitNonsense:

    def test_an_absurd_number_of_rooms_is_refused(self):
        people = [_p(f"p{i}", f"P{i}") for i in range(P.MAX_ROOMS + 1)]
        with pytest.raises(P.RoomingPlanError):
            P.plan(people)

    def test_an_empty_event_generates_an_empty_list_without_crashing(self):
        out = P.plan([])
        assert out["rooms"] == []
        assert out["summary"]["rooms"] == 0


# ===========================================================================
# The summary an organizer phones the hotel with
# ===========================================================================

class TestSummary:

    def test_nothing_is_unassigned_once_generated(self):
        out = P.plan([_p("a", "Ann"), _p("b", "Bob")])
        assert out["summary"]["unassigned"] == 0

    def test_it_separates_our_numbers_from_theirs(self):
        people = _pair() + [_p("x", "Xavier", room_number="304")]
        summary = P.plan(people)["summary"]
        assert summary["generated_numbers"] == 1
        assert summary["hotel_numbers"] == 1

    def test_the_participant_view_covers_everybody(self):
        out = P.plan(_pair() + [_p("x", "Xavier")])
        assert len(out["participants"]) == 3


def _numbers(plan_out):
    """participant id -> the number this plan puts them in, ours or theirs."""
    return {
        o["participant_id"]: room["room_number"]
        for room in plan_out["rooms"]
        for o in room["occupants"]
    }


# ===========================================================================
# The endpoints — where "generated, not automatic" is actually enforced
# ===========================================================================
#
# The service above can only promise that a plan is stable. Only the router can
# promise that nothing produces one without being asked, which is the whole
# point of the feature.

import asyncio
from types import SimpleNamespace

import routers.hotels as H

EV = "11111111-1111-1111-1111-111111111111"
USER = {"id": "99999999-9999-9999-9999-999999999999", "role": "admin"}


class _Q:
    """Enough PostgREST for these endpoints: select/eq/in_/order/limit/insert,
    plus update().eq() writing through to the stored rows."""

    def __init__(self, table, missing):
        self._t = table
        self._missing = missing
        self._rows = list(table.rows)
        self._patch = None

    def _check(self):
        if self._missing:
            raise RuntimeError(f'relation "{self._t.name}" does not exist')

    def select(self, *_a, **_k):
        self._check()
        return self

    def insert(self, rows):
        self._check()
        rows = rows if isinstance(rows, list) else [rows]
        for row in rows:
            row.setdefault("id", f"row-{len(self._t.rows) + 1}")
            row.setdefault("generated_at", "2027-03-01T10:00:00Z")
            self._t.rows.append(row)
        self._rows = rows
        return self

    def update(self, patch):
        self._check()
        self._patch = patch
        return self

    def eq(self, col, val):
        if self._patch is not None:
            for r in self._t.rows:
                if r.get(col) == val:
                    r.update(self._patch)
            self._rows = []
            return self
        self._rows = [r for r in self._rows if r.get(col) == val]
        return self

    def in_(self, col, vals):
        self._rows = [r for r in self._rows if r.get(col) in set(vals)]
        return self

    def order(self, col, desc=False):
        self._rows = sorted(self._rows, key=lambda r: r.get(col) or 0, reverse=desc)
        return self

    def limit(self, n):
        self._rows = self._rows[:n]
        return self

    def range(self, start, end):
        self._rows = self._rows[start:end + 1]
        return self

    def execute(self):
        return SimpleNamespace(data=self._rows)


class _Table:
    def __init__(self, name, rows):
        self.name, self.rows = name, rows


class _DB:
    """``missing`` names tables this deployment has not migrated yet."""

    def __init__(self, missing=(), **tables):
        self._missing = set(missing)
        self.tables = {n: _Table(n, r) for n, r in tables.items()}

    def table(self, name):
        if name not in self.tables:
            self.tables[name] = _Table(name, [])
        return _Q(self.tables[name], name in self._missing)


@pytest.fixture(autouse=True)
def _no_access_check(monkeypatch):
    async def _ok(*_a, **_k):
        return True
    monkeypatch.setattr(H, "verify_event_access", _ok)
    monkeypatch.setattr(H, "log_change", lambda *a, **k: None)


def _db(participants=None, missing=()):
    rows = []
    for p in participants or []:
        rows.append({**p, "event_id": EV})
    return _DB(missing=missing, participants=rows, hotels=[], rooming_lists=[])


def _get(db, **kw):
    return asyncio.run(H.rooming_list(EV, current_user=USER, supabase=db, **kw))


def _generate(db, **kw):
    body = H.RoomingGenerateRequest(**kw) if kw else None
    return asyncio.run(
        H.generate_rooming_list(EV, body=body, current_user=USER, supabase=db)
    )


class TestNothingIsGeneratedUntilSomebodyAsks:
    """The complaint behind the feature: the list appeared by itself."""

    def test_an_ungenerated_event_shows_an_empty_list(self):
        out = _get(_db(_pair()))
        assert out["generated"] is False
        assert out["rooms"] == []

    def test_it_says_the_feature_is_available_so_the_screen_can_offer_it(self):
        out = _get(_db(_pair()))
        assert out["storage_available"] is True

    def test_the_preview_shows_what_would_happen_without_committing_it(self):
        db = _db(_pair())
        preview = asyncio.run(
            H.rooming_list_preview(
                EV, start_number=101, prefix="", renumber=False,
                current_user=USER, supabase=db,
            )
        )
        assert len(preview["rooms"]) == 1
        assert db.tables["rooming_lists"].rows == []
        assert _get(db)["generated"] is False

    def test_generating_is_what_produces_a_list(self):
        db = _db(_pair())
        out = _generate(db)
        assert out["version"] == 1
        assert _get(db)["generated"] is True


class TestAGeneratedListStaysPut:

    def test_a_later_departure_does_not_change_what_was_generated(self):
        db = _db(_pair())
        _generate(db)
        db.tables["participants"].rows = [
            r for r in db.tables["participants"].rows if r["id"] != "l"
        ]
        out = _get(db)
        assert {o["name"] for o in out["rooms"][0]["occupants"]} == {"Tina Fey", "Leslie Knope"}

    def test_but_it_is_flagged_stale_and_says_what_moved(self):
        db = _db(_pair())
        _generate(db)
        db.tables["participants"].rows = [
            r for r in db.tables["participants"].rows if r["id"] != "l"
        ]
        out = _get(db)
        assert out["stale"] is True
        # Two facts, both worth printing: Leslie is gone, AND Tina is now alone
        # in a twin — which is the one the hotel will want to hear about.
        by_person = {c["participant_id"]: c["kind"] for c in out["changes"]}
        assert by_person == {"l": "removed", "t": "roommate_changed"}

    def test_an_untouched_event_is_not_stale(self):
        db = _db(_pair())
        _generate(db)
        assert _get(db)["stale"] is False

    def test_versions_accumulate_rather_than_overwrite(self):
        db = _db(_pair())
        _generate(db)
        _generate(db)
        versions = asyncio.run(
            H.rooming_list_versions(EV, current_user=USER, supabase=db)
        )["versions"]
        assert [v["version"] for v in versions] == [2, 1]


class TestGenerationWritesTheNumbersOntoTheFiches:

    def test_the_number_reaches_the_participant(self):
        db = _db(_pair())
        _generate(db)
        numbers = {r["id"]: r.get("room_number") for r in db.tables["participants"].rows}
        assert numbers == {"t": "101", "l": "101"}

    def test_a_locked_number_is_left_alone(self):
        people = _pair()
        people[0]["locked_fields"] = {"room_number": True}
        people[0]["room_number"] = "999"
        db = _db(people)
        _generate(db)
        numbers = {r["id"]: r.get("room_number") for r in db.tables["participants"].rows}
        assert numbers["t"] == "999"


class TestItDegradesInsteadOfCrashing:

    def test_without_migration_013_the_screen_still_renders(self):
        out = _get(_db(_pair(), missing=("rooming_lists",)))
        assert out["available"] is True
        assert out["storage_available"] is False
        assert len(out["rooms"]) == 1        # the old live derivation

    def test_and_generating_says_why_it_cannot(self):
        from fastapi import HTTPException
        with pytest.raises(HTTPException) as err:
            _generate(_db(_pair(), missing=("rooming_lists",)))
        assert err.value.status_code == 409
        assert "013" in err.value.detail

    def test_without_migration_012_nothing_is_offered_at_all(self):
        out = _get(_db(_pair(), missing=("participants",)))
        assert out["available"] is False
        assert out["rooms"] == []

    def test_generating_an_event_with_nobody_is_refused(self):
        from fastapi import HTTPException
        with pytest.raises(HTTPException) as err:
            _generate(_db([]))
        assert err.value.status_code == 422


# ===========================================================================
# A twin with nobody on the other side blocks the list (§4)
# ===========================================================================

class TestRoommateGapsBlockGeneration:
    """An hotelier reading "twin" next to one name either gives that room to
    one person or phones to ask. Both cost money, so the list refuses to be
    generated until somebody has looked at the gaps."""

    def _lonely(self):
        # Asked for a twin, named nobody, and nothing has paired them.
        return [_p("x", "Tina", "Fey", room_type="twin")]

    def test_a_twin_with_no_roommate_refuses_to_generate(self):
        with pytest.raises(H.HTTPException) as exc:
            _generate(_db(self._lonely()))
        assert exc.value.status_code == 409
        assert exc.value.detail["code"] == "roommate_gaps"

    def test_the_refusal_names_who_is_unpaired(self):
        # "Go fix these" beats "something is wrong".
        with pytest.raises(H.HTTPException) as exc:
            _generate(_db(self._lonely()))
        gaps = exc.value.detail["gaps"]
        assert [g["name"] for g in gaps] == ["Tina Fey"]
        assert gaps[0]["reason"] == "no_name"
        assert gaps[0]["label"]

    def test_force_generates_anyway(self):
        # The override exists; it is never the default.
        out = _generate(_db(self._lonely()), force=True)
        assert out["version"] == 1

    def test_a_confirmed_pair_is_not_a_gap(self):
        # Both point at each other. The free-text name is irrelevant — and is
        # routinely blank on the second person of a pair.
        out = _generate(_db(_pair()))
        assert out["version"] == 1

    def test_a_single_room_is_never_a_gap(self):
        out = _generate(_db([_p("s", "Ada", "L", room_type="single")]))
        assert out["version"] == 1

    def test_a_one_sided_link_is_a_gap(self):
        # Tina points at Leslie; Leslie points at nobody and asked for a twin.
        people = [
            _p("t", "Tina", "Fey", room_type="twin", roommate_participant_id="l"),
            _p("l", "Leslie", "Knope", room_type="twin"),
        ]
        with pytest.raises(H.HTTPException) as exc:
            _generate(_db(people))
        assert exc.value.detail["count"] >= 1

    def test_the_gaps_are_readable_before_pressing_generate(self):
        # The screen has to be able to warn first, not only after a refusal.
        out = _get(_db(self._lonely()))
        assert [g["name"] for g in out["roommate_gaps"]] == ["Tina Fey"]

    def test_an_event_with_no_gaps_reports_an_empty_list(self):
        assert _get(_db(_pair()))["roommate_gaps"] == []
