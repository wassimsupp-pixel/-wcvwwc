"""
Tests for turning an exception into a question (feedback §14).

The feature is mostly made of refusals, so most of these tests check that
something does NOT happen. The failure modes it exists to prevent are all
variations of one thing — emailing a real person about something they cannot
answer, already answered, or was never asked of them:

  * chasing a field the event turned off in Settings;
  * chasing somebody twice for what they sent last week;
  * asking a participant to help resolve an internal duplicate;
  * emailing a participant whose missing field is the email address.
"""

import pytest

from services import field_policy
from services import information_request as IR


def _p(pid="p1", **over):
    base = {
        "id": pid, "first_name": "Sophie", "last_name": "Marceau",
        "email": "sophie@example.com", "phone": "+32470000000",
        "nationality": "BE", "dietary_requirements": "Végétarien",
        "has_flight": True,
    }
    base.update(over)
    return base


def _exc(pid="p1", exc_type="MISSING_REQUIRED_FIELD", eid="e1", **context):
    return {
        "id": eid, "participant_id": pid, "exception_type": exc_type,
        "context_data": context or {},
    }


POLICY = field_policy.resolve(None)


# ===========================================================================
# "YES" is not an answer
# ===========================================================================

class TestAnAnswerThatSaysNothing:
    """The feedback's own example: Dietary requirements: YES."""

    @pytest.mark.parametrize("value", ["YES", "yes", "Oui", "ja", "x", "1", "TBC", "n/a", "-"])
    def test_a_tick_box_answer_is_treated_as_a_gap(self, value):
        assert IR.is_uninformative(value) is True

    @pytest.mark.parametrize("value", ["Végétarien", "No allergies", "Halal", "Non", "no", "Nee"])
    def test_a_real_answer_is_left_alone(self, value):
        # "No" is a real answer to a dietary question. Emailing a vegetarian to
        # ask what they meant by "no allergies" is worse than not asking.
        assert IR.is_uninformative(value) is False

    def test_an_empty_value_is_not_uninformative_it_is_absent(self):
        assert IR.is_uninformative("") is False
        assert IR.is_uninformative(None) is False

    def test_it_produces_a_request_with_the_right_reason(self):
        wanted = {"p1": {"fields": ["dietary_requirements"], "exception_ids": ["e1"]}}
        requests, _ = IR.plan_requests([_p(dietary_requirements="yes")], wanted, POLICY)
        assert requests[0]["fields"] == [
            {"key": "dietary_requirements", "reason": "uninformative"}
        ]


# ===========================================================================
# Reading the exceptions
# ===========================================================================

class TestWhatTheExceptionsAskFor:

    def test_missing_fields_come_through(self):
        got = IR.fields_from_exceptions([_exc(missing_fields=["phone", "nationality"])])
        assert got["p1"]["fields"] == ["phone", "nationality"]

    def test_a_field_nobody_can_answer_is_dropped(self):
        # first_name is in a critical exception, but a person cannot be emailed
        # to ask their own name when we have no name to address them by.
        got = IR.fields_from_exceptions([_exc(missing_fields=["first_name", "phone"])])
        assert got["p1"]["fields"] == ["phone"]

    def test_a_missing_flight_becomes_a_flight_question(self):
        got = IR.fields_from_exceptions([_exc(exc_type="PARTICIPANT_NO_FLIGHT")])
        assert got["p1"]["fields"] == ["flight"]

    def test_a_roommate_gap_becomes_a_roommate_question(self):
        got = IR.fields_from_exceptions([_exc(category="roommate")])
        assert got["p1"]["fields"] == ["roommate"]

    def test_an_internal_problem_asks_the_participant_nothing(self):
        for exc_type in ("POSSIBLE_DUPLICATE", "DATA_CONFLICT", "NAME_DIVERGENCE"):
            assert IR.fields_from_exceptions([_exc(exc_type=exc_type)]) == {}

    def test_an_aggregated_warning_is_not_a_question_for_anybody(self):
        systemic = {
            "id": "e9", "participant_id": None,
            "exception_type": "MISSING_REQUIRED_FIELD",
            "context_data": {"systemic_anomaly": True, "field": "nationality"},
        }
        assert IR.fields_from_exceptions([systemic]) == {}

    def test_one_person_with_three_exceptions_gets_one_request(self):
        got = IR.fields_from_exceptions([
            _exc(eid="e1", missing_fields=["phone"]),
            _exc(eid="e2", missing_fields=["nationality"]),
            _exc(eid="e3", exc_type="PARTICIPANT_NO_FLIGHT"),
        ])
        assert list(got) == ["p1"]
        assert got["p1"]["fields"] == ["phone", "nationality", "flight"]
        assert got["p1"]["exception_ids"] == ["e1", "e2", "e3"]

    def test_the_same_field_twice_is_asked_once(self):
        got = IR.fields_from_exceptions([
            _exc(eid="e1", missing_fields=["phone"]),
            _exc(eid="e2", missing_fields=["phone"]),
        ])
        assert got["p1"]["fields"] == ["phone"]


# ===========================================================================
# Who actually gets an email
# ===========================================================================

class TestWhoIsAsked:

    def _wanted(self, *fields, pid="p1"):
        return {pid: {"fields": list(fields), "exception_ids": ["e1"]}}

    def test_a_field_that_has_since_been_filled_is_not_chased(self):
        # The exception may be from last week's run. Nobody wants to be asked
        # twice for what they already sent.
        requests, skipped = IR.plan_requests([_p()], self._wanted("phone"), POLICY)
        assert requests == []
        assert skipped[0]["reason"] == "nothing_left_to_ask"

    def test_a_field_the_event_turned_off_is_not_chased(self):
        policy = dict(POLICY, passport_number="not_used")
        people = [_p(passport_number=None)]
        requests, skipped = IR.plan_requests(people, self._wanted("passport_number"), policy)
        assert requests == []
        assert skipped[0]["reason"] == "nothing_left_to_ask"

    def test_an_optional_field_may_still_be_asked_for(self):
        # Optional is not "not used": an organizer chasing accessibility needs
        # is doing their job, and the policy only forbids the untracked.
        people = [_p(pmr_needs=None)]
        requests, _ = IR.plan_requests(people, self._wanted("pmr_needs"), POLICY)
        assert [f["key"] for f in requests[0]["fields"]] == ["pmr_needs"]

    def test_somebody_with_no_email_cannot_be_emailed(self):
        people = [_p(email=None, phone=None)]
        requests, skipped = IR.plan_requests(people, self._wanted("phone"), POLICY)
        assert requests == []
        assert skipped[0]["reason"] == "no_email"
        assert skipped[0]["name"] == "Sophie Marceau"

    def test_an_unknown_participant_is_reported_not_ignored(self):
        requests, skipped = IR.plan_requests([], self._wanted("phone"), POLICY)
        assert requests == []
        assert skipped[0]["reason"] == "unknown_participant"

    def test_a_missing_flight_is_read_from_the_flag_not_a_column(self):
        people = [_p(has_flight=False)]
        requests, _ = IR.plan_requests(people, self._wanted("flight"), POLICY)
        assert [f["key"] for f in requests[0]["fields"]] == ["flight"]

    def test_somebody_who_has_a_flight_is_not_asked_for_one(self):
        requests, skipped = IR.plan_requests([_p()], self._wanted("flight"), POLICY)
        assert requests == []


# ===========================================================================
# The email itself
# ===========================================================================

class TestTheMessage:

    def _request(self, *fields, language="fr", name="Sophie Marceau"):
        return {
            "participant_id": "p1", "name": name, "email": "s@example.com",
            "language": language,
            "fields": [{"key": f, "reason": "missing"} for f in fields],
            "exception_ids": ["e1"],
        }

    def test_it_greets_the_person_by_their_first_name(self):
        _, body = IR.compose(self._request("phone"), "Sales Convention")
        assert body.startswith("Bonjour Sophie,")

    def test_the_event_name_is_in_the_subject(self):
        subject, _ = IR.compose(self._request("phone"), "Sales Convention")
        assert "Sales Convention" in subject

    def test_it_lists_exactly_what_is_missing_and_nothing_else(self):
        _, body = IR.compose(self._request("phone", "nationality"), "X")
        assert "Téléphone" in body
        assert "Nationalité" in body
        assert "passeport" not in body.lower()

    def test_a_dutch_participant_gets_a_dutch_email(self):
        subject, body = IR.compose(self._request("phone", language="nl"), "X")
        assert body.startswith("Beste Sophie,")
        assert "Telefoon" in body
        assert "we missen" in subject

    def test_an_english_participant_gets_an_english_email(self):
        subject, body = IR.compose(self._request("dietary_requirements", language="en"), "X")
        assert body.startswith("Hello Sophie,")
        assert "Dietary requirements" in body

    def test_an_unknown_language_falls_back_to_french(self):
        _, body = IR.compose(self._request("phone", language="de"), "X")
        assert body.startswith("Bonjour Sophie,")

    def test_a_vague_field_gets_a_hint(self):
        _, body = IR.compose(self._request("flight"), "X")
        assert "numéro de vol" in body

    def test_the_dietary_question_asks_which_one(self):
        _, body = IR.compose(self._request("dietary_requirements"), "X")
        assert "végétarien" in body.lower()

    def test_a_deadline_appears_only_when_given(self):
        _, without = IR.compose(self._request("phone"), "X")
        _, with_it = IR.compose(self._request("phone"), "X", deadline="12/03/2027")
        assert "12/03/2027" not in without
        assert "12/03/2027" in with_it

    def test_the_signature_is_the_sender_when_there_is_one(self):
        _, body = IR.compose(self._request("phone"), "X", sender="Marie, VO Event")
        assert body.rstrip().endswith("Marie, VO Event")

    def test_nobody_elses_name_is_in_the_message(self):
        _, body = IR.compose(self._request("roommate"), "X")
        assert "Leslie" not in body and "Tina" not in body


# ===========================================================================
# The preview an organizer reads before pressing anything
# ===========================================================================

class TestSummary:

    def test_it_counts_people_and_questions_separately(self):
        wanted = {
            "p1": {"fields": ["phone", "nationality"], "exception_ids": []},
            "p2": {"fields": ["phone"], "exception_ids": []},
        }
        people = [
            _p("p1", phone=None, nationality=None),
            _p("p2", phone=None, language="nl"),
        ]
        requests, skipped = IR.plan_requests(people, wanted, POLICY)
        summary = IR.summarise(requests, skipped)
        assert summary["recipients"] == 2
        assert summary["questions"] == 3
        assert summary["by_field"] == {"nationality": 1, "phone": 2}

    def test_it_breaks_the_recipients_down_by_language(self):
        wanted = {
            "p1": {"fields": ["phone"], "exception_ids": []},
            "p2": {"fields": ["phone"], "exception_ids": []},
        }
        people = [_p("p1", phone=None), _p("p2", phone=None, language="nl")]
        requests, skipped = IR.plan_requests(people, wanted, POLICY)
        assert IR.summarise(requests, skipped)["by_language"] == {"fr": 1, "nl": 1}

    def test_the_reasons_for_skipping_are_counted(self):
        wanted = {
            "p1": {"fields": ["phone"], "exception_ids": []},
            "p2": {"fields": ["phone"], "exception_ids": []},
        }
        people = [_p("p1"), _p("p2", email=None, phone=None)]
        requests, skipped = IR.plan_requests(people, wanted, POLICY)
        summary = IR.summarise(requests, skipped)
        assert summary["skipped"] == 2
        assert summary["skipped_reasons"] == {"no_email": 1, "nothing_left_to_ask": 1}
