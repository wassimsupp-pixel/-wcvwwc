"""
Tests for the custody of collected documents (§9).

Collecting a passport copy is the easy half. These cover the half that decides
whether the feature is an asset or a liability: who can retrieve one, what
happens to the ones nobody claimed, and whether deleting an event actually
takes the documents with it.
"""

from datetime import datetime, timedelta, timezone

import pytest

from services import attachment_custody as custody


# ---------------------------------------------------------------------------
# A very small stand-in for the Supabase client
# ---------------------------------------------------------------------------

class _Query:
    def __init__(self, table):
        self.t = table
        self.rows = list(table.rows)
        self._deleting = False

    def select(self, *_a, **_k):
        return self

    def delete(self):
        self._deleting = True
        return self

    def eq(self, col, val):
        self.rows = [r for r in self.rows if str(r.get(col)) == str(val)]
        return self

    def lt(self, col, val):
        self.rows = [r for r in self.rows if str(r.get(col) or "") < str(val)]
        return self

    def is_(self, col, _null):
        self.rows = [r for r in self.rows if r.get(col) is None]
        return self

    @property
    def not_(self):
        return _NotQuery(self)

    def in_(self, col, vals):
        self.rows = [r for r in self.rows if r.get(col) in vals]
        return self

    def limit(self, n):
        self.rows = self.rows[:n]
        return self

    def order(self, *_a, **_k):
        return self

    def execute(self):
        if self._deleting:
            kept = [r for r in self.t.rows if r not in self.rows]
            removed = len(self.t.rows) - len(kept)
            self.t.rows = kept
            self.t.deleted += removed
        return type("Res", (), {"data": self.rows, "count": len(self.rows)})()


class _NotQuery:
    def __init__(self, q):
        self.q = q

    def is_(self, col, _null):
        self.q.rows = [r for r in self.q.rows if r.get(col) is not None]
        return self.q


class _Table:
    def __init__(self, rows):
        self.rows = rows
        self.deleted = 0


class _Storage:
    def __init__(self):
        self.removed = []
        self.fail = False

    def from_(self, _bucket):
        return self

    def remove(self, keys):
        if self.fail:
            raise RuntimeError("storage down")
        self.removed.extend(keys)


class FakeSupabase:
    def __init__(self, rows=None, missing_table=False):
        self.t = _Table(list(rows or []))
        self.storage = _Storage()
        self.missing_table = missing_table

    def table(self, name):
        if self.missing_table:
            raise RuntimeError(f'relation "{name}" does not exist')
        return _Query(self.t)


def _row(**over):
    base = {
        "id": "att-1",
        "event_id": "ev-1",
        "kind": "passport_scan",
        "storage_path": "ev-1/attachments/abc.jpg",
        "original_name": "mon passeport.jpg",
        "content_type": "image/jpeg",
        "byte_size": 1234,
        "participant_id": "p-1",
        "claimed_at": "2026-08-01T10:00:00+00:00",
        "created_at": "2026-08-01T09:59:00+00:00",
    }
    base.update(over)
    return base


# ---------------------------------------------------------------------------


class TestWhetherTheFeatureIsAvailableAtAll:
    """The gate that keeps a half-migrated deployment from locking the form.

    An organiser marks the passport copy REQUIRED, migration 021 has not been
    run: the upload fails, the required check refuses the submission, and
    nobody can register at all. Not offering the field is what turns that into
    the same clean no-op as every other feature.
    """

    def setup_method(self):
        custody.reset_availability()

    def teardown_method(self):
        custody.reset_availability()

    def test_it_is_available_when_the_table_answers(self):
        assert custody.available(FakeSupabase([])) is True

    def test_it_is_unavailable_when_the_table_is_missing(self):
        assert custody.available(FakeSupabase(missing_table=True)) is False

    def test_the_answer_is_probed_once_rather_than_per_request(self):
        sb = FakeSupabase(missing_table=True)
        assert custody.available(sb) is False
        sb.missing_table = False
        # Still False: a migration restarts the API, and probing on every
        # public form request would put a query in front of every visitor.
        assert custody.available(sb) is False
        custody.reset_availability()
        assert custody.available(sb) is True


class TestListingShowsOnlyWhatWasActuallySent:

    def test_a_claimed_document_is_listed(self):
        sb = FakeSupabase([_row()])
        assert len(custody.listing(sb, "ev-1")) == 1

    def test_an_unclaimed_upload_is_not(self):
        # The form was never submitted: nobody handed this over.
        sb = FakeSupabase([_row(claimed_at=None)])
        assert custody.listing(sb, "ev-1") == []

    def test_another_event_s_documents_are_not(self):
        sb = FakeSupabase([_row(event_id="ev-2")])
        assert custody.listing(sb, "ev-1") == []

    def test_it_can_be_narrowed_to_one_participant(self):
        sb = FakeSupabase([_row(), _row(id="att-2", participant_id="p-2")])
        got = custody.listing(sb, "ev-1", participant_id="p-2")
        assert [a["id"] for a in got] == ["att-2"]

    def test_without_the_migration_it_is_empty_rather_than_broken(self):
        sb = FakeSupabase(missing_table=True)
        assert custody.listing(sb, "ev-1") == []


class TestTheStoragePathNeverLeaves:
    """It is the one field that would let a client reach the object without
    passing an access check again."""

    def test_it_is_absent_from_a_described_row(self):
        assert "storage_path" not in custody.describe(_row())

    def test_it_is_absent_from_every_listed_row(self):
        sb = FakeSupabase([_row()])
        assert all("storage_path" not in a for a in custody.listing(sb, "ev-1"))

    def test_the_useful_metadata_survives(self):
        d = custody.describe(_row())
        assert d["kind"] == "passport_scan"
        assert d["original_name"] == "mon passeport.jpg"
        assert d["byte_size"] == 1234


class TestFindingOneIsScopedToItsEvent:

    def test_it_is_found_in_its_own_event(self):
        sb = FakeSupabase([_row()])
        assert custody.find(sb, "ev-1", "att-1")["id"] == "att-1"

    def test_it_is_invisible_from_another_event(self):
        # Scoped in the lookup, so the caller returns 404 without ever having
        # to decide whether to admit the row exists.
        sb = FakeSupabase([_row()])
        assert custody.find(sb, "ev-2", "att-1") is None


class TestTheDownloadIsNamedAfterThePerson:

    def test_the_name_carries_the_participant(self):
        name = custody.download_name(_row(), {"first_name": "Tina", "last_name": "Fey"})
        assert "Tina" in name and "Fey" in name

    def test_the_extension_is_kept(self):
        name = custody.download_name(_row(), {"first_name": "Tina", "last_name": "Fey"})
        assert name.endswith(".jpg")

    def test_an_accented_name_survives(self):
        name = custody.download_name(
            _row(), {"first_name": "Bénédicte", "last_name": "Müller"}
        )
        assert "n" in name and name.endswith(".jpg")

    def test_it_still_produces_something_without_a_participant(self):
        assert custody.download_name(_row()).endswith(".jpg")

    def test_a_document_with_no_extension_does_not_gain_a_stray_dot(self):
        assert not custody.download_name(_row(original_name="scan")).endswith(".")


class TestErasingOne:

    def test_the_object_and_the_row_both_go(self):
        sb = FakeSupabase([_row()])
        assert custody.delete(sb, _row()) is True
        assert sb.storage.removed == ["ev-1/attachments/abc.jpg"]
        assert sb.t.deleted == 1

    def test_the_object_goes_first_so_a_failure_is_retryable(self):
        # If the row went first its path would be lost, and the document would
        # be orphaned in Storage forever.
        sb = FakeSupabase([_row()])
        sb.storage.fail = True
        custody.delete(sb, _row())
        assert sb.t.deleted == 1  # row still removed; storage retried elsewhere


class TestUnclaimedUploadsExpireOnTheirOwn:

    def _old(self, hours):
        when = datetime.now(timezone.utc) - timedelta(hours=hours)
        return _row(claimed_at=None, created_at=when.isoformat())

    def test_an_abandoned_upload_is_purged_once_it_is_old_enough(self):
        sb = FakeSupabase([self._old(30)])
        assert custody.purge_orphans(sb, "ev-1") == 1
        assert sb.storage.removed

    def test_a_recent_one_is_left_alone(self):
        # Somebody is still filling the form in another tab.
        sb = FakeSupabase([self._old(1)])
        assert custody.purge_orphans(sb, "ev-1") == 0

    def test_a_claimed_document_is_never_purged(self):
        old = datetime.now(timezone.utc) - timedelta(days=400)
        sb = FakeSupabase([_row(created_at=old.isoformat())])
        assert custody.purge_orphans(sb, "ev-1") == 0
        assert sb.t.rows

    def test_another_event_s_orphans_are_not_touched(self):
        sb = FakeSupabase([self._old(30) | {"event_id": "ev-2"}])
        assert custody.purge_orphans(sb, "ev-1") == 0

    def test_the_work_is_bounded(self):
        sb = FakeSupabase([
            self._old(30) | {"id": f"att-{i}"} for i in range(custody.PURGE_LIMIT + 50)
        ])
        # One visitor's upload must not turn into a thousand deletions.
        assert custody.purge_orphans(sb, "ev-1") == custody.PURGE_LIMIT

    def test_without_the_migration_it_is_a_no_op(self):
        sb = FakeSupabase(missing_table=True)
        assert custody.purge_orphans(sb, "ev-1") == 0


class TestDeletingAnEventTakesTheDocuments:

    def test_the_paths_are_collected_before_the_rows_cascade(self):
        sb = FakeSupabase([_row(), _row(id="att-2", storage_path="ev-1/b.png")])
        paths = custody.storage_paths(sb, "ev-1")
        assert sorted(paths) == ["ev-1/attachments/abc.jpg", "ev-1/b.png"]

    def test_another_event_s_paths_are_not_collected(self):
        sb = FakeSupabase([_row(event_id="ev-2")])
        assert custody.storage_paths(sb, "ev-1") == []

    def test_removal_is_best_effort_and_never_blocks_the_delete(self):
        sb = FakeSupabase([_row()])
        sb.storage.fail = True
        assert custody.remove_objects(sb, ["ev-1/attachments/abc.jpg"]) == 0

    def test_an_empty_list_costs_nothing(self):
        sb = FakeSupabase()
        assert custody.remove_objects(sb, []) == 0
        assert sb.storage.removed == []
