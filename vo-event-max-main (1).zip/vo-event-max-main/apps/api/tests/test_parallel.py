"""
Tests for the helper the master list and the dashboard now depend on.

It exists to remove latency, so one test measures that it actually does. The
rest pin the property that made it safe to put underneath two pages that must
never break: **a failed job is a missing answer, not an exception.** Every
caller degraded gracefully before — a deployment without migration 028 renders
the master list without note colours — and a helper that let a thread's
exception escape would turn each of those into a blank page.
"""

import time

import pytest

from services import parallel


class TestItReturnsWhatWasAsked:
    def test_each_job_comes_back_under_its_own_name(self):
        got = parallel.gather({"a": lambda: 1, "b": lambda: 2})
        assert got == {"a": 1, "b": 2}

    def test_no_jobs_is_no_results(self):
        assert parallel.gather({}) == {}

    def test_the_order_threads_finish_in_never_reaches_the_caller(self):
        """Keyed by name, so a slow job does not reshuffle the page."""
        jobs = {
            "slow": lambda: (time.sleep(0.05), "slow")[1],
            "fast": lambda: "fast",
        }
        got = parallel.gather(jobs)
        assert list(got) == ["slow", "fast"]


class TestAFailureCostsOnlyItsOwnAnswer:
    def _boom(self):
        raise RuntimeError("relation \"participant_notes\" does not exist")

    def test_a_raising_job_yields_none_rather_than_propagating(self):
        got = parallel.gather({"notes": self._boom})
        assert got == {"notes": None}

    def test_its_neighbours_still_return(self):
        """The whole point. Flights, transfers, hotels, nights and activities
        used to share one try/except, so a transfers table that was not there
        yet took the four reads after it down with it."""
        got = parallel.gather({
            "flights": lambda: ["a"],
            "transfers": self._boom,
            "hotels": lambda: ["b"],
        })
        assert got["flights"] == ["a"]
        assert got["transfers"] is None
        assert got["hotels"] == ["b"]

    def test_the_default_is_the_callers_to_choose(self):
        """`[]` where the caller will iterate, `None` where it will test."""
        got = parallel.gather({"notes": self._boom}, default=[])
        assert got == {"notes": []}

    def test_every_job_can_fail_without_raising(self):
        got = parallel.gather({"a": self._boom, "b": self._boom})
        assert got == {"a": None, "b": None}


class TestTheRequiredOnesAreEasyToCheck:
    def test_it_names_the_first_missing_answer(self):
        results = {"participants": ["p"], "source_rows": None}
        assert parallel.first_error(results, "participants", "source_rows") == "source_rows"

    def test_none_missing_reads_as_none(self):
        results = {"participants": ["p"], "source_rows": []}
        assert parallel.first_error(results, "participants", "source_rows") is None

    def test_an_empty_list_is_an_answer_not_a_failure(self):
        """An event with no source records has none; that is not an outage."""
        assert parallel.first_error({"source_rows": []}, "source_rows") is None


class TestItIsActuallyConcurrent:
    def test_five_slow_jobs_cost_about_one(self):
        """The whole reason this module exists.

        Five reads of 100 ms each cost 500 ms in a queue and roughly 100 ms
        together. The bound is loose — this is a thread pool on a shared
        machine, not a stopwatch — but 500 ms of stacking cannot hide under it.
        """
        jobs = {str(i): (lambda: time.sleep(0.1)) for i in range(5)}
        started = time.monotonic()
        parallel.gather(jobs)
        elapsed = time.monotonic() - started
        assert elapsed < 0.3, f"{elapsed:.2f}s — the reads are still queueing"

    def test_more_jobs_than_workers_still_all_run(self):
        """The pool is capped, so a page with more reads than workers must
        still get every answer — just in two waves rather than one."""
        count = parallel.MAX_WORKERS + 3
        got = parallel.gather({str(i): (lambda i=i: i) for i in range(count)})
        assert len(got) == count
        assert got["0"] == 0
