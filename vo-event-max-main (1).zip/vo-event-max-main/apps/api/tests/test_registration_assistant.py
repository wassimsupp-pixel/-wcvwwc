"""
Tests for the assistant that proposes a form from a description.

A model writes the answer, so the tests are not about whether the answer is
good — they are about the fact that a bad one cannot do damage. Every field key
is intersected with the real catalogue, identity is forced on afterwards, the
theme goes through the same sanitizer the save endpoint uses, and nothing is
written anywhere. What is left for a hallucination or a prompt injection to
achieve is "propose the wrong questions to somebody who is reading them".

The other half is that this never simply fails: no provider, an unreachable
one, or an unusable answer all fall back to keywords, because an organizer can
edit a rough proposal and can do nothing at all with a spinner.
"""

import pytest

from services import registration_assistant as A
from services import registration_form, registration_theme


@pytest.fixture
def no_ai(monkeypatch):
    """No provider configured — the keyword path."""
    monkeypatch.setattr(A.ai_service, "ai_available", lambda: False)


def with_answer(monkeypatch, answer):
    """Pin the model's answer so the shaping can be tested on its own."""
    monkeypatch.setattr(A.ai_service, "ai_available", lambda: True)
    monkeypatch.setattr(A.ai_service, "ai_json", lambda *a, **k: answer)


class TestTheProposalIsAlwaysApplicable:

    def test_it_covers_every_catalogue_field_and_no_others(self, no_ai):
        proposal = A.propose("Séminaire de deux jours à Lisbonne, hôtel et vols compris.")
        assert set(proposal["fields"]) == set(registration_form.FIELD_KEYS)
        assert set(proposal["order"]) == set(registration_form.FIELD_KEYS)
        assert len(proposal["order"]) == len(registration_form.FIELD_KEYS)

    def test_the_theme_is_one_the_save_endpoint_would_accept(self, no_ai):
        theme = A.propose("Convention")["theme"]
        assert registration_theme.sanitize(theme) == theme

    def test_every_field_carries_the_shape_the_editor_expects(self, no_ai):
        for state in A.propose("Gala")["fields"].values():
            assert set(state) == {"enabled", "required", "badges"}
            assert isinstance(state["enabled"], bool)
            assert isinstance(state["required"], bool)


class TestNothingTheModelSaysEscapesTheCatalogue:

    def test_an_invented_key_is_dropped(self, monkeypatch):
        with_answer(monkeypatch, {
            "enabled": ["email", "social_security_number", "credit_card", "phone"],
            "required": ["credit_card"],
        })
        proposal = A.propose("un événement")
        assert "social_security_number" not in proposal["fields"]
        assert "credit_card" not in proposal["fields"]
        assert proposal["fields"]["phone"]["enabled"]

    def test_a_required_field_it_never_enabled_is_not_required(self, monkeypatch):
        # Required-but-hidden is the one pair that makes a form unsubmittable.
        with_answer(monkeypatch, {"enabled": ["phone"], "required": ["passport_number"]})
        proposal = A.propose("un événement")
        assert not proposal["fields"]["passport_number"]["required"]
        assert not proposal["fields"]["passport_number"]["enabled"]

    def test_identity_stays_on_however_the_model_answers(self, monkeypatch):
        with_answer(monkeypatch, {"enabled": ["phone"], "required": []})
        fields = A.propose("un événement")["fields"]
        for key in registration_form.LOCKED_KEYS:
            assert fields[key]["enabled"], key
            assert fields[key]["required"], key

    def test_an_invented_theme_value_falls_back(self, monkeypatch):
        with_answer(monkeypatch, {
            "enabled": ["phone"],
            "theme": {"font": "comic-sans", "accent": "red; background:url(x)",
                      "surface": "neon", "header": {"style": "video"}},
        })
        theme = A.propose("un événement")["theme"]
        assert theme["font"] in registration_theme.FONTS
        assert theme["accent"] == registration_theme.DEFAULT_ACCENT
        assert theme["surface"] in registration_theme.SURFACES
        assert theme["header"]["style"] in registration_theme.HEADER_STYLES

    def test_markup_in_the_summary_and_the_questions_is_stripped(self, monkeypatch):
        with_answer(monkeypatch, {
            "enabled": ["phone"],
            "summary": "<script>alert(1)</script>Formulaire léger",
            "custom_fields": [{"label": "<img onerror=alert(1)>Taille de vélo", "type": "text"}],
        })
        proposal = A.propose("un événement")
        assert "<" not in proposal["summary"]
        assert "Formulaire léger" in proposal["summary"]
        assert "<" not in proposal["custom_fields"][0]["label"]

    def test_the_extra_questions_are_capped(self, monkeypatch):
        with_answer(monkeypatch, {
            "enabled": ["phone"],
            "custom_fields": [{"label": f"Question {i}"} for i in range(50)],
        })
        assert len(A.propose("un événement")["custom_fields"]) == 5

    def test_a_duplicated_key_appears_once_in_the_order(self, monkeypatch):
        with_answer(monkeypatch, {"enabled": ["phone"], "order": ["phone", "phone", "email"]})
        order = A.propose("un événement")["order"]
        assert order.count("phone") == 1
        assert sorted(order) == sorted(registration_form.FIELD_KEYS)

    def test_a_custom_field_type_it_invented_becomes_text(self, monkeypatch):
        with_answer(monkeypatch, {
            "enabled": ["phone"],
            "custom_fields": [{"label": "Taille", "type": "<script>"}],
        })
        assert A.propose("un événement")["custom_fields"][0]["type"] == "text"


class TestItNeverJustFails:

    @pytest.mark.parametrize("answer", [None, {}, [], "texte libre", {"enabled": []},
                                        {"enabled": ["not_a_field"]}])
    def test_an_unusable_answer_falls_back_to_keywords(self, monkeypatch, answer):
        with_answer(monkeypatch, answer)
        proposal = A.propose("Convention avec vols et hôtel")
        assert proposal["source"] == "keywords"
        assert proposal["fields"]["room_type"]["enabled"]

    def test_a_provider_that_raises_falls_back(self, monkeypatch):
        monkeypatch.setattr(A.ai_service, "ai_available", lambda: True)

        def boom(*_a, **_k):
            raise RuntimeError("502 from the provider")

        monkeypatch.setattr(A.ai_service, "ai_json", boom)
        proposal = A.propose("Convention avec vols et hôtel")
        assert proposal["source"] == "keywords"
        assert proposal["asked_count"] > 3

    def test_a_usable_answer_is_labelled_as_the_model_s(self, monkeypatch):
        with_answer(monkeypatch, {"enabled": ["phone", "company"], "required": ["phone"]})
        assert A.propose("un événement")["source"] == "ai"

    @pytest.mark.parametrize("brief", ["", None, "   ", "<p></p>"])
    def test_an_empty_brief_still_returns_a_usable_form(self, brief, no_ai):
        proposal = A.propose(brief)
        assert proposal["fields"]["email"]["enabled"]
        assert proposal["asked_count"] >= 3

    def test_a_very_long_brief_is_bounded(self, no_ai):
        proposal = A.propose("hôtel " * 5000)
        assert len(proposal["description"]) <= A.MAX_DESCRIPTION


class TestTheKeywordsReadTheBriefTheyAreGiven:

    def test_travel_words_turn_on_the_travel_block(self, no_ai):
        fields = A.propose("Vols au départ de Bruxelles, transferts aéroport inclus.")["fields"]
        assert fields["arrival_flight"]["enabled"]
        assert fields["transfer_needed"]["enabled"]

    def test_a_local_evening_asks_almost_nothing(self, no_ai):
        light = A.propose("Cocktail d'une soirée au bureau, 30 personnes.")
        heavy = A.propose("Convention de 3 jours à Lisbonne, vols, hôtel, dîner de gala.")
        assert light["asked_count"] < heavy["asked_count"]
        assert not light["fields"]["passport_number"]["enabled"]

    @pytest.mark.parametrize("brief", [
        "Journée d'étude à Bruxelles, sans hébergement.",
        "Séminaire d'une journée, pas d'hôtel.",
        "Day meeting in Brussels, no hotel.",
        "Studiedag in Brussel, zonder hotel.",
    ])
    def test_a_brief_that_rules_the_hotel_out_asks_no_rooming_questions(self, brief, no_ai):
        fields = A.propose(brief)["fields"]
        assert not fields["roommate"]["enabled"]
        assert not fields["room_type"]["enabled"]

    def test_one_negated_mention_does_not_settle_the_question(self, no_ai):
        # The brief rules it out once and back in immediately after, which is
        # how people actually write these.
        fields = A.propose("Pas de vol le premier jour ; vols pris en charge ensuite.")["fields"]
        assert fields["arrival_flight"]["enabled"]

    def test_accents_and_case_do_not_decide(self, no_ai):
        with_accent = A.propose("Hébergement à l'hôtel")["asked_count"]
        without = A.propose("hebergement a l hotel")["asked_count"]
        assert with_accent == without
