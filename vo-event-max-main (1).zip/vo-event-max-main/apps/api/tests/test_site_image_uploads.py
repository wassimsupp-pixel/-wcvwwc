"""
Tests for uploading a mini-site image instead of pasting a link (point 9).

Every section already took an image, but only as a pasted https:// URL —
meaning an organizer had to host the picture somewhere else first. This
validates a direct upload; storage and the public-bucket call are exercised
at the router level, not here (this module has no database, no storage).
"""

import pytest

from services import site_image_uploads as S

_PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 40
_JPEG = b"\xff\xd8\xff" + b"\x00" * 40
_PDF = b"%PDF-1.4\n" + b"\x00" * 40


class TestValidatingTheBytes:

    def test_a_png_is_accepted(self):
        got = S.validate("banner.png", _PNG)
        assert got["ext"] == "png"
        assert got["content_type"] == "image/png"

    def test_a_jpeg_is_accepted(self):
        got = S.validate("banner.jpg", _JPEG)
        assert got["ext"] == "jpg"
        assert got["content_type"] == "image/jpeg"

    def test_an_empty_file_is_refused(self):
        with pytest.raises(S.SiteImageRefused):
            S.validate("banner.png", b"")

    def test_a_pdf_renamed_to_png_is_refused(self):
        # The extension is the uploader's own claim about their own file.
        with pytest.raises(S.SiteImageRefused):
            S.validate("banner.png", _PDF)

    def test_random_bytes_are_refused(self):
        with pytest.raises(S.SiteImageRefused):
            S.validate("banner.png", b"not an image, just text pretending")

    def test_a_file_over_the_limit_is_refused(self):
        oversized = _PNG + b"\x00" * S.MAX_BYTES
        with pytest.raises(S.SiteImageRefused):
            S.validate("banner.png", oversized)

    def test_the_refusal_message_is_shown_as_is(self):
        # Same contract as registration_uploads: one message, written once.
        with pytest.raises(S.SiteImageRefused) as exc_info:
            S.validate("banner.png", b"")
        assert str(exc_info.value)


class TestTheStoragePathIsServerGenerated:

    def test_the_uploaders_filename_never_appears_in_the_path(self):
        path = S.storage_path("ev-1", "png")
        assert "banner" not in path

    def test_the_path_is_scoped_to_the_event(self):
        assert S.storage_path("ev-1", "png").startswith("ev-1/")

    def test_two_uploads_never_collide(self):
        a = S.storage_path("ev-1", "png")
        b = S.storage_path("ev-1", "png")
        assert a != b
