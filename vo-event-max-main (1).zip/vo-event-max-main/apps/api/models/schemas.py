"""
models/schemas.py — Pydantic v2 request/response models for VO Event Max API.

Organized by domain:
  - Events
  - Files / Column Mapping
  - Participants
  - Consolidation Runs
  - Exceptions
  - Exports
  - Change Log

i18n-ready error message constants are defined at the bottom of this file.
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any, Literal, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator


# ---------------------------------------------------------------------------
# Shared base
# ---------------------------------------------------------------------------

class ORMBase(BaseModel):
    """Base model with ORM mode enabled for use with Supabase dict responses."""
    model_config = ConfigDict(from_attributes=True)


# ---------------------------------------------------------------------------
# Organizations
# ---------------------------------------------------------------------------

class OrganizationResponse(ORMBase):
    id: UUID
    name: str
    slug: str
    created_at: datetime


# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------

class ProjectCreate(BaseModel):
    """Request body for creating a new project."""
    name: str = Field(..., min_length=1, max_length=255)
    client_name: str = Field(..., min_length=1, max_length=255)


class ProjectResponse(ORMBase):
    id: UUID
    org_id: UUID
    name: str
    client_name: str
    created_by: UUID
    created_at: datetime


# ---------------------------------------------------------------------------
# Events
# ---------------------------------------------------------------------------

class EventCreate(BaseModel):
    """Request body for creating a new event."""
    project_id: UUID
    name: str = Field(..., min_length=1, max_length=255)
    event_type: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    location_city: Optional[str] = None
    location_country: Optional[str] = None

    @field_validator("end_date")
    @classmethod
    def end_date_after_start(cls, v: Optional[date], info) -> Optional[date]:
        start = info.data.get("start_date")
        if v is not None and start is not None and v < start:
            raise ValueError("end_date must be on or after start_date.")
        return v


class EventUpdate(BaseModel):
    """Request body for partial event update (all fields optional)."""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    event_type: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    location_city: Optional[str] = None
    location_country: Optional[str] = None
    # Printed at the bottom of the participant confirmation PDF (§16). Free
    # text, one line per line — whose number goes on the document changes per
    # event, and three rigid columns would just get worked around.
    organiser_contact: Optional[str] = Field(None, max_length=500)
    # This event's own logo on the public registration form (point 11),
    # instead of the default MAX mark. Set via POST /events/{id}/logo, which
    # returns the URL to PATCH here — never a raw upload through this field.
    logo_url: Optional[str] = Field(None, max_length=500)


class EventResponse(ORMBase):
    id: UUID
    project_id: UUID
    name: str
    event_type: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    location_city: Optional[str] = None
    location_country: Optional[str] = None
    logo_url: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class ChatTurn(BaseModel):
    """One earlier exchange, sent back so follow-ups resolve ("et parmi eux…").
    Used only as context for choosing what to look up — never as a source of
    facts, which always come from a fresh query."""
    question: str = Field(..., max_length=500)


class ChatQuestion(BaseModel):
    """A free-form question about the event in the path."""
    question: str = Field(..., min_length=1, max_length=500)
    # The browser's own copy of the thread. Still accepted so a deployment
    # without migration 019 keeps working exactly as before — but IGNORED as
    # soon as conversation_id names a stored thread, because a client that can
    # supply the history can supply a fabricated one.
    history: list[ChatTurn] = Field(default_factory=list, max_length=20)
    # Continue an existing thread. Omit to start one.
    conversation_id: Optional[UUID] = None


class ChatAnswer(BaseModel):
    """An answer built from real event data.

    ``answered=False`` means the assistant declined (question outside its data,
    or a read failure) — the client shows `answer` as-is rather than retrying,
    because guessing is exactly what this feature must never do.
    """
    answer: str
    rows: list[dict[str, Any]] = []
    references: list[str] = []
    intent: Optional[str] = None
    answered: bool
    generated_on: Optional[str] = None
    # The thread this answer belongs to. None when migration 019 is absent —
    # the client then keeps carrying the history itself, as it always did.
    conversation_id: Optional[UUID] = None


class ChatSuggestions(BaseModel):
    questions: list[str]
    capabilities: list[str]


class ChatConversationSummary(BaseModel):
    """One row of the conversation list."""
    id: UUID
    title: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    questions: int = 0
    # A thread full of refusals is the useful signal here: somebody kept
    # asking something the data cannot answer.
    unanswered: int = 0


class ChatMessage(BaseModel):
    role: str
    content: str
    intent: Optional[str] = None
    answered: Optional[bool] = None
    # How many rows the answer carried. The rows themselves are not stored —
    # they are participant data, and a transcript is not a place to keep it.
    row_count: int = 0
    created_at: Optional[datetime] = None


class ChatTranscript(BaseModel):
    conversation: ChatConversationSummary
    messages: list[ChatMessage] = []


class RegistrationOpenUpdate(BaseModel):
    """Request body to open/close an event's public registration form."""
    is_open: bool


# ---------------------------------------------------------------------------
# Public registration form (unauthenticated)
# ---------------------------------------------------------------------------

class RegistrationFieldState(BaseModel):
    """One question of the public form, as resolved for a given event."""
    key: str
    label: str
    group: str
    locked: bool
    enabled: bool
    required: bool


class RegistrationFieldToggle(BaseModel):
    enabled: bool = True
    required: bool = False
    # Point 13 (v1): which badges may see this field. Empty means every
    # badge — the safe default, so turning badges on for an event never
    # silently hides a question nobody re-configured.
    badges: list[str] = Field(default_factory=list, max_length=20)


class RegistrationFieldsUpdate(BaseModel):
    """The organizer's choice of which questions the form asks, in what
    order. Keys outside the catalogue are dropped server-side
    (services/registration_form)."""
    fields: dict[str, RegistrationFieldToggle]
    # Point 13 (v1): the field order the organizer arranged by hand. Omitted
    # or empty keeps the catalogue's own order.
    order: list[str] = Field(default_factory=list, max_length=200)


class RegistrationSuggestRequest(BaseModel):
    """A plain-language brief about the event, from which the assistant
    proposes a whole form configuration.

    Capped well below what a model would accept: the useful input is two or
    three sentences about what the event IS, and a 20-page programme pasted in
    makes the answer worse rather than better.
    """
    description: str = Field(default="", max_length=2000)


class RegistrationThemeHeader(BaseModel):
    """What a visitor sees before the first question."""
    style: str = Field(default="title", max_length=32)
    image_url: str = Field(default="", max_length=500)
    title: str = Field(default="", max_length=120)
    subtitle: str = Field(default="", max_length=240)
    align: str = Field(default="center", max_length=16)
    height: str = Field(default="compact", max_length=16)


class RegistrationThemeUpdate(BaseModel):
    """How the public form looks.

    Every value here is re-derived server-side from the closed sets in
    services/registration_theme \u2014 this model bounds the payload's SIZE and
    nothing else. It deliberately does not use enums: an organizer saving a
    theme written by an older build of the editor should get the default for
    the key it does not know, not a 422 that throws away the rest of their
    work.
    """
    font: str = Field(default="sans", max_length=32)
    accent: str = Field(default="#2563eb", max_length=32)
    surface: str = Field(default="light", max_length=32)
    corners: str = Field(default="soft", max_length=32)
    # The photo behind the whole page. Without this field Pydantic drops it from
    # the payload, and every save silently wiped the image the organizer had
    # just uploaded — the model has to name every key the service stores.
    background_image: str = Field(default="", max_length=500)
    header: RegistrationThemeHeader = Field(default_factory=RegistrationThemeHeader)


class RegistrationLayoutUpdate(BaseModel):
    """How the public form is laid out — a map of page -> blocks (migration 032).

    A layout is now multi-page: "home" is the registration page, every other key
    is a mini-site section slug, each with its own ordered blocks. Like the theme
    model this bounds only the payload's SHAPE — every block, value and page key
    is re-derived server-side from the closed sets in services/registration_layout,
    which is where the real validation lives. Loosely typed on purpose: a newer
    editor may send a block key this build does not know, and that key should be
    dropped on the way to storage, not 422 the whole save.
    """
    pages: dict[str, list[dict[str, Any]]] = Field(default_factory=dict)


class RegistrationBadge(BaseModel):
    """One named audience the form can be shown differently to (point 13,
    v1) — selected by ?badge= on the link, never by the registrant."""
    id: str = Field(default="", max_length=40)
    name: str = Field(..., max_length=40)


class RegistrationBadgesUpdate(BaseModel):
    """The full set to save — same replace-the-whole-list contract as
    rooming presets and transfer settings elsewhere in this codebase."""
    badges: list[RegistrationBadge] = Field(default_factory=list, max_length=20)


class ParticipantNoteCreate(BaseModel):
    """An operational remark about a participant (feedback §8).

    ``include_in_export`` defaults to False, and that default is the feature:
    the failure mode is not a remark nobody shared, it is a coach company
    reading "difficult client" about somebody in their van. It is also only
    honoured for a category that has a supplier destination — see
    services/note_service.
    """
    body: str
    category: str = "general"
    include_in_export: bool = False
    # Which events.note_presets entry this came from, if any (migration 028).
    # Only drives the master-list row colour; the note itself is a normal note.
    preset_id: Optional[str] = Field(default=None, max_length=40)


class NotePreset(BaseModel):
    """A named, reusable internal note with its own colour."""
    id: str = Field(default="", max_length=40)
    name: str = Field(..., max_length=60)
    body: str = Field(default="", max_length=2000)
    color: str = Field(default="", max_length=7)
    category: str = "general"


class NotePresetsUpdate(BaseModel):
    """The full set to save — same replace-the-whole-list contract as rooming
    presets and registration badges."""
    presets: list[NotePreset] = Field(default_factory=list, max_length=30)


class SupplierExportRequest(BaseModel):
    """Which supplier the file is for, and — for a custom export — which
    columns. The selection is filtered server-side against an allow-list; a
    sensitive key sent here is dropped, never honoured."""
    profile: str
    columns: list[str] = Field(default_factory=list)


class TransferVehicle(BaseModel):
    """One vehicle type in an event's fleet, as MAX describes it on their own
    transfer sheets: a name and how many people fit in it."""
    name: str = ""
    capacity: int = 0


class TransferSettingsUpdate(BaseModel):
    """Per-event dispatching parameters (feedback §1).

    Every value is re-validated by services/dispatch_service before storage —
    a zero-seat vehicle or a thirty-hour margin is replaced by the default
    rather than rejected, so a typo cannot lock the planner.
    """
    vehicles: list[TransferVehicle] = Field(default_factory=list)
    min_hours_before_flight: float = 3.0
    # None, not a number: the feedback fixed this window at 45 minutes and
    # services/dispatch_service.DEFAULT_WINDOW_MINUTES is where that lives.
    # A second default here drifted to 60, so saving the vehicle fleet — a
    # payload that has no reason to mention the window at all — silently
    # widened the grouping from 45 to 60 behind the organizer's back.
    grouping_window_minutes: Optional[int] = None
    # Where arrivals are dropped and departures collected. Not derivable: the
    # flight file does not name a hotel and the hotel file does not say which
    # property serves this transfer, so the organizer writes it once.
    hotel_name: Optional[str] = None


class TransferGroupApply(BaseModel):
    """One accepted group, exactly as it appeared on screen — including any
    edit the organizer made to it before accepting."""
    direction: str
    pickup_time: Optional[str] = None
    pickup_location: str = ""
    dropoff_location: str = ""
    participant_ids: list[str] = Field(default_factory=list)
    vehicle: Optional[dict[str, Any]] = None


class TransferPlanApply(BaseModel):
    """The groups to persist. Only what is sent here is written: a group the
    organizer removed on screen must stay removed."""
    groups: list[TransferGroupApply] = Field(default_factory=list)


class RegistrationExtrasUpdate(BaseModel):
    """The organizer's own questions and contractual tick-boxes.

    Deliberately untyped lists of dicts: both are normalised by
    services/registration_form, which drops malformed entries instead of
    rejecting the whole payload. A 422 here would let one bad row lock an
    organizer out of their own form editor.
    """
    custom_fields: list[dict[str, Any]] = Field(default_factory=list)
    confirmations: list[dict[str, Any]] = Field(default_factory=list)


class FieldPolicyUpdate(BaseModel):
    """Which participant fields this event tracks, and how strictly.

    Values are ``required`` / ``optional`` / ``not_used``. Kept as a plain
    string map rather than a typed enum so an unknown state coming from an
    older client is dropped by services/field_policy instead of rejected with a
    422 — the settings screen must never be able to lock itself out.
    """
    policy: dict[str, Any]


class RoomingGenerateRequest(BaseModel):
    """The three decisions a generation leaves to the organizer.

    All optional: pressing "Generate" with no options is the common case, and it
    numbers from 101 the way the hotels in the feedback's own examples do.

    ``renumber`` is the destructive one, and it is off by default. Left off, a
    room keeps the number it already has as long as the same people are in it,
    so regenerating after one cancellation does not move ninety people and force
    a reprint. Turned on, our own numbers are laid out again from scratch —
    never the hotel's, which are facts about physical rooms.
    """
    start_number: int = Field(default=101, ge=0, le=99999)
    prefix: str = Field(default="", max_length=8)
    renumber: bool = False
    note: str = Field(default="", max_length=500)
    # What a participant who never answered the room-type question is booked
    # as. The one option on this screen with an invoice attached — ninety
    # singles and ninety doubles are not the same hotel bill — which is why it
    # replaced the starting number in the UI. A declared type still wins.
    default_room_type: Literal["single", "double"] = "single"
    # A twin with nobody on the other side blocks generation (§4): the hotel
    # either gives that room to one person or phones to ask, and both cost
    # money. `force` is the deliberate override, and it is never the default —
    # the point is that somebody sees the list of gaps before deciding.
    force: bool = False


class RoomingPreset(BaseModel):
    """One saved numbering convention (point 4) — 'start at 301, prefix B-'
    saved once instead of retyped every time this event's list is generated."""
    id: str = Field(default="", max_length=32)
    name: str = Field(..., max_length=60)
    start_number: int = Field(default=101, ge=0, le=99999)
    prefix: str = Field(default="", max_length=8)
    # Presets saved before this field existed come back as "single", which is
    # what they meant: the default was the only behaviour available.
    room_type: Literal["single", "double"] = "single"


class RoomingImportLine(BaseModel):
    """One room the hotel's file gives to one participant."""
    participant_id: UUID
    room_number: str = Field(..., min_length=1, max_length=20)
    # Empty when the file had no type column: the fiche keeps whatever it says
    # rather than being blanked by a file that never mentioned the subject.
    room_type: str = Field(default="", max_length=40)


class RoomingImportApply(BaseModel):
    """The lines a person looked at and accepted.

    The client sends back what it was shown rather than the file, so nothing
    can be written that was not on screen: re-parsing server-side would let a
    second upload between preview and apply change what gets saved.
    """
    lines: list[RoomingImportLine] = Field(default_factory=list, max_length=5000)
    # A number from the hotel is a fact about a physical room. Locked by
    # default so no later generation and no consolidation can quietly take it
    # back; unlockable per field from the participant screen as always.
    lock: bool = True


class RoomingPresetsUpdate(BaseModel):
    """The full set to save. Replaces what was there, the same contract
    transfer-settings already uses: the caller sends the complete list it
    wants kept, not a single preset to append."""
    presets: list[RoomingPreset] = Field(default_factory=list, max_length=50)


class PublicRegistrationInfo(BaseModel):
    """What the public form page needs to render itself: nothing more."""
    event_id: UUID
    event_name: str
    is_open: bool
    # Which questions to show and which to insist on. Always sent in full and
    # already resolved, so the public page never has to know the defaults.
    fields: list[RegistrationFieldState] = []
    # The organizer's own questions and contractual tick-boxes. Empty lists on
    # a deployment without migration 010 — the page renders the catalogue and
    # nothing else, exactly as before.
    custom_fields: list[dict[str, Any]] = []
    confirmations: list[dict[str, Any]] = []
    # The language the labels above came back in, and what else is on offer.
    # Echoed rather than assumed: the page asked for a language and needs to
    # know which one it actually got (an unsupported code resolves to French
    # rather than failing).
    locale: str = "fr"
    supported_locales: list[str] = ["fr", "nl", "en"]
    # The mini event site shown above the form (§11). Empty on an event that
    # configured none, and on a deployment without migration 018 — in both
    # cases the link shows the form alone, exactly as it did before.
    sections: list[dict[str, Any]] = []
    # Which documents this event asks for (§9), with their accepted formats and
    # size cap. Empty when the event asks for none — the page then renders no
    # upload field at all rather than an inert one.
    attachments: list[dict[str, Any]] = []
    # This event's own logo (point 11), or None — the page then falls back to
    # the default MAX mark, exactly as it always has.
    logo_url: Optional[str] = None
    # How the page looks (migration 030). Always sent, always complete: an
    # event that configured nothing gets the defaults resolved here rather
    # than a null the page would have to interpret.
    theme: dict[str, Any] = Field(default_factory=dict)
    # How the pages are laid out in blocks (migration 032). A map of
    # page -> blocks: "home" is the registration page, other keys are mini-site
    # section slugs. Empty ({}) on any event that never opted in — the signal
    # each page reads as "render the classic layout", so nothing changes until
    # an organizer arranges a page and saves.
    layout: dict[str, list[dict[str, Any]]] = Field(default_factory=dict)


class EventSiteUpdate(BaseModel):
    """The whole site, replaced in one call.

    A full replacement rather than per-section PATCHes: the editor holds every
    section on screen at once, and two half-saved sections is a worse state to
    recover from than one rejected save.
    """
    sections: list[dict[str, Any]] = []


class RegistrationCompanion(BaseModel):
    """A second participant registered in the same submission (§9).

    Deliberately a short list. A companion is a real participant and gets a
    real fiche, but the person filling the form is not their secretary: what is
    asked here is what only they can answer, and everything else — company,
    address, the event's own custom questions — is inherited from the main
    registrant rather than typed twice.

    The two are linked as roommates when a shared room type is requested, which
    is the case this feature exists for: today they register separately, write
    each other's name in a box, and the pairing step has to guess.
    """
    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: str = Field(..., min_length=1, max_length=100)
    # Optional on purpose: a spouse frequently has no professional address, and
    # refusing the registration over it would send the pair back to email.
    email: Optional[str] = None
    phone: Optional[str] = None
    date_of_birth: Optional[str] = None
    nationality: Optional[str] = None
    passport_number: Optional[str] = None
    passport_expiry: Optional[str] = None
    dietary_requirements: Optional[str] = None
    food_allergy_info: Optional[str] = None
    pmr_needs: Optional[str] = None
    shirt_size: Optional[str] = None
    remarks: Optional[str] = None
    # Shares a room with the main registrant unless told otherwise. The default
    # is the whole point: this is how the two get paired without either of them
    # writing the other's name into a free-text box.
    shares_room: bool = True


class PublicRegistrationSubmit(BaseModel):
    """
    A participant's own submission of the public registration form.

    Mirrors the fields already on the Registration List (first/last name,
    email, company, phone, nationality, dietary_requirements), the ones
    already canonical elsewhere in the app but never captured at
    registration time (date_of_birth, passport_number, passport_expiry,
    job_title, badge_name, language), plus the fields the client asked for
    that have no canonical field yet (special_requests, room_preference,
    pmr_needs, remarks, emergency_contact_name/phone) -- those pass through
    as extra keys in source_records.normalized_data exactly like an
    unrecognized column from an uploaded file (mapping_service.py's
    catch-all: "no information is ever discarded").
    """
    first_name: str = Field(..., min_length=1, max_length=255)
    last_name: str = Field(..., min_length=1, max_length=255)
    email: str
    company: Optional[str] = None
    phone: Optional[str] = None
    nationality: Optional[str] = None
    date_of_birth: Optional[str] = None
    passport_number: Optional[str] = None
    passport_expiry: Optional[str] = None
    job_title: Optional[str] = None
    badge_name: Optional[str] = None
    language: Optional[str] = None
    dietary_requirements: Optional[str] = None
    food_allergy_info: Optional[str] = None
    special_requests: Optional[str] = None
    room_preference: Optional[str] = None
    pmr_needs: Optional[str] = None
    remarks: Optional[str] = None
    emergency_contact_name: Optional[str] = None
    emergency_contact_phone: Optional[str] = None
    # Everything below mirrors the reference form MAX already runs for its own
    # clients. Optional here without exception: which of them a given event
    # actually asks (and insists on) is the organizer's call, enforced against
    # services/registration_form on submit — not baked into the model, which
    # would make every event ask the same twenty questions again.
    civility: Optional[str] = None
    birth_place: Optional[str] = None
    address: Optional[str] = None
    postal_code: Optional[str] = None
    city: Optional[str] = None
    country: Optional[str] = None
    company_vat: Optional[str] = None
    company_address: Optional[str] = None
    company_postal_code: Optional[str] = None
    company_city: Optional[str] = None
    passport_country: Optional[str] = None
    transfer_needed: Optional[str] = None
    arrival_flight: Optional[str] = None
    arrival_airport: Optional[str] = None
    departure_flight: Optional[str] = None
    # room_type and roommate are canonical: an answer here reaches the pairing
    # step directly, so a couple registering separately is linked without any
    # rooming list ever being imported.
    room_type: Optional[str] = None
    roommate: Optional[str] = None
    extension_requested: Optional[str] = None
    extension_start: Optional[str] = None
    extension_end: Optional[str] = None
    extension_hotel: Optional[str] = None
    shirt_size: Optional[str] = None
    activity_preferences: Optional[str] = None
    emergency_contact_country: Optional[str] = None
    # The organizer's own questions, keyed by the keys they defined. Unknown
    # keys are dropped server-side rather than trusted.
    custom: dict[str, Any] = Field(default_factory=dict)
    # The event's contractual tick-boxes (cancellation policy, role
    # confirmation), keyed the same way. All of them must be true.
    confirmations: dict[str, bool] = Field(default_factory=dict)
    # Documents uploaded before the form was submitted (§9), each
    # ``{"kind": ..., "id": ...}``. The ids are checked against this event's own
    # unclaimed uploads — a caller cannot attach somebody else's passport by
    # guessing an id.
    attachments: list[dict[str, str]] = Field(default_factory=list, max_length=6)
    # A second person registered in the same submission (§9): a spouse, a
    # colleague sharing the room. Only the fields that genuinely differ — the
    # rest is inherited from the main registrant, because asking somebody to
    # retype their own company for their partner is how a form gets abandoned.
    companion: Optional["RegistrationCompanion"] = None
    consent: bool
    # Honeypot: real visitors never see or fill this field (hidden by CSS on
    # the form); a non-empty value means a bot filled every input it found.
    website: str = ""

    @field_validator("phone", "emergency_contact_phone")
    @classmethod
    def phone_requires_a_country_code(cls, v: Optional[str]) -> Optional[str]:
        """The form's own UI requires picking a dial code before a number can
        be typed (ex. +32 Belgique, +213 Algérie) — this is the server-side
        backstop for a client that skips the browser form entirely."""
        import re
        if v and not re.match(r"^\+\d{1,4}\s", v.strip()):
            raise ValueError("Le numéro de téléphone doit inclure un indicatif pays (ex. +32, +213).")
        return v

    @field_validator("email")
    @classmethod
    def email_looks_valid(cls, v: str) -> str:
        import re
        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", v.strip()):
            raise ValueError("Adresse email invalide.")
        return v.strip().lower()

    @field_validator("consent")
    @classmethod
    def consent_is_required(cls, v: bool) -> bool:
        if not v:
            raise ValueError("Le consentement est requis pour s'inscrire.")
        return v


# ---------------------------------------------------------------------------
# Files & Column Mapping
# ---------------------------------------------------------------------------

class ColumnMappingSuggestion(BaseModel):
    suggested_field: Optional[str] = None
    confidence: float
    alternatives: list[str] = []


class MappingSuggestionsResponse(BaseModel):
    suggestions: dict[str, ColumnMappingSuggestion]
    canonical_fields: list[str]


class FileUploadResponse(ORMBase):
    """Returned after a file is successfully uploaded and parsed."""
    file_id: UUID
    original_filename: str
    source_type: str
    row_count: int
    column_count: int
    columns: list[str]
    sample_rows: list[dict[str, Any]]   # First 5 rows as list of dicts
    import_status: str
    mapping_suggestions: dict[str, ColumnMappingSuggestion]
    canonical_fields: list[str]


class FileListItem(ORMBase):
    id: UUID
    original_filename: str
    source_type: str
    row_count: Optional[int] = None
    column_count: Optional[int] = None
    import_status: str
    imported_at: datetime
    error_message: Optional[str] = None


class FilePreviewResponse(ORMBase):
    """Returned by GET /files/{file_id}/preview."""
    file_id: UUID
    columns: list[str]
    row_count: int
    sample_rows: list[dict[str, Any]]   # 10 rows
    mapping_suggestions: dict[str, ColumnMappingSuggestion]
    canonical_fields: list[str]
    # The full auto-built mapping already stored on the file (every column,
    # including catch-all custom fields) so the review confirms the COMPLETE
    # mapping and never drops columns. Plus the per-column report.
    column_mapping: Optional[dict[str, str]] = None
    mapping_report: Optional[dict[str, Any]] = None
    # Points 5+6: True when this project has already confirmed a mapping for
    # a layout shaped exactly like this file's. The screen is then a
    # verification of a remembered answer, not a mapping built from scratch.
    remembered: bool = False


class ColumnMappingRequest(BaseModel):
    """
    Request body for POST /files/{file_id}/map-columns.

    ``confirmed`` MUST be True — this gate enforces human review of the mapping
    before it is persisted and processing begins.
    """
    mapping: dict[str, str] = Field(
        ...,
        description="Map of source column name → canonical target field name.",
        examples=[{"Nom": "last_name", "Prénom": "first_name", "E-mail": "email"}],
    )
    confirmed: bool = Field(
        ...,
        description="Must be true. Confirms that a human has reviewed the column mapping.",
    )

    @field_validator("confirmed")
    @classmethod
    def must_be_confirmed(cls, v: bool) -> bool:
        if not v:
            raise ValueError(
                ERR_MAPPING_NOT_CONFIRMED
            )
        return v


class ColumnMappingResponse(BaseModel):
    """Returned after a column mapping is saved."""
    file_id: UUID
    import_status: str
    mapping: dict[str, str]
    message: str


# ---------------------------------------------------------------------------
# Participants
# ---------------------------------------------------------------------------

class ParticipantResponse(ORMBase):
    """Full participant record. dietary_requirements omitted for non-admin/pm."""
    id: UUID
    event_id: UUID
    first_name: str
    last_name: str
    email: Optional[str] = None
    company: Optional[str] = None
    phone: Optional[str] = None
    nationality: Optional[str] = None
    # dietary_requirements is conditionally included (see router)
    dietary_requirements: Optional[str] = None
    completeness_status: str
    has_flight: bool
    has_hotel: bool
    has_transfer: bool
    has_activities: bool
    verification_note: Optional[str] = None
    locked_fields: dict[str, Any]
    registration_source_id: Optional[UUID] = None
    fcm_source_id: Optional[UUID] = None
    # A personal extension at the registrant's own expense (§3, migration
    # 022) — their own words, not derived from a flight date nobody explained.
    extension_requested: Optional[str] = None
    extension_start: Optional[str] = None
    extension_end: Optional[str] = None
    extension_hotel: Optional[str] = None
    # Kinds of file this fiche was actually built from, read from the linked
    # source_records rather than from the two *_source_id columns above (which
    # stay NULL on a fiche created by the orphan-linking step).
    sources: list[str] = []
    created_at: datetime
    updated_at: datetime


class ParticipantListItem(ORMBase):
    """Lightweight participant for list views."""
    id: UUID
    event_id: UUID
    first_name: str
    last_name: str
    email: Optional[str] = None
    company: Optional[str] = None
    phone: Optional[str] = None
    completeness_status: str
    has_flight: bool
    has_hotel: bool
    has_transfer: bool
    has_activities: bool


class ParticipantLookupItem(ORMBase):
    """Minimal participant record for dropdowns/selectors."""
    id: UUID
    first_name: str
    last_name: str
    completeness_status: str


class ParticipantUpdate(BaseModel):
    """
    Request body for PATCH /participants/{id}.

    Each call updates a single field. The reason is required and written to the
    change_log BEFORE the update is applied (non-repudiation).
    """
    field: str = Field(..., description="Name of the field to update.")
    value: Any = Field(..., description="New value for the field.")
    lock: bool = Field(
        False,
        description="If true, add this field to locked_fields so re-imports cannot overwrite it.",
    )
    reason: str = Field(
        ...,
        min_length=1,
        description="Human-readable reason for the change (written to change_log).",
    )


class ParticipantListResponse(BaseModel):
    """Paginated participant list."""
    items: list[ParticipantListItem]
    total: int
    page: int
    page_size: int
    total_pages: int


# ---------------------------------------------------------------------------
# Consolidation Runs
# ---------------------------------------------------------------------------

class ConsolidationRunRequest(BaseModel):
    """Request body to trigger a new consolidation run."""
    # No body required — event_id comes from the path parameter.
    pass


class ConsolidationStats(BaseModel):
    """Statistics summary for a completed consolidation run.

    Mirrors the runtime `stats` dict built incrementally in
    consolidation_service.py's run_consolidation — several keys are only
    added conditionally during a run (e.g. mappings_repaired is 0 unless
    repair_stored_mappings actually changed something), so everything here
    defaults to 0 rather than being required. Kept in sync manually since
    that dict has no schema of its own (2026-07-21/22 audit finding: this
    model previously covered only 8 of the ~18 real keys).
    """
    total_source_records: int = 0
    matched_certain: int = 0
    matched_probable: int = 0
    to_verify: int = 0
    not_found: int = 0
    participants_created: int = 0
    participants_updated: int = 0
    exceptions_count: int = 0
    mappings_repaired: int = 0
    skipped_noise_rows: int = 0
    stale_records_purged: int = 0
    junk_participants_purged: int = 0
    links_sanitized: int = 0
    names_backfilled: int = 0
    phantoms_merged: int = 0
    exact_duplicates_merged: int = 0
    ai_auto_merged: int = 0
    match_candidates: int = 0

    model_config = ConfigDict(extra="allow")


class ConsolidationRunResponse(ORMBase):
    id: UUID
    event_id: UUID
    triggered_by: UUID
    status: str
    stats: Optional[ConsolidationStats] = None
    started_at: datetime
    completed_at: Optional[datetime] = None


class ConsolidationRunListItem(ORMBase):
    id: UUID
    status: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    stats: Optional[dict[str, Any]] = None


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class ExceptionResponse(ORMBase):
    id: UUID
    run_id: UUID
    event_id: UUID
    participant_id: Optional[UUID] = None
    source_record_id: Optional[UUID] = None
    exception_type: str
    severity: str
    message: str
    context_data: Optional[dict[str, Any]] = None
    resolved: bool
    resolved_by: Optional[UUID] = None
    resolved_at: Optional[datetime] = None
    created_at: datetime


class ExceptionResolveRequest(BaseModel):
    """Request body to mark an exception as resolved."""
    resolved: bool = True
    note: Optional[str] = None


class ExceptionResolutionRequest(BaseModel):
    """Request body to mark an exception as resolved with a chosen value."""
    resolution: str


# ---------------------------------------------------------------------------
# Exports
# ---------------------------------------------------------------------------

class ExportRequest(BaseModel):
    """Request body for POST /events/{event_id}/exports."""
    run_id: Optional[UUID] = Field(None, description="UUID of the consolidation run to export. If not provided, exports the latest completed run.")


class ExportResponse(ORMBase):
    id: UUID
    run_id: UUID
    event_id: UUID
    filename: str
    created_at: datetime


class ExportDownloadResponse(BaseModel):
    """Response containing a time-limited signed download URL."""
    export_id: UUID
    signed_url: str
    expires_at: datetime
    filename: str


# ---------------------------------------------------------------------------
# Change Log
# ---------------------------------------------------------------------------

class ChangeLogEntry(ORMBase):
    id: UUID
    event_id: UUID
    user_id: UUID
    entity_type: str
    entity_id: UUID
    field_name: str
    old_value: Optional[str] = None
    new_value: Optional[str] = None
    change_reason: Optional[str] = None
    changed_at: datetime


# ---------------------------------------------------------------------------
# Generic responses
# ---------------------------------------------------------------------------

class MessageResponse(BaseModel):
    """Simple success/info message."""
    message: str


class ErrorResponse(BaseModel):
    """Standard error response shape."""
    detail: str
    code: Optional[str] = None


# ---------------------------------------------------------------------------
# Phase 2 — Flights, Hotels, Transfers, Activities
# ---------------------------------------------------------------------------

class FlightResponse(ORMBase):
    id: UUID
    event_id: UUID
    participant_id: Optional[UUID] = None
    pnr_code: Optional[str] = None
    airline: Optional[str] = None
    flight_number: str
    departure_airport: str
    arrival_airport: str
    departure_time: datetime
    arrival_time: datetime
    baggage_info: Optional[str] = None
    status: str
    created_at: datetime
    participant_name: Optional[str] = None  # joined helper


class FlightCreate(BaseModel):
    """A flight entered by hand from the Flights page.

    Same shape as what the FCM extraction writes, so a manually added segment
    is indistinguishable downstream — it lands in the master list (has_flight),
    in the coverage counts and in the exports exactly like an imported one.
    """
    participant_id: UUID
    flight_number: str = Field(..., min_length=1, max_length=20)
    departure_airport: str = Field(..., min_length=1, max_length=120)
    arrival_airport: str = Field(..., min_length=1, max_length=120)
    departure_time: datetime
    arrival_time: datetime
    airline: Optional[str] = None
    pnr_code: Optional[str] = None
    baggage_info: Optional[str] = None
    status: str = "confirmed"


class FlightUpdate(BaseModel):
    pnr_code: Optional[str] = None
    airline: Optional[str] = None
    flight_number: Optional[str] = None
    departure_airport: Optional[str] = None
    arrival_airport: Optional[str] = None
    departure_time: Optional[datetime] = None
    arrival_time: Optional[datetime] = None
    baggage_info: Optional[str] = None
    status: Optional[str] = None


class HotelResponse(ORMBase):
    id: UUID
    event_id: UUID
    name: str
    address: Optional[str] = None
    city: Optional[str] = None
    contact_info: Optional[str] = None
    created_at: datetime


class HotelCreate(BaseModel):
    name: str
    address: Optional[str] = None
    city: Optional[str] = None
    contact_info: Optional[str] = None


class HotelUpdate(BaseModel):
    name: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    contact_info: Optional[str] = None


class HotelNightResponse(ORMBase):
    id: UUID
    hotel_id: UUID
    participant_id: UUID
    night_date: date
    room_type: str
    status: str
    created_at: datetime
    participant_name: Optional[str] = None  # joined helper
    hotel_name: Optional[str] = None        # joined helper


class HotelNightCreate(BaseModel):
    hotel_id: UUID
    participant_id: UUID
    night_date: date
    room_type: Optional[str] = "single"
    status: Optional[str] = "confirmed"


class HotelNightUpdate(BaseModel):
    hotel_id: Optional[UUID] = None
    room_type: Optional[str] = None
    status: Optional[str] = None


class TransferResponse(ORMBase):
    id: UUID
    event_id: UUID
    participant_id: UUID
    transfer_type: str
    flight_id: Optional[UUID] = None
    pickup_location: str
    dropoff_location: str
    pickup_time: datetime
    vehicle_type: Optional[str] = None
    status: str
    created_at: datetime
    participant_name: Optional[str] = None
    flight_number: Optional[str] = None


class TransferCreate(BaseModel):
    participant_id: UUID
    transfer_type: str
    flight_id: Optional[UUID] = None
    pickup_location: str
    dropoff_location: str
    pickup_time: datetime
    vehicle_type: Optional[str] = None
    status: Optional[str] = "scheduled"


class TransferUpdate(BaseModel):
    pickup_location: Optional[str] = None
    dropoff_location: Optional[str] = None
    pickup_time: Optional[datetime] = None
    vehicle_type: Optional[str] = None
    status: Optional[str] = None
    # 'arrival' | 'departure'. Needed because dropping somebody into another
    # group moves every field that defines that group, and direction is one of
    # them — without it, a person dragged into a departure keeps saying they
    # are arriving.
    transfer_type: Optional[str] = None


class TransferBulkUpdate(BaseModel):
    """One edit applied to many transfers at once.

    The alternative — one PATCH per transfer, fired in parallel from the
    browser — is what "Appliquer à tous les groupes" used to do. On an event
    with a few hundred people that is a few hundred concurrent requests, each
    re-checking access and each hitting the database several times; the first
    one to fail rejects the whole batch on the client while the rest keep
    going, so what the organizer sees is some rows changed, some not, and no
    way to tell which. One request, one access check, one write.
    """
    transfer_ids: list[UUID] = Field(default_factory=list, max_length=2000)
    patch: TransferUpdate


class ActivityResponse(ORMBase):
    id: UUID
    event_id: UUID
    name: str
    description: Optional[str] = None
    date_time: Optional[datetime] = None
    location: Optional[str] = None
    capacity: Optional[int] = None
    created_at: datetime
    registrations_count: Optional[int] = 0


class ActivityCreate(BaseModel):
    name: str
    description: Optional[str] = None
    date_time: Optional[datetime] = None
    location: Optional[str] = None
    capacity: Optional[int] = None


class ActivityUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    date_time: Optional[datetime] = None
    location: Optional[str] = None
    capacity: Optional[int] = None


class ParticipantActivityResponse(ORMBase):
    id: UUID
    participant_id: UUID
    activity_id: UUID
    status: str
    created_at: datetime
    participant_name: Optional[str] = None
    dietary_requirements: Optional[str] = None


# ---------------------------------------------------------------------------
# Phase 3 — Reporting & Global Participant History
# ---------------------------------------------------------------------------

class ReportSummaryResponse(BaseModel):
    total_registered: int
    missing_flight: int
    missing_hotel: int
    missing_transfer: int


class HotelNightsReportItem(BaseModel):
    night_date: date
    count: int


class GlobalParticipantHistoryItem(BaseModel):
    event_name: str
    event_date: Optional[date] = None
    dietary_requirements: Optional[str] = None


class GlobalParticipantHistoryResponse(BaseModel):
    email: str
    full_name: str
    history: list[GlobalParticipantHistoryItem]


# ---------------------------------------------------------------------------
# Phase 3 — AI Email Agent
# ---------------------------------------------------------------------------

class EmailProposalAnalyzeRequest(BaseModel):
    sender: str
    subject: str
    body: str

class EmailProposalResponse(ORMBase):
    id: UUID
    event_id: UUID
    sender: str
    subject: str
    body: str
    received_at: datetime
    participant_id: Optional[UUID] = None
    status: str
    proposed_changes: dict[str, Any]
    ai_explanation: Optional[str] = None
    created_at: datetime
    participant_name: Optional[str] = None


# ---------------------------------------------------------------------------
# i18n-ready error message constants
# ---------------------------------------------------------------------------
# These constants are the canonical English error messages.
# The frontend is responsible for translating them using their code (key name).

ERR_MAPPING_NOT_CONFIRMED = (
    "Column mapping must be explicitly confirmed (confirmed=true) before it can be saved. "
    "This ensures a human has reviewed the mapping."
)
ERR_UNSUPPORTED_FILE_FORMAT = (
    "Unsupported file format. Only .xlsx, .xls, and .csv files are accepted."
)
ERR_FILE_TOO_LARGE = "File exceeds the maximum allowed size of 50 MB."
ERR_EVENT_NOT_FOUND = "Event not found or access denied."
ERR_PARTICIPANT_NOT_FOUND = "Participant not found."
ERR_EXPORT_NOT_FOUND = "Export not found."
ERR_RUN_NOT_FOUND = "Consolidation run not found."
ERR_FILE_NOT_FOUND = "File not found."
ERR_INSUFFICIENT_ROLE = "You do not have permission to perform this action."
ERR_LOCKED_FIELD = "This field is locked and cannot be modified via re-import."
