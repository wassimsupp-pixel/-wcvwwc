"""
main.py — FastAPI application entry point for VO Event Max API.

Configures:
  - CORS middleware
  - All routers under /api prefix
  - Health check endpoint
  - Global exception handler (no stack traces in production)
"""

from __future__ import annotations

import logging
import os
import re
import traceback

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse

import config
from routers import events, files, participants, consolidation, exports, flights, hotels, transfers, activities, reports, global_participants, email_agent, mail_connection, communications, sharing, matching, event_grouping, public_registration, chatbot, history, attachments


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# App instance
# ---------------------------------------------------------------------------
app = FastAPI(
    title=config.APP_TITLE,
    description=config.APP_DESCRIPTION,
    version=config.APP_VERSION,
    # Disable the auto-generated docs in production to reduce attack surface
    docs_url="/docs" if os.getenv("ENVIRONMENT", "development") != "production" else None,
    redoc_url="/redoc" if os.getenv("ENVIRONMENT", "development") != "production" else None,
)

# ---------------------------------------------------------------------------
# CORS Middleware
# ---------------------------------------------------------------------------
# Filter out '*' wildcard from allowed_origins to prevent Starlette crash when allow_credentials=True
safe_origins = [origin.strip() for origin in config.ALLOWED_ORIGINS if origin.strip() and origin.strip() != "*"]

# Single source of truth for the origin regex: the middleware AND the global
# exception handler below must agree, otherwise unhandled 500s reach the
# browser without CORS headers (see the handler for why).
CORS_ORIGIN_REGEX = "https://.*\\.vercel\\.app|https://.*\\.railway\\.app|http://localhost:3000"
_cors_origin_re = re.compile(CORS_ORIGIN_REGEX)

# Compression, added before CORS so it wraps the CORS layer and every
# response inside it.
#
# Measured on the live event: the master list answers 247 KB of JSON with no
# content-encoding at all — roughly a quarter of a second of transfer for a
# payload that gzips to about a tenth of that. JSON of this shape (the same
# forty keys repeated eighty-one times) is close to the best case a compressor
# ever gets.
#
# The 1 KB floor keeps small answers alone: below that, compressing costs more
# CPU on both ends than the bytes it saves.
app.add_middleware(GZipMiddleware, minimum_size=1024)

app.add_middleware(
    CORSMiddleware,
    allow_origins=safe_origins,
    allow_origin_regex=CORS_ORIGIN_REGEX,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    # Without this the browser hides Content-Disposition from the page's own
    # JavaScript on a cross-origin response — and the frontend lives on
    # vercel.app while this API lives on railway.app, so every response is
    # cross-origin. The symptom is silent and confusing: the PDF downloads
    # fine, named "confirmation.pdf" instead of after the participant,
    # because the reader fell back to its default when the header came back
    # null. Only a handful of response headers are visible by default; every
    # other one has to be listed here.
    expose_headers=["Content-Disposition"],
)


def _cors_headers_for(request: Request) -> dict[str, str]:
    """CORS headers for responses produced OUTSIDE the middleware stack.

    Starlette handles the catch-all Exception handler in ServerErrorMiddleware,
    which sits outside CORSMiddleware — so its response never gets CORS
    headers, and the browser surfaces an opaque "Failed to fetch" instead of
    the JSON error (this is exactly what made the 2026-07 hotel-assignment
    500 hard to diagnose). Echo the origin here iff it would have been
    allowed by the middleware."""
    origin = request.headers.get("origin", "")
    if origin and (origin in safe_origins or _cors_origin_re.fullmatch(origin)):
        return {
            "Access-Control-Allow-Origin": origin,
            "Access-Control-Allow-Credentials": "true",
            "Vary": "Origin",
        }
    return {}

# ---------------------------------------------------------------------------
# Global exception handler
# ---------------------------------------------------------------------------

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """
    Catch-all handler for unhandled exceptions.

    In production: returns a generic 500 with no stack trace.
    In development: includes the traceback for easier debugging.
    """
    is_production = os.getenv("ENVIRONMENT", "development") == "production"

    logger.error(
        "Unhandled exception on %s %s: %s",
        request.method,
        request.url.path,
        exc,
        exc_info=True,
    )

    body: dict = {
        "detail": "An unexpected internal error occurred. Please try again or contact support.",
        "path": request.url.path,
    }

    if not is_production:
        body["debug_traceback"] = traceback.format_exc()

    return JSONResponse(status_code=500, content=body, headers=_cors_headers_for(request))


# ---------------------------------------------------------------------------
# Routers
# ---------------------------------------------------------------------------
API_PREFIX = "/api"

app.include_router(events.router,        prefix=API_PREFIX, tags=["Events"])
app.include_router(files.router,         prefix=API_PREFIX, tags=["Files"])
app.include_router(participants.router,  prefix=API_PREFIX, tags=["Participants"])
app.include_router(consolidation.router, prefix=API_PREFIX, tags=["Consolidation"])
app.include_router(exports.router,       prefix=API_PREFIX, tags=["Exports"])
app.include_router(flights.router,       prefix=API_PREFIX, tags=["Flights"])
app.include_router(hotels.router,        prefix=API_PREFIX, tags=["Hotels"])
app.include_router(transfers.router,     prefix=API_PREFIX, tags=["Transfers"])
app.include_router(activities.router,    prefix=API_PREFIX, tags=["Activities"])
app.include_router(reports.router,       prefix=API_PREFIX, tags=["Reports"])
app.include_router(global_participants.router, prefix=API_PREFIX, tags=["Global Participants"])
app.include_router(email_agent.router,         prefix=API_PREFIX, tags=["Email Agent"])
app.include_router(mail_connection.router,     prefix=API_PREFIX, tags=["Mail Connection"])
app.include_router(communications.router,      prefix=API_PREFIX, tags=["Communications"])
app.include_router(sharing.router,              prefix=API_PREFIX, tags=["Sharing"])
app.include_router(matching.router,             prefix=API_PREFIX, tags=["Matching"])
app.include_router(event_grouping.router,       prefix=API_PREFIX, tags=["Event Grouping"])
app.include_router(public_registration.router,  prefix=API_PREFIX, tags=["Public Registration"])
app.include_router(chatbot.router,              prefix=API_PREFIX, tags=["Assistant"])
app.include_router(history.router,              prefix=API_PREFIX, tags=["History"])
app.include_router(attachments.router,          prefix=API_PREFIX, tags=["Attachments"])



# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

@app.get("/health", tags=["Health"])
async def health_check() -> dict:
    """
    Liveness probe endpoint.

    Returns a simple status object used by Railway health checks and
    uptime monitors. No authentication required.
    """
    return {"status": "ok", "version": config.APP_VERSION}
