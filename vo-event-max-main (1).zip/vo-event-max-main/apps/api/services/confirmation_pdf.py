"""
services/confirmation_pdf.py — The participant's own copy (feedback §16).

MAX sends individual confirmations, and the feedback is explicit about what the
first version needs and about what it does not: name, event, flight, hotel with
check-in and check-out, transfer, activity, organiser contact — and the design
work comes later. "Je considère néanmoins que le PDF fonctionnel doit passer
avant la partie graphique avancée."

So this is a functional document, deliberately. One typeface, three sizes, no
images. What it is NOT is a summary: this is the sheet somebody holds at a
check-in desk, so it carries the booking reference, the airline, the hotel's
address and phone number, the room number and who they are sharing it with. A
confirmation that says "Radisson Blu" and nothing else is one the traveller has
to supplement with three emails.

Two rules decide everything else.

**Never invent.** Only facts actually present in the consolidated data appear,
and a section with nothing behind it is omitted rather than printed empty. A
traveller reading "Transfer: —" concludes there is no transfer; one reading a
document with no transfer section asks. The second is recoverable, the first is
somebody standing outside an airport.

**Nights become a stay.** The database stores hotel_nights one row per night
because that is how availability and invoicing work, but nobody wants to read
fourteen lines that each say "Radisson"; §16 asks for check-in and check-out,
which is the same fact stated the way a human holds it.
"""

from __future__ import annotations

import logging
import re
import unicodedata
from typing import Any, Iterable, Optional

logger = logging.getLogger(__name__)

# A4 at 72 dpi, which is what PyMuPDF works in.
PAGE_WIDTH = 595
PAGE_HEIGHT = 842
MARGIN = 56
BOTTOM = PAGE_HEIGHT - 64
# Where the value column starts on a label/value row. Fixed rather than
# measured: a document whose columns move between sections reads as three
# documents stapled together.
VALUE_X = MARGIN + 118

FONT = "helv"
FONT_BOLD = "hebo"

TITLES: dict[str, dict[str, str]] = {
    "fr": {
        "document": "Confirmation de participation",
        "you": "Vos coordonnées",
        "flight": "Vols", "hotel": "Hébergement", "transfer": "Transferts",
        "activity": "Activités", "contact": "Contact organisation",
        "needs": "Vos besoins particuliers",
        "dietary": "Régime alimentaire", "pmr": "Accessibilité",
        "checkin": "Arrivée", "checkout": "Départ", "nights": "nuit(s)",
        "room_type": "Type de chambre", "room": "N° de chambre", "roommate": "Avec",
        "reference": "Référence", "airline": "Compagnie", "baggage": "Bagages",
        "departure": "Décollage", "arrival": "Atterrissage", "segment": "Vol",
        "pickup": "Prise en charge", "vehicle": "Véhicule",
        "email": "Email", "phone": "Téléphone", "company": "Société",
        "role": "Fonction", "badge": "Nom sur badge", "nationality": "Nationalité",
        "address": "Adresse", "when": "Quand", "where": "Lieu",
        "cancelled": "ANNULÉ", "changed": "MODIFIÉ", "waitlisted": "LISTE D'ATTENTE",
        "extension": "extension personnelle",
        "duration": "Durée", "kind": "Type",
        "arrival_leg": "vers l'hôtel", "departure_leg": "vers l'aéroport",
        "activity_leg": "vers l'activité",
        "itinerary": "Votre séjour jour par jour",
        "footer": "Document généré automatiquement à partir des informations connues à ce jour.",
        "generated": "Généré le", "page": "Page",
    },
    "nl": {
        "document": "Bevestiging van deelname",
        "you": "Uw gegevens",
        "flight": "Vluchten", "hotel": "Accommodatie", "transfer": "Transfers",
        "activity": "Activiteiten", "contact": "Contact organisatie",
        "needs": "Uw bijzondere behoeften",
        "dietary": "Dieetwensen", "pmr": "Toegankelijkheid",
        "checkin": "Aankomst", "checkout": "Vertrek", "nights": "nacht(en)",
        "room_type": "Type kamer", "room": "Kamernummer", "roommate": "Met",
        "reference": "Referentie", "airline": "Maatschappij", "baggage": "Bagage",
        "departure": "Vertrek", "arrival": "Aankomst", "segment": "Vlucht",
        "pickup": "Ophalen", "vehicle": "Voertuig",
        "email": "E-mail", "phone": "Telefoon", "company": "Bedrijf",
        "role": "Functie", "badge": "Naam op badge", "nationality": "Nationaliteit",
        "address": "Adres", "when": "Wanneer", "where": "Plaats",
        "cancelled": "GEANNULEERD", "changed": "GEWIJZIGD", "waitlisted": "WACHTLIJST",
        "extension": "persoonlijke verlenging",
        "duration": "Duur", "kind": "Type",
        "arrival_leg": "naar het hotel", "departure_leg": "naar de luchthaven",
        "activity_leg": "naar de activiteit",
        "itinerary": "Uw verblijf dag per dag",
        "footer": "Automatisch gegenereerd op basis van de tot nu toe bekende gegevens.",
        "generated": "Gegenereerd op", "page": "Pagina",
    },
    "en": {
        "document": "Participation confirmation",
        "you": "Your details",
        "flight": "Flights", "hotel": "Accommodation", "transfer": "Transfers",
        "activity": "Activities", "contact": "Organiser contact",
        "needs": "Your specific needs",
        "dietary": "Dietary requirements", "pmr": "Accessibility",
        "checkin": "Check-in", "checkout": "Check-out", "nights": "night(s)",
        "room_type": "Room type", "room": "Room number", "roommate": "With",
        "reference": "Booking ref.", "airline": "Airline", "baggage": "Baggage",
        "departure": "Departure", "arrival": "Arrival", "segment": "Flight",
        "pickup": "Pick-up", "vehicle": "Vehicle",
        "email": "Email", "phone": "Phone", "company": "Company",
        "role": "Job title", "badge": "Name on badge", "nationality": "Nationality",
        "address": "Address", "when": "When", "where": "Where",
        "cancelled": "CANCELLED", "changed": "CHANGED", "waitlisted": "WAITING LIST",
        "extension": "personal extension",
        "duration": "Duration", "kind": "Type",
        "arrival_leg": "to the hotel", "departure_leg": "to the airport",
        "activity_leg": "to the activity",
        "itinerary": "Your stay, day by day",
        "footer": "Automatically generated from the information known to date.",
        "generated": "Generated on", "page": "Page",
    },
}

_MONTHS = {
    "fr": ("janvier", "février", "mars", "avril", "mai", "juin", "juillet",
           "août", "septembre", "octobre", "novembre", "décembre"),
    "nl": ("januari", "februari", "maart", "april", "mei", "juni", "juli",
           "augustus", "september", "oktober", "november", "december"),
    "en": ("January", "February", "March", "April", "May", "June", "July",
           "August", "September", "October", "November", "December"),
}


class PdfUnavailable(RuntimeError):
    """PyMuPDF is not importable on this deployment."""


# ---------------------------------------------------------------------------
# Dates and times, as a human reads them
# ---------------------------------------------------------------------------


def _parse(value: Any):
    from datetime import datetime
    if hasattr(value, "year") and hasattr(value, "month"):
        return value
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None


def day(value: Any, locale: str = "fr") -> str:
    """"03/03/2027" is ambiguous to half the world; "3 mars 2027" is not.

    An unparseable value is printed as it arrived rather than dropped — the
    traveller can still act on "Tuesday morning" written into a source file,
    and silently omitting it would leave a blank where a fact exists.
    """
    moment = _parse(value)
    if moment is None:
        return str(value or "")
    months = _MONTHS.get(locale, _MONTHS["fr"])
    return f"{moment.day} {months[moment.month - 1]} {moment.year}"


def moment(value: Any, locale: str = "fr") -> str:
    """A date with its time, when there is one."""
    parsed = _parse(value)
    if parsed is None:
        return str(value or "")
    text = day(parsed, locale)
    if getattr(parsed, "hour", 0) or getattr(parsed, "minute", 0):
        text += f" · {parsed.hour:02d}:{parsed.minute:02d}"
    return text


def clock(value: Any) -> str:
    """Just the time, for a row whose date is already stated."""
    parsed = _parse(value)
    if parsed is None or not hasattr(parsed, "hour"):
        return str(value or "")
    return f"{parsed.hour:02d}:{parsed.minute:02d}"


def duration(start: Any, end: Any) -> str:
    """"4h50" — the number a traveller uses to decide whether to eat first.

    Empty when either end is missing or the arithmetic gives something absurd:
    a negative duration means one of the two timestamps is wrong, and printing
    "-3h" on a confirmation is worse than printing nothing.
    """
    a, b = _parse(start), _parse(end)
    if a is None or b is None:
        return ""
    try:
        minutes = int((b - a).total_seconds() // 60)
    except TypeError:
        # One side carries a timezone and the other does not; comparing them
        # raises rather than lying, and a missing duration is survivable.
        return ""
    if minutes <= 0 or minutes > 36 * 60:
        return ""
    return f"{minutes // 60}h{minutes % 60:02d}" if minutes % 60 else f"{minutes // 60}h"


def airport(code: Any) -> str:
    """"Istanbul (IST)" rather than "IST".

    Three letters are what a booking system stores and what nobody reads. The
    code stays alongside the name because that IS what is printed on the
    boarding pass and on the departure board.
    """
    text = str(code or "").strip()
    if not text:
        return ""
    try:
        from services import geo
        name = geo.place_name(text)
    except Exception:                                # data file missing
        return text
    name = str(name or "").strip()
    if not name or name.upper() == text.upper():
        return text
    return f"{name} ({text.upper()})"


# ---------------------------------------------------------------------------
# Nights become a stay
# ---------------------------------------------------------------------------


def stays(nights: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    """Turn a list of nights into the stays a human recognises.

    One entry per hotel, with the first and last night it covers. A gap in the
    dates does NOT split the stay: somebody who spends a night elsewhere in the
    middle of a trip still has one reservation at the hotel, and printing two
    check-ins would have them queue at reception twice.
    """
    by_hotel: dict[str, dict[str, Any]] = {}
    for night in nights or []:
        hotel = str(night.get("hotel") or "").strip()
        date = str(night.get("night_date") or "").strip()
        if not date:
            continue
        entry = by_hotel.setdefault(hotel, {
            "hotel": hotel, "dates": [], "room_type": "",
            "address": "", "city": "", "contact": "", "extension_nights": 0,
        })
        entry["dates"].append(date)
        if not entry["room_type"] and night.get("room_type"):
            entry["room_type"] = str(night["room_type"])
        for source, key in (("hotel_address", "address"), ("hotel_city", "city"),
                            ("hotel_contact", "contact")):
            if not entry[key] and night.get(source):
                entry[key] = str(night[source])
        if str(night.get("night_kind") or "") == "extension":
            entry["extension_nights"] += 1

    out: list[dict[str, Any]] = []
    for entry in by_hotel.values():
        dates = sorted(entry["dates"])
        out.append({
            "hotel": entry["hotel"],
            "check_in": dates[0],
            # A night dated the 3rd is slept on the 3rd, so the guest leaves on
            # the 4th. Printing the last NIGHT as the check-out date is the
            # classic off-by-one that has people turning up to an empty room.
            "check_out": _next_day(dates[-1]),
            "nights": len(set(dates)),
            "room_type": entry["room_type"],
            "address": entry["address"],
            "city": entry["city"],
            "contact": entry["contact"],
            "extension_nights": entry["extension_nights"],
        })
    return sorted(out, key=lambda s: (s["check_in"], s["hotel"]))


def _next_day(date: str) -> str:
    from datetime import date as _date, timedelta
    try:
        return (_date.fromisoformat(date[:10]) + timedelta(days=1)).isoformat()
    except (ValueError, TypeError):
        return date


# ---------------------------------------------------------------------------
# What the document says, decided before anything is drawn
# ---------------------------------------------------------------------------
#
# Split out from the drawing so the decisions — what appears, in what order,
# with what omitted — can be tested against a table of facts rather than by
# opening a PDF and squinting.


def itinerary(facts: dict[str, Any], locale: str = "fr") -> list[dict[str, Any]]:
    """The trip in the order it happens, not in the order it is stored.

    Everything else on this document is filed by category — flights here,
    transfers there — which is how an organizer thinks and the opposite of how
    a traveller reads. A traveller reads Tuesday.

    So this merges every dated thing into one chronological list: take-off,
    landing, pick-up, check-in, dinner, check-out. It invents nothing; an item
    with no date simply does not appear here and is still printed in its own
    section below.

    Returns ``[{"date", "label", "entries": [(time, text)]}]``, days in order.
    """
    words = TITLES.get(locale, TITLES["fr"])
    # (day, sort key within the day, displayed time, text)
    events: list[tuple[str, str, str, str]] = []

    def add(when: Any, text: str, when_unknown: str = "23:59"):
        """``when_unknown`` places an entry we only have a DATE for.

        A hotel check-in carries no time, and sorting it at 00:00 puts "arrive
        at the Radisson" above an 08:15 take-off — the day read backwards. So
        a check-in sorts to the end of its day and a check-out to the start,
        which is where they actually happen. Nothing is invented: no time is
        printed for either.
        """
        parsed = _parse(when)
        if parsed is None or not text:
            return
        timed = _has_time(parsed)
        events.append((
            parsed.isoformat()[:10],
            clock(parsed) if timed else when_unknown,
            clock(parsed) if timed else "",
            text,
        ))

    for flight in facts.get("flights") or []:
        number = str(flight.get("flight_number") or words["segment"])
        status = str(flight.get("status") or "").strip().lower()
        mark = f"[{words['cancelled']}] " if status.startswith("cancel") else ""
        origin = airport(flight.get("departure_airport"))
        target = airport(flight.get("arrival_airport"))
        if flight.get("departure_time"):
            add(flight["departure_time"],
                f"{mark}{words['departure']} {number}" + (f" — {origin}" if origin else ""))
        if flight.get("arrival_time"):
            add(flight["arrival_time"],
                f"{mark}{words['arrival']} {number}" + (f" — {target}" if target else ""))

    for transfer in facts.get("transfers") or []:
        route = " → ".join(
            str(p) for p in (transfer.get("pickup_location"), transfer.get("dropoff_location")) if p
        )
        add(transfer.get("pickup_time"), f"{words['pickup']} — {route}" if route else words["transfer"])

    for stay in stays(facts.get("hotel_nights") or []):
        hotel = stay["hotel"] or words["hotel"]
        # You arrive at the hotel after the day's travelling and leave before
        # it — hence the ends of the day rather than an invented hour.
        add(stay["check_in"], f"{words['checkin']} — {hotel}", when_unknown="23:59")
        add(stay["check_out"], f"{words['checkout']} — {hotel}", when_unknown="00:00")

    for activity in facts.get("activities") or []:
        name = str(activity.get("name") or "")
        where = str(activity.get("location") or "")
        add(activity.get("date_time"), f"{name}" + (f" — {where}" if where else ""))

    by_day: dict[str, list[tuple[str, str]]] = {}
    for date, _order, shown, text in sorted(events):
        by_day.setdefault(date, []).append((shown, text))

    return [
        {"date": date, "label": day(date, locale), "entries": entries}
        for date, entries in sorted(by_day.items())
    ]


def _has_time(parsed: Any) -> bool:
    return bool(getattr(parsed, "hour", 0) or getattr(parsed, "minute", 0))


def sections(facts: dict[str, Any], locale: str = "fr") -> list[dict[str, Any]]:
    """The document's content: a list of ``{"title", "blocks"}``.

    A block is either ``{"heading": str, "rows": [(label, value)]}`` — a flight,
    a stay, a transfer — or a bare ``{"rows": [...]}`` for a section that is
    just facts.
    """
    words = TITLES.get(locale, TITLES["fr"])
    out: list[dict[str, Any]] = []

    you = [
        (words[key], str(facts[field]))
        for key, field in (
            ("email", "email"), ("phone", "phone"), ("company", "company"),
            ("role", "job_title"), ("badge", "badge_name"),
            ("nationality", "nationality"),
        )
        if facts.get(field)
    ]
    if you:
        out.append({"title": words["you"], "blocks": [{"rows": you}]})

    flights = facts.get("flights") or []
    if flights:
        out.append({"title": words["flight"], "blocks": [
            _flight_block(f, words, locale) for f in flights
        ]})

    stay_list = stays(facts.get("hotel_nights") or [])
    room_facts = ("room_number", "roommate_name", "room_type")
    if stay_list or any(facts.get(f) for f in room_facts):
        blocks = [_stay_block(s, words, locale) for s in stay_list]
        room_rows = [
            (words[key], str(facts[field]))
            for key, field in (("room", "room_number"), ("roommate", "roommate_name"))
            if facts.get(field)
        ]
        # Only when no booked night already stated it — the same label twice
        # with two different values is worse than not printing it.
        if facts.get("room_type") and not any(s.get("room_type") for s in stay_list):
            room_rows.insert(0, (words["room_type"], str(facts["room_type"])))
        if room_rows:
            # Attached to the first stay when there is one: a room number
            # floating in its own block reads as a second, phantom booking.
            if blocks:
                blocks[0]["rows"].extend(room_rows)
            else:
                blocks.append({"rows": room_rows})
        out.append({"title": words["hotel"], "blocks": blocks})

    transfers = facts.get("transfers") or []
    if transfers:
        out.append({"title": words["transfer"], "blocks": [
            _transfer_block(t, words, locale) for t in transfers
        ]})

    activities = facts.get("activities") or []
    if activities:
        out.append({"title": words["activity"], "blocks": [
            _activity_block(a, words, locale) for a in activities
        ]})

    needs = [
        (words[key], str(facts[field]))
        for key, field in (("dietary", "dietary_requirements"), ("pmr", "pmr_needs"))
        if facts.get(field)
    ]
    if needs:
        out.append({"title": words["needs"], "blocks": [{"rows": needs}]})

    return out


def _flight_block(flight: dict[str, Any], words: dict[str, str], locale: str) -> dict[str, Any]:
    # Three letters are what a booking system stores and what nobody reads.
    origin, target = airport(flight.get("departure_airport")), airport(flight.get("arrival_airport"))
    route = " → ".join(p for p in (origin, target) if p)
    heading = " · ".join(
        str(p) for p in (flight.get("flight_number"), route) if p
    ) or words["segment"]

    rows: list[tuple[str, str]] = []
    if flight.get("departure_time"):
        rows.append((words["departure"], moment(flight["departure_time"], locale)))
    if flight.get("arrival_time"):
        rows.append((words["arrival"], moment(flight["arrival_time"], locale)))
    flown = duration(flight.get("departure_time"), flight.get("arrival_time"))
    if flown:
        rows.append((words["duration"], flown))
    for key, field in (("airline", "airline"), ("reference", "pnr_code"),
                       ("baggage", "baggage_info")):
        if flight.get(field):
            rows.append((words[key], str(flight[field])))

    status = str(flight.get("status") or "").strip().lower()
    if status in ("cancelled", "canceled"):
        heading = f"[{words['cancelled']}] {heading}"
    elif status == "changed":
        heading = f"[{words['changed']}] {heading}"

    return {"heading": heading, "rows": rows}


def _stay_block(stay: dict[str, Any], words: dict[str, str], locale: str) -> dict[str, Any]:
    rows: list[tuple[str, str]] = [
        (words["checkin"], day(stay["check_in"], locale)),
        (words["checkout"], day(stay["check_out"], locale)),
    ]
    nights = f"{stay['nights']} {words['nights']}"
    if stay.get("extension_nights"):
        nights += f" · {stay['extension_nights']} {words['extension']}"
    rows.append(("", nights))
    if stay.get("room_type"):
        rows.append((words["room_type"], str(stay["room_type"])))
    address = ", ".join(str(p) for p in (stay.get("address"), stay.get("city")) if p)
    if address:
        rows.append((words["address"], address))
    if stay.get("contact"):
        rows.append((words["phone"], str(stay["contact"])))
    return {"heading": stay["hotel"] or words["hotel"], "rows": rows}


def _transfer_block(transfer: dict[str, Any], words: dict[str, str], locale: str) -> dict[str, Any]:
    route = " → ".join(
        str(p) for p in (transfer.get("pickup_location"), transfer.get("dropoff_location")) if p
    )
    rows: list[tuple[str, str]] = []
    if transfer.get("pickup_time"):
        rows.append((words["pickup"], moment(transfer["pickup_time"], locale)))
    kind = _TRANSFER_KINDS.get(str(transfer.get("transfer_type") or "").strip().lower())
    if kind:
        rows.append((words["kind"], words[kind]))
    if transfer.get("vehicle_type"):
        rows.append((words["vehicle"], str(transfer["vehicle_type"])))
    return {"heading": route or words["transfer"], "rows": rows}


def _activity_block(activity: dict[str, Any], words: dict[str, str], locale: str) -> dict[str, Any]:
    rows: list[tuple[str, str]] = []
    if activity.get("date_time"):
        rows.append((words["when"], moment(activity["date_time"], locale)))
    if activity.get("location"):
        rows.append((words["where"], str(activity["location"])))
    heading = str(activity.get("name") or "")
    # A waiting list is not a booking, and somebody who turns up believing it
    # was one has been misled by their own confirmation.
    status = str(activity.get("status") or "").strip().lower()
    if status in ("waitlisted", "waiting_list", "waitlist"):
        heading = f"[{words['waitlisted']}] {heading}"
    elif status == "cancelled":
        heading = f"[{words['cancelled']}] {heading}"
    return {"heading": heading, "rows": rows}


# transfers.transfer_type -> the word for it. Anything else is left unlabelled
# rather than guessed: "other" tells the traveller nothing they cannot see.
_TRANSFER_KINDS = {"arrival": "arrival_leg", "departure": "departure_leg",
                   "activity": "activity_leg"}


# ---------------------------------------------------------------------------
# Drawing
# ---------------------------------------------------------------------------


def build(
    facts: dict[str, Any],
    locale: str = "fr",
    organiser: str = "",
    generated_on: Any = None,
) -> bytes:
    """Render the confirmation. Returns PDF bytes.

    ``generated_on`` is passed in rather than read from the clock here, so the
    same facts always render the same bytes and a test can assert on them.

    Raises ``PdfUnavailable`` when PyMuPDF is missing, so the caller can offer
    the email version rather than returning a broken download.
    """
    try:
        import pymupdf as fitz
    except ImportError:                               # pragma: no cover
        try:
            import fitz                               # older PyMuPDF
        except ImportError as exc:
            raise PdfUnavailable("PyMuPDF is not installed on this deployment.") from exc

    words = TITLES.get(locale, TITLES["fr"])
    doc = fitz.open()
    page = doc.new_page(width=PAGE_WIDTH, height=PAGE_HEIGHT)
    cursor = [MARGIN + 24]

    def new_page():
        nonlocal page
        page = doc.new_page(width=PAGE_WIDTH, height=PAGE_HEIGHT)
        cursor[0] = MARGIN

    def write(text: str, size: float = 10.5, bold: bool = False, gap: float = 6,
              x: float = MARGIN, grey: bool = False):
        if cursor[0] + size + gap > BOTTOM:
            new_page()
        page.insert_text(
            (x, cursor[0]), _latin(text),
            fontname=FONT_BOLD if bold else FONT, fontsize=size,
            color=(0.42, 0.42, 0.42) if grey else (0, 0, 0),
        )
        cursor[0] += size + gap

    def row(label: str, value: str, size: float = 10.5):
        """A label/value line, both drawn at the same baseline."""
        if cursor[0] + size + 4 > BOTTOM:
            new_page()
        if label:
            page.insert_text((MARGIN + 12, cursor[0]), _latin(label),
                             fontname=FONT, fontsize=size, color=(0.42, 0.42, 0.42))
        page.insert_text((VALUE_X, cursor[0]), _latin(value),
                         fontname=FONT, fontsize=size)
        cursor[0] += size + 4

    def rule(gap: float = 12):
        if cursor[0] + gap > BOTTOM:
            new_page()
        page.draw_line(
            fitz.Point(MARGIN, cursor[0]),
            fitz.Point(PAGE_WIDTH - MARGIN, cursor[0]),
            color=(0.82, 0.82, 0.82), width=0.6,
        )
        cursor[0] += gap

    write(words["document"], size=19, bold=True, gap=14)

    if facts.get("participant_name"):
        write(str(facts["participant_name"]), size=13.5, bold=True, gap=4)
    if facts.get("event_name"):
        write(str(facts["event_name"]), size=11.5, gap=2)

    where_when = "  ·  ".join(str(x) for x in (
        facts.get("event_location"),
        _date_range(facts.get("event_start_date"), facts.get("event_end_date"), locale),
    ) if x)
    if where_when:
        write(where_when, size=10, gap=10, grey=True)

    rule()

    # The trip in the order it happens. Everything below is filed by category,
    # which is how an organizer thinks; a traveller reads Tuesday.
    days = itinerary(facts, locale)
    if len(days) > 1:
        write(words["itinerary"], size=12, bold=True, gap=6)
        for entry in days:
            write(f"  {entry['label']}", size=10.5, bold=True, gap=5)
            for time, text in entry["entries"]:
                row(time, text)
            cursor[0] += 4
        cursor[0] += 4
        rule()

    for section in sections(facts, locale):
        write(section["title"], size=12, bold=True, gap=6)
        for block in section["blocks"]:
            if block.get("heading"):
                write(f"  {block['heading']}", size=10.5, bold=True, gap=5)
            for label, value in block["rows"]:
                row(label, value)
            cursor[0] += 4
        cursor[0] += 4

    if organiser:
        rule()
        write(words["contact"], size=12, bold=True, gap=6)
        for line in str(organiser).splitlines():
            if line.strip():
                write(f"   {line.strip()}", size=10.5, gap=4)

    cursor[0] += 8
    stamp = day(generated_on, locale) if generated_on else ""
    footer = words["footer"]
    if stamp:
        footer = f"{words['generated']} {stamp}. {footer}"
    write(footer, size=8, gap=0, grey=True)

    # Page numbers last, once the total is known. A confirmation that spills
    # onto a second page is one somebody can hand over half of without
    # noticing.
    total = doc.page_count
    if total > 1:
        for index, sheet in enumerate(doc, start=1):
            sheet.insert_text(
                (PAGE_WIDTH - MARGIN - 60, PAGE_HEIGHT - 40),
                f"{words['page']} {index}/{total}",
                fontname=FONT, fontsize=8, color=(0.42, 0.42, 0.42),
            )

    data = doc.tobytes()
    doc.close()
    return data


def _date_range(start: Any, end: Any, locale: str = "fr") -> str:
    """A dash, not an arrow. "1 mars > 5 mars" reads as a route; the event does
    not travel from one date to another, it lasts from one to the other."""
    left, right = day(start, locale), day(end, locale)
    if left and right and left != right:
        return f"{left} – {right}"
    return left or right


# Typography Helvetica cannot draw, and what to draw instead. Without this the
# arrow in "BRU → IST" is silently dropped and the route reads "BRU IST", which
# says nothing about which way the person is flying.
_SUBSTITUTES = str.maketrans({
    "→": ">", "←": "<", "⇒": "=>",
    "–": "-", "—": "-", "−": "-",
    "‘": "'", "’": "'", "“": '"', "”": '"',
    "…": "...", "•": "-", " ": " ", " ": " ",
    "⁄": "/", "′": "'", "″": '"',
})


def _latin(text: str) -> str:
    """What the base-14 fonts can actually draw.

    Helvetica is Latin-1 only. A Turkish or Greek name would otherwise render as
    a row of blank boxes on a document somebody carries through an airport, so
    unrepresentable characters are transliterated where possible and dropped
    where not — a name missing a diacritic is still recognisably the name.

    Punctuation is substituted rather than folded, because folding an arrow
    leaves nothing at all: NFKD has no Latin-1 equivalent for "→", and the
    route it separated silently becomes two airport codes side by side.
    """
    text = text.translate(_SUBSTITUTES)
    try:
        text.encode("latin-1")
        return text
    except UnicodeEncodeError:
        stripped = unicodedata.normalize("NFKD", text)
        return "".join(ch for ch in stripped if ord(ch) < 256).strip() or "?"


# ---------------------------------------------------------------------------
# Naming the file
# ---------------------------------------------------------------------------


def _ascii(text: str) -> str:
    """Accents folded, everything else dropped.

    A Content-Disposition header is ASCII; a raw "Bénédicte" in it is either
    mangled or rejected depending on the browser. The accented form still
    travels, in the RFC 5987 ``filename*`` the caller sends alongside.
    """
    folded = unicodedata.normalize("NFKD", str(text or ""))
    return "".join(ch for ch in folded if not unicodedata.combining(ch))


def filename_for(facts: dict[str, Any], locale: str = "fr") -> str:
    """The person first — it is their document, and it lands in a folder next
    to nineteen others named after the same event.

    ``Confirmation_Sophie_Marceau_Sales_Convention_2027.pdf``, not
    ``confirmation.pdf``: somebody handling forty participants downloads forty
    of these, and a filename that starts with the event sorts them into one
    indistinguishable block.
    """
    name = _ascii(facts.get("participant_name") or "").strip()
    event = _ascii(facts.get("event_name") or "").strip()
    parts = [p for p in ("Confirmation", name, event) if p]
    raw = "_".join(parts)
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", raw).strip("_") or "Confirmation"
    return f"{re.sub(r'_+', '_', safe)[:110]}.pdf"


def content_disposition(facts: dict[str, Any]) -> str:
    """The header value, with both spellings of the name.

    ``filename`` is the ASCII fallback every client understands; ``filename*``
    carries the real one, accents included, for every client made this century.
    """
    from urllib.parse import quote

    ascii_name = filename_for(facts)
    real_name = re.sub(
        r"[^\w.\- ]+", "_",
        f"Confirmation_{facts.get('participant_name') or ''}_"
        f"{facts.get('event_name') or ''}".strip("_"),
        flags=re.UNICODE,
    ).strip("_ ") or "Confirmation"
    real_name = re.sub(r"\s+", "_", real_name)[:110] + ".pdf"
    return (
        f'attachment; filename="{ascii_name}"; '
        f"filename*=UTF-8''{quote(real_name, safe='')}"
    )
