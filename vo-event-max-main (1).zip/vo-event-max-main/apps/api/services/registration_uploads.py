"""
services/registration_uploads.py — Accepting a file from a stranger.

The registration form asks for a passport copy and a photo, which means an
endpoint that takes a file from somebody with no account, no session and no
prior relationship with us. That is the least trusted input the system has, and
almost everything in this module is a refusal.

The rules, and why each one is here:

  * **A short allowlist of kinds.** A passport scan and a photo. Not "any
    document": a field that accepts anything is a field somebody uses as free
    hosting.
  * **Extension AND content must agree.** A .jpg whose bytes say
    ``<!DOCTYPE html`` is not a photo, whatever the browser labelled it.
    Checking only the extension is checking the attacker's own claim.
  * **No archives, no documents that execute.** PDF, JPEG, PNG, HEIC, and
    nothing else. A .docx is a zip, and a zip is a thing that unpacks.
  * **A cap small enough to be boring.** Eight megabytes holds any passport
    scan a phone produces and does not hold a film.
  * **The visitor's filename never becomes a path.** It is kept as a label and
    replaced by a generated name on disk.

Pure module: bytes in, a verdict out. It touches no storage and no database, so
every rule above is a line in a test rather than an incident.
"""

from __future__ import annotations

import logging
import os
import re
import unicodedata
import uuid
from typing import Any

logger = logging.getLogger(__name__)

PASSPORT = "passport_scan"
PHOTO = "photo"

# What the form may ask for. Deliberately two: §9 lists a passport and a photo,
# and "other" is how an upload field becomes a filing cabinet.
KINDS: tuple[str, ...] = (PASSPORT, PHOTO)

LABELS: dict[str, dict[str, str]] = {
    PASSPORT: {
        "fr": "Copie du passeport", "nl": "Kopie van het paspoort",
        "en": "Passport copy",
    },
    PHOTO: {
        "fr": "Photo d'identité", "nl": "Pasfoto", "en": "Identity photo",
    },
}

# Eight megabytes: any passport scan a phone produces, and no film. The upload
# endpoint reads the body into memory, so this is also what stops one visitor
# from occupying the process.
MAX_BYTES = 8 * 1024 * 1024

# Per kind, the extensions allowed. A passport may be scanned to PDF; a photo
# may not — a "photo" that is a PDF is a document somebody has misfiled, and
# the badge printer will not thank anybody.
ALLOWED: dict[str, frozenset[str]] = {
    PASSPORT: frozenset({".pdf", ".jpg", ".jpeg", ".png", ".heic"}),
    PHOTO: frozenset({".jpg", ".jpeg", ".png", ".heic"}),
}

# First bytes -> what the file actually is. Checking the extension alone is
# checking the uploader's own claim about their own file.
_MAGIC: tuple[tuple[bytes, str], ...] = (
    (b"%PDF-", "pdf"),
    (b"\xff\xd8\xff", "jpeg"),
    (b"\x89PNG\r\n\x1a\n", "png"),
)

_EXTENSION_TYPES: dict[str, str] = {
    ".pdf": "pdf", ".jpg": "jpeg", ".jpeg": "jpeg", ".png": "png", ".heic": "heic",
}

_CONTENT_TYPES: dict[str, str] = {
    "pdf": "application/pdf", "jpeg": "image/jpeg",
    "png": "image/png", "heic": "image/heic",
}


class UploadRefused(ValueError):
    """The file cannot be accepted. The message is shown to the visitor."""


def label(kind: str, locale: str = "fr") -> str:
    entry = LABELS.get(kind, {})
    return entry.get(locale) or entry.get("fr") or kind


def sniff(content: bytes) -> str:
    """What the bytes say the file is, or "" when they say nothing known.

    HEIC is the deliberate gap: its magic sits at offset 4 behind a length
    prefix, and every phone in the room produces it. It is allowed through on
    its extension alone, which is acceptable precisely because the container
    formats we refuse — zip, html, scripts — all announce themselves in the
    first bytes and are caught below.
    """
    head = content[:16] if content else b""
    for prefix, name in _MAGIC:
        if head.startswith(prefix):
            return name
    if len(head) >= 12 and head[4:8] == b"ftyp":
        return "heic"
    return ""


def _looks_dangerous(content: bytes) -> bool:
    """Bytes that are certainly not a passport scan.

    Not an attempt at antivirus. It catches the specific case that matters: a
    file that is really markup or an archive, uploaded under an image name, in
    the hope that something downstream serves it back.
    """
    head = content[:512].lstrip()[:64].lower()
    return (
        head.startswith(b"<!doctype") or head.startswith(b"<html")
        or head.startswith(b"<?xml") or head.startswith(b"<svg")
        or head.startswith(b"pk\x03\x04")          # zip, and therefore docx/xlsx
        or head.startswith(b"#!")                  # a script
        or head.startswith(b"mz")                  # a Windows executable
    )


def safe_label(filename: str) -> str:
    """The visitor's own filename, kept only as something to show them.

    Never used as a path. Accents folded, everything unusual replaced, length
    bounded — a name is a label here, and a label cannot traverse a directory.
    """
    base = os.path.basename(str(filename or "")).replace("\\", "_").replace("/", "_")
    folded = unicodedata.normalize("NFKD", base)
    ascii_only = "".join(c for c in folded if not unicodedata.combining(c))
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", ascii_only).strip("._") or "fichier"
    return cleaned[:100]


def validate(
    kind: str,
    filename: str,
    content: bytes,
    declared_type: str = "",
) -> dict[str, Any]:
    """Accept the file, or refuse it with a reason the visitor can act on.

    Returns a descriptor: the kind, a safe label, the detected type, the size,
    and the content type to store it under — ours, not the browser's.
    """
    if kind not in KINDS:
        raise UploadRefused("Type de document non accepté.")

    size = len(content or b"")
    if size == 0:
        raise UploadRefused("Le fichier est vide.")
    if size > MAX_BYTES:
        raise UploadRefused(
            f"Le fichier dépasse {MAX_BYTES // (1024 * 1024)} Mo. "
            "Réduisez la qualité du scan et réessayez."
        )

    extension = os.path.splitext(str(filename or ""))[1].lower()
    if extension not in ALLOWED[kind]:
        allowed = ", ".join(sorted(ALLOWED[kind]))
        raise UploadRefused(f"Format non accepté. Formats acceptés : {allowed}.")

    if _looks_dangerous(content):
        # Refused on what it IS, not on what it was called.
        raise UploadRefused("Ce fichier n'est pas une image ou un PDF valide.")

    detected = sniff(content)
    expected = _EXTENSION_TYPES[extension]
    if detected and detected != expected:
        raise UploadRefused("Le contenu du fichier ne correspond pas à son extension.")
    if not detected and expected != "heic":
        raise UploadRefused("Ce fichier n'est pas une image ou un PDF valide.")

    return {
        "kind": kind,
        "filename": safe_label(filename),
        "detected_type": detected or expected,
        # Ours, never the browser's: a client controls the Content-Type header
        # it sends, and that header decides how anything downstream renders it.
        "content_type": _CONTENT_TYPES[expected],
        "byte_size": size,
        "extension": extension,
    }


def storage_path(event_id: str, descriptor: dict[str, Any]) -> str:
    """Where the file goes. Server-generated, start to finish.

    The visitor contributes nothing to this string — not the directory, not the
    name, not the extension. Their filename survives only in the database, as a
    label.
    """
    return f"{event_id}/registrations/{uuid.uuid4()}{descriptor['extension']}"


def requested(resolved_fields: Any) -> list[dict[str, Any]]:
    """The attachments this event asks for, from its form configuration.

    Reads the same resolved catalogue the rest of the form does, so enabling a
    passport copy is the same gesture as enabling a phone number.
    """
    out: list[dict[str, Any]] = []
    for field in resolved_fields or []:
        if not isinstance(field, dict):
            continue
        key = field.get("key")
        if key in KINDS and field.get("enabled"):
            out.append({
                "kind": key,
                "label": label(key),
                "required": bool(field.get("required")),
                "accept": sorted(ALLOWED[key]),
                "max_bytes": MAX_BYTES,
            })
    return out


def missing_required(requested_kinds: list[dict[str, Any]], provided: Any) -> list[str]:
    """Which required attachments were not supplied.

    Enforced on the server for the same reason every other required field is:
    this endpoint takes JSON from the open internet, and the form's own
    ``required`` attribute proves nothing about what arrived.
    """
    given = {
        str(item.get("kind"))
        for item in (provided or [])
        if isinstance(item, dict) and item.get("kind")
    }
    return [
        entry["label"] for entry in requested_kinds
        if entry.get("required") and entry["kind"] not in given
    ]
