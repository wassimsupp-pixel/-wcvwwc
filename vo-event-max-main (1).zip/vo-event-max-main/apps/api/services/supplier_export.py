"""
services/supplier_export.py — What each supplier is allowed to receive.

The master list carries around seventy columns, passport numbers, dietary
requirements and medical information among them. A transfer company that asks
for a passenger manifest currently receives all of it (feedback §6).

That is the wrong default in two directions at once. It is a data-protection
problem — a coach operator has no business holding somebody's epilepsy — and it
is also simply unusable: nobody wants to find the pickup time in column
fifty-three.

So each supplier gets a **fixed, server-side list of columns**, and the
sensitive ones are not merely absent from those lists — they are denied
outright, by a check that runs over every profile including the custom one.
The difference matters: an absent column is a decision somebody can undo by
editing a list, and a denied one cannot be reintroduced by accident.

The internal master-list export is untouched and remains what it always was.
This is the path for anything leaving the company.
"""

from __future__ import annotations

import logging
from typing import Any, Iterable, Optional

logger = logging.getLogger(__name__)

HOTEL = "hotel"
TRANSFER = "transfer"
ACTIVITY = "activity"
FLIGHT = "flight"
CUSTOM = "custom"

# Columns that may never leave the company, whatever profile asks for them.
#
# This is a denial, not an omission. Every profile below is checked against it
# at import time, and a custom selection is filtered through it — so adding a
# column to a profile cannot silently start shipping passport numbers, and
# neither can an organizer ticking a box.
SENSITIVE_KEYS: frozenset[str] = frozenset({
    "passport_number", "passport_expiry", "passport_country",
    "date_of_birth", "birth_place",
    "medical_info", "dietary_requirements", "food_allergy_info",
    "pmr_needs",
    "emergency_contact_name", "emergency_contact_phone", "emergency_contact_country",
    "address", "postal_code", "city", "country",
    "company_vat", "company_address", "company_postal_code", "company_city",
    "remarks", "comments", "special_requests", "internal_notes",
    "dq_missing_fields", "dq_open_exceptions", "dq_action_needed",
})

# profile -> ordered (column label, master-row key)
#
# Taken from the feedback's own lists, section by section. Where it names a
# column we do not compute yet (a room number), the entry is present and comes
# back empty rather than being dropped: a supplier reading a familiar sheet
# with a blank column asks about it, and one reading a sheet missing a column
# does not notice.
_PROFILES: dict[str, tuple[tuple[str, str], ...]] = {
    HOTEL: (
        ("Nom", "last_name"),
        ("Prénom", "first_name"),
        ("Hôtel", "hotel_name"),
        ("Check-in", "hotel_checkin"),
        ("Check-out", "hotel_checkout"),
        ("Nuitées", "hotel_nights_count"),
        ("Type de chambre", "hotel_room_type"),
        ("Roommate", "roommate_name"),
        ("N° de chambre", "room_number"),
        ("Remarque hébergement", "accommodation_note"),
    ),
    TRANSFER: (
        ("Nom", "last_name"),
        ("Prénom", "first_name"),
        ("N° de vol", "outbound_flight_number"),
        ("Heure d'arrivée", "outbound_arrival_time"),
        ("N° de vol retour", "return_flight_number"),
        ("Heure de départ", "return_departure_time"),
        ("Transfert assigné", "transfer_arrival_vehicle"),
        ("Heure de prise en charge", "transfer_arrival_time"),
        ("Trajet", "transfer_arrival_route"),
    ),
    ACTIVITY: (
        ("Nom", "last_name"),
        ("Prénom", "first_name"),
        ("Activité", "activity_1"),
        ("Horaire", "activity_1_time"),
        ("Lieu", "activity_1_location"),
        ("Statut", "activity_1_status"),
    ),
    FLIGHT: (
        ("Nom", "last_name"),
        ("Prénom", "first_name"),
        ("Compagnie aller", "outbound_airline"),
        ("N° vol aller", "outbound_flight_number"),
        ("Départ aller", "outbound_departure_airport"),
        ("Arrivée aller", "outbound_arrival_airport"),
        ("Heure départ aller", "outbound_departure_time"),
        ("Heure arrivée aller", "outbound_arrival_time"),
        ("Compagnie retour", "return_airline"),
        ("N° vol retour", "return_flight_number"),
        ("Départ retour", "return_departure_airport"),
        ("Arrivée retour", "return_arrival_airport"),
        ("Heure départ retour", "return_departure_time"),
        ("Heure arrivée retour", "return_arrival_time"),
    ),
}

# Everything a custom export may offer: the union of the fixed profiles plus a
# few operational columns that are safe to share and often asked for. Bounded
# on purpose — "choose your columns" from the whole master list would put the
# denial one careless tick away from being pointless.
_CUSTOM_CATALOGUE: tuple[tuple[str, str], ...] = tuple(
    dict(
        [(key, label) for cols in _PROFILES.values() for label, key in cols]
        + [
            ("company", "Entreprise"),
            ("email", "Email"),
            ("phone", "Téléphone"),
            ("badge_name", "Nom sur badge"),
            ("shirt_size", "Taille"),
            ("job_title", "Fonction"),
            ("nationality", "Nationalité"),
            ("hotel_nights_count", "Nuitées"),
        ]
    ).items()
)

PROFILE_LABELS = {
    HOTEL: "Hôtel",
    TRANSFER: "Société de transfert",
    ACTIVITY: "Activités",
    FLIGHT: "Vols",
    CUSTOM: "Export personnalisé",
}


class SensitiveColumnError(RuntimeError):
    """A profile tried to ship something that may not leave the company."""


def _assert_safe(profile: str, keys: Iterable[str]) -> None:
    leaked = sorted(set(keys) & SENSITIVE_KEYS)
    if leaked:
        raise SensitiveColumnError(
            f"Le profil « {profile} » exposerait des données sensibles : {', '.join(leaked)}."
        )


# Checked once, at import. A column added to a profile in a hurry fails the
# process rather than one participant's medical information.
for _name, _cols in _PROFILES.items():
    _assert_safe(_name, [key for _label, key in _cols])
_assert_safe(CUSTOM, [key for key, _label in _CUSTOM_CATALOGUE])


def available_profiles() -> list[dict[str, Any]]:
    """What the export screen offers, with the columns each one sends.

    The columns are part of the answer on purpose: an organizer about to email
    a coach company should be able to see exactly what is in the file before
    it leaves, not after.
    """
    out = [
        {
            "profile": name,
            "label": PROFILE_LABELS[name],
            "columns": [label for label, _key in _PROFILES[name]],
        }
        for name in (HOTEL, TRANSFER, ACTIVITY, FLIGHT)
    ]
    out.append({
        "profile": CUSTOM,
        "label": PROFILE_LABELS[CUSTOM],
        "columns": [],
        "choices": [{"key": key, "label": label} for key, label in _CUSTOM_CATALOGUE],
    })
    return out


def columns_for(profile: str, chosen: Optional[list[str]] = None) -> list[tuple[str, str]]:
    """The (label, key) pairs a given export will write.

    For a custom export, ``chosen`` is filtered against the catalogue: an
    unknown key is dropped and a sensitive one can never get through, whatever
    the caller sent. An empty selection falls back to name and surname, so the
    file is never a sheet of blank rows.
    """
    if profile in _PROFILES:
        return list(_PROFILES[profile])
    if profile != CUSTOM:
        raise ValueError(f"Profil d'export inconnu : {profile}")

    catalogue = dict(_CUSTOM_CATALOGUE)
    picked = [
        (catalogue[key], key)
        for key in (chosen or [])
        if key in catalogue and key not in SENSITIVE_KEYS
    ]
    if not picked:
        picked = [("Nom", "last_name"), ("Prénom", "first_name")]
    _assert_safe(CUSTOM, [key for _label, key in picked])
    return picked


def enrich(
    profile: str,
    master_rows: list[dict[str, Any]],
    room_lines: Optional[list[dict[str, Any]]] = None,
    notes: Optional[list[dict[str, Any]]] = None,
) -> list[dict[str, Any]]:
    """Fill the columns a profile promises but the master row does not carry.

    Two of them exist because the feedback names them: the hotel sheet's room
    number and its accommodation remark. Both come from elsewhere — the rooming
    view and the notes table — and both stay empty rather than absent when
    there is nothing to put in them.

    Notes are filtered by ``note_service.for_export``, which requires the note
    to be flagged AND its category to point at this exact profile. A general
    remark has no destination and reaches no supplier, whatever it says.
    """
    from services import note_service

    by_participant = {
        line["participant_id"]: line for line in (room_lines or []) if line.get("participant_id")
    }
    shared_notes = note_service.for_export(notes or [], profile)

    enriched: list[dict[str, Any]] = []
    for row in master_rows:
        pid = row.get("participant_id") or row.get("id")
        extra = dict(row)
        line = by_participant.get(pid)
        if line:
            extra.setdefault("room_number", line.get("room_number") or "")
            if not str(extra.get("roommate_name") or "").strip():
                extra["roommate_name"] = line.get("roommate") or ""
        if pid in shared_notes:
            extra["accommodation_note"] = shared_notes[pid]
        enriched.append(extra)
    return enriched


def build_rows(
    profile: str,
    master_rows: list[dict[str, Any]],
    chosen: Optional[list[str]] = None,
) -> tuple[list[str], list[list[Any]]]:
    """Headers and values for a supplier file.

    Reads the master rows the internal export already builds, and takes only
    the agreed columns out of them. A key the master row does not carry yields
    an empty cell rather than an error: the sheet's shape is a promise to the
    supplier, and it should not change because one event has no activities.
    """
    columns = columns_for(profile, chosen)
    headers = [label for label, _key in columns]
    values = [
        [_cell(row.get(key)) for _label, key in columns]
        for row in master_rows
    ]
    return headers, values


def _cell(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "Oui" if value else "Non"
    return value


# The prefixes `filename_for` produces. Kept next to it so the two cannot
# drift apart.
_FILENAME_PREFIXES: frozenset[str] = frozenset(
    {"hotel", "transferts", "activites", "vols", "personnalise"}
)


def is_supplier_file(filename: str) -> bool:
    """True when this export came from a supplier profile rather than the
    master list.

    The download endpoint regenerates an export for any role below admin/pm,
    because a stored MASTER LIST has dietary and medical columns baked in from
    whoever created it. A supplier file has no such columns by construction —
    they are denied outright, not merely omitted — so regenerating it is not a
    safety measure, it is a substitution: the caller asks for the hotel's ten
    columns and receives a seventy-column master list instead.

    Read from the filename because that is the only thing telling the two
    apart today. Adding an explicit ``profile`` column would be sturdier and
    is worth doing whenever ``exports`` next needs a migration.
    """
    head = str(filename or "").split("_", 1)[0].strip().lower()
    return head in _FILENAME_PREFIXES


def filename_for(profile: str, event_slug: str, day: str) -> str:
    """A name that says what it is once it is sitting in somebody's Downloads
    folder next to a dozen others."""
    label = {
        HOTEL: "hotel", TRANSFER: "transferts", ACTIVITY: "activites",
        FLIGHT: "vols", CUSTOM: "personnalise",
    }.get(profile, profile)
    return f"{label}_{event_slug}_{day}.xlsx"
