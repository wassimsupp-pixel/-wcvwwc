"""
services/registration_form.py — Which questions the public registration form
asks, per event.

The form used to ask every participant the same twenty questions regardless of
the event, so an organizer running a one-day city conference still made people
type a passport number and an emergency contact. This module is the single
catalogue of what CAN be asked; each event stores which of those it DOES ask
and which answers it insists on.

Two rules shape it:

  * **Identity is not optional.** first_name, last_name and email are what the
    consolidation engine matches people on — a submission without them cannot
    be merged with anything and would land as an orphan row. They are marked
    ``locked`` and no configuration can switch them off.
  * **An unknown key is dropped, never stored.** The config is written by an
    authenticated organizer, but it ends up driving a public page, so it is
    filtered against this catalogue on the way in rather than trusted on the
    way out.

An event with no stored configuration (including every event that predates
this feature, and any deployment where migration 007 has not been applied yet)
resolves to "every field shown, nothing extra required" — exactly the form's
behaviour before it became configurable.
"""

from __future__ import annotations

from typing import Any, Optional

# key, French label, section, locked. Order is the order of the form.
_CATALOGUE: tuple[tuple[str, str, str, bool], ...] = (
    ("first_name", "Prénom", "Identité", True),
    ("last_name", "Nom", "Identité", True),
    ("email", "Adresse email", "Identité", True),
    ("civility", "Civilité", "Identité", False),
    ("company", "Société", "Identité", False),
    ("phone", "Téléphone", "Identité", False),
    ("nationality", "Nationalité", "Identité", False),
    ("date_of_birth", "Date de naissance", "Identité", False),
    ("birth_place", "Lieu de naissance", "Identité", False),
    ("job_title", "Fonction / Poste", "Identité", False),
    ("badge_name", "Nom sur badge", "Identité", False),
    # Attachments (§9). Off by default: an event that does not need a passport
    # scan must not ask three hundred people for one, and a document nobody
    # asked for is a document somebody has to store and delete.
    ("passport_scan", "Copie du passeport", "Voyage", False),
    ("photo", "Photo d'identité", "Identité", False),
    ("language", "Langue préférée", "Identité", False),
    # Private address. Asked for by the reference form MAX already runs, where
    # it feeds travel insurance and anything posted to the participant.
    ("address", "Adresse privée", "Adresse", False),
    ("postal_code", "Code postal", "Adresse", False),
    ("city", "Ville", "Adresse", False),
    ("country", "Pays", "Adresse", False),
    # Company block. `company` alone was never enough for an incentive trip
    # billed to the employer: MAX's own form asks for the VAT number and the
    # registered address.
    ("company_vat", "Numéro de TVA", "Société", False),
    ("company_address", "Adresse de la société", "Société", False),
    ("company_postal_code", "Code postal (société)", "Société", False),
    ("company_city", "Commune (société)", "Société", False),
    ("passport_number", "Numéro de passeport", "Voyage", False),
    ("passport_expiry", "Expiration du passeport", "Voyage", False),
    ("passport_country", "Pays du passeport", "Voyage", False),
    # Travel. These are what makes the transfer dispatcher (§1) able to work
    # from registrations alone, before any FCM export arrives.
    ("transfer_needed", "Besoin d'un transfert ?", "Voyage", False),
    ("arrival_flight", "Vol d'arrivée", "Voyage", False),
    ("arrival_airport", "Aéroport d'arrivée", "Voyage", False),
    ("departure_flight", "Vol de retour", "Voyage", False),
    ("dietary_requirements", "Régime alimentaire", "Séjour", False),
    ("food_allergy_info", "Allergies", "Séjour", False),
    # Rooming. `room_type` and `roommate` are canonical fields, so an answer
    # here flows straight into the pairing step — asking the question at the
    # source is the whole point of §4, rather than reconstructing it later
    # from a rooming list.
    ("room_type", "Type de chambre", "Séjour", False),
    ("roommate", "Avec qui souhaitez-vous partager votre chambre ?", "Séjour", False),
    ("room_preference", "Préférences de chambre", "Séjour", False),
    # Personal extension (§3), captured at the source rather than inferred
    # from a flight date that nobody explained.
    ("extension_requested", "Souhaitez-vous prolonger votre séjour à vos frais ?", "Séjour", False),
    ("extension_start", "Début de l'extension", "Séjour", False),
    ("extension_end", "Fin de l'extension", "Séjour", False),
    ("extension_hotel", "Hôtel pendant l'extension", "Séjour", False),
    ("pmr_needs", "Besoins d'accessibilité (PMR)", "Séjour", False),
    ("shirt_size", "Taille de t-shirt", "Séjour", False),
    ("activity_preferences", "Activités souhaitées", "Séjour", False),
    ("emergency_contact_name", "Nom du contact d'urgence", "Contact d'urgence", False),
    ("emergency_contact_phone", "Téléphone du contact d'urgence", "Contact d'urgence", False),
    ("emergency_contact_country", "Pays du contact d'urgence", "Contact d'urgence", False),
    ("special_requests", "Demandes spéciales", "Divers", False),
    ("remarks", "Remarques", "Divers", False),
)

FIELD_KEYS: tuple[str, ...] = tuple(key for key, _, _, _ in _CATALOGUE)
LOCKED_KEYS: frozenset[str] = frozenset(key for key, _, _, locked in _CATALOGUE if locked)

# A field naming more badges than exist is a config error, not a use case —
# capped so a hand-edited console entry cannot bloat the stored config.
_MAX_BADGES = 20
_BADGE_NAME_MAX = 40
_BADGE_ID_MAX = 40


def resolve(stored: Any, badge: Optional[str] = None) -> list[dict[str, Any]]:
    """The catalogue with each event's choices applied, in the event's own
    order, filtered to one badge if given (point 13, v1 of a multi-pass
    feature — see the module note below).

    ``stored`` is whatever sits in ``events.registration_fields`` — including
    None, a stale shape from an older version, or something hand-edited in the
    Supabase console. Anything unrecognised falls back to the default for that
    field rather than failing: a broken config must not take the public form
    down with it.

    ``badge`` narrows the result to fields that badge may see. A field with no
    ``badges`` list (or an empty one) is visible to every badge — the safe
    default, so introducing badges on an event never silently hides a
    question nobody re-configured. Locked identity fields ignore badge
    filtering entirely: every badge needs a name and an email or the
    submission cannot be matched to anyone.
    """
    config = stored if isinstance(stored, dict) else {}
    catalogue_by_key = {key: (label, group, locked) for key, label, group, locked in _CATALOGUE}

    out: list[dict[str, Any]] = []
    for key in _field_order(config):
        catalogue_entry = catalogue_by_key.get(key)
        if not catalogue_entry:
            continue
        label, group, locked = catalogue_entry
        entry = config.get(key)
        entry = entry if isinstance(entry, dict) else {}
        enabled = bool(entry.get("enabled", True))
        required = bool(entry.get("required", False))
        badges = _clean_badge_list(entry.get("badges"))
        if locked:
            enabled, required, badges = True, True, []
        if badge and badges and badge not in badges:
            continue
        out.append({
            "key": key, "label": label, "group": group,
            "locked": locked, "enabled": enabled, "required": required,
            "badges": badges,
        })
    return out


def _field_order(config: dict[str, Any]) -> list[str]:
    """The catalogue's own keys, in the event's custom order if it set one.

    ``config["_order"]`` is a list of keys the organizer arranged by hand
    (point 13, v1). Anything it names that the catalogue does not recognise
    is dropped silently — the same "unknown key, never trusted" rule
    everything else in this module already follows. Anything the catalogue
    HAS that the order list left out is appended at the end, in catalogue
    order, so a field can never vanish from the form just because an older
    saved order predates it.
    """
    raw_order = config.get("_order")
    if not isinstance(raw_order, list):
        return list(FIELD_KEYS)
    ordered = [k for k in raw_order if isinstance(k, str) and k in FIELD_KEYS]
    seen = set(ordered)
    ordered.extend(k for k in FIELD_KEYS if k not in seen)
    return ordered


def _clean_badge_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return sorted({str(v).strip() for v in value if str(v or "").strip()})[:_MAX_BADGES]


def sanitize(payload: Any) -> dict[str, Any]:
    """The configuration as it may be stored: known keys only, booleans only,
    identity fields forced on. A field that is not shown cannot be required —
    that combination would make the form impossible to submit.

    ``badges`` per field and the top-level ``_order`` (point 13, v1) go
    through the same known-keys-only discipline as everything else here: the
    config is written by an authenticated organizer but drives a public page,
    so nothing reaches storage that was not deliberately set.
    """
    incoming = payload if isinstance(payload, dict) else {}
    clean: dict[str, Any] = {}
    for key, _label, _group, locked in _CATALOGUE:
        entry = incoming.get(key)
        entry = entry if isinstance(entry, dict) else {}
        enabled = True if locked else bool(entry.get("enabled", True))
        required = True if locked else bool(entry.get("required", False)) and enabled
        clean[key] = {
            "enabled": enabled, "required": required,
            "badges": [] if locked else _clean_badge_list(entry.get("badges")),
        }
    order = incoming.get("_order")
    if isinstance(order, list):
        clean["_order"] = [k for k in order if isinstance(k, str) and k in FIELD_KEYS][:len(FIELD_KEYS)]
    return clean


def missing_required(resolved: list[dict[str, Any]], submitted: dict[str, Any]) -> list[str]:
    """Labels of the required fields a submission left empty.

    Checked server-side because the browser's own ``required`` attribute is a
    convenience, not a guarantee: the endpoint is public and takes JSON.
    """
    missing = []
    for field in resolved:
        if not field["required"] or not field["enabled"]:
            continue
        if not str(submitted.get(field["key"]) or "").strip():
            missing.append(field["label"])
    return missing


# ---------------------------------------------------------------------------
# Questions the catalogue cannot know about
# ---------------------------------------------------------------------------
#
# The reference form MAX runs today asks for a favourite sweet and a favourite
# song. No catalogue will ever contain those, and that is the point: a fixed
# list of fifty fields still cannot ask the one question this trip needs. So
# the organizer writes their own.
#
# Answers land in normalized_data under their own key, exactly like an
# unrecognised column from an uploaded file — the catch-all contract, applied
# to the form.

_MAX_CUSTOM_FIELDS = 30
_MAX_LABEL = 200
_CUSTOM_TYPES = ("text", "textarea", "select", "date", "boolean")


def _clean_key(raw: Any) -> str:
    """A storage key that cannot collide with a catalogue field or break JSON
    paths. Unknown shapes yield "" and the entry is dropped."""
    key = "".join(
        ch if (ch.isalnum() or ch == "_") else "_"
        for ch in str(raw or "").strip().lower().replace(" ", "_")
    ).strip("_")[:60]
    return "" if not key or key in FIELD_KEYS else key


def resolve_custom(stored: Any) -> list[dict[str, Any]]:
    """The organizer's own questions, filtered into a shape the form can render.

    Each entry: ``{key, label, type, required, options}``. Anything malformed
    is dropped rather than rendered half-broken — this drives a public page
    that people outside the company fill in, so a typo in the console must not
    become a form nobody can submit.
    """
    entries = stored if isinstance(stored, list) else []
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for entry in entries[:_MAX_CUSTOM_FIELDS]:
        if not isinstance(entry, dict):
            continue
        key = _clean_key(entry.get("key") or entry.get("label"))
        if not key or key in seen:
            continue
        label = str(entry.get("label") or key).strip()[:_MAX_LABEL]
        if not label:
            continue
        ftype = entry.get("type") if entry.get("type") in _CUSTOM_TYPES else "text"
        options = [
            str(o).strip()[:_MAX_LABEL]
            for o in (entry.get("options") or [])
            if str(o).strip()
        ][:50] if isinstance(entry.get("options"), list) else []
        # A select with nothing to select is a dead end — degrade to free text
        # rather than render an empty dropdown a visitor cannot get past.
        if ftype == "select" and not options:
            ftype = "text"
        seen.add(key)
        out.append({
            "key": key, "label": label, "type": ftype,
            "required": bool(entry.get("required")), "options": options,
        })
    return out


def resolve_confirmations(stored: Any) -> list[dict[str, Any]]:
    """The tick-boxes this event insists on, with the organizer's own wording.

    MAX's reference form carries two: a cancellation policy with a hard date,
    and a confirmation that the attendee is the right commercial contact. Both
    are contractual, both are worded per trip, and neither belongs in code.

    Every confirmation is mandatory by construction. An optional tick-box that
    changes nothing is not a confirmation, it is a question — and questions are
    what ``resolve_custom`` is for.
    """
    entries = stored if isinstance(stored, list) else []
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for entry in entries[:_MAX_CUSTOM_FIELDS]:
        if not isinstance(entry, dict):
            continue
        key = _clean_key(entry.get("key") or entry.get("label"))
        if not key or key in seen:
            continue
        text = str(entry.get("text") or entry.get("label") or "").strip()[:2000]
        if not text:
            continue
        seen.add(key)
        out.append({
            "key": key,
            "label": str(entry.get("label") or "").strip()[:_MAX_LABEL] or text[:_MAX_LABEL],
            "text": text,
        })
    return out


def missing_custom(custom: list[dict[str, Any]], answers: Any) -> list[str]:
    """Labels of the organizer's own required questions left blank."""
    given = answers if isinstance(answers, dict) else {}
    return [
        field["label"] for field in custom
        if field["required"] and not str(given.get(field["key"]) or "").strip()
    ]


def missing_confirmations(confirmations: list[dict[str, Any]], ticked: Any) -> list[str]:
    """Labels of the confirmations that were not ticked.

    Checked server-side for the same reason the required fields are: the
    endpoint is public and takes JSON, so an unticked box in the browser is a
    courtesy, not a guarantee. These carry contractual weight — a cancellation
    policy nobody agreed to is worth nothing.
    """
    given = ticked if isinstance(ticked, dict) else {}
    return [c["label"] for c in confirmations if not given.get(c["key"]) is True]


def keep_custom_answers(
    custom: list[dict[str, Any]], answers: Any
) -> dict[str, Any]:
    """Answers to questions this event actually asks, and nothing else.

    A submission naming a key the event never defined is dropped: the endpoint
    is public, and normalized_data feeds the master list and every export.
    """
    given = answers if isinstance(answers, dict) else {}
    known = {field["key"] for field in custom}
    return {
        key: str(value).strip()[:2000]
        for key, value in given.items()
        if key in known and str(value or "").strip()
    }


def fetch(supabase: Any, event_id: str) -> Optional[dict[str, Any]]:
    """Read an event's stored configuration, or None.

    None covers three cases that all mean the same thing to the caller — never
    configured, configured as null, or migration 007 not applied on this
    deployment (the column simply does not exist and PostgREST errors). The
    form then shows its defaults instead of breaking.
    """
    try:
        resp = (
            supabase.table("events")
            .select("registration_fields")
            .eq("id", event_id)
            .limit(1)
            .execute()
        )
    except Exception:
        return None
    rows = resp.data if isinstance(resp.data, list) else []
    if not rows or not isinstance(rows[0], dict):
        return None
    stored = rows[0].get("registration_fields")
    return stored if isinstance(stored, dict) else None


def fetch_extras(supabase: Any, event_id: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """The event's own questions and confirmations, already resolved.

    Returns ``([], [])`` when migration 010 has not been applied — the form
    then renders exactly the catalogue, which is what it did before this
    existed. Selected apart from ``registration_fields`` on purpose: PostgREST
    fails a whole select when one column is missing, so folding these in would
    take the field configuration down with them on an un-migrated deployment.
    """
    try:
        resp = (
            supabase.table("events")
            .select("registration_custom_fields, registration_confirmations")
            .eq("id", event_id)
            .limit(1)
            .execute()
        )
    except Exception:
        return [], []
    rows = resp.data if isinstance(resp.data, list) else []
    if not rows or not isinstance(rows[0], dict):
        return [], []
    return (
        resolve_custom(rows[0].get("registration_custom_fields")),
        resolve_confirmations(rows[0].get("registration_confirmations")),
    )


# ---------------------------------------------------------------------------
# Badges (point 13, v1) — organise the form for different audiences
# ---------------------------------------------------------------------------
#
# "Modulable par badge" starts here: named categories an organizer defines
# once per event — VIP, Speaker, Staff, whatever the event calls them — that
# a field's ``badges`` list (see resolve/sanitize above) can restrict itself
# to. A badge is not selected by the registrant on the form; it comes from
# WHICH LINK they were sent (?badge=slug on the same registration token, see
# routers/public_registration.py), the way a real event sends the VIP list a
# different link from the general one.
#
# What this v1 does NOT do, on purpose, because it needs its own pass rather
# than being rushed alongside everything else in this one: a visual
# drag-and-drop canvas, and brand-new block TYPES beyond the existing
# catalogue of questions (photo/text placement is still catalogue order, now
# reorderable, not a free canvas).

def resolve_badges(stored: Any) -> list[dict[str, str]]:
    """The event's saved badges, with anything unusable dropped — same
    malformed-input tolerance as rooming_plan.resolve_presets and
    dispatch_service.resolve_settings elsewhere in this codebase."""
    if not isinstance(stored, list):
        return []
    out: list[dict[str, str]] = []
    seen_ids: set[str] = set()
    for entry in stored[:_MAX_BADGES]:
        if not isinstance(entry, dict):
            continue
        name = str(entry.get("name") or "").strip()[:_BADGE_NAME_MAX]
        if not name:
            continue
        badge_id = str(entry.get("id") or "").strip()[:_BADGE_ID_MAX] or _slugify(name)
        if not badge_id or badge_id in seen_ids:
            badge_id = f"{badge_id or 'badge'}-{len(seen_ids) + 1}"
        seen_ids.add(badge_id)
        out.append({"id": badge_id, "name": name})
    return out


def _slugify(name: str) -> str:
    slug = "".join(ch if ch.isalnum() else "-" for ch in name.strip().lower())
    while "--" in slug:
        slug = slug.replace("--", "-")
    return slug.strip("-")[:_BADGE_ID_MAX]


def fetch_badges(supabase: Any, event_id: str) -> list[dict[str, str]]:
    """The event's badges, or [] before migration 027 — same degrade-clean
    contract as fetch_extras above."""
    try:
        resp = (
            supabase.table("events")
            .select("registration_badges")
            .eq("id", event_id)
            .limit(1)
            .execute()
        )
    except Exception:
        return []
    rows = resp.data if isinstance(resp.data, list) else []
    if not rows or not isinstance(rows[0], dict):
        return []
    return resolve_badges(rows[0].get("registration_badges"))
