"""
services/site_image_uploads.py — a photo for the mini-site, instead of a link (point 9).

Every section of the mini-site (§11) already took an image, but only as a
pasted ``https://`` URL — meaning an organizer had to host the picture
somewhere else first (their own site, an image host) before the mini-site
could point at it. This validates a direct upload and hands back a URL
``services.event_site.clean_image`` already accepts unchanged: nothing about
how a section STORES its image needed to change, only how one arrives.

Two things this deliberately does NOT do:

  * **It does not touch the private bucket.** A mini-site image is shown on a
    page open to the world with no login — see config.SUPABASE_PUBLIC_BUCKET.
  * **It does not accept anything but an actual image.** Same reasoning as
    registration_uploads: the extension is the uploader's own claim about
    their own file, so the bytes are sniffed, not trusted.
"""

from __future__ import annotations

import uuid
from typing import Any

from services.registration_uploads import sniff

# Five megabytes: generous for a banner photo, and small enough that one
# organizer cannot turn the public bucket into a file host by accident.
MAX_BYTES = 5 * 1024 * 1024

_ALLOWED_SNIFFED: frozenset[str] = frozenset({"jpeg", "png"})

_CONTENT_TYPES: dict[str, str] = {
    "jpeg": "image/jpeg",
    "png": "image/png",
}


class SiteImageRefused(ValueError):
    """The file cannot be accepted. The message is shown to the organizer."""


def validate(filename: str, content: bytes) -> dict[str, Any]:
    """The file, checked and described — or a refusal.

    Returns ``{content_type, ext}`` on success. Raises ``SiteImageRefused``
    with a message fit to show directly, matching registration_uploads'
    contract for the same reason: one message, written once, shown as-is.
    """
    if not content:
        raise SiteImageRefused("Le fichier est vide.")
    if len(content) > MAX_BYTES:
        raise SiteImageRefused(
            f"Le fichier dépasse {MAX_BYTES // (1024 * 1024)} Mo."
        )

    kind = sniff(content)
    if kind not in _ALLOWED_SNIFFED:
        raise SiteImageRefused(
            "Ce fichier n'est pas reconnu comme une image JPEG ou PNG."
        )

    ext = "jpg" if kind == "jpeg" else "png"
    return {"content_type": _CONTENT_TYPES[kind], "ext": ext}


def storage_path(event_id: str, ext: str) -> str:
    """Fully server-generated — the uploader's own filename is never part of
    a path, same rule as every other upload in this codebase."""
    return f"{event_id}/{uuid.uuid4().hex}.{ext}"
