"""
services/rooming_service.py — Who shares a room with whom.

Two people register separately, both ask for a twin, and each writes the
other's name in a "Roommate" box. Nothing in the engine used to connect those
two rows, so the hotel received two single reservations for one twin room
(feedback §4).

This module resolves the free-text name each fiche carries into a link to the
other fiche, and it does it **reciprocally**: a pair is only linked when both
sides point at each other, or when one side points at somebody who named
nobody. That asymmetry is deliberate — "Tina → Leslie" alone is a claim, "Tina
→ Leslie" plus "Leslie → Tina" is a fact, and a room is not something to
guess wrong about in front of an hotelier.

Three rules keep it honest:

  * **Names are matched, never merged.** The identity test is the same strict
    one the deduplication engine uses (equal token sets, or containment with at
    least two tokens), so "Lin" does not resolve to "Chenyang Lin". Sharing a
    room is emphatically NOT evidence of being the same person — see
    ``never_merge_pairs`` below, which exists to keep the duplicate engine from
    drawing that conclusion.
  * **Ambiguity is refused, not resolved.** A name matching two fiches links to
    neither. The rooming list keeps a gap the organizer can see instead of a
    plausible wrong answer.
  * **Nothing here writes a room.** Linking says "these two share"; which
    physical room they get is the rooming list's business.
"""

from __future__ import annotations

import logging
from typing import Any, Iterable, Optional

logger = logging.getLogger(__name__)

# Room types that imply a second occupant. "single" and "suite" do not: a suite
# may well be shared, but nothing in the word says so, and inventing a missing
# roommate for every suite is exactly the kind of false alert §10 is about.
SHARED_ROOM_TYPES = frozenset({"twin", "double", "double room", "twin room", "shared"})


def wants_sharing(room_type: Any) -> bool:
    """True when this room type implies a second occupant."""
    value = str(room_type or "").strip().lower()
    if not value:
        return False
    if value in SHARED_ROOM_TYPES:
        return True
    # Real files write "Twin/Double", "DBL Room", "Chambre double"…
    return any(token in value for token in ("twin", "double", "dbl", "partag", "shared"))


def _index_by_name(
    participants: Iterable[dict[str, Any]],
    norm_name: Any,
) -> dict[str, list[dict[str, Any]]]:
    """Normalised full name -> every fiche answering to it.

    A list, not a single fiche: two genuinely different people can share a
    name on a large event, and that is precisely the case where guessing is
    forbidden.
    """
    index: dict[str, list[dict[str, Any]]] = {}
    for p in participants:
        full = f"{p.get('first_name') or ''} {p.get('last_name') or ''}".strip()
        key = norm_name(full)
        if key:
            index.setdefault(key, []).append(p)
    return index


def _candidates(
    written_name: str,
    index: dict[str, list[dict[str, Any]]],
    same_person_name: Any,
    norm_name: Any,
    exclude_id: str,
) -> list[dict[str, Any]]:
    """Fiches the written name could designate, excluding the writer's own.

    Exact normalised hit first — that is the overwhelming majority and it is
    unambiguous. Only when nothing matches exactly do we fall back to the
    strict identity test, which is what catches "Leslie Collon" written as
    "Leslie Collon-Dupont".
    """
    key = norm_name(written_name)
    if not key:
        return []

    exact = [p for p in index.get(key, []) if p.get("id") != exclude_id]
    if exact:
        return exact

    loose: list[dict[str, Any]] = []
    for indexed_name, fiches in index.items():
        if not same_person_name(key, indexed_name):
            continue
        loose.extend(p for p in fiches if p.get("id") != exclude_id)
    return loose


def resolve_pairs(
    participants: list[dict[str, Any]],
    same_person_name: Any,
    norm_name: Any,
) -> tuple[dict[str, Optional[str]], list[dict[str, Any]]]:
    """Work out who shares with whom.

    Returns ``(links, unresolved)``:

      * ``links`` maps a participant id to the id of the fiche they share with,
        or to None when a previously stored link no longer holds and must be
        cleared. Every link produced here is symmetric — both ids appear as
        each other's value — so the caller can write it in one pass without
        having to reason about direction.
      * ``unresolved`` describes each fiche that asked to share and could not be
        paired, with a ``reason`` the exception layer turns into a message.

    Pure: it reads dicts and returns dicts, touching no database. That is what
    lets the whole rule be tested against a table of names.
    """
    index = _index_by_name(participants, norm_name)
    by_id = {p["id"]: p for p in participants if p.get("id")}

    # Pass 1 — who does each fiche point at?
    intent: dict[str, str] = {}
    unresolved: list[dict[str, Any]] = []

    for p in participants:
        pid = p.get("id")
        if not pid:
            continue
        written = str(p.get("roommate_name") or "").strip()
        shares = wants_sharing(p.get("room_type"))

        if not written:
            if shares:
                unresolved.append({
                    "participant_id": pid,
                    "participant": p,
                    "reason": "no_name",
                    "written_name": "",
                })
            continue

        matches = _candidates(written, index, same_person_name, norm_name, exclude_id=pid)
        if not matches:
            unresolved.append({
                "participant_id": pid, "participant": p,
                "reason": "unknown_name", "written_name": written,
            })
            continue
        if len(matches) > 1:
            unresolved.append({
                "participant_id": pid, "participant": p,
                "reason": "ambiguous_name", "written_name": written,
            })
            continue
        intent[pid] = matches[0]["id"]

    # Pass 2 — confirm. A pair holds when both point at each other, or when the
    # other side named nobody at all (one of the two filled the box, which is
    # the common case: the couple registers, only one bothers).
    links: dict[str, Optional[str]] = {}
    for pid, target in intent.items():
        if pid in links:
            continue
        back = intent.get(target)
        target_named_nobody = target not in intent and not str(
            (by_id.get(target) or {}).get("roommate_name") or ""
        ).strip()

        if back == pid or target_named_nobody:
            links[pid] = target
            links[target] = pid
        else:
            # They named somebody who named a third person. Linking either way
            # would put three people in a twin.
            unresolved.append({
                "participant_id": pid,
                "participant": by_id.get(pid, {}),
                "reason": "contradicted",
                "written_name": str((by_id.get(pid) or {}).get("roommate_name") or ""),
            })

    # Clear links that no longer hold: a stored partner who is gone from this
    # run, or who now points elsewhere. Exceptions and links both describe the
    # CURRENT state, never the history.
    for p in participants:
        pid = p.get("id")
        stored = p.get("roommate_participant_id")
        if pid and stored and links.get(pid) != stored:
            links.setdefault(pid, None)

    # A fiche that is linked is no longer unresolved, whatever pass 1 thought.
    linked_ids = {pid for pid, target in links.items() if target}
    unresolved = [u for u in unresolved if u["participant_id"] not in linked_ids]

    return links, unresolved


def never_merge_pairs(links: dict[str, Optional[str]]) -> set[frozenset[str]]:
    """Pairs the duplicate engine must never fuse.

    Roommates are the worst possible false positive for deduplication: they
    routinely share a booking email, sometimes a contact phone, and on a
    company trip often a surname. Every signal the merge engine trusts points
    the wrong way at once — so the answer is not a better score, it is an
    explicit veto.
    """
    return {
        frozenset((pid, target))
        for pid, target in links.items()
        if target and pid != target
    }
