"""
services/roles.py — The access ladder §21 asks for.

The feedback is unusually concrete here. Five levels, named:

    MAX Admin            every MAX project
    Project User         only the projects they are authorised on
    Freelancer/External  one specific project
    Participant          no access to the internal app at all — only their
                         registration link and their mini event site
    Client               no operational access, for now

And one instruction wrapped around them: "dans un premier temps, on peut
probablement garder la majorite de l'equipe en Administrateur. Mais
l'architecture doit deja permettre plusieurs niveaux." So the ladder is built
now and used sparingly, rather than retrofitted onto a system where everybody
has been an admin for a year.

Three properties are worth stating because they are what the code enforces.

**Membership is the mechanism, the role is the policy.** ``project_members``
already carries who may see which project and which events inside it. A role
does not re-implement that; it decides whether membership is even consulted --
an admin skips it, a project user is bound by it, and a participant never gets
that far.

**Denial happens before membership, not after.** A participant with a stray
``project_members`` row must still be refused. Rights that can be granted by
accident are not rights, they are an accident waiting to be audited.

**``pm`` keeps the access it has today.** Narrowing it to per-project would
lock out, silently and immediately, every project manager already relying on
org-wide access. §21 asks for the architecture to allow the levels, not for the
existing team to be reorganised on a Tuesday -- that is the organizer's call,
made by moving people to ``project_user`` when they are ready.
"""

from __future__ import annotations

import os
from typing import Any

# Stored values. The first four already exist in the user_role enum; the last
# three arrive with migration 020.
ADMIN = "admin"
PM = "pm"
CLIENT = "client"
VIEWER = "viewer"
PROJECT_USER = "project_user"
FREELANCER = "freelancer"
PARTICIPANT = "participant"

# Roles that see every project in the organisation without a membership row.
ORG_WIDE: frozenset[str] = frozenset({ADMIN, PM})

# Whether the `client` role still reaches the internal application.
#
# §21 says "pas d'acces a la partie operationnelle actuellement", and taking
# that literally means every existing client account loses the application the
# moment this ships. That is a migration, not a code change: it needs somebody
# to know which accounts exist first.
#
# So the default is the non-breaking one -- a client keeps READ access and
# never gains write or sharing, which they did not have either way -- and the
# strict reading is one environment variable away:
#
#     CLIENT_OPERATIONAL_ACCESS=0
#
# Flip it once you have confirmed no client account is in daily use. Nothing
# else in the ladder depends on this choice.
CLIENT_OPERATIONAL_ACCESS: bool = (
    os.getenv("CLIENT_OPERATIONAL_ACCESS", "1").strip().lower()
    not in {"0", "false", "no", "off"}
)

# Roles that reach the internal application at all. Everything outside this set
# is refused before membership is even looked at.
#
# `participant` is the clear case and is never in it: §21 gives them their
# registration link and their mini event site, and nothing else.
OPERATIONAL: frozenset[str] = frozenset(
    {ADMIN, PM, PROJECT_USER, FREELANCER, VIEWER}
    | ({CLIENT} if CLIENT_OPERATIONAL_ACCESS else set())
)

# Roles allowed to change data, given a membership that also permits it.
# Reading and writing are separate questions: a freelancer on one project may
# well need to edit it, while a viewer on the same project may not.
CAN_WRITE: frozenset[str] = frozenset({ADMIN, PM, PROJECT_USER, FREELANCER})

# Roles that may administer other people's access.
#
# The two org-wide roles, and only them. For a project user or a freelancer it
# would be an escalation -- anyone who can grant project access can grant it to
# themselves, which turns every other level in this ladder into a suggestion.
# For a pm it is not: they already see every project, so granting themselves
# access gains them nothing. Narrowing this to the administrator alone is a
# one-line change, and a decision for whoever runs the organisation rather than
# something to impose on a team that has managed sharing for a year.
CAN_SHARE: frozenset[str] = frozenset({ADMIN, PM})

# A freelancer is scoped to a project and, in the common case, to the specific
# events inside it that they were hired for. An unrestricted membership for
# them is legal but noteworthy -- see `is_over_scoped`.
SCOPED_TIGHT: frozenset[str] = frozenset({FREELANCER})

_LABELS: dict[str, dict[str, str]] = {
    ADMIN:        {"fr": "Administrateur", "en": "Administrator"},
    PM:           {"fr": "Chef de projet", "en": "Project manager"},
    PROJECT_USER: {"fr": "Utilisateur projet", "en": "Project user"},
    FREELANCER:   {"fr": "Freelance / externe", "en": "Freelancer / external"},
    VIEWER:       {"fr": "Lecture seule", "en": "Read only"},
    CLIENT:       {"fr": "Client", "en": "Client"},
    PARTICIPANT:  {"fr": "Participant", "en": "Participant"},
}

_DESCRIPTIONS: dict[str, str] = {
    ADMIN:        "Acces a tous les projets de l'organisation, et a la gestion des acces.",
    PM:           "Acces a tous les projets de l'organisation.",
    PROJECT_USER: "Acces uniquement aux projets sur lesquels la personne est invitee.",
    FREELANCER:   "Acces a un projet precis, souvent a quelques evenements seulement.",
    VIEWER:       "Lecture seule, sur les projets partages avec la personne.",
    CLIENT:       "Lecture seule pour l'instant, jamais de modification ni de partage.",
    PARTICIPANT:  "Aucun acces a l'application : uniquement son lien d'inscription.",
}


def normalise(role: Any) -> str:
    """A known role, or ``viewer``.

    An unrecognised value resolves to the least privileged role rather than
    raising. A role typo in the database must not become an outage, and it must
    certainly not become an escalation.
    """
    value = str(role or "").strip().lower()
    return value if value in _LABELS else VIEWER


def sees_every_project(role: Any) -> bool:
    """True when membership is not consulted at all."""
    return normalise(role) in ORG_WIDE


def has_operational_access(role: Any) -> bool:
    """True when this role may reach the internal app at all.

    Checked BEFORE membership: a participant with a stray project_members row
    must still be refused.
    """
    return normalise(role) in OPERATIONAL


def can_write(role: Any) -> bool:
    """True when the role permits changing data -- membership permitting too."""
    return normalise(role) in CAN_WRITE


def can_manage_access(role: Any) -> bool:
    """True when the role may grant or revoke somebody else's access.

    The org-wide roles only. For anybody scoped by membership it would be an
    escalation: they could grant themselves the projects they cannot see.
    """
    return normalise(role) in CAN_SHARE


def is_over_scoped(role: Any, membership: Any) -> bool:
    """A freelancer invited to a whole project rather than to named events.

    Not an error -- sometimes that is the arrangement -- but worth surfacing on
    the sharing screen, because it is almost always somebody clicking through a
    dialog rather than a decision.
    """
    if normalise(role) not in SCOPED_TIGHT:
        return False
    if not isinstance(membership, dict):
        return False
    return not (membership.get("event_ids") or [])


def label(role: Any, locale: str = "fr") -> str:
    entry = _LABELS.get(normalise(role), _LABELS[VIEWER])
    return entry.get(locale) or entry["fr"]


def describe() -> list[dict[str, Any]]:
    """The ladder, for the settings screen -- in the order §21 lists it."""
    order = (ADMIN, PM, PROJECT_USER, FREELANCER, VIEWER, CLIENT, PARTICIPANT)
    return [
        {
            "role": role,
            "label": label(role),
            "description": _DESCRIPTIONS[role],
            "sees_every_project": role in ORG_WIDE,
            "operational": role in OPERATIONAL,
            "can_write": role in CAN_WRITE,
            "can_manage_access": role in CAN_SHARE,
        }
        for role in order
    ]
