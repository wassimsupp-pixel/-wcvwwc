"""
services/consolidation_service.py — Consolidation orchestrator.

Entry point: ``run_consolidation(event_id, run_id, user_id, supabase)``

Consolidation pipeline:
  1. Load all mapped files for the event
  2. Parse raw rows and create source_records
  3. Separate registration records from FCM records
  4. Run the matching engine to link FCM → registration participants
  5. Upsert participants (non-destructive: skip locked fields)
  6. Detect DUPLICATE_EMAIL exceptions
  7. Run the full exception detector
  8. Mark all processed files as 'processed'
  9. Update the consolidation_run with final status and stats
 10. Write a summary entry to the change_log
"""

from __future__ import annotations

import hashlib
import logging
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Optional

from rapidfuzz import fuzz
from supabase import Client

from services import exception_service
from services.audit_service import log_change
from services.file_service import download_and_parse_file, download_all_sheets, get_mapped_files_for_event
from services.mapping_service import parse_and_insert_source_records, suggest_mapping

def fetch_all_source_records(supabase: Client, file_ids: list[str]) -> list[dict]:
    all_data = []
    limit = 1000
    offset = 0
    while True:
        resp = supabase.table("source_records").select("id, normalized_data, raw_data, file_id, event_id, row_index").in_("file_id", file_ids).range(offset, offset + limit - 1).execute()
        data = resp.data or []
        all_data.extend(data)
        if len(data) < limit:
            break
        offset += limit
    return all_data

def fetch_all_hotel_nights(supabase: Client, hotel_ids: list[str]) -> list[dict]:
    all_data = []
    limit = 1000
    offset = 0
    while True:
        resp = supabase.table("hotel_nights").select("id, participant_id, night_date, hotel_id").in_("hotel_id", hotel_ids).range(offset, offset + limit - 1).execute()
        data = resp.data or []
        all_data.extend(data)
        if len(data) < limit:
            break
        offset += limit
    return all_data

def fetch_all_participants(supabase: Client, event_id: str) -> list[dict]:
    all_data = []
    limit = 1000
    offset = 0
    while True:
        resp = supabase.table("participants").select("id, email, first_name, last_name, locked_fields, nationality, has_flight, has_hotel, has_transfer, has_activities").eq("event_id", event_id).range(offset, offset + limit - 1).execute()
        data = resp.data or []
        all_data.extend(data)
        if len(data) < limit:
            break
        offset += limit
    return all_data

logger = logging.getLogger(__name__)

# Thresholds for name-matching confidence
SCORE_CERTAIN_THRESHOLD  = 95.0   # email match + high name similarity
SCORE_PROBABLE_THRESHOLD = 75.0   # no email match but strong name match

# How alike two names must be, with no email on either side, to be treated as
# the same person. Deliberately high: below this the two are kept apart, which
# costs a duplicate the organizer can merge, whereas merging two different
# people silently destroys one of them.
_FUZZY_NAME_MIN = 90


# ---------------------------------------------------------------------------
# Name splitting
# ---------------------------------------------------------------------------

def split_full_name(raw: Any) -> tuple[str, str]:
    """
    Split a combined name into ``(first_name, last_name)``.

    Client files carry the identity in a single cell far more often than in two,
    and in three different conventions:

        "MONTOYA HURTADO/MARÍA"  → ("María", "Montoya Hurtado")   airline/GDS
        "Nakagawa, Tatsuhito"    → ("Tatsuhito", "Nakagawa")      roster export
        "Simona Accorsi"         → ("Simona", "Accorsi")          plain

    Returns ``("", "")`` when there is nothing to split, and ``("", name)`` for a
    mononym — a single-token name is a complete identity in many cultures
    (e.g. a Japanese name written without a space), so it is kept as the last
    name rather than being torn in half or discarded.

    Nothing here rewrites a value: the characters are the client's, only the
    column they land in changes.
    """
    s = str(raw or "").strip()
    if not s:
        return "", ""
    if "/" in s:                       # LAST/First — the GDS convention
        a, b = s.split("/", 1)
        return b.strip(), a.strip()
    if "," in s:                       # "Last, First"
        a, b = s.split(",", 1)
        return b.strip(), a.strip()
    toks = s.split()
    if len(toks) >= 2:                 # "First Last" / "First Middle Last"
        return toks[0], " ".join(toks[1:])
    return "", s                       # mononym


def resolve_identity_name(nd: dict[str, Any]) -> tuple[str, str]:
    """
    Derive ``(first_name, last_name)`` from a normalized record, splitting a
    combined name whenever the file did not provide the two parts separately.

    Order of trust: explicit first+last > ``traveler_name`` > a ``last_name``
    that actually holds the whole name (the mapper legitimately routes a column
    named "Full Name" there, and a "Nom" column often contains "SURNAME/Given").
    """
    first = str(nd.get("first_name") or "").strip()
    last = str(nd.get("last_name") or "").strip()
    if first and last:
        return first, last

    # A combined-name column wins when we are missing a half.
    if not first:
        combined = [nd.get("traveler_name"), nd.get("full_name"), nd.get("name")]
        for src in combined:
            f, l = split_full_name(src)
            if f and l:
                return f, l
        # Otherwise the surviving half may itself be the full name.
        f, l = split_full_name(last)
        if f and l:
            return f, l
        # Neither could be split. A mononym is still an identity — never drop it.
        if not last:
            for src in combined:
                _, l = split_full_name(src)
                if l:
                    return "", l
    return first, last


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

class ParticipantRecord:
    """Lightweight in-memory representation of a (potential) participant."""

    def __init__(self, source_record_id: str, normalized: dict[str, Any]):
        self.source_record_id = source_record_id
        self.normalized = normalized
        # Split here rather than at each call site: EVERY downstream consumer
        # (dedup key, fuzzy match, participant row) must see the same identity.
        first, last = resolve_identity_name(normalized)
        self.first_name: str = first
        self.last_name:  str = last
        self.email:      str = (normalized.get("email") or "").strip().lower()
        self.company:    str = (normalized.get("company") or "").strip()

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}".strip()


class MatchResult:
    """Outcome of matching a single FCM record against a registration participant."""

    def __init__(
        self,
        fcm_record: ParticipantRecord,
        reg_record: Optional[ParticipantRecord],
        decision: str,  # certain | probable | to_verify | not_found
        score: float,
        signals: dict[str, Any],
    ):
        self.fcm_record  = fcm_record
        self.reg_record  = reg_record
        self.decision    = decision
        self.score       = score
        self.signals     = signals


# ---------------------------------------------------------------------------
# Matching engine
# ---------------------------------------------------------------------------

def _compute_name_score(a: ParticipantRecord, b: ParticipantRecord) -> float:
    """
    Compute a fuzzy name-similarity score between two participant records.

    Uses token_sort_ratio to handle reversed name order (Last, First vs First Last).
    Returns a float in [0, 100].
    """
    score_full = fuzz.token_sort_ratio(a.full_name.lower(), b.full_name.lower())
    # Also try last name only for partial matches
    score_last = fuzz.ratio(a.last_name.lower(), b.last_name.lower())
    return max(score_full, score_last)


def match_sources(
    registrations: list[ParticipantRecord],
    fcm_records: list[ParticipantRecord],
) -> list[MatchResult]:
    """
    Match FCM records against registration records.

    Matching algorithm (in priority order):
    1. **Exact email match** → CERTAIN (score=100)
    2. **No email on one side + high name score ≥ 95** → CERTAIN
    3. **Name score ≥ 75** → PROBABLE
    4. **Name score < 75** → NOT_FOUND

    Parameters
    ----------
    registrations:
        List of ParticipantRecord objects from registration source files.
    fcm_records:
        List of ParticipantRecord objects from FCM source files.

    Returns
    -------
    List of MatchResult — one per FCM record.
    """
    # Build email index for O(1) lookup
    email_index: dict[str, ParticipantRecord] = {}
    for reg in registrations:
        if reg.email:
            email_index[reg.email] = reg

    results: list[MatchResult] = []

    for fcm in fcm_records:
        best_reg: Optional[ParticipantRecord] = None
        best_score = 0.0
        signals: dict[str, Any] = {}

        # Step 1: exact email match
        if fcm.email and fcm.email in email_index:
            best_reg = email_index[fcm.email]
            name_score = _compute_name_score(fcm, best_reg)
            best_score = 100.0
            signals = {"email_match": True, "name_score": name_score}
            decision = "certain"

        else:
            # Step 2–4: name-based fuzzy matching
            signals["email_match"] = False
            for reg in registrations:
                name_score = _compute_name_score(fcm, reg)
                if name_score > best_score:
                    best_score = name_score
                    best_reg = reg
                    signals["name_score"] = name_score
                    signals["company_match"] = (
                        fcm.company.lower() == reg.company.lower()
                        if fcm.company and reg.company
                        else None
                    )

            if best_score >= SCORE_CERTAIN_THRESHOLD:
                decision = "certain"
            elif best_score >= SCORE_PROBABLE_THRESHOLD:
                decision = "probable"
            elif best_reg is not None:
                decision = "to_verify"
            else:
                decision = "not_found"
                best_reg = None

        results.append(
            MatchResult(
                fcm_record=fcm,
                reg_record=best_reg,
                decision=decision,
                score=best_score,
                signals=signals,
            )
        )

    return results


# ---------------------------------------------------------------------------
# Non-destructive merge
# ---------------------------------------------------------------------------

def merge_participant_fields(
    existing: dict[str, Any],
    new_data: dict[str, Any],
    locked_fields: dict[str, Any],
) -> dict[str, Any]:
    """
    Merge new data into an existing participant record, skipping locked fields.

    Rules:
    - Locked fields (``locked_fields[field] == True``) are never overwritten.
    - ``None`` or empty string values in ``new_data`` do not overwrite existing values.
    - Non-locked, non-empty new values are applied.

    Parameters
    ----------
    existing:
        Current participant row from the database.
    new_data:
        Dict of candidate new values.
    locked_fields:
        Dict of ``{field_name: True}`` for locked fields.

    Returns
    -------
    Merged dict ready to be passed to ``supabase.table("participants").update()``.
    """
    merged = existing.copy()
    if isinstance(locked_fields, list):
        locked_fields = {f: True for f in locked_fields}
    elif not isinstance(locked_fields, dict):
        locked_fields = {}

    for field, value in new_data.items():
        if locked_fields.get(field):
            continue  # preserve manually set value
        if value is not None and value != "":
            merged[field] = value

    # Clean up nationality if it's one of the source type indicators
    src_indicators = {'Formulaire web', 'Assistant', 'Import Excel', 'Email direct'}
    if merged.get("nationality") in src_indicators:
        merged["nationality"] = None

    return merged


# Columns that actually exist on the participants table. normalized_data can
# carry many extra master-file fields (attendee_category, passport_number, …)
# which live in source_records — writing them to participants would fail with
# "column does not exist", so updates are filtered to this whitelist.
_PARTICIPANT_WRITABLE_FIELDS = {
    "first_name", "last_name", "email", "company", "phone", "nationality",
    "dietary_requirements", "completeness_status",
    "has_flight", "has_hotel", "has_transfer", "has_activities",
    "verification_note", "registration_source_id", "fcm_source_id",
    # A personal extension at the registrant's own expense (§3, migration
    # 022). Free text, like verification_note: the form asks an open
    # question, not a checkbox, and the answer is theirs to word.
    "extension_requested", "extension_start", "extension_end", "extension_hotel",
}


# ---------------------------------------------------------------------------
# Duplicate email detector
# ---------------------------------------------------------------------------

def detect_duplicate_emails(
    registrations: list[ParticipantRecord],
    run_id: str,
    event_id: str,
    supabase: Client,
    exceptions_list: Optional[list[dict]] = None,
) -> int:
    """
    Detect duplicate email addresses within the registration source records.

    Inserts a DUPLICATE_EMAIL exception for each group of records sharing
    the same email address (when email is not empty).

    Returns
    -------
    Number of exception records inserted.
    """
    from services.exception_service import _insert_exception

    email_groups: dict[str, list[ParticipantRecord]] = defaultdict(list)
    for r in registrations:
        if r.email:
            email_groups[r.email].append(r)

    count = 0
    for email, records in email_groups.items():
        if len(records) > 1:
            names = ", ".join(r.full_name for r in records)
            _insert_exception(
                supabase=supabase,
                run_id=run_id,
                event_id=event_id,
                exception_type="DUPLICATE_EMAIL",
                severity="critical",
                message=f"Email '{email}' appears {len(records)} times in registration data: {names}",
                context_data={
                    "email": email,
                    "occurrences": len(records),
                    "participant_names": names,
                    "source_record_ids": [r.source_record_id for r in records],
                },
                exceptions_list=exceptions_list,
            )
            count += 1

    return count


def detect_duplicate_participant_emails(
    run_id: str,
    event_id: str,
    supabase: Client,
) -> int:
    """
    Flag emails shared by SEVERAL DISTINCT participants in the final master
    list — one exception per email, listing everyone concerned. Rows repeated
    across source files that consolidated into ONE participant are NOT flagged.
    """
    parts: list[dict] = []
    offset = 0
    while True:
        res = (
            supabase.table("participants")
            .select("id, first_name, last_name, email")
            .eq("event_id", event_id)
            .range(offset, offset + 999)
            .execute()
        )
        data = res.data or []
        parts.extend(data)
        if len(data) < 1000:
            break
        offset += 1000

    groups: dict[str, list[dict]] = defaultdict(list)
    for p in parts:
        email = (p.get("email") or "").strip().lower()
        if email:
            groups[email].append(p)

    rows: list[dict] = []
    for email, members in groups.items():
        if len(members) < 2:
            continue
        names = ", ".join(
            f"{m.get('first_name') or ''} {m.get('last_name') or ''}".strip() for m in members
        )
        rows.append({
            "run_id": run_id,
            "event_id": event_id,
            "participant_id": members[0]["id"],
            "exception_type": "DUPLICATE_EMAIL",
            "severity": "critical",
            "message": f"Email '{email}' est partagé par {len(members)} participants distincts : {names}",
            "context_data": {
                "email": email,
                "participant_count": len(members),
                "participant_ids": [m["id"] for m in members],
                "participant_names": names,
            },
        })

    for i in range(0, len(rows), 100):
        try:
            supabase.table("exceptions").insert(rows[i:i + 100]).execute()
        except Exception as exc:
            logger.error("Failed to insert duplicate-email exceptions: %s", exc)
    return len(rows)


# ---------------------------------------------------------------------------
# Main orchestrator
# ---------------------------------------------------------------------------

def _is_public_form_file(uploaded_file: dict) -> bool:
    """True for the per-event virtual uploaded_files row that
    routers/public_registration.py creates for public form submissions —
    storage_path is set to ``f"public-form/{event_id}"`` there, which never
    collides with a real upload's ``{event_id}/{file_id}/{filename}`` path."""
    return (uploaded_file.get("storage_path") or "").startswith("public-form/")


def _load_public_form_record_ids(supabase: Client, file_id: str) -> list[str]:
    """All source_record ids for the public-form virtual file, paginated
    (PostgREST caps a single select at 1000 rows) and in a deterministic
    order (row_index, then id for the rare duplicate row_index produced by
    the router's count-then-insert) so match_sources' first-encountered-wins
    tie-break stays stable across runs (audit PROP-002)."""
    ids: list[str] = []
    offset = 0
    limit = 1000
    while True:
        resp = (
            supabase.table("source_records")
            .select("id")
            .eq("file_id", file_id)
            .order("row_index")
            .order("id")
            .range(offset, offset + limit - 1)
            .execute()
        )
        data = resp.data or []
        ids.extend(r["id"] for r in data)
        if len(data) < limit:
            break
        offset += limit
    return ids


def _purge_scope(mapped_files: list[dict], parsed_file_ids: set[str]) -> set[str]:
    """Files whose source_records the stale-copy purge may touch. Public-form
    virtual files are excluded: their rows are inserted exactly once by
    routers/public_registration.py and never re-inserted by a run, so they
    can never have stale copies — but a submission that lands *while* a run
    is in flight (after the run read the file's ids, before the purge) would
    look exactly like a stray and be deleted, destroying a visitor's
    registration. Same for rows beyond the read's pagination horizon."""
    public_form_ids = {f["id"] for f in mapped_files if _is_public_form_file(f)}
    return parsed_file_ids - public_form_ids


def _late_public_form_submissions(
    supabase: Client,
    event_id: str,
    public_form_counts: dict[str, int],
) -> bool:
    """True when public-form submissions exist that this run did not read —
    either rows added to a known virtual file after step 3 read it, or a
    virtual file created mid-run by a first-ever submission (it wasn't in
    mapped_files at all). Pure count comparison on the DB side, so it does
    not depend on clock agreement between the API server and Postgres."""
    try:
        files_resp = (
            supabase.table("uploaded_files")
            .select("id")
            .eq("event_id", event_id)
            .eq("storage_path", f"public-form/{event_id}")
            .execute()
        )
        for row in files_resp.data or []:
            fid = row["id"]
            cnt_resp = (
                supabase.table("source_records")
                .select("id", count="exact")
                .eq("file_id", fid)
                .limit(1)
                .execute()
            )
            if (cnt_resp.count or 0) > public_form_counts.get(fid, 0):
                return True
    except Exception as exc:
        logger.warning("Late public-form submission check failed for event %s: %s", event_id, exc)
    return False


def _name_key(first: Any, last: Any) -> str:
    """Normalised 'first last' key (lowercased, accent-stripped) for deduping the
    same person across files when the email is missing or inconsistent."""
    import unicodedata
    s = f"{first or ''} {last or ''}".strip().lower()
    s = "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")
    return " ".join(s.split())


def _name_key_sorted(first: Any, last: Any) -> str:
    """The name key with its words sorted, so that "DUPONT Jean" and
    "Jean Dupont" produce the same string.

    Airline and hotel exports put the family name first; registration files put
    it last. Which column ends up as `first_name` therefore depends on the file,
    not on the person — and the ordered key alone treats the two as strangers.
    """
    return " ".join(sorted(_name_key(first, last).split()))


def find_matching_participant(
    record: dict[str, Any],
    by_email: dict[str, dict],
    by_name: dict[str, dict],
    by_sorted_name: Optional[dict[str, dict]] = None,
    *,
    allow_fuzzy: bool = True,
) -> Optional[dict]:
    """Which already-known participant this source row belongs to, or None.

    This is the decision the whole product rests on: the same person listed in
    two files — the phone in one, the email in the other — has to land on ONE
    fiche carrying both. It lived inline in run_consolidation, which meant the
    single most important behaviour of the application had no test of its own.

    Four ways in, tried in order:
      1. the same email (settles it outright);
      2. the same normalised name (accent- and case-insensitive);
      3. the same name with the words in the other order — "DUPONT Jean" is
         "Jean Dupont". An exact dictionary hit, so it holds at any size;
      4. a near-identical name (typos), when the event is small enough for the
         O(n²) scan to be affordable.

    Step 3 exists because step 4 used to carry that case alone, and step 4 is
    switched off past 400 known names: the reversal merged correctly on a
    30-person test event and silently produced duplicates on the 500-person
    one — the events where nobody re-reads the master list by hand.

    One veto: if BOTH sides carry an email and the two differ, they are two
    people who happen to share a name, and nothing is merged. A missing email
    on either side is not a conflict — it is precisely the gap the merge is
    meant to fill.
    """
    email = (record.get("email") or "").strip().lower() or None
    name_key = _name_key(record.get("first_name"), record.get("last_name"))

    existing = by_email.get(email) if email else None
    if existing or not name_key:
        return existing

    cand = by_name.get(name_key)
    if not cand and by_sorted_name:
        cand = by_sorted_name.get(_name_key_sorted(record.get("first_name"), record.get("last_name")))
    if not cand and allow_fuzzy and len(by_name) <= 400:
        best = 0
        for k, c in by_name.items():
            sc = fuzz.token_sort_ratio(name_key, k)
            if sc > best:
                best, cand = sc, c
        if best < _FUZZY_NAME_MIN:
            cand = None
    if not cand:
        return None

    cand_email = (cand.get("email") or "").strip().lower() or None
    if not email or not cand_email or email == cand_email:
        return cand
    return None


import re as _re


_CODE_JUNK = {"yes", "no", "oui", "non", "true", "false", "n/a", "na", "tbc", "tbd",
              "x", "-", "0", "1", "masterbill", "own account", "staff", "finance"}


def _is_plausible_code(code: Any) -> bool:
    """A registration/participant CODE must be a real unique identifier — never a
    form value like 'Yes'/'No'. Matching on such junk collapses everyone sharing
    it onto one participant (contaminating flights/hotels)."""
    c = str(code or "").strip().lower()
    if len(c) < 5 or c in _CODE_JUNK:
        return False
    # A genuine code has a digit or is a long-ish token (UUID/ref), not a word.
    if not any(ch.isdigit() for ch in c) and len(c) < 8:
        return False
    return True


def _norm_name(s: Any) -> str:
    """Lowercased, accent-stripped, punctuation/nickname-free name for matching.
    Drops parenthesised nicknames ('Xinzhu (Judy) Zhu' → 'xinzhu zhu')."""
    import unicodedata
    s = str(s or "").lower()
    s = _re.sub(r"\([^)]*\)", " ", s)                 # drop "(Judy)" nicknames
    s = "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")
    s = _re.sub(r"[^a-z0-9\s]", " ", s)               # drop punctuation
    return " ".join(s.split())


# Subtotal / label rows that must NOT become participants (e.g. "115 / Total",
# "Percussion facilitator"). Only applied when there is no email to trust.
_ROLE_NOISE = _re.compile(
    r"\b(total|subtotal|sous[-\s]?total|grand\s*total|facilitator|animateur|organizer|"
    r"departures?|arrivals?|arrival\s*transfers?|cancelled|canceled|villas?|hotels?|n/?a)\b",
    _re.I,
)


def _auto_sheet_mapping(sdf) -> dict[str, str]:
    """Auto column→field mapping for a secondary sheet (no human review): keep
    confident suggestions, then preserve every remaining column as a custom
    field (A→Z, nothing dropped). Returns {} if no identity column is found."""
    from services.mapping_service import _custom_field_key
    try:
        cols = list(sdf.columns)
        sample = sdf.head(8).to_dict(orient="records")
        sug = suggest_mapping(cols, sample)
        m = {c: s["suggested_field"] for c, s in sug.items()
             if s.get("suggested_field") and s.get("confidence", 0) >= 0.6}
        # Only worth processing if the sheet has an identity column to link on.
        if not any(v in ("first_name", "last_name", "traveler_name", "email") for v in m.values()):
            return {}
        # Catch-all: keep leftover columns (with data) as custom fields.
        used = set(m.values())
        for col in cols:
            if col in m:
                continue
            if not any(str(r.get(col) or "").strip() for r in sample):
                continue
            key = _custom_field_key(col, used)
            if key:
                m[col] = key
                used.add(key)
        return m
    except Exception as exc:
        logger.warning("Auto-mapping of secondary sheet failed: %s", exc)
        return {}


_FR_MONTHS = {
    "janv": 1, "jan": 1, "févr": 2, "fevr": 2, "fev": 2, "feb": 2, "mars": 3, "mar": 3,
    "avr": 4, "apr": 4, "mai": 5, "may": 5, "juin": 6, "jun": 6, "juil": 7, "jul": 7,
    "août": 8, "aout": 8, "aug": 8, "sept": 9, "sep": 9, "oct": 10, "nov": 11, "déc": 12, "dec": 12,
}


def _parse_header_date(header: str, year: int):
    """Parse a per-night column header ('26-janv', '27-Jan', '2026-01-26', '26/01')
    into a date. Returns a date or None."""
    from datetime import date as _date
    s = str(header or "").strip().lower()
    m = _re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})", s)
    if m:
        try:
            return _date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None
    m = _re.match(r"^(\d{1,2})[-/\s]+([a-zàâéèêîû]+)", s)  # DD-mon
    if m:
        day = int(m.group(1))
        mon = _FR_MONTHS.get(m.group(2)[:4]) or _FR_MONTHS.get(m.group(2)[:3])
        if mon:
            try:
                return _date(year, mon, day)
            except ValueError:
                return None
    m = _re.match(r"^(\d{1,2})[-/](\d{1,2})$", s)  # DD/MM
    if m:
        try:
            return _date(year, int(m.group(2)), int(m.group(1)))
        except ValueError:
            return None
    return None


_STAY_RANGE_RE = _re.compile(
    r"(?:arriv\w*\s*)?(\d{1,2})\s*/\s*(\d{1,2})(?:\s*/\s*(\d{2,4}))?"
    r"\s*(?:-|–|—|to|au|a)\s*"
    r"(?:depart\w*\s*)?(\d{1,2})\s*/\s*(\d{1,2})(?:\s*/\s*(\d{2,4}))?",
    _re.IGNORECASE,
)


def _parse_stay_range(text: Any, year: int) -> Optional[tuple[str, str]]:
    """
    Parse villa-roster stay texts — 'Arrival 03/02 - departure 06/02',
    '3/02 - 6/02', '31/01-6/02' (day/month[, year]) — into ISO
    (check_in, check_out). Returns None when no plausible range is found.
    """
    from datetime import date as _date
    m = _STAY_RANGE_RE.search(str(text or ""))
    if not m:
        return None
    d1, m1, y1, d2, m2, y2 = m.groups()
    try:
        yy1 = int(y1) if y1 else year
        yy2 = int(y2) if y2 else year
        if yy1 < 100:
            yy1 += 2000
        if yy2 < 100:
            yy2 += 2000
        ci = _date(yy1, int(m1), int(d1))
        co = _date(yy2, int(m2), int(d2))
        if co <= ci and not y2:
            co = _date(yy2 + 1, int(m2), int(d2))   # stay across New Year
    except ValueError:
        return None
    if co <= ci or (co - ci).days > 60:
        return None
    return ci.isoformat(), co.isoformat()


def _parse_flexible_day(value: Any):
    """Parse a single date-ish cell: ISO, 'DD/MM/YYYY', 'DD-MM-YYYY', 'DD.MM.YYYY'."""
    from datetime import date as _date, datetime as _dt
    raw = str(value or "").split("T")[0].split(" ")[0].strip()
    if not raw:
        return None
    try:
        return _date.fromisoformat(raw)
    except ValueError:
        pass
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y"):
        try:
            return _dt.strptime(raw, fmt).date()
        except ValueError:
            continue
    return None


# Name given to the property when a rooming grid books real nights without ever
# naming the hotel. Deliberately explicit so nobody mistakes it for a real
# property name — it is meant to be renamed on the hotels page.
_UNNAMED_HOTEL = "Hébergement (nom non précisé)"

_YEAR_RE = _re.compile(r"\b(20\d{2})\b")


def _infer_night_year(records: list[dict], default_date: Any) -> int:
    """Which year the per-night columns ("20-juin") belong to.

    A rooming grid names a day and a month and never a year, so the year has to
    come from somewhere else. It used to come from ``events.start_date``, which
    no event in production has ever had set — so every stay fell back to the
    hardcoded "2025-11-10" and 431 nights were booked in **June 2025**, a year
    before the event, printed in the master list right beside flights dated
    2026 (found in the browser, 2026-08-12).

    The travel dates in the file are the reliable signal: they are complete,
    they are numerous, and they describe the same trip as the grid. The most
    frequent year among them wins; ``start_date`` and finally today decide only
    when there is no travel date at all.
    """
    from collections import Counter

    years: Counter = Counter()
    for r in records:
        data = r.get("normalized_data") or {}
        for field in ("departure_date", "arrival_date", "return_departure_date", "check_in_date"):
            m = _YEAR_RE.search(str(data.get(field) or ""))
            if m:
                years[int(m.group(1))] += 1
    if years:
        return years.most_common(1)[0][0]
    try:
        return int(str(default_date)[:4])
    except (ValueError, TypeError):
        return datetime.now(timezone.utc).year


def _parse_night_columns(raw: dict[str, Any], year: int):
    """From per-night date columns (headers like '26-janv' with a truthy cell),
    reconstruct (check_in, check_out) as ISO strings. check_out = last night + 1."""
    from datetime import timedelta
    booked = []
    for k, v in (raw or {}).items():
        if v is None:
            continue
        sv = str(v).strip().lower()
        if sv in ("", "0", "0.0", "nan", "none", "no"):
            continue
        d = _parse_header_date(k, year)
        if d:
            booked.append(d)
    if not booked:
        return None, None
    booked.sort()
    return booked[0].isoformat(), (booked[-1] + timedelta(days=1)).isoformat()


# Corporate org-unit / form-label vocabulary: a "name" made (almost) entirely
# of these words is a department header or a Yes/No cell, never a person
# ("Commercial Operations", "Supply Chain/Logistics/Procurement", "R&D", "No").
_ORG_WORDS = {
    "innovation", "country", "manager", "supply", "chain", "logistics",
    "procurement", "comex", "it", "r&d", "rd", "r", "d", "regulatory",
    "affairs", "bidding", "design", "administration", "office", "commercial",
    "excellence", "operations", "operation", "demand", "planning", "technical",
    "service", "services", "field", "clinical", "management", "general",
    "marketing", "finance", "sales", "legal", "quality", "hr", "human",
    "resources", "engineering", "medical", "customer", "corporate", "business",
    "unit", "function", "department", "specialist", "director", "team",
    "no", "yes", "na", "n/a", "tbc", "tbd",
}


def _is_junk_name(first: Any, last: Any, traveler: Any = "") -> bool:
    """True when the 'name' is an org unit / role / form label, not a person."""
    combined = f"{first or ''} {last or ''} {traveler or ''}".strip()
    if not combined:
        return False
    if _re.fullmatch(r"[\d\s/.\-]+", combined):
        return True            # purely numeric (subtotal row)
    if _ROLE_NOISE.search(combined):
        return True            # "… Total", "Percussion facilitator", …
    tokens = [t for t in _re.split(r"[\s/,&\-]+", combined.lower()) if t]
    if not tokens:
        return False
    org = sum(1 for t in tokens if t in _ORG_WORDS)
    # All tokens are org vocabulary, or nearly all on multi-word labels
    # ("Japan Management/General Affairs" → 3/4).
    return org == len(tokens) or (len(tokens) >= 3 and org / len(tokens) >= 0.75)


def _is_real_person(nd: dict[str, Any]) -> bool:
    """False for parasitic rows (subtotals, job-title labels, fully-empty)."""
    first = (nd.get("first_name") or "").strip()
    last = (nd.get("last_name") or "").strip()
    email = (nd.get("email") or "").strip()
    traveler = (nd.get("traveler_name") or "").strip()
    if not any([first, last, email, traveler]):
        return False           # no identity at all
    if _is_junk_name(first, last, traveler):
        return False           # a department label is not a person, email or not
    if email:
        return True            # a real email → trust it's a person
    return True


def format_signature(source_type: Optional[str], columns: list) -> str:
    """Stable fingerprint of a file's shape: its source type + the set of its
    (normalised) column names. Two uploads with the same layout share it."""
    norm = sorted({str(c).strip().lower() for c in (columns or []) if str(c).strip()})
    basis = f"{source_type or ''}||" + "\x1f".join(norm)
    return hashlib.sha1(basis.encode("utf-8")).hexdigest()


def _user_org_id(supabase: Client, user_id: str) -> Optional[str]:
    try:
        r = supabase.table("users").select("org_id").eq("id", user_id).single().execute()
        return (r.data or {}).get("org_id")
    except Exception:
        return None


def event_project_id(supabase: Client, event_id: str) -> Optional[str]:
    """The project an event belongs to, or None if it cannot be resolved."""
    try:
        r = supabase.table("events").select("project_id").eq("id", event_id).single().execute()
        return (r.data or {}).get("project_id")
    except Exception:
        return None


def known_format_mapping(
    supabase: Client, org_id: Optional[str], project_id: Optional[str], signature: str,
) -> Optional[dict]:
    """The human-confirmed mapping for a previously-seen format IN THIS PROJECT,
    or None (points 5+6).

    Scoped by project, not by organisation: an agency running Coca-Cola and
    Pepsi events under one org must never have one client's confirmed column
    meaning silently apply to the other's file just because both happened to
    export a same-shaped spreadsheet. A format confirmed once inside a project
    is remembered there and nowhere else — cross the project boundary and
    there is no memory, on purpose, matching what a client asked for outright.

    Without ``project_id`` this returns None rather than falling back to an
    org-wide match: no signal is safer than a signal that might be wrong.
    """
    if not org_id or not project_id:
        return None
    try:
        r = (
            supabase.table("column_mapping_templates")
            .select("mapping")
            .eq("org_id", org_id)
            .eq("project_id", project_id)
            .eq("template_name", signature)
            .limit(1)
            .execute()
        )
        rows = r.data or []
        return rows[0].get("mapping") if rows else None
    except Exception:
        return None


def remember_format(
    supabase: Client, org_id: Optional[str], project_id: Optional[str],
    source_type: Optional[str], signature: str, mapping: dict, user_id: str,
) -> None:
    """Memorise a confirmed format for THIS PROJECT so the next matching
    upload arrives pre-filled — a verification to click through, not a
    mapping to build from scratch. Best-effort; never raises.

    Still requires the same human confirmation every time (see
    routers/files.py::map_columns): memory changes how much of the work is
    already done, never whether a person looks at it.
    """
    if not org_id or not project_id or not mapping:
        return
    try:
        existing = (
            supabase.table("column_mapping_templates")
            .select("id")
            .eq("org_id", org_id)
            .eq("project_id", project_id)
            .eq("template_name", signature)
            .limit(1)
            .execute()
        )
        if existing.data:
            supabase.table("column_mapping_templates").update(
                {"mapping": mapping}
            ).eq("id", existing.data[0]["id"]).execute()
        else:
            supabase.table("column_mapping_templates").insert({
                "org_id": org_id,
                "project_id": project_id,
                "source_type": source_type,
                "template_name": signature,
                "mapping": mapping,
                "created_by": user_id,
            }).execute()
    except Exception as exc:
        logger.warning("Failed to memorise format template: %s", exc)


async def start_and_run_consolidation(event_id: str, user_id: str, supabase: Client) -> None:
    """Kick a consolidation if none is already fresh-running. Used after a mapping
    is confirmed (auto or human) so the file's people fuse into the master list."""
    try:
        run_id = start_consolidation_if_idle(event_id, user_id, supabase)
        if run_id:
            await run_consolidation(event_id, run_id, user_id, supabase)
    except Exception as exc:
        logger.error("Background consolidation failed for event %s: %s", event_id, exc)


async def auto_map_and_consolidate(
    file_id: str,
    event_id: str,
    columns: list,
    sample_rows: list,
    user_id: str,
    supabase: Client,
) -> None:
    """
    Background job kicked off right after upload. AI-maps the file, then parks
    it in 'review' for a human to confirm — always, whether or not the
    project has seen this exact layout before (points 5+6).

    A format recognised from THIS project's own history (see
    known_format_mapping) has its mapping pre-filled from that memory instead
    of freshly computed, so the human's job is a verification — read what is
    already filled in, click confirm — rather than mapping from scratch. It is
    never silent: a mapping mistake here is a passport number or a health
    field landing in the wrong column, and memory is meant to save typing, not
    the one human check that catches that before it reaches a hotel or a
    supplier export.

    If the 'review' state isn't migrated, it stays fully automatic (no
    regression, pre-migration fallback). Upload stays instant either way.
    """
    from services.mapping_service import build_mapping_with_report
    try:
        # Respect a mapping the user may have confirmed in the meantime — only
        # auto-map while the file is still 'pending' (no mapping yet).
        cur = (
            supabase.table("uploaded_files")
            .select("import_status, source_type")
            .eq("id", file_id).single().execute()
        )
        cur_data = cur.data or {}
        if cur_data.get("import_status") not in ("pending", None):
            # Already mapped/confirmed elsewhere — just make sure it consolidates.
            await start_and_run_consolidation(event_id, user_id, supabase)
            return

        mapping, report = build_mapping_with_report(columns, sample_rows)
        if not mapping:
            logger.warning("Auto-map produced no mapping for file %s", file_id)
            return

        source_type = cur_data.get("source_type")
        org_id = _user_org_id(supabase, user_id)
        project_id = event_project_id(supabase, event_id)
        signature = format_signature(source_type, columns)
        known = known_format_mapping(supabase, org_id, project_id, signature)
        prefilled = known or mapping

        # Gate for a one-time confirmation IF the 'review' state exists;
        # otherwise stay fully automatic (pre-migration fallback).
        try:
            supabase.table("uploaded_files").update({
                "column_mapping": prefilled,
                "import_status": "review",
            }).eq("id", file_id).execute()
            # Store the per-column report for the review UI (column may not
            # exist pre-migration — best-effort, never breaks the flow).
            try:
                supabase.table("uploaded_files").update(
                    {"mapping_report": report}
                ).eq("id", file_id).execute()
            except Exception:
                pass
            if known:
                logger.info("File %s matches this project's known format — pre-filled, awaiting verification", file_id)
            else:
                logger.info("New format for file %s — awaiting one-time mapping confirmation", file_id)
            return  # wait for human confirmation before consolidating
        except Exception:
            supabase.table("uploaded_files").update({
                "column_mapping": prefilled,
                "import_status": "mapped",
            }).eq("id", file_id).execute()
            logger.info("Auto-mapped file %s (review state unavailable): %d/%d cols",
                        file_id, len(prefilled), len(columns))
    except Exception as exc:
        logger.error("Background auto-mapping failed for file %s: %s", file_id, exc)
        return

    await start_and_run_consolidation(event_id, user_id, supabase)


def start_consolidation_if_idle(event_id: str, user_id: str, supabase: Client) -> Optional[str]:
    """
    Create a consolidation run for the event UNLESS one is already in progress
    (avoids concurrent runs when several files are dropped at once). Returns the
    new run_id to enqueue, or None when a fresh run is already handling it — that
    run re-triggers itself at the end if new files arrived meanwhile.
    """
    from datetime import timedelta
    cutoff = (datetime.now(timezone.utc) - timedelta(minutes=20)).isoformat()
    try:
        running = (
            supabase.table("consolidation_runs")
            .select("id, started_at")
            .eq("event_id", event_id)
            .eq("status", "running")
            .execute()
        )
        for r in (running.data or []):
            if (r.get("started_at") or "") >= cutoff:   # a fresh run is active
                return None
    except Exception as exc:
        logger.warning("Idle check failed, starting a run anyway: %s", exc)
    run_id = str(uuid.uuid4())
    try:
        supabase.table("consolidation_runs").insert({
            "id": run_id,
            "event_id": event_id,
            "triggered_by": user_id,
            "status": "running",
        }).execute()
    except Exception as exc:
        logger.error("Failed to create auto consolidation run: %s", exc)
        return None
    return run_id


async def run_consolidation(
    event_id: str,
    run_id: str,
    user_id: str,
    supabase: Client,
    _depth: int = 0,
) -> None:
    """
    Orchestrate a full consolidation run for an event.

    This function is designed to run as a FastAPI BackgroundTask.
    All exceptions are caught and surfaced through the run record's ``status``
    field (set to ``failed``) rather than propagating as HTTP errors.

    Steps:
    1. Load mapped files
    2. Parse + insert source_records
    3. Build in-memory participant lists from registration and FCM files
    4. Run matching engine
    5. Upsert participants (non-destructive)
    6. Detect duplicate emails
    7. Run full exception detector
    8. Mark files as processed
    9. Finalise run record

    Parameters
    ----------
    event_id:   UUID of the event.
    run_id:     UUID of the consolidation_run record (already created as 'running').
    user_id:    UUID of the user who triggered the run.
    supabase:   Supabase service-role client.
    """
    logger.info("Consolidation started: run_id=%s event_id=%s", run_id, event_id)

    stats: dict[str, int] = {
        "total_source_records": 0,
        "matched_certain": 0,
        "matched_probable": 0,
        "to_verify": 0,
        "not_found": 0,
        "participants_created": 0,
        "participants_updated": 0,
        "exceptions_count": 0,
    }

    try:
        # ---------------------------------------------------------------
        # 0. Self-heal mis-mappings baked into stored column_mapping (e.g. a
        #    "Conf #" holding `phone`, which made every dual-source participant
        #    raise a DATA_CONFLICT). Must run BEFORE the files are re-parsed.
        # ---------------------------------------------------------------
        try:
            from services.mapping_service import repair_stored_mappings
            stats["mappings_repaired"] = repair_stored_mappings(event_id, supabase)
        except Exception as exc:
            logger.warning("Stored-mapping repair failed: %s", exc)

        # ---------------------------------------------------------------
        # 1. Load event metadata (for date incoherence checks)
        # ---------------------------------------------------------------
        event_resp = supabase.table("events").select("start_date, end_date").eq("id", event_id).single().execute()
        event_data = event_resp.data or {}
        event_start = event_data.get("start_date")
        event_end   = event_data.get("end_date")

        # ---------------------------------------------------------------
        # 2. Load mapped files
        # ---------------------------------------------------------------
        mapped_files = get_mapped_files_for_event(supabase, event_id)
        if not mapped_files:
            raise RuntimeError("No mapped files found — consolidation aborted.")

        # ---------------------------------------------------------------
        # 1b. Exceptions describe the CURRENT state of the master list:
        #     wipe the previous run's findings so the exceptions page never
        #     stacks the same issue once per run.
        # ---------------------------------------------------------------
        try:
            supabase.table("exceptions").delete().eq("event_id", event_id).execute()
        except Exception as exc:
            logger.warning("Failed to purge previous exceptions: %s", exc)

        registrations: list[ParticipantRecord] = []
        fcm_records:   list[ParticipantRecord] = []
        # Every record id (re)written THIS run + the files actually parsed:
        # anything else in source_records is a stale copy from an earlier run
        # (records used to be re-inserted with random UUIDs) and gets purged.
        fresh_record_ids: set[str] = set()
        parsed_file_ids: set[str] = set()
        # Per public-form file: how many submissions step 3 read. Compared
        # against a fresh count at the end of the run to catch submissions
        # that landed while the run was already past its read step.
        public_form_counts: dict[str, int] = {}

        # ---------------------------------------------------------------
        # 3. Parse files, insert source_records, build in-memory lists
        # ---------------------------------------------------------------
        for uploaded_file in mapped_files:
            file_id     = uploaded_file["id"]
            source_type = uploaded_file["source_type"]
            mapping     = uploaded_file.get("column_mapping") or {}
            primary_ids: list[str] = []

            # Public registration-form submissions (routers/public_registration.py)
            # are inserted directly as already-normalized source_records — there
            # is no real document in Storage to download for this "file", and it
            # has no column_mapping (nothing to map: the data arrives pre-shaped).
            # Read back what's already there instead of trying to parse a
            # document that doesn't exist. Found via a real submission: the
            # empty-mapping guard below silently skipped this file every run, so
            # the participant's own fields (phone/company/nationality/dietary_
            # requirements) never merged in even though the raw submission was
            # correctly linked and visible on their fiche via the separate
            # orphan-record linking step (2026-07-26).
            if _is_public_form_file(uploaded_file):
                try:
                    primary_ids = _load_public_form_record_ids(supabase, file_id)
                except Exception as exc:
                    logger.warning("Failed to load public-form source_records for file %s: %s", file_id, exc)
                    primary_ids = []
                stats["total_source_records"] += len(primary_ids)
                fresh_record_ids.update(primary_ids)
                parsed_file_ids.add(file_id)
                # Remembered so the tail of the run can detect submissions
                # that arrived after this read and chain a follow-up run.
                public_form_counts[file_id] = len(primary_ids)
            elif not mapping:
                logger.warning("File %s has no column_mapping — skipping.", file_id)
                continue
            else:
                # Read EVERY sheet. The first sheet uses the human-validated mapping;
                # additional sheets (hotel / transfers / departures in a combined
                # master file) are auto-mapped so their data is not lost. Rows that
                # carry a person's name merge into the same participant, and their
                # hotel/transfer columns are extracted afterwards.
                try:
                    sheets = download_all_sheets(
                        supabase, uploaded_file["storage_path"], uploaded_file["original_filename"]
                    )
                except Exception as exc:
                    logger.warning("Multi-sheet read failed for %s (%s); falling back to first sheet", file_id, exc)
                    sheets = {"main": download_and_parse_file(
                        supabase, uploaded_file["storage_path"], uploaded_file["original_filename"])}

                sheet_names = list(sheets.keys())
                for si, sname in enumerate(sheet_names):
                    sdf = sheets[sname]
                    if si == 0:
                        sheet_mapping = mapping                       # human-validated
                    else:
                        sheet_mapping = _auto_sheet_mapping(sdf)      # auto (secondary sheet)
                        if not sheet_mapping:
                            continue
                    raw_rows = sdf.to_dict(orient="records")
                    inserted_ids = parse_and_insert_source_records(
                        supabase=supabase,
                        file_id=file_id,
                        event_id=event_id,
                        df_rows=raw_rows,
                        mapping=sheet_mapping,
                        sheet_key=str(si),
                    )
                    stats["total_source_records"] += len(inserted_ids)
                    fresh_record_ids.update(inserted_ids)
                    parsed_file_ids.add(file_id)
                    if si == 0:
                        primary_ids = inserted_ids

            # Build ParticipantRecord objects from the PRIMARY sheet ONLY (the
            # human-validated profile source). Secondary-sheet rows are NOT turned
            # into profile records — they'd overwrite identity/region/category with
            # their own (often messier) columns and inflate duplicates. Instead
            # they stay unlinked and are attached later by name (domain data only).
            for ci in range(0, len(primary_ids), 200):
                chunk = primary_ids[ci:ci + 200]
                sr_resp = (
                    supabase.table("source_records")
                    .select("id, normalized_data")
                    .in_("id", chunk)
                    .execute()
                )
                # PostgREST/Postgres does not guarantee `.in_()` results come back in
                # the input list's order. Re-sort by that order so ParticipantRecord
                # construction — and therefore any tie-break in match_sources() that
                # relies on "first encountered wins" — is stable across runs on the
                # same source data (audit PROP-002).
                chunk_order = {id_: i for i, id_ in enumerate(chunk)}
                sorted_rows = sorted(sr_resp.data or [], key=lambda r: chunk_order.get(r["id"], 0))
                for sr in sorted_rows:
                    pr = ParticipantRecord(sr["id"], sr.get("normalized_data") or {})
                    if source_type in ("registration", "masterfile"):
                        registrations.append(pr)
                    elif source_type == "fcm":
                        fcm_records.append(pr)

        # ---------------------------------------------------------------
        # 4. Upsert participants from registration records
        # ---------------------------------------------------------------
        # Lookups to dedupe the same person across the 10+ files: by email AND
        # by normalised name (so records with a missing/inconsistent email still
        # merge into one participant instead of creating duplicates).
        by_email: dict[str, dict] = {}
        by_name: dict[str, dict] = {}
        # Same names with the words sorted: the one index that catches
        # "DUPONT Jean" vs "Jean Dupont" without an O(n²) scan, and therefore
        # keeps working on a 500-person event.
        by_sorted_name: dict[str, dict] = {}
        existing_data = fetch_all_participants(supabase, event_id)
        for p in existing_data:
            if p.get("email"):
                by_email[p["email"].lower()] = p
            nk = _name_key(p.get("first_name"), p.get("last_name"))
            if nk:
                by_name.setdefault(nk, p)
            sk = _name_key_sorted(p.get("first_name"), p.get("last_name"))
            if sk:
                by_sorted_name.setdefault(sk, p)

        participant_id_map: dict[str, str] = {}  # source_record_id → participant_id

        skipped_noise = 0
        merge_change_rows: list[dict] = []   # batched change_log (avoid 1/insert)
        allow_fuzzy = len(registrations) <= 1500  # cap the O(n^2) fuzzy dedup
        # Accumulate in memory; write in BATCHES afterwards. Each participant is
        # written once with its final merged state instead of once per source row
        # (turned ~2000 sequential UPDATEs into a handful of bulk upserts).
        touched: dict[str, dict] = {}         # participant_id -> full row (create/merge)
        links: dict[str, list[str]] = {}      # participant_id -> [source_record_id]
        created_ids: set[str] = set()
        for reg in registrations:
            # Use the SPLIT identity, not the raw columns: a registration file
            # very often carries one "Full Name" / "Nom" column holding
            # "MONTOYA HURTADO/MARÍA". Read as-is it produced a fiche with an
            # empty first name and the whole name crammed into the last name —
            # which then broke dedup, the master list and the exports.
            nd = dict(reg.normalized)
            nd["first_name"] = reg.first_name
            nd["last_name"] = reg.last_name

            # Skip parasitic rows (subtotals, job-title labels, fully-empty) — they
            # must not be created as participants (feedback #4).
            if not _is_real_person(nd):
                skipped_noise += 1
                continue

            email = (nd.get("email") or "").strip().lower() or None
            name_key = _name_key(nd.get("first_name"), nd.get("last_name"))

            # 1) match by email; 2) exact same name; 3) fuzzy same name — unless
            #    emails clearly conflict (two different people sharing a name).
            #    Extracted so the behaviour the product rests on can be tested
            #    on its own: see find_matching_participant.
            existing = find_matching_participant(
                nd, by_email, by_name, by_sorted_name, allow_fuzzy=allow_fuzzy
            )

            if existing:
                # Non-destructive merge: keep known values, fill the gaps.
                locked = existing.get("locked_fields") or {}
                merged = merge_participant_fields(existing, nd, locked)
                merged["registration_source_id"] = reg.source_record_id
                update_payload = {k: v for k, v in merged.items() if k in _PARTICIPANT_WRITABLE_FIELDS}
                if len(merge_change_rows) < 5000:
                    for f, newv in update_payload.items():
                        oldv = existing.get(f)
                        if str(oldv or "") != str(newv or ""):
                            merge_change_rows.append({
                                "event_id": event_id, "user_id": user_id,
                                "entity_type": "participant", "entity_id": existing["id"],
                                "field_name": f, "old_value": str(oldv or ""),
                                "new_value": str(newv or ""), "change_reason": "merge",
                            })
                existing.update(update_payload)
                participant_id = existing["id"]
                touched[participant_id] = existing
                if email:
                    by_email[email] = existing
                if name_key:
                    by_name.setdefault(name_key, existing)
                    by_sorted_name.setdefault(" ".join(sorted(name_key.split())), existing)
            else:
                participant_id = str(uuid.uuid4())
                new_participant = {
                    "id": participant_id,
                    "event_id": event_id,
                    "first_name": nd.get("first_name") or "",
                    "last_name":  nd.get("last_name") or "",
                    "email":      nd.get("email"),
                    "company":    nd.get("company"),
                    "phone":      nd.get("phone"),
                    "nationality": nd.get("nationality"),
                    "dietary_requirements": nd.get("dietary_requirements"),
                    "completeness_status": "incomplete",
                    "registration_source_id": reg.source_record_id,
                }
                touched[participant_id] = new_participant
                created_ids.add(participant_id)
                if email:
                    by_email[email] = new_participant
                if name_key:
                    by_name.setdefault(name_key, new_participant)
                    by_sorted_name.setdefault(" ".join(sorted(name_key.split())), new_participant)

            participant_id_map[reg.source_record_id] = participant_id
            links.setdefault(participant_id, []).append(reg.source_record_id)

        stats["participants_created"] = len(created_ids)
        stats["participants_updated"] = len(touched) - len(created_ids)
        stats["skipped_noise_rows"] = skipped_noise
        if skipped_noise:
            logger.info("Skipped %d parasitic (subtotal/label) rows during consolidation", skipped_noise)

        # --- Batched writes (create + merge in one upsert stream) ---
        upsert_rows = []
        for pid, row in touched.items():
            r = {k: row.get(k) for k in _PARTICIPANT_WRITABLE_FIELDS if k in row}
            r["id"] = pid
            r["event_id"] = event_id
            r.setdefault("first_name", row.get("first_name") or "")
            r.setdefault("last_name", row.get("last_name") or "")
            r.setdefault("completeness_status", row.get("completeness_status") or "incomplete")
            # NOT-NULL boolean flags MUST be present on every row: a bulk upsert
            # aligns all rows to a common column set, so a batch mixing existing
            # rows (which carry has_flight) with new ones (which don't) would send
            # has_flight=NULL for the new rows and violate the constraint.
            for _flag in ("has_flight", "has_hotel", "has_transfer", "has_activities"):
                r[_flag] = bool(row.get(_flag))
            upsert_rows.append(r)
        for i in range(0, len(upsert_rows), 100):
            supabase.table("participants").upsert(upsert_rows[i:i + 100]).execute()
        # Keep an id -> full-row lookup: step 5 below (FCM matching) reuses it
        # to flip has_flight/fcm_source_id without a second participants fetch.
        participant_rows_by_id: dict[str, dict] = {r["id"]: r for r in upsert_rows}

        # Link source_records → participant. PostgREST's upsert validates the
        # attempted INSERT row against NOT-NULL constraints BEFORE the ON
        # CONFLICT branch resolves it — a payload missing file_id/event_id/
        # row_index/raw_data raises a constraint violation instead of doing a
        # targeted UPDATE (confirmed empirically against production on
        # 2026-07-21; this is what made commit eec57e6's partial-column
        # upsert crash every run). Batch-fetch the full existing rows first,
        # merge in only the link fields, then upsert whole rows — every
        # NOT-NULL column always has a real value, so the constraint check
        # can never fail, while still collapsing what used to be one
        # .update() call per participant into a handful of chunked calls.
        all_link_sr_ids = [sr_id for sr_ids in links.values() for sr_id in sr_ids]
        if all_link_sr_ids:
            existing_sr_by_id: dict[str, dict] = {}
            for i in range(0, len(all_link_sr_ids), 100):
                chunk = all_link_sr_ids[i:i + 100]
                resp = supabase.table("source_records").select("*").in_("id", chunk).execute()
                for row in (resp.data or []):
                    existing_sr_by_id[row["id"]] = row

            # Keyed by sr_id (not a plain list): a single upsert batch containing
            # the SAME id twice raises "ON CONFLICT DO UPDATE command cannot
            # affect row a second time" in Postgres — the old .update().in_()
            # tolerated duplicate ids in its filter list for free, so this must
            # too. A dict naturally dedupes (last write wins, same as before).
            link_rows_by_id: dict[str, dict] = {}
            for pid, sr_ids in links.items():
                for sr_id in sr_ids:
                    base = existing_sr_by_id.get(sr_id)
                    if base is None:
                        continue  # record vanished mid-run — nothing to link
                    merged = dict(base)
                    merged["participant_id"] = pid
                    merged["match_decision"] = "certain"
                    merged["match_score"] = 100.0
                    merged["match_signals"] = {"source": "registration"}
                    link_rows_by_id[sr_id] = merged
            link_rows = list(link_rows_by_id.values())
            for i in range(0, len(link_rows), 100):
                supabase.table("source_records").upsert(link_rows[i:i + 100]).execute()

        # Bulk-insert the batched merge change-log entries (chunked).
        if merge_change_rows:
            try:
                for i in range(0, len(merge_change_rows), 200):
                    supabase.table("change_log").insert(merge_change_rows[i:i + 200]).execute()
            except Exception as exc:
                logger.warning("Failed to bulk-insert merge change_log: %s", exc)

        # ---------------------------------------------------------------
        # 5. Match FCM records → participants
        # ---------------------------------------------------------------
        match_results = match_sources(registrations, fcm_records)

        # Collect every write instead of issuing it inline — this loop used to
        # make TWO sequential HTTP calls per matched flight (participants +
        # source_records), by far the largest contributor to a multi-minute
        # run on a several-hundred-flight event. Multi-segment semantics are
        # preserved exactly: when a participant has several matches (aller +
        # retour), the LAST one processed in this loop still ends up as their
        # has_flight/fcm_source_id, same as the old sequential .update() calls
        # each overwriting the previous.
        touched_participant_ids: set[str] = set()
        fcm_link_targets: dict[str, dict] = {}

        for mr in match_results:
            if mr.decision in ("certain", "probable") and mr.reg_record:
                p_id = participant_id_map.get(mr.reg_record.source_record_id)
                if p_id:
                    prow = participant_rows_by_id.get(p_id)
                    if prow is not None:
                        prow["has_flight"] = True
                        prow["fcm_source_id"] = mr.fcm_record.source_record_id
                        touched_participant_ids.add(p_id)

                    fcm_link_targets[mr.fcm_record.source_record_id] = {
                        "participant_id": p_id,
                        "match_decision": mr.decision,
                        "match_score": mr.score,
                        "match_signals": mr.signals,
                    }

                    if mr.decision == "certain":
                        stats["matched_certain"] += 1
                    else:
                        stats["matched_probable"] += 1

                        # PROBABLE_MATCH exception for human review
                        from services.exception_service import _insert_exception
                        _insert_exception(
                            supabase=supabase,
                            run_id=run_id,
                            event_id=event_id,
                            exception_type="PROBABLE_MATCH",
                            severity="warning",
                            message=(
                                f"Le vol au nom de « {mr.fcm_record.full_name} » a probablement été rattaché "
                                f"à « {mr.reg_record.full_name} » (score {mr.score:.1f}). "
                                "À confirmer."
                            ),
                            source_record_id=mr.fcm_record.source_record_id,
                            participant_id=p_id,
                            context_data=mr.signals,
                        )
                        stats["exceptions_count"] += 1

            elif mr.decision == "to_verify":
                stats["to_verify"] += 1
            else:
                stats["not_found"] += 1

        # Flush participants: re-upsert only the rows this step touched,
        # reusing the full-row dicts already built (and already NOT-NULL
        # complete) for the earlier participants upsert — no extra fetch.
        if touched_participant_ids:
            flight_rows = [participant_rows_by_id[pid] for pid in touched_participant_ids]
            for i in range(0, len(flight_rows), 100):
                supabase.table("participants").upsert(flight_rows[i:i + 100]).execute()

        # Flush FCM source_records: same NOT-NULL-safe pattern as the
        # registration-link step above — fetch full existing rows first,
        # merge in only the match fields, upsert whole rows.
        if fcm_link_targets:
            fcm_ids = list(fcm_link_targets.keys())
            existing_fcm_by_id: dict[str, dict] = {}
            for i in range(0, len(fcm_ids), 100):
                chunk = fcm_ids[i:i + 100]
                resp = supabase.table("source_records").select("*").in_("id", chunk).execute()
                for row in (resp.data or []):
                    existing_fcm_by_id[row["id"]] = row

            fcm_rows = []
            for sr_id, fields in fcm_link_targets.items():
                base = existing_fcm_by_id.get(sr_id)
                if base is None:
                    continue  # record vanished mid-run — nothing to link
                merged = dict(base)
                merged.update(fields)
                fcm_rows.append(merged)
            for i in range(0, len(fcm_rows), 100):
                supabase.table("source_records").upsert(fcm_rows[i:i + 100]).execute()

        # ---------------------------------------------------------------
        # 6a-1. Purge stale source-record copies from earlier runs (records
        #       used to be re-inserted with random UUIDs each run — the stale
        #       copies carried pre-repair data: junk passports, inflated
        #       hotel counts). Participants were repointed in step 5.
        #       Public-form files are excluded (_purge_scope): their rows are
        #       never re-inserted, so a submission that landed mid-run would
        #       be the only copy — purging it would destroy the registration.
        # ---------------------------------------------------------------
        try:
            stats["stale_records_purged"] = cleanup_stale_source_records(
                event_id, fresh_record_ids, _purge_scope(mapped_files, parsed_file_ids), supabase
            )
        except Exception as exc:
            logger.warning("Stale source-record cleanup failed: %s", exc)

        # ---------------------------------------------------------------
        # 6a-2. Purge junk-name participants ("Commercial Operations", "R&D")
        #       created from department columns; their records are unlinked
        #       and relinked to the right person (via email) in 6b.
        # ---------------------------------------------------------------
        try:
            stats["junk_participants_purged"] = purge_junk_participants(event_id, supabase)
        except Exception as exc:
            logger.warning("Junk participant purge failed: %s", exc)

        # ---------------------------------------------------------------
        # 6a-bis. Sever contaminated links from earlier runs (junk codes,
        #         shared organizer emails) so 6b can relink them correctly.
        # ---------------------------------------------------------------
        try:
            stats["links_sanitized"] = sanitize_participant_links(event_id, supabase)
        except Exception as exc:
            logger.warning("Link sanitization failed: %s", exc)

        # ---------------------------------------------------------------
        # 6b. Match non-registration source records to participants
        # ---------------------------------------------------------------
        doubts = match_non_registration_files_to_participants(event_id, supabase) or []
        # A name reduced to an initial ("Wassim A") was merged to its best
        # candidate — flag a DOUBT so a human can confirm (feedback: fuse but
        # emit a doubt in exceptions).
        if doubts:
            doubt_rows = []
            for d in doubts:
                multi = " (plusieurs candidats)" if d.get("candidates", 1) > 1 else ""
                doubt_rows.append({
                    "run_id": run_id,
                    "event_id": event_id,
                    "participant_id": d["participant_id"],
                    "exception_type": "PROBABLE_MATCH",
                    "severity": "warning",
                    "message": (
                        f"Fusion à vérifier : « {d['rec_name']} » (nom réduit à une initiale) "
                        f"rattaché à « {d['part_name']} »{multi}."
                    ),
                    "context_data": {
                        "record_name": d["rec_name"],
                        "participant_name": d["part_name"],
                        "candidate_count": d.get("candidates", 1),
                        "reason": "initial_based_merge",
                    },
                })
            try:
                for i in range(0, len(doubt_rows), 100):
                    supabase.table("exceptions").insert(doubt_rows[i:i+100]).execute()
                stats["exceptions_count"] += len(doubt_rows)
            except Exception as exc:
                logger.warning("Failed to insert doubt exceptions: %s", exc)

        # ---------------------------------------------------------------
        # 6b-bis. Repair incomplete identities now that every source record is
        #         linked: split a full name stuck in one column, and give a
        #         name to fiches that only had an email. Runs every time so
        #         fiches created by an earlier, buggier run get fixed too.
        # ---------------------------------------------------------------
        try:
            stats["names_backfilled"] = backfill_participant_names(event_id, supabase)
        except Exception as exc:
            logger.warning("Name backfill failed: %s", exc)

        # ---------------------------------------------------------------
        # 6c. Reconcile FCM match stats with reality. Step 5 can report
        #     'not_found' for flight records whose identity is a single
        #     "Traveller" name; step 6b then links them (or creates a client).
        #     Recompute the counters from actual linkage so the dashboard is
        #     accurate: matched_certain + matched_probable = linked, and
        #     not_found = genuinely unlinked flight records.
        # ---------------------------------------------------------------
        try:
            fcm_ids = [f["id"] for f in mapped_files if f.get("source_type") == "fcm"]
            if fcm_ids:
                total_fcm = 0
                linked_fcm = 0
                offset = 0
                while True:
                    res = (
                        supabase.table("source_records")
                        .select("participant_id")
                        .in_("file_id", fcm_ids)
                        .range(offset, offset + 999)
                        .execute()
                    )
                    data = res.data or []
                    total_fcm += len(data)
                    linked_fcm += sum(1 for r in data if r.get("participant_id"))
                    if len(data) < 1000:
                        break
                    offset += 1000
                stats["not_found"] = max(0, total_fcm - linked_fcm)
                stats["to_verify"] = 0
                stats["matched_probable"] = min(stats["matched_probable"], linked_fcm)
                stats["matched_certain"] = max(0, linked_fcm - stats["matched_probable"])
        except Exception as exc:
            logger.warning("Failed to reconcile FCM match stats: %s", exc)

        # ---------------------------------------------------------------
        # 6d. Self-heal residual phantom duplicates (from earlier runs or
        #     first-name-vs-legal-name splits) before extraction/stats.
        # ---------------------------------------------------------------
        try:
            merged_phantoms = merge_duplicate_participants(event_id, supabase)
            stats["phantoms_merged"] = merged_phantoms
            if merged_phantoms:
                stats["participants_created"] = max(0, stats["participants_created"] - merged_phantoms)
        except Exception as exc:
            logger.warning("Phantom duplicate merge failed: %s", exc)

        # ---------------------------------------------------------------
        # 6d-bis. Exact duplicates: same email AND matching identity, neither
        #     side "thin" enough for the phantom-merge pass above. This is the
        #     shape an event merge produces — the same person fully registered
        #     in each of the merged events survives as two complete fiches
        #     otherwise, invisibly (arbitration explicitly defers score>=93
        #     pairs here; skipping this step makes that deferral a lie).
        # ---------------------------------------------------------------
        try:
            exact_merged = merge_exact_duplicate_participants(event_id, supabase)
            stats["exact_duplicates_merged"] = exact_merged
        except Exception as exc:
            logger.warning("Exact-duplicate merge failed: %s", exc)

        # ---------------------------------------------------------------
        # 6d-bis. Fiches split by a REVERSED name ("DUPONT Jean" vs "Jean
        #     Dupont") and sharing no email — the step above groups by email,
        #     so it cannot see them. Consolidation no longer creates these
        #     (find_matching_participant), but the ones already written would
        #     stay forever: nothing else ever compares two fiches with no
        #     address in common. Runs every consolidation, so it also cleans
        #     up after an import that predates the fix.
        # ---------------------------------------------------------------
        try:
            split_merged = merge_split_name_duplicates(event_id, supabase)
            stats["split_name_duplicates_merged"] = split_merged
        except Exception as exc:
            logger.warning("Split-name duplicate merge failed: %s", exc)

        # ---------------------------------------------------------------
        # 6d-quater. Same name, same phone number, two email addresses. Every
        #     pass above refuses a bucket with two distinct emails — but a
        #     travel export's address is often the BOOKER's, and a corporate
        #     directory carries both eoakes@ and ernest.oakes@ for one person.
        #     An identical mobile number settles what the email cannot.
        # ---------------------------------------------------------------
        try:
            phone_merged = merge_same_phone_duplicates(event_id, supabase)
            stats["same_phone_duplicates_merged"] = phone_merged
        except Exception as exc:
            logger.warning("Same-phone duplicate merge failed: %s", exc)

        # ---------------------------------------------------------------
        # 6d-ter. Fill the EMPTY fields of each fiche from that person's own
        #     source rows. Runs HERE and not earlier: every record is linked
        #     (6b) and every duplicate is merged (6d), so a fiche now sees all
        #     the rows that belong to it — including the ones a merge just
        #     brought over. Runs BEFORE step 8/9 so exceptions and
        #     completeness are computed on the enriched state, not on gaps
        #     the run itself was about to close.
        # ---------------------------------------------------------------
        try:
            stats["fields_backfilled"] = enrich_participants_from_sources(
                event_id, supabase, user_id
            )
        except Exception as exc:
            logger.warning("Profile field backfill failed: %s", exc)

        # ---------------------------------------------------------------
        # 6e. Duplicate emails — computed on the FINAL participants (after
        #     merges), one exception per email. Six rows of the same person
        #     across six files are ONE participant, not six alerts.
        # ---------------------------------------------------------------
        try:
            dup_count = detect_duplicate_participant_emails(run_id, event_id, supabase)
            stats["exceptions_count"] += dup_count
        except Exception as exc:
            logger.warning("Duplicate-email detection failed: %s", exc)

        # ---------------------------------------------------------------
        # 6f. AI arbitration of the ambiguous middle band: similar-but-not-certain
        #     participant pairs are arbitrated by the LLM — confident duplicates
        #     are merged automatically, the rest queued in match_candidates for a
        #     human to resolve side-by-side. Never blocks the run: it's fully
        #     wrapped and degrades to a no-op if the AI or table is unavailable.
        # ---------------------------------------------------------------
        try:
            arb = detect_ambiguous_duplicate_participants(event_id, run_id, user_id, supabase)
            stats["ai_auto_merged"] = arb.get("auto_merged", 0)
            stats["match_candidates"] = arb.get("candidates", 0)
        except Exception as exc:
            logger.warning("Ambiguous-duplicate arbitration failed: %s", exc)

        # ---------------------------------------------------------------
        # 7. Extract flights, hotels, transfers, and activities from source
        #    records. MUST run before exception detection: this is the step
        #    that sets participants' has_flight/has_hotel/has_transfer/
        #    has_activities, and the coverage detectors read exactly those
        #    flags. Detecting first meant every first consolidation reported
        #    "300 participants sans hôtel" from flags that were about to be
        #    filled in one step later — and once those gaps escalated to a
        #    "suspected mapping anomaly" warning (2026-08-01), the stale read
        #    turned into a loud false alarm telling the organizer to go check
        #    a mapping that was perfectly fine (observed on Sales Convention
        #    2027, 2026-08-03: hotel + transfer flagged at 300/300 while the
        #    database had all 300 correctly covered).
        # ---------------------------------------------------------------
        extract_domain_data_from_sources(event_id, supabase)

        # ---------------------------------------------------------------
        # 7b. Pair the fiches that share a room (feedback §4). Runs after
        #     extraction because the requested room type only reaches the
        #     fiche once the hotel rows have been read, and before step 8 so
        #     the "roommate manquant" alerts describe the final state rather
        #     than a link this run was about to make.
        # ---------------------------------------------------------------
        rooming: dict[str, Any] = {"linked": 0, "unresolved": [], "available": False}
        try:
            rooming = resolve_roommates(event_id, supabase)
            stats["roommates_linked"] = rooming.get("linked", 0)
        except Exception as exc:
            logger.warning("Roommate resolution failed: %s", exc)

        # ---------------------------------------------------------------
        # 7c. Give the participants with no rooming row the stay their
        #     flights imply, and stamp every night program/extension
        #     (feedback §2/§3). After extraction, so an imported rooming
        #     list is already in place and is compared rather than
        #     overwritten.
        # ---------------------------------------------------------------
        nights: dict[str, Any] = {"derived": 0, "extension_nights": 0, "mismatches": []}
        try:
            nights = derive_nights_from_flights(event_id, supabase, event_start, event_end)
            stats["nights_derived"] = nights.get("derived", 0)
            stats["extension_nights"] = nights.get("extension_nights", 0)
        except Exception as exc:
            logger.warning("Night derivation failed: %s", exc)

        # ---------------------------------------------------------------
        # 8. Full exception detection — now reading the final state.
        # ---------------------------------------------------------------
        exc_count = exception_service.detect_all(
            event_id=event_id,
            run_id=run_id,
            supabase=supabase,
            event_start_date=event_start,
            event_end_date=event_end,
            unresolved_roommates=rooming.get("unresolved") or [],
            night_mismatches=nights.get("mismatches") or [],
        )
        stats["exceptions_count"] += exc_count

        # ---------------------------------------------------------------
        # 9. Update completeness_status on all participants. Stays AFTER
        #    detection: it marks a participant 'conflict' based on the
        #    DATA_CONFLICT exceptions step 8 just wrote.
        # ---------------------------------------------------------------
        _update_completeness_statuses(event_id, supabase)

        # ---------------------------------------------------------------
        # 10. Mark files as processed
        # ---------------------------------------------------------------
        for f in mapped_files:
            supabase.table("uploaded_files").update({"import_status": "processed"}).eq("id", f["id"]).execute()

        # ---------------------------------------------------------------
        # 11. Finalise run record
        # ---------------------------------------------------------------
        # A running TOTAL, not a per-run counter. Every other key in `stats`
        # counts what this particular run did, so the dashboard's "since
        # yesterday" delta had nothing meaningful to subtract: a run that
        # created 13 fiches followed by one that created none read as
        # "-13 nouveaux participants". The trend line was equally starved —
        # it charts stats.participants_total, which nothing ever wrote.
        try:
            resp = (
                supabase.table("participants")
                .select("id", count="exact")
                .eq("event_id", event_id)
                .limit(1)
                .execute()
            )
            stats["participants_total"] = resp.count or 0
        except Exception as exc:
            logger.warning("Could not record participants_total for run %s: %s", run_id, exc)

        supabase.table("consolidation_runs").update({
            "status": "completed",
            "stats": stats,
            "completed_at": datetime.now(timezone.utc).isoformat(),
        }).eq("id", run_id).execute()

        # Summary change_log entry
        log_change(
            supabase=supabase,
            event_id=event_id,
            user_id=user_id,
            entity_type="consolidation_run",
            entity_id=run_id,
            field_name="status",
            old_value="running",
            new_value="completed",
            reason="import",
        )

        logger.info("Consolidation completed: run_id=%s stats=%s", run_id, stats)

        # Re-fuse if a file was uploaded DURING this run (rapid multi-file drop):
        # such a file is still 'mapped' (this run only marked its own snapshot
        # 'processed'). Same for a public-form submission that landed after
        # step 3 read the virtual file — without this it would sit invisible
        # until the next trigger. Chain one more run, depth-capped to avoid loops.
        if _depth < 5:
            try:
                late = (
                    supabase.table("uploaded_files")
                    .select("id")
                    .eq("event_id", event_id)
                    .eq("import_status", "mapped")
                    .limit(1)
                    .execute()
                )
                if late.data or _late_public_form_submissions(supabase, event_id, public_form_counts):
                    next_run_id = str(uuid.uuid4())
                    supabase.table("consolidation_runs").insert({
                        "id": next_run_id,
                        "event_id": event_id,
                        "triggered_by": user_id,
                        "status": "running",
                    }).execute()
                    logger.info("New files arrived during run — chaining consolidation %s (depth %d)", next_run_id, _depth + 1)
                    await run_consolidation(event_id, next_run_id, user_id, supabase, _depth=_depth + 1)
            except Exception as exc:
                logger.warning("Failed to chain follow-up consolidation: %s", exc)

    except Exception as exc:
        logger.error("Consolidation FAILED: run_id=%s: %s", run_id, exc, exc_info=True)
        try:
            supabase.table("consolidation_runs").update({
                "status": "failed",
                "stats": stats,
                "completed_at": datetime.now(timezone.utc).isoformat(),
            }).eq("id", run_id).execute()
        except Exception as update_exc:
            logger.error("Failed to mark run as failed: %s", update_exc)


def _update_completeness_statuses(event_id: str, supabase: Client) -> None:
    """
    Recompute and update ``completeness_status`` for all participants of an event.

    A participant is:
    - ``complete``:   has first_name, last_name, email, AND has_flight
    - ``conflict``:   has exceptions of type DATA_CONFLICT (checked separately)
    - ``incomplete``: otherwise
    """
    try:
        # Participants with an unresolved data conflict get status 'conflict'.
        conflict_ids: set[str] = set()
        try:
            conf = (
                supabase.table("exceptions")
                .select("participant_id")
                .eq("event_id", event_id)
                .eq("exception_type", "DATA_CONFLICT")
                .eq("resolved", False)
                .execute()
            )
            conflict_ids = {r["participant_id"] for r in (conf.data or []) if r.get("participant_id")}
        except Exception as exc:
            logger.warning("Failed to load conflict exceptions for completeness: %s", exc)

        participants = (
            supabase.table("participants")
            .select("id, first_name, last_name, email, has_flight")
            .eq("event_id", event_id)
            .execute()
        )
        # Bucket participants by target status, then issue one UPDATE per status
        # (chunked) instead of one UPDATE per participant — avoids N+1 on big events.
        buckets: dict[str, list[str]] = {"conflict": [], "complete": [], "incomplete": []}
        for p in participants.data or []:
            if p["id"] in conflict_ids:
                status_val = "conflict"
            elif p.get("first_name") and p.get("last_name") and p.get("email") and p.get("has_flight"):
                status_val = "complete"
            else:
                status_val = "incomplete"
            buckets[status_val].append(p["id"])

        for status_val, ids in buckets.items():
            for i in range(0, len(ids), 100):
                chunk = ids[i:i + 100]
                if chunk:
                    supabase.table("participants").update(
                        {"completeness_status": status_val}
                    ).in_("id", chunk).execute()
    except Exception as exc:
        logger.warning("Failed to update completeness_status: %s", exc)


def combine_to_iso_timestamp(date_val: Any, time_val: Any, default_date: str = "2025-11-10") -> str:
    import re
    # Clean inputs
    d_str = str(date_val or "").strip()
    t_str = str(time_val or "").strip()
    
    # Check if either is already a full ISO datetime (contains YYYY-MM-DD and THH:MM)
    iso_pattern = re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}")
    if iso_pattern.search(d_str):
        val = d_str.replace(" ", "T")
        if not val.endswith("Z") and "+" not in val:
            val += "Z"
        return val
    if iso_pattern.search(t_str):
        val = t_str.replace(" ", "T")
        if not val.endswith("Z") and "+" not in val:
            val += "Z"
        return val

    # Extract date (YYYY-MM-DD)
    date_pattern = re.compile(r"(\d{4}[-/]\d{2}[-/]\d{2})|(\d{2}[-/]\d{2}[-/]\d{4})")
    match_d = date_pattern.search(d_str)
    
    target_date = default_date
    if match_d:
        raw_date = match_d.group(0).replace("/", "-")
        parts = raw_date.split("-")
        if len(parts[0]) == 2: # DD-MM-YYYY
            target_date = f"{parts[2]}-{parts[1]}-{parts[0]}"
        else: # YYYY-MM-DD
            target_date = raw_date
            
    # Extract time — supports 24h ("16:50"), 1-digit hours ("9:00") and 12-hour
    # AM/PM ("4:50 PM", "11:45 AM"). The old pattern required a 2-digit hour and
    # ignored AM/PM, so every "4:50 PM" silently became 00:00.
    time_pattern = re.compile(r"(\d{1,2}):(\d{2})(?::(\d{2}))?\s*([AaPp][Mm])?")
    match_t = time_pattern.search(t_str) or time_pattern.search(d_str)

    target_time = "00:00:00"
    if match_t:
        hh = int(match_t.group(1))
        mm = match_t.group(2)
        ss = match_t.group(3) or "00"
        ampm = (match_t.group(4) or "").lower()
        if ampm == "pm" and hh < 12:
            hh += 12
        elif ampm == "am" and hh == 12:
            hh = 0
        if 0 <= hh <= 23:
            target_time = f"{hh:02d}:{mm}:{ss}"

    return f"{target_date}T{target_time}Z"


# Same two patterns combine_to_iso_timestamp uses to recognise a real calendar
# date — shared here so a caller can ask "would this actually parse?" BEFORE
# committing to build a row, instead of after the fact.
_REAL_DATE_ISO_RE = _re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}")
_REAL_DATE_RE = _re.compile(r"(\d{4}[-/]\d{2}[-/]\d{2})|(\d{2}[-/]\d{2}[-/]\d{4})")


def _has_real_date(data: dict[str, Any], *fields: str) -> bool:
    """
    True when at least one of ``fields`` actually spells out a calendar date —
    either on its own (``departure_date: "2026-02-03"``) or embedded in a
    datetime (``departure_time: "2026-02-03 18:30"``).

    Used to gate flight/transfer row creation: a lone reference code with no
    date anywhere is not evidence of a booked segment, and letting it through
    only forces ``combine_to_iso_timestamp`` to invent one (the fixed
    "2025-11-10" fallback, since no event in production has ``start_date``
    set) — a fabricated date presented as if it were real. Refusing to create
    the row is not "losing" data: nothing usable was there to begin with.
    """
    for f in fields:
        v = str(data.get(f) or "")
        if v and (_REAL_DATE_ISO_RE.search(v) or _REAL_DATE_RE.search(v)):
            return True
    return False


def _clean_flight_number(raw: Any) -> str:
    """
    Normalise a flight number so duplicates collapse: strip the Excel float
    artifact ('4777.0' -> '4777') and pull the flight code out of a value that
    also carries the airline name ('TURKISH AIRLINES INC. 4777.0' -> '4777',
    'VIETNAM AIRLINES 143.0' -> '143'). Keeps IATA-style codes ('TK4777').
    """
    s = str(raw or "").strip().upper()
    s = _re.sub(r"\.0+$", "", s)            # '4777.0' -> '4777'
    codes = _re.findall(r"[A-Z]{0,3}\d{1,4}[A-Z]?", s)
    return codes[-1] if codes else s


def _token_name_match(name_toks: list[str], p_tokens: set[str]) -> bool:
    """
    True when every FULL (2+ letter) token of the record name is present in the
    participant's name tokens, and every single-letter INITIAL matches the start
    of a distinct remaining participant token. Handles 'Wassim M Abdoun',
    'Wassim Abdoun', 'Wassim A', 'W Abdoun' → 'Wassim Mohamed Abdoun'.
    """
    full = [t for t in name_toks if len(t) > 1]
    if not full or not all(t in p_tokens for t in full):
        return False
    remaining = [t for t in p_tokens if t not in full]
    for ini in [t for t in name_toks if len(t) == 1]:
        idx = next((i for i, t in enumerate(remaining) if t.startswith(ini)), None)
        if idx is None:
            return False
        remaining.pop(idx)      # a participant token can back only ONE initial
    return True


def match_non_registration_files_to_participants(event_id: str, supabase: Client):
    """
    Match source_records from non-registration files (hotel, transfer, activity)
    to the correct participant based on registration code, email, or name.
    """
    logger.info("Matching non-registration files to participants for event_id=%s", event_id)
    try:
        parts_resp = supabase.table("participants").select("id, first_name, last_name, email, registration_source_id").eq("event_id", event_id).execute()
        participants = parts_resp.data or []
    except Exception as exc:
        logger.error("Failed to load participants for non-registration mapping: %s", exc)
        return

    # NOTE: an empty participant list is NOT a reason to bail out — with a lone
    # travel/hotel file (no registration list at all), every record below simply
    # falls through to client auto-creation, which IS the master list.

    reg_sr_ids = [p["registration_source_id"] for p in participants if p.get("registration_source_id")]
    reg_sr_map = {}
    if reg_sr_ids:
        for k in range(0, len(reg_sr_ids), 100):
            chunk = reg_sr_ids[k:k+100]
            try:
                sr_resp = supabase.table("source_records").select("id, normalized_data").in_("id", chunk).execute()
                for sr in sr_resp.data or []:
                    reg_sr_map[sr["id"]] = sr["normalized_data"] or {}
            except Exception as exc:
                logger.error("Failed to load registration source records chunk: %s", exc)

    part_lookup = []
    for p in participants:
        reg_data = reg_sr_map.get(p.get("registration_source_id"), {})
        reg_code = (reg_data.get("id") or reg_data.get("participant_id") or "").strip().lower()
        if not _is_plausible_code(reg_code):
            reg_code = ""   # ignore junk codes ('yes'/'no'/…) — never match on them
        first_n = _norm_name(p.get("first_name"))
        last_n = _norm_name(p.get("last_name"))
        part_lookup.append({
            "id": p["id"],
            "first_name": (p["first_name"] or "").strip().lower(),
            "last_name": (p["last_name"] or "").strip().lower(),
            "email": (p["email"] or "").strip().lower(),
            "reg_code": reg_code,
            "first_n": first_n,
            "last_n": last_n,
            "first1": first_n.split()[0] if first_n else "",
            "first_collapsed": first_n.replace(" ", ""),
            "last_collapsed": last_n.replace(" ", ""),
            "tokens": set((first_n + " " + last_n).split()),
        })

    # Index participants by (space-insensitive) last name, to reconcile emailless
    # travel records whose first name differs entirely (English vs legal name).
    last_index: dict[str, list[str]] = {}
    for p in part_lookup:
        if p["last_collapsed"]:
            last_index.setdefault(p["last_collapsed"], []).append(p["id"])

    # Process EVERY source record not yet linked to a participant. This covers
    # separate fcm/hotel/transfer/activity files AND the secondary sheets of a
    # master file (hotel / transfers) — the registration primary sheet is already
    # linked, so it is skipped. Paginated (PostgREST caps at 1000).
    records = []
    try:
        offset = 0
        page = 1000
        while True:
            res = (
                supabase.table("source_records")
                .select("id, file_id, event_id, row_index, raw_data, normalized_data, participant_id")
                .eq("event_id", event_id)
                .is_("participant_id", "null")
                .range(offset, offset + page - 1)
                .execute()
            )
            data = res.data or []
            records.extend(data)
            if len(data) < page:
                break
            offset += page
    except Exception as exc:
        logger.error("Failed to load unlinked source records for matching: %s", exc)
        return

    if not records:
        return

    updates = []
    # Records that match nobody are attached to a NEW participant/client so their
    # info is never orphaned (feedback: every info must belong to a person).
    new_parts: list[dict] = []
    new_by_key: dict[str, str] = {}
    # Name-key of the client that first claimed each email — lets us tell a
    # personal email (same owner) from a shared booking contact (different name).
    new_email_owner_nk: dict[str, str] = {}
    # Tentative (initial-based) links to flag as a doubt in the exceptions.
    doubt_links: list[dict] = []
    for rec in records:
        normalized = rec.get("normalized_data") or {}
        raw = rec.get("raw_data") or {}

        # Flight/hotel files usually carry the identity as a single "Traveller"
        # field ("LAI/Chun Chi" = LAST/First, "Nakagawa, Tatsuhito", "First Last").
        # ONE shared splitter for the whole engine (see resolve_identity_name) —
        # this used to be a second, slightly different copy of the same logic.
        _rf, _rl = resolve_identity_name(normalized)
        rec_first = _rf.strip().lower()
        rec_last = _rl.strip().lower()
        rec_traveler = (normalized.get("traveler_name") or "").strip().lower()

        # A department label mistaken for a name ("Commercial Operations",
        # "R&D") is NOT an identity: ignore it entirely so the row's email can
        # match its true owner, and no junk client is ever created from it.
        if _is_junk_name(rec_first, rec_last, rec_traveler):
            rec_first = rec_last = rec_traveler = ""

        # Order-insensitive matching downstream (token_sort_ratio) tolerates a
        # wrong first/last guess.
        rec_full_name = f"{rec_first} {rec_last}".strip()
        rec_email = (normalized.get("email") or "").strip().lower()
        rec_code = (normalized.get("id") or normalized.get("participant_id") or raw.get("ID Participant") or "").strip().lower()
        if not _is_plausible_code(rec_code):
            rec_code = ""   # never match on junk form values like 'Yes'/'No'

        rec_first_n = _norm_name(rec_first)
        rec_last_n = _norm_name(rec_last)
        rec_first1 = rec_first_n.split()[0] if rec_first_n else ""
        rec_first_collapsed = rec_first_n.replace(" ", "")
        rec_last_collapsed = rec_last_n.replace(" ", "")
        rec_tokens = set((rec_first_n + " " + rec_last_n).split())
        rec_name_joined = f"{rec_first_n} {rec_last_n}".strip()
        rec_name_toks = rec_name_joined.split()
        # A DOUBT case: the surname or the given name itself is reduced to a
        # single-letter initial ("Wassim A", "W Abdoun"). A mere middle initial
        # ("Wassim M Abdoun") is NOT a doubt — first and last are still full.
        is_doubt_case = len(rec_name_toks) >= 2 and (len(rec_name_toks[0]) == 1 or len(rec_name_toks[-1]) == 1)

        matched_id = None

        if rec_code:
            for p in part_lookup:
                if p["reg_code"] == rec_code:
                    matched_id = p["id"]
                    break

        # Set when the record's email matched a participant whose NAME clearly
        # designates someone else: the email is then a shared contact column
        # (organizer address repeated on every villa row) and must no longer
        # veto name matching for this record.
        email_is_contact = False

        if not matched_id and rec_email:
            for p in part_lookup:
                if p["email"] == rec_email:
                    # An email column is often a shared CONTACT (villa rosters
                    # repeat one organizer's address on every row). Never let it
                    # override a record name that clearly designates someone
                    # else — leave those rows to name matching below.
                    if (
                        rec_tokens and p["tokens"]
                        and not (rec_tokens & p["tokens"])
                        and fuzz.token_set_ratio(rec_name_joined, f"{p['first_n']} {p['last_n']}") < 70
                    ):
                        email_is_contact = True
                        continue
                    matched_id = p["id"]
                    break

        if not matched_id and rec_full_name:
            for p in part_lookup:
                if not (p["last_n"] and rec_last_n):
                    continue
                # Skip only when BOTH have an email and they clearly differ
                # (two distinct people sharing a name) — unless the email was
                # exposed as a shared contact column above.
                if not email_is_contact and rec_email and p["email"] and rec_email != p["email"]:
                    continue
                # Same last name — space/hyphen insensitive ("Abu Shinnar" vs
                # "AbuShinnar").
                same_last = p["last_n"] == rec_last_n or p["last_collapsed"] == rec_last_collapsed
                same_first = (
                    (p["first1"] and rec_first1 and p["first1"] == rec_first1)
                    or (p["first_collapsed"] and rec_first_collapsed and p["first_collapsed"] == rec_first_collapsed)
                )
                # Strong: same last name + same given name (tolerates middle names,
                # patronymics, spaces/hyphens, NOM/Prénom departures format).
                if same_last and same_first:
                    matched_id = p["id"]
                    break
                # Subset: one full name's tokens contained in the other's.
                if same_last and rec_tokens and p["tokens"] and (
                    rec_tokens <= p["tokens"] or p["tokens"] <= rec_tokens
                ):
                    matched_id = p["id"]
                    break
                # Clean token match with a MIDDLE initial ("Wassim M Abdoun"):
                # first & last are full, so it's confident — no doubt.
                if not is_doubt_case and _token_name_match(rec_name_toks, p["tokens"]):
                    matched_id = p["id"]
                    break

            # Fuzzy — but NOT for doubt cases (a name reduced to an initial like
            # "Wassim A" would fuzzy-match the wrong "Wassim Ali" with false
            # confidence; those go through the doubt path below).
            if not matched_id and not is_doubt_case:
                rec_name_n = rec_name_joined
                best_score = 0
                best_p_id = None
                for p in part_lookup:
                    p_name = f"{p['first_n']} {p['last_n']}".strip()
                    if not p_name:
                        continue
                    if not email_is_contact and rec_email and p["email"] and rec_email != p["email"]:
                        continue
                    # token_set_ratio is robust to extra middle names / word order.
                    score = fuzz.token_set_ratio(rec_name_n, p_name)
                    if score > best_score:
                        best_score = score
                        best_p_id = p["id"]
                if best_score >= 88:
                    matched_id = best_p_id

            # Initial-aware TENTATIVE match for a DOUBT case ("Wassim A",
            # "W Abdoun"): find every participant the name could designate, merge
            # to the best one, and raise a DOUBT. On several candidates we prefer
            # a REGISTERED one (has email/code), per the chosen policy.
            if not matched_id and is_doubt_case:
                cands = [
                    p for p in part_lookup
                    if (email_is_contact or not rec_email or not p["email"] or rec_email == p["email"])
                    and _token_name_match(rec_name_toks, p["tokens"])
                ]
                if cands:
                    registered = [p for p in cands if (p.get("email") or p.get("reg_code"))]
                    pool = registered or cands
                    chosen = max(
                        pool,
                        key=lambda p: (fuzz.token_set_ratio(rec_name_joined, f"{p['first_n']} {p['last_n']}"), p["id"]),
                    )
                    matched_id = chosen["id"]
                    doubt_links.append({
                        "participant_id": matched_id,
                        "rec_name": rec_full_name.title(),
                        "part_name": f"{chosen['first_n']} {chosen['last_n']}".title(),
                        "candidates": len(cands),
                    })

            # Last resort for an emailless travel record whose first name differs
            # entirely from the registration (English name vs legal name on the
            # ticket, e.g. "Tony Tang" vs "Ruizhe Tang"): if exactly ONE registered
            # participant carries that last name, it must be them.
            if not matched_id and (not rec_email or email_is_contact) and rec_last_collapsed:
                same_last_ids = last_index.get(rec_last_collapsed)
                if same_last_ids and len(same_last_ids) == 1:
                    matched_id = same_last_ids[0]

        # A shared contact email must not identify (or deduplicate) a new client.
        if email_is_contact:
            rec_email = ""

        # No existing participant matched → create a client so the info is linked,
        # but skip parasitic rows (subtotals, job-title labels).
        _cand_nd = {"first_name": rec_first, "last_name": rec_last, "email": rec_email, "traveler_name": rec_traveler}
        if not matched_id and (rec_full_name.strip() or rec_email) and _is_real_person(_cand_nd):
            nk = _name_key(rec_first, rec_last)

            # Dedup by name first when the row HAS a name. The email column of a
            # travel file is frequently a shared BOOKING contact (one coordinator
            # booked several passengers) — reusing the email-keyed client would
            # merge distinct travellers onto one person. So only reuse an
            # email-keyed client when this row has no name of its own, or its
            # name matches the client that first claimed that email.
            email_owner = new_by_key.get(rec_email) if rec_email else None
            email_is_shared_contact = bool(
                email_owner and nk and new_email_owner_nk.get(rec_email) not in (None, nk)
            )
            matched_id = new_by_key.get(nk) if nk else None
            if not matched_id and email_owner and not email_is_shared_contact:
                matched_id = email_owner

            if not matched_id and (nk or (rec_email and not rec_full_name.strip())):
                matched_id = str(uuid.uuid4())
                new_parts.append({
                    "id": matched_id,
                    "event_id": event_id,
                    "first_name": (rec_first or "").title(),
                    "last_name": (rec_last or "").title(),
                    # Never stamp a shared booking email onto a distinct traveller.
                    "email": None if email_is_shared_contact else (rec_email or None),
                    "completeness_status": "incomplete",
                })
                if nk:
                    new_by_key[nk] = matched_id
                # Only let an email key a client the FIRST time (its owner), and
                # only when we actually attached that email to the client.
                if rec_email and not email_is_shared_contact and rec_email not in new_by_key:
                    new_by_key[rec_email] = matched_id
                    new_email_owner_nk[rec_email] = nk

        if matched_id:
            updates.append({
                "id": rec["id"],
                "file_id": rec["file_id"],
                "event_id": rec["event_id"],
                "row_index": rec["row_index"],
                "raw_data": rec["raw_data"],
                "normalized_data": rec["normalized_data"],
                "participant_id": matched_id
            })

    # Insert the auto-created clients first (source_records reference them).
    if new_parts:
        logger.info("Creating %d client participant(s) from non-registration files", len(new_parts))
        try:
            for i in range(0, len(new_parts), 100):
                supabase.table("participants").insert(new_parts[i:i+100]).execute()
        except Exception as exc:
            logger.error("Failed to insert auto-created participants: %s", exc)

    if updates:
        logger.info("Matching non-registration records: updating %d records with participant_id...", len(updates))
        try:
            for i in range(0, len(updates), 100):
                supabase.table("source_records").upsert(updates[i:i+100]).execute()
        except Exception as exc:
            logger.error("Failed to bulk update participant_id on source_records: %s", exc)

    # Collapse doubts to one per participant (a person may gather several
    # initial-based records) so the exceptions page shows one card per person.
    by_part: dict[str, dict] = {}
    for d in doubt_links:
        by_part.setdefault(d["participant_id"], d)
    return list(by_part.values())


def cleanup_stale_source_records(
    event_id: str,
    fresh_ids: set[str],
    parsed_file_ids: set[str],
    supabase: Client,
) -> int:
    """
    Delete source_records NOT (re)written by this run. Earlier versions
    re-INSERTED every row with a random UUID on each consolidation, so the table
    stacked one full copy per run — stale copies kept pre-repair normalized_data
    (junk passport_expiry…) and inflated every count. Runs after step 5 so
    participants' registration_source_id already points at the fresh rows.
    Only files parsed THIS run are touched. Stale exceptions referencing the
    strays are dropped first (FK). Returns the number of records deleted.
    """
    if not fresh_ids or not parsed_file_ids:
        return 0
    strays: list[str] = []
    offset = 0
    while True:
        try:
            res = (
                supabase.table("source_records")
                .select("id, file_id")
                .eq("event_id", event_id)
                .range(offset, offset + 999)
                .execute()
            )
        except Exception as exc:
            logger.error("Failed to page source records for stale cleanup: %s", exc)
            return 0
        data = res.data or []
        strays.extend(r["id"] for r in data if r["id"] not in fresh_ids and r.get("file_id") in parsed_file_ids)
        if len(data) < 1000:
            break
        offset += 1000
    if not strays:
        return 0

    deleted = 0
    for i in range(0, len(strays), 100):
        chunk = strays[i:i + 100]
        try:
            supabase.table("exceptions").delete().in_("source_record_id", chunk).execute()
        except Exception as exc:
            logger.warning("Failed to drop stale exceptions chunk: %s", exc)
        try:
            supabase.table("source_records").delete().in_("id", chunk).execute()
            deleted += len(chunk)
        except Exception:
            # A row still FK-referenced must not keep the whole chunk alive.
            for rid in chunk:
                try:
                    supabase.table("source_records").delete().eq("id", rid).execute()
                    deleted += 1
                except Exception as exc2:
                    logger.warning("Stale record %s still referenced, kept: %s", rid, exc2)
    logger.info("Purged %d stale source record(s) for event %s", deleted, event_id)
    return deleted


def backfill_participant_names(event_id: str, supabase: Client) -> int:
    """
    Self-heal fiches whose identity is incomplete while their own source rows
    hold the full name. Two situations, both observed in production:

      * the whole name sits in ``last_name`` ("MONTOYA HURTADO/MARÍA") because
        the file had a single "Full Name" column — split it in place;
      * the fiche has NO name at all, only an email, while the linked flight or
        hotel row carries ``traveler_name: "ACCORSI/SIMONA"`` — the matcher
        linked the row and moved on without ever filling the identity in.

    Fixing the engine alone would leave those fiches broken forever (an import
    is not replayed), so the repair runs on every consolidation. It is strictly
    additive: a field that already has a value is never overwritten, so a name
    a human typed on the fiche always wins.

    Returns the number of participants repaired.
    """
    parts: list[dict] = []
    offset = 0
    while True:
        try:
            res = (
                supabase.table("participants")
                .select("id, first_name, last_name")
                .eq("event_id", event_id)
                .range(offset, offset + 999)
                .execute()
            )
        except Exception as exc:
            logger.warning("Name backfill: participant fetch failed: %s", exc)
            return 0
        data = res.data or []
        parts.extend(data)
        if len(data) < 1000:
            break
        offset += 1000

    # Only the fiches that are actually incomplete.
    broken = {
        p["id"]: p for p in parts
        if not (p.get("first_name") or "").strip() or not (p.get("last_name") or "").strip()
    }
    if not broken:
        return 0

    # Pass 1 — the name is already on the fiche, just not split.
    updates: dict[str, dict] = {}
    still_missing: list[str] = []
    for pid, p in broken.items():
        first, last = resolve_identity_name(p)
        if first and last and (first, last) != (p.get("first_name"), p.get("last_name")):
            updates[pid] = {"first_name": first, "last_name": last}
        elif not (p.get("first_name") or "").strip() and not (p.get("last_name") or "").strip():
            still_missing.append(pid)

    # Pass 2 — nameless fiches: recover the identity from their own source rows.
    for i in range(0, len(still_missing), 100):
        chunk = still_missing[i:i + 100]
        try:
            res = (
                supabase.table("source_records")
                .select("participant_id, normalized_data")
                .in_("participant_id", chunk)
                .execute()
            )
        except Exception as exc:
            logger.warning("Name backfill: source fetch failed: %s", exc)
            continue
        for sr in res.data or []:
            pid = sr.get("participant_id")
            if not pid or pid in updates:
                continue          # first usable row wins; don't fight between rows
            nd = sr.get("normalized_data") or {}
            first, last = resolve_identity_name(nd)
            if not last:
                continue
            if _is_junk_name(first, last, nd.get("traveler_name")):
                continue          # a department label is not an identity
            updates[pid] = {"first_name": first.title(), "last_name": last.title()}

    repaired = 0
    for pid, patch in updates.items():
        try:
            supabase.table("participants").update(patch).eq("id", pid).execute()
            repaired += 1
        except Exception as exc:
            logger.warning("Name backfill failed for %s: %s", pid, exc)

    if repaired:
        logger.info("Backfilled the name of %d participant(s) for event %s", repaired, event_id)
    return repaired


# Fiche fields that can be recovered from the person's OWN source rows, and the
# normalized_data keys allowed to feed each one, in priority order.
#
# A source file almost never labels a column the way the fiche does. LivaNova's
# registration export calls the company column "Business Unit / Corporate
# Function" (→ `function`), and its FCM flight export carries the traveller's
# country under "Book Country" (→ `nationality`/`country` depending on the
# sheet). Every one of those values reached source_records and stopped there:
# the fiche stayed empty while the data sat one click below it in "Données
# sources complètes". Measured on the Istanbul event, 2026-08-11: 99 fiches out
# of 108 had no Société while 101 rows carried the business unit, 103 had no
# nationality while 178 rows carried the country, 9 had no phone while their
# own flight row did.
#
# Only the participant's OWN rows are read (participant_id = this fiche), so
# this can never pull a value off someone else's record.
_PROFILE_BACKFILL_SOURCES: dict[str, tuple[str, ...]] = {
    "email":                ("email",),
    "phone":                ("phone",),
    "company":              ("company", "business_unit", "function"),
    "nationality":          ("nationality", "country"),
    "dietary_requirements": ("dietary_requirements", "food_allergy_info"),
}

# "Do you have any dietary requirements or allergies?" is a yes/no question; the
# requirement itself lives in the follow-up "Please specify" column. Copying the
# ANSWER into dietary_requirements would write the word "no" onto 83 fiches and
# make them count as documented — worse than empty, because nobody would ever
# think to ask again.
_YES_NO_ANSWERS = {
    "yes", "no", "y", "n", "oui", "non", "true", "false", "1", "0",
    "none", "aucun", "aucune", "nothing", "rien", "ras", "n/a", "na",
}


def _is_yes_no(value: Any) -> bool:
    """True for a value that only answers a question instead of holding data."""
    return str(value or "").strip().lower() in _YES_NO_ANSWERS


# Columns migration 009 adds. Selected in their OWN query, never folded into
# _PROFILE_BACKFILL_SOURCES: PostgREST fails the whole select when one column is
# missing, so asking for them alongside the profile fields would take the
# backfill down on every deployment that has not run 009 yet.
_ROOMING_COLUMNS = "id, first_name, last_name, room_type, roommate_name, roommate_participant_id, locked_fields"


def resolve_roommates(event_id: str, supabase: Client) -> dict[str, Any]:
    """Link the fiches that share a room, and report the ones that cannot be.

    Two people who register separately for a twin each write the other's name
    in a free-text box. This reads those boxes off the source rows, pairs them
    through ``rooming_service``, and stores the resolved link both ways.

    Degrades to a clean no-op when migration 009 has not been applied: the
    select fails, nothing is written, and consolidation carries on exactly as
    it did before. Same contract as the arbitration queue before migration 004.

    Returns ``{"linked": n, "unresolved": [...], "available": bool}``.
    """
    from services import rooming_service
    from services.mapping_service import is_placeholder

    try:
        res = (
            supabase.table("participants")
            .select(_ROOMING_COLUMNS)
            .eq("event_id", event_id)
            .execute()
        )
    except Exception as exc:
        logger.info("Roommate resolution skipped (migration 009 not applied?): %s", exc)
        return {"linked": 0, "unresolved": [], "available": False}

    parts = res.data or []
    if not parts:
        return {"linked": 0, "unresolved": [], "available": True}

    # Pull the written roommate name and the requested room type off each
    # fiche's OWN rows. A human-typed value always wins: locked_fields is what
    # somebody corrected by hand on the fiche, and a re-import must not undo it.
    ids = [p["id"] for p in parts if p.get("id")]
    from_sources: dict[str, dict[str, str]] = {}
    for i in range(0, len(ids), 100):
        chunk = ids[i:i + 100]
        try:
            rows = (
                supabase.table("source_records")
                .select("participant_id, normalized_data")
                .in_("participant_id", chunk)
                .execute()
            )
        except Exception as exc:
            logger.warning("Roommate resolution: source fetch failed: %s", exc)
            continue
        for sr in rows.data or []:
            pid = sr.get("participant_id")
            if not pid:
                continue
            nd = sr.get("normalized_data") or {}
            bucket = from_sources.setdefault(pid, {})
            for field, key in (("roommate_name", "roommate"), ("room_type", "room_type")):
                if field in bucket:
                    continue
                value = str(nd.get(key) or "").strip()
                if value and not is_placeholder(value):
                    bucket[field] = value

    resolved_parts: list[dict[str, Any]] = []
    backfill: dict[str, dict[str, Any]] = {}
    for p in parts:
        locked = p.get("locked_fields")
        if isinstance(locked, list):
            locked = {f: True for f in locked}
        elif not isinstance(locked, dict):
            locked = {}

        merged = dict(p)
        patch: dict[str, Any] = {}
        for field, value in (from_sources.get(p.get("id")) or {}).items():
            if str(p.get(field) or "").strip() or locked.get(field):
                continue
            merged[field] = value
            patch[field] = value
        if patch:
            backfill[p["id"]] = patch
        resolved_parts.append(merged)

    links, unresolved = rooming_service.resolve_pairs(
        resolved_parts, same_person_name=_same_person_name, norm_name=_norm_name
    )

    # One write per fiche: the values read off the sources and the resolved
    # link go together, so a fiche is never left holding a name with no link.
    written = 0
    for pid in {*backfill, *links}:
        patch = dict(backfill.get(pid) or {})
        if pid in links:
            patch["roommate_participant_id"] = links[pid]
        if not patch:
            continue
        try:
            supabase.table("participants").update(patch).eq("id", pid).execute()
            written += 1
        except Exception as exc:
            logger.warning("Roommate link write failed for %s: %s", pid, exc)

    linked = sum(1 for target in links.values() if target)
    logger.info(
        "Roommates: %d fiche(s) linked, %d unresolved, %d row(s) written",
        linked, len(unresolved), written,
    )
    return {"linked": linked, "unresolved": unresolved, "available": True}


def enrich_participants_from_sources(
    event_id: str, supabase: Client, user_id: Optional[str] = None
) -> int:
    """
    Fill the EMPTY fields of each fiche from that person's own source rows.

    Step 4 writes a participant's profile from the registration row that created
    it, and step 5 only ever flips ``has_flight`` on an FCM match — so a value
    that arrives on any other row (a flight export's phone, a second sheet's
    business unit, a fiche created by the orphan-linking step) never reaches the
    fiche. This closes that gap, and runs on every consolidation so imports made
    before the fix are repaired too.

    Strictly additive and safe by construction:
      * a field that already holds a value is never touched;
      * ``locked_fields`` (what a human typed) always wins;
      * only rows already linked to THIS participant are read;
      * an email already carried by another fiche of the event is refused — a
        travel file's email column is often the booking contact's, and stamping
        it on a traveller would both mislabel them and make the identity engine
        merge two different people on the next run.

    Returns the number of participants whose fiche gained at least one value.
    """
    from services.mapping_service import is_placeholder

    parts: list[dict] = []
    offset = 0
    select = "id, " + ", ".join(_PROFILE_BACKFILL_SOURCES) + ", locked_fields"
    while True:
        try:
            res = (
                supabase.table("participants")
                .select(select)
                .eq("event_id", event_id)
                .range(offset, offset + 999)
                .execute()
            )
        except Exception as exc:
            logger.warning("Profile backfill: participant fetch failed: %s", exc)
            return 0
        data = res.data or []
        parts.extend(data)
        if len(data) < 1000:
            break
        offset += 1000

    if not parts:
        return 0

    # Emails already spoken for. Used to refuse a shared booking address, and
    # rebuilt as we go so two fiches in the same pass cannot claim the same one.
    taken_emails = {
        str(p.get("email") or "").strip().lower()
        for p in parts if str(p.get("email") or "").strip()
    }

    gaps = {
        p["id"]: p for p in parts
        if any(not str(p.get(f) or "").strip() for f in _PROFILE_BACKFILL_SOURCES)
    }
    if not gaps:
        return 0

    # Candidate values per fiche, gathered from its own rows. Each value keeps
    # the id of the file it came from: "phone changed" is a fact, "phone changed
    # because Tuesday's hotel list said so" is an answer (feedback §19).
    candidates: dict[str, dict[str, Any]] = {}
    origins: dict[str, dict[str, str]] = {}
    ids = list(gaps)
    for i in range(0, len(ids), 100):
        chunk = ids[i:i + 100]
        try:
            res = (
                supabase.table("source_records")
                .select("participant_id, normalized_data, file_id")
                .in_("participant_id", chunk)
                .execute()
            )
        except Exception as exc:
            logger.warning("Profile backfill: source fetch failed: %s", exc)
            continue
        for sr in res.data or []:
            pid = sr.get("participant_id")
            if pid not in gaps:
                continue
            nd = sr.get("normalized_data") or {}
            bucket = candidates.setdefault(pid, {})
            from_file = origins.setdefault(pid, {})
            for field, keys in _PROFILE_BACKFILL_SOURCES.items():
                if field in bucket:
                    continue                      # a higher-priority row won
                for key in keys:
                    value = str(nd.get(key) or "").strip()
                    if not value or is_placeholder(value):
                        continue
                    if field == "dietary_requirements" and _is_yes_no(value):
                        continue
                    bucket[field] = value
                    if sr.get("file_id"):
                        from_file[field] = sr["file_id"]
                    break

    file_sources = _source_types(supabase, {
        fid for per_field in origins.values() for fid in per_field.values()
    })

    updates: dict[str, dict[str, Any]] = {}
    for pid, p in gaps.items():
        locked = p.get("locked_fields")
        if isinstance(locked, list):
            locked = {f: True for f in locked}
        elif not isinstance(locked, dict):
            locked = {}

        patch: dict[str, Any] = {}
        for field, value in (candidates.get(pid) or {}).items():
            if str(p.get(field) or "").strip() or locked.get(field):
                continue
            if field == "email":
                low = value.lower()
                if low in taken_emails:
                    continue                      # shared booking contact
                taken_emails.add(low)
                value = low
            patch[field] = value
        if patch:
            updates[pid] = patch

    changes: list[dict] = []
    repaired = 0
    for pid, patch in updates.items():
        try:
            supabase.table("participants").update(patch).eq("id", pid).execute()
        except Exception as exc:
            logger.warning("Profile backfill failed for %s: %s", pid, exc)
            continue
        repaired += 1
        if user_id and len(changes) < 5000:
            for field, value in patch.items():
                file_id = (origins.get(pid) or {}).get(field)
                changes.append({
                    "event_id": event_id, "user_id": user_id,
                    "entity_type": "participant", "entity_id": pid,
                    "field_name": field, "old_value": "",
                    "new_value": str(value), "change_reason": "import",
                    "source": file_sources.get(file_id, "system"),
                    "source_file_id": file_id,
                })

    if changes:
        _insert_change_log(supabase, changes)

    if repaired:
        logger.info("Backfilled profile fields on %d fiche(s) for event %s", repaired, event_id)
    return repaired


def _source_types(supabase: Client, file_ids: set[str]) -> dict[str, str]:
    """file id -> the origin label its kind implies (feedback §19).

    ``uploaded_files.source_type`` already draws the distinction the feedback
    asks for — FCM export, registration form, hotel list — so an import only
    has to pass it along rather than have it reconstructed from a filename.
    """
    from services import history_service

    ids = [fid for fid in file_ids if fid]
    if not ids:
        return {}
    try:
        res = (
            supabase.table("uploaded_files")
            .select("id, source_type")
            .in_("id", ids)
            .execute()
        )
    except Exception as exc:
        logger.info("Change origins unavailable: %s", exc)
        return {}
    return {
        row["id"]: history_service.FROM_SOURCE_TYPE.get(
            str(row.get("source_type") or ""), history_service.SYSTEM
        )
        for row in (res.data or [])
    }


def _insert_change_log(supabase: Client, rows: list[dict]) -> None:
    """Write audit rows, dropping the §19 columns if migration 015 is absent.

    An audit line without its origin is still an audit line; losing the whole
    batch to gain a column would be the wrong trade.
    """
    def _write(payload: list[dict]) -> None:
        for i in range(0, len(payload), 200):
            supabase.table("change_log").insert(payload[i:i + 200]).execute()

    try:
        _write(rows)
        return
    except Exception as exc:
        logger.info("change_log insert with origins failed (migration 015?): %s", exc)

    stripped = [
        {k: v for k, v in row.items() if k not in ("source", "source_file_id")}
        for row in rows
    ]
    try:
        _write(stripped)
    except Exception as exc:
        logger.warning("Profile backfill change_log insert failed: %s", exc)


def purge_junk_participants(event_id: str, supabase: Client) -> int:
    """
    Delete participants whose 'name' is an org unit / form label ("Commercial
    Operations", "R&D", "No") — created when a department column was mistaken
    for a person name. Their child rows are unlinked (source_records) or
    dropped (flights/nights/transfers/activities/exceptions) so the matcher can
    relink the records to the right person via their email.
    """
    parts: list[dict] = []
    offset = 0
    while True:
        res = (
            supabase.table("participants")
            .select("id, first_name, last_name, email, company, phone")
            .eq("event_id", event_id)
            .range(offset, offset + 999)
            .execute()
        )
        data = res.data or []
        parts.extend(data)
        if len(data) < 1000:
            break
        offset += 1000

    junk = [
        p["id"] for p in parts
        if _is_junk_name(p.get("first_name"), p.get("last_name"))
        and not (p.get("email") or "").strip()
        and not (p.get("company") or "").strip()
        and not (p.get("phone") or "").strip()
    ]
    if not junk:
        return 0

    deleted = 0
    for i in range(0, len(junk), 100):
        chunk = junk[i:i + 100]
        try:
            supabase.table("source_records").update({"participant_id": None}).in_("participant_id", chunk).execute()
        except Exception as exc:
            logger.warning("Unlink records of junk participants failed: %s", exc)
        for table in ("flights", "hotel_nights", "transfers", "participant_activities", "exceptions", "communications"):
            try:
                supabase.table(table).delete().in_("participant_id", chunk).execute()
            except Exception as exc:
                logger.warning("Delete %s of junk participants failed: %s", table, exc)
        try:
            supabase.table("participants").delete().in_("id", chunk).execute()
            deleted += len(chunk)
        except Exception:
            for pid in chunk:
                try:
                    supabase.table("participants").delete().eq("id", pid).execute()
                    deleted += 1
                except Exception as exc2:
                    logger.warning("Delete junk participant %s failed: %s", pid, exc2)
    logger.info("Purged %d junk-name participant(s) for event %s", deleted, event_id)
    return deleted


def sanitize_participant_links(event_id: str, supabase: Client) -> int:
    """
    Sever source_record → participant links that are clearly WRONG. Contaminated
    links persist across runs (the matcher only processes unlinked records): junk
    'id'='Yes' codes and shared organizer emails once collapsed hundreds of
    travellers onto one participant (Chander: 44 flights). A link is severed only
    when the record carries a real name that shares no token (nor collapsed
    substring, nor fuzzy similarity) with the participant's name. Registration-
    anchored records are never touched. Returns the number of links severed;
    the matcher relinks those records right after.
    """
    try:
        parts_resp = (
            supabase.table("participants")
            .select("id, first_name, last_name, registration_source_id")
            .eq("event_id", event_id)
            .execute()
        )
        participants = parts_resp.data or []
    except Exception as exc:
        logger.error("Failed to load participants for link sanitization: %s", exc)
        return 0
    if not participants:
        return 0

    anchored = {p["registration_source_id"] for p in participants if p.get("registration_source_id")}
    pmap: dict[str, tuple[set[str], str, str]] = {}
    for p in participants:
        first_n = _norm_name(p.get("first_name"))
        last_n = _norm_name(p.get("last_name"))
        tokens = set((first_n + " " + last_n).split())
        pmap[p["id"]] = (tokens, f"{first_n} {last_n}".strip(), "".join(sorted(tokens)))

    to_unlink: list[str] = []
    offset = 0
    while True:
        try:
            res = (
                supabase.table("source_records")
                .select("id, participant_id, normalized_data")
                .eq("event_id", event_id)
                .not_.is_("participant_id", "null")
                .range(offset, offset + 999)
                .execute()
            )
        except Exception as exc:
            logger.error("Failed to page linked source records for sanitization: %s", exc)
            break
        data = res.data or []
        for rec in data:
            if rec["id"] in anchored:
                continue
            info = pmap.get(rec.get("participant_id"))
            if not info:
                continue
            nd = rec.get("normalized_data") or {}
            if _is_junk_name(nd.get("first_name"), nd.get("last_name"), nd.get("traveler_name")):
                continue    # a department label contradicts nothing — the email link is right
            toks: set[str] = set()
            for k in ("first_name", "last_name", "traveler_name", "full_name", "name"):
                v = nd.get(k)
                if v:
                    toks |= set(_norm_name(str(v).replace("/", " ")).split())
            if not toks:
                continue    # nameless record — nothing to contradict the link
            p_tokens, p_name, p_collapsed = info
            if toks & p_tokens:
                continue
            # Space variants: "Abu Shinnar" tokens vs collapsed "abushinnar".
            rec_collapsed = "".join(sorted(toks))
            if any(len(t) >= 4 and t in p_collapsed for t in toks) or any(
                len(t) >= 4 and t in rec_collapsed for t in p_tokens
            ):
                continue
            if fuzz.token_set_ratio(" ".join(sorted(toks)), p_name) >= 70:
                continue
            to_unlink.append(rec["id"])
        if len(data) < 1000:
            break
        offset += 1000

    for i in range(0, len(to_unlink), 100):
        try:
            supabase.table("source_records").update({"participant_id": None}).in_(
                "id", to_unlink[i:i + 100]
            ).execute()
        except Exception as exc:
            logger.warning("Failed to unlink mismatched records chunk: %s", exc)
    if to_unlink:
        logger.info("Sanitized %d mismatched participant link(s) for event %s", len(to_unlink), event_id)
    return len(to_unlink)


def merge_duplicate_participants(event_id: str, supabase: Client) -> int:
    """
    Self-heal residual phantom duplicates (e.g. left over from earlier runs): an
    emailless, 'thin' participant (a travel-derived stub with no company/phone)
    is merged into the SINGLE registered participant that shares its last name —
    covering the English-name-vs-legal-name case (Tony↔Ruizhe Tang). Child rows
    (flights/hotels/transfers/activities/source_records) are reassigned first,
    then the phantom is deleted. Returns the number of phantoms merged.
    """
    parts: list[dict] = []
    offset = 0
    while True:
        res = (
            supabase.table("participants")
            .select("id, first_name, last_name, email, company, phone, registration_source_id")
            .eq("event_id", event_id)
            .range(offset, offset + 999)
            .execute()
        )
        data = res.data or []
        parts.extend(data)
        if len(data) < 1000:
            break
        offset += 1000

    groups: dict[str, list[dict]] = {}
    for p in parts:
        lc = _norm_name(p.get("last_name")).replace(" ", "")
        if lc:
            groups.setdefault(lc, []).append(p)

    def _is_thin(m: dict) -> bool:
        # A travel-derived stub: no email, no company, no phone. A real emailless
        # registrant keeps company/phone, so it is left alone.
        return not (
            (m.get("email") or "").strip()
            or (m.get("company") or "").strip()
            or (m.get("phone") or "").strip()
        )

    merges: dict[str, list[str]] = {}   # canonical_id -> [phantom_ids]
    for members in groups.values():
        if len(members) < 2:
            continue
        with_email = [m for m in members if (m.get("email") or "").strip()]
        thin = [m for m in members if _is_thin(m)]

        for m in thin:
            target = None
            if len(with_email) == 1:
                # Single registered person with that last name — the stub is
                # their legal/ticket name (Tony ↔ Ruizhe Tang).
                target = with_email[0]
            elif with_email:
                # Several registered people share the last name (Zhang…):
                # merge only when the given name singles ONE of them out —
                # exact collapsed match, legal name inside the email local
                # part (Jieyu → jieyu.zhang@), or a close typo (Huusam ↔
                # Hussam). Ambiguity keeps everyone separate.
                m_first = _norm_name(m.get("first_name"))
                m_coll = m_first.replace(" ", "")
                m_toks = [t for t in m_first.split() if len(t) >= 4]
                scored: list[tuple[int, dict]] = []
                for t in with_email:
                    t_coll = _norm_name(t.get("first_name")).replace(" ", "")
                    local = _re.sub(r"[^a-z]", "", (t.get("email") or "").split("@")[0].lower())
                    if m_coll and t_coll and m_coll == t_coll:
                        s = 100
                    elif m_coll and local and (m_coll in local or any(tok in local for tok in m_toks)):
                        s = 95
                    elif m_coll and t_coll:
                        s = int(fuzz.ratio(m_coll, t_coll))
                    else:
                        s = 0
                    scored.append((s, t))
                scored.sort(key=lambda x: -x[0])
                if scored and scored[0][0] >= 75 and (len(scored) == 1 or scored[1][0] < 60):
                    target = scored[0][1]
            if target is not None and target["id"] != m["id"]:
                merges.setdefault(target["id"], []).append(m["id"])

        # Typo pair with no email at all (Bharathi / Baharathi Senthil): merge
        # the unregistered spelling into the registered one.
        if not with_email and len(members) == 2:
            a, b = members
            fa = _norm_name(a.get("first_name")).replace(" ", "")
            fb = _norm_name(b.get("first_name")).replace(" ", "")
            if fa and fb and fuzz.ratio(fa, fb) >= 88:
                registered = [x for x in members if x.get("registration_source_id")]
                if len(registered) == 1:
                    keeper = registered[0]
                    loser = b if keeper is a else a
                    if _is_thin(loser):
                        merges.setdefault(keeper["id"], []).append(loser["id"])

    if not merges:
        return 0

    all_phantoms: list[str] = []
    for canonical_id, phantom_ids in merges.items():
        all_phantoms.extend(phantom_ids)
        for i in range(0, len(phantom_ids), 100):
            chunk = phantom_ids[i:i + 100]
            # Reassign EVERY table holding a participant FK — exceptions included,
            # otherwise the delete below is blocked by the FK constraint.
            for table in (
                "flights", "hotel_nights", "transfers", "participant_activities",
                "source_records", "exceptions", "communications",
            ):
                try:
                    supabase.table(table).update({"participant_id": canonical_id}).in_("participant_id", chunk).execute()
                except Exception as exc:
                    logger.warning("Reassign %s during phantom merge failed: %s", table, exc)

    deleted = 0
    for i in range(0, len(all_phantoms), 100):
        chunk = all_phantoms[i:i + 100]
        try:
            supabase.table("participants").delete().in_("id", chunk).execute()
            deleted += len(chunk)
        except Exception:
            # One blocked row must not keep the whole chunk alive — retry one by one.
            for pid in chunk:
                try:
                    supabase.table("participants").delete().eq("id", pid).execute()
                    deleted += 1
                except Exception as exc2:
                    logger.warning("Delete phantom %s failed: %s", pid, exc2)

    logger.info("Merged %d phantom duplicate participant(s) for event %s", deleted, event_id)
    return deleted


def merge_exact_duplicate_participants(event_id: str, supabase: Client) -> int:
    """
    Merge participants that are the SAME PERSON beyond reasonable doubt: an
    identical (normalised) email shared by fiches whose names also match
    (``_same_person_name`` — the strict identity test, not a fuzzy score).

    This exists for a case ``merge_duplicate_participants`` above deliberately
    does NOT cover: two fully-populated fiches (both have email, company,
    phone — neither is a "thin" travel stub). That shape is produced by
    ``event_grouping_service.merge_events``, whose re-consolidation is the only
    thing standing between "two look-alike events merged" and "every shared
    attendee now has two permanent fiches" — silently, since
    ``detect_ambiguous_duplicate_participants`` explicitly skips near-exact
    (score >= 93) pairs on the assumption a later pass merges them. This IS
    that pass.

    A shared email with a NON-matching name is left alone (a booking contact
    address reused across different travellers is common — see
    ``email_is_contact`` elsewhere in this file); it stays visible as a
    DUPLICATE_EMAIL exception instead of being force-merged.
    """
    parts: list[dict] = []
    offset = 0
    while True:
        res = (
            supabase.table("participants")
            .select("id, first_name, last_name, email, phone, company, nationality, registration_source_id")
            .eq("event_id", event_id)
            .range(offset, offset + 999)
            .execute()
        )
        data = res.data or []
        parts.extend(data)
        if len(data) < 1000:
            break
        offset += 1000

    by_email: dict[str, list[dict]] = {}
    for p in parts:
        email = (p.get("email") or "").strip().lower()
        if email:
            by_email.setdefault(email, []).append(p)

    def _pname(p: dict) -> str:
        return f"{p.get('first_name') or ''} {p.get('last_name') or ''}"

    merged = 0
    for email, members in by_email.items():
        if len(members) < 2:
            continue
        # Fold to the richest fiche (registered > has email > most secondary
        # fields) — it survives; everyone else merges into it.
        winner = members[0]
        for m in members[1:]:
            winner, _ = _order_winner_loser(winner, m)
        winner_name = _pname(winner)
        for m in members:
            if m["id"] == winner["id"]:
                continue
            if not _same_person_name(winner_name, _pname(m)):
                continue  # same email, unrelated name — a shared contact, not a duplicate
            if _merge_participant_into(supabase, m["id"], winner["id"]):
                merged += 1

    if merged:
        logger.info("Merged %d exact-duplicate participant(s) for event %s", merged, event_id)
    return merged


def merge_split_name_duplicates(event_id: str, supabase: Client) -> int:
    """
    Retroactive catch-up for one person sitting on two fiches because the
    files spelled their name in a different order.

    ``merge_exact_duplicate_participants`` above groups by EMAIL, so it never
    compares two fiches that share none — and that is exactly the shape this
    defect produced: the registration file supplied the email, the airline
    export supplied the phone, the reversed name kept them apart, and neither
    fiche carries the other's address. Nothing could ever bring them back
    together. Consolidation stopped creating them (see
    find_matching_participant), but the ones already written stay until
    something goes looking for them. This is that something.

    Grouped on the sorted name words, so "DUPONT Jean" and "Jean Dupont" fall
    in the same bucket. Two guards decide what is safe to fold:

      * a bucket holding TWO DIFFERENT email addresses is left entirely alone.
        Those are two people who share a name, and there is no way to tell
        which of them an address-less third fiche belongs to. Being wrong here
        deletes somebody's flight, so the rule is to do nothing;
      * ``_same_person_name`` still has to agree, which rejects the
        one-token containment traps ("Lin Lin" vs "Chenyang Lin").

    Returns the number of fiches folded away.
    """
    parts: list[dict] = []
    offset = 0
    while True:
        res = (
            supabase.table("participants")
            .select("id, first_name, last_name, email, phone, company, nationality, registration_source_id")
            .eq("event_id", event_id)
            .range(offset, offset + 999)
            .execute()
        )
        data = res.data or []
        parts.extend(data)
        if len(data) < 1000:
            break
        offset += 1000

    buckets: dict[str, list[dict]] = {}
    for p in parts:
        key = _name_key_sorted(p.get("first_name"), p.get("last_name"))
        if key:
            buckets.setdefault(key, []).append(p)

    def _pname(p: dict) -> str:
        return f"{p.get('first_name') or ''} {p.get('last_name') or ''}"

    merged = 0
    for members in buckets.values():
        if len(members) < 2:
            continue
        emails = {(m.get("email") or "").strip().lower() for m in members}
        emails.discard("")
        if len(emails) > 1:
            continue          # two people sharing a name — never guess

        winner = members[0]
        for m in members[1:]:
            winner, _ = _order_winner_loser(winner, m)
        winner_name = _pname(winner)
        for m in members:
            if m["id"] == winner["id"]:
                continue
            if not _same_person_name(winner_name, _pname(m)):
                continue
            if _merge_participant_into(supabase, m["id"], winner["id"]):
                merged += 1

    if merged:
        logger.info(
            "Merged %d participant fiche(s) split by a reversed name for event %s",
            merged, event_id,
        )
    return merged


# A travel export carries the MEETING the trip was booked under — FCM calls the
# column "Meetinf name" (sic) or "Reporting 3" — and it maps to activity_name by
# name similarity. Every booking reference then became an "activity": on a real
# event that produced 14 phantom activities beside the 3 genuine ones
# ("BLANK" with 8 attendees, "0", "AA11", seven spellings of the summit's own
# name), and inflated the dashboard's activity coverage, since a participant
# "had an activity" merely because their ticket carried a meeting code
# (2026-08-12).
_MEETING_REF_RE = _re.compile(
    r"^(\d{0,4}[\s-]*)?"                       # optional leading year, even truncated ("026…")
    r"(global\s*)?innovation[\s-]*(summit|meeting|community)"
    r"|^(summit|meeting|congress|convention|conference|reunion|seminaire|séminaire)$"
    r"|^[A-Z]{1,3}\d{1,4}$",                   # a bare booking code: AA11
    _re.IGNORECASE,
)
# Values that name nothing at all. `is_placeholder` covers "n/a" and "-", but a
# roster writes "BLANK" and a spreadsheet writes a bare 0.
_EMPTY_ACTIVITY_VALUES = {"blank", "0", "0.0", "vide", "aucune", "aucun", "none", "no"}


def _is_real_activity(value: Any, event_name: str = "") -> bool:
    """True when this value names an ACTIVITY people attend, not the meeting
    they were booked under, and not a placeholder."""
    from services.mapping_service import is_placeholder

    s = str(value or "").strip()
    if not s or is_placeholder(s):
        return False
    low = s.lower()
    if low in _EMPTY_ACTIVITY_VALUES:
        return False
    if _MEETING_REF_RE.search(_re.sub(r"[^\w\s-]", "", s)):
        return False
    # The event itself is not one of its own activities.
    ev = _re.sub(r"[^a-z0-9]", "", str(event_name or "").lower())
    return not (ev and len(ev) > 4 and ev in _re.sub(r"[^a-z0-9]", "", low))


def _phone_digits(value: Any) -> str:
    """Just the digits, so "(+1) 2142931656" and "+12142931656" compare equal."""
    return "".join(c for c in str(value or "") if c.isdigit())


def derive_nights_from_flights(
    event_id: str,
    supabase: Client,
    event_start: Optional[str] = None,
    event_end: Optional[str] = None,
) -> dict[str, Any]:
    """Give every participant the stay their flights imply (feedback §2/§3).

    Runs after the hotel extraction, and splits the population in two:

      * a participant with NO booked night gets one derived from their travel
        dates, against the event's property. Their Accommodation tab stops
        being empty on an event that already holds everything needed to fill
        it;
      * a participant who DOES have booked nights keeps them untouched — an
        imported rooming list is a fact and a derivation is an inference, so
        the inference never overwrites the fact. It is compared instead, and
        any gap is reported.

    Every night this writes, derived or already booked, is stamped
    ``program`` or ``extension`` against the event's own dates.

    Degrades to a no-op when migration 009 has not been applied.

    Returns ``{"derived", "extension_nights", "mismatches", "available"}``.
    """
    from services import accommodation_service as ACC

    start_day, end_day = ACC.as_day(event_start), ACC.as_day(event_end)
    result: dict[str, Any] = {
        "derived": 0, "extension_nights": 0, "mismatches": [], "available": False,
    }

    try:
        probe = (
            supabase.table("hotel_nights").select("id, night_kind").limit(1).execute()
        )
        _ = probe.data
    except Exception as exc:
        logger.info("Night derivation skipped (migration 009 not applied?): %s", exc)
        return result
    result["available"] = True

    try:
        parts_res = (
            supabase.table("participants")
            .select("id, first_name, last_name")
            .eq("event_id", event_id)
            .execute()
        )
        flights_res = (
            supabase.table("flights")
            .select("participant_id, departure_time, arrival_time")
            .eq("event_id", event_id)
            .execute()
        )
    except Exception as exc:
        logger.warning("Night derivation: fetch failed: %s", exc)
        return result

    participants = {p["id"]: p for p in (parts_res.data or []) if p.get("id")}
    if not participants:
        return result

    by_participant: dict[str, list[dict]] = {}
    for f in flights_res.data or []:
        pid = f.get("participant_id")
        if pid in participants:
            by_participant.setdefault(pid, []).append(f)

    hotel_ids: list[str] = []
    try:
        hotels_res = supabase.table("hotels").select("id, name").eq("event_id", event_id).execute()
        hotel_rows = hotels_res.data or []
        hotel_ids = [h["id"] for h in hotel_rows]
    except Exception as exc:
        logger.warning("Night derivation: hotel fetch failed: %s", exc)
        hotel_rows = []

    booked: dict[str, list[Any]] = {}
    existing_ids: dict[tuple[str, str], str] = {}
    if hotel_ids:
        try:
            for n in fetch_all_hotel_nights(supabase, hotel_ids):
                pid = n.get("participant_id")
                day = ACC.as_day(n.get("night_date"))
                if pid and day:
                    booked.setdefault(pid, []).append(day)
                    existing_ids[(pid, day.isoformat())] = n["id"]
        except Exception as exc:
            logger.warning("Night derivation: existing nights fetch failed: %s", exc)

    # Where derived nights go. Deriving a stay means "they sleep at the event
    # hotel"; when the event has exactly one property that is unambiguous, and
    # when it has several, guessing which would be worse than not deriving.
    target_hotel_id = hotel_rows[0]["id"] if len(hotel_rows) == 1 else None
    if target_hotel_id is None and not hotel_rows:
        try:
            created = supabase.table("hotels").insert(
                {"event_id": event_id, "name": _UNNAMED_HOTEL}
            ).execute()
            target_hotel_id = created.data[0]["id"]
        except Exception as exc:
            logger.warning("Night derivation: could not create placeholder hotel: %s", exc)

    payloads: list[dict[str, Any]] = []
    kind_updates: list[tuple[str, str]] = []
    derived_participants: set[str] = set()

    for pid, person in participants.items():
        flights = by_participant.get(pid) or []
        arrival, departure = ACC.travel_window(flights)
        derived_nights = ACC.nights_between(arrival, departure)
        already = booked.get(pid) or []

        if already:
            # Keep the imported truth; only classify it, and report the gap.
            for day in already:
                kind = ACC.classify_night(day, start_day, end_day)
                night_id = existing_ids.get((pid, day.isoformat()))
                if night_id:
                    kind_updates.append((night_id, kind))
                if kind == ACC.EXTENSION:
                    result["extension_nights"] += 1
            gap = ACC.mismatch(derived_nights, already)
            if gap:
                name = f"{person.get('first_name') or ''} {person.get('last_name') or ''}".strip() or pid
                result["mismatches"].append({
                    "participant_id": pid, "participant_name": name, **gap,
                })
            continue

        if not derived_nights or not target_hotel_id:
            continue

        for day in derived_nights:
            kind = ACC.classify_night(day, start_day, end_day)
            if kind == ACC.EXTENSION:
                result["extension_nights"] += 1
            payloads.append({
                "id": str(uuid.uuid4()),
                "hotel_id": target_hotel_id,
                "participant_id": pid,
                "night_date": day.isoformat(),
                "room_type": "single",
                "status": "requested",   # inferred, not confirmed by any hotel
                "night_kind": kind,
                "source": "derived_from_flights",
            })
        derived_participants.add(pid)

    for i in range(0, len(payloads), 100):
        try:
            supabase.table("hotel_nights").upsert(payloads[i:i + 100]).execute()
        except Exception as exc:
            logger.warning("Night derivation: night upsert failed: %s", exc)

    for night_id, kind in kind_updates:
        try:
            supabase.table("hotel_nights").update({"night_kind": kind}).eq("id", night_id).execute()
        except Exception as exc:
            logger.debug("Night derivation: could not stamp night %s: %s", night_id, exc)

    if derived_participants:
        ids = list(derived_participants)
        for i in range(0, len(ids), 50):
            try:
                supabase.table("participants").update({"has_hotel": True}).in_("id", ids[i:i + 50]).execute()
            except Exception as exc:
                logger.warning("Night derivation: has_hotel update failed: %s", exc)

    result["derived"] = len(derived_participants)
    logger.info(
        "Nights from flights: %d participant(s) given a derived stay, "
        "%d extension night(s), %d mismatch(es)",
        result["derived"], result["extension_nights"], len(result["mismatches"]),
    )
    return result


def roommate_veto(event_id: str, supabase: Client) -> set[frozenset[str]]:
    """Pairs of fiches that must never be merged, because they share a ROOM.

    Roommates are the worst false positive available to a deduplication
    engine, and they defeat every signal it trusts at once: a couple books on
    one email, gives one mobile as the contact, and on a family trip carries
    the same surname. The phone pass added on 2026-08-12 exists precisely to
    merge "same name + same number" — which is exactly what a mother and
    daughter sharing a twin look like from the outside.

    No score can separate those two cases, so this is a veto rather than a
    weight: if the rooming step linked them as sharing a room, they are two
    people, full stop.

    Empty (and harmless) when migration 009 has not been applied.
    """
    try:
        res = (
            supabase.table("participants")
            .select("id, roommate_participant_id")
            .eq("event_id", event_id)
            .execute()
        )
    except Exception as exc:
        logger.debug("Roommate veto unavailable for event %s: %s", event_id, exc)
        return set()

    pairs: set[frozenset[str]] = set()
    for row in res.data or []:
        pid, mate = row.get("id"), row.get("roommate_participant_id")
        if pid and mate and pid != mate:
            pairs.add(frozenset((pid, mate)))
    return pairs


def merge_same_phone_duplicates(event_id: str, supabase: Client) -> int:
    """
    One person on two fiches because the two files gave two email addresses.

    Every other merge pass refuses a bucket holding two different emails — two
    people can share a name, and guessing wrong deletes somebody's flight. But
    a differing email has an innocent explanation the engine never used: on a
    travel export the address is often the BOOKER's, and a corporate directory
    routinely carries both `eoakes@` and `ernest.oakes@` for the same person.

    An identical PHONE NUMBER settles it. Two different people who share a name
    do not share a mobile number, so the pair is the same human being and the
    email veto no longer has anything to protect. Found in production
    (2026-08-12): four people — Adam Birge, Ernest Oakes, Ahmet Tezel, Sujay
    Mashru — each sitting on two fiches with the SAME number written two ways,
    each scored 100/100 by the matcher and each parked in match_candidates
    waiting for a human. The master list meanwhile announced 121 participants,
    four of them counted twice.

    Deliberately narrow: the names must still designate the same person, and
    the number must carry at least 8 digits so a truncated or placeholder value
    cannot bring strangers together.
    """
    parts: list[dict] = []
    offset = 0
    while True:
        res = (
            supabase.table("participants")
            .select("id, first_name, last_name, email, phone, company, nationality, registration_source_id")
            .eq("event_id", event_id)
            .range(offset, offset + 999)
            .execute()
        )
        data = res.data or []
        parts.extend(data)
        if len(data) < 1000:
            break
        offset += 1000

    # Bucketed on the PHONE NUMBER alone. Adding the name to the key looked
    # like a second safety net and was really a blind spot: it demanded the two
    # names be spelled identically, so "Yasmin Sezgin" and "Yasmin Sezgin
    # Stuart" — same mobile, one carrying a maiden name the other omits — never
    # landed in the same bucket and were never even compared (production,
    # 2026-08-12). The name is still decisive, but through _same_person_name
    # below, which understands that one name can contain the other; that is
    # what keeps two strangers on a shared switchboard number apart.
    buckets: dict[str, list[dict]] = {}
    for p in parts:
        digits = _phone_digits(p.get("phone"))
        if len(digits) >= 8 and _name_key_sorted(p.get("first_name"), p.get("last_name")):
            buckets.setdefault(digits, []).append(p)

    def _pname(p: dict) -> str:
        return f"{p.get('first_name') or ''} {p.get('last_name') or ''}"

    # Two people sharing a twin also share a booking email and, very often, one
    # contact number — and on a family trip, a surname too. That is this pass's
    # exact merge signature, so the rooming link overrules it.
    veto = roommate_veto(event_id, supabase)

    merged = 0
    for members in buckets.values():
        if len(members) < 2:
            continue
        winner = members[0]
        for m in members[1:]:
            winner, _ = _order_winner_loser(winner, m)
        winner_name = _pname(winner)
        for m in members:
            if m["id"] == winner["id"]:
                continue
            if not _same_person_name(winner_name, _pname(m)):
                continue
            if frozenset((winner["id"], m["id"])) in veto:
                logger.info(
                    "Refusing to merge %s into %s: they are linked as roommates",
                    m["id"], winner["id"],
                )
                continue
            if _merge_participant_into(supabase, m["id"], winner["id"]):
                merged += 1

    if merged:
        logger.info(
            "Merged %d fiche(s) sharing a name and a phone number for event %s",
            merged, event_id,
        )
    return merged


_MERGE_CHILD_TABLES = (
    "flights", "hotel_nights", "transfers", "participant_activities",
    "source_records", "exceptions", "communications",
)


def _merge_participant_into(supabase: Client, loser_id: str, winner_id: str) -> bool:
    """
    Merge participant ``loser_id`` into ``winner_id``: backfill the winner's
    empty identity fields from the loser (never overwrite), reassign every child
    row (flights/hotels/transfers/activities/source_records/exceptions/comms and
    any other match_candidates), then delete the loser. Returns True on delete.
    Shared by the AI auto-merge step and the human "fusionner" dashboard action.
    """
    if not loser_id or not winner_id or loser_id == winner_id:
        return False
    try:
        w = (supabase.table("participants").select(
            "email, phone, company, nationality, has_flight, has_hotel, has_transfer, has_activities"
        ).eq("id", winner_id).single().execute().data) or {}
        l = (supabase.table("participants").select(
            "email, phone, company, nationality, has_flight, has_hotel, has_transfer, has_activities"
        ).eq("id", loser_id).single().execute().data) or {}
        patch: dict = {}
        for f in ("email", "phone", "company", "nationality"):
            if not (w.get(f) or "").strip() and (l.get(f) or "").strip():
                patch[f] = l[f]
        for flag in ("has_flight", "has_hotel", "has_transfer", "has_activities"):
            if l.get(flag):
                patch[flag] = True
        if patch:
            supabase.table("participants").update(patch).eq("id", winner_id).execute()
    except Exception as exc:
        logger.warning("Merge backfill %s->%s failed: %s", loser_id, winner_id, exc)

    for table in _MERGE_CHILD_TABLES:
        try:
            supabase.table(table).update({"participant_id": winner_id}).eq("participant_id", loser_id).execute()
        except Exception as exc:
            logger.warning("Reassign %s during merge failed: %s", table, exc)

    # Repoint any other candidates that referenced the loser, then drop the
    # self-referential ones this may create.
    try:
        supabase.table("match_candidates").update({"participant_a_id": winner_id}).eq("participant_a_id", loser_id).execute()
        supabase.table("match_candidates").update({"participant_b_id": winner_id}).eq("participant_b_id", loser_id).execute()
    except Exception:
        pass

    try:
        supabase.table("participants").delete().eq("id", loser_id).execute()
        return True
    except Exception as exc:
        logger.warning("Delete merged participant %s failed: %s", loser_id, exc)
        return False


def _order_winner_loser(a: dict, b: dict) -> tuple[dict, dict]:
    """Pick which of two duplicate fiches survives: prefer the registered one,
    then the one with an email, then the richer fiche, then a stable id order."""
    def rank(p: dict) -> tuple:
        return (
            1 if p.get("registration_source_id") else 0,
            1 if (p.get("email") or "").strip() else 0,
            sum(1 for f in ("phone", "company", "nationality") if (p.get(f) or "").strip()),
        )
    ra, rb = rank(a), rank(b)
    if ra != rb:
        return (a, b) if ra > rb else (b, a)
    return (a, b) if str(a.get("id")) <= str(b.get("id")) else (b, a)


def _same_person_name(a: str, b: str) -> bool:
    """
    Strict identity test used for the "same name, different emails" rule.

    rapidfuzz's token_set_ratio returns 100 whenever one token SET is contained
    in the other, so "Lin Lin" (which dedups to the single token {lin}) scored
    100% against "Chenyang Lin" — two different people. We therefore require the
    token sets to be equal, or one to be contained in the other with AT LEAST two
    tokens ("Melcy Romero" ⊂ "Melcy Romero Trujillo" is the same person, while a
    single-token name never is).
    """
    ta = {t for t in _norm_name(a).split() if t}
    tb = {t for t in _norm_name(b).split() if t}
    if not ta or not tb:
        return False
    if ta == tb:
        return True
    small, big = (ta, tb) if len(ta) <= len(tb) else (tb, ta)
    return len(small) >= 2 and small < big


def _fallback_duplicate_exception(supabase: Client, run_id: str, event_id: str, a: dict, b: dict, score: float) -> None:
    """Surface a same-name/different-email duplicate as a POSSIBLE_DUPLICATE
    exception when the match_candidates table isn't migrated yet."""
    try:
        na = f"{a.get('first_name', '')} {a.get('last_name', '')}".strip()
        nb = f"{b.get('first_name', '')} {b.get('last_name', '')}".strip()
        supabase.table("exceptions").insert({
            "run_id": run_id, "event_id": event_id,
            "exception_type": "POSSIBLE_DUPLICATE", "severity": "warning",
            "message": f"Doublon possible : « {na} » ({a.get('email')}) et « {nb} » ({b.get('email')}) — même nom, emails différents.",
            "participant_id": a.get("id"),
            "context_data": {
                "participant_a_id": a.get("id"), "participant_b_id": b.get("id"),
                "name_a": na, "name_b": nb, "email_a": a.get("email"), "email_b": b.get("email"),
                "score": float(score),
            },
            "resolved": False,
        }).execute()
    except Exception as exc:
        logger.warning("Fallback duplicate exception insert failed: %s", exc)


def detect_ambiguous_duplicate_participants(
    event_id: str, run_id: str, user_id: str, supabase: Client
) -> dict:
    """
    Step 6f — AI arbitration of the ambiguous middle band. Find participant pairs
    whose names are similar enough to be suspicious but not certain (rapidfuzz
    ~78-93), skip the ones the data already settles (two different non-empty
    emails = two people), and let the reasoning LLM arbitrate the rest. EVERY
    non-"separer" verdict — including a high-confidence "fusionner" — becomes a
    ``match_candidates`` row for side-by-side human review; the AI never merges
    on its own (PROP-001, applied 2026-08-01: _merge_participant_into is
    destructive and irreversible, and the LLM's confidence score is
    self-declared — a human must see every merge). Bounded by
    ``MAX_ARBITRATIONS_PER_RUN``. Returns ``{"auto_merged", "candidates"}``
    (auto_merged is always 0 now, kept for the stats contract).
    """
    from services import arbitration_service as ARB

    parts: list[dict] = []
    offset = 0
    while True:
        res = (
            supabase.table("participants")
            .select(
                "id, first_name, last_name, email, phone, company, nationality, "
                "has_flight, has_hotel, has_transfer, has_activities, registration_source_id"
            )
            .eq("event_id", event_id)
            .range(offset, offset + 999)
            .execute()
        )
        data = res.data or []
        parts.extend(data)
        if len(data) < 1000:
            break
        offset += 1000

    if len(parts) < 2:
        return {"auto_merged": 0, "candidates": 0}

    def _name(p: dict) -> str:
        return f"{_norm_name(p.get('first_name'))} {_norm_name(p.get('last_name'))}".strip()

    # Blocking: only compare fiches sharing the first 3 letters of the collapsed
    # last name (falls back to first name). Turns an O(n^2) sweep over the whole
    # event into a handful of small buckets.
    blocks: dict[str, list[int]] = {}
    for idx, p in enumerate(parts):
        if not _name(p):
            continue
        last_c = _norm_name(p.get("last_name")).replace(" ", "")
        key = (last_c or _norm_name(p.get("first_name")).replace(" ", ""))[:3]
        if key:
            blocks.setdefault(key, []).append(idx)

    scored_pairs: list[tuple[float, int, int]] = []
    for members in blocks.values():
        for x in range(len(members)):
            i = members[x]
            ni = _name(parts[i])
            for y in range(x + 1, len(members)):
                j = members[y]
                score = fuzz.token_set_ratio(ni, _name(parts[j]))
                if score >= ARB.AMBIGUOUS_MIN:
                    scored_pairs.append((float(score), i, j))
    scored_pairs.sort(key=lambda t: -t[0])

    MAX_CANDIDATES = 100

    # Pending candidates are re-derived from the CURRENT participants on every
    # run, exactly like exceptions: without this, a pair that is no longer a
    # duplicate (or was queued by an older, buggier rule) stays in the dashboard
    # for ever. Resolved candidates are never touched.
    try:
        supabase.table("match_candidates").delete().eq("event_id", event_id).eq("status", "pending").execute()
    except Exception as exc:
        logger.warning("Could not clear pending match candidates: %s", exc)

    # Roommates score very high here — same surname on a family trip, one
    # shared booking email — and every card they generate is one an organizer
    # has to open, read and dismiss. They are two people by definition of
    # sharing a room, so they never reach the queue at all.
    veto = roommate_veto(event_id, supabase)

    auto_merged = 0  # always 0 since PROP-001 — kept for the stats contract
    candidates = 0
    calls = 0
    for score, i, j in scored_pairs:
        if candidates >= MAX_CANDIDATES:
            break
        a, b = parts[i], parts[j]
        if frozenset((a["id"], b["id"])) in veto:
            continue
        ea = (a.get("email") or "").strip().lower()
        eb = (b.get("email") or "").strip().lower()
        diff_email = bool(ea and eb and ea != eb)
        winner, loser = _order_winner_loser(a, b)

        # Same (near-exact) name but DIFFERENT emails: almost certainly ONE person
        # recorded under two addresses. The data can't settle it, so queue it for
        # one-click confirmation in "Fusions à vérifier" — never auto-merge (could
        # be true homonyms). Falls back to a POSSIBLE_DUPLICATE exception if the
        # match_candidates table isn't migrated yet.
        if diff_email:
            if _same_person_name(_name(a), _name(b)):
                verdict = {
                    "decision": "incertain",
                    "justification": "Même nom, deux emails différents — à confirmer.",
                    "confidence": 0.0,
                }
                if not ARB.create_candidate(supabase, event_id, run_id, loser, winner, score, verdict):
                    _fallback_duplicate_exception(supabase, run_id, event_id, winner, loser, score)
                candidates += 1
            continue  # different emails + only a fuzzy name match => different people

        # Same or missing email:
        if score >= ARB.AMBIGUOUS_MAX:
            # Near-exact duplicate. If the email matches too, it was already
            # merged upstream by merge_exact_duplicate_participants (step
            # 6d-bis) — this pair surviving to here means the identity check
            # there disagreed (different name despite the fuzzy name score),
            # so it is correctly left alone rather than force-merged.
            continue
        if calls >= ARB.MAX_ARBITRATIONS_PER_RUN:
            continue  # AI budget spent; low-band pairs wait for the next run
        calls += 1
        verdict = ARB.arbitrate_pair(a, b, score)

        if verdict["decision"] == "separer":
            continue
        # 'fusionner' (any confidence) or 'incertain' -> mandatory human
        # review via the "Fusions à vérifier" queue (PROP-001: the AI never
        # merges on its own; ai_confidence is stored on the candidate so the
        # UI can sort obvious ones first).
        if ARB.create_candidate(supabase, event_id, run_id, loser, winner, score, verdict):
            candidates += 1

    if auto_merged or candidates:
        logger.info(
            "Ambiguous-duplicate arbitration event=%s: %d auto-merged, %d queued (from %d AI calls)",
            event_id, auto_merged, candidates, calls,
        )
    return {"auto_merged": auto_merged, "candidates": candidates}


def _infer_event_city(all_records: list[dict]) -> Optional[str]:
    """
    Infer the event's own city from flight data when events.location_city
    was never set (there is currently no UI to set it). Virtually every
    attendee's RETURN leg departs FROM the event city, so across hundreds of
    distinct home-city departures, only the event city repeats at high
    frequency — real data: "BARCELONE BCN" 300/600 vs every other airport
    under 25/600. The modal departure_airport, when it clearly dominates
    (>=30% of all departures, minimum sample of 10), is a safe stand-in;
    otherwise returns None rather than guessing on thin data.
    """
    dep_counts: dict[str, int] = {}
    for r in all_records:
        d = r.get("normalized_data") or r.get("raw_data") or {}
        apt = str(d.get("departure_airport") or "").strip()
        if apt:
            dep_counts[apt] = dep_counts.get(apt, 0) + 1
    if not dep_counts:
        return None
    top_apt, top_n = max(dep_counts.items(), key=lambda kv: kv[1])
    total = sum(dep_counts.values())
    if top_n >= 10 and top_n >= 0.3 * total:
        return top_apt
    return None


def _fallback_arrival_airport(dep_apt: Optional[str], event_city: str) -> str:
    """
    The event-city fallback (used when a file states no explicit arrival
    airport — common when "everyone lands at the event city" is implicit)
    only makes sense for a flight travelling TO the event. Applying it
    unconditionally also stamped it onto the RETURN leg, which already
    departs FROM the event city — producing a nonsensical "BARCELONE BCN ->
    BARCELONE BCN" self-round-trip (real case, 300/600 flights). Skip the
    fallback when the flight is already departing from the event city.
    """
    if not event_city:
        return ""
    dep = str(dep_apt or "").strip().upper()
    city = str(event_city).strip().upper()
    if dep and (city in dep or dep in city):
        return ""
    return event_city


def extract_domain_data_from_sources(event_id: str, supabase: Client) -> None:
    """
    Extract flights, hotels, transfers, and activities from mapped source_records
    and populate the respective domain tables.
    """
    from datetime import date, timedelta
    logger.info("Extracting domain data from sources for event_id=%s", event_id)

    # Load default event date as fallback
    default_date = "2025-11-10"
    event_city = ""
    event_name = ""
    try:
        ev_resp = supabase.table("events").select("name, start_date, location_city").eq("id", event_id).single().execute()
        if ev_resp.data and ev_resp.data.get("start_date"):
            default_date = str(ev_resp.data["start_date"])
        if ev_resp.data and ev_resp.data.get("location_city"):
            event_city = str(ev_resp.data["location_city"]).strip()
        if ev_resp.data and ev_resp.data.get("name"):
            event_name = str(ev_resp.data["name"]).strip()
    except Exception:
        pass

    # Fetch ALL participant-linked source records once (paginated — PostgREST caps
    # at 1000). We extract from every record regardless of the file's source_type
    # so a single combined "masterfile" (flights + hotel + activities in one sheet)
    # is fully exploited, not just type-specific files. The per-domain field guards
    # below simply skip records that don't carry the relevant columns.
    all_records: list[dict] = []
    try:
        _offset = 0
        while True:
            _res = (
                supabase.table("source_records")
                .select("id, file_id, row_index, participant_id, normalized_data, raw_data")
                .eq("event_id", event_id)
                .not_.is_("participant_id", "null")
                .range(_offset, _offset + 999)
                .execute()
            )
            _data = _res.data or []
            all_records.extend(_data)
            if len(_data) < 1000:
                break
            _offset += 1000
    except Exception as exc:
        logger.error("Failed to load source records for domain extraction: %s", exc)

    # DETERMINISM: two runs over the same sources must produce the same result.
    # Without a stable order, "last write wins" collisions below pick a random
    # record each run (flights flipping airports/times between exports).
    all_records.sort(key=lambda r: (str(r.get("file_id") or ""), r.get("row_index") or 0, str(r.get("id") or "")))

    # There is currently no UI to set events.location_city, so this fallback
    # is empty far more often than not — leaving arrival_airport blank on
    # EVERY flight for a file that (very commonly) never states an explicit
    # arrival airport at all, because "everyone lands at the event city" is
    # implicit in the source file (confirmed real case: a 2-sheet Arrival/
    # Departure FCM export with no arrival-airport column whatsoever, 600/600
    # flights left with arrival_airport=""). Infer it from the data itself
    # instead of leaving it unset. Also feeds the transfers pickup/dropoff
    # fallback below, which relies on the same `event_city` variable.
    if not event_city:
        inferred = _infer_event_city(all_records)
        if inferred:
            event_city = inferred
            logger.info("event_id=%s: location_city unset, inferred event city %r from departure_airport frequency", event_id, event_city)

    # 1. Flights Extraction (any record exposing flight fields)
    try:
        if all_records:
            # Existing flights: reuse ids on upsert; anything not regenerated
            # this run is STALE (a leftover of contaminated links) and deleted.
            existing_flights = supabase.table("flights").select("id, participant_id, flight_number, departure_time").eq("event_id", event_id).execute()
            existing_rows = existing_flights.data or []
            existing_flights_map = {}
            for f in existing_rows:
                k = (f["participant_id"], f["flight_number"], str(f.get("departure_time") or "")[:10])
                existing_flights_map.setdefault(k, f["id"])

            def _flight_quality(p: dict) -> int:
                # When several records collide on the same (participant, flight,
                # date), keep the richest segment: real times over 00:00
                # defaults, IATA codes over city names, airline/PNR present.
                q = 0
                if p.get("departure_time") and "00:00:00" not in str(p["departure_time"]):
                    q += 4
                if p.get("arrival_time") and "00:00:00" not in str(p["arrival_time"]):
                    q += 4
                if _re.fullmatch(r"[A-Z]{3}", p.get("departure_airport") or ""):
                    q += 2
                if _re.fullmatch(r"[A-Z]{3}", p.get("arrival_airport") or ""):
                    q += 2
                if p.get("airline"):
                    q += 1
                if p.get("pnr_code"):
                    q += 1
                return q

            flight_payloads = {}
            participants_has_flight = set()

            for record in all_records:
                try:
                    part_id = record["participant_id"]
                    data = record["normalized_data"] or record["raw_data"] or {}

                    # A record that ALSO carries transfer-specific fields is a
                    # transfer row, not a flight booking — even when it has a
                    # flight_number. Transfer files legitimately carry
                    # "Numéro de vol lié" (linking the transfer to a flight,
                    # mapped to flight_number for exactly that reason), and
                    # their "Aeroport"/pickup-time/"Date" columns can ALSO map
                    # onto arrival_airport/departure_time/arrival_date by
                    # coincidence of naming — together a complete-looking
                    # flight signal, so every transfer row spawned a SECOND,
                    # ghost flight next to the real one from the FCM file: same
                    # flight number, but no real departure side (a transfer
                    # row never carries one), so it fell to the hardcoded
                    # "2025-11-10" fallback below. has_real_date alone could
                    # not catch this — the transfer row DOES carry one genuine
                    # date (its own transfer date). Presence of pickup/dropoff/
                    # vehicle/transfer-type fields is the one signal a real FCM
                    # or combined-masterfile flight record never has.
                    if any(data.get(k) for k in (
                        "pickup_location", "dropoff_location", "vehicle_type", "transfer_type", "pickup_time",
                    )):
                        continue

                    # A masterfile row often carries BOTH legs side by side —
                    # LivaNova's registrant list has "Airline / Flight Number /
                    # Depart Date…" for the outbound and a second block
                    # ("Airline3", "Flight Number4", "Depart Date6"…) for the
                    # return. Reading only the first block dropped the return
                    # flight of 94 of its 124 travellers. Build one segment
                    # spec per block and run the identical extraction on each.
                    outbound = {
                        "flight_number": data.get("flight_number") or data.get("passenger_flight"),
                        "airline":        data.get("airline"),
                        "departure_airport": data.get("departure_airport") or data.get("departure") or data.get("departure_city"),
                        "arrival_airport":   data.get("arrival_airport") or data.get("arrival") or data.get("arrival_city"),
                        "departure_date": data.get("departure_date"),
                        "departure_time": data.get("departure_time"),
                        # NOT `return_date`: the outbound leg's arrival has
                        # nothing to do with the day the traveller flies home,
                        # and this dict is what _has_real_date reads to decide
                        # whether a flight was really booked. Including it let
                        # a file carrying only a return date and a preferred
                        # carrier ("TK 81" typed as a preference) satisfy the
                        # ghost-flight guard and mint a segment stamped with
                        # the hardcoded fallback date — the very thing the
                        # guard exists to prevent.
                        "arrival_date":   data.get("arrival_date") or data.get("departure_date"),
                        "arrival_time":   data.get("arrival_time"),
                    }
                    segments = [outbound]
                    if data.get("return_flight_number"):
                        segments.append({
                            "flight_number": data.get("return_flight_number"),
                            "airline":       data.get("return_airline") or data.get("airline"),
                            # The return leaves from wherever the outbound
                            # landed (the event) unless the file says otherwise.
                            "departure_airport": data.get("return_departure_airport")
                                or data.get("return_departure_city") or outbound["arrival_airport"],
                            "arrival_airport":   data.get("return_arrival_airport")
                                or data.get("return_arrival_city") or outbound["departure_airport"],
                            "departure_date": data.get("return_departure_date") or data.get("return_date"),
                            "departure_time": data.get("return_departure_time"),
                            "arrival_date":   data.get("return_arrival_date")
                                or data.get("return_departure_date") or data.get("return_date"),
                            "arrival_time":   data.get("return_arrival_time"),
                        })

                    for seg in segments:
                        flight_num = seg.get("flight_number")
                        if flight_num and str(flight_num).strip().lower() in (
                            "yes", "no", "oui", "non", "true", "false", "x", "-", "n/a", "na", "tbc", "tbd"
                        ):
                            flight_num = None
                        # Airports are often PARTIAL in event files: a "Da Nang
                        # flights" list has no arrival column because everyone
                        # lands at the event city. Fall back to cities, then to
                        # the event's own city for the arrival — never drop the
                        # flight just because one endpoint is implicit.
                        dep_apt = seg.get("departure_airport")
                        arr_apt = seg.get("arrival_airport") or _fallback_arrival_airport(dep_apt, event_city)
                        has_time_signal = any(
                            seg.get(k) for k in ("departure_time", "departure_date", "arrival_time", "arrival_date")
                        )
                        # A flight number with NO date anywhere is not evidence of a
                        # booked segment — it is very often a reference/preference
                        # column on a registration or transfer file ("TK 81" typed
                        # as a preferred carrier, a quoted itinerary). Letting it
                        # through created a "ghost" flight AND forced the fallback
                        # below to fabricate a date, since no event has start_date
                        # set. Requiring a real date keeps every genuine FCM/
                        # masterfile row (which always carries one) and drops only
                        # the fabricated ones.
                        has_real_date = _has_real_date(
                            seg, "departure_date", "arrival_date", "departure_time", "arrival_time"
                        )

                        if flight_num and has_real_date and (dep_apt or arr_apt or has_time_signal):
                            # A genuinely missing endpoint (common: a "flights to
                            # <event city>" list has no arrival column because
                            # everyone lands there) is left BLANK, not stamped with
                            # a literal "-" that reads as if it were a real code.
                            dep_apt = dep_apt or ""
                            arr_apt = arr_apt or ""
                            flight_num_clean = _clean_flight_number(flight_num)
                            # Only pass real DATE fields as the date part — never a
                            # time value (that made the date fall back to default_date,
                            # i.e. the corrupted "2025-11-10" arrival). When the file
                            # has no arrival date, the flight lands the same day it
                            # departs, so fall back to the departure date.
                            dep_ts = combine_to_iso_timestamp(
                                seg.get("departure_date"),
                                seg.get("departure_time"),
                                default_date
                            )
                            arr_ts = combine_to_iso_timestamp(
                                seg.get("arrival_date") or seg.get("departure_date"),
                                seg.get("arrival_time"),
                                default_date
                            )

                            pnr = data.get("pnr_code") or data.get("pnr")
                            airline = seg.get("airline")
                            baggage = data.get("baggage_info") or data.get("baggage")

                            payload = {
                                "id": str(uuid.uuid4()),
                                "event_id": event_id,
                                "participant_id": part_id,
                                "flight_number": flight_num_clean,
                                "departure_airport": str(dep_apt).strip().upper(),
                                "arrival_airport": str(arr_apt).strip().upper(),
                                "departure_time": dep_ts,
                                "arrival_time": arr_ts,
                                "pnr_code": pnr,
                                "airline": airline,
                                "baggage_info": baggage,
                                "status": "confirmed",
                            }

                            # Key includes the DATE: the same flight number on two
                            # different days is two distinct segments, not one.
                            key = (part_id, flight_num_clean, str(dep_ts or "")[:10])
                            existing_id = existing_flights_map.get(key)
                            if existing_id:
                                payload["id"] = existing_id

                            prev = flight_payloads.get(key)
                            if prev is None:
                                flight_payloads[key] = payload
                            elif _flight_quality(payload) > _flight_quality(prev):
                                payload["id"] = prev["id"]   # keep the id already chosen
                                flight_payloads[key] = payload
                            participants_has_flight.add(part_id)
                except Exception as record_exc:
                    logger.warning("Failed to extract flight record: %s", record_exc)

            # Bulk upsert flights
            payload_list = list(flight_payloads.values())
            if payload_list:
                for i in range(0, len(payload_list), 100):
                    supabase.table("flights").upsert(payload_list[i:i+100]).execute()

            # Delete stale flights (their record was unlinked/relinked elsewhere;
            # keeping them is exactly the "44 flights on one person" bug).
            kept_ids = {p["id"] for p in flight_payloads.values()}
            stale_ids = [f["id"] for f in existing_rows if f["id"] not in kept_ids]
            for i in range(0, len(stale_ids), 100):
                try:
                    supabase.table("flights").delete().in_("id", stale_ids[i:i+100]).execute()
                except Exception as exc:
                    logger.warning("Failed to delete stale flights chunk: %s", exc)

            # Recompute has_flight from scratch so it reflects the rebuilt table.
            supabase.table("participants").update({"has_flight": False}).eq("event_id", event_id).execute()
            if participants_has_flight:
                part_ids = list(participants_has_flight)
                for i in range(0, len(part_ids), 50):
                    supabase.table("participants").update({"has_flight": True}).in_("id", part_ids[i:i+50]).execute()

    except Exception as exc:
        logger.error("Failed to extract flights during consolidation: %s", exc)

    # 2. Hotels Extraction (any record exposing hotel fields)
    try:
        if all_records:
            # Load existing hotels
            existing_hotels = supabase.table("hotels").select("id, name").eq("event_id", event_id).execute()
            hotel_map = {h["name"]: h["id"] for h in (existing_hotels.data or [])}
            
            # Load existing nights for all event hotels to avoid duplicate inserts
            existing_nights_map = {}
            if hotel_map:
                existing_nights = fetch_all_hotel_nights(supabase, list(hotel_map.values()))
                existing_nights_map = {
                    (n["participant_id"], n["night_date"]): n["id"] for n in existing_nights
                }
            
            nights_payloads = {}
            participants_has_hotel = set()
            _year = _infer_night_year(all_records, default_date)
            # Decided ONCE, before the loop. hotel_map grows as named properties
            # are created below, so reading len(hotel_map) inside the loop made
            # the answer depend on the order the records happened to arrive in —
            # one file could split its nameless stays across two properties, and
            # differently on each run.
            _nameless_hotel = next(iter(hotel_map)) if len(hotel_map) == 1 else _UNNAMED_HOTEL

            for record in all_records:
                try:
                    part_id = record["participant_id"]
                    data = record["normalized_data"] or record["raw_data"] or {}

                    hotel_name = data.get("hotel_name")
                    if hotel_name and str(hotel_name).strip().lower() in ("yes", "no", "oui", "non", "x", "1", "0", "true", "false"):
                        hotel_name = None
                    if not hotel_name:
                        # An event where everyone sleeps in the SAME hotel names
                        # it nowhere — the rooming grid is just one column per
                        # night ("20-juin", "21-juin"…) with a 1 in the cells.
                        # Requiring a hotel name discarded the whole grid, so
                        # every participant of such an event read "pas d'hôtel"
                        # forever, however complete the file was. Book the
                        # nights against a single placeholder property instead
                        # — the stay is real, only the property's name is
                        # missing, and it can be renamed on the hotels page.
                        ci_pn, co_pn = _parse_night_columns(record.get("raw_data") or {}, _year)
                        if not (ci_pn and co_pn):
                            continue
                        # A nameless rooming grid means "the event hotel". When
                        # the event already has exactly ONE property, that is
                        # the one — including after someone renamed the
                        # placeholder on the hotels page. Looking the property
                        # up by name alone would stop finding it the moment it
                        # was renamed, create _UNNAMED_HOTEL a second time, and
                        # move the whole stay onto it: the rename silently
                        # undone and the nights split across two properties.
                        hotel_name = _nameless_hotel

                    # A room assignment counts as "accommodation covered" even
                    # when the roster gives no parsable dates (nights are only
                    # created below when dates are known).
                    participants_has_hotel.add(part_id)

                    # Check / Create Hotel Property
                    if hotel_name not in hotel_map:
                        new_hotel = supabase.table("hotels").insert({
                            "event_id": event_id,
                            "name": hotel_name
                        }).execute()
                        hotel_id = new_hotel.data[0]["id"]
                        hotel_map[hotel_name] = hotel_id
                    else:
                        hotel_id = hotel_map[hotel_name]

                    check_in_str = data.get("check_in_date")
                    check_out_str = data.get("check_out_date")
                    room_type = data.get("room_type") or "single"

                    # Parse dates flexibly: ISO, DD/MM/YYYY, or a textual stay
                    # range crammed into ONE cell ('Arrival 03/02 - departure
                    # 06/02', '3/02 - 6/02') as villa rosters do.
                    check_in = _parse_flexible_day(check_in_str) if check_in_str else None
                    check_out = _parse_flexible_day(check_out_str) if check_out_str else None
                    if not (check_in and check_out):
                        rng = _parse_stay_range(f"{check_in_str or ''} {check_out_str or ''}", _year)
                        if rng:
                            check_in = date.fromisoformat(rng[0])
                            check_out = date.fromisoformat(rng[1])
                    # Fallback: hotels encoded as per-night date columns (26-janv,
                    # 27-Jan… with a "1") — reconstruct check-in/out from raw_data.
                    if not (check_in and check_out):
                        ci_pn, co_pn = _parse_night_columns(record.get("raw_data") or {}, _year)
                        if ci_pn and co_pn:
                            check_in = _parse_flexible_day(ci_pn)
                            check_out = _parse_flexible_day(co_pn)

                    if check_in and check_out and check_in < check_out:
                        try:
                            current_date = check_in
                            while current_date < check_out:
                                night_str = current_date.isoformat()
                                payload = {
                                    "id": str(uuid.uuid4()),
                                    "hotel_id": hotel_id,
                                    "participant_id": part_id,
                                    "night_date": night_str,
                                    "room_type": room_type,
                                    "status": "confirmed"
                                }
                                
                                # Add primary key ID if it exists
                                existing_id = existing_nights_map.get((part_id, night_str))
                                if existing_id:
                                    payload["id"] = existing_id
                                    
                                nights_payloads[(part_id, night_str)] = payload
                                current_date += timedelta(days=1)
                            
                            participants_has_hotel.add(part_id)
                        except Exception as e:
                            logger.error("Failed to parse check_in/check_out date for hotel: %s", e)
                except Exception as record_exc:
                    logger.warning("Failed to extract hotel record: %s", record_exc)
            
            # Bulk upsert hotel nights
            payload_list = list(nights_payloads.values())
            if payload_list:
                for i in range(0, len(payload_list), 100):
                    supabase.table("hotel_nights").upsert(payload_list[i:i+100]).execute()

            # Delete stale nights (left over from contaminated links).
            kept_night_ids = {p["id"] for p in nights_payloads.values()}
            stale_nights = [nid for nid in existing_nights_map.values() if nid not in kept_night_ids]
            for i in range(0, len(stale_nights), 100):
                try:
                    supabase.table("hotel_nights").delete().in_("id", stale_nights[i:i+100]).execute()
                except Exception as exc:
                    logger.warning("Failed to delete stale hotel nights chunk: %s", exc)

            # Recompute has_hotel from scratch so it reflects the rebuilt table.
            supabase.table("participants").update({"has_hotel": False}).eq("event_id", event_id).execute()
            if participants_has_hotel:
                part_ids = list(participants_has_hotel)
                for i in range(0, len(part_ids), 50):
                    supabase.table("participants").update({"has_hotel": True}).in_("id", part_ids[i:i+50]).execute()

    except Exception as exc:
        logger.error("Failed to extract hotels during consolidation: %s", exc)

    # 3. Activities Extraction (any record exposing an activity name)
    try:
        if all_records:
            # Load existing activities
            existing_acts = supabase.table("activities").select("id, name").eq("event_id", event_id).execute()
            act_map = {a["name"]: a["id"] for a in (existing_acts.data or [])}
            
            # Load existing participant activity registrations
            existing_regs_map = {}
            if act_map:
                existing_regs = supabase.table("participant_activities").select("id, participant_id, activity_id").in_("activity_id", list(act_map.values())).execute()
                existing_regs_map = {
                    (r["participant_id"], r["activity_id"]): r["id"] for r in (existing_regs.data or [])
                }
                
            reg_payloads = {}
            participants_has_activity = set()

            for record in all_records:
                try:
                    part_id = record["participant_id"]
                    data = record["normalized_data"] or record["raw_data"] or {}
                    
                    act_name = data.get("activity_name")
                    if not _is_real_activity(act_name, event_name):
                        continue
                    act_name = str(act_name).strip()

                    # Check / Create Activity
                    if act_name not in act_map:
                        new_act = supabase.table("activities").insert({
                            "event_id": event_id,
                            "name": act_name
                        }).execute()
                        act_id = new_act.data[0]["id"]
                        act_map[act_name] = act_id
                    else:
                        act_id = act_map[act_name]
                    
                    payload = {
                        "id": str(uuid.uuid4()),
                        "participant_id": part_id,
                        "activity_id": act_id,
                        "status": "registered"
                    }
                    
                    # Add primary key ID if it exists
                    existing_id = existing_regs_map.get((part_id, act_id))
                    if existing_id:
                        payload["id"] = existing_id
                        
                    reg_payloads[(part_id, act_id)] = payload
                    participants_has_activity.add(part_id)
                except Exception as record_exc:
                    logger.warning("Failed to extract activity record: %s", record_exc)
            
            # Bulk upsert registrations
            payload_list = list(reg_payloads.values())
            if payload_list:
                for i in range(0, len(payload_list), 100):
                    supabase.table("participant_activities").upsert(payload_list[i:i+100]).execute()
                    
            # Bulk update participants
            if participants_has_activity:
                part_ids = list(participants_has_activity)
                for i in range(0, len(part_ids), 50):
                    supabase.table("participants").update({"has_activities": True}).in_("id", part_ids[i:i+50]).execute()

    except Exception as exc:
        logger.error("Failed to extract activities during consolidation: %s", exc)

    # 4. Transfers Extraction (any record exposing pickup/dropoff)
    try:
        if all_records:
            # Load existing transfers. Only EXTRACTED transfers (flight_id IS NULL)
            # are managed here; calculated shuttles (flight_id set, from the
            # dispatcher) are left untouched. Keeping the full list lets us delete
            # stale extracted rows so re-runs don't pile up duplicates.
            existing_trans = supabase.table("transfers").select("id, participant_id, pickup_time, flight_id").eq("event_id", event_id).execute()
            existing_trans_rows = existing_trans.data or []
            existing_trans_map = {
                (t["participant_id"], t["pickup_time"]): t["id"]
                for t in existing_trans_rows if not t.get("flight_id")
            }

            trans_payloads = {}
            participants_has_transfer = set()

            for record in all_records:
                try:
                    part_id = record["participant_id"]
                    if not part_id:
                        continue
                    data = record["normalized_data"] or record["raw_data"] or {}

                    pickup_loc = (data.get("pickup_location") or data.get("pickup") or "").strip()
                    dropoff_loc = (data.get("dropoff_location") or data.get("dropoff") or "").strip()
                    pickup_time_val = data.get("pickup_time")
                    transfer_type_val = data.get("transfer_type")

                    # A transfer row is anything carrying a transfer-specific signal:
                    # a pickup/dropoff location, a pickup time, or a transfer type.
                    # Real transfer files are often PARTIAL (only a destination, or
                    # only an airport + time), so we fall the missing endpoint back to
                    # the airport / event city instead of dropping the transfer — the
                    # transfers table requires both locations NOT NULL. Mirrors the
                    # flight partial-route fallback.
                    #
                    # BUT ``transfer_type_val`` alone is not enough: a registration
                    # form's "Do you require a transfer on arrival?" Yes/No question
                    # is routinely mapped to that field, and answering "Yes" is not a
                    # location. Without an actual pickup/dropoff/airport AND a real
                    # date, this created a phantom transfer to "À préciser" stamped
                    # with the fabricated 2025-11-10 fallback — pure noise, not data.
                    dep_airport = (data.get("departure_airport") or "").strip()
                    arr_airport = (data.get("arrival_airport") or "").strip()
                    has_location_signal = bool(pickup_loc or dropoff_loc or dep_airport or arr_airport)
                    # `return_date` included: a transfer file's single "Date" column
                    # commonly fuzzy-matches return_date (a flight-only synonym list,
                    # SYNONYMS["return_date"]) instead of departure_date/arrival_date/
                    # date — the mapping is wrong, but the date it carries is real.
                    # Without this, every transfer whose date landed there had a real
                    # date sitting right in normalized_data yet was silently dropped
                    # as if undated (2026-07-22: 500/500 rows had it, 0 transfers created).
                    has_real_date = _has_real_date(
                        data, "pickup_date", "departure_date", "arrival_date", "date",
                        "return_date", "pickup_time", "departure_time",
                    )
                    if (pickup_loc or dropoff_loc or pickup_time_val or transfer_type_val) \
                            and has_location_signal and has_real_date:
                        transfer_type = transfer_type_val or "arrival"
                        pu = pickup_loc or dep_airport or arr_airport or event_city or "À préciser"
                        do = dropoff_loc or arr_airport or event_city or "À préciser"
                        # Avoid a meaningless X→X (both endpoints fell back to the
                        # same airport): an arrival goes airport→hotel, a departure
                        # hotel→airport. The hotel side is the event city if known.
                        if pu == do:
                            airport = dep_airport or arr_airport or pu
                            hotel = event_city or "Hôtel"
                            if str(transfer_type).lower().startswith("depart"):
                                pu, do = hotel, airport
                            else:
                                pu, do = airport, hotel

                        # ARRIVAL_date matters here as much as departure_date: on an
                        # "Arrivee" row the transfer file's own date column IS the
                        # arrival date (a "Depart" row carries departure_date). Missing
                        # arrival_date from this chain was the direct cause of every
                        # arrival transfer silently landing on the fabricated fallback
                        # date instead of its real one.
                        pickup_time_str = combine_to_iso_timestamp(
                            data.get("pickup_date") or data.get("departure_date")
                            or data.get("arrival_date") or data.get("date") or data.get("return_date"),
                            pickup_time_val or data.get("departure_time"),
                            default_date
                        )
                        vehicle_type = data.get("vehicle_type") or "shuttle"

                        payload = {
                            "id": str(uuid.uuid4()),
                            "event_id": event_id,
                            "participant_id": part_id,
                            "transfer_type": transfer_type,
                            "pickup_location": pu,
                            "dropoff_location": do,
                            "pickup_time": pickup_time_str,
                            "vehicle_type": vehicle_type,
                            "status": "scheduled"
                        }

                        # Reuse the existing row id (same participant + pickup time).
                        existing_id = existing_trans_map.get((part_id, pickup_time_str))
                        if existing_id:
                            payload["id"] = existing_id

                        trans_payloads[(part_id, pickup_time_str)] = payload
                        participants_has_transfer.add(part_id)
                except Exception as record_exc:
                    logger.warning("Failed to extract transfer record: %s", record_exc)
            
            # Bulk upsert transfers
            payload_list = list(trans_payloads.values())
            if payload_list:
                for i in range(0, len(payload_list), 100):
                    supabase.table("transfers").upsert(payload_list[i:i+100]).execute()

            # Delete STALE extracted transfers (flight_id NULL) not regenerated
            # this run — otherwise every re-consolidation stacks another copy
            # (the "MFM→MFM ×3" duplication). Calculated shuttles are untouched.
            kept_ids = {p["id"] for p in trans_payloads.values()}
            stale_ids = [
                t["id"] for t in existing_trans_rows
                if not t.get("flight_id") and t["id"] not in kept_ids
            ]
            for i in range(0, len(stale_ids), 100):
                try:
                    supabase.table("transfers").delete().in_("id", stale_ids[i:i+100]).execute()
                except Exception as exc:
                    logger.warning("Stale transfer delete failed: %s", exc)

            # Bulk update participants
            if participants_has_transfer:
                part_ids = list(participants_has_transfer)
                for i in range(0, len(part_ids), 50):
                    supabase.table("participants").update({"has_transfer": True}).in_("id", part_ids[i:i+50]).execute()

    except Exception as exc:
        logger.error("Failed to extract transfers during consolidation: %s", exc)
