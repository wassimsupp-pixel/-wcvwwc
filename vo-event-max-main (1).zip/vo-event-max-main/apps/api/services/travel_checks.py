"""
services/travel_checks.py — The exceptions §18 names and the engine did not raise.

The alerts module already caught the obvious gaps: no email, no phone, no
flight, no hotel, a duplicate, a name that does not match between two files.
What §18 adds is the operational layer — the things that are wrong not because a
box is empty but because two facts contradict each other:

    Conflicting flight · Reversed itinerary · Missing return flight · Flight changed
    Transfer requested but not assigned · Participant has flight but no transfer
    Vehicle capacity exceeded

Every one of them is computed here from lists of dicts and nothing else, which
is what lets them be argued about in a test rather than in production.

Two design constraints run through all six:

  * **The project's configuration decides.** §18 closes with it, and it is the
    same rule §10 introduced: an event that does not handle transfers must not
    be told about missing ones. The caller passes the policy; these functions
    only ever report facts, and the caller decides which facts are gaps.
  * **A contradiction, not a suspicion.** "Two flights whose times overlap" is
    a contradiction — nobody is on two planes at once. "Two flights the same
    day" is a stopover. Only the first is worth an organizer's afternoon.
"""

from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from typing import Any, Iterable, Optional

from services.accommodation_service import as_day

logger = logging.getLogger(__name__)

# A flight that says it changed or was cancelled. The importer writes these;
# surfacing them is the whole of "Flight changed" — inferring a change by
# diffing two imports would report the first import of every event as a change.
ALERTING_STATUSES = frozenset({"changed", "cancelled", "canceled"})

# Transfers this far apart share a vehicle, so they share a capacity check.
# Same 60 minutes the dispatcher groups arrivals by, deliberately: a capacity
# alert that disagrees with the proposal that caused it is worse than none.
GROUPING_MINUTES = 60


def _moment(value: Any) -> Optional[datetime]:
    """A timestamp, or None. Never raises — one malformed row must not take a
    whole detection pass down."""
    if isinstance(value, datetime):
        return value
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None


def _naive(moment: datetime) -> datetime:
    """Compare like with like: some rows carry a timezone and some do not, and
    Python refuses to compare the two."""
    return moment.replace(tzinfo=None) if moment.tzinfo else moment



def _people(count: int) -> str:
    """"1 participant", "36 participants".

    These sentences carry a number that the read-time re-count can change after
    the fact — a card written for thirty-six can end up saying one — so the
    agreement has to follow the number rather than be baked into the string.
    """
    return f"{count} participant" + ("s" if count > 1 else "")


def _have(count: int) -> str:
    """"a" or "ont" — the verb has to follow the number too."""
    return "ont" if count > 1 else "a"


def _by_participant(rows: Iterable[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    out: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        pid = row.get("participant_id")
        if pid:
            out.setdefault(pid, []).append(row)
    return out


# ---------------------------------------------------------------------------
# Flights
# ---------------------------------------------------------------------------


def conflicting_flights(flights: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    """Two segments the same person cannot both be on.

    The test is overlap in time, not similarity of route. A Brussels-Istanbul
    leg followed by an Istanbul-Ankara leg is a connection and perfectly
    normal; two legs whose windows overlap mean one of the two files is wrong,
    and the organizer is about to send a transfer to the wrong airport.

    Cancelled segments are ignored — a cancelled flight overlapping its
    replacement is the normal shape of a rebooking, and reporting it would make
    every rebooking look like an error.
    """
    out: list[dict[str, Any]] = []
    for pid, rows in sorted(_by_participant(flights).items()):
        live = [
            f for f in rows
            if str(f.get("status") or "").strip().lower() not in ("cancelled", "canceled")
        ]
        spans: list[tuple[datetime, datetime, dict[str, Any]]] = []
        for f in live:
            start, end = _moment(f.get("departure_time")), _moment(f.get("arrival_time"))
            if start and end and _naive(end) >= _naive(start):
                spans.append((_naive(start), _naive(end), f))
        spans.sort(key=lambda s: s[0])

        for i in range(len(spans) - 1):
            a_start, a_end, a = spans[i]
            b_start, b_end, b = spans[i + 1]
            if b_start >= a_end:
                continue                      # a connection, not a contradiction
            if str(a.get("flight_number") or "") == str(b.get("flight_number") or ""):
                continue                      # the same segment imported twice
            out.append({
                "participant_id": pid,
                "flights": [a.get("flight_number") or "?", b.get("flight_number") or "?"],
                "overlap_from": b_start.isoformat(),
                "overlap_to": min(a_end, b_end).isoformat(),
            })
    return out


# ---------------------------------------------------------------------------
# The event's own airport
# ---------------------------------------------------------------------------
#
# Nothing configures it — there is no field for it anywhere — but the flight
# file states it loudly, so it is read off the data. Same shape and the same
# guard as `_infer_event_city` in the consolidation service.

_HUB_MIN_SEGMENTS = 10
_HUB_MIN_SHARE = 0.3


def _airport(value: Any) -> str:
    return str(value or "").strip().upper()


def event_airport(flights: Iterable[dict[str, Any]]) -> Optional[str]:
    """Where the event is, inferred from the flights themselves.

    Participants leave from a hundred different home airports and all land at
    the same one, then leave from that one and scatter again. So the airport
    appearing on the most segments IS the event's, and it does not win closely:
    on a 75-person event all 150 segments touch it and the runner-up touches two.

    On thin or scattered data this returns None and the rule below stays quiet,
    rather than nominating a hub from four rows and then calling everybody's
    itinerary broken.
    """
    touches: dict[str, int] = {}
    total = 0
    for flight in flights:
        seen = {
            code for code in (
                _airport(flight.get("departure_airport")),
                _airport(flight.get("arrival_airport")),
            ) if code
        }
        if not seen:
            continue
        total += 1
        for code in seen:
            touches[code] = touches.get(code, 0) + 1

    if not touches:
        return None
    top, count = max(touches.items(), key=lambda kv: (kv[1], kv[0]))
    if count >= _HUB_MIN_SEGMENTS and count >= _HUB_MIN_SHARE * total:
        return top
    return None


def reversed_itinerary(
    flights: Iterable[dict[str, Any]],
    hub: Optional[str] = None,
) -> list[dict[str, Any]]:
    """Somebody the files show leaving the event before they ever reach it.

    `conflicting_flights` above is airport-blind on purpose: two windows that
    overlap prove a contradiction without anyone needing to know where the
    planes went. But it can only fire when the windows DO overlap, and a round
    trip entered backwards usually produces none — the return departs, lands,
    and is over before the outbound takes off. Two participants of Athens 2026
    were exactly that, and nothing said a word about either.

    With the airports in scope the shape is unmistakable: the first thing the
    participant does is leave the event's airport, and only later do they arrive
    at it. Legs swapped, or dates swapped; either way the transfer would be
    ordered for the wrong day.

    One benign reading exists — somebody based in the event's own city flying
    out and back during the week draws the same shape. They would have to be
    locally based AND booked through the travel agency, which is rare enough,
    and odd enough, that the question is worth asking. So the message asks
    rather than asserts.
    """
    hub = _airport(hub) or event_airport(flights)
    if not hub:
        return []

    out: list[dict[str, Any]] = []
    for pid, rows in sorted(_by_participant(flights).items()):
        live = [
            f for f in rows
            if str(f.get("status") or "").strip().lower() not in ("cancelled", "canceled")
        ]
        dated = [
            (_naive(moment), f)
            for moment, f in ((_moment(f.get("departure_time")), f) for f in live)
            if moment
        ]
        if len(dated) < 2:
            continue
        dated.sort(key=lambda pair: pair[0])

        leaves_at, outbound = dated[0]
        if _airport(outbound.get("departure_airport")) != hub:
            continue                       # they start somewhere else: normal
        if _airport(outbound.get("arrival_airport")) == hub:
            continue                       # a hub-to-hub row is an artefact, not a trip

        inbound = next(
            (f for _, f in dated[1:] if _airport(f.get("arrival_airport")) == hub),
            None,
        )
        if inbound is None:
            continue                       # left and never came back is one-way, not reversed

        landing = _moment(inbound.get("arrival_time"))
        out.append({
            "participant_id": pid,
            "hub": hub,
            "flights": [
                outbound.get("flight_number") or "?",
                inbound.get("flight_number") or "?",
            ],
            "leaves": leaves_at.isoformat(timespec="minutes"),
            "arrives": _naive(landing).isoformat(timespec="minutes") if landing else "",
        })
    return out


def missing_return(
    flights: Iterable[dict[str, Any]],
    event_end: Optional[date] = None,
) -> list[dict[str, Any]]:
    """Somebody who flew in and, as far as the files know, never flies home.

    "Never flies home" means every segment we hold departs before the event
    ends. A one-way booking is real — some people continue elsewhere — so this
    is an alert, never a correction, and it is exactly the kind of thing an
    organizer wants to ask about rather than assume.

    Without an event end date the test falls back to "one segment only", which
    is the unambiguous half of the same question.
    """
    out: list[dict[str, Any]] = []
    for pid, rows in sorted(_by_participant(flights).items()):
        live = [
            f for f in rows
            if str(f.get("status") or "").strip().lower() not in ("cancelled", "canceled")
        ]
        if not live:
            continue

        departures = [d for d in (as_day(f.get("departure_time")) for f in live) if d]
        if not departures:
            continue

        if event_end is None:
            if len(live) == 1:
                out.append({
                    "participant_id": pid, "segments": 1,
                    "last_departure": departures[0].isoformat(),
                })
            continue

        if max(departures) < event_end:
            out.append({
                "participant_id": pid,
                "segments": len(live),
                "last_departure": max(departures).isoformat(),
            })
    return out


def staying_at_own_expense(
    flights: Iterable[dict[str, Any]],
    event_start: Optional[date] = None,
    event_end: Optional[date] = None,
) -> list[dict[str, Any]]:
    """People whose own flights say they are not on the programme's dates.

    Distinct from ``missing_return``, which is about somebody with NO return
    segment at all. These people have one — it simply leaves after the event
    is over, or lands before it starts. Either way there are nights the client
    did not book, and somebody has to decide who is paying for them before the
    hotel invoice arrives and settles it by default.

    Both ends are reported because they are the same question asked twice: a
    delegate flying in the evening before is as much "a night nobody booked"
    as one flying home three days later. ``extra_nights`` counts both.

    Cancelled segments are ignored — a cancelled late return is not a stay.
    Without programme dates nothing is reported: an event that never set them
    must not suddenly announce that everybody is on a private holiday.
    """
    if not event_start or not event_end or event_end <= event_start:
        return []

    out: list[dict[str, Any]] = []
    for pid, rows in sorted(_by_participant(flights).items()):
        live = [
            f for f in rows
            if str(f.get("status") or "").strip().lower() not in ("cancelled", "canceled")
        ]
        if not live:
            continue

        days = [d for d in (as_day(f.get("departure_time")) for f in live) if d]
        if not days:
            continue
        first, last = min(days), max(days)

        early = (event_start - first).days if first < event_start else 0
        late = (last - event_end).days if last > event_end else 0
        if early <= 0 and late <= 0:
            continue

        out.append({
            "participant_id": pid,
            "arrives_early_days": early,
            "stays_late_days": late,
            "first_departure": first.isoformat(),
            "last_departure": last.isoformat(),
            "extra_nights": early + late,
        })
    return out


def describe_staying(name: str, gap: dict[str, Any]) -> str:
    parts = []
    if gap["arrives_early_days"]:
        parts.append(f"arrive {gap['arrives_early_days']} jour(s) avant le début")
    if gap["stays_late_days"]:
        parts.append(f"repart {gap['stays_late_days']} jour(s) après la fin")
    return (
        f"« {name} » {' et '.join(parts)} : {gap['extra_nights']} nuit(s) hors programme. "
        f"À confirmer — prolongation à ses frais ou nuits à ajouter au contrat ?"
    )


def describe_staying_systemic(count: int, with_flight: int, nights: int) -> str:
    """The same pattern on a whole cohort, said once.

    A group extending together is normal and expected; turning it into `count`
    individual warnings buries the real exceptions underneath it.
    """
    return (
        f"{_people(count)} sur {with_flight} {_have(count)} des vols hors des "
        f"dates du "
        f"programme ({nights} nuit(s) au total). Le plus souvent, c'est une "
        f"prolongation à leurs frais — à confirmer par groupe plutôt que "
        f"participant par participant."
    )


def changed_flights(flights: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    """Segments the airline moved or cancelled.

    Reported per participant with the segment, because the action is always the
    same and always about a person: check that their transfer and their first
    night still line up with the new time.
    """
    out: list[dict[str, Any]] = []
    for f in flights:
        status = str(f.get("status") or "").strip().lower()
        if status not in ALERTING_STATUSES or not f.get("participant_id"):
            continue
        out.append({
            "participant_id": f["participant_id"],
            "flight_number": f.get("flight_number") or "?",
            "status": status,
            "departure_time": str(f.get("departure_time") or ""),
        })
    return sorted(out, key=lambda r: (r["participant_id"], r["flight_number"]))


# ---------------------------------------------------------------------------
# Transfers
# ---------------------------------------------------------------------------


_YES = frozenset({"yes", "y", "oui", "ja", "true", "1", "x"})


def wants_transfer(value: Any) -> bool:
    """Did this person ask for a transfer?

    Only an explicit yes counts. An empty box is not a request, and treating it
    as one would raise an alert for every participant of an event that never
    asked the question.
    """
    return str(value or "").strip().lower() in _YES


def transfer_requested_not_assigned(
    participants: Iterable[dict[str, Any]],
    transfers: Iterable[dict[str, Any]],
) -> list[dict[str, Any]]:
    """They ticked the box and nothing was booked."""
    assigned = {t.get("participant_id") for t in transfers if t.get("participant_id")}
    return [
        {"participant_id": p["id"], "name": _name(p)}
        for p in sorted(participants, key=lambda p: str(p.get("id")))
        if p.get("id") and p["id"] not in assigned and wants_transfer(p.get("transfer_needed"))
    ]


def flight_without_transfer(
    participants: Iterable[dict[str, Any]],
    transfers: Iterable[dict[str, Any]],
) -> list[dict[str, Any]]:
    """They land somewhere and nobody is picking them up.

    Reads ``has_flight`` rather than the flights table because that flag is what
    consolidation maintains and what every other coverage card already agrees
    with. Somebody who explicitly declined a transfer is left alone: declining
    is an answer, and re-asking it every consolidation is how an alert list
    becomes wallpaper.
    """
    assigned = {t.get("participant_id") for t in transfers if t.get("participant_id")}
    out: list[dict[str, Any]] = []
    for p in sorted(participants, key=lambda p: str(p.get("id"))):
        if not p.get("id") or not p.get("has_flight") or p["id"] in assigned:
            continue
        declared = p.get("transfer_needed")
        if declared is not None and str(declared).strip() and not wants_transfer(declared):
            continue
        out.append({"participant_id": p["id"], "name": _name(p)})
    return out


def capacity_exceeded(
    transfers: Iterable[dict[str, Any]],
    fleet: Iterable[dict[str, Any]],
) -> list[dict[str, Any]]:
    """More passengers than the assigned vehicle holds.

    Groups by vehicle type, pickup point and a one-hour window — the same
    grouping the dispatcher uses, so an alert never contradicts the proposal
    that produced it. A vehicle type nobody declared a capacity for is skipped
    rather than assumed: inventing a capacity would either cry wolf or, worse,
    stay silent about a genuinely overloaded coach.
    """
    capacities = {
        str(v.get("name") or "").strip().lower(): int(v.get("capacity") or 0)
        for v in fleet if v.get("capacity")
    }
    if not capacities:
        return []

    groups: dict[tuple[str, str, str], list[dict[str, Any]]] = {}
    for t in transfers:
        vehicle = str(t.get("vehicle_type") or "").strip().lower()
        if vehicle not in capacities:
            continue
        moment = _moment(t.get("pickup_time"))
        if not moment:
            continue
        slot = _slot(_naive(moment))
        key = (vehicle, str(t.get("pickup_location") or "").strip().lower(), slot)
        groups.setdefault(key, []).append(t)

    out: list[dict[str, Any]] = []
    for (vehicle, place, slot), rows in sorted(groups.items()):
        # One passenger may appear twice across two imported files; the coach
        # only carries them once.
        heads = {r.get("participant_id") for r in rows if r.get("participant_id")}
        count = len(heads) or len(rows)
        capacity = capacities[vehicle]
        if count > capacity:
            out.append({
                "vehicle_type": vehicle,
                "pickup_location": place,
                "pickup_time": slot,
                "passengers": count,
                "capacity": capacity,
                "over_by": count - capacity,
            })
    return out


def _slot(moment: datetime) -> str:
    """The hour-long window a pickup falls in, anchored to midnight."""
    minutes = moment.hour * 60 + moment.minute
    start = (minutes // GROUPING_MINUTES) * GROUPING_MINUTES
    anchored = moment.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(minutes=start)
    return anchored.isoformat(timespec="minutes")


def _name(participant: dict[str, Any]) -> str:
    return " ".join(
        part for part in (participant.get("first_name"), participant.get("last_name")) if part
    ).strip() or str(participant.get("id") or "")


# ---------------------------------------------------------------------------
# Messages
# ---------------------------------------------------------------------------
#
# Kept next to the detectors so a rule and the sentence it produces cannot drift
# apart, and phrased as what to DO — an alert that only states a fact leaves the
# reader to work out the action, every time, for three hundred rows.

def describe_conflict(name: str, gap: dict[str, Any]) -> str:
    return (
        f"« {name} » a deux vols qui se chevauchent : {gap['flights'][0]} et "
        f"{gap['flights'][1]}. Une des deux sources se trompe — vérifiez laquelle "
        f"avant de commander le transfert."
    )


def _fr_moment(iso: str) -> str:
    """"2026-09-04T07:00" -> "04/09 à 07:00" — the day is the whole point here."""
    moment = _moment(iso)
    return moment.strftime("%d/%m à %H:%M") if moment else str(iso or "")


def describe_reversed_itinerary(name: str, gap: dict[str, Any]) -> str:
    return (
        f"« {name} » quitte {gap['hub']} avant d'y être arrivé : le vol "
        f"{gap['flights'][0]} part le {_fr_moment(gap['leaves'])}, et le vol "
        f"{gap['flights'][1]} n'atterrit que le {_fr_moment(gap['arrives'])}. "
        f"Les deux segments sont probablement inversés — vérifiez le sens avant "
        f"de commander le transfert."
    )


def describe_missing_return(name: str, gap: dict[str, Any]) -> str:
    return (
        f"« {name} » n'a pas de vol retour : le dernier segment connu part le "
        f"{gap['last_departure']}, avant la fin de l'événement. Aller simple "
        f"volontaire ou vol manquant ?"
    )


def describe_missing_return_systemic(missing: int, with_flight: int) -> str:
    """The same absence of a return flight on a whole cohort, said once.

    Unlike a systemic transfer gap, this is not usually a sign the import is
    broken — it is what a group of people extending their stay at their own
    expense looks like in the data. Escalating it into `missing` individual
    warnings would flag a normal, expected pattern as if it were a problem;
    one calm card asks the question collectively instead.
    """
    return (
        f"{_people(missing)} sur {with_flight} n'{_have(missing)} pas de vol "
        f"retour "
        f"identifié. Le plus souvent, c'est un aller simple volontaire ou une "
        f"prolongation de séjour à leurs frais — à confirmer par groupe plutôt "
        f"que participant par participant."
    )


def describe_changed_flight(name: str, gap: dict[str, Any]) -> str:
    word = "annulé" if gap["status"].startswith("cancel") else "modifié"
    return (
        f"Le vol {gap['flight_number']} de « {name} » est {word}. Revérifiez son "
        f"transfert et sa première nuit d'hôtel."
    )


def describe_transfer_requested(name: str) -> str:
    return f"« {name} » a demandé un transfert et aucun ne lui est assigné."


def describe_flight_no_transfer(name: str) -> str:
    return (
        f"« {name} » a un vol mais aucun transfert. Personne ne l'attend à "
        f"l'aéroport."
    )


def describe_flight_no_transfer_systemic(missing: int, with_flight: int) -> str:
    """The same gap on ~everybody, said once.

    Deliberately points at the import rather than at the people: when the
    proportion is this high the participants are not the problem, and a
    message naming them would send somebody to fix three hundred fiches by
    hand instead of one column mapping.
    """
    return (
        f"{_people(missing)} sur {with_flight} {_have(missing)} un vol sans aucun "
        f"transfert. Une proportion pareille vient presque toujours de "
        f"l'import : soit le fichier transferts n'a pas encore été chargé, "
        f"soit sa colonne participant n'est pas mappée et les transferts "
        f"existent sans être rattachés à personne."
    )


def describe_capacity(gap: dict[str, Any]) -> str:
    return (
        f"{gap['passengers']} passagers pour un {gap['vehicle_type']} de "
        f"{gap['capacity']} places ({gap['pickup_location'] or 'lieu non précisé'}, "
        f"{gap['pickup_time']}) — {gap['over_by']} de trop."
    )
