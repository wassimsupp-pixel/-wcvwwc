"""
services/note_presets.py — Named, reusable internal notes with their own colour.

The team writes the same handful of remarks over and over: "Super VIP",
"cadeau dans la chambre", "appeler personnellement". Typing them by hand every
time is slow and, worse, inconsistent — "Super VIP" and "super vip" are two
different strings and only one of them is ever searched for.

A preset is that remark, named once per event, with a colour the team picks.
Applying it to somebody writes a normal note (so nothing downstream needs to
know presets exist) and stamps which preset it came from, which is what lets
the master list colour that person's row.

Colour resolution order, and why:

  * the PRESET's colour when the note came from one — the team chose it, and a
    choice beats a default;
  * otherwise the note's CATEGORY colour (services/note_service), which is
    what every note had before presets existed.

Everything here follows the same malformed-input tolerance as
rooming_plan.resolve_presets and registration_form.resolve_badges: an entry
that cannot be rendered is dropped rather than raising, because this drives a
screen the team uses all day and one bad row must not blank it.
"""

from __future__ import annotations

import re
from typing import Any, Optional

from services import note_service

MAX_PRESETS = 30
NAME_MAX = 60
BODY_MAX = 2000
ID_MAX = 40

# A colour is stored as it will be used: a CSS hex the browser can render
# directly. Anything else is refused rather than sanitised into a colour
# nobody picked — a silently-wrong colour is a silently-wrong signal.
_HEX = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")

# Offered when a preset names no colour of its own. Deliberately distinct from
# note_service.CATEGORY_COLORS so a preset never masquerades as a category.
DEFAULT_COLOR = "#64748B"


def resolve(stored: Any) -> list[dict[str, str]]:
    """The event's saved presets, with anything unusable dropped."""
    if not isinstance(stored, list):
        return []
    out: list[dict[str, str]] = []
    seen: set[str] = set()
    for entry in stored[:MAX_PRESETS]:
        if not isinstance(entry, dict):
            continue
        name = str(entry.get("name") or "").strip()[:NAME_MAX]
        if not name:
            continue
        preset_id = str(entry.get("id") or "").strip()[:ID_MAX] or _slugify(name)
        if not preset_id or preset_id in seen:
            preset_id = f"{preset_id or 'note'}-{len(seen) + 1}"
        seen.add(preset_id)
        # The body defaults to the name: a preset called "Super VIP" with no
        # separate wording is a note that says "Super VIP", which is exactly
        # what somebody creating it that way meant.
        body = str(entry.get("body") or name).strip()[:BODY_MAX]
        raw_color = str(entry.get("color") or "").strip()
        color = raw_color if _HEX.match(raw_color) else DEFAULT_COLOR
        out.append({
            "id": preset_id,
            "name": name,
            "body": body,
            "color": color,
            "category": note_service.normalise_category(entry.get("category")),
        })
    return out


def _slugify(name: str) -> str:
    slug = "".join(ch if ch.isalnum() else "-" for ch in name.strip().lower())
    while "--" in slug:
        slug = slug.replace("--", "-")
    return slug.strip("-")[:ID_MAX]


def fetch(supabase: Any, event_id: str) -> list[dict[str, str]]:
    """The event's presets, or [] before migration 028 — same degrade-clean
    contract as registration_form.fetch_badges."""
    try:
        resp = (
            supabase.table("events")
            .select("note_presets")
            .eq("id", event_id)
            .limit(1)
            .execute()
        )
    except Exception:
        return []
    rows = resp.data if isinstance(resp.data, list) else []
    if not rows or not isinstance(rows[0], dict):
        return []
    return resolve(rows[0].get("note_presets"))


def highlight_color(
    notes: list[dict[str, Any]],
    presets: list[dict[str, str]],
) -> tuple[Optional[str], Optional[str]]:
    """``(colour, label)`` for a participant's master-list row, or ``(None,
    None)`` when they carry no notes at all.

    A preset-backed note wins over a plain one: somebody who deliberately
    tagged a person "Super VIP" wants to see that, not the generic colour of
    whatever category the preset happens to sit in. Among several presets the
    first one still attached to a live preset definition wins, in the order
    the notes came back (newest first, per the notes endpoint).
    """
    by_id = {p["id"]: p for p in presets}
    for note in notes:
        if not note:
            continue
        preset = by_id.get(str(note.get("preset_id") or ""))
        if preset:
            return preset["color"], preset["name"]

    category = note_service.highlight_category(notes)
    if not category:
        return None, None
    return (
        note_service.CATEGORY_COLORS.get(category),
        note_service.CATEGORY_LABELS.get(category, category),
    )
