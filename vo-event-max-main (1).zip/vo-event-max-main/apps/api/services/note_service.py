"""
services/note_service.py — Operational remarks about a participant.

"Super VIP", "cadeau dans la chambre", "appeler personnellement", "besoin
spécifique". The team writes these constantly and had one free-text `remarks`
field to put them in — no category, and no control over whether they left the
building (feedback §8).

Two rules shape this module, and both are about the second problem.

**Nothing leaves by default.** ``include_in_export`` is false unless somebody
deliberately turns it on, note by note. The feedback asks for the flag; making
it default to NO is the part that matters, because the failure mode is not "we
forgot to share a remark", it is a coach company reading "difficult client,
handle carefully" about somebody sitting in their van.

**A category is not decoration.** It decides which supplier could ever see the
note, even once flagged: an accommodation note can reach the hotel sheet and
nothing else. A note has one destination, so a flight remark cannot end up on
a rooming list because somebody ticked a box in a hurry.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

GENERAL = "general"
ACCOMMODATION = "accommodation"
FLIGHT = "flight"
TRANSFER = "transfer"
ACTIVITY = "activity"

CATEGORIES: tuple[str, ...] = (GENERAL, ACCOMMODATION, FLIGHT, TRANSFER, ACTIVITY)

CATEGORY_LABELS: dict[str, str] = {
    GENERAL: "Remarque générale",
    ACCOMMODATION: "Hébergement",
    FLIGHT: "Vol",
    TRANSFER: "Transfert",
    ACTIVITY: "Activité",
}

# category -> the supplier profile a flagged note may reach, and nothing else.
# `general` is absent on purpose: a note with no stated destination has no
# business being on any supplier's sheet, whatever it says.
EXPORTABLE_TO: dict[str, str] = {
    ACCOMMODATION: "hotel",
    FLIGHT: "flight",
    TRANSFER: "transfer",
    ACTIVITY: "activity",
}

# One colour per category (point 14), so a row in the master list carrying a
# note says so at a glance instead of requiring somebody to open the fiche.
# General is the muted one on purpose — a remark with no stated destination
# is not a flag to act on the way "hébergement" or "transfert" is.
CATEGORY_COLORS: dict[str, str] = {
    GENERAL: "#94A3B8",       # slate
    ACCOMMODATION: "#3B82F6", # blue
    FLIGHT: "#0EA5E9",        # sky
    TRANSFER: "#F59E0B",      # amber
    ACTIVITY: "#8B5CF6",      # violet
}

# The order a row's colour is chosen in when a participant has notes in more
# than one category. A note actually about logistics is more useful to see at
# a glance than a general remark, so those win first; general is the
# fallback, never the tiebreaker.
_HIGHLIGHT_PRIORITY: tuple[str, ...] = (ACCOMMODATION, FLIGHT, TRANSFER, ACTIVITY, GENERAL)


def highlight_category(notes: list[dict[str, Any]]) -> Optional[str]:
    """Which category should colour this participant's master-list row, or
    None when they have no notes at all.

    Reads every note regardless of ``include_in_export``: the colour is a
    convenience for the team looking at their own master list, not something
    that ever reaches a supplier, so whether a note was flagged to leave the
    building is irrelevant here.
    """
    present = {normalise_category(n.get("category")) for n in notes if n}
    for category in _HIGHLIGHT_PRIORITY:
        if category in present:
            return category
    return None

MAX_BODY = 2000


def normalise_category(value: Any) -> str:
    """A known category, defaulting to ``general``.

    Unknown values fall back rather than raise — and they fall back to the one
    category that can never be exported, which is the safe direction for a
    value nobody recognises.
    """
    candidate = str(value or "").strip().lower()
    return candidate if candidate in CATEGORIES else GENERAL


def clean(body: Any, category: Any, include_in_export: Any) -> Optional[dict[str, Any]]:
    """A note ready to store, or None when there is nothing to store.

    ``include_in_export`` is only honoured for a category that has a
    destination: ticking "share this" on a general note is a request nobody
    can fulfil, and silently storing it as true would leave a flag that looks
    active and is not.
    """
    text = str(body or "").strip()[:MAX_BODY]
    if not text:
        return None
    cat = normalise_category(category)
    shared = include_in_export is True and cat in EXPORTABLE_TO
    return {"category": cat, "body": text, "include_in_export": shared}


def for_export(notes: list[dict[str, Any]], profile: str) -> dict[str, str]:
    """Participant id -> the notes this supplier is allowed to read.

    Three conditions, all required: the note is flagged, its category has a
    destination, and that destination is this profile. Several notes on one
    participant are joined rather than one of them winning silently.
    """
    out: dict[str, list[str]] = {}
    for note in notes:
        if not note.get("include_in_export"):
            continue
        category = normalise_category(note.get("category"))
        if EXPORTABLE_TO.get(category) != profile:
            continue
        pid = note.get("participant_id")
        text = str(note.get("body") or "").strip()
        if pid and text:
            out.setdefault(pid, []).append(text)
    return {pid: " · ".join(texts) for pid, texts in out.items()}


def group_by_participant(notes: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """Every note, internal ones included, for the fiche."""
    grouped: dict[str, list[dict[str, Any]]] = {}
    for note in notes:
        pid = note.get("participant_id")
        if pid:
            grouped.setdefault(pid, []).append(note)
    return grouped


def describe_categories() -> list[dict[str, Any]]:
    """The categories, for the fiche's dropdown: which exist and which can
    ever be shared."""
    return [
        {
            "key": key,
            "label": CATEGORY_LABELS[key],
            "exportable_to": EXPORTABLE_TO.get(key),
        }
        for key in CATEGORIES
    ]
