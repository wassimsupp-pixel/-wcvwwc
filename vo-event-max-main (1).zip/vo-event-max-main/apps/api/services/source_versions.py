"""
services/source_versions.py — FCM Week 1, Week 2, Week 3 (feedback §20).

MAX receives a fresh export every week, and the same person is in all three.
The engine has always handled that correctly — it matches, merges
non-destructively, and a human correction survives a re-import. What it could
not do is tell the difference between two intentions:

    **Add / Update Source** — another file about the same event. Week 2 does not
    invalidate Week 1; some people only ever appeared in Week 1, and their hotel
    booking is real.

    **Replace Source** — a corrected version of a file already imported. Week 2
    IS Week 1, redone. Keeping both means the master list is fed by a file
    somebody has explicitly withdrawn.

Today everything is the first. This module makes the second possible, and makes
it show its work first: which people are new, which changed, and — the question
that actually matters — **who would be left with no source at all**.

Nothing here deletes a participant. Superseding a file stops it feeding the
master list; a person who came only from it stays on the list and is named, so
a human decides. Somebody who registered in Week 1, has a room booked and a
transfer assigned, must not evaporate because a spreadsheet was re-exported.

Pure module: it compares lists of dicts.
"""

from __future__ import annotations

import logging
from typing import Any, Iterable, Optional

logger = logging.getLogger(__name__)

# Fields worth comparing between two versions of the same file. Not everything
# in normalized_data: a re-export routinely renumbers its own row indices and
# reformats its dates, and reporting those as "changed" for three hundred people
# would bury the four that matter.
COMPARED_FIELDS: tuple[str, ...] = (
    "first_name", "last_name", "email", "phone", "company",
    "nationality", "dietary_requirements",
    "arrival_flight", "departure_flight", "arrival_date", "departure_date",
    "hotel_name", "room_type", "roommate",
    "check_in", "check_out", "transfer_needed",
)


def person_key(record: dict[str, Any], norm_name: Any) -> str:
    """What identifies a row across two versions of the same file.

    Email when there is one — it is the identity the whole matching engine
    trusts. Otherwise the normalised full name, which is weaker but is what a
    file without emails leaves us. A row with neither cannot be tracked between
    versions and is reported as neither added nor removed: pretending we can
    follow it would produce a phantom departure and a phantom arrival for the
    same person.
    """
    data = record.get("normalized_data") or {}
    email = str(data.get("email") or "").strip().lower()
    if email:
        return f"email:{email}"
    full = f"{data.get('first_name') or ''} {data.get('last_name') or ''}".strip()
    key = norm_name(full)
    return f"name:{key}" if key else ""


def index(records: Iterable[dict[str, Any]], norm_name: Any) -> dict[str, dict[str, Any]]:
    """key -> the row, keeping the first occurrence.

    Duplicates within one file are the file's own problem and the duplicate
    engine's business; here the first row wins so a comparison is stable.
    """
    out: dict[str, dict[str, Any]] = {}
    for record in records:
        key = person_key(record, norm_name)
        if key and key not in out:
            out[key] = record
    return out


def _label(record: dict[str, Any]) -> str:
    data = record.get("normalized_data") or {}
    name = " ".join(
        str(data.get(k) or "") for k in ("first_name", "last_name")
    ).strip()
    return name or str(data.get("email") or "") or "?"


def impact(
    old_records: list[dict[str, Any]],
    new_records: list[dict[str, Any]],
    norm_name: Any,
) -> dict[str, Any]:
    """What replacing the old file with the new one would change.

    Three lists, in the order somebody reads them:

      * ``removed`` — in the old file, absent from the new. The dangerous one,
        and the reason this preview exists at all.
      * ``changed`` — present in both, with at least one compared field
        different. Each entry names the fields and both values.
      * ``added`` — only in the new file. The least alarming, and usually the
        reason a new export was requested.
    """
    old = index(old_records, norm_name)
    new = index(new_records, norm_name)

    removed = [
        {"key": key, "name": _label(record)}
        for key, record in sorted(old.items()) if key not in new
    ]
    added = [
        {"key": key, "name": _label(record)}
        for key, record in sorted(new.items()) if key not in old
    ]

    changed: list[dict[str, Any]] = []
    for key in sorted(set(old) & set(new)):
        before = (old[key].get("normalized_data") or {})
        after = (new[key].get("normalized_data") or {})
        diffs = []
        for field in COMPARED_FIELDS:
            a = str(before.get(field) or "").strip()
            b = str(after.get(field) or "").strip()
            if a != b:
                diffs.append({"field": field, "old": a, "new": b})
        if diffs:
            changed.append({"key": key, "name": _label(new[key]), "fields": diffs})

    return {
        "added": added,
        "removed": removed,
        "changed": changed,
        "unchanged": len(set(old) & set(new)) - len(changed),
        "old_rows": len(old_records),
        "new_rows": len(new_records),
        "untracked": sum(1 for r in old_records + new_records if not person_key(r, norm_name)),
    }


def orphaned(
    old_records: list[dict[str, Any]],
    other_live_records: list[dict[str, Any]],
) -> list[str]:
    """Participants the old file is the ONLY live source for.

    These are the people who would be left with nothing backing them. They are
    not deleted and never will be by this module — they are named, because a
    participant with a room and a transfer whose spreadsheet was re-exported is
    still going on the trip.
    """
    covered = {
        r.get("participant_id") for r in other_live_records if r.get("participant_id")
    }
    only_here = {
        r.get("participant_id") for r in old_records if r.get("participant_id")
    } - covered
    return sorted(pid for pid in only_here if pid)


def describe(report: dict[str, Any]) -> str:
    """One sentence, leading with the number somebody needs to react to."""
    parts = []
    if report["removed"]:
        parts.append(f"{len(report['removed'])} disparition(s)")
    if report["changed"]:
        parts.append(f"{len(report['changed'])} modification(s)")
    if report["added"]:
        parts.append(f"{len(report['added'])} nouvelle(s) personne(s)")
    if not parts:
        return "Aucune différence entre les deux fichiers."
    return ", ".join(parts) + "."


def candidates(
    files: list[dict[str, Any]],
    new_file: dict[str, Any],
) -> list[dict[str, Any]]:
    """Files the new one could be replacing: same event, same kind, older, live.

    Same source_type is the whole test. A hotel list never replaces an FCM
    export however similar the filenames look, and offering it would let
    somebody retire the wrong file with one click.
    """
    new_id = new_file.get("id")
    kind = new_file.get("source_type")
    when = str(new_file.get("imported_at") or "")

    out = [
        f for f in files
        if f.get("id") != new_id
        and f.get("source_type") == kind
        and not f.get("superseded_at")
        and str(f.get("imported_at") or "") <= when
    ]
    return sorted(out, key=lambda f: str(f.get("imported_at") or ""), reverse=True)
