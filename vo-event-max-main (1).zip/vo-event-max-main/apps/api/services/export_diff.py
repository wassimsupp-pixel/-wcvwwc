"""
services/export_diff.py — What changed since the last file you sent them.

MAX sends updated lists to clients and suppliers every week. The recipient
opens "Master List semaine 2" and has to work out, unaided, what moved since
week 1 — today by colouring cells in Excel by hand (feedback §7).

So each export leaves a snapshot behind, and the next one compares itself to
it and carries an UPDATES sheet: participant, information, old value, new
value, plus a status.

Three statuses, and the third is the one that matters most:

  * ``NEW``       — a participant who was not on the previous file
  * ``UPDATED``   — a value that changed
  * ``CANCELLED`` — a participant who was on the previous file and is gone

A supplier who never learns that somebody cancelled keeps a seat, a room and a
meal for them. An absent row communicates nothing at all, which is exactly why
the comparison is done against a stored snapshot rather than by diffing two
files somebody happens to still have.

The comparison is deliberately blunt: values are compared as trimmed strings.
A smarter comparison — knowing that "3" and "3 nuits" mean the same — would
also be one that can decide two different things are equal, and a change
wrongly reported costs a glance while a change wrongly hidden costs a room.
"""

from __future__ import annotations

import logging
from typing import Any, Iterable, Optional

logger = logging.getLogger(__name__)

NEW = "NEW"
UPDATED = "UPDATED"
CANCELLED = "CANCELLED"

# What a snapshot remembers. Not the whole master row: a snapshot is stored on
# every export, so it holds the operational facts a supplier acts on, and not
# the seventy columns that would make it a second copy of the database.
TRACKED_FIELDS: tuple[tuple[str, str], ...] = (
    ("first_name", "Prénom"),
    ("last_name", "Nom"),
    ("email", "Email"),
    ("company", "Entreprise"),
    ("outbound_flight_number", "Vol aller"),
    ("outbound_departure_time", "Heure vol aller"),
    ("return_flight_number", "Vol retour"),
    ("return_departure_time", "Heure vol retour"),
    ("hotel_name", "Hôtel"),
    ("hotel_checkin", "Arrivée hôtel"),
    ("hotel_checkout", "Départ hôtel"),
    ("hotel_nights_count", "Nuitées"),
    ("hotel_room_type", "Type de chambre"),
    ("roommate_name", "Roommate"),
    ("room_number", "N° de chambre"),
    ("transfer_arrival_time", "Heure transfert arrivée"),
    ("transfer_arrival_vehicle", "Véhicule transfert"),
    ("activity_1", "Activité"),
)

_LABELS = dict(TRACKED_FIELDS)
_KEYS = tuple(key for key, _label in TRACKED_FIELDS)


def _value(raw: Any) -> str:
    """A comparable string. None, "" and "  " all mean "we do not know"."""
    if raw is None:
        return ""
    if isinstance(raw, bool):
        return "Oui" if raw else "Non"
    return str(raw).strip()


def _display_name(row: dict[str, Any]) -> str:
    return " ".join(
        part for part in (_value(row.get("first_name")), _value(row.get("last_name"))) if part
    ).strip()


def snapshot(master_rows: Iterable[dict[str, Any]]) -> dict[str, Any]:
    """What this export said, in a form the next one can compare against.

    Keyed by participant id: names change (a maiden name, a corrected
    spelling), and keying on a name would report one person as another leaving
    and a stranger arriving.
    """
    out: dict[str, Any] = {}
    for row in master_rows:
        pid = row.get("participant_id") or row.get("id")
        if not pid:
            continue
        out[str(pid)] = {key: _value(row.get(key)) for key in _KEYS}
    return out


def diff(previous: Optional[dict[str, Any]], current: dict[str, Any]) -> list[dict[str, Any]]:
    """The changes between two snapshots, in the shape the UPDATES sheet wants.

    A first export has nothing to compare against and returns no rows — not a
    list declaring all two hundred participants NEW, which would be true and
    useless.
    """
    if not previous:
        return []

    changes: list[dict[str, Any]] = []

    for pid, row in sorted(current.items()):
        before = previous.get(pid)
        name = _display_name(row)
        if before is None:
            changes.append({
                "status": NEW, "participant_id": pid, "participant_name": name,
                "field": "", "label": "", "old": "", "new": "",
            })
            continue
        for key in _KEYS:
            old, new = _value(before.get(key)), _value(row.get(key))
            if old == new:
                continue
            changes.append({
                "status": UPDATED, "participant_id": pid, "participant_name": name,
                "field": key, "label": _LABELS[key], "old": old, "new": new,
            })

    for pid, row in sorted(previous.items()):
        if pid in current:
            continue
        # A supplier who never learns about a cancellation keeps a room and a
        # seat for somebody who is not coming.
        changes.append({
            "status": CANCELLED, "participant_id": pid,
            "participant_name": _display_name(row),
            "field": "", "label": "", "old": "", "new": "",
        })

    order = {NEW: 0, UPDATED: 1, CANCELLED: 2}
    return sorted(changes, key=lambda c: (order[c["status"]], c["participant_name"].lower(), c["label"]))


def summarise(changes: list[dict[str, Any]]) -> dict[str, int]:
    """Counts for the sheet's header line and for the UI."""
    return {
        "new": len({c["participant_id"] for c in changes if c["status"] == NEW}),
        "updated": len({c["participant_id"] for c in changes if c["status"] == UPDATED}),
        "cancelled": len({c["participant_id"] for c in changes if c["status"] == CANCELLED}),
        "changes": len(changes),
    }


UPDATES_HEADERS = ["Statut", "Participant", "Information", "Ancienne valeur", "Nouvelle valeur"]


def as_sheet_rows(changes: list[dict[str, Any]]) -> list[list[str]]:
    """The UPDATES sheet, ready to write."""
    return [
        [c["status"], c["participant_name"], c["label"], c["old"], c["new"]]
        for c in changes
    ]
