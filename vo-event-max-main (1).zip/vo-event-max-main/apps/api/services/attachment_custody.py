# -*- coding: utf-8 -*-
"""
attachment_custody.py — what happens to a passport copy after it arrives (§9).

``registration_uploads`` answers "may this file come in?". This module answers
the three questions that follow, and that a collection-only feature leaves open:

  * **Who can look at it, and is that visible?** A passport scan is the most
    sensitive object the platform holds. Reading one is an event worth
    recording, so a fetch is auditable rather than silent.
  * **What happens to the ones nobody claimed?** A visitor who uploads a
    passport and then abandons the form leaves a file with no participant and
    no registration behind it. Nothing points to it, so nothing would ever find
    it again — it has to expire on its own.
  * **What happens when the event is deleted?** The database row cascades. The
    object in Storage does not, and once the row is gone the path is
    unrecoverable: a passport scan nobody can even locate to delete. Deleting
    an event has to take the objects with it.

The module holds no HTTP and no auth: the router decides who may call, this
decides what the operation means.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable, Optional

logger = logging.getLogger(__name__)

TABLE = "registration_attachments"

# How long an unclaimed upload survives. Generous on purpose: somebody
# photographs their passport, then hunts for their flight number for a quarter
# of an hour. Short enough that an abandoned form does not leave identity
# documents lying around indefinitely.
ORPHAN_TTL = timedelta(hours=24)

# A purge runs opportunistically, on the next upload for the same event, so
# there is no scheduler to keep alive. The cap bounds that piggybacked work:
# a purge must never turn one visitor's upload into a thousand deletions.
PURGE_LIMIT = 100


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Is the feature actually available?
# ---------------------------------------------------------------------------

# Probed once per process. The answer only changes when somebody runs a
# migration, and that restarts the API anyway.
_AVAILABLE: Optional[bool] = None


def available(supabase: Any) -> bool:
    """True when migration 021 has been run.

    This decides whether the upload fields are offered *at all*, and that
    matters more than it looks. An organiser who marks the passport copy
    **required** on a deployment without the table would otherwise lock the
    form completely: the upload fails, the required check refuses the
    submission, and nobody can register — with a 503 as the only clue.

    Degrading here turns that into the same no-op as every other feature: the
    field is not advertised, so it is not required, so registration works.
    """
    global _AVAILABLE
    if _AVAILABLE is not None:
        return _AVAILABLE
    try:
        supabase.table(TABLE).select("id").limit(1).execute()
        _AVAILABLE = True
    except Exception as exc:
        logger.info("Registration attachments disabled (migration 021?): %s", exc)
        _AVAILABLE = False
    return _AVAILABLE


def reset_availability() -> None:
    """Forget the probe. For tests, and for a process that outlives a migration."""
    global _AVAILABLE
    _AVAILABLE = None


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

def listing(
    supabase: Any,
    event_id: str,
    *,
    participant_id: Optional[str] = None,
) -> list[dict[str, Any]]:
    """Metadata for the attachments of an event — never the bytes.

    Only *claimed* rows are listed. An unclaimed row is a file from a form
    somebody never submitted: it belongs to no participant, and showing it
    would put a document on screen that its owner never actually sent.
    """
    try:
        query = (
            supabase.table(TABLE)
            .select("*")
            .eq("event_id", str(event_id))
            .not_.is_("claimed_at", "null")
        )
        if participant_id:
            query = query.eq("participant_id", str(participant_id))
        rows = query.order("created_at", desc=True).execute().data or []
    except Exception as exc:
        # No table yet (migration 021) is a normal state, not an error: the
        # screen shows nothing rather than failing.
        logger.info("Attachments unavailable (migration 021?): %s", exc)
        return []
    return [describe(row) for row in rows]


def describe(row: dict[str, Any]) -> dict[str, Any]:
    """The row as a screen needs it: no storage path.

    The path is deliberately withheld. It is the one field that turns a listing
    into a way of reaching the object directly, and a client has no use for it
    — every read goes back through an access check.
    """
    return {
        "id": row.get("id"),
        "kind": row.get("kind"),
        "participant_id": row.get("participant_id"),
        "original_name": row.get("original_name"),
        "content_type": row.get("content_type"),
        "byte_size": row.get("byte_size") or 0,
        "created_at": row.get("created_at"),
        "claimed_at": row.get("claimed_at"),
    }


def find(supabase: Any, event_id: str, attachment_id: str) -> Optional[dict[str, Any]]:
    """One attachment row, scoped to its event.

    The event is part of the lookup rather than checked afterwards, so an id
    belonging to another event returns nothing at all — the caller raises 404
    and never has to decide whether to admit that the row exists.
    """
    try:
        rows = (
            supabase.table(TABLE)
            .select("*")
            .eq("id", str(attachment_id))
            .eq("event_id", str(event_id))
            .execute()
        ).data or []
    except Exception as exc:
        logger.info("Attachment lookup failed (migration 021?): %s", exc)
        return None
    return rows[0] if rows else None


def download_name(row: dict[str, Any], participant: Optional[dict[str, Any]] = None) -> str:
    """A filename that says whose document this is.

    ``passport.jpg`` in a downloads folder is indistinguishable from the next
    one; the person's name is the whole point of the file.
    """
    from services import registration_uploads

    kind = str(row.get("kind") or "document")
    original = str(row.get("original_name") or "")
    suffix = ""
    if "." in original:
        suffix = "." + original.rsplit(".", 1)[-1].lower()[:5]

    who = ""
    if participant:
        who = " ".join(
            str(participant.get(part) or "").strip()
            for part in ("first_name", "last_name")
        ).strip()

    label = registration_uploads.safe_label(f"{who} {kind}".strip() or kind)
    label = label.rsplit(".", 1)[0] if "." in label else label
    return f"{label or kind}{suffix}"


# ---------------------------------------------------------------------------
# Removal
# ---------------------------------------------------------------------------

def storage_paths(supabase: Any, event_id: str) -> list[str]:
    """Every Storage key held by an event's attachments.

    Collected *before* the rows go, because after the cascade the paths are
    gone and the objects become unreachable.
    """
    try:
        rows = (
            supabase.table(TABLE)
            .select("storage_path")
            .eq("event_id", str(event_id))
            .execute()
        ).data or []
    except Exception as exc:
        logger.info("Could not list attachment paths (migration 021?): %s", exc)
        return []
    return [str(r["storage_path"]) for r in rows if r.get("storage_path")]


def remove_objects(supabase: Any, paths: Iterable[str]) -> int:
    """Delete Storage objects. Best-effort: never blocks a database delete."""
    keys = [p for p in paths if p]
    if not keys:
        return 0
    import config

    try:
        supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).remove(keys)
    except Exception as exc:
        logger.warning("Attachment storage removal failed: %s", exc)
        return 0
    return len(keys)


def delete(supabase: Any, row: dict[str, Any]) -> bool:
    """Erase one attachment: the object first, then the row.

    That order is the safe one. If the object is removed and the row delete
    then fails, a later retry still has the path and finishes the job; the
    reverse loses the path and orphans the document forever.
    """
    remove_objects(supabase, [row.get("storage_path") or ""])
    try:
        supabase.table(TABLE).delete().eq("id", row["id"]).execute()
    except Exception as exc:
        logger.error("Attachment row delete failed for %s: %s", row.get("id"), exc)
        return False
    return True


def purge_orphans(supabase: Any, event_id: str, *, ttl: timedelta = ORPHAN_TTL) -> int:
    """Drop unclaimed uploads older than *ttl*. Returns how many went.

    An unclaimed row is a document from a form that was never submitted. There
    is no participant to attach it to and no screen it appears on, so leaving
    it is not caution — it is an identity document with nothing pointing at it.
    """
    cutoff = (_now() - ttl).isoformat()
    try:
        rows = (
            supabase.table(TABLE)
            .select("id, storage_path")
            .eq("event_id", str(event_id))
            .is_("claimed_at", "null")
            .lt("created_at", cutoff)
            .limit(PURGE_LIMIT)
            .execute()
        ).data or []
    except Exception as exc:
        logger.info("Orphan purge skipped (migration 021?): %s", exc)
        return 0
    if not rows:
        return 0

    remove_objects(supabase, [r.get("storage_path") or "" for r in rows])
    ids = [r["id"] for r in rows if r.get("id")]
    try:
        supabase.table(TABLE).delete().in_("id", ids).execute()
    except Exception as exc:
        logger.warning("Orphan row delete failed: %s", exc)
        return 0
    logger.info("Purged %d unclaimed attachment(s) for event %s", len(ids), event_id)
    return len(ids)
