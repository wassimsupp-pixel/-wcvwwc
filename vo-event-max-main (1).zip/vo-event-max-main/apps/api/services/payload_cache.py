"""
services/payload_cache.py — One read for five hundred visitors.

The public registration form is the only page in this product that a crowd
opens at once: an organizer sends one email to three hundred people and they
click within the hour. Serving it costs six database round trips — the event,
its fields, its extra questions, its mini-site sections, its logo, its theme —
and `supabase-py` is synchronous, so each of those blocks its uvicorn worker's
whole event loop, not merely the request making it. Measured against the
deployed API, that puts the ceiling around six requests a second across two
workers. Five hundred arrivals take a minute and a half to drain, and most
browsers give up first.

The payload is the same for everyone. Two visitors opening the same link in the
same language see byte-identical JSON, because nothing in it depends on who is
asking. So it is computed once and handed to everyone else.

**Invalidation is explicit, and the TTL is only a safety net.** A time-based
cache alone would be wrong here in a way that matters: an organizer who closes
registrations expects them closed, not closed in fifty seconds. So every
endpoint that changes what the form shows drops that event's entries as it
writes, and the TTL exists for the cases nobody thought to wire up.

**Per-process, deliberately.** Each uvicorn worker keeps its own copy. A shared
store (Redis) would collapse the misses across workers too, but it is another
service to run, secure and pay for, and the win here is already the one that
matters: with N workers, a crowd of five hundred costs N reads instead of five
hundred.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)

# How long an entry survives without anyone invalidating it. Short enough that
# a forgotten invalidation is a minor staleness rather than a wrong page, long
# enough to flatten the spike a mailshot produces.
TTL_SECONDS = float(os.getenv("PUBLIC_CACHE_TTL", "60"))

# A ceiling, so a bot walking bad tokens cannot grow this without limit. Each
# entry is a few kilobytes; a thousand of them is single-digit megabytes, and
# an event has at most a handful of (language, badge) combinations.
MAX_ENTRIES = int(os.getenv("PUBLIC_CACHE_MAX_ENTRIES", "1000"))


class PayloadCache:
    """A bounded TTL cache whose entries can also be dropped by owner.

    Two indexes rather than one: `_entries` answers "what is cached under this
    key", `_by_owner` answers "which keys belong to this event". The second is
    what makes invalidation possible at all — the cache key is built from a
    registration token, and an organizer saving a theme knows their event id,
    not the tokens pointing at it.
    """

    def __init__(self, ttl: float = TTL_SECONDS, max_entries: int = MAX_ENTRIES):
        self.ttl = ttl
        self.max_entries = max_entries
        self._entries: dict[str, tuple[float, Any]] = {}
        self._by_owner: dict[str, set[str]] = {}
        # Sync handlers and dependencies run in a threadpool, so two requests
        # really can touch this at once. The critical sections are dictionary
        # operations; the lock costs nothing next to the read it avoids.
        self._lock = threading.Lock()
        self.hits = 0
        self.misses = 0

    def get(self, key: str) -> Optional[Any]:
        """The cached value, or None when absent or expired."""
        now = time.monotonic()
        with self._lock:
            entry = self._entries.get(key)
            if entry is None:
                self.misses += 1
                return None
            expires_at, value = entry
            if expires_at <= now:
                # Expired entries are dropped on the way past rather than by a
                # sweeper: there is no thread to run one, and a cache this
                # small does not need one.
                self._forget(key)
                self.misses += 1
                return None
            self.hits += 1
            return value

    def put(self, key: str, owner: str, value: Any) -> None:
        """Cache `value` under `key`, owned by `owner` for invalidation."""
        with self._lock:
            if len(self._entries) >= self.max_entries and key not in self._entries:
                # Oldest first. Not an LRU — insertion order is enough for a
                # cache whose entries all expire within a minute anyway.
                oldest = next(iter(self._entries), None)
                if oldest is not None:
                    self._forget(oldest)
            self._entries[key] = (time.monotonic() + self.ttl, value)
            self._by_owner.setdefault(owner, set()).add(key)

    def invalidate(self, owner: str) -> int:
        """Drop everything belonging to one event. Returns how many went.

        Called from every endpoint that changes what the public form shows, so
        a save is visible on the next request rather than after the TTL.
        """
        with self._lock:
            keys = self._by_owner.pop(owner, set())
            for key in keys:
                self._entries.pop(key, None)
        if keys:
            logger.info("Public cache: dropped %d entries for event %s", len(keys), owner)
        return len(keys)

    def clear(self) -> None:
        with self._lock:
            self._entries.clear()
            self._by_owner.clear()

    def stats(self) -> dict[str, Any]:
        with self._lock:
            served = self.hits + self.misses
            return {
                "entries": len(self._entries),
                "hits": self.hits,
                "misses": self.misses,
                "hit_rate": round(self.hits / served, 3) if served else 0.0,
                "ttl_seconds": self.ttl,
            }

    def _forget(self, key: str) -> None:
        """Remove one key from both indexes. Caller holds the lock."""
        self._entries.pop(key, None)
        for owner, keys in list(self._by_owner.items()):
            if key in keys:
                keys.discard(key)
                if not keys:
                    del self._by_owner[owner]
                break


# The one instance the application uses. Module-level, so every request in a
# worker shares it and nothing has to thread it through FastAPI's dependencies.
public_form = PayloadCache()


def form_key(token: str, lang: str, badge: Optional[str]) -> str:
    """What makes two requests interchangeable.

    Language and badge both change the payload — a Dutch visitor gets Dutch
    labels, and a badge hides the fields it is not allowed to see — so both
    belong in the key. Nothing else about the caller does: the page is
    identical for everyone holding the same link.
    """
    return "%s|%s|%s" % (token, lang, badge or "")


def cached_or_build(
    key: str,
    owner: str,
    build: Callable[[], Any],
    cache: Optional[PayloadCache] = None,
) -> tuple[Any, bool]:
    """Return `(value, was_cached)`, computing it only on a miss.

    A cache that can fail a page is worse than no cache, so `build` runs
    outside the lock and any exception it raises propagates untouched — a
    404 for an unknown token must still be a 404.
    """
    store = cache or public_form
    hit = store.get(key)
    if hit is not None:
        return hit, True
    value = build()
    store.put(key, owner, value)
    return value, False
