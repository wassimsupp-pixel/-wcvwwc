"""
services/history_service.py — Why a value changed, not just that it did.

``change_log`` has recorded every field-level change since the beginning: who,
when, which field, from what to what. What it could never say is **where the new
value came from** (feedback §19), and that is the one column an organizer
actually needs. "Phone changed from X to Y" invites the question. "Phone changed
because Tuesday's FCM export said so" answers it.

Six origins, taken from the feedback's own list:

    FCM Upload · Registration Form · Hotel File · Manual Update ·
    Participant Email · AI Suggestion

New writes record their origin explicitly. Older rows never had the column, so
this module INFERS one from the reason code — and says so, with a distinct
``inferred`` flag rather than a confident label. A history that quietly
back-fills its own gaps is worse than one that admits them: somebody arguing
about who changed a passport number needs to know which lines are evidence.

One more rule, from §23. The log holds passport numbers and dietary
requirements in plain text, because that is what changed. A history SCREEN that
reprints them turns an audit trail into a second copy of the sensitive data, so
the values of sensitive fields are reported as changed without being repeated.
"""

from __future__ import annotations

import logging
from typing import Any, Iterable, Optional

from services import field_policy
from services.supplier_export import SENSITIVE_KEYS

logger = logging.getLogger(__name__)

# Canonical origins. The keys are stable and stored; the labels are what a
# human reads.
FCM_UPLOAD = "fcm_upload"
REGISTRATION_FORM = "registration_form"
HOTEL_FILE = "hotel_file"
TRANSFER_FILE = "transfer_file"
MANUAL_UPDATE = "manual_update"
PARTICIPANT_EMAIL = "participant_email"
AI_SUGGESTION = "ai_suggestion"
SYSTEM = "system"
UNKNOWN = "unknown"

LABELS: dict[str, str] = {
    FCM_UPLOAD: "Import FCM",
    REGISTRATION_FORM: "Formulaire d'inscription",
    HOTEL_FILE: "Fichier hôtel",
    TRANSFER_FILE: "Fichier transferts",
    MANUAL_UPDATE: "Modification manuelle",
    PARTICIPANT_EMAIL: "Email du participant",
    AI_SUGGESTION: "Suggestion IA",
    SYSTEM: "Traitement automatique",
    UNKNOWN: "Origine inconnue",
}

# uploaded_files.source_type -> origin. The enum already carries the
# distinction the feedback asks for, so an import only has to pass it along.
FROM_SOURCE_TYPE: dict[str, str] = {
    "fcm": FCM_UPLOAD,
    "registration": REGISTRATION_FORM,
    "hotel": HOTEL_FILE,
    "transfer": TRANSFER_FILE,
    "email": PARTICIPANT_EMAIL,
}

# change_reason -> origin, for the rows written before the column existed.
# Deliberately incomplete: "import" alone cannot tell an FCM export from a hotel
# spreadsheet, and guessing would put a confident wrong word in an audit trail.
_FROM_REASON: dict[str, str] = {
    "manual_edit": MANUAL_UPDATE,
    "human_arbitration": MANUAL_UPDATE,
    "lock": MANUAL_UPDATE,
    "unlock": MANUAL_UPDATE,
    "resolve_exception": MANUAL_UPDATE,
    "email_agent": AI_SUGGESTION,
    "rooming_list_generated": SYSTEM,
    "consolidation": SYSTEM,
}

# Fields whose VALUES must not be reprinted in a history screen (§23). The
# change is reported; the content is not repeated.
_MASKED = frozenset(SENSITIVE_KEYS) | {"date_of_birth", "passport_number"}

_EXTRA_LABELS: dict[str, str] = {
    "last_name": "Nom",
    "room_number": "N° de chambre",
    "room_type": "Type de chambre",
    "roommate_name": "Roommate",
    "roommate_participant_id": "Lien roommate",
    "has_flight": "Vol", "has_hotel": "Hébergement",
    "has_transfer": "Transfert", "has_activities": "Activités",
    "status": "Statut",
    "completeness_status": "Complétude",
}


def field_label(field_name: str) -> str:
    """A human name for a field, including the dotted ones.

    ``locked_fields.email`` reads as "Verrou — Adresse email", because "a lock
    was placed on the email" and "the email changed" are different events and a
    history that renders both as "locked_fields.email" makes the reader do the
    parsing.
    """
    if field_name.startswith("locked_fields."):
        return f"Verrou — {field_label(field_name.split('.', 1)[1])}"
    return _EXTRA_LABELS.get(field_name) or field_policy.label(field_name)


def infer(row: dict[str, Any]) -> tuple[str, bool]:
    """The origin of one change, and whether we had to guess it.

    Returns ``(origin, inferred)``. A stored origin is never second-guessed:
    the writer knew more than we can reconstruct afterwards.
    """
    stored = str(row.get("source") or "").strip()
    if stored:
        return (stored if stored in LABELS else UNKNOWN), False

    reason = str(row.get("change_reason") or "").strip()
    guessed = _FROM_REASON.get(reason)
    if guessed:
        return guessed, True
    return UNKNOWN, True


def _mask(field_name: str, value: Any) -> str:
    """A value fit to appear on a screen."""
    base = field_name.split(".", 1)[-1]
    text = "" if value is None else str(value)
    if base in _MASKED and text.strip():
        return "•••"
    return text


def readable(
    rows: Iterable[dict[str, Any]],
    users: Optional[dict[str, str]] = None,
    participants: Optional[dict[str, str]] = None,
) -> list[dict[str, Any]]:
    """The change log as §19 asks for it: one line, seven columns.

    ``users`` and ``participants`` map ids to names. A missing name falls back
    to the id rather than to an empty cell — an audit line that names nobody is
    not an audit line.
    """
    users = users or {}
    participants = participants or {}
    out: list[dict[str, Any]] = []

    for row in rows:
        origin, inferred = infer(row)
        field_name = str(row.get("field_name") or "")
        entity_id = str(row.get("entity_id") or "")
        out.append({
            "id": row.get("id"),
            "at": row.get("changed_at"),
            "user_id": row.get("user_id"),
            "user": users.get(row.get("user_id")) or row.get("user_id") or "—",
            "entity_type": row.get("entity_type"),
            "entity_id": entity_id,
            "participant": participants.get(entity_id, ""),
            "field": field_name,
            "field_label": field_label(field_name),
            "old_value": _mask(field_name, row.get("old_value")),
            "new_value": _mask(field_name, row.get("new_value")),
            "masked": field_name.split(".", 1)[-1] in _MASKED,
            "source": origin,
            "source_label": LABELS.get(origin, LABELS[UNKNOWN]),
            "source_inferred": inferred,
            "reason": row.get("change_reason") or "",
        })
    return out


def summarise(lines: list[dict[str, Any]]) -> dict[str, Any]:
    """Where this event's changes have been coming from.

    The number worth looking at is ``inferred``: it says how much of the
    history predates the column and therefore cannot be relied on in an
    argument.
    """
    by_source: dict[str, int] = {}
    by_field: dict[str, int] = {}
    for line in lines:
        by_source[line["source"]] = by_source.get(line["source"], 0) + 1
        by_field[line["field"]] = by_field.get(line["field"], 0) + 1
    return {
        "changes": len(lines),
        "inferred": sum(1 for line in lines if line["source_inferred"]),
        "by_source": dict(sorted(by_source.items())),
        "by_field": dict(sorted(by_field.items(), key=lambda kv: (-kv[1], kv[0]))[:12]),
        "people": len({line["entity_id"] for line in lines if line["entity_type"] == "participant"}),
    }


def describe_sources() -> list[dict[str, str]]:
    """The filter list for the history screen."""
    return [{"key": key, "label": label} for key, label in LABELS.items()]
