"""
services/exception_service.py — Data quality exception detector.

Detects structural, logical, and data-quality issues in consolidated event data
and writes them to the ``exceptions`` table for human review.

Detectable exception types:
  PARTICIPANT_NO_FLIGHT   — participant has no linked flight record
  FLIGHT_NO_PARTICIPANT   — FCM source record not linked to any participant
  DATE_INCOHERENCE        — departure before arrival, or dates outside event window
  INVALID_FORMAT          — unparseable date or invalid email format
  MISSING_REQUIRED_FIELD  — first_name, last_name, or email missing after normalisation
  DATA_CONFLICT           — conflicting values between registration and FCM sources
  PARTICIPANT_NO_HOTEL    — participant has no hotel information
  PARTICIPANT_NO_TRANSFER — participant has no transfer information
  MISSING_CONTACT         — participant has neither an email nor a phone number
"""

from __future__ import annotations

import logging
import re
import uuid
from typing import Any, Iterable, Optional

from supabase import Client

from services import field_policy

logger = logging.getLogger(__name__)

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_DATE_RE  = re.compile(r"^\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2}(:\d{2})?(\.\d+)?([+-]\d{2}:?\d{2}|Z)?)?$")  # ISO 8601 (date, optional time)

# Systemic-anomaly escalation (2026-08-01, mapping-health plan phase 1): when a
# coverage gap or a missing profile field hits nearly EVERY participant of a
# real event, the odds that hundreds of people genuinely lack that data are
# negligible next to the odds that a column mapping silently sent it to the
# wrong field — the exact failure mode behind the two 2026-07 incidents (600
# transfer rows → 0 transfers; a Country column → 300 blank nationalities),
# which nothing surfaced until a manual audit. Ratio at/above this on events
# with a meaningful population escalates the alert to a warning that points at
# the mapping, instead of an info card nobody reads.
_SYSTEMIC_ANOMALY_RATIO = 0.9
_SYSTEMIC_ANOMALY_MIN_PARTICIPANTS = 20


# Above this many people travelling outside the programme dates, the alert is
# one line about the group rather than one card each.
_STAYING_INDIVIDUAL_MAX = 8


def _is_systemic(missing_count: int, total_participants: int) -> bool:
    """True when a gap is too widespread to plausibly be real data."""
    return (
        total_participants >= _SYSTEMIC_ANOMALY_MIN_PARTICIPANTS
        and missing_count / total_participants >= _SYSTEMIC_ANOMALY_RATIO
    )


def _insert_exception(
    supabase: Client,
    run_id: str,
    event_id: str,
    exception_type: str,
    severity: str,
    message: str,
    participant_id: Optional[str] = None,
    source_record_id: Optional[str] = None,
    context_data: Optional[dict] = None,
    exceptions_list: Optional[list[dict]] = None,
) -> None:
    """
    Insert a single exception record into the ``exceptions`` table (or collect in list).
    """
    record = {
        "id": str(uuid.uuid4()),
        "run_id": run_id,
        "event_id": event_id,
        "exception_type": exception_type,
        "severity": severity,
        "message": message,
        "participant_id": participant_id,
        "source_record_id": source_record_id,
        "context_data": context_data,
        "resolved": False,
    }
    if exceptions_list is not None:
        exceptions_list.append(record)
        return

    # Translate only on direct database insert
    db_record = record.copy()
    if db_record["exception_type"] == "NAME_MISMATCH_BETWEEN_SOURCES":
        db_record["exception_type"] = "DATA_CONFLICT"
        if db_record["context_data"] is None:
            db_record["context_data"] = {}
        else:
            db_record["context_data"] = db_record["context_data"].copy()
        db_record["context_data"]["original_type"] = "NAME_MISMATCH_BETWEEN_SOURCES"

    try:
        supabase.table("exceptions").insert(db_record).execute()
    except Exception as exc:
        logger.error("Failed to insert exception %s: %s", exception_type, exc)


def detect_all(
    event_id: str,
    run_id: str,
    supabase: Client,
    event_start_date: Optional[str] = None,
    event_end_date: Optional[str] = None,
    unresolved_roommates: Optional[list[dict]] = None,
    night_mismatches: Optional[list[dict]] = None,
) -> int:
    """
    Run all exception detectors for an event after consolidation.
    """
    exceptions_to_insert: list[dict] = []

    # What this event actually needs to know about its participants (feedback
    # §10). A field marked "not_used" cannot raise an alert here, however blank
    # it is — that is the whole point: an event that never collects nationality
    # must not open on 150 cards saying so. Unconfigured events resolve to the
    # defaults, which are exactly the fields this engine already alerted on.
    policy = field_policy.for_event(supabase, event_id)

    # Which source types were imported for this event? "Missing X" alerts only
    # make sense once the X source file exists — otherwise every participant is
    # flagged as missing X, which is pure noise (feedback §14).
    imported_types: set[str] = set()
    try:
        files = supabase.table("uploaded_files").select("source_type").eq("event_id", event_id).execute()
        imported_types = {f["source_type"] for f in (files.data or []) if f.get("source_type")}
    except Exception as exc:
        logger.warning("Could not load imported source types: %s", exc)

    # Event population, computed once — the systemic-anomaly escalation in the
    # coverage/missing-field detectors compares gap sizes against it.
    total_participants = 0
    try:
        count_resp = (
            supabase.table("participants")
            .select("id", count="exact")
            .eq("event_id", event_id)
            .limit(1)
            .execute()
        )
        total_participants = count_resp.count or 0
    except Exception as exc:
        logger.warning("Could not count participants for event %s: %s", event_id, exc)

    if "fcm" in imported_types and field_policy.is_required(policy, "flight"):
        _aggregate_coverage_exception(
            event_id, run_id, supabase, exceptions_to_insert,
            flag="has_flight", exception_type="PARTICIPANT_NO_FLIGHT",
            message_fr="{count} participant(s) sans vol enregistré. Voir la master list, filtre « Sans vol ».",
            total_participants=total_participants,
        )
    _detect_flight_no_participant(event_id, run_id, supabase, exceptions_to_insert)
    _detect_missing_required_fields(event_id, run_id, supabase, exceptions_to_insert)
    _detect_invalid_formats(event_id, run_id, supabase, exceptions_to_insert)
    _detect_date_incoherence(event_id, run_id, supabase, event_start_date, event_end_date, exceptions_to_insert)
    _detect_data_conflicts(event_id, run_id, supabase, exceptions_to_insert)
    # Possible duplicates now go to the "Fusions à vérifier" dashboard
    # (match_candidates) via the consolidation arbitration step — no longer
    # flooded here as exceptions.
    _detect_name_mismatches_between_sources(event_id, run_id, supabase, exceptions_to_insert)
    # Per-participant "missing info in the master list" alerts (feedback §14),
    # gated on the relevant source file having been imported.
    if "hotel" in imported_types and field_policy.is_required(policy, "hotel"):
        _aggregate_coverage_exception(
            event_id, run_id, supabase, exceptions_to_insert,
            flag="has_hotel", exception_type="PARTICIPANT_NO_HOTEL",
            message_fr="{count} participant(s) sans hébergement. Voir la master list, filtre « Sans hôtel ».",
            total_participants=total_participants,
        )
    if "transfer" in imported_types and field_policy.is_required(policy, "transfer"):
        # The exception_type ENUM has no PARTICIPANT_NO_TRANSFER value — reuse
        # MISSING_REQUIRED_FIELD (context_data carries the specifics).
        _aggregate_coverage_exception(
            event_id, run_id, supabase, exceptions_to_insert,
            flag="has_transfer", exception_type="MISSING_REQUIRED_FIELD",
            message_fr="{count} participant(s) sans transfert. Voir la master list, filtre « Sans transfert ».",
            total_participants=total_participants,
        )
    # Actionable per-participant missing profile fields (email/phone/nationality/
    # dietary) → the "Champs manquants" category with per-field sub-categories.
    _detect_missing_profile_fields(
        event_id, run_id, supabase, exceptions_to_insert,
        total_participants=total_participants,
        policy=policy,
    )
    # A twin nobody is paired with (feedback §4). Computed during consolidation
    # — the detector only formats what the rooming step could not resolve, so
    # the two can never disagree about who is linked.
    _detect_roommate_gaps(
        event_id, run_id, supabase, exceptions_to_insert,
        unresolved=unresolved_roommates or [], policy=policy,
    )
    # Flights say four nights, the hotel booked three (feedback §2). Computed
    # during consolidation for the same reason as the roommate gaps: the
    # comparison and the alert must read the same numbers.
    _detect_night_mismatches(
        event_id, run_id, supabase, exceptions_to_insert,
        mismatches=night_mismatches or [], policy=policy,
    )
    # The operational layer (feedback §18): things that are wrong not because a
    # box is empty but because two facts contradict each other. Gated on the
    # relevant source having been imported AND on the event tracking that
    # domain, which is how §18 itself ends — "les exceptions doivent dépendre
    # de la configuration du projet".
    _detect_travel_contradictions(
        event_id, run_id, supabase, exceptions_to_insert,
        event_start_date=event_start_date, event_end_date=event_end_date, policy=policy,
        imported_types=imported_types,
    )

    total = len(exceptions_to_insert)
    
    if exceptions_to_insert:
        db_payload = []
        for exc in exceptions_to_insert:
            db_exc = exc.copy()
            if db_exc["exception_type"] == "NAME_MISMATCH_BETWEEN_SOURCES":
                db_exc["exception_type"] = "DATA_CONFLICT"
                if db_exc["context_data"] is None:
                    db_exc["context_data"] = {}
                else:
                    db_exc["context_data"] = db_exc["context_data"].copy()
                db_exc["context_data"]["original_type"] = "NAME_MISMATCH_BETWEEN_SOURCES"
            db_payload.append(db_exc)

        try:
            logger.info("Bulk inserting %d exceptions for event %s run %s...", total, event_id, run_id)
            # Batch in chunks of 100
            for i in range(0, len(db_payload), 100):
                supabase.table("exceptions").insert(db_payload[i:i+100]).execute()
        except Exception as exc:
            logger.error("Failed to bulk insert exceptions: %s", exc)

    logger.info("Exception detection complete: %d exceptions for event %s run %s", total, event_id, run_id)
    return total


# ---------------------------------------------------------------------------
# Individual detectors
# ---------------------------------------------------------------------------

def _aggregate_coverage_exception(
    event_id: str,
    run_id: str,
    supabase: Client,
    exceptions_list: list[dict],
    *,
    flag: str,
    exception_type: str,
    message_fr: str,
    total_participants: int = 0,
) -> int:
    """
    COVERAGE gaps ("no flight / no hotel / no transfer") are NOT per-person
    errors: they get ONE aggregated info card with the count and the list of
    concerned participants — the master-list filters show the detail.

    When the gap covers ~everyone (_is_systemic), it stops being a data gap
    and almost certainly means the source file's column mapping sent the data
    to the wrong field — escalate to a warning that says so.
    """
    try:
        result = (
            supabase.table("participants")
            .select("id, first_name, last_name")
            .eq("event_id", event_id)
            .eq(flag, False)
            .execute()
        )
    except Exception as exc:
        logger.error("%s query failed: %s", exception_type, exc)
        return 0

    people = result.data or []
    if not people:
        return 0
    names = [f"{p.get('first_name', '')} {p.get('last_name', '')}".strip() for p in people]
    systemic = _is_systemic(len(people), total_participants)
    severity = "warning" if systemic else "info"
    message = message_fr.format(count=len(people))
    if systemic:
        message += (
            " Cette proportion est anormalement élevée pour des données réelles — "
            "vérifiez le mapping de colonnes du fichier source correspondant."
        )
    context_data = {
        "aggregate": True,
        # Which coverage dimension this card is about, in machine-readable
        # form. The exception_type alone cannot say: the ENUM has no
        # PARTICIPANT_NO_TRANSFER value, so the transfer card is filed under
        # the generic MISSING_REQUIRED_FIELD and was indistinguishable from any
        # other missing field. The UI needs this to expand the card into the
        # actual people concerned rather than showing a bare count.
        "coverage_flag": flag,
        "count": len(people),
        "participant_ids": [p["id"] for p in people[:500]],
        "sample_names": names[:15],
    }
    if systemic:
        context_data["systemic_anomaly"] = True
        context_data["total_participants"] = total_participants
    _insert_exception(
        supabase=supabase,
        run_id=run_id,
        event_id=event_id,
        exception_type=exception_type,
        severity=severity,
        message=message,
        participant_id=None,
        context_data=context_data,
        exceptions_list=exceptions_list,
    )
    return 1


def _detect_flight_no_participant(event_id: str, run_id: str, supabase: Client, exceptions_list: list[dict]) -> int:
    """
    FLIGHT_NO_PARTICIPANT — FCM source records not linked to any participant.
    """
    try:
        result = (
            supabase.table("source_records")
            .select("id, normalized_data, file_id")
            .eq("event_id", event_id)
            .is_("participant_id", "null")
            .execute()
        )
    except Exception as exc:
        logger.error("FLIGHT_NO_PARTICIPANT query failed: %s", exc)
        return 0

    if not result.data:
        return 0

    file_ids = list({r["file_id"] for r in result.data})
    try:
        files_resp = (
            supabase.table("uploaded_files")
            .select("id, source_type")
            .in_("id", file_ids)
            .execute()
        )
        fcm_file_ids = {f["id"] for f in files_resp.data if f["source_type"] == "fcm"}
    except Exception as exc:
        logger.error("Failed to load file types for FLIGHT_NO_PARTICIPANT: %s", exc)
        return 0

    count = 0
    for sr in result.data:
        if sr["file_id"] not in fcm_file_ids:
            continue
        nd: dict = sr.get("normalized_data") or {}
        name = f"{nd.get('first_name', '')} {nd.get('last_name', '')}".strip() or "Unknown"
        _insert_exception(
            supabase=supabase,
            run_id=run_id,
            event_id=event_id,
            exception_type="FLIGHT_NO_PARTICIPANT",
            severity="warning",
            message=f"Le vol au nom de « {name} » ne correspond à aucun participant inscrit.",
            source_record_id=sr["id"],
            context_data={"normalized_data": nd},
            exceptions_list=exceptions_list,
        )
        count += 1

    logger.debug("FLIGHT_NO_PARTICIPANT: %d exceptions", count)
    return count


def _detect_missing_required_fields(event_id: str, run_id: str, supabase: Client, exceptions_list: list[dict]) -> int:
    """
    MISSING_REQUIRED_FIELD — participants with NO usable name at all (critical:
    such a fiche cannot be identified, printed on a badge or exported).

    A single-token name is NOT an error. "Mohan", "髙取広太郎" (a Japanese name
    written without a space) are complete identities; flagging them "Critique"
    for a missing first_name buried the genuinely broken fiches under noise.
    An incomplete-but-usable name is reported as an actionable "Champs
    manquants" entry instead (see _detect_missing_profile_fields).

    Contact/profile fields (email, phone, nationality, dietary) are likewise
    handled there.
    """
    try:
        result = (
            supabase.table("participants")
            .select("id, first_name, last_name, email")
            .eq("event_id", event_id)
            .execute()
        )
    except Exception as exc:
        logger.error("MISSING_REQUIRED_FIELD query failed: %s", exc)
        return 0

    count = 0
    for p in result.data or []:
        first = (p.get("first_name") or "").strip()
        last = (p.get("last_name") or "").strip()
        if first or last:
            continue                       # a name exists — nothing critical here

        email = (p.get("email") or "").strip()
        who = f"« {email} »" if email else "sans email"
        _insert_exception(
            supabase=supabase,
            run_id=run_id,
            event_id=event_id,
            exception_type="MISSING_REQUIRED_FIELD",
            severity="critical",
            message=(
                f"Fiche sans aucun nom ({who}), impossible à identifier. "
                "Ajoutez le nom, ou vérifiez la colonne « Nom » du fichier source."
            ),
            participant_id=p["id"],
            context_data={"missing_fields": ["first_name", "last_name"]},
            exceptions_list=exceptions_list,
        )
        count += 1

    logger.debug("MISSING_REQUIRED_FIELD: %d exceptions", count)
    return count


# Profile fields surfaced in the actionable "Champs manquants" category, each an
# editable field on the participant fiche so the "Ajouter" button can fill it.
# first_name is here rather than in the critical check: a mononym ("Mohan") is a
# usable identity, so it is something to COMPLETE, not an error to fix.
_MISSING_PROFILE_FIELDS = ("first_name", "email", "phone", "nationality", "dietary_requirements")

# Cards that are ABOUT one policy key without naming it in `missing_fields`.
# Read-time filtering needs the mapping: a rule turned off today has to take
# effect today, not at whatever hour somebody next presses Consolidate.
_CATEGORY_POLICY_KEY = {
    "missing_return_flight": "return_flight",
}

# What each of those fields is CALLED. Used by both messages this detector
# writes: the per-person card used to interpolate the raw column name, so an
# organizer looking for the dietary alert read "champ(s) manquant(s) :
# dietary_requirements" and did not recognise their own feature.
_FIELD_LABELS: dict[str, str] = {
    "first_name": "prénom",
    "email": "email",
    "phone": "téléphone",
    "nationality": "nationalité",
    "dietary_requirements": "régime alimentaire",
}


def _detect_missing_profile_fields(
    event_id: str,
    run_id: str,
    supabase: Client,
    exceptions_list: list[dict],
    total_participants: int = 0,
    policy: Optional[dict[str, str]] = None,
) -> int:
    """
    MISSING_FIELD ("Champs manquants") — ONE exception per participant that is
    missing any of the actionable profile fields (email, phone, nationality,
    dietary). context_data.missing_fields lets the UI sort each person into the
    right sub-category (Email / Téléphone / Nationalité / Régime), each with an
    "Ajouter" button that opens their fiche. One exception per person (not per
    field) keeps the volume sane.

    On top of the per-person cards: a field missing on ~everyone (_is_systemic)
    is almost never 300 people forgetting the same box — it's a source column
    mapped to the wrong field (the 2026-07 nationality incident: a "Country"
    column silently routed to an internal field, 300 blank nationalities, zero
    signal). One extra aggregated warning per such field points at the mapping.

    Only the fields this event marks ``required`` are considered (feedback
    §10). A field the event does not insist on is not a gap, so it produces
    neither a per-person card nor a systemic warning — including when it is
    blank on literally everyone, which for an unused field is the expected
    state and not an anomaly worth escalating.
    """
    resolved = policy if policy is not None else field_policy.resolve(None)
    tracked = field_policy.required_keys(resolved, _MISSING_PROFILE_FIELDS)
    if not tracked:
        logger.debug("MISSING_FIELD: no field is required for this event — skipped")
        return 0

    try:
        result = (
            supabase.table("participants")
            .select("id, first_name, last_name, email, phone, nationality, dietary_requirements")
            .eq("event_id", event_id)
            .execute()
        )
    except Exception as exc:
        logger.error("MISSING_FIELD query failed: %s", exc)
        return 0

    count = 0
    field_gap_counts: dict[str, int] = {}
    for p in result.data or []:
        missing = [f for f in tracked if not (p.get(f) or "").strip()]
        for f in missing:
            field_gap_counts[f] = field_gap_counts.get(f, 0) + 1
        if not missing:
            continue
        # A fiche with no name at all is already reported as critical — don't
        # duplicate it here as a mere "champ manquant".
        if not (p.get("first_name") or "").strip() and not (p.get("last_name") or "").strip():
            continue
        name = f"{p.get('first_name', '')} {p.get('last_name', '')}".strip() or p["id"]
        _insert_exception(
            supabase=supabase,
            run_id=run_id,
            event_id=event_id,
            # ENUM-valid; the "missing_field" category marker lives in context_data.
            exception_type="MISSING_REQUIRED_FIELD",
            severity="info",
            message=(
                f"Fiche de « {name} » incomplète — champ(s) manquant(s) : "
                f"{', '.join(_FIELD_LABELS.get(f, f) for f in missing)}."
            ),
            participant_id=p["id"],
            context_data={
                "category": "missing_field",
                "missing_fields": missing,
                "participant_name": name,
            },
            exceptions_list=exceptions_list,
        )
        count += 1

    for field, gap in sorted(field_gap_counts.items()):
        if not _is_systemic(gap, total_participants):
            continue
        label = _FIELD_LABELS.get(field, field)
        _insert_exception(
            supabase=supabase,
            run_id=run_id,
            event_id=event_id,
            exception_type="MISSING_REQUIRED_FIELD",
            severity="warning",
            message=(
                f"{gap} participant(s) sur {total_participants} n'ont aucune valeur "
                f"pour « {label} ». Cette proportion est anormalement élevée pour des "
                f"données réelles — vérifiez le mapping de colonnes du fichier source "
                f"correspondant."
            ),
            participant_id=None,
            context_data={
                "category": "missing_field",
                "systemic_anomaly": True,
                "field": field,
                "missing_count": gap,
                "total_participants": total_participants,
            },
            exceptions_list=exceptions_list,
        )
        count += 1

    logger.debug("MISSING_FIELD: %d exceptions", count)
    return count


_ROOMMATE_REASONS = {
    "no_name": (
        "warning",
        "« {name} » a demandé une chambre {room} sans indiquer avec qui la partager.",
    ),
    "unknown_name": (
        "warning",
        "« {name} » partage avec « {written} », qui ne correspond à aucun participant de l'événement.",
    ),
    "ambiguous_name": (
        "warning",
        "« {name} » partage avec « {written} », mais plusieurs participants portent ce nom — à trancher à la main.",
    ),
    "contradicted": (
        "warning",
        "« {name} » indique « {written} », qui a désigné quelqu'un d'autre — trois personnes ne tiennent pas dans une chambre double.",
    ),
}


def _detect_roommate_gaps(
    event_id: str,
    run_id: str,
    supabase: Client,
    exceptions_list: list[dict],
    unresolved: list[dict],
    policy: Optional[dict[str, str]] = None,
) -> int:
    """ROOMMATE_MISSING — a shared room with nobody on the other side.

    The feedback (§4) calls this one blocking before a rooming list can be
    considered final, and it is: an hotelier reading "twin" with a single name
    either gives the room to one person or calls to ask. Both cost money.

    Nothing is detected here — consolidation already worked out who could not
    be paired and why. This turns each case into a card, which is what keeps
    the alert and the link from ever telling two different stories.

    Silenced when the event marks ``roommate`` as not used: a conference where
    nobody shares must not open on a wall of these.
    """
    resolved = policy if policy is not None else field_policy.resolve(None)
    if not unresolved or not field_policy.is_tracked(resolved, "roommate"):
        return 0

    count = 0
    for gap in unresolved:
        severity, template = _ROOMMATE_REASONS.get(gap.get("reason", ""), (None, None))
        if not template:
            continue
        participant = gap.get("participant") or {}
        name = (
            f"{participant.get('first_name') or ''} {participant.get('last_name') or ''}".strip()
            or gap.get("participant_id")
            or "?"
        )
        room = str(participant.get("room_type") or "partagée").strip() or "partagée"
        _insert_exception(
            supabase=supabase,
            run_id=run_id,
            event_id=event_id,
            # ENUM-valid; the real category travels in context_data, exactly as
            # the "missing_field" cards do.
            exception_type="MISSING_REQUIRED_FIELD",
            severity=severity,
            message=template.format(name=name, room=room, written=gap.get("written_name") or "?"),
            participant_id=gap.get("participant_id"),
            context_data={
                "category": "roommate",
                "reason": gap.get("reason"),
                "participant_name": name,
                "written_name": gap.get("written_name") or "",
                "room_type": participant.get("room_type"),
            },
            exceptions_list=exceptions_list,
        )
        count += 1

    logger.debug("ROOMMATE_MISSING: %d exceptions", count)
    return count


def _detect_night_mismatches(
    event_id: str,
    run_id: str,
    supabase: Client,
    exceptions_list: list[dict],
    mismatches: list[dict],
    policy: Optional[dict[str, str]] = None,
) -> int:
    """ACCOMMODATION_MISMATCH — the flights and the hotel disagree.

    Land on the 1st, fly home on the 5th, and the rooming list holds three
    nights: somebody is sleeping in an airport. This is the check the feedback
    (§2) asks for by name, and it is the kind of error that costs nothing to
    fix a month ahead and a great deal at the front desk.

    Reported as a warning rather than an error: the hotel file can legitimately
    differ (a participant paying for their own last night elsewhere), so it
    needs a human look, not a blocked pipeline.
    """
    resolved = policy if policy is not None else field_policy.resolve(None)
    if not mismatches or not field_policy.is_tracked(resolved, "hotel"):
        return 0

    from services.accommodation_service import describe_mismatch

    count = 0
    for gap in mismatches:
        name = gap.get("participant_name") or gap.get("participant_id") or "?"
        _insert_exception(
            supabase=supabase,
            run_id=run_id,
            event_id=event_id,
            exception_type="DATA_CONFLICT",
            severity="warning",
            message=describe_mismatch(name, gap),
            participant_id=gap.get("participant_id"),
            context_data={
                "category": "accommodation_mismatch",
                "participant_name": name,
                "derived_nights": gap.get("derived_nights"),
                "booked_nights": gap.get("booked_nights"),
                "missing": gap.get("missing"),
                "extra": gap.get("extra"),
                "delta": gap.get("delta"),
            },
            exceptions_list=exceptions_list,
        )
        count += 1

    logger.debug("ACCOMMODATION_MISMATCH: %d exceptions", count)
    return count


def _detect_travel_contradictions(
    event_id: str,
    run_id: str,
    supabase: Client,
    exceptions_list: list[dict],
    event_start_date: Optional[str] = None,
    event_end_date: Optional[str] = None,
    policy: Optional[dict[str, str]] = None,
    imported_types: Optional[set[str]] = None,
) -> int:
    """The six operational alerts of feedback §18.

    Overlapping flights, a round trip entered backwards, a missing return, a
    flight the airline moved, a requested transfer nobody booked, a landing
    nobody is meeting, and a coach with more passengers than seats.

    Everything is gated twice. On the SOURCE — a "missing return flight" alert
    on an event whose flight file has not been imported would fire for every
    participant and mean nothing. And on the POLICY — §18 closes on exactly
    that rule, and an event that does not handle transfers must not be told
    about missing ones.

    Reads its own rows rather than taking them as arguments because it is the
    only consumer, and every fact it needs is one query away.
    """
    from services import travel_checks
    from services.accommodation_service import as_day

    resolved = policy if policy is not None else field_policy.resolve(None)
    imported = imported_types or set()
    count = 0

    flights: list[dict] = []
    if "fcm" in imported and field_policy.is_tracked(resolved, "flight"):
        try:
            flights = (
                supabase.table("flights")
                .select("participant_id, flight_number, departure_time, arrival_time, "
                        "status, departure_airport, arrival_airport")
                .eq("event_id", event_id)
                .execute()
            ).data or []
        except Exception as exc:
            logger.warning("§18: could not read flights: %s", exc)

    transfers: list[dict] = []
    if "transfer" in imported and field_policy.is_tracked(resolved, "transfer"):
        try:
            transfers = (
                supabase.table("transfers")
                .select("participant_id, vehicle_type, pickup_location, pickup_time, status")
                .eq("event_id", event_id)
                .execute()
            ).data or []
        except Exception as exc:
            logger.warning("§18: could not read transfers: %s", exc)

    if not flights and not transfers:
        return 0

    names = _participant_names(supabase, event_id)

    def emit(exception_type: str, severity: str, message: str, pid, context):
        _insert_exception(
            supabase=supabase, run_id=run_id, event_id=event_id,
            exception_type=exception_type, severity=severity, message=message,
            participant_id=pid, context_data=context, exceptions_list=exceptions_list,
        )

    contradicted: set[str] = set()
    for gap in travel_checks.conflicting_flights(flights):
        name = names.get(gap["participant_id"], gap["participant_id"])
        emit("DATA_CONFLICT", "critical",
             travel_checks.describe_conflict(name, gap),
             gap["participant_id"],
             {"category": "flight_conflict", "participant_name": name, **gap})
        contradicted.add(gap["participant_id"])
        count += 1

    # The same broken round trip, read from the airports instead of the clock.
    # Somebody already holding an overlap card does not need a second one saying
    # the same thing in other words — the two rules deliberately share ground,
    # and only the half the overlap cannot see is worth a card of its own.
    for gap in travel_checks.reversed_itinerary(flights):
        if gap["participant_id"] in contradicted:
            continue
        name = names.get(gap["participant_id"], gap["participant_id"])
        emit("DATA_CONFLICT", "critical",
             travel_checks.describe_reversed_itinerary(name, gap),
             gap["participant_id"],
             {"category": "flight_reversed", "participant_name": name, **gap})
        count += 1

    for gap in travel_checks.changed_flights(flights):
        name = names.get(gap["participant_id"], gap["participant_id"])
        emit("DATA_CONFLICT", "warning",
             travel_checks.describe_changed_flight(name, gap),
             gap["participant_id"],
             {"category": "flight_changed", "participant_name": name, **gap})
        count += 1

    if flights and field_policy.is_required(resolved, "return_flight"):
        end = as_day(event_end_date)
        gaps = travel_checks.missing_return(flights, end)

        # One card per person, UNLESS it is a whole cohort. A missing return
        # flight on three people is worth asking about individually; on forty
        # it is very rarely forty separate mistakes — it is a group extending
        # their stay at their own expense, or a delegation booked one-way on
        # purpose. Flagging each of them as a gap misreads an expected pattern
        # as a problem; one informational card asks the question once, for the
        # group, instead.
        with_flight = len({f["participant_id"] for f in flights if f.get("participant_id")})
        if gaps and _is_systemic(len(gaps), with_flight):
            emit("MISSING_REQUIRED_FIELD", "info",
                 travel_checks.describe_missing_return_systemic(len(gaps), with_flight),
                 None,
                 {
                     "category": "missing_return_flight",
                     "aggregate": True,
                     "count": len(gaps),
                     "total_participants": with_flight,
                     "participant_ids": [g["participant_id"] for g in gaps[:500]],
                     "sample_names": [
                         names.get(g["participant_id"], g["participant_id"])
                         for g in gaps[:15]
                     ],
                 })
            count += 1
        else:
            for gap in gaps:
                name = names.get(gap["participant_id"], gap["participant_id"])
                emit("MISSING_REQUIRED_FIELD", "warning",
                     travel_checks.describe_missing_return(name, gap),
                     gap["participant_id"],
                     {"category": "missing_return_flight", "participant_name": name, **gap})
                count += 1

    # People whose flights fall outside the programme's own dates — they have a
    # return, it simply leaves after the event ends (or they land before it
    # starts). Those are nights the client did not book, and the invoice will
    # decide who pays for them if nobody does it first.
    #
    # Not gated on the flight policy the way the missing-return check is: this
    # is a billing question, not a completeness one. An event that does not
    # require flights can still be handed a hotel bill for a night nobody
    # agreed to.
    if flights:
        stays = travel_checks.staying_at_own_expense(
            flights, as_day(event_start_date), as_day(event_end_date)
        )
        with_flight = len({f["participant_id"] for f in flights if f.get("participant_id")})
        # Grouped much sooner than the systemic threshold would allow.
        #
        # This is a billing question about a cohort, not a mistake repeated
        # once per person: measured on the live event, 36 of the 64 people
        # with a flight travel outside the programme dates — 141 nights. At
        # 56% that sits under the systemic ratio, so it would have produced
        # thirty-six separate cards each ending in a question mark, on a page
        # whose whole point is that everything on it needs doing.
        #
        # A handful is still worth naming one by one; a crowd is one line with
        # a total, which is also how the invoice will arrive.
        if stays and (len(stays) > _STAYING_INDIVIDUAL_MAX
                      or _is_systemic(len(stays), with_flight)):
            emit("MISSING_REQUIRED_FIELD", "info",
                 travel_checks.describe_staying_systemic(
                     len(stays), with_flight, sum(s["extra_nights"] for s in stays)),
                 None,
                 {
                     "category": "staying_own_expense",
                     "aggregate": True,
                     "count": len(stays),
                     "total_participants": with_flight,
                     "extra_nights": sum(s["extra_nights"] for s in stays),
                     "participant_ids": [s["participant_id"] for s in stays[:500]],
                     "sample_names": [
                         names.get(s["participant_id"], s["participant_id"])
                         for s in stays[:15]
                     ],
                 })
            count += 1
        else:
            for gap in stays:
                name = names.get(gap["participant_id"], gap["participant_id"])
                emit("MISSING_REQUIRED_FIELD", "info",
                     travel_checks.describe_staying(name, gap),
                     gap["participant_id"],
                     {"category": "staying_own_expense", "participant_name": name, **gap})
                count += 1

    if field_policy.is_tracked(resolved, "transfer"):
        participants = _participants_for_transfer_checks(supabase, event_id)

        for gap in travel_checks.transfer_requested_not_assigned(participants, transfers):
            emit("MISSING_REQUIRED_FIELD", "warning",
                 travel_checks.describe_transfer_requested(gap["name"]),
                 gap["participant_id"],
                 {"category": "transfer_not_assigned", "participant_name": gap["name"]})
            count += 1

        if flights and field_policy.is_required(resolved, "transfer"):
            gaps = travel_checks.flight_without_transfer(participants, transfers)

            # One card per person, UNLESS it is everybody. A hundred cards all
            # saying the same sentence is not a hundred findings: it is one
            # finding about the EVENT — the transfer file was never imported,
            # or its participant column went to the wrong field (the
            # 2026-07 incident: 600 transfer rows, 0 transfers linked).
            #
            # Per-person cards are for gaps somebody can act on one at a time.
            # When the ratio says otherwise, the actionable item is the import,
            # and burying it under a hundred identical rows is how a list
            # nobody reads gets built.
            with_flight = sum(1 for p in participants if p.get("has_flight"))
            if gaps and _is_systemic(len(gaps), with_flight):
                emit("MISSING_REQUIRED_FIELD", "warning",
                     travel_checks.describe_flight_no_transfer_systemic(
                         len(gaps), with_flight
                     ),
                     None,
                     {
                         "category": "flight_without_transfer",
                         "aggregate": True,
                         "systemic_anomaly": True,
                         "coverage_flag": "has_transfer",
                         "count": len(gaps),
                         "total_participants": with_flight,
                         "participant_ids": [g["participant_id"] for g in gaps[:500]],
                         "sample_names": [g["name"] for g in gaps[:15]],
                     })
                count += 1
            else:
                for gap in gaps:
                    emit("MISSING_REQUIRED_FIELD", "warning",
                         travel_checks.describe_flight_no_transfer(gap["name"]),
                         gap["participant_id"],
                         {"category": "flight_without_transfer",
                          "participant_name": gap["name"]})
                    count += 1

        for gap in travel_checks.capacity_exceeded(transfers, _fleet_for(supabase, event_id)):
            emit("DATA_CONFLICT", "critical",
                 travel_checks.describe_capacity(gap), None,
                 {"category": "capacity_exceeded", **gap})
            count += 1

    logger.debug("§18 travel contradictions: %d exceptions", count)
    return count


def _participant_names(supabase: Client, event_id: str) -> dict[str, str]:
    try:
        rows = (
            supabase.table("participants")
            .select("id, first_name, last_name")
            .eq("event_id", event_id)
            .execute()
        ).data or []
    except Exception as exc:
        logger.warning("§18: could not read participant names: %s", exc)
        return {}
    return {
        r["id"]: " ".join(
            p for p in (r.get("first_name"), r.get("last_name")) if p
        ).strip() or r["id"]
        for r in rows
    }


def _participants_for_transfer_checks(supabase: Client, event_id: str) -> list[dict]:
    """The fiches, with ``transfer_needed`` when that column exists.

    Two queries rather than one: PostgREST fails the whole select when a column
    is absent, and transfer_needed only arrives with migration 010. Without it
    the "requested but not assigned" check simply finds nothing, which is the
    right answer for a deployment that never asked the question.
    """
    try:
        rows = (
            supabase.table("participants")
            .select("id, first_name, last_name, has_flight")
            .eq("event_id", event_id)
            .execute()
        ).data or []
    except Exception as exc:
        logger.warning("§18: could not read participants: %s", exc)
        return []

    try:
        extra = (
            supabase.table("participants")
            .select("id, transfer_needed")
            .eq("event_id", event_id)
            .execute()
        ).data or []
        wanted = {r["id"]: r.get("transfer_needed") for r in extra}
        for row in rows:
            row["transfer_needed"] = wanted.get(row["id"])
    except Exception as exc:
        logger.info("§18: transfer_needed unavailable (migration 010?): %s", exc)

    return rows


def _fleet_for(supabase: Client, event_id: str) -> list[dict]:
    """The event's own fleet, or the defaults it has not overridden."""
    from services import dispatch_service
    try:
        res = (
            supabase.table("events")
            .select("transfer_settings")
            .eq("id", event_id)
            .single()
            .execute()
        )
        stored = (res.data or {}).get("transfer_settings")
    except Exception:
        stored = None
    return dispatch_service.resolve_settings(stored).get("fleet") or []


def _detect_invalid_formats(event_id: str, run_id: str, supabase: Client, exceptions_list: list[dict]) -> int:
    """
    INVALID_FORMAT — source records with unparseable dates or invalid emails.
    """
    date_fields = {"departure_date", "return_date", "check_in_date", "check_out_date"}

    try:
        result = (
            supabase.table("source_records")
            .select("id, normalized_data")
            .eq("event_id", event_id)
            .not_.is_("normalized_data", "null")
            .execute()
        )
    except Exception as exc:
        logger.error("INVALID_FORMAT query failed: %s", exc)
        return 0

    # Local import: consolidation_service imports this module at load time.
    from services.consolidation_service import resolve_identity_name

    _DATE_LABELS = {
        "departure_date": "date de départ", "return_date": "date de retour",
        "check_in_date": "date d'arrivée hôtel", "check_out_date": "date de départ hôtel",
    }

    count = 0
    for sr in result.data or []:
        nd: dict = sr.get("normalized_data") or {}
        issues: list[str] = []

        # Check email format
        email = nd.get("email")
        if email and not _EMAIL_RE.match(email):
            issues.append(f"email « {email} » n'est pas une adresse valide")

        # Check date fields
        for df in date_fields:
            val = nd.get(df)
            if val and isinstance(val, str) and not _DATE_RE.match(val):
                issues.append(f"{_DATE_LABELS.get(df, df)} « {val} » est illisible")

        if issues:
            # Name the person, not the row's UUID: an operator can act on
            # "Ligne de Steven Krithinakis", never on "Source record 7dd668dd-…".
            first, last = resolve_identity_name(nd)
            who = f"{first} {last}".strip()
            subject = f"Ligne de « {who} »" if who else "Une ligne du fichier source"
            _insert_exception(
                supabase=supabase,
                run_id=run_id,
                event_id=event_id,
                exception_type="INVALID_FORMAT",
                severity="warning",
                message=f"{subject} : {' ; '.join(issues)}.",
                source_record_id=sr["id"],
                context_data={"issues": issues, "normalized_data": nd},
                exceptions_list=exceptions_list,
            )
            count += 1

    logger.debug("INVALID_FORMAT: %d exceptions", count)
    return count


def _detect_date_incoherence(
    event_id: str,
    run_id: str,
    supabase: Client,
    event_start: Optional[str],
    event_end: Optional[str],
    exceptions_list: list[dict],
) -> int:
    """
    DATE_INCOHERENCE — a row that leaves before it arrives.

    The out-of-window half of this check is deliberately gone. A departure
    after the event ends is not an incoherent date: it is somebody flying home
    on their own nights, which ``staying_at_own_expense`` reports properly —
    by name, with the count of nights, grouped when it is a crowd, and carried
    on the master list as a fact rather than a question. Reporting it here too
    meant the same truth arriving twice, and the worse version was the loud
    one: English, per source row, against a UUID nobody can act on.

    What is left is a genuine contradiction inside a single row, and one
    nothing else covers.
    """
    try:
        result = (
            supabase.table("source_records")
            .select("id, participant_id, normalized_data")
            .eq("event_id", event_id)
            .not_.is_("normalized_data", "null")
            .execute()
        )
    except Exception as exc:
        logger.error("DATE_INCOHERENCE query failed: %s", exc)
        return 0

    names = _participant_names(supabase, event_id)
    count = 0
    seen: set[tuple[str, str, str]] = set()

    for sr in result.data or []:
        nd: dict = sr.get("normalized_data") or {}
        dep = nd.get("departure_date")
        ret = nd.get("return_date")

        if not (dep and ret and _DATE_RE.match(dep) and _DATE_RE.match(ret)):
            continue
        if dep <= ret:
            continue

        pid = sr.get("participant_id")
        # One card per person and per pair of dates. The same contradiction
        # copied across two source files is one problem, not two.
        key = (str(pid or sr["id"]), dep, ret)
        if key in seen:
            continue
        seen.add(key)

        who = names.get(pid) if pid else None
        subject = f"« {who} »" if who else "Une ligne source"
        _insert_exception(
            supabase=supabase,
            run_id=run_id,
            event_id=event_id,
            exception_type="DATE_INCOHERENCE",
            severity="warning",
            message=(
                f"{subject} repart le {_fr_date(dep)} alors que le retour est "
                f"noté au {_fr_date(ret)} : le départ est après le retour. "
                f"L'une des deux dates est fausse."
            ),
            participant_id=pid,
            source_record_id=sr["id"],
            context_data={
                "category": "date_incoherence",
                "participant_name": who or "",
                "departure_date": dep,
                "return_date": ret,
            },
            exceptions_list=exceptions_list,
        )
        count += 1

    logger.debug("DATE_INCOHERENCE: %d exceptions", count)
    return count


def _fr_date(value: str) -> str:
    """2026-09-08 as 08/09/2026 — the way the rest of the screen writes it."""
    parts = str(value or "").split("-")
    return f"{parts[2]}/{parts[1]}/{parts[0]}" if len(parts) == 3 else str(value)


_LEGAL_SUFFIX_RE = re.compile(
    r"\b(inc|llc|ltd|limited|corp|corporation|co|sa|sas|sarl|gmbh|bv|nv|plc|ag|spa|srl|pty|group|holding|hldg)\b",
    re.I,
)


def _norm_org(v: Any) -> str:
    """Company/organisation name reduced to its meaningful core: no punctuation,
    no legal suffix, no case — 'LivaNova Inc.' == 'LIVANOVA'."""
    s = re.sub(r"[^a-z0-9 ]", " ", str(v or "").lower())
    s = _LEGAL_SUFFIX_RE.sub(" ", s)
    return " ".join(s.split())


def _values_conflict(field: str, a: Any, b: Any) -> bool:
    """
    True only when two source values GENUINELY disagree — formatting differences
    never count. Phones compare on digits / last 9 (so '+1 513 376 1196' ==
    '5133761196'); organisations ignore case, punctuation and legal suffixes.
    """
    sa, sb = str(a or "").strip(), str(b or "").strip()
    if not sa or not sb:
        return False
    if field == "phone":
        na = re.sub(r"\D", "", sa)
        nb = re.sub(r"\D", "", sb)
        if not na or not nb or na == nb:
            return False
        tail = min(len(na), len(nb), 9)
        return na[-tail:] != nb[-tail:]
    if field in ("company", "nationality"):
        ca, cb = _norm_org(sa), _norm_org(sb)
        if not ca or not cb:
            return False
        # One being a prefix/subset of the other ("LivaNova" vs "LivaNova France")
        # is a refinement, not a contradiction.
        return not (ca == cb or ca in cb or cb in ca)
    return sa.lower() != sb.lower()


# Field names as they read in a conflict message, so the card says
# "nationalité" rather than the column name.
_FIELD_FR = {"nationality": "nationalité", "company": "société",
             "phone": "téléphone", "email": "email"}


def _detect_data_conflicts(event_id: str, run_id: str, supabase: Client, exceptions_list: list[dict]) -> int:
    """
    DATA_CONFLICT — same participant has conflicting values between registration and FCM.
    """
    try:
        result = (
            supabase.table("participants")
            .select(
                "id, first_name, last_name, "
                "registration_source_id, fcm_source_id"
            )
            .eq("event_id", event_id)
            .not_.is_("registration_source_id", "null")
            .not_.is_("fcm_source_id", "null")
            .execute()
        )
    except Exception as exc:
        logger.error("DATA_CONFLICT query failed: %s", exc)
        return 0

    if not result.data:
        return 0

    # Load the source records in bulk
    reg_ids = [p["registration_source_id"] for p in result.data]
    fcm_ids = [p["fcm_source_id"] for p in result.data]
    all_ids = list(set(reg_ids + fcm_ids))

    try:
        sr_resp = (
            supabase.table("source_records")
            .select("id, normalized_data")
            .in_("id", all_ids)
            .execute()
        )
        sr_map = {r["id"]: r["normalized_data"] or {} for r in sr_resp.data}
    except Exception as exc:
        logger.error("Failed to load source_records for DATA_CONFLICT: %s", exc)
        return 0

    # `phone` is deliberately NOT a conflict field: a registration form and a
    # travel agency routinely hold two different (both valid) numbers for the same
    # person — mobile vs office, personal vs corporate. That is extra contact
    # info, not a data error, and flagging it produced hundreds of unactionable
    # cards. Both numbers stay visible in the participant's source data.
    # company/nationality are kept: a real divergence there can reveal a WRONG
    # merge, which is genuinely worth a look.
    conflict_fields = ["company", "nationality"]
    count = 0

    for p in result.data:
        reg_data = sr_map.get(p["registration_source_id"], {})
        fcm_data = sr_map.get(p["fcm_source_id"], {})
        conflicts: list[dict] = []

        for field in conflict_fields:
            reg_val = reg_data.get(field)
            fcm_val = fcm_data.get(field)
            if reg_val and fcm_val and _values_conflict(field, reg_val, fcm_val):
                conflicts.append({
                    "field": field,
                    "registration_value": reg_val,
                    "fcm_value": fcm_val,
                })

        if conflicts:
            name = f"{p.get('first_name', '')} {p.get('last_name', '')}".strip()
            _insert_exception(
                supabase=supabase,
                run_id=run_id,
                event_id=event_id,
                exception_type="DATA_CONFLICT",
                severity="warning",
                message=(
                    f"Valeurs différentes pour « {name} » entre l'inscription et le fichier vols. "
                    + ", ".join(
                        f"{_FIELD_FR.get(c['field'], c['field']).capitalize() if i == 0 else _FIELD_FR.get(c['field'], c['field'])} : "
                        f"« {c['registration_value']} » vs « {c['fcm_value']} »"
                        for i, c in enumerate(conflicts)
                    )
                ),
                participant_id=p["id"],
                context_data={"conflicts": conflicts},
                exceptions_list=exceptions_list,
            )
            count += 1

    logger.debug("DATA_CONFLICT: %d exceptions", count)
    return count


def _detect_possible_duplicates(event_id: str, run_id: str, supabase: Client, exceptions_list: list[dict]) -> int:
    """
    POSSIBLE_DUPLICATE — participants with very similar names but different email addresses.
    """
    from rapidfuzz import fuzz

    try:
        result = (
            supabase.table("participants")
            .select("id, first_name, last_name, email, company")
            .eq("event_id", event_id)
            .execute()
        )
    except Exception as exc:
        logger.error("POSSIBLE_DUPLICATE query failed: %s", exc)
        return 0

    participants = result.data or []
    if len(participants) < 2:
        return 0

    count = 0
    for i in range(len(participants)):
        for j in range(i + 1, len(participants)):
            p1 = participants[i]
            p2 = participants[j]

            email1 = (p1.get("email") or "").strip().lower()
            email2 = (p2.get("email") or "").strip().lower()

            if email1 == email2 or not email1 or not email2:
                continue

            name1 = f"{p1.get('first_name') or ''} {p1.get('last_name') or ''}".strip().lower()
            name2 = f"{p2.get('first_name') or ''} {p2.get('last_name') or ''}".strip().lower()

            if not name1 or not name2:
                continue

            score = fuzz.token_sort_ratio(name1, name2)
            if score >= 80:
                name_display1 = f"{p1.get('first_name') or ''} {p1.get('last_name') or ''}".strip()
                name_display2 = f"{p2.get('first_name') or ''} {p2.get('last_name') or ''}".strip()
                
                _insert_exception(
                    supabase=supabase,
                    run_id=run_id,
                    event_id=event_id,
                    exception_type="POSSIBLE_DUPLICATE",
                    severity="warning",
                    message=(
                        f"Potential duplicate participant detected: '{name_display1}' ({email1}) "
                        f"and '{name_display2}' ({email2}) share very similar names (similarity={score:.1f}%)."
                    ),
                    participant_id=p1["id"],
                    context_data={
                        "participant_a_id": p1["id"],
                        "participant_b_id": p2["id"],
                        "name_a": name_display1,
                        "name_b": name_display2,
                        "email_a": email1,
                        "email_b": email2,
                        "score": float(score),
                    },
                    exceptions_list=exceptions_list,
                )
                count += 1

    return count


def _detect_name_mismatches_between_sources(event_id: str, run_id: str, supabase: Client, exceptions_list: list[dict]) -> int:
    """
    NAME_MISMATCH_BETWEEN_SOURCES — same participant has name mismatch between registration and flight source files.
    """
    try:
        result = (
            supabase.table("participants")
            .select("id, first_name, last_name, registration_source_id, fcm_source_id")
            .eq("event_id", event_id)
            .not_.is_("registration_source_id", "null")
            .not_.is_("fcm_source_id", "null")
            .execute()
        )
    except Exception as exc:
        logger.error("NAME_MISMATCH_BETWEEN_SOURCES query failed: %s", exc)
        return 0

    participants = result.data or []
    if not participants:
        return 0

    reg_ids = [p["registration_source_id"] for p in participants]
    fcm_ids = [p["fcm_source_id"] for p in participants]
    all_ids = list(set(reg_ids + fcm_ids))

    try:
        sr_resp = (
            supabase.table("source_records")
            .select("id, normalized_data")
            .in_("id", all_ids)
            .execute()
        )
        sr_map = {r["id"]: r["normalized_data"] or {} for r in sr_resp.data or []}
    except Exception as exc:
        logger.error("Failed to load source_records for NAME_MISMATCH_BETWEEN_SOURCES: %s", exc)
        return 0

    count = 0
    for p in participants:
        reg_data = sr_map.get(p["registration_source_id"], {})
        fcm_data = sr_map.get(p["fcm_source_id"], {})

        reg_first = (reg_data.get("first_name") or "").strip().lower()
        reg_last = (reg_data.get("last_name") or "").strip().lower()
        fcm_first = (fcm_data.get("first_name") or "").strip().lower()
        fcm_last = (fcm_data.get("last_name") or "").strip().lower()

        if (reg_first or reg_last) and (fcm_first or fcm_last):
            if reg_first != fcm_first or reg_last != fcm_last:
                reg_name = f"{reg_data.get('first_name') or ''} {reg_data.get('last_name') or ''}".strip()
                fcm_name = f"{fcm_data.get('first_name') or ''} {fcm_data.get('last_name') or ''}".strip()
                
                _insert_exception(
                    supabase=supabase,
                    run_id=run_id,
                    event_id=event_id,
                    # ENUM-valid name for a registration-vs-FCM name mismatch.
                    exception_type="NAME_DIVERGENCE",
                    severity="warning",
                    message=(
                        f"Name mismatch: registration name is '{reg_name}' "
                        f"but FCM flight record name is '{fcm_name}'."
                    ),
                    participant_id=p["id"],
                    context_data={
                        "registration_name": reg_name,
                        "fcm_name": fcm_name,
                    },
                    exceptions_list=exceptions_list,
                )
                count += 1

    return count


def _detect_missing_service(
    event_id: str,
    run_id: str,
    supabase: Client,
    exceptions_list: list[dict],
    *,
    flag: str,
    exception_type: str,
    label: str,
    severity: str = "warning",
) -> int:
    """
    Generic per-participant "missing info" detector for a boolean service flag
    (``has_hotel``, ``has_transfer`` …). Flags every participant where the flag
    is False — i.e. that master-list line is missing this information.
    """
    try:
        result = (
            supabase.table("participants")
            .select("id, first_name, last_name, email")
            .eq("event_id", event_id)
            .eq(flag, False)
            .execute()
        )
    except Exception as exc:
        logger.error("%s query failed: %s", exception_type, exc)
        return 0

    count = 0
    for p in result.data or []:
        name = f"{p.get('first_name', '')} {p.get('last_name', '')}".strip()
        _insert_exception(
            supabase=supabase,
            run_id=run_id,
            event_id=event_id,
            exception_type=exception_type,
            severity=severity,
            message=f"Participant '{name}' has no {label} information.",
            participant_id=p["id"],
            context_data={"participant_name": name, "email": p.get("email"), "missing": label},
            exceptions_list=exceptions_list,
        )
        count += 1

    logger.debug("%s: %d exceptions", exception_type, count)
    return count


def _detect_missing_contact(event_id: str, run_id: str, supabase: Client, exceptions_list: list[dict]) -> int:
    """
    MISSING_CONTACT — participant has neither an email nor a phone number, so
    they cannot be reached for confirmations.
    """
    try:
        result = (
            supabase.table("participants")
            .select("id, first_name, last_name, email, phone")
            .eq("event_id", event_id)
            .execute()
        )
    except Exception as exc:
        logger.error("MISSING_CONTACT query failed: %s", exc)
        return 0

    count = 0
    for p in result.data or []:
        if not p.get("email") and not p.get("phone"):
            name = f"{p.get('first_name', '')} {p.get('last_name', '')}".strip()
            _insert_exception(
                supabase=supabase,
                run_id=run_id,
                event_id=event_id,
                # The exception_type ENUM has no MISSING_CONTACT value.
                exception_type="MISSING_REQUIRED_FIELD",
                severity="warning",
                message=f"« {name} » n'a ni email ni téléphone.",
                participant_id=p["id"],
                context_data={"participant_name": name},
                exceptions_list=exceptions_list,
            )
            count += 1

    logger.debug("MISSING_CONTACT: %d exceptions", count)
    return count



# ---------------------------------------------------------------------------
# What is still an exception, as the policy reads TODAY
# ---------------------------------------------------------------------------
#
# Exceptions are WRITTEN by a consolidation run, so the table holds whatever
# rules were in force when that run happened. Applying the policy again on the
# way out is what makes a rule change take effect when it is made rather than
# at the next consolidation — the live event was still showing 69 "Régime
# alimentaire" cards four days after a blank diet stopped being a gap.
#
# Every counter goes through here. A badge that disagrees with the page it
# links to is worse than a wrong number, because the reader cannot tell which
# one to believe.


# The four booleans the aggregate cards count on. Named here rather than in
# the caller so the column list and the check cannot drift apart.
COVERAGE_FLAGS = ("has_flight", "has_hotel", "has_transfer", "has_activities")


def answered_fields(participants: Iterable[dict[str, Any]]) -> dict[str, set[str]]:
    """Per participant, everything they now HAVE.

    Both kinds in one map, because both answer the same question — is this
    still missing? A text field counts when it is non-blank, a coverage flag
    when it is true. Built from the current fiches, so it says what is true
    when the page is read rather than what was true when the run wrote its
    cards.
    """
    out: dict[str, set[str]] = {}
    for person in participants:
        pid = person.get("id")
        if not pid:
            continue
        have = {
            field for field in _MISSING_PROFILE_FIELDS
            if str(person.get(field) or "").strip()
        }
        have |= {flag for flag in COVERAGE_FLAGS if person.get(flag)}
        out[str(pid)] = have
    return out


def apply_policy(
    row: dict[str, Any],
    policy: dict[str, str],
    answered: Optional[dict[str, set[str]]] = None,
) -> Optional[dict[str, Any]]:
    """The card as this event's policy leaves it, or None if it says nothing.

    Two shapes, because a "missing fields" card names several fields at once:

      * every field it names is one the event no longer requires -> nothing is
        left to report and the card is dropped;
      * some are and some are not -> the card stays, listing only the fields
        that are still gaps, so "champs manquants : nationalité, régime
        alimentaire" becomes "champs manquants : nationalité" rather than
        vanishing along with the real gap it also carried.

    ``answered`` adds the second reason a named field drops out: somebody has
    since filled it in. The card was written by a run and the fiche has moved
    on, so re-checking here is what stops the page contradicting the counters
    printed beside it.

    Only ever narrows, and never deletes: turning a field back on — or emptying
    it again — brings its cards straight back, with no consolidation and no
    history lost.

    Anything that is not a missing-field card passes through untouched. A
    conflict between two files is not a question we chose to ask; it is our own
    records disagreeing, and no policy makes that uninteresting.
    """
    context = row.get("context_data") or {}
    if not isinstance(context, dict):
        return row

    if _is_only_out_of_window(row, context):
        return None

    key = _CATEGORY_POLICY_KEY.get(str(context.get("category") or ""))
    if key is not None and not field_policy.is_required(policy, key):
        return None

    if context.get("aggregate") and context.get("coverage_flag"):
        return _recount_aggregate(row, context, answered or {})

    if context.get("category") != "missing_field":
        return row

    named = context.get("missing_fields")
    if not isinstance(named, list) or not named:
        return row

    filled = (answered or {}).get(str(row.get("participant_id") or ""), frozenset())
    kept = [
        f for f in named
        if field_policy.is_required(policy, str(f)) and str(f) not in filled
    ]
    if not kept:
        return None
    if len(kept) == len(named):
        return row

    # Rewritten rather than left contradicting itself: the message lists the
    # fields, and a card reading "régime alimentaire" while its data says
    # otherwise is worse than either version alone.
    name = context.get("participant_name") or ""
    labels = ", ".join(field_policy.label(str(f)).lower() for f in kept)
    trimmed = dict(row)
    trimmed["context_data"] = {**context, "missing_fields": kept}
    if name:
        trimmed["message"] = (
            f"Fiche de \u00ab {name} \u00bb incompl\u00e8te "
            f"\u2014 champ(s) manquant(s) : {labels}."
        )
    return trimmed


# Every column the read-time filter needs to make its decisions. Written once,
# because it has now been got wrong twice by three readers keeping their own
# hand-typed lists: first `participant_id` was missing from the count and no
# answered field ever cleared a card, then `exception_type` was missing and the
# badge counted forty date cards the page had already dropped. A filter that
# silently sees less than the page it is counting cannot agree with it.
READ_COLUMNS = "id, exception_type, severity, created_at, participant_id, context_data, resolved"


def fetch_answered(supabase: Any, event_id: str) -> dict[str, set[str]]:
    """Which tracked fields each participant has a value for, right now.

    Lives here, next to ``_MISSING_PROFILE_FIELDS``, because the column list
    and the field list have to be the same list. They were not: the badge
    counted with a select that omitted ``participant_id``, so every card read
    as belonging to nobody and no answered field ever cleared one — 13 in the
    navigation beside a page listing 12.

    Degrades to an empty map. Without it every card simply stands as written,
    which is the behaviour that existed before this check.
    """
    columns = "id, " + ", ".join(_MISSING_PROFILE_FIELDS + COVERAGE_FLAGS)
    rows: list[dict[str, Any]] = []
    try:
        limit, offset = 1000, 0
        while True:
            page = (
                supabase.table("participants")
                .select(columns)
                .eq("event_id", event_id)
                .range(offset, offset + limit - 1)
                .execute()
            ).data or []
            rows.extend(page)
            if len(page) < limit:
                break
            offset += limit
    except Exception as exc:
        logger.warning("Could not re-check fiches for %s: %s", event_id, exc)
        return {}
    return answered_fields(rows)


def _is_only_out_of_window(row: dict[str, Any], context: dict[str, Any]) -> bool:
    """A DATE_INCOHERENCE card whose whole complaint is "outside the event".

    The detector stopped writing these, but a run that already happened wrote
    plenty, and they are the noisiest kind: one per source row, in English,
    against a UUID, saying a departure after the event is a date problem. It is
    not — it is somebody on their own nights, and `staying_at_own_expense`
    reports that by name with the count of nights.

    A card that ALSO carries a real contradiction (leaves before it arrives)
    survives: only the ones with nothing else in them go.
    """
    if str(row.get("exception_type") or "") != "DATE_INCOHERENCE":
        return False
    issues = context.get("issues")
    if not isinstance(issues, list) or not issues:
        return False
    return all("falls outside event window" in str(i) for i in issues)


def _recount_aggregate(
    row: dict[str, Any],
    context: dict[str, Any],
    answered: dict[str, set[str]],
) -> Optional[dict[str, Any]]:
    """An aggregate card, re-counted against the fiches as they read today.

    Dropped when nobody it names is still missing the thing — the card was a
    claim about a moment, and that moment has passed. Otherwise the count is
    corrected in both the data and the sentence, because a card whose number
    contradicts the KPI printed beside it teaches the reader to trust neither.

    Left exactly as written when there are no fiches to check against: the read
    that builds ``answered`` can fail, and a card standing unchanged is the
    behaviour that existed before this check.
    """
    ids = context.get("participant_ids")
    flag = str(context.get("coverage_flag") or "")
    if not answered or not isinstance(ids, list) or not ids:
        return row

    # Only people who are still on the event. An id the map has never heard of
    # belongs to a fiche that has since been merged away or deleted, and
    # counting it as "still missing a transfer" kept the live card reading
    # "1 participants sur 65" when the true answer was none.
    still = [
        pid for pid in ids
        if str(pid) in answered and flag not in answered[str(pid)]
    ]
    if not still:
        return None
    if len(still) == len(ids):
        return row

    trimmed = dict(row)
    trimmed["context_data"] = {**context, "count": len(still), "participant_ids": still}
    old = str(context.get("count") or len(ids))
    message = str(row.get("message") or "")
    # Only the count it opens with. Any other number in the sentence — "sur
    # 65", a date, a threshold — means something else and is not ours to move.
    if message.startswith(old):
        trimmed["message"] = _reagree(str(len(still)) + message[len(old):], len(still))
    return trimmed


def _reagree(message: str, count: int) -> str:
    """Make the opening phrase agree with the number now in front of it.

    The sentence was written by a run for thirty-six people and this function
    has just changed the number to one, leaving "1 participants sur 65 ont un
    vol sans aucun transfert" on screen. Only the opening subject and its verb
    are touched — everything after them belongs to whoever wrote the message.
    """
    if count != 1:
        return message
    head = f"{count} participants sur "
    if not message.startswith(head):
        return message
    rest = message[len(head):]
    # "<total> ont …" / "<total> n'ont pas …"
    for plural, singular in ((" n'ont ", " n'a "), (" ont ", " a ")):
        cut = rest.find(plural)
        # Only if it follows the total immediately, i.e. within the first word.
        if 0 < cut <= len(rest.split(" ")[0]):
            rest = rest[:cut] + singular + rest[cut + len(plural):]
            break
    return f"{count} participant sur " + rest


def visible(
    rows: Iterable[dict[str, Any]],
    policy: dict[str, str],
    answered: Optional[dict[str, set[str]]] = None,
) -> list[dict[str, Any]]:
    """The rows an organizer should see, in order."""
    out = [apply_policy(row, policy, answered) for row in rows]
    return [row for row in out if row is not None]
