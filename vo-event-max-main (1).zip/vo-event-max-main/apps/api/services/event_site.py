"""
services/event_site.py — The registration link becomes a small event site (§11).

The question asked during the presentation was whether the link sent to a
participant could carry more than a form, and the feedback answers: yes, and
without building a CMS. A title, a text, an image, a few sections.

So that is exactly what this is. Seven sections the feedback names — Welcome,
Event information, Programme, Practical information, Accommodation,
Destination, Conditions — plus the form itself, which is always last because it
is what the visitor came to do.

Three decisions worth knowing about:

  * **Text, never markup.** The body is written by an organizer and rendered on
    a page open to the world with no login. Accepting HTML would make every
    organizer account a stored-XSS vector against every participant. Paragraphs
    are the one structure the text keeps, and they come from blank lines.
  * **Three languages, like the form.** §12 already established that a Dutch
    participant gets a Dutch form; a French welcome page above a Dutch form
    would undo that. Untranslated sections fall back rather than disappear —
    a participant reading the wrong language still reads something.
  * **An empty site is not a broken site.** An event that configures nothing
    gets the form alone, exactly as today. The sections are additive.

Pure module: dicts in, dicts out.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Iterable, Optional

from services import registration_i18n

logger = logging.getLogger(__name__)

# The sections §11 lists, in the order it lists them. `registration` is not here
# because the form is not a section an organizer can reorder or hide — a site
# with no way to register is not what anybody is trying to build.
SECTIONS: tuple[tuple[str, str], ...] = (
    ("welcome",       "Bienvenue"),
    ("information",   "Informations sur l'événement"),
    ("programme",     "Programme"),
    ("practical",     "Informations pratiques"),
    ("accommodation", "Hébergement"),
    ("destination",   "Destination"),
    ("conditions",    "Conditions"),
)

_ORDER = {slug: i for i, (slug, _) in enumerate(SECTIONS)}
_DEFAULT_TITLES = dict(SECTIONS)

_TITLES_I18N: dict[str, dict[str, str]] = {
    "welcome":       {"nl": "Welkom", "en": "Welcome"},
    "information":   {"nl": "Info over het evenement", "en": "Event information"},
    "programme":     {"nl": "Programma", "en": "Programme"},
    "practical":     {"nl": "Praktische informatie", "en": "Practical information"},
    "accommodation": {"nl": "Accommodatie", "en": "Accommodation"},
    "destination":   {"nl": "Bestemming", "en": "Destination"},
    "conditions":    {"nl": "Voorwaarden", "en": "Terms"},
}

# A body long enough to be a novel is a paste accident, not a programme.
MAX_BODY = 8000
MAX_TITLE = 120


class EventSiteError(ValueError):
    """The section cannot be stored as given."""


def known(slug: Any) -> bool:
    return str(slug or "").strip().lower() in _ORDER


def default_title(slug: str, locale: str = "fr") -> str:
    french = _DEFAULT_TITLES.get(slug, slug)
    locale = registration_i18n.normalise(locale)
    if locale == registration_i18n.DEFAULT:
        return french
    return _TITLES_I18N.get(slug, {}).get(locale) or french


def clean_text(value: Any, limit: int = MAX_BODY) -> str:
    """Strip everything that could execute, and normalise the whitespace.

    Tags are removed rather than escaped. Escaping preserves the author's
    intent for a feature they do not have — an organizer who pastes a ``<b>``
    and sees it printed verbatim learns the rule immediately, which is a better
    outcome than markup that half-works.
    """
    text = str(value or "")
    text = re.sub(r"<[^>]*>", " ", text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # Collapse runs of blank lines to a single paragraph break, and runs of
    # spaces to one. Pasted text from a Word document is full of both.
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()[:limit]


def paragraphs(body: str) -> list[str]:
    """The one structure the text keeps."""
    return [p.strip() for p in str(body or "").split("\n\n") if p.strip()]


def clean_image(url: Any) -> str:
    """An image URL fit to appear in a public page's ``src``.

    Only ``https``. Not ``data:`` (a whole payload smuggled into an attribute),
    not ``javascript:``, and not plain ``http`` — a page served over TLS that
    pulls an image over plaintext gets a mixed-content warning at best and is
    blocked at worst, which looks like a broken site to the participant.
    """
    text = str(url or "").strip()
    if not text:
        return ""
    if not text.lower().startswith("https://"):
        raise EventSiteError("L'image doit être une URL https.")
    if any(ch in text for ch in ('"', "'", "<", ">", "\n")):
        raise EventSiteError("URL d'image invalide.")
    return text[:500]


def _localised(field: Any, locale: str, fallback: str = "") -> str:
    """One language out of a {fr, nl, en} map, falling back rather than blanking.

    A participant reading a French paragraph on a Dutch page still reads
    something; one reading an empty section learns nothing and assumes the site
    is broken.
    """
    if isinstance(field, str):
        return field
    if not isinstance(field, dict):
        return fallback
    for code in (locale, registration_i18n.DEFAULT, *registration_i18n.SUPPORTED):
        value = str(field.get(code) or "").strip()
        if value:
            return value
    return fallback


# Where the photo sits relative to the text inside a section (point 13). Two
# options rather than a free canvas: on a page read mostly on a phone, a
# photo is either the thing you see first or the thing that closes the
# section, and every other arrangement is the same one of those on a
# narrow screen.
IMAGE_POSITIONS = ("above", "below")
DEFAULT_IMAGE_POSITION = "above"


def clean_image_position(value: Any) -> str:
    candidate = str(value or "").strip().lower()
    return candidate if candidate in IMAGE_POSITIONS else DEFAULT_IMAGE_POSITION


def clean_position(value: Any, slug: str) -> int:
    """Where this section sits on the page.

    The catalogue's own order is only the DEFAULT now (point 13): an organizer
    who moved Programme above Bienvenue gets to keep it that way. An
    unusable value falls back to the catalogue rather than to 0, which would
    silently pile every broken section at the top.
    """
    try:
        position = int(value)
    except (TypeError, ValueError):
        return _ORDER[slug]
    return position if 0 <= position <= 999 else _ORDER[slug]


def sanitise_section(payload: dict[str, Any]) -> dict[str, Any]:
    """One section, ready to store. Raises rather than storing something odd."""
    slug = str(payload.get("slug") or "").strip().lower()
    if not known(slug):
        raise EventSiteError(f"Section inconnue : {slug or '(vide)'}.")

    title: dict[str, str] = {}
    body: dict[str, str] = {}
    for code in registration_i18n.SUPPORTED:
        raw_title = (payload.get("title") or {}).get(code) if isinstance(payload.get("title"), dict) else None
        raw_body = (payload.get("body") or {}).get(code) if isinstance(payload.get("body"), dict) else None
        cleaned_title = clean_text(raw_title, MAX_TITLE)
        cleaned_body = clean_text(raw_body, MAX_BODY)
        if cleaned_title:
            title[code] = cleaned_title
        if cleaned_body:
            body[code] = cleaned_body

    return {
        "slug": slug,
        "position": clean_position(payload.get("position"), slug),
        "title": title,
        "body": body,
        "image_url": clean_image(payload.get("image_url")),
        "image_position": clean_image_position(payload.get("image_position")),
        "visible": bool(payload.get("visible", True)),
    }


def sanitise_all(payload: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    """Every section, deduplicated by slug — the last one wins.

    A client that sends "programme" twice has a bug; storing both would give a
    page with two Programme headings and no way to tell which is live.
    """
    by_slug: dict[str, dict[str, Any]] = {}
    for section in payload or []:
        cleaned = sanitise_section(section)
        by_slug[cleaned["slug"]] = cleaned
    # Ties broken by the catalogue: two sections claiming position 3 must
    # still come back in a stable order, or the page reshuffles on every save.
    return sorted(by_slug.values(), key=lambda s: (s["position"], _ORDER[s["slug"]]))


def render(
    rows: Iterable[dict[str, Any]],
    locale: str = "fr",
) -> list[dict[str, Any]]:
    """What the public page shows: visible sections, one language, in order.

    A section with neither text nor image is dropped even when marked visible —
    a heading over nothing reads as a page that failed to load.
    """
    locale = registration_i18n.normalise(locale)
    out: list[dict[str, Any]] = []

    for row in rows or []:
        slug = str(row.get("slug") or "").strip().lower()
        if not known(slug) or not row.get("visible", True):
            continue
        body = _localised(row.get("body"), locale)
        image = str(row.get("image_url") or "").strip()
        if not body and not image:
            continue
        out.append({
            "slug": slug,
            "title": _localised(row.get("title"), locale, default_title(slug, locale)),
            "paragraphs": paragraphs(body),
            "image_url": image,
            "image_position": clean_image_position(row.get("image_position")),
            "position": clean_position(row.get("position"), slug),
        })

    # The organizer's own order, with the catalogue only as the tie-breaker.
    return sorted(out, key=lambda s: (s["position"], _ORDER.get(s["slug"], 99)))


def describe(locale: str = "fr") -> list[dict[str, str]]:
    """The section catalogue, for the editor."""
    locale = registration_i18n.normalise(locale)
    return [
        {"slug": slug, "label": default_title(slug, locale)}
        for slug, _ in SECTIONS
    ]


def summarise(rows: Iterable[dict[str, Any]]) -> dict[str, Any]:
    """What an organizer sees before sending the link."""
    rendered_fr = render(rows, "fr")
    translated = {
        code: len(render(rows, code)) for code in registration_i18n.SUPPORTED
    }
    return {
        "sections": len(rendered_fr),
        "with_image": sum(1 for s in rendered_fr if s["image_url"]),
        # Equal numbers across languages do NOT mean everything is translated —
        # untranslated sections fall back — so this counts what is genuinely
        # written per language instead.
        "written": {
            code: sum(
                1 for row in rows or []
                if isinstance(row.get("body"), dict) and str(row["body"].get(code) or "").strip()
            )
            for code in registration_i18n.SUPPORTED
        },
        "rendered": translated,
    }
