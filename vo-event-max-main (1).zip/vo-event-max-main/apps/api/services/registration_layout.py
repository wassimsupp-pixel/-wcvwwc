"""
services/registration_layout.py — WHERE things sit on the public form.

The three legs already here each answer one question about the registration
page: `registration_form` decides which questions it asks, `event_site` what is
written above it, `registration_theme` what colour and typeface it wears. All
three assume the same skeleton — a header, then a single column of fields — and
only redress it. An organizer who wanted the photo beside the intro rather than
above it, or two blocks of text before the form, had no way to say so.

This is the fourth leg: an ordered list of BLOCKS the organizer arranges freely
— a photo (inline or full-bleed with text laid over it), a heading, a
paragraph, a button, a divider, and the form itself — each with its own
placement, alignment, colour and typeface.

It obeys the same three rules as the modules next door, and one more that is
its own:

  * **A closed set, never a stylesheet.** A block's type is one of a fixed
    list; every value inside it is an enum key, a validated hex, a bounded line
    of text, or an https image URL from our own bucket. Nothing an organizer
    types becomes CSS or markup. This page has no login and a crowd loads it,
    so "let them arrange blocks" must not become "let them inject one".
  * **A bad value is dropped, not raised.** An unknown block type or a
    malformed field is discarded; the save still succeeds with what remained.
    A single bad block must not be able to fail a form a participant is about
    to open, nor a hand-crafted payload to reach the page.
  * **The form can never be arranged away.** Whatever the organizer sends,
    `sanitize` guarantees exactly one `form` block survives — the page's whole
    reason to exist. A layout with none gets one appended; a layout with
    several keeps the first.

And the rule that separates this leg from the others:

  * **Layout is opt-in and backward-compatible.** An event that never touched
    it stores nothing, and `resolve` returns an empty list, which the page
    reads as "render the classic header-then-fields layout you always did".
    Only a stored, non-empty layout switches the page into block mode. No
    existing form changes appearance until someone opens this editor and saves.

The `form` block styles and places the form; it does not decide its questions —
those stay in `registration_form`, so badges and field policy keep working
untouched. Pure module: lists in, lists out. `fetch` is the only function that
touches the database, and it treats a missing column as "never configured" so a
deployment without migration 032 keeps serving the form it serves today.
"""

from __future__ import annotations

import re
import uuid
from typing import Any, Optional

# One source of truth for the things a block shares with the theme: the same
# five self-hosted typefaces, the same corner vocabulary, and the same colour,
# line and image validators. Importing them rather than re-declaring means a
# font added to the theme is a font available to a block, and a hardening of
# the colour rule hardens both.
from services.registration_theme import (
    CORNERS,
    DEFAULT_ACCENT,
    FONTS,
    clean_colour,
    clean_image,
    clean_line,
)

# ---------------------------------------------------------------------------
# The closed sets
# ---------------------------------------------------------------------------

BLOCK_TYPES: tuple[str, ...] = ("image", "title", "text", "form", "button", "divider")

# Where a block sits across the page. "left"/"right" pair up: a left block
# immediately followed by a right block share a row; alone, each falls back to
# full width. On a phone the row stacks — which is the whole reason placement is
# a column key and not an x/y coordinate.
COLUMNS: tuple[str, ...] = ("full", "left", "right")

ALIGNMENTS: tuple[str, ...] = ("left", "center", "right")
DEFAULT_ALIGN = "left"

# A photo is either a contained band or a full-bleed panel with room for text
# laid over it.
IMAGE_VARIANTS: tuple[str, ...] = ("banner", "background")
DEFAULT_VARIANT = "banner"

# Where overlaid text sits within a background photo, top to bottom.
OVERLAY_POS: tuple[str, ...] = ("start", "center", "end")
DEFAULT_OVERLAY_POS = "end"

# Named background gradients, offered when no photo has been uploaded yet so a
# block is never a blank grey box in the editor. "" means "no preset" — a real
# uploaded image, or nothing.
PRESETS: tuple[str, ...] = ("dusk", "sunrise", "rose", "violet", "forest", "")
DEFAULT_PRESET = "dusk"

TITLE_SIZES: tuple[str, ...] = ("s", "m", "l", "xl")
TEXT_SIZES: tuple[str, ...] = ("s", "m", "l")
HEAD_SIZES: tuple[str, ...] = ("m", "l", "xl")
FORM_STYLES: tuple[str, ...] = ("outline", "fill")
DIVIDER_THICKNESS: tuple[int, ...] = (1, 2, 4)

DEFAULT_FONT = "sans"
DEFAULT_OVERLAY_COLOUR = "#ffffff"
DEFAULT_BUTTON_BG = DEFAULT_ACCENT
DEFAULT_BUTTON_FG = "#ffffff"
DEFAULT_FORM_ACCENT = DEFAULT_ACCENT

# Bounds. A layout is small by nature — a form is not a website — so a payload
# larger than this is either a mistake or an attempt to make the column grow
# without limit, and either way the tail is dropped.
MAX_BLOCKS = 40
MAX_HEADING = 120
MAX_SUBHEADING = 240
MAX_TITLE = 120
MAX_PARAGRAPH = 2000
MAX_LABEL = 60

# A layout is no longer one page but a MAP of pages: the registration page plus
# each mini-site section, every one arranged in its own blocks. "home" is the
# registration page and is the only one that carries the form block; the others
# are content pages keyed by their mini-site section slug.
HOME = "home"
MAX_PAGES = 30
_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,24}$")
# A page key is "home" or a section slug — the same shape event_site slugs take.
_PAGE_KEY_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,39}$")


def _one_of(value: Any, allowed: tuple[str, ...], default: str) -> str:
    candidate = str(value or "").strip().lower()
    return candidate if candidate in allowed else default


def _clean_colour_opt(value: Any) -> str:
    """A hex colour, or "" meaning "inherit the surface's ink".

    Title, text and divider colours are optional: left blank they take the
    readable default the page's surface already defines, so an organizer who
    only wants to move a block need not also pick a colour for it.
    """
    text = str(value or "").strip()
    if not text:
        return ""
    return clean_colour(text, default="")


def _clean_paragraph(value: Any, limit: int) -> str:
    """A block of organizer text, tags stripped, paragraph breaks kept.

    `clean_line` collapses newlines because a heading is one line; a paragraph
    is not, so this keeps single breaks and caps runs of blank lines rather
    than flattening them. Tags are still removed — the web side renders this as
    text content with `white-space: pre-wrap`, so a surviving newline is a line
    break and a surviving `<` is the character, never an element.
    """
    text = str(value or "")
    text = re.sub(r"<[^>]*>", " ", text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()[:limit]


# The languages a block's text can carry, and the one a bare string is read as.
# Same three the rest of the public form speaks (registration_i18n.SUPPORTED).
LANGS: tuple[str, ...] = ("fr", "nl", "en")
DEFAULT_LANG = "fr"


def _clean_i18n(value: Any, limit: int, *, multiline: bool = False) -> dict[str, str]:
    """A text field in every language it was given, cleaned per language.

    A dict is cleaned language by language, keeping only the ones actually
    written. A bare string — an older block, or an editor sending a single
    language — is read as the default language, so nothing written before the
    block became multilingual is lost. The renderer falls back across languages,
    so a block translated in only one still shows something to everyone.
    """
    cleaner = _clean_paragraph if multiline else clean_line
    if isinstance(value, dict):
        out: dict[str, str] = {}
        for lang in LANGS:
            cleaned = cleaner(value.get(lang), limit)
            if cleaned:
                out[lang] = cleaned
        return out
    cleaned = cleaner(value, limit)
    return {DEFAULT_LANG: cleaned} if cleaned else {}


def _clean_id(value: Any, seen: set[str]) -> str:
    """Keep the editor's id when it is a safe slug and unused, else mint one.

    Ids are React keys and edit targets, not security-bearing, but two blocks
    sharing one make the editor address the wrong block — so a duplicate is
    regenerated even when it is well-formed.
    """
    text = str(value or "")
    if _ID_RE.match(text) and text not in seen:
        return text
    new = "b" + uuid.uuid4().hex[:8]
    while new in seen:
        new = "b" + uuid.uuid4().hex[:8]
    return new


def _clean_common(raw: dict[str, Any], seen: set[str]) -> dict[str, Any]:
    return {
        "id": _clean_id(raw.get("id"), seen),
        "col": _one_of(raw.get("col"), COLUMNS, "full"),
    }


def clean_block(raw: Any, seen: set[str]) -> Optional[dict[str, Any]]:
    """One block rebuilt from the closed sets, or None to drop it.

    None rather than an exception, and None rather than a placeholder: an
    unknown type is discarded so a payload written by a newer editor degrades
    to the blocks an older server understands instead of failing the save.
    """
    if not isinstance(raw, dict):
        return None
    btype = _one_of(raw.get("type"), BLOCK_TYPES, "")
    if not btype:
        return None

    block = _clean_common(raw, seen)
    block["type"] = btype

    if btype == "image":
        image_url = clean_image(raw.get("image_url"))
        preset = _one_of(raw.get("preset"), PRESETS, DEFAULT_PRESET)
        # A real photo wins over a preset; a photo present means the preset is
        # irrelevant and is cleared so the two can never disagree on the page.
        if image_url:
            preset = ""
        block.update(
            {
                "variant": _one_of(raw.get("variant"), IMAGE_VARIANTS, DEFAULT_VARIANT),
                "image_url": image_url,
                "preset": preset,
                "heading": _clean_i18n(raw.get("heading"), MAX_HEADING),
                "subheading": _clean_i18n(raw.get("subheading"), MAX_SUBHEADING),
                "overlay_color": clean_colour(raw.get("overlay_color"), DEFAULT_OVERLAY_COLOUR),
                "overlay_align": _one_of(raw.get("overlay_align"), ALIGNMENTS, DEFAULT_ALIGN),
                "overlay_pos": _one_of(raw.get("overlay_pos"), OVERLAY_POS, DEFAULT_OVERLAY_POS),
                "heading_font": _one_of(raw.get("heading_font"), FONTS, "serif"),
                "heading_size": _one_of(raw.get("heading_size"), HEAD_SIZES, "xl"),
            }
        )

    elif btype == "title":
        block.update(
            {
                "text": _clean_i18n(raw.get("text"), MAX_TITLE),
                "font": _one_of(raw.get("font"), FONTS, "grotesk"),
                "size": _one_of(raw.get("size"), TITLE_SIZES, "l"),
                "align": _one_of(raw.get("align"), ALIGNMENTS, DEFAULT_ALIGN),
                "color": _clean_colour_opt(raw.get("color")),
            }
        )

    elif btype == "text":
        block.update(
            {
                "text": _clean_i18n(raw.get("text"), MAX_PARAGRAPH, multiline=True),
                "font": _one_of(raw.get("font"), FONTS, DEFAULT_FONT),
                "size": _one_of(raw.get("size"), TEXT_SIZES, "m"),
                "align": _one_of(raw.get("align"), ALIGNMENTS, DEFAULT_ALIGN),
                "width": _one_of(raw.get("width"), ("narrow", "full"), "narrow"),
                "color": _clean_colour_opt(raw.get("color")),
            }
        )

    elif btype == "button":
        block.update(
            {
                "label": _clean_i18n(raw.get("label"), MAX_LABEL),
                "href": clean_image(raw.get("href")),  # https-only, our-bucket-shaped url rules fit a link too
                "bg": clean_colour(raw.get("bg"), DEFAULT_BUTTON_BG),
                "fg": clean_colour(raw.get("fg"), DEFAULT_BUTTON_FG),
                "corners": _one_of(raw.get("corners"), CORNERS, "soft"),
                "align": _one_of(raw.get("align"), ALIGNMENTS, "center"),
                "full": bool(raw.get("full")),
            }
        )

    elif btype == "divider":
        thick = raw.get("thickness")
        try:
            thick = int(thick)
        except (TypeError, ValueError):
            thick = 1
        block.update(
            {
                "color": _clean_colour_opt(raw.get("color")),
                "thickness": thick if thick in DIVIDER_THICKNESS else 1,
            }
        )

    elif btype == "form":
        button = _clean_i18n(raw.get("button"), MAX_LABEL)
        if not button:
            button = {DEFAULT_LANG: "Je m'inscris"}
        block.update(
            {
                "accent": clean_colour(raw.get("accent"), DEFAULT_FORM_ACCENT),
                "corners": _one_of(raw.get("corners"), CORNERS, "soft"),
                "style": _one_of(raw.get("style"), FORM_STYLES, "outline"),
                "button": button,
            }
        )

    return block


def default_form_block(seen: Optional[set[str]] = None) -> dict[str, Any]:
    """The form block appended when a layout arrives without one."""
    block = {"type": "form"}
    return clean_block(block, seen if seen is not None else set())  # type: ignore[return-value]


def sanitize_page(payload: Any, *, require_form: bool) -> list[dict[str, Any]]:
    """One page's blocks, cleaned and bounded.

    `require_form=True` — the registration page — guarantees exactly one form
    block survives: the first if several were sent, a fresh one if none, so a
    participant always has something to register through. `require_form=False`
    — a mini-site content page — drops every form block, because the form lives
    only on the registration page and one arranged onto a content page is an
    artefact, not an intent.
    """
    raw = payload if isinstance(payload, list) else []
    seen: set[str] = set()
    blocks: list[dict[str, Any]] = []
    form_seen = False

    for item in raw[: MAX_BLOCKS * 2]:  # read a little past the cap; drop below
        block = clean_block(item, seen)
        if block is None:
            continue
        if block["type"] == "form":
            if not require_form or form_seen:
                continue  # forms are registration-page-only, and only the first
            form_seen = True
        seen.add(block["id"])
        blocks.append(block)
        if len(blocks) >= MAX_BLOCKS:
            break

    if require_form and not form_seen:
        # The guaranteed form counts against the cap. If the organizer already
        # filled every slot with other blocks, the last one yields its place —
        # a form that renders beats a fortieth divider that does not.
        if len(blocks) >= MAX_BLOCKS:
            blocks = blocks[: MAX_BLOCKS - 1]
        blocks.append(default_form_block(seen))

    return blocks


def _clean_page_key(value: Any) -> Optional[str]:
    """A page key that is "home" or a section slug, else None."""
    key = str(value or "").strip().lower()
    if key == HOME:
        return HOME
    return key if _PAGE_KEY_RE.match(key) else None


def sanitize(payload: Any) -> dict[str, list[dict[str, Any]]]:
    """What may be STORED: a map of page -> blocks.

    A bare list is read as the registration page alone, so a row written before
    the layout became multi-page still means exactly what it meant. A dict is a
    page map: "home" always survives and always carries its form; every other
    key must be a slug, and keeps its blocks only if it has any — an empty
    content page is stored as nothing and falls back to the classic rendering.
    The page count is bounded like everything else here.
    """
    if isinstance(payload, list):
        payload = {HOME: payload}
    raw = payload if isinstance(payload, dict) else {}

    pages: dict[str, list[dict[str, Any]]] = {HOME: sanitize_page(raw.get(HOME), require_form=True)}

    for key, blocks in raw.items():
        clean_key = _clean_page_key(key)
        if clean_key is None or clean_key == HOME:
            continue
        if len(pages) >= MAX_PAGES:
            break
        page = sanitize_page(blocks, require_form=False)
        if page:  # an empty content page stays classic rather than stored empty
            pages[clean_key] = page

    return pages


def resolve(stored: Any) -> dict[str, list[dict[str, Any]]]:
    """What the PUBLIC page renders, per page — or {} for "classic everywhere".

    {} is the signal an event never opted in: every page renders the way it
    always did. Anything stored is sanitized again, because a row written by an
    older build is as untrustworthy as a fresh payload — and a bare list from
    before the multi-page change resolves to just the registration page.
    """
    if isinstance(stored, list):
        return sanitize(stored) if stored else {}
    if isinstance(stored, dict) and stored:
        return sanitize(stored)
    return {}


def default_page(event_name: str = "") -> list[dict[str, Any]]:
    """The registration page a first-time editor opens on — never blank."""
    hero = clean_block(
        {
            "type": "image", "col": "full", "variant": "background", "preset": "dusk",
            "heading": event_name or "Votre événement", "subheading": "",
            "overlay_color": "#ffffff", "overlay_align": "left", "overlay_pos": "end",
            "heading_font": "serif", "heading_size": "xl",
        },
        set(),
    )
    intro = clean_block(
        {
            "type": "text", "col": "full",
            "text": "Confirmez votre présence en quelques instants.",
            "font": "sans", "size": "l", "align": "center", "width": "narrow",
        },
        {hero["id"]},
    )
    form = clean_block(
        {"type": "form", "col": "full", "accent": DEFAULT_FORM_ACCENT, "corners": "soft",
         "style": "outline", "button": "Je confirme ma présence"},
        {hero["id"], intro["id"]},
    )
    return [hero, intro, form]


def default_layout(event_name: str = "") -> dict[str, list[dict[str, Any]]]:
    """A starting point for the editor: the registration page seeded, the
    content pages left for the organizer to fill (empty = classic)."""
    return {HOME: default_page(event_name)}


def fetch(supabase: Any, event_id: str) -> Optional[Any]:
    """This event's stored layout, or None.

    Returns whatever the column holds — a bare list (a row written before the
    multi-page change) or a page map (after it); `resolve` accepts both. None
    covers never configured, stored as null, and migration 032 not applied,
    three situations the caller renders identically, as the classic layout.
    Selected on its own, like the theme, so a missing column cannot take the
    form's field configuration down with it.
    """
    try:
        resp = (
            supabase.table("events")
            .select("registration_layout")
            .eq("id", event_id)
            .limit(1)
            .execute()
        )
    except Exception:
        return None
    rows = resp.data if isinstance(resp.data, list) else []
    if not rows or not isinstance(rows[0], dict):
        return None
    stored = rows[0].get("registration_layout")
    return stored if isinstance(stored, (list, dict)) else None
