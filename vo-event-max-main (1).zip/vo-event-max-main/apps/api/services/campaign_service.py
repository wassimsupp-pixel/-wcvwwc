# -*- coding: utf-8 -*-
"""
campaign_service.py
===================
Bulk personalized email to all participants of an event: either a written
template with {placeholders} substituted per participant, or an AI-generated
message adapted to each participant's data. Delivery goes through the connected
mailbox (mail_connection_service). Each message is tracked in `communications`.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from supabase import Client

from services import master_list_service, mail_connection_service

logger = logging.getLogger(__name__)

# (dead google-generativeai import block removed 2026-08-01: this module
# talks to AI only through services/ai_service.py's unified gateway.)
# Placeholders offered to the user for template mode
PLACEHOLDERS = [
    "first_name", "last_name", "full_name", "email", "company",
    "region", "country", "attendee_category", "job_title", "event_name",
]


def _event_name(supabase: Client, event_id: str) -> str:
    try:
        res = supabase.table("events").select("name").eq("id", event_id).maybe_single().execute()
        return (res.data or {}).get("name") or ""
    except Exception:
        return ""


def _placeholders(row: dict[str, Any], event_name: str) -> dict[str, str]:
    fn = (row.get("first_name") or "").strip()
    ln = (row.get("last_name") or "").strip()
    return {
        "first_name": fn,
        "last_name": ln,
        "full_name": f"{fn} {ln}".strip(),
        "email": row.get("email") or "",
        "company": row.get("company") or "",
        "region": row.get("region") or "",
        "country": row.get("country") or "",
        "attendee_category": row.get("attendee_category") or "",
        "job_title": row.get("job_title") or "",
        "event_name": event_name,
    }


def _apply_template(template: str, ph: dict[str, str]) -> str:
    out = template or ""
    for k, v in ph.items():
        out = out.replace("{" + k + "}", str(v))
    return out


def _ai_personalize(instructions: str, ph: dict[str, str]) -> tuple[str, str]:
    """AI-generate a personalized subject+body for one participant."""
    from services import ai_service
    if not ai_service.ai_available():
        # Fallback: a minimal templated message from the instructions
        subject = f"{ph.get('event_name') or 'Information'}"
        body = f"Bonjour {ph.get('first_name', '')},\n\n{instructions}\n\nCordialement,\nL'équipe organisation"
        return subject, body
    prompt = f"""
    Rédige un e-mail personnalisé et professionnel en français pour un participant à un événement.
    Consigne de l'organisateur : {instructions}

    Données du participant (utilise-les pour personnaliser, n'invente RIEN d'autre) :
    {json.dumps(ph, ensure_ascii=False)}

    Réponds STRICTEMENT en JSON : {{"subject": "...", "body": "..."}}
    """
    try:
        from services import ai_service
        text = (ai_service.ai_text(prompt) or "").strip()
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0].strip()
        elif "```" in text:
            text = text.split("```")[1].split("```")[0].strip()
        parsed = json.loads(text)
        return parsed.get("subject") or (ph.get("event_name") or "Information"), parsed.get("body") or ""
    except Exception as exc:
        logger.warning("AI personalize failed, using fallback: %s", exc)
        return f"{ph.get('event_name') or 'Information'}", f"Bonjour {ph.get('first_name', '')},\n\n{instructions}\n\nCordialement,"


def _render(mode: str, subject: str, body: str, instructions: str, ph: dict[str, str]) -> tuple[str, str]:
    if mode == "ai":
        return _ai_personalize(instructions, ph)
    return _apply_template(subject, ph), _apply_template(body, ph)


def _rows_for(
    supabase: Client, event_id: str, participant_ids: list[str] | None
) -> list[dict[str, Any]]:
    """The fiches a campaign addresses: everybody, or a named few.

    The individual letter and the campaign to all participants are the same
    operation with a different audience, so they share one code path — the
    personalisation, the tracking row and the throttle behave identically
    whether one person is written to or four hundred.
    """
    rows = master_list_service.build_master_rows(supabase, event_id)
    if not participant_ids:
        return rows
    wanted = {str(pid) for pid in participant_ids if pid}
    return [r for r in rows if str(r.get("id") or "") in wanted]


def preview(
    supabase: Client,
    event_id: str,
    mode: str,
    subject: str,
    body: str,
    instructions: str,
    sample: int = 3,
    participant_ids: list[str] | None = None,
) -> dict[str, Any]:
    """Return a few personalized examples + the recipient count."""
    rows = _rows_for(supabase, event_id, participant_ids)
    recipients = [r for r in rows if (r.get("email") or "").strip()]
    event_name = _event_name(supabase, event_id)
    samples = []
    for r in recipients[:sample]:
        ph = _placeholders(r, event_name)
        subj, bod = _render(mode, subject, body, instructions, ph)
        samples.append({"to": r["email"], "name": ph["full_name"], "subject": subj, "body": bod})
    return {"recipient_count": len(recipients), "without_email": len(rows) - len(recipients), "samples": samples}


async def run_campaign(
    supabase: Client,
    event_id: str,
    mode: str,
    subject: str,
    body: str,
    instructions: str,
    do_send: bool,
    user_id: str,
    participant_ids: list[str] | None = None,
) -> dict[str, Any]:
    """
    Generate a personalized message per participant, store it in `communications`,
    and (if do_send) send it via the connected mailbox.
    """
    from datetime import datetime, timezone
    from services import mail_throttle

    rows = _rows_for(supabase, event_id, participant_ids)
    event_name = _event_name(supabase, event_id)
    provider = mail_connection_service.connected_provider(event_id) if do_send else None

    recipients = [r for r in rows if (r.get("email") or "").strip()]
    skipped = len(rows) - len(recipients)

    # Decided before anything leaves (§15). Exchange Online throttles a mailbox
    # at around 30 messages a minute, and a burst that trips it does not fail
    # cleanly: the tenant's reputation drops and later mail lands in Junk, long
    # after the campaign that caused it.
    schedule = mail_throttle.plan(
        len(recipients), provider, _throttle_override(supabase, event_id)
    )
    if do_send and provider and schedule["deferred"]:
        logger.warning(
            "Campaign on %s exceeds the daily cap: %d of %d will not be attempted",
            event_id, schedule["deferred"], schedule["total"],
        )

    generated = sent = errors = 0
    payloads: list[dict[str, Any]] = []
    delivered_so_far = 0

    for batch in mail_throttle.batches(recipients, schedule["batch_size"]):
        for row in batch:
            to = (row.get("email") or "").strip()
            ph = _placeholders(row, event_name)
            subj, bod = _render(mode, subject, body, instructions, ph)

            status = "ready"
            sent_at = None
            # Past the daily cap the message is still generated and stored —
            # it is simply not attempted. A draft somebody can send tomorrow
            # beats a silently dropped recipient.
            within_cap = delivered_so_far < schedule["attempted"]
            if do_send and provider and within_cap:
                try:
                    await asyncio.to_thread(
                        mail_connection_service.send_email, provider, event_id, to, subj, bod
                    )
                    status = "sent"
                    # An ISO timestamp, not the string "now()": PostgREST posts
                    # the value verbatim and Postgres refuses "now()" as a
                    # timestamptz, taking the whole insert down with it.
                    sent_at = datetime.now(timezone.utc).isoformat()
                    sent += 1
                except Exception as exc:
                    logger.warning("Failed to send campaign email to %s: %s", to, exc)
                    errors += 1
                    status = "ready"
                delivered_so_far += 1

            payloads.append({
                "event_id": event_id,
                "participant_id": row["id"],
                # An individual letter and a mass campaign are tracked apart:
                # "was this person written to personally?" is a question the
                # history is asked, and a shared label cannot answer it.
                "type": "individual" if participant_ids else "campaign",
                "channel": "email",
                "subject": subj,
                "body": bod,
                "status": status,
                "sent_at": sent_at,
                "created_by": user_id,
            })
            generated += 1

        # Pause between batches rather than between messages: the same average
        # rate, a fraction of the sleeps, and a burst small enough to go
        # unnoticed. Skipped once nothing more will be sent.
        if do_send and provider and delivered_so_far < schedule["attempted"]:
            await asyncio.sleep(schedule["pause_seconds"])

    # Persist all messages (best-effort — table may not be migrated yet)
    try:
        for i in range(0, len(payloads), 100):
            supabase.table("communications").insert(payloads[i:i + 100]).execute()
    except Exception as exc:
        logger.warning("Could not persist campaign communications (run migration 002?): %s", exc)

    return {
        "generated": generated,
        "sent": sent,
        "skipped_no_email": skipped,
        "errors": errors,
        "provider": provider,
        "delivered": bool(do_send and provider),
        "schedule": schedule,
        "schedule_line": mail_throttle.describe(schedule),
    }


def _throttle_override(supabase: Client, event_id: str) -> Any:
    """An event's own pacing, when it has set one.

    Optional everywhere: a deployment without the column simply uses the
    provider defaults, which are already conservative.
    """
    try:
        res = (
            supabase.table("events")
            .select("mail_throttle")
            .eq("id", event_id)
            .single()
            .execute()
        )
        return (res.data or {}).get("mail_throttle")
    except Exception:
        return None
