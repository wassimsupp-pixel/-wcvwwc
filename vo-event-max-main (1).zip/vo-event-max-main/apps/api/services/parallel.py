"""
services/parallel.py — Independent reads, taken at the same time.

A page like the master list is thirteen questions to the database, and none of
them needs the answer to the others: participants, flights, transfers, hotels,
nights, activities, notes, communications, exceptions. Asked one after another
from Railway, each costs a round trip to Supabase — around two hundred
milliseconds of waiting during which nothing at all happens. Thirteen of those
is three seconds, and essentially all of it is latency rather than work.

Asked together, the same thirteen cost roughly one round trip.

Two rules make this safe to use on a page that must never break:

  * **A failed job is a missing answer, not an exception.** Every caller here
    already degraded gracefully — a deployment without migration 028 has no
    ``participant_notes`` table and the master list simply renders without note
    colours. Raising out of a thread would turn that into a blank page, so a
    job that fails returns ``None`` and the caller treats it exactly as its old
    ``except`` branch did.

  * **One job per question.** Grouping several reads behind one try/except is
    how a missing transfers table used to hide the flights that were fetched
    after it in the same block. Split, each failure costs only its own answer.

The Supabase client is shared across the threads on purpose: ``supabase.table()``
builds a fresh query object per call, and the httpx client underneath is
thread-safe. Nothing here mutates shared state.
"""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)

# Enough to collapse the biggest page into one wave, not so many that a burst of
# requests opens hundreds of connections to Supabase at once.
MAX_WORKERS = 10


def gather(
    jobs: dict[str, Callable[[], Any]],
    *,
    label: str = "",
    default: Any = None,
) -> dict[str, Any]:
    """Run every job at once; return their results by name.

    A job that raises is logged and yields ``default`` — the caller decides what
    a missing answer means, exactly as it did when the read was inline.

    Deterministic: results are keyed by name, so the order threads happen to
    finish in never reaches the page.
    """
    if not jobs:
        return {}

    out: dict[str, Any] = {}
    with ThreadPoolExecutor(max_workers=min(len(jobs), MAX_WORKERS)) as pool:
        futures = {name: pool.submit(job) for name, job in jobs.items()}
        for name, future in futures.items():
            try:
                out[name] = future.result()
            except Exception as exc:
                logger.warning(
                    "%s: could not read %s (%s) — continuing without it",
                    label or "parallel read", name, exc,
                )
                out[name] = default
    return out


def first_error(results: dict[str, Any], *names: str) -> Optional[str]:
    """The first of ``names`` whose answer is missing, or None.

    For the reads a page genuinely cannot do without: the caller checks them
    together rather than repeating the same ``is None`` four times.
    """
    for name in names:
        if results.get(name) is None:
            return name
    return None
