"""
services/information_request.py — Turning an exception into a question.

The exceptions module is good at noticing that Sophie's dietary requirements say
"YES" and nothing else. What it could not do is the obvious next thing: ask her
(feedback §14).

The rest of that loop already exists. ``email_agent_service`` reads an inbound
reply, extracts "Vegetarian", and proposes an update that a human validates
before it reaches the master list. The missing half was the outbound one — so
this module composes the question, and only the question.

Four rules, and each of them is a refusal:

  * **Only ask the participant what the participant knows.** A POSSIBLE_DUPLICATE
    is our problem, not theirs; "are you perhaps two people?" is not a question
    anybody should receive. The askable set below is deliberately short.
  * **Only ask for fields this event tracks.** A city conference that turned
    passports off in Settings must not email three hundred people about their
    passport. ``field_policy`` decides, exactly as it does for the alerts.
  * **One email per person, never one per exception.** Sophie missing a phone
    number AND her dietary details gets one message with two questions. Three
    separate emails in one afternoon is how an organizer burns a client's
    goodwill.
  * **Nothing is sent from here.** This builds a draft. A human reads it and
    presses send, through the same ``communications`` lifecycle every other
    outbound message goes through.

Pure module: dicts in, dicts out. No database, no mailbox, no clock.
"""

from __future__ import annotations

import logging
from typing import Any, Iterable, Optional

from services import field_policy, registration_i18n

logger = logging.getLogger(__name__)

# What a participant can actually answer about themselves.
#
# Everything the exception engine detects that is NOT in here is an internal
# problem — a conflict between two of our files, a suspected mapping error, a
# possible duplicate — and emailing somebody about it would be asking them to
# do our job while telling them we cannot keep our records straight.
ASKABLE: tuple[str, ...] = (
    "phone",
    "nationality",
    "dietary_requirements",
    "passport_number",
    "passport_expiry",
    "date_of_birth",
    "emergency_contact_name",
    "emergency_contact_phone",
    "pmr_needs",
    "roommate",
    "flight",
)

# An answer that is technically present and tells us nothing. The feedback's own
# example: "Dietary requirements: YES". A tick-box answered on a form that
# expected free text is not data, and treating it as data is how somebody ends
# up with a plate of chicken.
_EMPTY_ANSWERS = frozenset({
    "yes", "y", "oui", "ja", "true", "1", "x", "ok",
    "n/a", "na", "tbc", "tba", "?", "-", "to be confirmed", "a confirmer",
})

# exception_type -> the field it is really about, when there is exactly one.
# MISSING_REQUIRED_FIELD is absent on purpose: it carries its own list in
# ``context_data.missing_fields`` and reading that is more honest than guessing.
_TYPE_TO_FIELD: dict[str, str] = {
    "PARTICIPANT_NO_FLIGHT": "flight",
}

# context_data.category -> field, for the detectors that share a type.
_CATEGORY_TO_FIELD: dict[str, str] = {
    "roommate": "roommate",
}

_SUBJECTS: dict[str, str] = {
    "fr": "{event} — il nous manque quelques informations",
    "nl": "{event} — we missen nog enkele gegevens",
    "en": "{event} — a few details are still missing",
}

_OPENINGS: dict[str, str] = {
    "fr": (
        "Bonjour {first_name},\n\n"
        "Nous préparons votre participation à {event} et il nous manque encore "
        "les informations suivantes :"
    ),
    "nl": (
        "Beste {first_name},\n\n"
        "We bereiden uw deelname aan {event} voor en missen nog de volgende "
        "gegevens:"
    ),
    "en": (
        "Hello {first_name},\n\n"
        "We are preparing your participation in {event} and still need the "
        "following details:"
    ),
}

_CLOSINGS: dict[str, str] = {
    "fr": (
        "Vous pouvez simplement répondre à cet email — pas besoin de formulaire.\n\n"
        "Merci d'avance,\n{sender}"
    ),
    "nl": (
        "U kunt gewoon op deze e-mail antwoorden — geen formulier nodig.\n\n"
        "Alvast bedankt,\n{sender}"
    ),
    "en": (
        "You can simply reply to this email — no form to fill in.\n\n"
        "Thank you in advance,\n{sender}"
    ),
}

_DEADLINE: dict[str, str] = {
    "fr": "Merci de nous répondre avant le {deadline}.",
    "nl": "Gelieve te antwoorden vóór {deadline}.",
    "en": "Please reply before {deadline}.",
}

# The question, when the label alone is not a question. A participant reading
# "Régime alimentaire" in a list knows what to do; one reading "Vol" does not
# necessarily know we want the flight number and the times.
_HINTS: dict[str, dict[str, str]] = {
    "flight": {
        "fr": "numéro de vol, date et heure, à l'aller comme au retour",
        "nl": "vluchtnummer, datum en tijd, zowel heen als terug",
        "en": "flight number, date and time, both outbound and return",
    },
    "dietary_requirements": {
        "fr": "précisez lequel (végétarien, halal, allergie…)",
        "nl": "graag specifiëren (vegetarisch, halal, allergie…)",
        "en": "please specify which (vegetarian, halal, allergy…)",
    },
    "roommate": {
        "fr": "le nom et le prénom de la personne avec qui vous partagez la chambre",
        "nl": "de voor- en achternaam van de persoon met wie u de kamer deelt",
        "en": "the first and last name of the person you are sharing the room with",
    },
    "passport_expiry": {
        "fr": "au format JJ/MM/AAAA",
        "nl": "in het formaat DD/MM/JJJJ",
        "en": "in DD/MM/YYYY format",
    },
}

# The reason we are asking, shown to the ORGANIZER in the preview — never to the
# participant, who does not need to be told their own form was half-filled.
REASONS = {
    "missing": "champ vide",
    "uninformative": "répondu « oui » sans précision",
}


def is_uninformative(value: Any) -> bool:
    """True when a value is present but says nothing.

    Deliberately narrow. "No" is a real answer to a dietary question and must
    never land here — a vegetarian who answered "no allergies" being emailed to
    ask what they meant is worse than not asking at all.
    """
    text = str(value or "").strip().lower().rstrip(".!")
    return bool(text) and text in _EMPTY_ANSWERS


def _gap_reason(participant: dict[str, Any], key: str) -> Optional[str]:
    """Why this field is a gap for this person, or None if it is not."""
    if key == "flight":
        return None if participant.get("has_flight") else "missing"
    if key == "roommate":
        value = participant.get("roommate_name") or participant.get("roommate")
        return "missing" if not str(value or "").strip() else None
    value = participant.get(key)
    if not str(value or "").strip():
        return "missing"
    if is_uninformative(value):
        return "uninformative"
    return None


def fields_from_exceptions(exceptions: Iterable[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """participant id -> {"fields": [...], "exception_ids": [...]}.

    Merges every exception raised about one person into one request. The
    exception ids travel with it so the answer can close what prompted it.
    """
    out: dict[str, dict[str, Any]] = {}
    for exc in exceptions:
        pid = exc.get("participant_id")
        if not pid:
            continue                      # aggregated warnings are about mapping
        context = exc.get("context_data") or {}
        keys: list[str] = []

        for key in context.get("missing_fields") or []:
            if key in ASKABLE:
                keys.append(key)

        category = context.get("category")
        if category in _CATEGORY_TO_FIELD:
            keys.append(_CATEGORY_TO_FIELD[category])

        mapped = _TYPE_TO_FIELD.get(exc.get("exception_type") or "")
        if mapped:
            keys.append(mapped)

        if not keys:
            continue
        bucket = out.setdefault(pid, {"fields": [], "exception_ids": []})
        for key in keys:
            if key not in bucket["fields"]:
                bucket["fields"].append(key)
        if exc.get("id") and exc["id"] not in bucket["exception_ids"]:
            bucket["exception_ids"].append(exc["id"])
    return out


def plan_requests(
    participants: list[dict[str, Any]],
    wanted: dict[str, dict[str, Any]],
    policy: dict[str, str],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Who to ask, what to ask them, and who cannot be asked at all.

    Returns ``(requests, skipped)``. Each request carries the fields with their
    reason; ``skipped`` says why somebody was dropped, because "we emailed 40 of
    your 47 gaps" is only useful with the other seven named.

    Three things are filtered out here, and each one is a bug avoided:

      * a field the event does not track — asking is noise;
      * a field that has since been filled — the exception may be from last
        week's run, and nobody wants to be asked twice for what they sent;
      * a participant with no email address — including, pointedly, the case
        where the missing field IS the email.
    """
    by_id = {p["id"]: p for p in participants if p.get("id")}
    requests: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []

    for pid, ask in sorted(wanted.items()):
        person = by_id.get(pid)
        if person is None:
            skipped.append({"participant_id": pid, "reason": "unknown_participant"})
            continue

        name = _full_name(person)
        if not str(person.get("email") or "").strip():
            skipped.append({
                "participant_id": pid, "name": name, "reason": "no_email",
            })
            continue

        fields: list[dict[str, Any]] = []
        for key in ask.get("fields") or []:
            if not field_policy.is_tracked(policy, key):
                continue
            reason = _gap_reason(person, key)
            if reason is None:
                continue
            fields.append({"key": key, "reason": reason})

        if not fields:
            skipped.append({
                "participant_id": pid, "name": name, "reason": "nothing_left_to_ask",
            })
            continue

        requests.append({
            "participant_id": pid,
            "name": name,
            "email": person["email"],
            "language": registration_i18n.normalise(person.get("language")),
            "fields": fields,
            "exception_ids": ask.get("exception_ids") or [],
        })

    return requests, skipped


def compose(
    request: dict[str, Any],
    event_name: str,
    sender: str = "",
    deadline: str = "",
) -> tuple[str, str]:
    """The email itself, in the participant's language.

    Nothing about anybody else appears in it — not the roommate's answers, not
    the event's other gaps, not a count of how many people we are chasing.
    """
    locale = registration_i18n.normalise(request.get("language"))
    first_name = (request.get("name") or "").split(" ")[0] or request.get("name") or ""

    subject = _SUBJECTS.get(locale, _SUBJECTS["fr"]).format(event=event_name)

    lines = [_OPENINGS.get(locale, _OPENINGS["fr"]).format(
        first_name=first_name, event=event_name
    ), ""]
    for field in request.get("fields") or []:
        lines.append(f"  • {question(field['key'], locale)}")
    lines.append("")
    if deadline:
        lines.append(_DEADLINE.get(locale, _DEADLINE["fr"]).format(deadline=deadline))
        lines.append("")
    lines.append(_CLOSINGS.get(locale, _CLOSINGS["fr"]).format(sender=sender or event_name))

    return subject, "\n".join(lines)


def question(key: str, locale: str) -> str:
    """One line of the list: the field's own label, plus a hint when needed."""
    locale = registration_i18n.normalise(locale)
    label = registration_i18n.label(key, field_policy.label(key), locale)
    hint = _HINTS.get(key, {}).get(locale)
    return f"{label} ({hint})" if hint else label


def _full_name(participant: dict[str, Any]) -> str:
    return " ".join(
        part for part in (participant.get("first_name"), participant.get("last_name")) if part
    ).strip()


def summarise(requests: list[dict[str, Any]], skipped: list[dict[str, Any]]) -> dict[str, Any]:
    """What the organizer sees before pressing anything."""
    by_field: dict[str, int] = {}
    by_language: dict[str, int] = {}
    for request in requests:
        by_language[request["language"]] = by_language.get(request["language"], 0) + 1
        for field in request["fields"]:
            by_field[field["key"]] = by_field.get(field["key"], 0) + 1
    reasons: dict[str, int] = {}
    for entry in skipped:
        reasons[entry["reason"]] = reasons.get(entry["reason"], 0) + 1
    return {
        "recipients": len(requests),
        "questions": sum(len(r["fields"]) for r in requests),
        "by_field": dict(sorted(by_field.items())),
        "by_language": dict(sorted(by_language.items())),
        "skipped": len(skipped),
        "skipped_reasons": dict(sorted(reasons.items())),
    }
