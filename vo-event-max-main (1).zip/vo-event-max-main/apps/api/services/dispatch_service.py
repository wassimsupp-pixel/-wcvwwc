"""
services/dispatch_service.py — Turning flight times into vehicles.

MAX organises ground transport from the flights: people landing on the same
plane travel together, people landing close enough in time can share, and the
vehicle is chosen from the head count — taxi, van, minibus, bus (feedback §1).

The tool's job is to propose the obvious answer, not to decide. Everything here
returns a **plan**: a list of groups with a pickup time, a vehicle and its
passengers, and nothing is written anywhere. The organizer accepts it, splits a
group, swaps a vehicle, moves an hour or adds somebody by hand, and only then
does it become rows in the database. That separation is the point — it is the
same "l'IA propose, l'utilisateur garde le contrôle" the feedback repeats, and
here it is not even AI, just arithmetic that still has no business overruling
somebody who knows the client.

Three things this module refuses to do:

  * **Guess a vehicle it does not have.** With no fleet configured it returns
    groups with a head count and no vehicle, rather than inventing a "bus".
  * **Overfill.** A group larger than the biggest vehicle is split across
    several, never rounded up into one that cannot hold it.
  * **Invent a return time.** A departure pickup needs a flight time and a
    safety margin; without either, the group is proposed with no pickup time
    and flagged, which an organizer can see and fix.

Pure by construction — dicts in, dicts out, no database — so the grouping and
the vehicle choice can be tested against a table of head counts.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any, Iterable, Optional

logger = logging.getLogger(__name__)

ARRIVAL = "arrival"
DEPARTURE = "departure"

# What the feedback itself lists, as the starting point an organizer edits per
# event. Names in French because that is what appears on their transfer sheets.
DEFAULT_FLEET: tuple[dict[str, Any], ...] = (
    {"name": "Taxi", "capacity": 3},
    {"name": "Van", "capacity": 7},
    {"name": "Minibus", "capacity": 18},
    {"name": "Bus", "capacity": 50},
)

# "Temps minimum avant départ du vol" — three hours is the value MAX gave as
# their usual international default. Configurable per event.
DEFAULT_SAFETY_HOURS = 3.0

# Arrivals within this many minutes of each other can share a vehicle.
# Lowered from 60 on 2026-08-18: an hour apart was pairing people who had
# already been waiting a while by the time the last one landed. Still
# configurable per event through PUT .../transfer-settings.
DEFAULT_WINDOW_MINUTES = 45

# Where the arrivals are dropped off and the departures picked up. There is no
# way to derive it: an event's hotel is not in the flight file, and the hotel
# file names properties without saying which one this transfer serves. So the
# organizer writes it once and every group uses it. Empty falls back to the
# generic word rather than to a hotel nobody booked.
DEFAULT_HOTEL_NAME = ""
_MAX_HOTEL_NAME = 120

_MAX_WINDOW_MINUTES = 24 * 60


def resolve_settings(stored: Any) -> dict[str, Any]:
    """An event's transfer settings, with anything unusable replaced.

    A malformed fleet must not take the proposal down: an organizer editing
    JSON in a console is one typo away from a capacity of zero, which would
    make the vehicle chooser loop forever.
    """
    config = stored if isinstance(stored, dict) else {}

    fleet: list[dict[str, Any]] = []
    raw_fleet = config.get("vehicles")
    if isinstance(raw_fleet, list):
        for entry in raw_fleet[:20]:
            if not isinstance(entry, dict):
                continue
            name = str(entry.get("name") or "").strip()[:60]
            try:
                capacity = int(entry.get("capacity"))
            except (TypeError, ValueError):
                continue
            if name and capacity > 0:
                fleet.append({"name": name, "capacity": capacity})
    if not fleet:
        fleet = [dict(v) for v in DEFAULT_FLEET]

    try:
        safety = float(config.get("min_hours_before_flight"))
        if not 0 < safety <= 24:
            raise ValueError
    except (TypeError, ValueError):
        safety = DEFAULT_SAFETY_HOURS

    try:
        window = int(config.get("grouping_window_minutes"))
        if not 0 < window <= _MAX_WINDOW_MINUTES:
            raise ValueError
    except (TypeError, ValueError):
        window = DEFAULT_WINDOW_MINUTES

    # Only a string is a hotel name. str() on a list would happily store
    # "['x']" and print it on a driver's sheet, the same way an unvalidated
    # fleet would have stored a zero-seat vehicle.
    raw_hotel = config.get("hotel_name")
    hotel = raw_hotel.strip()[:_MAX_HOTEL_NAME] if isinstance(raw_hotel, str) else ""

    return {
        "vehicles": sorted(fleet, key=lambda v: v["capacity"]),
        "min_hours_before_flight": safety,
        "grouping_window_minutes": window,
        "hotel_name": hotel or DEFAULT_HOTEL_NAME,
    }


def _airport(value: Any) -> str:
    """An airport as it should read on a transfer sheet."""
    return str(value or "").strip()[:80]


def choose_vehicles(passengers: int, fleet: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """The vehicles needed for a head count, smallest sufficient first.

    One vehicle when one fits: 23 people with a 50-seat bus available is one
    bus, which is what MAX would book. Only when nobody is big enough does it
    split — 120 people become two buses and a van, not three buses with sixty
    empty seats between them.

    The remainder is then rounded UP to the smallest vehicle that holds it, so
    four leftover passengers get a van rather than two taxis.
    """
    if passengers <= 0 or not fleet:
        return []

    ordered = sorted(fleet, key=lambda v: v["capacity"])
    for vehicle in ordered:
        if vehicle["capacity"] >= passengers:
            return [{"name": vehicle["name"], "capacity": vehicle["capacity"], "seats_used": passengers}]

    largest = ordered[-1]
    chosen: list[dict[str, Any]] = []
    remaining = passengers
    while remaining > largest["capacity"]:
        chosen.append({
            "name": largest["name"], "capacity": largest["capacity"],
            "seats_used": largest["capacity"],
        })
        remaining -= largest["capacity"]
    chosen.extend(choose_vehicles(remaining, ordered))
    return chosen


def _as_dt(value: Any) -> Optional[datetime]:
    """A timezone-naive datetime from what the flights table holds, or None."""
    if isinstance(value, datetime):
        return value.replace(tzinfo=None)
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).replace(tzinfo=None)
    except ValueError:
        logger.debug("Unparsable flight time: %r", value)
        return None


def _slot(moment: datetime, window_minutes: int) -> datetime:
    """The window a moment falls into, anchored to midnight.

    Anchored to midnight rather than to the arrival's own hour: with a 90- or
    120-minute window, anchoring to "own hour" silently collapses back to
    hourly buckets, and two flights twenty minutes apart can land in slots an
    hour apart. The same bug was fixed in the older grouping endpoint; the
    grid is the fix, so it is built in here rather than rediscovered.
    """
    minutes = moment.hour * 60 + moment.minute
    start = moment.replace(hour=0, minute=0, second=0, microsecond=0)
    return start + timedelta(minutes=(minutes // window_minutes) * window_minutes)


def propose_arrivals(
    flights: Iterable[dict[str, Any]],
    settings: dict[str, Any],
    airport: str = "",
    destination: str = "",
) -> list[dict[str, Any]]:
    """Group arrivals into shared vehicles.

    People on the same flight always travel together; flights landing in the
    same window AND at the same airport share a vehicle. Pickup is set at the
    END of the window, so the last passenger to land is not being waited for
    by a bus that left.

    The airport is part of the grouping key, not a setting. Two people landing
    at 14:00, one at Brussels and one at Charleroi, are not sharing a car, and
    a single `airport` string for the whole event said they were — while also
    printing the wrong pickup point on both their sheets.
    """
    window = settings["grouping_window_minutes"]
    fleet = settings["vehicles"]
    hotel = settings.get("hotel_name") or destination

    buckets: dict[tuple[datetime, str], list[dict[str, Any]]] = {}
    for flight in flights:
        landed = _as_dt(flight.get("arrival_time"))
        if not landed or not flight.get("participant_id"):
            continue
        where = _airport(flight.get("arrival_airport")) or _airport(airport)
        buckets.setdefault((_slot(landed, window), where), []).append(flight)

    proposals: list[dict[str, Any]] = []
    for slot, where in sorted(buckets, key=lambda k: (k[0], k[1])):
        members = buckets[(slot, where)]
        pickup = slot + timedelta(minutes=window)
        flight_numbers = sorted({
            str(f.get("flight_number") or "").strip()
            for f in members if str(f.get("flight_number") or "").strip()
        })
        participants = sorted({f["participant_id"] for f in members})
        for index, vehicle in enumerate(_split(participants, fleet)):
            proposals.append({
                "direction": ARRIVAL,
                "pickup_time": pickup.isoformat(),
                "pickup_location": where or "Aéroport",
                "dropoff_location": hotel or "Hôtel",
                "flight_numbers": flight_numbers,
                "participant_ids": vehicle["participant_ids"],
                "passengers": len(vehicle["participant_ids"]),
                "vehicle": vehicle["vehicle"],
                "sequence": index + 1,
            })
    return proposals


def propose_departures(
    flights: Iterable[dict[str, Any]],
    settings: dict[str, Any],
    airport: str = "",
    origin: str = "",
) -> list[dict[str, Any]]:
    """Group departures, working backwards from each flight's take-off.

    Flight at 14:00 with a three-hour margin means leaving the hotel at 11:00
    — the feedback's own example. Passengers whose computed departure falls in
    the same window ride together.
    """
    window = settings["grouping_window_minutes"]
    margin = timedelta(hours=settings["min_hours_before_flight"])
    fleet = settings["vehicles"]
    hotel = settings.get("hotel_name") or origin

    # Same reasoning as the arrivals: the airport somebody flies OUT of belongs
    # in the key. Two people leaving at the same hour from two airports need
    # two cars going in two directions.
    buckets: dict[tuple[datetime, str], list[dict[str, Any]]] = {}
    undated: list[dict[str, Any]] = []
    for flight in flights:
        if not flight.get("participant_id"):
            continue
        takeoff = _as_dt(flight.get("departure_time"))
        where = _airport(flight.get("departure_airport")) or _airport(airport)
        if not takeoff:
            undated.append(flight)
            continue
        buckets.setdefault((_slot(takeoff - margin, window), where), []).append(flight)

    proposals: list[dict[str, Any]] = []
    for slot, where in sorted(buckets, key=lambda k: (k[0], k[1])):
        members = buckets[(slot, where)]
        flight_numbers = sorted({
            str(f.get("flight_number") or "").strip()
            for f in members if str(f.get("flight_number") or "").strip()
        })
        participants = sorted({f["participant_id"] for f in members})
        for index, vehicle in enumerate(_split(participants, fleet)):
            proposals.append({
                "direction": DEPARTURE,
                # The START of the window: leaving early is inconvenient,
                # leaving late means missing a plane.
                "pickup_time": slot.isoformat(),
                "pickup_location": hotel or "Hôtel",
                "dropoff_location": where or "Aéroport",
                "flight_numbers": flight_numbers,
                "participant_ids": vehicle["participant_ids"],
                "passengers": len(vehicle["participant_ids"]),
                "vehicle": vehicle["vehicle"],
                "sequence": index + 1,
            })

    if undated:
        # Surfaced rather than dropped: a participant with a return flight and
        # no time on it needs a transfer somebody has to arrange by hand, and
        # silence is how they end up without one.
        proposals.append({
            "direction": DEPARTURE,
            "pickup_time": None,
            "pickup_location": hotel or "Hôtel",
            "dropoff_location": _airport(
                next((f.get("departure_airport") for f in undated
                      if _airport(f.get("departure_airport"))), "")
            ) or _airport(airport) or "Aéroport",
            "flight_numbers": sorted({
                str(f.get("flight_number") or "").strip()
                for f in undated if str(f.get("flight_number") or "").strip()
            }),
            "participant_ids": sorted({f["participant_id"] for f in undated}),
            "passengers": len({f["participant_id"] for f in undated}),
            "vehicle": None,
            "sequence": 1,
            "needs_attention": "no_flight_time",
        })
    return proposals


def _split(participant_ids: list[str], fleet: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Passengers dealt into the vehicles that carry them."""
    vehicles = choose_vehicles(len(participant_ids), fleet)
    if not vehicles:
        # No fleet configured: one group, a head count, and no invented vehicle.
        return [{"participant_ids": participant_ids, "vehicle": None}]
    out: list[dict[str, Any]] = []
    cursor = 0
    for vehicle in vehicles:
        take = vehicle["seats_used"]
        out.append({
            "participant_ids": participant_ids[cursor:cursor + take],
            "vehicle": {"name": vehicle["name"], "capacity": vehicle["capacity"]},
        })
        cursor += take
    return out


def summarise(proposals: list[dict[str, Any]]) -> dict[str, Any]:
    """Head-line numbers for the confirmation screen."""
    return {
        "groups": len(proposals),
        "participants": len({p for group in proposals for p in group["participant_ids"]}),
        "arrivals": sum(1 for g in proposals if g["direction"] == ARRIVAL),
        "departures": sum(1 for g in proposals if g["direction"] == DEPARTURE),
        "needs_attention": sum(1 for g in proposals if g.get("needs_attention")),
    }
