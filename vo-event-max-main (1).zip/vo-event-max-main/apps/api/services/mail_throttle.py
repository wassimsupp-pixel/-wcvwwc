"""
services/mail_throttle.py — Two hundred emails without looking like a spammer.

§15 asks for the communication side to move onto Microsoft when the app lands in
VO's environment, and names the thing that will break first: "il faudra gérer
intelligemment l'envoi de masse pour éviter que Outlook considère 200 mails
envoyés simultanément comme du spam."

That is not a theoretical worry. Exchange Online throttles a mailbox at roughly
30 messages a minute and 10 000 recipients a day, and a burst that trips it does
not fail cleanly — the tenant's reputation drops, later mail lands in Junk, and
the damage outlives the campaign that caused it. Gmail is looser but not
unlimited.

So sending is paced, and the pacing is a plan computed before anything leaves:

  * a **rate** per minute, per provider, deliberately below the published
    ceiling — the goal is to stay invisible to the throttler, not to race it;
  * a **batch size**, so the sender pauses in chunks rather than sleeping
    between every single message;
  * a **daily cap**, beyond which the run stops and says so rather than
    silently dropping the tail.

Everything here is pure arithmetic over a plan. The waiting itself belongs to
the caller, which is what lets the schedule be asserted in a test instead of
observed over four minutes.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

GMAIL = "gmail"
OUTLOOK = "outlook"

# Comfortably under what each provider actually enforces. Exchange Online
# throttles around 30/minute and Gmail's API around 100 — sitting at two thirds
# of the ceiling leaves room for whatever else the mailbox is doing while a
# campaign runs, which is the case nobody remembers to account for.
DEFAULT_RATES: dict[str, dict[str, int]] = {
    OUTLOOK: {"per_minute": 20, "batch": 10, "daily_cap": 9000},
    GMAIL:   {"per_minute": 60, "batch": 20, "daily_cap": 1500},
}

# For an unknown or absent provider. The slowest of the two: guessing high on
# a mailbox we know nothing about is how a reputation gets burned.
FALLBACK = {"per_minute": 20, "batch": 10, "daily_cap": 1000}


def settings_for(provider: Optional[str], override: Any = None) -> dict[str, int]:
    """The pacing for this mailbox, with an event's own values applied.

    A malformed override falls back rather than raising: an organizer editing
    JSON in a console is one typo away from a rate of zero, which would make
    the sender wait forever on the first message.
    """
    base = dict(DEFAULT_RATES.get(str(provider or "").lower(), FALLBACK))
    config = override if isinstance(override, dict) else {}

    for key, floor, ceiling in (
        ("per_minute", 1, 300),
        ("batch", 1, 100),
        ("daily_cap", 1, 100_000),
    ):
        value = config.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            continue
        number = int(value)
        if floor <= number <= ceiling:
            base[key] = number

    # A batch larger than the per-minute rate would send the whole minute's
    # quota in one burst, which is exactly the shape a throttler notices.
    base["batch"] = min(base["batch"], base["per_minute"])
    return base


def plan(total: int, provider: Optional[str] = None, override: Any = None) -> dict[str, Any]:
    """How this send will be spread out, decided before anything leaves.

    Returns the batch layout, the pause between batches, an estimated duration,
    and — when the run exceeds the daily cap — how many messages will NOT be
    attempted. Reporting that up front is the whole point: an organizer who
    learns at message 9 001 that the rest never went is one who has already
    told a client they were sent.
    """
    rules = settings_for(provider, override)
    total = max(0, int(total or 0))

    attempted = min(total, rules["daily_cap"])
    deferred = total - attempted
    batch = rules["batch"]
    batches = (attempted + batch - 1) // batch if attempted else 0

    # Seconds to wait AFTER each batch so the rate holds. The final batch needs
    # no pause — waiting after the last message delays nothing but the report.
    pause = round(60.0 * batch / rules["per_minute"], 2)
    seconds = round(pause * max(0, batches - 1), 1)

    return {
        "total": total,
        "attempted": attempted,
        "deferred": deferred,
        "batches": batches,
        "batch_size": batch,
        "pause_seconds": pause,
        "per_minute": rules["per_minute"],
        "daily_cap": rules["daily_cap"],
        "estimated_seconds": seconds,
        "provider": provider or "",
    }


def batches(items: list[Any], size: int) -> list[list[Any]]:
    """The list, cut into sending chunks."""
    size = max(1, int(size or 1))
    return [items[i:i + size] for i in range(0, len(items), size)]


def describe(schedule: dict[str, Any], locale: str = "fr") -> str:
    """One sentence an organizer reads before pressing send."""
    if not schedule["attempted"]:
        return "Aucun destinataire." if locale == "fr" else "No recipients."

    minutes = schedule["estimated_seconds"] / 60.0
    if locale == "fr":
        duration = (
            "moins d'une minute" if minutes < 1
            else f"environ {round(minutes)} minute(s)"
        )
        line = (
            f"{schedule['attempted']} email(s) par lots de {schedule['batch_size']}, "
            f"{schedule['per_minute']}/minute — {duration}."
        )
        if schedule["deferred"]:
            line += (
                f" {schedule['deferred']} au-delà du plafond quotidien de "
                f"{schedule['daily_cap']} ne seront pas envoyés aujourd'hui."
            )
        return line

    duration = "under a minute" if minutes < 1 else f"about {round(minutes)} minute(s)"
    line = (
        f"{schedule['attempted']} email(s) in batches of {schedule['batch_size']}, "
        f"{schedule['per_minute']}/minute — {duration}."
    )
    if schedule["deferred"]:
        line += (
            f" {schedule['deferred']} beyond today's cap of {schedule['daily_cap']} "
            f"will not be sent today."
        )
    return line
