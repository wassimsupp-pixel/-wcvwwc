"""
services/ai_service.py — Unified AI gateway for every intelligent step
(auto-mapping, file analysis, poster recognition, quality summaries, email
agent, campaign generation).

Provider policy (first usable wins, automatic fallback on failure):
  1. Anthropic Claude (env ``ANTHROPIC_API_KEY``, ``claude-opus-5``) — used
     FIRST when its key is present. Official SDK, text and vision. Absent the
     key this provider returns None immediately and the chain below is exactly
     what it always was, so adding Claude changes nothing until it is
     configured.
  2. NVIDIA NIM (env ``NVIDIA_API_KEY``). Text reasoning (mapping, fusion,
     analysis) via ``nemotron``; photo/PDF vision (event posters) via
     ``meta/llama-3.2-90b-vision-instruct``. OpenAI-compatible endpoint.
  3. OpenAI (env ``OPENAI_API_KEY``, gpt-4o-mini) — vision-capable fallback.
  4. Google Gemini (env ``GEMINI_API_KEY``, gemini-2.5-flash) — final fallback,
     handles images and PDFs natively.

An invalid key is detected once (401/403) and that provider is skipped for the
rest of the process — no added latency on later calls. A slow or too-large
image on NVIDIA simply falls back to the next vision provider.

Model overrides: ``ANTHROPIC_MODEL``, ``ANTHROPIC_EFFORT``, ``NVIDIA_MODEL``
(text), ``NVIDIA_VISION_MODEL`` (vision).
"""

from __future__ import annotations

import base64
import json
import logging
import os
from typing import Any, Optional

import httpx

logger = logging.getLogger(__name__)

_NVIDIA_URL = "https://integrate.api.nvidia.com/v1/chat/completions"
# Text model for mapping / fusion / analysis / match arbitration. Nemotron-3
# Ultra is an agentic reasoning model (its chain-of-thought lands in a separate
# ``reasoning_content`` field, so ``content`` stays clean JSON). Despite being a
# 550B flagship it uses speculative decoding and is ~2.7x faster than Llama 3.3
# 70B on a real mapping prompt (~28s vs ~78s) while producing better-reasoned
# fusion/arbitration decisions. Override with NVIDIA_MODEL.
_NVIDIA_MODEL = os.getenv("NVIDIA_MODEL", "nvidia/nemotron-3-ultra-550b-a55b")
# Vision model for event photo/PDF analysis (Pixtral is not available on the
# integrate endpoint; Llama 3.2 90B Vision is and is confirmed working).
_NVIDIA_VISION_MODEL = os.getenv("NVIDIA_VISION_MODEL", "meta/llama-3.2-90b-vision-instruct")
# Fast model for short, tightly-constrained tasks (the assistant's query
# planner). Benchmarked on the real planning prompt, 2026-08-03: the 30B nano
# answered in ~11s against ~17s for the 550B flagship with the same JSON
# validity, and the caller re-runs the flagship whenever a fast answer fails
# validation — so speed never costs correctness. Override with NVIDIA_FAST_MODEL.
NVIDIA_FAST_MODEL = os.getenv("NVIDIA_FAST_MODEL", "nvidia/nemotron-3-nano-30b-a3b")
# Model for FREE PROSE (the assistant's advisory answers and phrasing). The
# planner benchmark ranked models on JSON validity and passed this one over for
# failing that 1 time in 3 — the wrong test for prose, which has no JSON to get
# wrong. Re-benchmarked on the real advisory prompt, 2026-08-05: 3/3 grounded
# answers, ~31s median (vs 34s for the 30B nano and repeated timeouts for the
# 550B flagship), and visibly better writing — it explains what a figure means
# for the event instead of listing it. Override with NVIDIA_PROSE_MODEL.
NVIDIA_PROSE_MODEL = os.getenv("NVIDIA_PROSE_MODEL", "nvidia/nemotron-3-super-120b-a12b")
_nvidia_disabled = False

_OPENAI_URL = "https://api.openai.com/v1/chat/completions"
_OPENAI_MODEL = "gpt-4o-mini"
_openai_disabled = False

# google-genai (successor of the EOL google-generativeai package — same API
# key, same models; only the client surface changed). The old package was
# never in requirements.txt, so this fallback only ever worked on machines
# that happened to have it installed — google-genai is now a declared
# dependency and the fallback is real everywhere.
# --- Anthropic (Claude) ---------------------------------------------------
_ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-opus-5")
# Thinking depth and overall token spend. Claude Opus 5 thinks by default and
# "high" is the API's own default; it is exposed here so an operator can trade
# depth for latency on the interactive paths (the form assistant, the chatbot)
# without a redeploy. Values: low | medium | high | xhigh | max.
_ANTHROPIC_EFFORT = os.getenv("ANTHROPIC_EFFORT", "high")
ANTHROPIC_SDK_AVAILABLE = False
_anthropic_client = None
_anthropic_disabled = False
try:
    import anthropic as _anthropic
    ANTHROPIC_SDK_AVAILABLE = True
except ImportError:
    pass

_GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
GEMINI_AVAILABLE = False
_gemini_client = None
try:
    from google import genai as _genai
    from google.genai import types as _genai_types
    if os.getenv("GEMINI_API_KEY"):
        _gemini_client = _genai.Client(api_key=os.getenv("GEMINI_API_KEY"))
        GEMINI_AVAILABLE = True
except ImportError:
    pass


def _nvidia_key() -> Optional[str]:
    if _nvidia_disabled:
        return None
    return (os.getenv("NVIDIA_API_KEY") or "").strip() or None


def _openai_key() -> Optional[str]:
    if _openai_disabled:
        return None
    return (os.getenv("OPENAI_API_KEY") or "").strip() or None


def _anthropic_key() -> Optional[str]:
    if _anthropic_disabled or not ANTHROPIC_SDK_AVAILABLE:
        return None
    return (os.getenv("ANTHROPIC_API_KEY") or "").strip() or None


def _anthropic_ready() -> "Optional[Any]":
    """The Claude client, built once, or None when it cannot be used.

    Built lazily rather than at import: the key is read at call time, so a
    deployment that gains ANTHROPIC_API_KEY starts using Claude on its next
    request instead of on its next restart.
    """
    global _anthropic_client
    key = _anthropic_key()
    if not key:
        return None
    if _anthropic_client is None:
        _anthropic_client = _anthropic.Anthropic(api_key=key)
    return _anthropic_client


def ai_available() -> bool:
    """True when at least one AI provider is usable."""
    return (
        bool(_anthropic_key())
        or bool(_nvidia_key())
        or bool(_openai_key())
        or GEMINI_AVAILABLE
    )


def _anthropic_complete(
    prompt: str,
    image_bytes: Optional[bytes],
    mime_type: Optional[str],
    timeout_s: Optional[float] = None,
    model_override: Optional[str] = None,
) -> Optional[str]:
    """Claude, through the official SDK.

    Returns None on every failure, like the providers below it, so the gateway
    simply moves on to NVIDIA rather than surfacing an error to a screen.

    ``model_override`` is honoured ONLY when it names a Claude model. Every
    existing caller passes an NVIDIA model id through that argument — the
    chatbot's planner asks for the fast Nemotron, its phrasing step for the
    prose one — and forwarding those to the Anthropic API would 404 on every
    call. An override meant for another provider is therefore ignored, not
    translated: choosing a cheaper Claude model is a decision for whoever
    configures ANTHROPIC_MODEL, not something to infer from a Nemotron id.
    """
    global _anthropic_disabled
    client = _anthropic_ready()
    if client is None:
        return None

    if image_bytes is not None:
        content: Any = [
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": mime_type or "image/png",
                    "data": base64.standard_b64encode(image_bytes).decode(),
                },
            },
            {"type": "text", "text": prompt},
        ]
        timeout = timeout_s or 120.0
    else:
        content = prompt
        timeout = timeout_s or 90.0

    model = model_override if (model_override or "").startswith("claude") else _ANTHROPIC_MODEL

    try:
        response = client.with_options(timeout=timeout).messages.create(
            model=model,
            max_tokens=16000,
            output_config={"effort": _ANTHROPIC_EFFORT},
            messages=[{"role": "user", "content": content}],
        )
    except (_anthropic.AuthenticationError, _anthropic.PermissionDeniedError) as exc:
        # A bad key does not get better on the next call. Same treatment the
        # NVIDIA path gives a 401: stop asking for the rest of the process.
        logger.error("Anthropic key rejected (%s) — skipping Claude for the rest of this process.", exc)
        _anthropic_disabled = True
        return None
    except _anthropic.NotFoundError as exc:
        logger.warning("Anthropic model %r not found (%s) — trying next provider.", model, exc)
        return None
    except _anthropic.RateLimitError as exc:
        logger.warning("Anthropic rate limited (%s) — trying next provider.", exc)
        return None
    except _anthropic.APIStatusError as exc:
        logger.warning("Anthropic call failed with %s (%s) — trying next provider.", exc.status_code, exc)
        return None
    except _anthropic.APIConnectionError as exc:
        logger.warning("Anthropic unreachable (%s) — trying next provider.", exc)
        return None
    except Exception as exc:                        # noqa: BLE001 — never fail a screen
        logger.warning("Anthropic call failed (%s) — trying next provider.", exc)
        return None

    # A policy decline arrives as HTTP 200 with no usable text. Falling through
    # to the next provider is the honest answer; returning "" would look to the
    # caller like a model that answered with nothing.
    if getattr(response, "stop_reason", None) == "refusal":
        category = getattr(getattr(response, "stop_details", None), "category", None)
        logger.warning("Claude declined the request (%s) — trying next provider.", category)
        return None

    # Only text blocks carry the answer: a response may also contain thinking
    # blocks, and concatenating those would put reasoning into the JSON the
    # callers parse.
    text = "".join(
        block.text for block in response.content if getattr(block, "type", None) == "text"
    ).strip()
    return text or None


def _nvidia_complete(prompt: str, image_bytes: Optional[bytes], mime_type: Optional[str], timeout_s: Optional[float] = None, model_override: Optional[str] = None) -> Optional[str]:
    """
    NVIDIA NIM chat completion (OpenAI-compatible). Text uses the Mistral text
    model; an image uses the vision model with a longer timeout. Returns None on
    any failure so the gateway falls back to the next provider.
    """
    global _nvidia_disabled
    key = _nvidia_key()
    if not key:
        return None

    if image_bytes is not None:
        b64 = base64.b64encode(image_bytes).decode()
        content: Any = [
            {"type": "text", "text": prompt},
            {"type": "image_url", "image_url": {"url": f"data:{mime_type or 'image/png'};base64,{b64}"}},
        ]
        model = _NVIDIA_VISION_MODEL
        timeout = timeout_s or 120.0
    else:
        content = prompt
        # A caller may name a cheaper/faster model for a task that does not
        # need the flagship's reasoning (the assistant's query planner tries a
        # fast one first and only falls back to the default when the result
        # fails validation).
        model = model_override or _NVIDIA_MODEL
        # Reasoning model: allow headroom for chain-of-thought on large mappings.
        # Interactive paths still pass their own short timeout_s to stay snappy.
        timeout = timeout_s or 90.0

    try:
        resp = httpx.post(
            _NVIDIA_URL,
            headers={"Authorization": f"Bearer {key}"},
            json={
                "model": model,
                "messages": [{"role": "user", "content": content}],
                "temperature": 0,
            },
            timeout=timeout,
        )
        if resp.status_code in (401, 403):
            logger.error("NVIDIA key rejected — skipping NVIDIA for the rest of this process.")
            _nvidia_disabled = True
            return None
        resp.raise_for_status()
        return (resp.json()["choices"][0]["message"]["content"] or "").strip()
    except Exception as exc:
        logger.warning("NVIDIA call failed (%s) — trying next provider.", exc)
        return None


def _openai_complete(prompt: str, image_bytes: Optional[bytes], mime_type: Optional[str], timeout_s: Optional[float] = None) -> Optional[str]:
    global _openai_disabled
    key = _openai_key()
    if not key:
        return None
    content: Any = prompt
    if image_bytes is not None:
        b64 = base64.b64encode(image_bytes).decode()
        content = [
            {"type": "text", "text": prompt},
            {"type": "image_url", "image_url": {"url": f"data:{mime_type or 'image/png'};base64,{b64}"}},
        ]
    try:
        resp = httpx.post(
            _OPENAI_URL,
            headers={"Authorization": f"Bearer {key}"},
            json={
                "model": _OPENAI_MODEL,
                "messages": [{"role": "user", "content": content}],
                "temperature": 0,
            },
            timeout=timeout_s or 45.0,
        )
        if resp.status_code in (401, 403):
            logger.error("OpenAI key rejected (%s) — falling back to Gemini for this process.", resp.status_code)
            _openai_disabled = True
            return None
        resp.raise_for_status()
        return (resp.json()["choices"][0]["message"]["content"] or "").strip()
    except Exception as exc:
        logger.warning("OpenAI call failed (%s) — trying Gemini fallback.", exc)
        return None


def _gemini_complete(prompt: str, image_bytes: Optional[bytes], mime_type: Optional[str], timeout_s: Optional[float] = None) -> Optional[str]:
    if not GEMINI_AVAILABLE or _gemini_client is None:
        return None
    try:
        contents: list[Any] = [prompt]
        if image_bytes is not None:
            contents.append(_genai_types.Part.from_bytes(data=image_bytes, mime_type=mime_type or "image/png"))
        kwargs: dict[str, Any] = {}
        if timeout_s:
            # google-genai HttpOptions.timeout is in MILLISECONDS.
            kwargs["config"] = _genai_types.GenerateContentConfig(
                http_options=_genai_types.HttpOptions(timeout=int(timeout_s * 1000))
            )
        resp = _gemini_client.models.generate_content(
            model=_GEMINI_MODEL, contents=contents, **kwargs
        )
        return (resp.text or "").strip()
    except Exception as exc:
        logger.warning("Gemini call failed: %s", exc)
        return None


def ai_text(
    prompt: str,
    image_bytes: Optional[bytes] = None,
    mime_type: Optional[str] = None,
    timeout_s: Optional[float] = None,
    model_override: Optional[str] = None,
) -> Optional[str]:
    """
    Run the prompt (optionally with an image) through the best available
    provider. Returns the raw text answer, or None when no provider succeeds.
    ``timeout_s`` bounds each provider call — pass a short value on interactive
    paths so a slow model never blocks the UI.
    """
    return (
        _anthropic_complete(prompt, image_bytes, mime_type, timeout_s, model_override)
        or _nvidia_complete(prompt, image_bytes, mime_type, timeout_s, model_override)
        or _openai_complete(prompt, image_bytes, mime_type, timeout_s)
        or _gemini_complete(prompt, image_bytes, mime_type, timeout_s)
    )


def strip_json(text: Optional[str]) -> Optional[Any]:
    """Extract and parse the JSON object/array from an LLM answer."""
    if not text:
        return None
    t = text.strip()
    if "```json" in t:
        t = t.split("```json")[1].split("```")[0].strip()
    elif "```" in t:
        t = t.split("```")[1].split("```")[0].strip()
    start = min((i for i in (t.find("{"), t.find("[")) if i >= 0), default=-1)
    if start < 0:
        return None
    end = max(t.rfind("}"), t.rfind("]"))
    if end <= start:
        return None
    try:
        return json.loads(t[start:end + 1])
    except ValueError:
        return None


def ai_json(
    prompt: str,
    image_bytes: Optional[bytes] = None,
    mime_type: Optional[str] = None,
    timeout_s: Optional[float] = None,
) -> Optional[Any]:
    """ai_text + JSON extraction. Returns the parsed object, or None."""
    return strip_json(ai_text(prompt, image_bytes, mime_type, timeout_s))
