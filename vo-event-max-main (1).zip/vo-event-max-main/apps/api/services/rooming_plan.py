"""
services/rooming_plan.py — A rooming list somebody decides to make.

``room_service`` derives rooms live, on every read: it answers "given what we
know right now, who would share with whom". That is the right answer for a
dashboard and the wrong one for a rooming list, because a rooming list is a
document. It gets printed, sent to a hotel, and referred to by number for three
weeks. A document that quietly renumbers itself between two page loads — because
somebody cancelled on Tuesday — is not a document.

So the list is **generated**, on purpose, by a person, and then it stays put:

  * generation reads the same links and nights ``room_service`` reads, assigns a
    number to every room that has none, and stores the result as a version;
  * nothing else in the system may rewrite that version — a consolidation
    changes the underlying data, never the generated list;
  * when the data has moved on, the stored list is flagged **stale**, and the
    organizer decides whether to regenerate. The system reports the drift; it
    does not resolve it.

Two numbering rules make regeneration safe to press:

  * **A number the hotel gave is never touched.** It is a fact about a physical
    room, and we do not own it.
  * **A number we generated is kept as long as the room still holds the same
    people.** Regenerating after one cancellation must not shift ninety numbers
    and force a reprint. Renumbering everything from scratch is available, but
    only when explicitly asked for.

Pure module: it takes lists of dicts and returns dicts. No database, no clock,
no randomness — the same inputs always produce the same list, which is what
makes a generated document worth trusting.
"""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Any, Iterable, Optional

from services import room_service

logger = logging.getLogger(__name__)

# Where a room number came from. The distinction is the whole reason
# regeneration can be non-destructive: we may revisit our own numbers and may
# not revisit the hotel's.
FROM_HOTEL = "hotel"
GENERATED = "generated"

# Hotels number rooms from a floor, not from one. 101 is the convention the
# feedback's own examples use. No longer asked for on screen: the numbers that
# matter come back from the hotel's own file, and an organizer who has to pick
# a starting integer before generating is being asked the wrong question.
DEFAULT_START = 101

# What somebody who never filled the room-type box gets booked as. This IS the
# question worth asking before a generation, because it is the one with an
# invoice attached: ninety singles and ninety doubles are not the same hotel
# bill. A declared type always wins over it.
DEFAULT_ROOM_TYPE = "single"
ROOM_TYPES = ("single", "double")

# A generated list larger than this is a mistake somewhere upstream, not an
# event. Refusing is kinder than emitting sixty thousand rooms.
MAX_ROOMS = 5000

# How many presets one event may keep (point 4). Not a technical ceiling —
# a hundred saved presets is a sign the list itself needs cleaning up, not a
# limit worth enforcing strictly, so this is generous rather than tight.
MAX_PRESETS = 50
_PREFIX_MAX_LEN = 8
_NAME_MAX_LEN = 60


class RoomingPlanError(ValueError):
    """The inputs cannot produce a list worth printing."""


def resolve_presets(stored: Any) -> list[dict[str, Any]]:
    """The event's saved numbering presets, with anything unusable dropped.

    A preset is nothing the planner does not already accept per call
    (prefix, default room type, and the start number that is no longer asked
    for on screen) — it exists purely so a collaborator does not retype
    "prefix B-, tout en double" every single time they open this event's
    rooming list. Stored on the event, not globally: the numbering a
    hotel wants is a property of that event's contract with that hotel, not
    a house style to carry into the next one.

    Malformed entries are skipped rather than rejecting the whole list: one
    bad preset (typed by hand in a console, say) must not take down every
    other saved one.
    """
    if not isinstance(stored, list):
        return []
    out: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for entry in stored[:MAX_PRESETS]:
        if not isinstance(entry, dict):
            continue
        name = str(entry.get("name") or "").strip()[:_NAME_MAX_LEN]
        if not name:
            continue
        try:
            start_number = int(entry.get("start_number"))
        except (TypeError, ValueError):
            continue
        if not 0 <= start_number <= 99999:
            continue
        prefix = str(entry.get("prefix") or "").strip()[:_PREFIX_MAX_LEN]
        room_type = str(entry.get("room_type") or "").strip().lower()
        if room_type not in ROOM_TYPES:
            # Presets saved before the option existed carry no type; they keep
            # working and mean "whatever the default is".
            room_type = DEFAULT_ROOM_TYPE
        preset_id = str(entry.get("id") or "").strip() or _new_preset_id()
        if preset_id in seen_ids:
            preset_id = _new_preset_id()
        seen_ids.add(preset_id)
        out.append({
            "id": preset_id, "name": name,
            "start_number": start_number, "prefix": prefix,
            "room_type": room_type,
        })
    return out


def _new_preset_id() -> str:
    import uuid
    return uuid.uuid4().hex[:12]


def _numbers_in_use(rooms: Iterable[dict[str, Any]]) -> dict[str, set[str]]:
    """Per hotel, the numbers already spoken for.

    Scoped by hotel because room 101 exists in every hotel on earth, and a two
    hotel event that shares one number pool wastes numbers and confuses
    everybody reading either list.
    """
    used: dict[str, set[str]] = {}
    for room in rooms:
        number = str(room.get("room_number") or "").strip()
        if number:
            used.setdefault(room.get("hotel_name") or "", set()).add(number)
    return used


def _occupant_ids(room: dict[str, Any]) -> frozenset[str]:
    return frozenset(o["participant_id"] for o in room.get("occupants") or [])


def previous_numbers(previous: Optional[dict[str, Any]]) -> dict[frozenset[str], str]:
    """The numbers a previous generation assigned, keyed by who was in the room.

    Keyed by the SET of occupants rather than by participant, so a number
    survives exactly as long as the room does. If Tina and Leslie stop sharing,
    neither of them inherits 304 — the room they were both in no longer exists,
    and handing the number to one of them silently would put the other in a
    room the printed list says is occupied.
    """
    if not previous:
        return {}
    out: dict[frozenset[str], str] = {}
    for room in previous.get("rooms") or []:
        if room.get("origin") != GENERATED:
            continue
        number = str(room.get("room_number") or "").strip()
        occupants = _occupant_ids(room)
        if number and occupants:
            out[occupants] = number
    return out


def _next_number(cursor: int, used: set[str], prefix: str) -> tuple[str, int]:
    """The next free number at or after ``cursor``, and where to resume."""
    while True:
        candidate = f"{prefix}{cursor}"
        cursor += 1
        if candidate not in used:
            used.add(candidate)
            return candidate, cursor


def plan(
    participants: list[dict[str, Any]],
    nights: Optional[Iterable[dict[str, Any]]] = None,
    *,
    previous: Optional[dict[str, Any]] = None,
    start_number: int = DEFAULT_START,
    prefix: str = "",
    renumber: bool = False,
    default_room_type: str = DEFAULT_ROOM_TYPE,
    hotel_names: Optional[dict[str, str]] = None,
) -> dict[str, Any]:
    """Build the rooming list this event's data implies.

    ``previous`` is the payload of the last generation, and passing it is what
    makes a second generation an update rather than a fresh start: a room whose
    occupants are unchanged keeps the number it was given.

    ``renumber=True`` drops every number we generated and lays them out again
    from ``start_number``. Numbers the hotel gave survive that too — the option
    tidies our own work, it does not overwrite theirs.

    ``default_room_type`` is what a participant who never answered the question
    is booked as. It is stored with the generation and replayed when staleness
    is checked, so a list generated as doubles does not read as stale merely
    because the check recomputed it as singles.

    Returns ``{"rooms", "participants", "summary", "fingerprint"}``. ``rooms``
    is ``room_service``'s shape plus an ``origin`` on each room, so a reader can
    always tell which numbers are ours to change.
    """
    rooms = room_service.occupancy(
        participants, nights,
        default_room_type=default_room_type, hotel_names=hotel_names,
    )
    if len(rooms) > MAX_ROOMS:
        raise RoomingPlanError(
            f"{len(rooms)} rooms is beyond what a rooming list can mean "
            f"(limit {MAX_ROOMS}); check the roommate links before generating."
        )

    inherited = {} if renumber else previous_numbers(previous)

    # Every number we have ever generated, by the room that held it. A
    # generation writes its numbers back onto the fiches, so on the next read
    # the fiche carries a number and looks — to a test that only asks "is
    # there a number here?" — exactly like a fiche the hotel numbered. Room 101
    # was `generated` in the stored version and `hotel` when re-derived a
    # second later, which made "Numéros de l'hôtel" report 81 on an event where
    # the hotel had given none, and would have made `renumber` refuse to
    # renumber anything at all, permanently.
    #
    # Read from `previous` unconditionally, unlike `inherited`: renumbering
    # changes which of our numbers a room keeps, never whether it was ours.
    ours = previous_numbers(previous)

    # Reserve, in this order: the numbers the hotel gave (immutable), then the
    # ones we are re-using from the previous generation. Assignment then fills
    # the gaps, so a cancellation frees its number for the next new room instead
    # of leaving a hole in the middle of the list forever.
    used = _numbers_in_use(rooms)
    for occupants, number in inherited.items():
        for room in rooms:
            if _occupant_ids(room) == occupants and not room["room_number"]:
                used.setdefault(room.get("hotel_name") or "", set()).add(number)
                break

    cursors: dict[str, int] = {}
    generated = 0

    for room in rooms:
        hotel = room.get("hotel_name") or ""
        if room["room_number"]:
            room["origin"] = (
                GENERATED if ours.get(_occupant_ids(room)) == room["room_number"]
                else FROM_HOTEL
            )
            continue

        occupants = _occupant_ids(room)
        number = inherited.get(occupants)
        if number is None:
            cursor = cursors.get(hotel, start_number)
            number, cursor = _next_number(cursor, used.setdefault(hotel, set()), prefix)
            cursors[hotel] = cursor
        room["room_number"] = number
        room["origin"] = GENERATED
        generated += 1

    # Rooms in a named hotel first, then the ones nobody has housed yet.
    # Sorting on the name alone put the empty string first, so a list opened
    # by a client began with twenty-one people who have no hotel and no dates —
    # the rows with the least to say leading the document.
    rooms.sort(key=lambda r: (
        not (r.get("hotel_name") or ""),
        r.get("hotel_name") or "",
        _sort_key(r["room_number"]),
    ))

    summary = dict(room_service.summarise(rooms))
    # Both are PROVENANCE counts, and together they account for every room.
    # `generated_numbers` used to count the numbers handed out on this run
    # instead — an action, not an origin — so the pair silently stopped adding
    # up the moment a second generation kept numbers it had assigned before.
    summary["generated_numbers"] = sum(1 for r in rooms if r["origin"] == GENERATED)
    summary["hotel_numbers"] = sum(1 for r in rooms if r["origin"] == FROM_HOTEL)
    # How many numbers this particular run had to invent. Useful for the "N
    # numéro(s) écrit(s) sur les fiches" line, and a different question.
    summary["newly_numbered"] = generated
    # Nothing is left unassigned once a list has been generated; the field stays
    # in the summary so the two views keep the same shape, and it reads 0.
    summary["unassigned"] = sum(1 for r in rooms if not r["room_number"])

    return {
        "rooms": rooms,
        "participants": room_service.participant_view(rooms),
        "summary": summary,
        "fingerprint": fingerprint(rooms),
    }


def _sort_key(number: str) -> tuple[int, str]:
    digits = "".join(ch for ch in number if ch.isdigit())
    return (int(digits) if digits else 0, number)


def fingerprint(rooms: list[dict[str, Any]]) -> str:
    """A short hash of what the list says.

    Recomputed on every read of the live data and compared with the one stored
    at generation time. Equal means the printed list is still true; different
    means somebody should look. It is deliberately computed over the OUTPUT
    rather than the inputs: two different inputs that produce the same rooming
    list are, for this purpose, the same event.
    """
    material = [
        [
            room.get("room_number") or "",
            room.get("room_type") or "",
            room.get("hotel_name") or "",
            room.get("check_in") or "",
            room.get("check_out") or "",
            sorted(o["participant_id"] for o in room.get("occupants") or []),
        ]
        for room in rooms
    ]
    material.sort(key=lambda row: (row[2], row[0], row[5]))
    blob = json.dumps(material, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]


def assignments(plan_payload: dict[str, Any]) -> dict[str, str]:
    """participant id -> the number this plan puts them in.

    Only the numbers we generated: the caller writes these back to the fiches,
    and writing back a number the hotel gave would be a no-op at best and, if
    the fiche has since been corrected, an overwrite of somebody's correction.
    """
    out: dict[str, str] = {}
    for room in plan_payload.get("rooms") or []:
        if room.get("origin") != GENERATED:
            continue
        for occupant in room.get("occupants") or []:
            out[occupant["participant_id"]] = room["room_number"]
    return out


def differences(
    previous: Optional[dict[str, Any]],
    current: dict[str, Any],
) -> list[dict[str, Any]]:
    """What regenerating would change, one line per person affected.

    This is what turns "Regenerate" from a leap into a decision. An organizer
    who has already sent the list to the hotel needs to know they are about to
    move four people, not to discover it when the hotel calls.

    A first generation has nothing to compare against and reports nothing: every
    line would say "new", which is true and useless.
    """
    if not previous or not (previous.get("rooms") or []):
        return []

    before = _by_participant(previous)
    after = _by_participant(current)
    changes: list[dict[str, Any]] = []

    for pid, now in after.items():
        was = before.get(pid)
        if was is None:
            changes.append({
                "participant_id": pid, "name": now["name"], "kind": "added",
                "from": "", "to": now["room_number"],
            })
            continue
        if was["room_number"] != now["room_number"]:
            changes.append({
                "participant_id": pid, "name": now["name"], "kind": "moved",
                "from": was["room_number"], "to": now["room_number"],
            })
        elif was["mates"] != now["mates"]:
            changes.append({
                "participant_id": pid, "name": now["name"], "kind": "roommate_changed",
                "from": ", ".join(sorted(was["mates"])),
                "to": ", ".join(sorted(now["mates"])),
            })
        elif was["hotel"] != now["hotel"]:
            # Same room number, different building. On a two-hotel event this
            # is the difference between a driver finding somebody and not.
            changes.append({
                "participant_id": pid, "name": now["name"], "kind": "hotel_changed",
                "from": was["hotel"], "to": now["hotel"],
            })
        elif was["type"] != now["type"]:
            changes.append({
                "participant_id": pid, "name": now["name"], "kind": "type_changed",
                "from": was["type"], "to": now["type"],
            })

    for pid, was in before.items():
        if pid not in after:
            changes.append({
                "participant_id": pid, "name": was["name"], "kind": "removed",
                "from": was["room_number"], "to": "",
            })

    order = {"removed": 0, "moved": 1, "roommate_changed": 2, "added": 3,
             "hotel_changed": 4, "type_changed": 5}
    return sorted(changes, key=lambda c: (order.get(c["kind"], 9), c["name"].lower()))


def _by_participant(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for room in payload.get("rooms") or []:
        names = {o["participant_id"]: o.get("name", "") for o in room.get("occupants") or []}
        for pid, name in names.items():
            out[pid] = {
                "name": name,
                "room_number": room.get("room_number") or "",
                "mates": frozenset(n for i, n in names.items() if i != pid),
                # Both are in the fingerprint, so both can make a list read
                # stale. Left out of the diff, the screen announced "les
                # données ont changé" and then listed nothing — which teaches
                # a reader to ignore the banner.
                "hotel": room.get("hotel_name") or "",
                "type": room.get("room_type") or "",
            }
    return out


def describe(changes: list[dict[str, Any]]) -> str:
    """One sentence an organizer can read before pressing the button."""
    if not changes:
        return "Aucun changement."
    counts: dict[str, int] = {}
    for change in changes:
        counts[change["kind"]] = counts.get(change["kind"], 0) + 1
    labels = {
        "added": "arrivée(s)",
        "removed": "départ(s)",
        "moved": "changement(s) de chambre",
        "roommate_changed": "changement(s) de binôme",
        "hotel_changed": "changement(s) d'hôtel",
        "type_changed": "changement(s) de type",
    }
    kinds = ("removed", "moved", "roommate_changed", "added", "hotel_changed", "type_changed")
    parts = [f"{counts[k]} {labels[k]}" for k in kinds if counts.get(k)]
    return ", ".join(parts) + "."
