"""
services/rooming_import.py — The hotel's own file, read back in.

The rooming list goes out to the hotel with our numbers on it. What comes back
three days later is *their* file, with *their* numbers: the hotel reallocated
two rooms, gave 304 to somebody else, and put our twin on the fourth floor.
Until now the only way to get those numbers into the system was to open ninety
fiches and retype them, which is exactly the kind of work this product exists
to remove.

So: read their file, match each line to a fiche, show what it would change, and
write it only once somebody has looked. Three rules shape the whole module.

  * **A number from the hotel is a fact, not a proposal.** Once written it is
    marked locked, and ``rooming_plan`` already refuses to renumber a room that
    carries one. Their file outranks our generation, always — they own the
    building.
  * **A line that does not match is reported, never guessed.** A name matching
    two fiches links to neither, exactly as ``rooming_service`` refuses an
    ambiguous roommate. "Which of these two Lins is in 304" is a question for a
    human with a phone, not for a scoring function.
  * **Nothing is written by the parse.** Reading the file and changing the data
    are two endpoints, because a hotel file with a shifted header row would
    otherwise silently move ninety people into the wrong rooms.

Pure module: bytes in, dicts out. No database, no clock — the same file always
produces the same proposal, which is what makes the preview worth trusting.
"""

from __future__ import annotations

import logging
import re
import unicodedata
from typing import Any, Iterable, Optional

from services import file_service

logger = logging.getLogger(__name__)

# A hotel file with more lines than this is not a rooming list; refusing is
# kinder than matching sixty thousand rows against every fiche in the event.
MAX_ROWS = 5000

_NUMBER_MAX_LEN = 20
_TYPE_MAX_LEN = 40

# What we call each status, and what it means for the caller:
#
#   matched    — one fiche, one number, and the number differs from the fiche's
#   unchanged  — one fiche, and it already carries exactly this number
#   ambiguous  — the name fits several fiches; refused rather than resolved
#   duplicate  — a line earlier in the file already claimed that fiche
#   unknown    — nobody in this event answers to that name or address
#   invalid    — the line carries no usable room number, or no name at all
MATCHED = "matched"
UNCHANGED = "unchanged"
AMBIGUOUS = "ambiguous"
DUPLICATE = "duplicate"
UNKNOWN = "unknown"
INVALID = "invalid"


class RoomingImportError(ValueError):
    """The file cannot be read as a rooming list."""


# ---------------------------------------------------------------------------
# Normalisation
# ---------------------------------------------------------------------------

def _norm(value: Any) -> str:
    """Lowercased, accent-stripped, punctuation-flattened.

    "N° de chambre", "N. de Chambre" and "n de chambre" are the same header
    written by three different people, and a header detector that treats them
    as three different columns is no detector at all.
    """
    text = unicodedata.normalize("NFD", str(value or ""))
    text = "".join(ch for ch in text if unicodedata.category(ch) != "Mn")
    text = re.sub(r"[^0-9a-zA-Z]+", " ", text.lower())
    return " ".join(text.split())


def _blank(value: Any) -> bool:
    return str(value or "").strip().lower() in ("", "nan", "none", "nat", "-", "n/a")


def name_key(first: Any, last: Any) -> str:
    """The identity key, matching the one consolidation dedupes on."""
    return _norm(f"{first or ''} {last or ''}")


def sorted_name_key(first: Any, last: Any) -> str:
    """The name key with its words sorted.

    A hotel file writes "BELL Tina"; the registration file wrote "Tina Bell".
    Which half landed in ``first_name`` is a property of the file, not of the
    person, so the ordered key alone would treat the two as strangers.
    """
    return " ".join(sorted(name_key(first, last).split()))


def clean_number(value: Any) -> str:
    """The room number as a hotel means it: a label, not an integer.

    Excel hands back "304.0" for a column it decided was numeric, and a driver
    knocking on "304.0" is a support call. Everything else — "B-12", "1204a",
    "Suite 3" — is kept exactly as typed, because it is the hotel's own name
    for a physical door.
    """
    if _blank(value):
        return ""
    text = str(value).strip()
    if re.fullmatch(r"\d+\.0+", text):
        text = text.split(".", 1)[0]
    return text[:_NUMBER_MAX_LEN]


_TYPE_ALIASES = (
    ("twin", "twin"),
    ("double", "double"),
    ("dbl", "double"),
    ("single", "single"),
    ("sgl", "single"),
    ("individuel", "single"),
    ("individual", "single"),
    ("triple", "triple"),
    ("suite", "suite"),
)


def clean_type(value: Any) -> str:
    """The file's word for the room, mapped onto ours where we recognise it.

    An unrecognised word is kept rather than dropped: "Deluxe King" means
    something to the hotel and nothing to us, and losing it would make the
    export we send back poorer than the file we read.
    """
    if _blank(value):
        return ""
    text = _norm(value)
    for token, canonical in _TYPE_ALIASES:
        if token in text:
            return canonical
    return str(value).strip()[:_TYPE_MAX_LEN]


# ---------------------------------------------------------------------------
# Column detection
# ---------------------------------------------------------------------------

# Exact header forms, tried first. Order inside a tuple does not matter; order
# BETWEEN the targets does, because the first target to claim a column keeps it.
_EXACT: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("email", ("email", "e mail", "mail", "courriel", "adresse email", "adresse e mail", "e mail adres")),
    ("first_name", ("prenom", "prenoms", "first name", "firstname", "given name", "voornaam")),
    ("full_name", (
        "nom complet", "full name", "name", "naam", "guest", "guest name", "guests",
        "client", "participant", "nom du participant", "nom du client", "passenger", "gast",
    )),
    ("last_name", ("nom", "noms", "last name", "lastname", "surname", "family name", "achternaam", "nom de famille")),
    ("room_type", ("type", "type de chambre", "type chambre", "room type", "type of room", "kamertype", "categorie", "categorie de chambre")),
    ("room_number", (
        "chambre", "n chambre", "no chambre", "num chambre", "numero de chambre",
        "numero chambre", "n de chambre", "no de chambre", "room", "room number",
        "room no", "room nr", "roomnumber", "roomno", "kamer", "kamernummer", "kamer nr",
    )),
)

# Substring fallbacks for headers nobody claimed exactly — "Room # (final)",
# "Nom du voyageur", "Adresse e-mail pro". Deliberately narrower than the exact
# list: a wrong column here silently rewrites ninety room numbers.
_SUBSTRING: tuple[tuple[str, tuple[str, ...], tuple[str, ...]], ...] = (
    # (target, hints, disqualifiers)
    ("email", ("mail",), ()),
    ("first_name", ("prenom", "first", "voornaam"), ()),
    ("last_name", ("last", "surname", "achternaam", "nom"), ("prenom",)),
    ("full_name", ("name", "naam", "guest", "participant", "voyageur"), ("first", "last", "sur")),
    ("room_type", ("type", "categorie"), ()),
    ("room_number", ("chambre", "room", "kamer"), ("type", "categorie")),
)


def detect_columns(columns: Iterable[Any]) -> dict[str, str]:
    """Which column holds what, by header name.

    Returns a target -> original column-name map, and the caller is expected to
    show it: a hotel file whose "Room" column turned out to be "Room service"
    must be visible as a wrong guess before anything is written, not discovered
    afterwards in the numbers.
    """
    headers = [str(c) for c in columns]
    normalised = {header: _norm(header) for header in headers}
    claimed: set[str] = set()
    found: dict[str, str] = {}

    for target, forms in _EXACT:
        for header in headers:
            if header in claimed:
                continue
            if normalised[header] in forms:
                found[target] = header
                claimed.add(header)
                break

    for target, hints, disqualifiers in _SUBSTRING:
        if target in found:
            continue
        for header in headers:
            if header in claimed:
                continue
            text = normalised[header]
            if any(bad in text for bad in disqualifiers):
                continue
            if any(hint in text for hint in hints):
                found[target] = header
                claimed.add(header)
                break

    return found


def _split_full_name(value: str) -> tuple[str, str]:
    """"BELL Tina" or "Tina Bell" into two halves.

    Which half is which is not decidable from the string, and this module does
    not try: matching runs on the sorted key as well as the ordered one, so
    both readings find the same fiche.
    """
    parts = str(value or "").strip().split()
    if len(parts) < 2:
        return (str(value or "").strip(), "")
    return (" ".join(parts[:-1]), parts[-1])


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

def read_file(raw: bytes, filename: str) -> tuple[list[dict[str, Any]], dict[str, str]]:
    """The hotel's file as rows plus the column map that produced them.

    Rows keep their 1-based position in the file. When the preview says line 47
    could not be matched, somebody has to be able to open the file and look at
    line 47.
    """
    df = file_service.read_tabular(raw, filename)
    if df is None or df.empty:
        raise RoomingImportError("Le fichier ne contient aucune ligne exploitable.")

    mapping = detect_columns(df.columns)
    if "room_number" not in mapping:
        raise RoomingImportError(
            "Aucune colonne de numéro de chambre trouvée. "
            "Attendu une colonne « Chambre », « N° de chambre » ou « Room number »."
        )
    if not ({"full_name", "last_name", "email"} & set(mapping)):
        raise RoomingImportError(
            "Aucune colonne de nom ou d'e-mail trouvée : impossible de savoir "
            "à qui attribuer les chambres."
        )

    rows: list[dict[str, Any]] = []
    for position, (_, record) in enumerate(df.iterrows(), start=2):
        if len(rows) >= MAX_ROWS:
            break

        def cell(target: str) -> Any:
            column = mapping.get(target)
            return record.get(column) if column else None

        def text(target: str) -> str:
            """A cell as a name, or nothing.

            Goes through ``_blank`` like every other field: pandas str-casts an
            empty cell to "nan", and reading it raw produced a preview line for
            a guest called nan — matched to the right person by email, and
            unrecognisable to whoever had to check the list.
            """
            value = cell(target)
            return "" if _blank(value) else str(value).strip()

        first = text("first_name")
        last = text("last_name")
        if not (first or last):
            first, last = _split_full_name(text("full_name"))

        row = {
            "row": position,
            "first_name": first,
            "last_name": last,
            "email": text("email").lower(),
            "room_number": clean_number(cell("room_number")),
            "room_type": clean_type(cell("room_type")),
        }
        if not (row["first_name"] or row["last_name"] or row["email"] or row["room_number"]):
            continue  # a spacer line, not a guest
        rows.append(row)

    if not rows:
        raise RoomingImportError("Le fichier ne contient aucune ligne exploitable.")
    return rows, mapping


# ---------------------------------------------------------------------------
# Matching
# ---------------------------------------------------------------------------

def _index(participants: Iterable[dict[str, Any]]) -> tuple[dict, dict, dict]:
    by_email: dict[str, list[dict]] = {}
    by_name: dict[str, list[dict]] = {}
    by_sorted: dict[str, list[dict]] = {}
    for person in participants:
        if not person.get("id"):
            continue
        email = str(person.get("email") or "").strip().lower()
        if email:
            by_email.setdefault(email, []).append(person)
        key = name_key(person.get("first_name"), person.get("last_name"))
        if key:
            by_name.setdefault(key, []).append(person)
            by_sorted.setdefault(" ".join(sorted(key.split())), []).append(person)
    return by_email, by_name, by_sorted


def _display(person: dict[str, Any]) -> str:
    return " ".join(
        part for part in (person.get("first_name"), person.get("last_name")) if part
    ).strip()


def match(
    rows: list[dict[str, Any]],
    participants: list[dict[str, Any]],
) -> dict[str, Any]:
    """One decision per line of the file, and a count of each kind.

    A fiche is claimed at most once. Two lines naming the same person — the
    hotel listing both nights of a split stay, say — would otherwise both
    report as writable and the second would silently overwrite the first.
    """
    by_email, by_name, by_sorted = _index(participants)
    taken: set[str] = set()
    lines: list[dict[str, Any]] = []

    for row in rows:
        written = str(row.get("room_number") or "").strip()
        label = " ".join(p for p in (row["first_name"], row["last_name"]) if p).strip()
        line = {
            "row": row["row"],
            "name": label,
            "email": row["email"],
            "room_number": written,
            "room_type": row["room_type"],
            "status": INVALID,
            "participant_id": "",
            "participant_name": "",
            "current_number": "",
        }

        if not written or not (label or row["email"]):
            lines.append(line)
            continue

        candidates: list[dict[str, Any]] = []
        if row["email"]:
            candidates = by_email.get(row["email"], [])
        if not candidates and label:
            key = name_key(row["first_name"], row["last_name"])
            candidates = by_name.get(key) or by_sorted.get(" ".join(sorted(key.split()))) or []

        # A fiche already claimed by an earlier line is not a candidate for
        # this one; if that leaves none, the line is a duplicate, not a match.
        free = [p for p in candidates if p["id"] not in taken]

        if len(free) > 1:
            line["status"] = AMBIGUOUS
            line["participant_name"] = ", ".join(_display(p) for p in free[:3])
        elif len(free) == 1:
            person = free[0]
            taken.add(person["id"])
            line["participant_id"] = person["id"]
            line["participant_name"] = _display(person)
            line["current_number"] = str(person.get("room_number") or "").strip()
            same_number = line["current_number"] == written
            same_type = (
                not row["room_type"]
                or str(person.get("room_type") or "").strip().lower() == row["room_type"].lower()
            )
            line["status"] = UNCHANGED if (same_number and same_type) else MATCHED
        elif candidates:
            # The fiche exists but an earlier line already spoke for it: the
            # file names the same person twice. Reported, not silently
            # overwritten — the two lines may well disagree about the number.
            line["status"] = DUPLICATE
            line["participant_name"] = _display(candidates[0])
        else:
            line["status"] = UNKNOWN

        lines.append(line)

    summary = {
        status: sum(1 for line in lines if line["status"] == status)
        for status in (MATCHED, UNCHANGED, AMBIGUOUS, DUPLICATE, UNKNOWN, INVALID)
    }
    summary["rows"] = len(lines)
    return {"lines": lines, "summary": summary}


def describe(summary: dict[str, Any]) -> str:
    """One sentence for the button: what pressing Apply would do."""
    parts: list[str] = []
    if summary.get(MATCHED):
        parts.append(f"{summary[MATCHED]} chambre(s) à écrire")
    if summary.get(UNCHANGED):
        parts.append(f"{summary[UNCHANGED]} déjà à jour")
    if summary.get(AMBIGUOUS):
        parts.append(f"{summary[AMBIGUOUS]} ambiguë(s)")
    if summary.get(DUPLICATE):
        parts.append(f"{summary[DUPLICATE]} doublon(s)")
    if summary.get(UNKNOWN):
        parts.append(f"{summary[UNKNOWN]} participant(s) introuvable(s)")
    if summary.get(INVALID):
        parts.append(f"{summary[INVALID]} ligne(s) inexploitable(s)")
    return ", ".join(parts) or "Rien à importer."
