"""
services/dashboard_service.py — Everything the dashboard shows, computed once.

The dashboard used to assemble itself from four calls and fill the gaps with
guesses: the "Comms" slice of its distribution chart was the literal constant
90, shown as data on every event. Nothing else on that page could be trusted
more than its weakest number, so the numbers are all computed here now, and a
figure that cannot be computed is returned as null for the UI to omit rather
than invented.

Three things the page was missing entirely, all of them from data the database
already held:

  * **Time.** 64 % of transfers booked is fine at D-90 and a crisis at D-5.
    The event's start date was never on the page, so every rate was read
    without the one thing that gives it meaning.
  * **Movement.** Every consolidation writes its stats into
    consolidation_runs.stats with a timestamp. That history was stored and
    never shown: an organizer could not tell whether they were gaining on the
    gaps or losing to them.
  * **Segments.** "Which company still hasn't sent its list" is a daily
    question on a corporate event, and `company` sat in the master list
    unaggregated.

The ranked priorities come from the assistant's own ranking function, not a
second copy of it — the dashboard and the assistant must never disagree about
what matters most.
"""

from __future__ import annotations

import logging
from datetime import date, datetime, timedelta, timezone
from typing import Any, Optional

from supabase import Client

from services import exception_service, field_policy, parallel
from services.chatbot_service import (
    SNAPSHOT_PARTICIPANT_COLS,
    event_snapshot,
    ranked_findings,
)

logger = logging.getLogger(__name__)

# Same threshold as the UI's "en retard" badge (apps/web/src/lib/alerts.ts).
OVERDUE_AFTER = timedelta(hours=24)

# How many past runs the trend line covers. Enough to see a direction, few
# enough to stay readable on a card.
TREND_RUNS = 10

_COVERAGE_FLAGS = ("has_flight", "has_hotel", "has_transfer", "has_activities")

# Run stats that describe the STATE of the event after a run, and can therefore
# be subtracted from one another to mean something.
#
# Most keys in `stats` are per-run COUNTERS — participants_created,
# matched_certain, stale_records_purged. Differencing those is nonsense: a run
# that created 13 fiches followed by one that created none gives 0 - 13, and
# the dashboard proudly announced "-13 nouveaux participants" (production,
# 2026-08-12). Only what is a running total belongs here.
STATE_METRICS = ("participants_total", "exceptions_count")


def _participants(supabase: Client, event_id: str) -> list[dict[str, Any]]:
    """One read of the columns every block below needs. PostgREST caps a
    select at 1000 rows, hence the paging.

    The column list comes from chatbot_service, not from here: this same list
    is handed to event_snapshot(), and a field the snapshot reads but this
    select omits does not read as "unknown" — it reads as "missing on every
    single participant".
    """
    out: list[dict[str, Any]] = []
    offset = 0
    while True:
        res = (
            supabase.table("participants")
            .select(SNAPSHOT_PARTICIPANT_COLS)
            .eq("event_id", event_id)
            .range(offset, offset + 999)
            .execute()
        )
        rows = res.data or []
        out.extend(rows)
        if len(rows) < 1000:
            break
        offset += 1000
    return out


def _alerts(supabase: Client, event_id: str) -> dict[str, Any]:
    """Open alerts, and how many stopped moving.

    An alert nobody has touched for a day is the one that needs a name: a
    running total reads the same on day one and day five.
    """
    try:
        rows = (
            supabase.table("exceptions")
            # context_data comes along so the policy can be applied: a run from
            # before a field was made optional still holds its cards, and this
            # block would otherwise count them long after the page stopped
            # showing them.
            .select(exception_service.READ_COLUMNS)
            .eq("event_id", event_id)
            .eq("resolved", False)
            .execute()
        ).data or []
        rows = exception_service.visible(
            rows,
            field_policy.for_event(supabase, event_id),
            exception_service.fetch_answered(supabase, event_id),
        )
    except Exception as exc:
        logger.warning("Dashboard alerts unavailable for %s: %s", event_id, exc)
        return {"open": None, "overdue": None, "critical": None, "oldest_age_hours": None}

    now = datetime.now(timezone.utc)
    cutoff = now - OVERDUE_AFTER
    overdue = 0
    oldest_age_hours = 0
    for r in rows:
        raw = str(r.get("created_at") or "")
        try:
            created = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        except ValueError:
            continue                      # never guess an age
        if created.tzinfo is None:
            created = created.replace(tzinfo=timezone.utc)
        if created < cutoff:
            overdue += 1
        age = int((now - created).total_seconds() // 3600)
        oldest_age_hours = max(oldest_age_hours, age)

    return {
        "open": len(rows),
        "overdue": overdue,
        "critical": sum(1 for r in rows if r.get("severity") == "critical"),
        "oldest_age_hours": oldest_age_hours,
    }


def _communications(supabase: Client, event_id: str, total: int) -> dict[str, Any]:
    """How many participants have actually been written to.

    Returns None rather than a number when the communications table is not
    deployed on this instance — the chart drops the slice instead of showing
    the invented 90 % it used to.
    """
    try:
        rows = (
            supabase.table("communications")
            .select("participant_id, status")
            .eq("event_id", event_id)
            .eq("status", "sent")
            .execute()
        ).data or []
    except Exception:
        return {"participants_contacted": None, "pct": None}

    contacted = len({r["participant_id"] for r in rows if r.get("participant_id")})
    return {
        "participants_contacted": contacted,
        "pct": round(100 * contacted / total) if total else 0,
    }


def _registrations(supabase: Client, event_id: str) -> Optional[int]:
    """Responses to the public form — the number an organizer refreshes every
    hour during a registration wave, and which only lived on the form page."""
    try:
        files = (
            supabase.table("uploaded_files")
            .select("id")
            .eq("event_id", event_id)
            .eq("storage_path", f"public-form/{event_id}")
            .execute()
        ).data or []
        total = 0
        for f in files:
            counted = (
                supabase.table("source_records")
                .select("id", count="exact")
                .eq("file_id", f["id"])
                .limit(1)
                .execute()
            )
            total += counted.count or 0
        return total
    except Exception as exc:
        logger.warning("Registration count unavailable for %s: %s", event_id, exc)
        return None


def _trend(supabase: Client, event_id: str) -> dict[str, Any]:
    """The stats every consolidation has been writing all along.

    ``stats`` is a free-form JSONB written by consolidation_service, so each
    point is filtered down to the keys that are actually integers — a run from
    an older version simply contributes fewer series rather than breaking the
    chart.
    """
    try:
        runs = (
            supabase.table("consolidation_runs")
            .select("id, started_at, completed_at, status, stats")
            .eq("event_id", event_id)
            .eq("status", "completed")
            .order("started_at", desc=True)
            .limit(TREND_RUNS)
            .execute()
        ).data or []
    except Exception as exc:
        logger.warning("Trend unavailable for %s: %s", event_id, exc)
        return {"points": [], "delta": None}

    points = []
    for r in reversed(runs):                       # oldest first, for a chart
        stats = r.get("stats") if isinstance(r.get("stats"), dict) else {}
        points.append({
            "at": r.get("completed_at") or r.get("started_at"),
            "stats": {k: v for k, v in stats.items() if isinstance(v, int)},
        })

    return {"points": points, "delta": _delta(points)}


def _delta(points: list[dict[str, Any]]) -> Optional[dict[str, Any]]:
    """What changed since roughly a day ago — not since the previous run.

    Comparing the last two runs looked right until you consolidate three times
    in an hour: the "progress" then covers four minutes and reads as zero.
    The baseline is the most recent run at least ~20 h old, so the number
    answers "où en étais-je hier ?". With no run that old (a young event, or
    one consolidated once a week), it falls back to the previous run and says
    so through `since`, which the UI displays.
    """
    if len(points) < 2:
        return None
    latest = points[-1]
    threshold = datetime.now(timezone.utc) - timedelta(hours=20)

    baseline = None
    for point in reversed(points[:-1]):
        at = point.get("at")
        try:
            when = datetime.fromisoformat(str(at).replace("Z", "+00:00"))
        except ValueError:
            continue
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        if when <= threshold:
            baseline = point
            break
    if baseline is None:
        baseline = points[-2]

    before, after = baseline["stats"], latest["stats"]
    return {
        "since": baseline["at"],
        "changes": {
            k: after[k] - before[k]
            for k in STATE_METRICS
            if k in after and k in before and after[k] != before[k]
        },
    }


def _by_company(people: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Per-company gaps, worst first — "who still owes us their list"."""
    buckets: dict[str, dict[str, int]] = {}
    for p in people:
        name = str(p.get("company") or "").strip() or "—"
        b = buckets.setdefault(name, {
            "participants": 0, "without_flight": 0, "without_hotel": 0,
            "without_transfer": 0, "incomplete": 0,
        })
        b["participants"] += 1
        if not p.get("has_flight"):
            b["without_flight"] += 1
        if not p.get("has_hotel"):
            b["without_hotel"] += 1
        if not p.get("has_transfer"):
            b["without_transfer"] += 1
        if p.get("completeness_status") != "complete":
            b["incomplete"] += 1

    rows = [{"company": name, **counts} for name, counts in buckets.items()]
    rows.sort(
        key=lambda r: (
            -(r["without_flight"] + r["without_hotel"] + r["without_transfer"] + r["incomplete"]),
            -r["participants"],
            r["company"],
        )
    )
    return rows


def build_dashboard(supabase: Client, event_id: str) -> dict[str, Any]:
    people = _participants(supabase, event_id)
    total = len(people)

    # Four blocks that share nothing but the participant count, plus the
    # snapshot the priorities are ranked from. Sequentially they were four
    # round trips to Supabase stacked behind each other for a page that renders
    # all of them at once; started together they cost the slowest one.
    blocks = parallel.gather({
        "snapshot": lambda: event_snapshot(event_id, supabase, people),
        "communications": lambda: _communications(supabase, event_id, total),
        "registrations": lambda: _registrations(supabase, event_id),
        "alerts": lambda: _alerts(supabase, event_id),
        "trend": lambda: _trend(supabase, event_id),
    }, label=f"dashboard {event_id}")

    snapshot = blocks["snapshot"] or {}
    event_info = snapshot.get("evenement") or {}
    days_until_start = event_info.get("jours_avant_le_debut")

    coverage: dict[str, Any] = {}
    for flag in _COVERAGE_FLAGS:
        covered = sum(1 for p in people if p.get(flag))
        coverage[flag] = {
            "with": covered,
            "without": total - covered,
            "pct": round(100 * covered / total) if total else 0,
        }

    complete = sum(1 for p in people if p.get("completeness_status") == "complete")

    return {
        "event": {
            "name": event_info.get("name"),
            "start_date": event_info.get("start_date"),
            "end_date": event_info.get("end_date"),
            "location_city": event_info.get("location_city"),
            "days_until_start": days_until_start,
            "generated_on": date.today().isoformat(),
        },
        "participants": {
            "total": total,
            "complete": complete,
            "completeness_pct": round(100 * complete / total) if total else 0,
        },
        "coverage": coverage,
        # `or` rather than a bare read: a block whose table is not there yet
        # returns None from the gather, and the page renders without it exactly
        # as it did when each of these had its own try/except inline.
        "communications": blocks["communications"] or {},
        "registrations": {"submissions": blocks["registrations"]},
        "alerts": blocks["alerts"] or {},
        "trend": blocks["trend"] or {},
        # Same ranking the assistant reasons with, on purpose: the page and the
        # answer must never disagree about what matters most.
        # The same policy the advice list and the quality score follow, so
        # the two lists on this screen cannot answer the same question
        # differently.
        "priorities": ranked_findings(snapshot, field_policy.for_event(supabase, event_id)),
        "companies": _by_company(people),
    }
