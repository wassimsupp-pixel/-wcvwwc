"""
services/field_policy.py — What each event actually needs to know about its
participants, and therefore what counts as a gap.

The detectors used to decide on their own that a missing nationality was worth
an alert. On an event that never needed nationality that produced one alert per
participant — 150 cards saying nothing, in the one panel an organizer reads
first (feedback §10). The fix is not a better heuristic: it is asking the
organizer once, at project level, and letting every downstream consumer read
the answer.

Three states, not two booleans:

  * ``required``  — the event needs it. A blank value is a gap: it raises an
    exception and it weighs on the completeness score.
  * ``optional``  — nice to have. Stored and displayed, never alerted on, never
    scored.
  * ``not_used``  — this event does not collect it at all. Invisible to the
    exception engine and to the score. It is NOT erased: a value arriving from
    a source file is still stored and still shown on the fiche, because
    throwing data away would break the engine's first promise.

The distinction between ``optional`` and ``not_used`` matters for the score,
not just for alerts: a dimension nobody uses must not drag an event's quality
down, so it is dropped from the weighting entirely and the remaining weights
are renormalised.

**Defaults reproduce today's behaviour exactly.** An event with no stored
policy — every event that predates this feature, and any deployment where
migration 008 has not run — resolves to the fields the detectors already
alerted on being ``required`` and everything else ``optional``. Nothing changes
until somebody deliberately configures it.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

REQUIRED = "required"
OPTIONAL = "optional"
NOT_USED = "not_used"

_STATES = (REQUIRED, OPTIONAL, NOT_USED)

# key -> (French label, section, default state)
#
# The defaults are not a design opinion, they are a compatibility contract:
# every key the exception engine already alerts on defaults to `required`, so
# an unconfigured event behaves exactly as it did before this module existed.
_CATALOGUE: tuple[tuple[str, str, str, str], ...] = (
    # Identity
    ("first_name",              "Prénom",                     "Identité",      REQUIRED),
    ("email",                   "Adresse email",              "Identité",      REQUIRED),
    ("phone",                   "Téléphone",                  "Identité",      REQUIRED),
    ("nationality",             "Nationalité",                "Identité",      REQUIRED),
    ("company",                 "Société",                    "Identité",      OPTIONAL),
    ("job_title",               "Fonction / Poste",           "Identité",      OPTIONAL),
    ("badge_name",              "Nom sur badge",              "Identité",      OPTIONAL),
    ("date_of_birth",           "Date de naissance",          "Identité",      OPTIONAL),
    # Travel documents.
    #
    # passport_number defaults to `required` for one reason only: it is one of
    # the six dimensions of the data-quality score today, weighted at 15%.
    # Defaulting it to `optional` would silently drop it from the score and
    # move every unconfigured event's number, which is precisely the kind of
    # unannounced change this default set exists to prevent. A city conference
    # that never asks for a passport turns it off once, in Settings, and that
    # is the feature working as intended.
    ("passport_number",         "Numéro de passeport",        "Voyage",        REQUIRED),
    ("passport_expiry",         "Expiration du passeport",    "Voyage",        OPTIONAL),
    # A return flight is OPTIONAL, and for the same reason the diet is: its
    # absence is usually the answer, not a hole. People extend their stay at
    # their own expense, continue somewhere else, or fly home on a ticket that
    # was never ours to see. Gated on `flight` — which every event requires —
    # it fired on all of those, and on the live event two of its five cards
    # were flatly false: a participant reported as having no way home while
    # holding a booking for the 9th, and another whose single segment WAS the
    # return.
    #
    # A chartered group that really does fly home together turns it on, and
    # then a one-way booking IS worth a question.
    ("return_flight",           "Vol retour",                 "Voyage",        OPTIONAL),
    # Stay
    #
    # dietary_requirements is OPTIONAL, and that is the whole point of it. A
    # blank diet is not a hole in the file, it is the answer: most people eat
    # everything. Defaulting it to `required` turned that answer into an
    # anomaly — 69 exceptions out of 82 participants on one live event, 98 out
    # of 105 on another, 236 cards in total whose only content was "this
    # person has no dietary restriction". A page where five sixths of the
    # alerts are normal is a page nobody reads, and the six real problems
    # underneath were buried by it.
    #
    # An event with a plated dinner that truly needs everyone's answer turns
    # it on in the field policy, and then a blank IS a gap.
    ("dietary_requirements",    "Régime alimentaire",         "Séjour",        OPTIONAL),
    ("room_preference",         "Préférences de chambre",     "Séjour",        OPTIONAL),
    ("roommate",                "Roommate",                   "Séjour",        OPTIONAL),
    ("pmr_needs",               "Besoins d'accessibilité",    "Séjour",        OPTIONAL),
    ("emergency_contact_name",  "Contact d'urgence (nom)",    "Séjour",        OPTIONAL),
    ("emergency_contact_phone", "Contact d'urgence (tél.)",   "Séjour",        OPTIONAL),
    # Services — these gate the aggregate "N participants without X" cards
    ("flight",                  "Vol",                        "Logistique",    REQUIRED),
    ("hotel",                   "Hébergement",                "Logistique",    REQUIRED),
    ("transfer",                "Transfert",                  "Logistique",    REQUIRED),
    ("activity",                "Activités",                  "Logistique",    OPTIONAL),
)

FIELD_KEYS: tuple[str, ...] = tuple(key for key, _, _, _ in _CATALOGUE)
_DEFAULTS: dict[str, str] = {key: state for key, _, _, state in _CATALOGUE}
_LABELS: dict[str, str] = {key: label for key, label, _, _ in _CATALOGUE}


def resolve(stored: Any) -> dict[str, str]:
    """The policy for every known key, with the event's choices applied.

    ``stored`` is whatever sits in ``events.field_policy`` — including None, a
    shape written by an older version, or something hand-edited in the Supabase
    console. An unrecognised value falls back to that field's default rather
    than raising: a malformed policy must never take consolidation down.
    """
    config = stored if isinstance(stored, dict) else {}
    out: dict[str, str] = {}
    for key in FIELD_KEYS:
        raw = config.get(key)
        # Accept both the bare string form ({"phone": "required"}) and the
        # object form ({"phone": {"state": "required"}}) so the UI can grow a
        # richer per-field object later without a data migration.
        if isinstance(raw, dict):
            raw = raw.get("state")
        out[key] = raw if raw in _STATES else _DEFAULTS[key]
    return out


def sanitize(payload: Any) -> dict[str, str]:
    """The policy as it may be stored: known keys only, valid states only.

    Written by an authenticated organizer, but it drives what the engine
    reports on every run — so it is filtered against the catalogue on the way
    in rather than trusted on the way out.
    """
    return resolve(payload)


def is_tracked(policy: dict[str, str], key: str) -> bool:
    """False only for ``not_used`` — the event does not collect this at all."""
    return policy.get(key, _DEFAULTS.get(key, OPTIONAL)) != NOT_USED


def is_required(policy: dict[str, str], key: str) -> bool:
    """True when a blank value is a genuine gap for this event."""
    return policy.get(key, _DEFAULTS.get(key, OPTIONAL)) == REQUIRED


def required_keys(policy: dict[str, str], candidates: tuple[str, ...]) -> list[str]:
    """The subset of ``candidates`` this event actually insists on, in order."""
    return [k for k in candidates if is_required(policy, k)]


def label(key: str) -> str:
    return _LABELS.get(key, key)


def describe() -> list[dict[str, str]]:
    """The catalogue, for the settings UI: key, label, section, default."""
    return [
        {"key": key, "label": lbl, "group": group, "default": state}
        for key, lbl, group, state in _CATALOGUE
    ]


def fetch(supabase: Any, event_id: str) -> Optional[dict[str, Any]]:
    """Read an event's stored policy, or None.

    None covers three cases that mean the same thing to every caller: never
    configured, configured as null, or migration 008 not applied on this
    deployment (the column does not exist and PostgREST errors on the select).
    """
    try:
        resp = (
            supabase.table("events")
            .select("field_policy")
            .eq("id", event_id)
            .limit(1)
            .execute()
        )
    except Exception as exc:
        logger.debug("field_policy unavailable for event %s (%s) — using defaults", event_id, exc)
        return None
    rows = resp.data or []
    if not rows:
        return None
    stored = rows[0].get("field_policy")
    return stored if isinstance(stored, dict) else None


def for_event(supabase: Any, event_id: str) -> dict[str, str]:
    """The resolved policy for an event — never raises, never returns empty."""
    return resolve(fetch(supabase, event_id))
