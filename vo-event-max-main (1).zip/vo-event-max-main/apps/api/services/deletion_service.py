# -*- coding: utf-8 -*-
"""
deletion_service.py
===================
Cascade deletion of events and projects.

Most foreign keys to ``events(id)`` in the schema do **not** declare
``ON DELETE CASCADE``, so a raw ``DELETE`` on the event row would fail with a
foreign-key violation. This service deletes all dependent rows in dependency
order (children first) before removing the event itself.

Deletion order for an event
---------------------------
1. Junction/grandchild tables keyed by participant/activity/hotel ids
   (``participant_activities``, ``hotel_nights``).
2. Event-scoped tables referencing participants / runs / source_records
   (``exceptions``, ``exports``, ``email_proposals``, ``flights``,
   ``transfers``, ``change_log``).
3. ``consolidation_runs`` (referenced by exceptions/exports, now gone).
4. ``activities`` and ``hotels`` (their junction rows are gone).
5. Break the circular FK between ``participants`` and ``source_records``: null
   ``participants.registration_source_id`` / ``fcm_source_id`` so source_records
   can go first.
6. ``source_records`` (participant links nulled, exceptions gone).
7. ``participants``.
8. Storage objects, then ``uploaded_files``.
9. The ``events`` row itself.
"""

from __future__ import annotations

import logging

from supabase import Client

import config

logger = logging.getLogger(__name__)

# Keep `IN (...)` id-lists small: PostgREST rejects over-long request URLs
# (a 1000-UUID list ≈ 37 KB → 400 "Bad Request"). 100 keeps URLs well under limits.
_CHUNK = 100


def _ids(supabase: Client, table: str, filter_col: str, filter_val: str) -> list[str]:
    """Return ALL ``id`` values of rows in *table* matching filter.

    PostgREST caps a single response at ~1000 rows, so we must paginate — a
    partial id list would leave rows behind and break FK-ordered deletes.
    """
    ids: list[str] = []
    page_size = 1000
    offset = 0
    while True:
        res = (
            supabase.table(table)
            .select("id")
            .eq(filter_col, filter_val)
            .range(offset, offset + page_size - 1)
            .execute()
        )
        data = res.data or []
        ids.extend(row["id"] for row in data)
        if len(data) < page_size:
            break
        offset += page_size
    return ids


def _delete_in(supabase: Client, table: str, col: str, ids: list[str], chunk_size: int = _CHUNK) -> None:
    """Delete rows of *table* where *col* is in *ids* (chunked, no-op if empty)."""
    for i in range(0, len(ids), chunk_size):
        chunk = ids[i : i + chunk_size]
        supabase.table(table).delete().in_(col, chunk).execute()


def _remove_event_storage(supabase: Client, event_id: str) -> None:
    """Best-effort removal of Storage objects for an event's uploaded files."""
    res = (
        supabase.table("uploaded_files")
        .select("storage_path")
        .eq("event_id", event_id)
        .execute()
    )
    paths = [row["storage_path"] for row in (res.data or []) if row.get("storage_path")]
    if not paths:
        return
    try:
        supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).remove(paths)
    except Exception as exc:  # storage cleanup is best-effort; never block the DB delete
        logger.warning("Storage removal during event delete failed: %s", exc)


def _export_storage_paths(supabase: Client, event_id: str) -> list[str]:
    """Storage keys of an event's exports, read while the rows still exist."""
    try:
        res = (
            supabase.table("exports")
            .select("storage_path")
            .eq("event_id", event_id)
            .execute()
        )
    except Exception as exc:
        logger.warning("Could not list export paths for %s: %s", event_id, exc)
        return []
    return [r["storage_path"] for r in (res.data or []) if r.get("storage_path")]


def _remove_export_storage(supabase: Client, paths: list[str], event_id: str) -> None:
    """Delete an event's export objects, registered ones and regenerated ones.

    The rows only ever named the original file. A download by anybody below
    admin/pm writes a second, role-redacted copy under
    ``…/{export_id}/redacted-{role}-{uuid}/`` that no row has ever pointed at,
    so the prefix has to be swept as well — otherwise the redacted copies, which
    hold the same people, outlive the event that justified them.
    """
    keys = list(paths)
    keys.extend(_storage_keys_under(supabase, f"exports/{event_id}"))
    keys = list(dict.fromkeys(k for k in keys if k))
    if not keys:
        return
    for i in range(0, len(keys), _CHUNK):
        try:
            supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).remove(keys[i : i + _CHUNK])
        except Exception as exc:  # best-effort; never blocks the DB delete
            logger.warning("Export storage removal failed: %s", exc)


# How deep the sweep walks below `exports/{event_id}`: the export_id folder,
# then a possible `redacted-…` folder, then the file. Bounded rather than
# unbounded so a surprising layout cannot turn a delete into a crawl.
_SWEEP_DEPTH = 3


def _storage_keys_under(supabase: Client, prefix: str, depth: int = _SWEEP_DEPTH) -> list[str]:
    """Every object key below *prefix*. Folders have no id; files do."""
    if depth <= 0:
        return []
    try:
        entries = supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).list(prefix)
    except Exception as exc:
        logger.warning("Could not list storage under %s: %s", prefix, exc)
        return []
    keys: list[str] = []
    for entry in entries or []:
        name = (entry or {}).get("name")
        if not name:
            continue
        child = f"{prefix}/{name}"
        if entry.get("id"):
            keys.append(child)
        else:
            keys.extend(_storage_keys_under(supabase, child, depth - 1))
    return keys


def delete_event(supabase: Client, event_id: str) -> None:
    """Delete an event and every row that depends on it (see module docstring)."""
    eid = str(event_id)

    # Parent ids needed for junction tables that have no event_id column.
    participant_ids = _ids(supabase, "participants", "event_id", eid)
    activity_ids = _ids(supabase, "activities", "event_id", eid)
    hotel_ids = _ids(supabase, "hotels", "event_id", eid)

    # 1. Junction / grandchild tables
    _delete_in(supabase, "participant_activities", "participant_id", participant_ids)
    _delete_in(supabase, "participant_activities", "activity_id", activity_ids)
    _delete_in(supabase, "hotel_nights", "participant_id", participant_ids)
    _delete_in(supabase, "hotel_nights", "hotel_id", hotel_ids)

    # Export files, collected BEFORE step 2 deletes the rows that name them.
    #
    # This was the leak: step 2 removes the `exports` rows, `_remove_event_storage`
    # only ever read `uploaded_files`, and so every deleted event left its export
    # files behind — unreachable, because the paths went with the rows. A master
    # list carries passport numbers, dietary requirements and medical
    # information, which makes an unreachable copy of one the worst kind of
    # object to leave lying around: nothing can show it, and nothing can find it
    # to delete it either.
    export_paths = _export_storage_paths(supabase, eid)

    # 2. Event-scoped tables referencing participants / runs / source_records.
    #    `communications` has no ON DELETE CASCADE on event_id/participant_id
    #    (docs/migrations/002_communications.sql) — any confirmation/campaign
    #    email generated for the event blocks the later participants/events
    #    delete with a foreign-key violation unless cleared here first.
    for table in ("exceptions", "exports", "email_proposals", "communications", "flights", "transfers", "change_log"):
        supabase.table(table).delete().eq("event_id", eid).execute()

    # 3. Consolidation runs (referenced by exceptions/exports, now removed)
    supabase.table("consolidation_runs").delete().eq("event_id", eid).execute()

    # 4. Activities & hotels (their junction rows are gone)
    supabase.table("activities").delete().eq("event_id", eid).execute()
    supabase.table("hotels").delete().eq("event_id", eid).execute()

    # 5. Break the circular FK between participants and source_records:
    #    participants reference source_records (registration_source_id /
    #    fcm_source_id) AND source_records reference participants
    #    (participant_id). Null the participant→source links (nullable columns)
    #    so source_records can be deleted before participants.
    supabase.table("participants").update(
        {"registration_source_id": None, "fcm_source_id": None}
    ).eq("event_id", eid).execute()

    # 6/7. Delete source_records and participants in small id-batches. Both tables
    #      are targets of foreign keys, so Postgres re-checks referencing columns
    #      per deleted row — a single bulk DELETE can exceed the DB statement
    #      timeout on large events. Chunking keeps each statement short.
    source_record_ids = _ids(supabase, "source_records", "event_id", eid)
    logger.info("Deleting %d source_records for event %s", len(source_record_ids), eid)
    _delete_in(supabase, "source_records", "id", source_record_ids, chunk_size=100)

    logger.info("Deleting %d participants for event %s", len(participant_ids), eid)
    _delete_in(supabase, "participants", "id", participant_ids, chunk_size=100)

    # 8. Storage objects, then uploaded_files
    _remove_event_storage(supabase, eid)
    supabase.table("uploaded_files").delete().eq("event_id", eid).execute()

    # 8a. The export files, using the paths captured before step 2.
    _remove_export_storage(supabase, export_paths, eid)

    # 8b. Registration attachments (§9). The ROWS cascade when the event goes,
    #     but the objects in Storage do not — and once the rows are gone their
    #     paths are unrecoverable, leaving passport scans nobody can even
    #     locate to delete. Collected here, while the paths still exist.
    from services import attachment_custody

    attachment_custody.remove_objects(
        supabase, attachment_custody.storage_paths(supabase, eid)
    )

    # 9. The event itself
    supabase.table("events").delete().eq("id", eid).execute()

    logger.info("Deleted event %s and all dependent data", eid)


def _null_participant_source_refs_for(supabase: Client, source_ids: list[str]) -> None:
    """Null participants.registration_source_id / fcm_source_id pointing at *source_ids*."""
    for i in range(0, len(source_ids), 100):
        chunk = source_ids[i : i + 100]
        supabase.table("participants").update({"registration_source_id": None}).in_("registration_source_id", chunk).execute()
        supabase.table("participants").update({"fcm_source_id": None}).in_("fcm_source_id", chunk).execute()


def delete_file_cascade(supabase: Client, file_id: str) -> None:
    """
    Delete an uploaded file and its source_records robustly, handling the same
    pitfalls as event deletion: PostgREST's 1000-row cap (paginate ids), the
    circular participants<->source_records FK (null the participant links first),
    exceptions referencing the records, and statement timeouts (chunk deletes).
    """
    fid = str(file_id)
    source_ids = _ids(supabase, "source_records", "file_id", fid)
    logger.info("Deleting file %s with %d source_records", fid, len(source_ids))

    # 1. Break participant -> source_records references
    _null_participant_source_refs_for(supabase, source_ids)
    # 2. Exceptions referencing these source records
    _delete_in(supabase, "exceptions", "source_record_id", source_ids, chunk_size=100)
    # 3. Source records themselves (chunked by id to stay under the statement timeout)
    _delete_in(supabase, "source_records", "id", source_ids, chunk_size=100)
    # 4. The uploaded_files row
    supabase.table("uploaded_files").delete().eq("id", fid).execute()


def delete_project(supabase: Client, project_id: str) -> None:
    """Delete a project and every event (with all their data) under it."""
    pid = str(project_id)
    event_ids = _ids(supabase, "events", "project_id", pid)
    for eid in event_ids:
        delete_event(supabase, eid)
    supabase.table("projects").delete().eq("id", pid).execute()
    logger.info("Deleted project %s and %d event(s)", pid, len(event_ids))
