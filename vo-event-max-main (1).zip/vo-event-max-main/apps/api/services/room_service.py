"""
services/room_service.py — The same stay, seen as rooms instead of as people.

The master list is built around participants, which is right: the participant
is the system's main entity and every other fact hangs off them. But a hotel
does not work that way. A hotel works by room, and the sheet it wants back
reads "304 — Tina + Leslie", not two rows that happen to mention each other
(feedback §5).

So this is a second presentation of one truth, never a second truth. Both views
are computed from the same nights and the same roommate links; nothing here
stores an occupancy that could drift out of step with them.

What a room is, here:

  * a numbered room the hotel gave us, when there is one;
  * otherwise a room the pairing implies — two people linked as roommates
    occupy one room whether or not anybody has numbered it yet.

The second case is what makes the view useful a month before the rooming list
comes back: an organizer can already count how many twins they need.
"""

from __future__ import annotations

import logging
from typing import Any, Iterable, Optional

logger = logging.getLogger(__name__)

_SINGLE = "single"
_TWIN = "twin"


def _name(participant: dict[str, Any]) -> str:
    return " ".join(
        part for part in (participant.get("first_name"), participant.get("last_name")) if part
    ).strip()


def occupancy(
    participants: list[dict[str, Any]],
    nights: Optional[Iterable[dict[str, Any]]] = None,
    *,
    default_room_type: str = _SINGLE,
    hotel_names: Optional[dict[str, str]] = None,
) -> list[dict[str, Any]]:
    """Who shares which room, one entry per room.

    Pairs come from the resolved roommate link, which is symmetric by
    construction — so a pair is emitted once, under whichever of the two the
    sort order reaches first, and never twice under both.

    A participant with a room number keeps it. Two roommates whose numbers
    disagree are surfaced rather than merged: the hotel gave two different
    answers about one room, and picking one silently would be inventing an
    answer nobody gave.

    ``hotel_names`` maps a hotel id to its name. It comes from the NIGHTS,
    which are the only records that know where somebody is sleeping — the
    participant fiche has never carried a hotel. Without it every row of the
    list showed "—" in the hotel column, which on a two-hotel event is not a
    cosmetic problem: it is a driver being told to collect somebody from a
    building nobody named.

    ``default_room_type`` decides what somebody who never said gets booked as.
    It is a real question and it costs real money: an event where nobody filled
    the room-type box is either ninety singles or ninety doubles, and the
    difference is the hotel invoice. It never overrides a declared type — a
    participant who asked for a twin gets a twin whatever the default says.
    """
    by_id = {p["id"]: p for p in participants if p.get("id")}
    nights_by_participant: dict[str, list[str]] = {}
    hotel_by_participant: dict[str, str] = {}
    names = hotel_names or {}
    for night in nights or []:
        pid = night.get("participant_id")
        if pid and night.get("night_date"):
            nights_by_participant.setdefault(pid, []).append(str(night["night_date"]))
        # First hotel wins: somebody who moves mid-stay is a real case, and the
        # rooming list is grouped by the room they start in.
        if pid and pid not in hotel_by_participant:
            label = names.get(str(night.get("hotel_id") or ""))
            if label:
                hotel_by_participant[pid] = label

    seen: set[str] = set()
    rooms: list[dict[str, Any]] = []

    for pid in sorted(by_id):
        if pid in seen:
            continue
        person = by_id[pid]
        mate_id = person.get("roommate_participant_id")
        mate = by_id.get(mate_id) if mate_id else None

        occupants = [person]
        seen.add(pid)
        if mate and mate.get("id") not in seen:
            occupants.append(mate)
            seen.add(mate["id"])

        numbers = sorted({
            str(o.get("room_number") or "").strip()
            for o in occupants if str(o.get("room_number") or "").strip()
        })
        stays = sorted({
            night for o in occupants for night in nights_by_participant.get(o["id"], [])
        })

        room = {
            "room_number": numbers[0] if numbers else "",
            "room_type": _room_type(occupants, default_room_type),
            "occupants": [
                {"participant_id": o["id"], "name": _name(o)} for o in occupants
            ],
            "occupancy": len(occupants),
            "hotel_name": next(
                (
                    o.get("hotel_name") or hotel_by_participant.get(o["id"], "")
                    for o in occupants
                    if o.get("hotel_name") or hotel_by_participant.get(o["id"])
                ),
                "",
            ),
            "check_in": stays[0] if stays else "",
            "check_out": stays[-1] if stays else "",
            "nights": len(stays),
        }
        if len(numbers) > 1:
            # Two people in one room with two different numbers on the sheet.
            room["conflict"] = "room_number_mismatch"
            room["room_numbers"] = numbers
        rooms.append(room)

    # Numbered rooms first and in order, then the ones still to be assigned —
    # which is the order somebody works through them in.
    return sorted(rooms, key=lambda r: (r["room_number"] == "", _numeric(r["room_number"])))


def _room_type(occupants: list[dict[str, Any]], default: str = _SINGLE) -> str:
    """The type the occupants agree on, or the event's default."""
    declared = [
        str(o.get("room_type") or "").strip()
        for o in occupants if str(o.get("room_type") or "").strip()
    ]
    if declared:
        return declared[0]
    fallback = (default or _SINGLE).strip().lower() or _SINGLE
    if len(occupants) > 1:
        # Two people never occupy a single, whatever the default says: the
        # default answers "what do we book for someone who never told us", and
        # a confirmed pair has already told us something the default cannot
        # contradict.
        return _TWIN if fallback == _SINGLE else fallback
    return fallback


def _numeric(value: str) -> tuple[int, str]:
    """Sort "9" before "10" — a hotel's numbers are numbers, not strings."""
    digits = "".join(ch for ch in value if ch.isdigit())
    return (int(digits) if digits else 0, value)


def summarise(rooms: list[dict[str, Any]]) -> dict[str, Any]:
    """What an organizer needs before phoning the hotel: how many rooms of
    each kind, and how many are still unnumbered."""
    by_type: dict[str, int] = {}
    for room in rooms:
        by_type[room["room_type"]] = by_type.get(room["room_type"], 0) + 1
    return {
        "rooms": len(rooms),
        "participants": sum(room["occupancy"] for room in rooms),
        "unassigned": sum(1 for room in rooms if not room["room_number"]),
        "conflicts": sum(1 for room in rooms if room.get("conflict")),
        "by_type": dict(sorted(by_type.items())),
    }


def participant_view(rooms: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """The same rooms, one line per person — what the feedback calls the
    participant view, and what the hotel export writes.

    Derived FROM the room view rather than computed separately: two functions
    reading the same links could disagree, and a rooming list that contradicts
    itself between two tabs is worse than one that is merely incomplete.
    """
    out: list[dict[str, Any]] = []
    for room in rooms:
        for occupant in room["occupants"]:
            mates = [o["name"] for o in room["occupants"] if o["participant_id"] != occupant["participant_id"]]
            out.append({
                "participant_id": occupant["participant_id"],
                "name": occupant["name"],
                "room_number": room["room_number"],
                "room_type": room["room_type"],
                "roommate": ", ".join(mates),
                "hotel_name": room["hotel_name"],
                "check_in": room["check_in"],
                "check_out": room["check_out"],
                "nights": room["nights"],
            })
    return sorted(out, key=lambda r: r["name"].lower())
