"""
services/export_service.py — Excel workbook generator for consolidation exports.

``generate_excel`` produces a single-sheet ``.xlsx``: the Master List, all
participants, colour-coded by completeness. It used to carry five more sheets
(quality analysis, advice, exceptions, summary, change log) plus a conditional
UPDATES sheet — dropped by request, so a file meant for a hotel or a client
stays exactly what its name says. Every one of those still exists as its own
screen in the app (Rapports, Exceptions, Historique) for anyone reading inside
the platform rather than a spreadsheet somebody else forwards along.

The sheet-building helpers below (``_build_quality_sheet`` and siblings) are
kept: ``generate_excel`` no longer calls them, but they are exercised directly
by tests and are the natural place to add a sheet back if a specific export
profile ever needs one again.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from supabase import Client

from services import master_list_service

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Brand colours
# ---------------------------------------------------------------------------
BRAND_PURPLE   = "806CAF"   # Header background
HEADER_FONT    = "FFFFFF"   # Header text colour
ROW_COMPLETE   = "E3F5EA"   # Green  — participant is complete
ROW_INCOMPLETE = "FEECDF"   # Orange — participant is incomplete
ROW_CONFLICT   = "FBE2E1"   # Red    — participant has data conflicts

SEV_CRITICAL   = "FBE2E1"
SEV_WARNING    = "FEECDF"
SEV_INFO       = "EAF4FB"


def _header_fill() -> PatternFill:
    return PatternFill(start_color=BRAND_PURPLE, end_color=BRAND_PURPLE, fill_type="solid")


def _header_font() -> Font:
    return Font(bold=True, color=HEADER_FONT)


def _row_fill(hex_color: str) -> PatternFill:
    return PatternFill(start_color=hex_color, end_color=hex_color, fill_type="solid")


def _thin_border() -> Border:
    thin = Side(style="thin", color="CCCCCC")
    return Border(left=thin, right=thin, top=thin, bottom=thin)


def _auto_width(ws, min_width: int = 10, max_width: int = 50) -> None:
    """Adjust column widths based on cell content."""
    for col in ws.columns:
        col_letter = get_column_letter(col[0].column)
        col_max = min_width
        for cell in col:
            try:
                cell_len = len(str(cell.value)) if cell.value is not None else 0
                col_max = max(col_max, cell_len)
            except Exception:
                pass
        ws.column_dimensions[col_letter].width = min(col_max + 2, max_width)


# Excel/CSV formula injection (CWE-1236): a cell string starting with "="
# gets auto-promoted by openpyxl to data_type='f' — a REAL live formula
# (an actual <f> element in the XML), which Excel evaluates on open. Every
# value here can originate from an uploaded file's cell content OR its
# column header (custom/unmapped fields keep their original header text)
# and flows into this export verbatim, so a booby-trapped upload (e.g. a
# Company column containing `=cmd|'/c calc'!A1`) would execute when a
# DIFFERENT, possibly more privileged staff member later opens the export.
#
# +, -, @ (the other CSV-injection trigger characters from OWASP's classic
# guidance) do NOT need the same treatment HERE: verified empirically that
# openpyxl already stores those as plain data_type='s' strings, and Excel/
# LibreOffice respect an OOXML cell's explicit stored type on open — a
# string-typed cell is never re-parsed as a formula just because its text
# starts with +/-/@ (that risk is specific to raw CSV, which has no type
# metadata at all). Guarding them anyway would require the same "prefix
# with an apostrophe" trick CSV tools use, but openpyxl has no matching
# "hide this quote marker" flag (that's an Excel-UI-only behaviour for
# manual typing) — the apostrophe would show up as a literal, VISIBLE
# character on ordinary data that legitimately starts with one of these,
# most commonly phone numbers ("+33...").
#
# So instead of mutating the VALUE (which either leaves +/-/@ unprotected
# or corrupts legitimate data), neutralise at the CELL level: after
# openpyxl has decided a value looks like a formula, force it back to a
# plain string type. This preserves the original text byte-for-byte —
# Excel then displays "=cmd|..." as inert visible text, not a formula —
# while adding zero visible side effects to anything else.
def _neutralize_formula(cell) -> Any:
    if cell.data_type == "f":
        cell.data_type = "s"
    return cell


def _write_header_row(ws, headers: list[str]) -> None:
    """Write a styled header row."""
    for col_idx, header in enumerate(headers, start=1):
        cell = _neutralize_formula(ws.cell(row=1, column=col_idx, value=header))
        cell.fill   = _header_fill()
        cell.font   = _header_font()
        cell.border = _thin_border()
        cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 20


def generate_simple_sheet(title: str, headers: list[str], rows: list[list[Any]]) -> bytes:
    """One styled sheet, one header row, no analysis — for supplier exports.

    Deliberately not a trimmed-down ``generate_excel``: that one starts from
    the master list and removes what a supplier must not see, which is the
    wrong direction. This starts from nothing and adds only the columns
    ``supplier_export`` handed over, so a column can only appear here by having
    been named there.

    Values go through the same formula neutralisation as every other sheet: a
    participant whose company is literally ``=cmd|…`` must not become a live
    formula in a coach operator's Excel.
    """
    wb = Workbook()
    ws = wb.active
    ws.title = (title or "Export")[:31]

    _write_header_row(ws, headers)
    for row_idx, values in enumerate(rows, start=2):
        for col_idx, value in enumerate(values, start=1):
            cell = _neutralize_formula(ws.cell(row=row_idx, column=col_idx, value=value))
            cell.border = _thin_border()

    for col_idx, header in enumerate(headers, start=1):
        longest = max(
            [len(str(header))] + [len(str(r[col_idx - 1])) for r in rows if col_idx <= len(r)]
        )
        ws.column_dimensions[get_column_letter(col_idx)].width = min(max(longest + 2, 10), 40)

    ws.freeze_panes = "A2"

    from io import BytesIO
    buffer = BytesIO()
    wb.save(buffer)
    return buffer.getvalue()


# ---------------------------------------------------------------------------
# Sheet 1 — Master List
# ---------------------------------------------------------------------------

def _build_master_list_sheet(
    ws, rows: list[dict], conflict_ids: set[str], custom_fields: list[str] | None = None,
    include_dietary: bool = True,
) -> None:
    """Populate the detailed Master List sheet (feedback §6): identity + real
    flight / hotel / transfer / activity / dietary details, not just booleans.
    User-defined custom mapping fields are appended as extra columns.

    ``include_dietary=False`` blanks Dietary Requirements / Food-Allergy for
    every row: dietary_requirements is RGPD-sensitive and restricted to
    admin/pm everywhere else in the app (participants.py's _strip_dietary,
    the master-list JSON endpoint) — the export must not be a bypass for a
    client/viewer role that can already reach this endpoint via
    verify_event_access's read-level check.
    """
    ws.title = "Master List"
    ws.freeze_panes = "A2"
    custom_fields = custom_fields or []

    # Bloc headers (MVP feedback §11): the existing multi-line summary columns
    # (Flights/Transfers/Activities) are kept EXACTLY as they were — nothing
    # that already worked changes — these are ADDED alongside them so a 3+-leg
    # itinerary or a 3rd activity is never lost, only additionally summarised
    # in the two-column form the spec asks for.
    headers = [
        "Nom", "Prénom", "Email", "Entreprise", "Téléphone", "Nationalité",
        "Région", "Catégorie",
        # Operational columns a real client master file carries. "Info
        # médicale" is health data and follows the same admin/pm gate as the
        # dietary columns below.
        "Société / Business Unit", "VIP", "Nom sur badge", "Taille",
        "Transfert Aller (demandé)", "Transfert Retour (demandé)", "Commentaires",
        "Info Médicale",
        "Régime Alimentaire", "Allergies / Alimentation",
        "Vols (compagnie · trajet · horaires)",
        "Compagnie Aller", "N° Vol Aller", "Départ Aller", "Arrivée Aller",
        "Heure Départ Aller", "Heure Arrivée Aller", "Statut Aller",
        "Compagnie Retour", "N° Vol Retour", "Départ Retour", "Arrivée Retour",
        "Heure Départ Retour", "Heure Arrivée Retour", "Statut Retour",
        "Hôtel", "Arrivée Hôtel", "Départ Hôtel", "Nuitées", "Chambre",
        "Transferts",
        "Type Transfert Arrivée", "Trajet Transfert Arrivée", "Heure Transfert Arrivée",
        "Véhicule Transfert Arrivée", "Statut Transfert Arrivée",
        "Type Transfert Retour", "Trajet Transfert Retour", "Heure Transfert Retour",
        "Véhicule Transfert Retour", "Statut Transfert Retour",
        "Activités (nom · jour/heure)",
        "Activité 1", "Activité 1 — Horaire", "Activité 1 — Lieu", "Activité 1 — Statut",
        "Activité 2", "Activité 2 — Horaire", "Activité 2 — Lieu", "Activité 2 — Statut",
        "Statut",
        "Confirmation Préparée", "Confirmation Envoyée", "Date d'envoi", "Mise à jour requise", "Dernière Communication",
        "Données Complètes", "Champs Manquants", "Exceptions Ouvertes", "Priorité",
        "Sources Utilisées", "Dernière Mise à Jour", "Action Requise",
    ] + list(custom_fields)
    _write_header_row(ws, headers)

    def _yn(v: Any) -> str:
        return "Oui" if v else "Non"

    for row_idx, p in enumerate(rows, start=2):
        custom = p.get("custom") or {}
        values = [
            p.get("last_name"),
            p.get("first_name"),
            p.get("email"),
            p.get("company"),
            p.get("phone"),
            p.get("nationality"),
            p.get("region"),
            p.get("attendee_category"),
            p.get("business_unit") or p.get("function"),
            p.get("vip_status"),
            p.get("badge_name"),
            p.get("shirt_size"),
            p.get("transfer_in"),
            p.get("transfer_out"),
            p.get("comments"),
            p.get("medical_info") if include_dietary else None,
            p.get("dietary_requirements") if include_dietary else None,
            p.get("food_allergy_info") if include_dietary else None,
            p.get("flight_summary"),
            p.get("outbound_airline"), p.get("outbound_flight_number"),
            p.get("outbound_departure_airport"), p.get("outbound_arrival_airport"),
            p.get("outbound_departure_time"), p.get("outbound_arrival_time"), p.get("outbound_status"),
            p.get("return_airline"), p.get("return_flight_number"),
            p.get("return_departure_airport"), p.get("return_arrival_airport"),
            p.get("return_departure_time"), p.get("return_arrival_time"), p.get("return_status"),
            p.get("hotel_name"),
            p.get("hotel_checkin"),
            p.get("hotel_checkout"),
            p.get("hotel_nights_count") or "",
            p.get("hotel_room_type"),
            p.get("transfer_summary"),
            p.get("transfer_arrival_type"), p.get("transfer_arrival_route"),
            p.get("transfer_arrival_time"), p.get("transfer_arrival_vehicle"), p.get("transfer_arrival_status"),
            p.get("transfer_return_type"), p.get("transfer_return_route"),
            p.get("transfer_return_time"), p.get("transfer_return_vehicle"), p.get("transfer_return_status"),
            p.get("activities_summary"),
            p.get("activity_1_name"), p.get("activity_1_when"),
            p.get("activity_1_location"), p.get("activity_1_status"),
            p.get("activity_2_name"), p.get("activity_2_when"),
            p.get("activity_2_location"), p.get("activity_2_status"),
            p.get("completeness_status", "incomplete"),
            _yn(p.get("comm_confirmation_prepared")), _yn(p.get("comm_confirmation_sent")),
            p.get("comm_sent_date"), _yn(p.get("comm_needs_update")), p.get("comm_last_activity"),
            _yn(p.get("dq_complete")), p.get("dq_missing_fields"),
            p.get("dq_open_exceptions") or 0, p.get("dq_priority"),
            p.get("dq_sources_used"), p.get("dq_last_updated"), p.get("dq_action_needed"),
        ] + [custom.get(cf) for cf in custom_fields]

        # Determine row colour
        p_id = str(p.get("id", ""))
        raw_status = p.get("completeness_status", "incomplete")
        if p_id in conflict_ids:
            fill_hex = ROW_CONFLICT
        elif raw_status == "complete":
            fill_hex = ROW_COMPLETE
        else:
            fill_hex = ROW_INCOMPLETE

        fill = _row_fill(fill_hex)
        for col_idx, value in enumerate(values, start=1):
            cell = _neutralize_formula(ws.cell(row=row_idx, column=col_idx, value=value))
            cell.fill   = fill
            cell.border = _thin_border()
            # Multi-line detail cells wrap; the rest are top-aligned for consistency
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    _auto_width(ws, max_width=60)


# ---------------------------------------------------------------------------
# Sheet 2 — Exceptions
# ---------------------------------------------------------------------------

def _build_exceptions_sheet(ws, exceptions: list[dict]) -> None:
    """Populate the Exceptions sheet with unresolved exceptions."""
    ws.title = "Exceptions"
    ws.freeze_panes = "A2"

    headers = ["Type", "Sévérité", "Nom du Participant", "Message", "Contexte"]
    _write_header_row(ws, headers)

    # Severity → colour map
    sev_color = {"critical": SEV_CRITICAL, "warning": SEV_WARNING, "info": SEV_INFO}
    sev_label = {"critical": "Critique", "warning": "Avertissement", "info": "Info"}

    for row_idx, exc in enumerate(exceptions, start=2):
        severity = exc.get("severity", "warning")
        context  = exc.get("context_data")
        ctx_str  = str(context) if context else ""

        # Try to build participant name from context
        p_name = (context or {}).get("participant_name", "—") if context else "—"

        values = [
            exc.get("exception_type"),
            sev_label.get(severity, severity),
            p_name,
            exc.get("message"),
            ctx_str,
        ]
        fill = _row_fill(sev_color.get(severity, SEV_WARNING))
        for col_idx, value in enumerate(values, start=1):
            cell = _neutralize_formula(ws.cell(row=row_idx, column=col_idx, value=value))
            cell.fill   = fill
            cell.border = _thin_border()
            cell.alignment = Alignment(wrap_text=True, vertical="top")

    _auto_width(ws, max_width=80)


# ---------------------------------------------------------------------------
# Sheet 3 — Summary
# ---------------------------------------------------------------------------

def _build_summary_sheet(ws, run: dict, user_id: str) -> None:
    """Populate the Summary sheet with run statistics."""
    ws.title = "Résumé"

    stats: dict = run.get("stats") or {}
    rows = [
        ("ID de l'exécution",          run.get("id")),
        ("ID de l'événement",          run.get("event_id")),
        ("Déclenché par",              user_id),
        ("Statut",                     run.get("status")),
        ("Démarré à",                  run.get("started_at")),
        ("Terminé à",                  run.get("completed_at")),
        ("Généré à",                   datetime.now(timezone.utc).isoformat()),
        ("", ""),  # spacer
        ("— Statistiques —",           ""),
        ("Total enregistrements source", stats.get("total_source_records", 0)),
        ("Correspondances (certaines)", stats.get("matched_certain", 0)),
        ("Correspondances (probables)", stats.get("matched_probable", 0)),
        ("À vérifier",                 stats.get("to_verify", 0)),
        ("Non trouvés",                stats.get("not_found", 0)),
        ("Participants créés",         stats.get("participants_created", 0)),
        ("Participants mis à jour",    stats.get("participants_updated", 0)),
        ("Nombre d'exceptions",        stats.get("exceptions_count", 0)),
    ]

    # Header row
    ws.cell(row=1, column=1, value="Clé").font   = _header_font()
    ws.cell(row=1, column=1).fill = _header_fill()
    ws.cell(row=1, column=2, value="Valeur").font = _header_font()
    ws.cell(row=1, column=2).fill = _header_fill()

    for row_idx, (key, value) in enumerate(rows, start=2):
        ws.cell(row=row_idx, column=1, value=key).font  = Font(bold=True)
        ws.cell(row=row_idx, column=2, value=str(value) if value is not None else "")

    _auto_width(ws, min_width=20)


# ---------------------------------------------------------------------------
# Sheet 4 — Change Log
# ---------------------------------------------------------------------------

def _build_change_log_sheet(ws, changes: list[dict], include_dietary: bool = True) -> None:
    """Populate the Change Log sheet (last 500 entries).

    ``include_dietary=False`` blanks Old/New Value for any entry touching
    dietary_requirements: the Master List sheet strips the CURRENT value for
    non-admin/pm roles, but every historical edit to that field is written
    here verbatim (participants.py's update_participant, the email agent's
    apply_proposal) — without this, the same RGPD-sensitive value leaks
    through the audit trail regardless of the Master List redaction.
    """
    ws.title = "Historique des modifications"
    ws.freeze_panes = "A2"

    headers = ["Date de modification", "Utilisateur", "Type d'entité", "ID de l'entité", "Champ", "Ancienne valeur", "Nouvelle valeur", "Raison"]
    _write_header_row(ws, headers)

    for row_idx, ch in enumerate(changes, start=2):
        is_dietary = ch.get("field_name") == "dietary_requirements"
        values = [
            ch.get("changed_at"),
            ch.get("user_id"),
            ch.get("entity_type"),
            str(ch.get("entity_id", "")),
            ch.get("field_name"),
            ch.get("old_value") if (include_dietary or not is_dietary) else None,
            ch.get("new_value") if (include_dietary or not is_dietary) else None,
            ch.get("change_reason"),
        ]
        for col_idx, value in enumerate(values, start=1):
            cell = _neutralize_formula(ws.cell(row=row_idx, column=col_idx, value=value))
            cell.border = _thin_border()
            cell.alignment = Alignment(vertical="center")

    _auto_width(ws)


# ---------------------------------------------------------------------------
# Sheet — Data-quality analysis & advice (feedback §15)
# ---------------------------------------------------------------------------

def _build_quality_sheet(ws, analysis: dict) -> None:
    """Data-quality dimensions, missing-data counts and distributions."""
    ws.title = "Analyse Qualité"

    ws.cell(row=1, column=1, value="Indicateur").font = _header_font()
    ws.cell(row=1, column=1).fill = _header_fill()
    ws.cell(row=1, column=2, value="Valeur").font = _header_font()
    ws.cell(row=1, column=2).fill = _header_fill()

    dims = analysis.get("dimensions", {}) or {}
    missing = analysis.get("missing", {}) or {}
    dim_labels = {
        "identite": "Identité (email présent)",
        "contact": "Contact (email ou téléphone)",
        "voyage": "Voyage (vol renseigné)",
        "hebergement": "Hébergement",
        "regime": "Régime alimentaire",
        "passeport": "Passeport",
    }
    rows: list[tuple[str, Any]] = [
        ("Participants", analysis.get("total", 0)),
        ("Score qualité global", f"{analysis.get('quality_score', 0)}/100"),
        ("", ""),
        ("— Dimensions (%) —", ""),
    ]
    rows += [(dim_labels.get(k, k), f"{v}%") for k, v in dims.items()]
    rows += [
        ("", ""),
        ("— Données manquantes —", ""),
        ("Sans email", missing.get("email", 0)),
        ("Sans téléphone", missing.get("phone", 0)),
        ("Sans régime alimentaire", missing.get("dietary_requirements", 0)),
        ("Sans n° passeport", missing.get("passport_number", 0)),
        ("Sans fonction/poste", missing.get("job_title", 0)),
        ("Sans région", missing.get("region", 0)),
        ("", ""),
        ("— Services manquants —", ""),
        ("Sans vol", analysis.get("without_flight", 0)),
        ("Sans hébergement", analysis.get("without_hotel", 0)),
        ("Sans transfert", analysis.get("without_transfer", 0)),
        ("Conflits de données non résolus", analysis.get("conflicts", 0)),
        ("Passeports expirés", analysis.get("passport_expired", 0)),
        ("Passeports expirant (< 6 mois)", analysis.get("passport_expiring", 0)),
    ]

    for i, (k, v) in enumerate(rows, start=2):
        c1 = ws.cell(row=i, column=1, value=k)
        if str(k).startswith("—") or k in ("Participants", "Score qualité global"):
            c1.font = Font(bold=True)
        ws.cell(row=i, column=2, value=str(v) if v != "" else "")

    # Distributions on the right
    def _write_distribution(start_col: int, title: str, dist: dict) -> None:
        ws.cell(row=1, column=start_col, value=title).font = _header_font()
        ws.cell(row=1, column=start_col).fill = _header_fill()
        ws.cell(row=1, column=start_col + 1, value="Nombre").font = _header_font()
        ws.cell(row=1, column=start_col + 1).fill = _header_fill()
        for i, (k, v) in enumerate(list(dist.items())[:25], start=2):
            _neutralize_formula(ws.cell(row=i, column=start_col, value=str(k)))
            ws.cell(row=i, column=start_col + 1, value=v)

    _write_distribution(4, "Par région", analysis.get("by_region", {}) or {})
    _write_distribution(7, "Par catégorie", analysis.get("by_category", {}) or {})

    _auto_width(ws, min_width=14, max_width=40)


def _build_advice_sheet(ws, analysis: dict) -> None:
    """Prioritised, data-driven recommendations + the AI narrative (feedback §15)."""
    ws.title = "Conseils"

    # AI narrative on top (if any)
    ai = analysis.get("ai_summary")
    start = 1
    if ai:
        ws.cell(row=1, column=1, value="Synthèse (IA)").font = _header_font()
        ws.cell(row=1, column=1).fill = _header_fill()
        cell = _neutralize_formula(ws.cell(row=2, column=1, value=str(ai)))
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=4)
        ws.row_dimensions[2].height = 90
        start = 4

    headers = ["Priorité", "Recommandation", "Nombre concerné"]
    for col_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=start, column=col_idx, value=header)
        cell.fill = _header_fill()
        cell.font = _header_font()
        cell.alignment = Alignment(horizontal="center")

    sev_label = {"critical": "🔴 Critique", "warning": "🟠 Important", "info": "🔵 Info"}
    sev_color = {"critical": SEV_CRITICAL, "warning": SEV_WARNING, "info": SEV_INFO}
    recs = analysis.get("recommendations", []) or []
    # critical → warning → info
    order = {"critical": 0, "warning": 1, "info": 2}
    recs = sorted(recs, key=lambda r: order.get(r.get("severity"), 3))

    for i, r in enumerate(recs, start=start + 1):
        sev = r.get("severity", "info")
        fill = _row_fill(sev_color.get(sev, SEV_INFO))
        vals = [sev_label.get(sev, sev), r.get("text"), r.get("count")]
        for col_idx, value in enumerate(vals, start=1):
            cell = _neutralize_formula(ws.cell(row=i, column=col_idx, value=value))
            cell.fill = fill
            cell.border = _thin_border()
            cell.alignment = Alignment(wrap_text=True, vertical="top")

    if not recs:
        ws.cell(row=start + 1, column=1, value="Aucun point d'attention détecté — données complètes.")

    _auto_width(ws, max_width=90)


# ---------------------------------------------------------------------------
# Main generator
# ---------------------------------------------------------------------------

async def generate_excel(
    event_id: str,
    run_id: str,
    user_id: str,
    supabase: Client,
    role: str = "viewer",
) -> bytes:
    """
    Generate a multi-sheet Excel workbook for a completed consolidation run.

    Parameters
    ----------
    event_id:  UUID of the event.
    run_id:    UUID of the consolidation_run this export reflects. Kept in the
               signature and threaded into the ``exports`` row by the caller
               even though the workbook itself no longer has a Summary sheet
               to print run stats into.
    user_id:   UUID of the user requesting the export. Not read here; kept for
               callers and for whichever sheet next needs "generated by".
    supabase:  Supabase client.
    role:      Requesting user's role. Only "admin"/"pm" get dietary_requirements
               / food_allergy_info in the Master List sheet — same RGPD-sensitive
               gate applied everywhere else (participants.py's _strip_dietary).
               Defaults to the LEAST privileged role ("viewer") so a caller
               that forgets to pass it fails closed (dietary stripped) rather
               than open; the HTTP router always passes the caller's real role.

    Returns
    -------
    Raw ``.xlsx`` bytes, ready to be uploaded to Supabase Storage.
    """
    # --- Load all data ---

    # Enriched master rows (identity + real flight/hotel/transfer/activity detail).
    # This export runs server-side as an admin operation; the router enforces who
    # can trigger exports, so dietary/allergy fields are included here.
    master_rows: list[dict] = master_list_service.build_master_rows(supabase, event_id)
    master_rows.sort(key=lambda r: str(r.get("last_name") or "").lower())
    custom_fields = sorted({k for r in master_rows for k in (r.get("custom") or {}).keys()})

    # Identify participants with DATA_CONFLICT exceptions — still needed: the
    # Master List sheet itself colours these rows.
    conflict_resp = (
        supabase.table("exceptions")
        .select("participant_id")
        .eq("event_id", event_id)
        .eq("exception_type", "DATA_CONFLICT")
        .eq("resolved", False)
        .execute()
    )
    conflict_ids: set[str] = {
        str(r["participant_id"])
        for r in (conflict_resp.data or [])
        if r.get("participant_id")
    }

    # --- Build workbook ---
    #
    # One sheet, by request: the quality analysis, advice, exceptions,
    # summary, change log and UPDATES sheets this file used to carry are gone.
    # Analysis and advice are still live in the app under Rapports
    # (routers/reports.py -> master_list_service.build_analysis) — only their
    # duplication into this file was removed. "What changed since the last
    # export" (§7) is likewise still answered by its own screen
    # (GET .../exports/updates), which reads export_diff directly rather than
    # through a sheet in this workbook.
    wb = Workbook()
    ws1 = wb.active
    _build_master_list_sheet(
        ws1, master_rows, conflict_ids, custom_fields,
        include_dietary=role in ("admin", "pm"),
    )

    # Serialise to bytes
    import io
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()
