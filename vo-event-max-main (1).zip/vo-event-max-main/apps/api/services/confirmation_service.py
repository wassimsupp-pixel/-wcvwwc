# -*- coding: utf-8 -*-
"""
confirmation_service.py
=======================
Generate an individual participant confirmation (email/letter) from the
consolidated event data — feedback §13 + "Lettre individuelle".

Hard rule (from the brief): the confirmation must **never invent** information.
Only fields actually present in the participant's consolidated data are used;
missing data is simply omitted (and flagged to the user separately).
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from supabase import Client

logger = logging.getLogger(__name__)

# (dead google-generativeai import block removed 2026-08-01: this module
# talks to AI only through services/ai_service.py's unified gateway.)

def _gather(supabase: Client, participant_id: str) -> dict[str, Any]:
    """Collect the participant's core + consolidated logistics (best-effort)."""
    def safe(fn):
        try:
            return fn().data or []
        except Exception as exc:
            logger.warning("confirmation gather sub-query failed: %s", exc)
            return []

    part_res = (
        supabase.table("participants")
        .select("id, event_id, first_name, last_name, email, company, phone, "
                "nationality, dietary_requirements")
        .eq("id", participant_id)
        .maybe_single()
        .execute()
    )
    participant = (part_res.data if part_res else None) or {}

    # Columns added by later migrations. Tried widest-first and narrowed on
    # failure, because PostgREST fails the WHOLE select when ONE column is
    # absent — asking for room_number and badge_name together on a database
    # that has the first and not the second loses both, and the confirmation
    # silently comes back without a room number that exists.
    for columns in (
        "id, room_number, room_type, roommate_name, roommate_participant_id, "
        "pmr_needs, job_title, badge_name",
        "id, room_number, room_type, roommate_name, roommate_participant_id",
        "id, room_number",
    ):
        extra = safe(lambda cols=columns: supabase.table("participants")
                     .select(cols).eq("id", participant_id).execute())
        if extra:
            participant.update({
                k: v for k, v in extra[0].items() if k != "id" and v is not None
            })
            break

    # The roommate's name, which is the one piece of somebody ELSE's data that
    # belongs on this document: the participant is about to share a room with
    # them and needs to recognise the name at reception. The resolved LINK is
    # preferred over the free-text box — the box is what somebody typed, the
    # link is who the engine actually paired them with.
    if participant.get("roommate_participant_id"):
        mate = safe(lambda: supabase.table("participants")
                    .select("first_name, last_name")
                    .eq("id", participant["roommate_participant_id"]).execute())
        if mate:
            resolved = " ".join(
                x for x in (mate[0].get("first_name"), mate[0].get("last_name")) if x
            ).strip()
            if resolved:
                participant["roommate_name"] = resolved

    event = {}
    if participant.get("event_id"):
        ev = safe(lambda: supabase.table("events").select("name, location_city, location_country, start_date, end_date").eq("id", participant["event_id"]).execute())
        event = ev[0] if ev else {}

    flights = safe(lambda: supabase.table("flights").select("*").eq("participant_id", participant_id).execute())
    transfers = safe(lambda: supabase.table("transfers").select("*").eq("participant_id", participant_id).execute())
    # The hotel's address and phone are what a traveller actually needs at 2am
    # in a taxi; the name alone is not enough to get there.
    hotel_nights = safe(lambda: supabase.table("hotel_nights")
                        .select("*, hotels(name, city, address, contact_info)")
                        .eq("participant_id", participant_id).execute())
    if not hotel_nights:
        hotel_nights = safe(lambda: supabase.table("hotel_nights")
                            .select("*, hotels(name, city)")
                            .eq("participant_id", participant_id).execute())
    activities = safe(lambda: supabase.table("participant_activities")
                      .select("*, activities(name, date_time, location, description)")
                      .eq("participant_id", participant_id).execute())
    if not activities:
        activities = safe(lambda: supabase.table("participant_activities")
                          .select("*, activities(name)")
                          .eq("participant_id", participant_id).execute())

    return {
        "participant": participant,
        "event": event,
        "flights": flights,
        "transfers": transfers,
        "hotel_nights": hotel_nights,
        "activities": activities,
    }


def _facts(data: dict[str, Any]) -> dict[str, Any]:
    """Reduce the raw consolidated data to a clean, present-only fact dict."""
    p = data["participant"]
    ev = data["event"]
    facts: dict[str, Any] = {}

    name = f"{p.get('first_name', '')} {p.get('last_name', '')}".strip()
    if name:
        facts["participant_name"] = name
    if ev.get("name"):
        facts["event_name"] = ev["name"]
    loc = ", ".join([x for x in (ev.get("location_city"), ev.get("location_country")) if x])
    if loc:
        facts["event_location"] = loc
    if ev.get("start_date"):
        facts["event_start_date"] = str(ev["start_date"])
    if ev.get("end_date"):
        facts["event_end_date"] = str(ev["end_date"])

    # The participant's own identity block. Their contact details are on the
    # document so they can check them: a wrong phone number nobody ever showed
    # them is a wrong phone number that stays wrong until the airport.
    for key in ("email", "phone", "company", "job_title", "badge_name", "nationality"):
        if p.get(key):
            facts[key] = p[key]

    flights = []
    for f in data["flights"]:
        seg = {
            k: f[k] for k in (
                "flight_number", "airline", "pnr_code",
                "departure_airport", "arrival_airport",
                "departure_time", "arrival_time",
                "baggage_info", "status",
            ) if f.get(k)
        }
        if seg:
            flights.append(seg)
    if flights:
        # Chronological: a confirmation that lists the return leg first is one
        # somebody misreads at 5am.
        flights.sort(key=lambda s: str(s.get("departure_time") or ""))
        facts["flights"] = flights

    nights = []
    for h in data["hotel_nights"]:
        seg = {}
        hotel = h.get("hotels") or {}
        if hotel.get("name"):
            seg["hotel"] = hotel["name"]
        for source, key in (("address", "hotel_address"), ("city", "hotel_city"),
                            ("contact_info", "hotel_contact")):
            if hotel.get(source):
                seg[key] = hotel[source]
        for k in ("night_date", "room_type", "status", "night_kind"):
            if h.get(k):
                seg[k] = h[k]
        if seg:
            nights.append(seg)
    if nights:
        facts["hotel_nights"] = nights

    if p.get("room_number"):
        facts["room_number"] = p["room_number"]
    if p.get("roommate_name"):
        facts["roommate_name"] = p["roommate_name"]
    # The type the participant ASKED for, which is often known long before any
    # night is booked — a confirmation that says nothing about the room on an
    # event where twins were requested reads as though nobody registered it.
    if p.get("room_type"):
        facts["room_type"] = p["room_type"]

    transfers = []
    for tr in data["transfers"]:
        seg = {
            k: tr[k] for k in (
                "pickup_location", "dropoff_location", "pickup_time",
                "transfer_type", "vehicle_type", "status",
            ) if tr.get(k)
        }
        if seg:
            transfers.append(seg)
    if transfers:
        transfers.sort(key=lambda s: str(s.get("pickup_time") or ""))
        facts["transfers"] = transfers

    acts = []
    for a in data["activities"]:
        activity = a.get("activities") or {}
        if not activity.get("name"):
            continue
        acts.append({
            k: activity[k] for k in ("name", "date_time", "location") if activity.get(k)
        } | ({"status": a["status"]} if a.get("status") else {}))
    if acts:
        acts.sort(key=lambda s: str(s.get("date_time") or ""))
        facts["activities"] = acts

    if p.get("dietary_requirements"):
        facts["dietary_requirements"] = p["dietary_requirements"]
    if p.get("pmr_needs"):
        facts["pmr_needs"] = p["pmr_needs"]

    return facts


def _template(facts: dict[str, Any]) -> tuple[str, str]:
    """Deterministic fallback confirmation (used when no LLM is available)."""
    name = facts.get("participant_name", "")
    event = facts.get("event_name", "l'événement")
    subject = f"Confirmation de votre participation — {event}" if facts.get("event_name") else "Confirmation de votre participation"

    lines = [f"Bonjour {name},", "", f"Nous confirmons votre participation à {event}.", ""]
    if facts.get("event_location") or facts.get("event_start_date"):
        loc = facts.get("event_location", "")
        dates = facts.get("event_start_date", "")
        if facts.get("event_end_date"):
            dates = f"{dates} → {facts['event_end_date']}"
        lines.append(f"Lieu : {loc}".rstrip(" :"))
        if dates:
            lines.append(f"Dates : {dates}")
        lines.append("")

    if facts.get("flights"):
        lines.append("Vos vols :")
        for f in facts["flights"]:
            route = f"{f.get('departure_airport', '')} → {f.get('arrival_airport', '')}".strip(" →")
            lines.append(f"  - {f.get('flight_number', '')} {route} {f.get('departure_time', '')}".rstrip())
        lines.append("")
    if facts.get("hotel_nights"):
        lines.append("Votre hébergement :")
        for h in facts["hotel_nights"]:
            lines.append(f"  - {h.get('hotel', '')} {h.get('night_date', '')} {h.get('room_type', '')}".rstrip())
        lines.append("")
    if facts.get("transfers"):
        lines.append("Vos transferts :")
        for tr in facts["transfers"]:
            lines.append(f"  - {tr.get('pickup_location', '')} → {tr.get('dropoff_location', '')} {tr.get('pickup_time', '')}".strip(" →"))
        lines.append("")
    if facts.get("activities"):
        # Each activity is a dict now (name + when + where); the email keeps
        # the short form and the PDF prints the detail.
        names = [str(a.get("name") or "") for a in facts["activities"] if a.get("name")]
        if names:
            lines.append("Vos activités : " + ", ".join(names))
            lines.append("")
    if facts.get("dietary_requirements"):
        lines.append(f"Régime alimentaire noté : {facts['dietary_requirements']}")
        lines.append("")

    lines.append("Pour toute question, n'hésitez pas à nous contacter.")
    lines.append("")
    lines.append("Bien cordialement,")
    lines.append("L'équipe organisation")
    return subject, "\n".join(lines)


def _generate_with_gemini(facts: dict[str, Any]) -> Optional[tuple[str, str]]:
    prompt = f"""
    Rédige un e-mail de confirmation de participation, chaleureux et professionnel, en français.

    Utilise UNIQUEMENT les informations fournies ci-dessous (au format JSON). Règle absolue :
    n'invente JAMAIS une information absente ; si un champ manque, ne le mentionne pas.

    Données du participant :
    {json.dumps(facts, ensure_ascii=False, indent=2)}

    Réponds STRICTEMENT en JSON avec deux champs :
    {{"subject": "...", "body": "..."}}
    Le body est le corps de l'e-mail (texte, sauts de ligne autorisés).
    """
    try:
        from services import ai_service
        text = (ai_service.ai_text(prompt) or "").strip()
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0].strip()
        elif "```" in text:
            text = text.split("```")[1].split("```")[0].strip()
        parsed = json.loads(text)
        subject = parsed.get("subject") or "Confirmation de votre participation"
        body = parsed.get("body") or ""
        if not body:
            return None
        return subject, body
    except Exception as exc:
        logger.error("Gemini confirmation generation failed, using template: %s", exc)
        return None


def facts_for(supabase: Client, participant_id: str) -> dict[str, Any]:
    """The consolidated facts alone, with no message written around them.

    The PDF (§16) needs exactly what the email needs and none of the prose, and
    routing it through ``generate_confirmation`` would spend an LLM call
    producing a body nobody reads.
    """
    data = _gather(supabase, participant_id)
    facts = _facts(data)
    facts["_event_id"] = data["participant"].get("event_id")
    return facts


def generate_confirmation(supabase: Client, participant_id: str) -> dict[str, Any]:
    """
    Build a confirmation draft for a participant. Returns
    ``{subject, body, facts, missing, source}`` — never persists.
    """
    data = _gather(supabase, participant_id)
    facts = _facts(data)

    # Which useful blocks are missing (surfaced to the user, never invented)
    missing = [
        key for key in ("flights", "hotel_nights", "transfers")
        if key not in facts
    ]

    from services import ai_service
    result = _generate_with_gemini(facts) if ai_service.ai_available() else None
    if result is None:
        subject, body = _template(facts)
        source = "template"
    else:
        subject, body = result
        source = "gemini"

    return {
        "subject": subject,
        "body": body,
        "facts": facts,
        "missing": missing,
        "source": source,
        "event_id": data["participant"].get("event_id"),
    }
