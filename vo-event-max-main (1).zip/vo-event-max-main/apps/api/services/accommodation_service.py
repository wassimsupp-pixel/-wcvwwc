"""
services/accommodation_service.py — How many nights each participant actually
needs, worked out from their flights.

The first design assumed accommodation arrives as a rooming list to import.
MAX's real workflow usually runs the other way round (feedback §2): they have
the registrations and the flights first, and they DERIVE the number of nights
from the travel dates — you land on the 1st and fly home on the 5th, so you
sleep there four times. The hotel list, when it exists at all, comes later and
is a thing to check the derivation AGAINST rather than a prerequisite for it.

Two consequences, and both are here:

  * **Nights without a hotel file.** A participant with flights and no rooming
    row still gets a stay, so the Accommodation tab stops being empty on an
    event that has all the information it needs.
  * **A cross-check when both exist.** Derived four nights, hotel booked three:
    that gap is worth one precise alert, not silence. It is the kind of
    mismatch that is cheap to fix a month out and expensive at the front desk.

And once nights have dates, the programme's own dates split them (feedback §3):
an official programme running the 1st to the 3rd covers two of those four
nights, and the other two are a personal extension the participant pays for.
MAX needs that split to talk to the hotel; the hotel needs it to bill the right
party.

Everything in this module is pure — dates in, dates out, no database — so the
rules can be tested against a table of cases rather than against a fixture.
"""

from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from typing import Any, Iterable, Optional

logger = logging.getLogger(__name__)

PROGRAM = "program"
EXTENSION = "extension"

# A stay longer than this is almost certainly two trips glued together by a
# mis-parsed date, not somebody sleeping there for three months. Deriving 90
# hotel nights from one bad year would be a far louder failure than deriving
# none, so the derivation refuses rather than guesses.
MAX_DERIVED_NIGHTS = 60


def as_day(value: Any) -> Optional[date]:
    """The calendar day of an ISO timestamp or date, or None.

    Accepts what the flights table actually holds — ``2026-09-01T14:15:00Z``,
    ``2026-09-01 14:15:00+00:00``, a bare ``2026-09-01``, or a real date object.
    Anything else returns None instead of raising: one unparsable row must not
    cost a participant their whole stay.
    """
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value).strip()
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).date()
    except ValueError:
        pass
    try:
        return date.fromisoformat(text[:10])
    except ValueError:
        logger.debug("Unparsable travel date: %r", value)
        return None


def travel_window(flights: Iterable[dict[str, Any]]) -> tuple[Optional[date], Optional[date]]:
    """The day the participant lands, and the day they fly home.

    Arrival is the earliest segment's arrival day; departure is the latest
    segment's departure day. Reading it off the extremes rather than off an
    outbound/return marker is deliberate: the flights table carries no
    direction column, and a trip with a stopover has more than two segments.

    A single segment gives an arrival and no departure — a one-way booking is
    real, and we would rather derive nothing than invent a return.
    """
    arrivals: list[date] = []
    departures: list[date] = []
    for f in flights:
        arrival = as_day(f.get("arrival_time"))
        departure = as_day(f.get("departure_time"))
        if arrival:
            arrivals.append(arrival)
        if departure:
            departures.append(departure)

    if not arrivals or not departures:
        return (min(arrivals) if arrivals else None, None)

    first_arrival = min(arrivals)
    last_departure = max(departures)
    if last_departure <= first_arrival:
        # Every segment on one day, or a single leg: nothing to sleep through.
        return (first_arrival, None)
    return (first_arrival, last_departure)


def nights_between(arrival: Optional[date], departure: Optional[date]) -> list[date]:
    """The nights actually slept: arrival included, departure excluded.

    Land on the 1st, fly home on the 5th → the nights of the 1st, 2nd, 3rd and
    4th. Four nights, not five: you do not sleep there the night you leave.
    This is the same half-open convention the rooming-list extraction already
    uses, which is what lets derived and imported nights share a table.
    """
    if not arrival or not departure or departure <= arrival:
        return []
    span = (departure - arrival).days
    if span > MAX_DERIVED_NIGHTS:
        logger.warning(
            "Refusing to derive a %d-night stay (%s → %s) — almost certainly a parsing error",
            span, arrival, departure,
        )
        return []
    return [arrival + timedelta(days=offset) for offset in range(span)]


def classify_night(
    night: date,
    event_start: Optional[date],
    event_end: Optional[date],
) -> str:
    """``program`` or ``extension`` for a single night.

    The programme covers the nights from its start up to — but not including —
    its end day, mirroring ``nights_between``: a programme running the 1st to
    the 3rd covers the nights of the 1st and the 2nd.

    Nights before the programme count as an extension too. The feedback only
    describes people staying on, but somebody flying in a day early is the
    identical situation — a night the client did not book — and treating it as
    programme would quietly hand the bill to the wrong party.

    With no programme dates, everything is ``program``: an event that never set
    its dates must not suddenly report that everyone is on a private holiday.
    """
    if not event_start or not event_end or event_end <= event_start:
        return PROGRAM
    return PROGRAM if event_start <= night < event_end else EXTENSION


def split_nights(
    nights: Iterable[date],
    event_start: Optional[date],
    event_end: Optional[date],
) -> dict[str, list[date]]:
    """Nights grouped by who is paying for them."""
    out: dict[str, list[date]] = {PROGRAM: [], EXTENSION: []}
    for night in sorted(nights):
        out[classify_night(night, event_start, event_end)].append(night)
    return out


def mismatch(derived: list[date], booked: list[date]) -> Optional[dict[str, Any]]:
    """The gap between the nights the flights imply and the nights the hotel
    holds, or None when they agree.

    Both counts and the two symmetric differences are reported: "one night
    short" and "one night on the wrong date" are very different phone calls to
    make, and the count alone cannot tell them apart.
    """
    if not derived or not booked:
        return None
    d, b = set(derived), set(booked)
    if d == b:
        return None
    missing = sorted(d - b)
    extra = sorted(b - d)
    return {
        "derived_nights": len(d),
        "booked_nights": len(b),
        "missing": [n.isoformat() for n in missing],
        "extra": [n.isoformat() for n in extra],
        "delta": len(d) - len(b),
    }


def describe_mismatch(name: str, gap: dict[str, Any]) -> str:
    """The French sentence an organizer reads on the exception card."""
    derived, booked = gap["derived_nights"], gap["booked_nights"]
    if gap["delta"] > 0:
        detail = f"il manque {gap['delta']} nuit(s) à l'hôtel"
    elif gap["delta"] < 0:
        detail = f"l'hôtel en a {abs(gap['delta'])} de trop"
    else:
        detail = "le nombre est le bon mais les dates diffèrent"
    return (
        f"« {name} » : les vols impliquent {derived} nuit(s), l'hôtel en a réservé "
        f"{booked} — {detail}."
    )
