"""
services/registration_i18n.py — The public form in the participant's language.

The internal app has spoken three languages since the start. The public page
never has: its labels are written in French in the catalogue and in the page
itself, so a Dutch-speaking participant of a Belgian agency receives a French
form (feedback §12).

The reference form MAX already runs opens on "Kies uw taal / Choisissez votre
langue" before anything else, which is the right instinct — the first thing you
ask somebody should not itself be a barrier.

Two decisions worth stating:

**The server translates the field labels, not the browser.** The catalogue
lives here, the organizer's own questions live in the database, and the
required-field error messages are produced server-side. Translating half of
that in the page would guarantee a form that is Dutch above the fold and
French in its error messages.

**An untranslated label falls back to French rather than to its key.** A
participant seeing "Prénom" on a Dutch form is mildly untidy; one seeing
"first_name" is looking at a broken page. Adding a field to the catalogue
without translating it must never be able to produce the second.
"""

from __future__ import annotations

from typing import Any

SUPPORTED: tuple[str, ...] = ("fr", "nl", "en")
DEFAULT = "fr"

# field key -> {locale: label}. French lives in the catalogue itself and is the
# fallback, so only nl/en appear here.
_LABELS: dict[str, dict[str, str]] = {
    "first_name": {"nl": "Voornaam", "en": "First name"},
    "last_name": {"nl": "Achternaam", "en": "Last name"},
    "email": {"nl": "E-mailadres", "en": "Email address"},
    "civility": {"nl": "Aanhef", "en": "Title"},
    "company": {"nl": "Bedrijf", "en": "Company"},
    "phone": {"nl": "Telefoon", "en": "Phone"},
    "nationality": {"nl": "Nationaliteit", "en": "Nationality"},
    "date_of_birth": {"nl": "Geboortedatum", "en": "Date of birth"},
    "birth_place": {"nl": "Geboorteplaats", "en": "Place of birth"},
    "job_title": {"nl": "Functie", "en": "Job title"},
    "badge_name": {"nl": "Naam op badge", "en": "Name on badge"},
    "language": {"nl": "Voorkeurstaal", "en": "Preferred language"},
    "address": {"nl": "Privé-adres", "en": "Home address"},
    "postal_code": {"nl": "Postcode", "en": "Postal code"},
    "city": {"nl": "Woonplaats", "en": "City"},
    "country": {"nl": "Land", "en": "Country"},
    "company_vat": {"nl": "BTW-nummer", "en": "VAT number"},
    "company_address": {"nl": "Adres bedrijf", "en": "Company address"},
    "company_postal_code": {"nl": "Postcode (bedrijf)", "en": "Postal code (company)"},
    "company_city": {"nl": "Gemeente (bedrijf)", "en": "Town (company)"},
    "passport_scan": {"nl": "Kopie van het paspoort", "en": "Passport copy"},
    "photo": {"nl": "Pasfoto", "en": "Passport photo"},
    "passport_number": {"nl": "Nummer paspoort", "en": "Passport number"},
    "passport_expiry": {"nl": "Geldigheid paspoort", "en": "Passport expiry"},
    "passport_country": {"nl": "Land van het paspoort", "en": "Passport country"},
    "transfer_needed": {"nl": "Transfer nodig?", "en": "Transfer needed?"},
    "arrival_flight": {"nl": "Aankomstvlucht", "en": "Arrival flight"},
    "arrival_airport": {"nl": "Luchthaven van aankomst", "en": "Arrival airport"},
    "departure_flight": {"nl": "Terugvlucht", "en": "Return flight"},
    "dietary_requirements": {"nl": "Dieetwensen", "en": "Dietary requirements"},
    "food_allergy_info": {"nl": "Allergieën", "en": "Allergies"},
    "room_type": {"nl": "Type kamer", "en": "Room type"},
    "roommate": {"nl": "Met wie wilt u uw kamer delen?", "en": "Who would you like to share a room with?"},
    "room_preference": {"nl": "Kamervoorkeuren", "en": "Room preferences"},
    "extension_requested": {"nl": "Wilt u uw verblijf op eigen kosten verlengen?",
                            "en": "Would you like to extend your stay at your own expense?"},
    "extension_start": {"nl": "Begin van de verlenging", "en": "Extension starts"},
    "extension_end": {"nl": "Einde van de verlenging", "en": "Extension ends"},
    "extension_hotel": {"nl": "Hotel tijdens de verlenging", "en": "Hotel during the extension"},
    "pmr_needs": {"nl": "Toegankelijkheidsbehoeften", "en": "Accessibility needs"},
    "shirt_size": {"nl": "T-shirtmaat", "en": "T-shirt size"},
    "activity_preferences": {"nl": "Gewenste activiteiten", "en": "Preferred activities"},
    "emergency_contact_name": {"nl": "Naam noodcontact", "en": "Emergency contact name"},
    "emergency_contact_phone": {"nl": "Telefoon noodcontact", "en": "Emergency contact phone"},
    "emergency_contact_country": {"nl": "Land noodcontact", "en": "Emergency contact country"},
    "special_requests": {"nl": "Speciale verzoeken", "en": "Special requests"},
    "remarks": {"nl": "Opmerkingen", "en": "Remarks"},
}

# Section headings.
_GROUPS: dict[str, dict[str, str]] = {
    "Identité": {"nl": "Identiteit", "en": "Identity"},
    "Adresse": {"nl": "Adres", "en": "Address"},
    "Société": {"nl": "Bedrijf", "en": "Company"},
    "Voyage": {"nl": "Reis", "en": "Travel"},
    "Séjour": {"nl": "Verblijf", "en": "Stay"},
    "Contact d'urgence": {"nl": "Noodcontact", "en": "Emergency contact"},
    "Divers": {"nl": "Overige", "en": "Other"},
}

# The sentences the API itself produces. The page's own chrome is translated by
# next-intl; these are the ones that arrive from the server and would otherwise
# be French inside an otherwise Dutch page.
_MESSAGES: dict[str, dict[str, str]] = {
    "missing_fields": {
        "fr": "Merci de renseigner : {fields}.",
        "nl": "Gelieve in te vullen: {fields}.",
        "en": "Please fill in: {fields}.",
    },
    "missing_confirmations": {
        "fr": "Merci de confirmer : {fields}.",
        "nl": "Gelieve te bevestigen: {fields}.",
        "en": "Please confirm: {fields}.",
    },
    "submitted": {
        "fr": "Inscription bien reçue. Merci !",
        "nl": "Inschrijving goed ontvangen. Bedankt!",
        "en": "Registration received. Thank you!",
    },
    "closed": {
        "fr": "Les inscriptions pour cet événement sont closes.",
        "nl": "De inschrijvingen voor dit evenement zijn gesloten.",
        "en": "Registration for this event is closed.",
    },
}


def normalise(locale: Any) -> str:
    """A supported language code. Accepts "nl-BE" and "NL" as "nl"."""
    code = str(locale or "").strip().lower().replace("_", "-").split("-")[0]
    return code if code in SUPPORTED else DEFAULT


def label(key: str, french: str, locale: str) -> str:
    """The field's label in this language, falling back to the French one.

    Never falls back to the key: a participant seeing "Prénom" on a Dutch form
    is untidy, one seeing "first_name" is looking at a broken page.
    """
    if locale == DEFAULT:
        return french
    return _LABELS.get(key, {}).get(locale) or french


def group(french: str, locale: str) -> str:
    if locale == DEFAULT:
        return french
    return _GROUPS.get(french, {}).get(locale) or french


def message(key: str, locale: str, **params: Any) -> str:
    """One of the server's own sentences, formatted."""
    template = _MESSAGES.get(key, {}).get(locale) or _MESSAGES.get(key, {}).get(DEFAULT, "")
    return template.format(**params) if params else template


def translate_fields(fields: list[dict[str, Any]], locale: str) -> list[dict[str, Any]]:
    """The resolved catalogue, relabelled. Keys, order and flags untouched —
    only what a human reads changes."""
    if locale == DEFAULT:
        return fields
    return [
        {**field,
         "label": label(field["key"], field["label"], locale),
         "group": group(field["group"], locale)}
        for field in fields
    ]
