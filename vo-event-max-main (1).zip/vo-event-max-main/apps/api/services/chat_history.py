"""
services/chat_history.py — Conversations that survive a page reload.

The assistant already accepted a ``history``, but the BROWSER carried it: close
the tab and the thread was gone, along with the follow-up thread of reasoning it
supported. Somebody who asked four questions on Monday to narrow down a problem
came back on Tuesday to an empty box.

Four decisions shaped this, and each is a restriction rather than a feature.

**A conversation belongs to a person, not to an event.** Two organizers working
the same event do not see each other's threads. What somebody asks reveals what
they are worried about — "qui n'a toujours pas de passeport", "est-ce qu'on peut
encore annuler" — and that is not team-wide information by default.

**The history the assistant reads comes from the database, not from the
request.** The client used to send it, which meant a caller could hand the
assistant a fabricated exchange and shape what came next. Once a conversation
has an id, the server reads its own record.

**Answers are stored as prose, never as rows.** An answer's ``rows`` hold real
participant data — names, dietary requirements — and keeping them would make
every conversation a second, unmanaged copy of the master list (§23). The
sentence is kept; the table is recomputed whenever it is asked for again.

**A title is the first question, trimmed.** Not summarised by an AI: a
conversation list where the labels are approximations of what you asked is a
list you cannot scan.
"""

from __future__ import annotations

import logging
from typing import Any, Iterable, Optional

logger = logging.getLogger(__name__)

USER = "user"
ASSISTANT = "assistant"

# How many past turns the assistant is given. Enough for "et sans hôtel ?" to
# resolve against the question before it, short enough that a long thread does
# not quietly change what a question means.
CONTEXT_TURNS = 8

MAX_TITLE = 80
# A thread longer than this is a session, not a question. New ones still work;
# only the context window and the transcript read are bounded.
MAX_TRANSCRIPT = 200


class HistoryUnavailable(RuntimeError):
    """Migration 019 has not been applied on this deployment."""


def title_for(question: str) -> str:
    """The first question, trimmed to fit a sidebar.

    Deliberately not an AI summary. A list whose labels are approximations of
    what you asked is a list you have to open every row of.
    """
    text = " ".join(str(question or "").split())
    if len(text) <= MAX_TITLE:
        return text or "Nouvelle conversation"
    return text[: MAX_TITLE - 1].rstrip(" ,;:") + "…"


def as_turns(messages: Iterable[dict[str, Any]]) -> list[dict[str, str]]:
    """Stored messages in the shape ``chatbot_service.answer_question`` wants.

    That shape is ``{"question": ...}`` and nothing else — see ``ChatTurn``.
    The assistant filters on exactly that key, so a list of role/content pairs
    would be dropped without a word: no error, no context, and a follow-up
    quietly answering as though it were a fresh question.

    Only what the USER said. The assistant's own answers are not context for
    choosing what to look up next; they are what it already concluded, and
    feeding them back invites it to build on its own output.
    """
    return [
        {"question": str(m.get("content") or "").strip()}
        for m in messages
        if m.get("role") == USER and str(m.get("content") or "").strip()
    ]


def recent(messages: list[dict[str, Any]], turns: int = CONTEXT_TURNS) -> list[dict[str, str]]:
    """The tail of a conversation, oldest first.

    Bounded because a follow-up resolves against what was JUST asked. Feeding
    forty turns back does not make the assistant more accurate; it makes an
    old question able to change what a new one means.
    """
    return as_turns(messages)[-max(0, turns):]


def summarise(conversation: dict[str, Any], messages: list[dict[str, Any]]) -> dict[str, Any]:
    """One row of the conversation list."""
    questions = [m for m in messages if m.get("role") == USER]
    refused = [m for m in messages if m.get("role") == ASSISTANT and m.get("answered") is False]
    return {
        "id": conversation.get("id"),
        "title": conversation.get("title") or "Nouvelle conversation",
        "created_at": conversation.get("created_at"),
        "updated_at": conversation.get("updated_at"),
        "questions": len(questions),
        # Surfaced because a thread full of refusals is the useful signal here:
        # it means somebody kept asking something the data cannot answer.
        "unanswered": len(refused),
    }


# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------
#
# Every function below returns rather than raises when the tables are absent,
# except where the caller explicitly asked for a conversation. The assistant
# must keep answering on a deployment that has not run migration 019 — losing
# the transcript is survivable, losing the assistant is not.


def load(supabase: Any, conversation_id: str, event_id: str, user_id: str) -> tuple[
    Optional[dict[str, Any]], list[dict[str, Any]]
]:
    """A conversation and its messages, or ``(None, [])``.

    Scoped by BOTH event and user: an id alone must never be enough to read
    somebody else's thread, and a conversation id guessed from another event
    must not resolve.
    """
    try:
        found = (
            supabase.table("chat_conversations")
            .select("*")
            .eq("id", conversation_id)
            .eq("event_id", event_id)
            .eq("user_id", user_id)
            .execute()
        ).data or []
    except Exception as exc:
        logger.info("Chat history unavailable (migration 019?): %s", exc)
        return None, []

    if not found:
        return None, []

    try:
        messages = (
            supabase.table("chat_messages")
            .select("*")
            .eq("conversation_id", conversation_id)
            .order("created_at")
            .limit(MAX_TRANSCRIPT)
            .execute()
        ).data or []
    except Exception as exc:
        logger.warning("Could not read chat messages: %s", exc)
        messages = []

    return found[0], messages


def start(supabase: Any, event_id: str, user_id: str, question: str) -> Optional[str]:
    """Open a conversation. Returns its id, or None when storage is absent."""
    try:
        res = (
            supabase.table("chat_conversations")
            .insert({
                "event_id": event_id,
                "user_id": user_id,
                "title": title_for(question),
            })
            .execute()
        )
    except Exception as exc:
        logger.info("Chat history unavailable (migration 019?): %s", exc)
        return None
    rows = res.data or []
    return rows[0].get("id") if rows else None


def append(
    supabase: Any,
    conversation_id: str,
    question: str,
    answer: dict[str, Any],
) -> bool:
    """Store the exchange. The answer's rows are deliberately NOT kept.

    They are real participant data, and a transcript holding them is a second
    copy of the master list nobody is managing. The prose is enough to read the
    thread back; the table is recomputed if the question is asked again.
    """
    payload = [
        {"conversation_id": conversation_id, "role": USER, "content": question},
        {
            "conversation_id": conversation_id,
            "role": ASSISTANT,
            "content": str(answer.get("answer") or ""),
            "intent": answer.get("intent"),
            "answered": bool(answer.get("answered")),
            # How many rows the answer carried, so the transcript can say "42
            # participants" without holding the forty-two names.
            "row_count": len(answer.get("rows") or []),
        },
    ]
    from datetime import datetime, timezone

    try:
        supabase.table("chat_messages").insert(payload).execute()
        # An ISO timestamp, not the string "now()": PostgREST posts the value
        # verbatim and Postgres rejects "now()" as a timestamptz. It would have
        # failed silently — the exchange stored, updated_at frozen, and the
        # conversation list quietly sorted by the wrong date forever.
        supabase.table("chat_conversations").update(
            {"updated_at": datetime.now(timezone.utc).isoformat()}
        ).eq("id", conversation_id).execute()
        return True
    except Exception as exc:
        logger.warning("Could not store chat exchange: %s", exc)
        return False
