"""
services/registration_assistant.py — Describe the event, get a form.

Configuring the public form means forty-six on/off switches, forty-six
"required" switches, an order, a set of extra questions, and an appearance.
Every one of those choices is obvious once you know the event and tedious to
click one at a time — which is exactly the shape of problem worth handing to a
model.

So: the organizer writes a sentence or two about the event, and this returns a
complete proposal. A two-day sales convention in Lisbon with hotel and flights
booked for everyone needs the travel block, the rooming block and dietary
requirements; a one-evening cocktail in the same office needs a name, an email
and nothing else. Asking the second event's guests for a passport expiry date
is the failure this exists to remove.

**The model proposes; this module disposes.** That is the whole safety story
and it is worth being precise about, because the input is free text written by
a human and the output configures a page open to the world:

  * Field keys are intersected with `registration_form.FIELD_KEYS`. A key the
    model invented is dropped, not created.
  * Locked identity fields are forced on afterwards, whatever the model said.
  * The theme goes through `registration_theme.sanitize`, so it can only ever
    contain keys this codebase defined and one validated hex colour.
  * Free text is stripped of markup with the same function the mini-site uses.
  * Nothing is written. `propose` returns a draft; the organizer reviews it and
    saves it through the existing endpoints, which sanitize again.

The consequence is that the worst a prompt injection buried in an event
description can achieve is a form asking the wrong questions, which the
organizer is looking at when they decide whether to apply it.

And when no AI provider is configured, or the model is unreachable, this still
answers — `_heuristic` reads the same description with keywords. A degraded
proposal an organizer can edit beats a spinner that ends in an error.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Optional

from services import ai_service, event_site, registration_form, registration_theme

logger = logging.getLogger(__name__)

MAX_DESCRIPTION = 2000

# How long to wait for the model.
#
# Measured against the production provider on 2026-08-31: the flagship answers
# a trivial prompt in ~27s and THIS one -- 46 catalogue lines plus the brief --
# in 46.3s. At the previous budget of 45s that was a coin toss between a good
# answer and the keyword fallback, decided by provider load.
#
# The wait costs less than it looks: the caller runs this off the event loop,
# nothing is written while it runs, and an organizer configures an event once.
# The panel tells them it can take a minute rather than leaving them guessing.
_TIMEOUT_S = 75.0


# ---------------------------------------------------------------------------
# What the model is allowed to say
# ---------------------------------------------------------------------------

def _catalogue_for_prompt() -> str:
    """The field catalogue as the model sees it: key, label, section.

    Sent in full rather than summarised. The whole value of the feature is that
    it knows `passport_expiry` exists and that a domestic one-day event does not
    need it — which it cannot do from a list it was never shown.
    """
    lines = []
    for key, label, section, locked in registration_form._CATALOGUE:
        suffix = "  [toujours activé]" if locked else ""
        lines.append(f"  {key} | {section} | {label}{suffix}")
    return "\n".join(lines)


_PROMPT = """Tu configures le formulaire d'inscription en ligne d'un événement professionnel.

DESCRIPTION DE L'ÉVÉNEMENT (écrite par l'organisateur) :
\"\"\"
{description}
\"\"\"

CHAMPS DISPONIBLES (clé | section | libellé) :
{catalogue}

RÈGLES :
- N'active que ce que cet événement a réellement besoin de savoir. Un champ
  activé « au cas où » est une question de plus posée à chaque participant.
- `required` uniquement si l'inscription est inutilisable sans la réponse.
- Les champs marqués [toujours activé] le restent, ne les liste pas comme désactivés.
- Pas d'hébergement mentionné => pas de bloc chambre. Pas de vol pris en charge
  => pas de bloc voyage. Pas de repas => pas de régime alimentaire.
- N'invente aucune clé : utilise exclusivement celles de la liste.

APPARENCE — choisis parmi ces valeurs exactement :
- font : {fonts}
- surface : {surfaces}
- corners : {corners}
- header.style : {headers}
- accent : une couleur hexadécimale #rrggbb cohérente avec le ton de l'événement.

Réponds UNIQUEMENT avec ce JSON, sans texte autour :
{{
  "enabled": ["cle", ...],
  "required": ["cle", ...],
  "order": ["cle", ...],
  "custom_fields": [{{"label": "question propre à cet événement", "type": "text"}}],
  "theme": {{"font": "...", "accent": "#rrggbb", "surface": "...", "corners": "...",
             "header": {{"style": "...", "title": "...", "subtitle": "..."}}}},
  "summary": "une phrase expliquant le choix, en français"
}}"""


def _clean_description(text: Any) -> str:
    """The organizer's words, bounded and stripped of markup.

    Markup goes because a description is also echoed back in the proposal's
    summary, and because a `<script>` in a prompt is a `<script>` in whatever
    the model quotes back.
    """
    value = re.sub(r"<[^>]*>", " ", str(text or ""))
    value = re.sub(r"\s+", " ", value)
    return value.strip()[:MAX_DESCRIPTION]


def _keys(values: Any) -> list[str]:
    """Whatever the model returned, intersected with the real catalogue.

    Order is preserved and duplicates are dropped, so a model that lists a key
    twice does not produce it twice in the form's order.
    """
    seen: set[str] = set()
    out: list[str] = []
    for raw in values if isinstance(values, list) else []:
        key = str(raw or "").strip()
        if key in registration_form.FIELD_KEYS and key not in seen:
            seen.add(key)
            out.append(key)
    return out


def _custom_fields(values: Any) -> list[dict[str, Any]]:
    """Questions the catalogue does not cover, capped and de-marked-up.

    Kept deliberately small: the model is good at noticing that a golf day
    needs a handicap, and bad at knowing when to stop. Five is enough to be
    useful and few enough to review at a glance.
    """
    out: list[dict[str, Any]] = []
    for entry in values if isinstance(values, list) else []:
        if not isinstance(entry, dict):
            continue
        label = event_site.clean_text(entry.get("label"), limit=120)
        if not label:
            continue
        kind = str(entry.get("type") or "text").strip().lower()
        out.append({"label": label, "type": kind if kind in ("text", "textarea", "select") else "text"})
        if len(out) >= 5:
            break
    return out


def _shape(raw: Any, description: str) -> dict[str, Any]:
    """One model answer, turned into something that can only be applied safely.

    Everything the organizer would otherwise click is reconstructed here from
    the catalogue rather than copied from the answer, which is what makes a
    hallucinated key a no-op instead of a bad row.
    """
    data = raw if isinstance(raw, dict) else {}
    enabled = set(_keys(data.get("enabled")))
    required = set(_keys(data.get("required"))) & enabled
    # Identity is not optional, whatever the model decided.
    enabled |= set(registration_form.LOCKED_KEYS)

    # The order the model gave, then everything it did not mention, so the
    # proposal is always a total order over the catalogue.
    order = _keys(data.get("order"))
    order += [k for k in registration_form.FIELD_KEYS if k not in set(order)]

    fields = {
        key: {
            "enabled": key in enabled,
            "required": key in required or key in registration_form.LOCKED_KEYS,
            "badges": [],
        }
        for key in registration_form.FIELD_KEYS
    }

    return {
        "fields": fields,
        "order": order,
        "custom_fields": _custom_fields(data.get("custom_fields")),
        # Sanitized here so the preview the organizer approves is byte-for-byte
        # the theme that would be stored if they hit save.
        "theme": registration_theme.sanitize(data.get("theme")),
        "summary": event_site.clean_text(data.get("summary"), limit=400),
        "description": description,
        "asked_count": sum(1 for f in fields.values() if f["enabled"]),
        # The editor says which of the two answered, because "the keywords
        # guessed" and "the model read your brief" deserve different amounts
        # of trust from the person about to click Apply.
        "source": "keywords",
    }


# ---------------------------------------------------------------------------
# The fallback that means this never simply fails
# ---------------------------------------------------------------------------

# Keyword -> the block it turns on. Deliberately coarse: this exists so an
# organizer without an AI key, or with an unreachable provider, still gets a
# starting point instead of an error. It is not trying to be the model.
_SIGNALS: tuple[tuple[tuple[str, ...], tuple[str, ...]], ...] = (
    (("vol", "avion", "flight", "vlucht", "aéroport", "aeroport"),
     ("arrival_flight", "arrival_airport", "departure_flight", "transfer_needed",
      "passport_number", "passport_expiry", "passport_country", "date_of_birth")),
    (("hôtel", "hotel", "nuit", "chambre", "logement", "hébergement", "hebergement"),
     ("room_type", "roommate", "room_preference")),
    (("repas", "dîner", "diner", "déjeuner", "dejeuner", "banquet", "gala", "cocktail",
      "buffet", "restaurant"),
     ("dietary_requirements", "food_allergy_info")),
    (("société", "societe", "entreprise", "client", "facturation", "tva"),
     ("company", "job_title", "company_vat")),
    (("badge", "accréditation", "accreditation"), ("badge_name", "photo")),
    (("international", "étranger", "etranger", "visa"),
     ("nationality", "passport_number", "passport_expiry")),
    (("activité", "activite", "excursion", "team building", "sport", "golf"),
     ("activity_preferences", "shirt_size")),
    (("prolong", "extension", "séjour libre", "sejour libre"),
     ("extension_requested", "extension_start", "extension_end")),
)


# Briefs say what an event does NOT include at least as often as what it does
# — "sans hébergement", "pas de vol", "repas non compris". A keyword match that
# cannot see those turns every no-hotel event into one asking its guests who
# they would like to share a room with, which is worse than asking nothing.
_NEGATION = re.compile(
    r"\b(?:sans|aucune?|pas\s+d[eu']?|non\s+(?:inclus|compris|pr[ée]vus?)|"
    r"without|no|geen|zonder)\b",
    re.IGNORECASE,
)
# How far back to look for it. Long enough for "pas de vol", short enough that
# a negation about one thing does not silence the next sentence.
_NEGATION_WINDOW = 24


def _mentions(text: str, needle: str) -> bool:
    """True when the brief raises the subject without ruling it out.

    Every occurrence is checked, so "pas de vol le premier jour, vols pris en
    charge le second" still turns the travel block on: one negated mention does
    not settle the question.
    """
    start = 0
    while True:
        at = text.find(needle, start)
        if at < 0:
            return False
        if not _NEGATION.search(text[max(0, at - _NEGATION_WINDOW):at]):
            return True
        start = at + len(needle)


def _heuristic(description: str) -> dict[str, Any]:
    """A proposal built from keywords, for when there is no model to ask.

    Starts from the identity block — the only thing every event needs — and
    adds a block per signal found. An event described as "cocktail au bureau"
    ends with a name, an email and a dietary question, which is close enough to
    right that the organizer edits rather than starts over.
    """
    text = description.lower()
    enabled = {"first_name", "last_name", "email", "phone"}
    for needles, keys in _SIGNALS:
        if any(_mentions(text, needle) for needle in needles):
            enabled.update(keys)
    return _shape(
        {
            "enabled": sorted(enabled),
            "required": ["phone"] if "phone" in enabled else [],
            "summary": "Proposition établie à partir des mots-clés de votre description "
                       "(assistant IA indisponible). À ajuster avant d'appliquer.",
        },
        description,
    )


# ---------------------------------------------------------------------------
# The one entry point
# ---------------------------------------------------------------------------

def propose(description: Any) -> dict[str, Any]:
    """A complete, reviewable form configuration from a plain-language brief.

    Never raises and never writes. The caller returns this to the editor, which
    shows it as a proposal the organizer applies or discards — so a bad answer
    costs a click, not a form three hundred people have already filled in.
    """
    brief = _clean_description(description)
    if not brief:
        return _heuristic("")

    if not ai_service.ai_available():
        return _heuristic(brief)

    prompt = _PROMPT.format(
        description=brief,
        catalogue=_catalogue_for_prompt(),
        fonts=", ".join(registration_theme.FONTS),
        surfaces=", ".join(registration_theme.SURFACES),
        corners=", ".join(registration_theme.CORNERS),
        headers=", ".join(registration_theme.HEADER_STYLES),
    )
    try:
        answer = ai_service.ai_json(prompt, timeout_s=_TIMEOUT_S)
    except Exception as exc:                       # noqa: BLE001 — never fail the screen
        logger.warning("Registration assistant: provider error, falling back: %s", exc)
        answer = None

    if not isinstance(answer, dict) or not _keys(answer.get("enabled")):
        # An empty or unparseable answer is worse than the keywords: it would
        # propose a form asking nothing but a name.
        logger.info("Registration assistant: unusable model answer, using keywords")
        return _heuristic(brief)

    proposal = _shape(answer, brief)
    proposal["source"] = "ai"
    return proposal
