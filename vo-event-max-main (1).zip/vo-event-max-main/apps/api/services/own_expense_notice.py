"""
services/own_expense_notice.py — Telling somebody their extra nights are theirs.

Thirty-six people on the live event travel outside the programme's dates: 141
nights the client never booked. Somebody is going to pay for them, and the
question is settled either now, by a sentence, or later, by an invoice.

So this is a *grouped* send of *individual* letters. One email each, in their
own language, carrying their own flight dates and their own night count. What
it must never become is a mail-merge with a shared list attached: a delegate
reading that thirty-five colleagues are also extending learns nothing they
need and something they were not offered.

Three rules, all of them about tone as much as correctness.

  * **It informs; it does not invoice.** We are telling somebody what their
    own booking implies, not billing them. Nothing here quotes a price,
    because we do not know the hotel's rate and inventing one would be worse
    than saying nothing.
  * **The dates come from their file, and are shown.** "You arrive on the
    26th, three days before the programme opens" is checkable. "You have
    extra nights" is an assertion they cannot verify, and the first reply
    would be "which nights?".
  * **A wrong flight is a likely outcome, not an error case.** Our file may
    simply be out of date. Every letter says so and invites the correction,
    because a participant who has already changed their return is the one
    most likely to receive this.

Pure module: dicts in, dicts out. No database, no clock, no sending.
"""

from __future__ import annotations

import logging
from typing import Any, Iterable, Optional

from services import registration_i18n

logger = logging.getLogger(__name__)

# Somebody a single night outside the dates is usually a late flight, not an
# extension, and a letter about it reads as pedantic. The threshold is the
# organizer's to lower; this is the default the send starts from.
DEFAULT_MIN_NIGHTS = 1


_SUBJECTS = {
    "fr": "{event} — vos nuits en dehors du programme",
    "nl": "{event} — uw nachten buiten het programma",
    "en": "{event} — your nights outside the programme",
}

_OPENINGS = {
    "fr": "Bonjour {first_name},",
    "nl": "Beste {first_name},",
    "en": "Hello {first_name},",
}

_PROGRAMME = {
    "fr": "Le programme de {event} se déroule du {start} au {end}.",
    "nl": "Het programma van {event} loopt van {start} tot {end}.",
    "en": "The {event} programme runs from {start} to {end}.",
}

_INTRO = {
    "fr": "D'après les vols enregistrés à votre nom :",
    "nl": "Volgens de vluchten die op uw naam staan:",
    "en": "According to the flights we hold in your name:",
}

_ARRIVAL = {
    "fr": "arrivée le {date} — soit {days} jour(s) avant le début du programme",
    "nl": "aankomst op {date} — {days} dag(en) vóór het programma begint",
    "en": "arriving on {date} — {days} day(s) before the programme starts",
}

_DEPARTURE = {
    "fr": "départ le {date} — soit {days} jour(s) après la fin du programme",
    "nl": "vertrek op {date} — {days} dag(en) na het einde van het programma",
    "en": "leaving on {date} — {days} day(s) after the programme ends",
}

_CONSEQUENCE = {
    "fr": (
        "Cela représente {nights} nuit(s) en dehors du programme. Ces nuits ne "
        "sont pas comprises dans l'organisation : elles restent à votre charge, "
        "de même que les transferts correspondants."
    ),
    "nl": (
        "Dat zijn {nights} nacht(en) buiten het programma. Deze nachten vallen "
        "niet onder de organisatie: ze zijn voor uw eigen rekening, evenals de "
        "bijbehorende transfers."
    ),
    "en": (
        "That is {nights} night(s) outside the programme. These nights are not "
        "covered by the organisation: they are at your own expense, as are the "
        "matching transfers."
    ),
}

_CORRECTION = {
    "fr": (
        "Si ces dates ne correspondent pas à votre voyage — un vol modifié, une "
        "réservation annulée — répondez à ce message et nous corrigerons votre "
        "dossier."
    ),
    "nl": (
        "Kloppen deze data niet met uw reis — een gewijzigde vlucht, een "
        "geannuleerde boeking — antwoord dan op dit bericht en wij passen uw "
        "dossier aan."
    ),
    "en": (
        "If these dates do not match your trip — a changed flight, a cancelled "
        "booking — reply to this message and we will correct your file."
    ),
}

_CLOSINGS = {
    "fr": "Bien à vous,\n{sender}",
    "nl": "Met vriendelijke groet,\n{sender}",
    "en": "Kind regards,\n{sender}",
}


class OwnExpenseNoticeError(ValueError):
    """The event cannot support this send at all."""


def _full_name(participant: dict[str, Any]) -> str:
    return " ".join(
        part for part in (participant.get("first_name"), participant.get("last_name")) if part
    ).strip()


def _fr_date(value: Any) -> str:
    """2026-09-08 as 08/09/2026 — the way every other screen writes it."""
    parts = str(value or "").split("-")
    return f"{parts[2]}/{parts[1]}/{parts[0]}" if len(parts) == 3 else str(value or "")


def plan_notices(
    participants: list[dict[str, Any]],
    stays: Iterable[dict[str, Any]],
    *,
    min_nights: int = DEFAULT_MIN_NIGHTS,
    only: Optional[Iterable[str]] = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Who gets a letter, and who cannot get one.

    ``stays`` is ``travel_checks.staying_at_own_expense`` output — the same
    computation the master list column and the exception card are built from,
    passed in rather than repeated, so the letter can never name a different
    number of nights from the screen the organizer was looking at.

    Returns ``(notices, skipped)``. ``skipped`` matters as much as the drafts:
    "36 prepared" is only honest with the ones that were not, and the usual
    reason — no email address — is not something the send itself can fix.
    """
    by_id = {p["id"]: p for p in participants if p.get("id")}
    wanted = {str(pid) for pid in only} if only is not None else None

    notices: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []

    for stay in sorted(stays, key=lambda s: -int(s.get("extra_nights") or 0)):
        pid = str(stay.get("participant_id") or "")
        if wanted is not None and pid not in wanted:
            continue

        person = by_id.get(pid)
        if person is None:
            skipped.append({"participant_id": pid, "reason": "unknown_participant"})
            continue

        name = _full_name(person)
        nights = int(stay.get("extra_nights") or 0)
        if nights < max(1, min_nights):
            skipped.append({
                "participant_id": pid, "name": name, "reason": "below_threshold",
                "nights": nights,
            })
            continue

        if not str(person.get("email") or "").strip():
            skipped.append({"participant_id": pid, "name": name, "reason": "no_email"})
            continue

        notices.append({
            "participant_id": pid,
            "name": name,
            "email": person["email"],
            "language": registration_i18n.normalise(person.get("language")),
            "nights": nights,
            "arrives_early_days": int(stay.get("arrives_early_days") or 0),
            "stays_late_days": int(stay.get("stays_late_days") or 0),
            "first_departure": stay.get("first_departure") or "",
            "last_departure": stay.get("last_departure") or "",
        })

    return notices, skipped


def compose(
    notice: dict[str, Any],
    event_name: str,
    event_start: str,
    event_end: str,
    sender: str = "",
) -> tuple[str, str]:
    """One letter, in one person's language, about one person's dates.

    Nothing about anybody else appears in it: not how many colleagues are in
    the same position, not the total number of nights across the event, not a
    list. Somebody forwarding this to a manager should be forwarding their own
    situation and nothing more.
    """
    locale = registration_i18n.normalise(notice.get("language"))

    def line(table: dict[str, str], **kw: Any) -> str:
        return table.get(locale, table["fr"]).format(**kw)

    name = str(notice.get("name") or "")
    first_name = name.split(" ")[0] or name

    subject = line(_SUBJECTS, event=event_name)

    body: list[str] = [line(_OPENINGS, first_name=first_name), ""]
    if event_start and event_end:
        body.append(line(_PROGRAMME, event=event_name,
                         start=_fr_date(event_start), end=_fr_date(event_end)))
        body.append("")

    body.append(line(_INTRO))
    if notice.get("arrives_early_days"):
        body.append("  • " + line(_ARRIVAL,
                                  date=_fr_date(notice.get("first_departure")),
                                  days=notice["arrives_early_days"]))
    if notice.get("stays_late_days"):
        body.append("  • " + line(_DEPARTURE,
                                  date=_fr_date(notice.get("last_departure")),
                                  days=notice["stays_late_days"]))
    body.append("")

    body.append(line(_CONSEQUENCE, nights=notice.get("nights") or 0))
    body.append("")
    body.append(line(_CORRECTION))
    body.append("")
    body.append(line(_CLOSINGS, sender=sender or event_name))

    return subject, "\n".join(body)


def summarise(
    notices: list[dict[str, Any]],
    skipped: list[dict[str, Any]],
) -> dict[str, Any]:
    """What the organizer reads before pressing anything."""
    by_language: dict[str, int] = {}
    for notice in notices:
        key = notice.get("language") or "fr"
        by_language[key] = by_language.get(key, 0) + 1

    reasons: dict[str, int] = {}
    for entry in skipped:
        key = str(entry.get("reason") or "unknown")
        reasons[key] = reasons.get(key, 0) + 1

    return {
        "notices": len(notices),
        "nights": sum(int(n.get("nights") or 0) for n in notices),
        "by_language": dict(sorted(by_language.items())),
        "skipped": len(skipped),
        "skipped_reasons": dict(sorted(reasons.items())),
    }
