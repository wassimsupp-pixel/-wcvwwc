"""
services/registration_theme.py — What the public registration form LOOKS like.

`registration_form` decides which questions the form asks; `event_site` decides
what is written above it. Neither has anything to say about the page's own
appearance, so every event's form has looked identical: the same accent, the
same typeface, the same centred wordmark, whoever the event was for. An
organizer sending a link to three hundred people on behalf of a client had no
way to make the page look like the client.

This module is the third leg: a small, closed set of appearance choices, stored
per event and applied to the public page.

Three rules shape it, and they are the same three that shape the two modules
next door:

  * **A closed set, never a stylesheet.** Fonts, corner radii and surfaces are
    keys chosen from tuples defined here, and the colour is a validated hex.
    Nothing an organizer types becomes CSS. A free style field on a page open
    to the world with no login is a stored-XSS vector against every
    participant, and "let them paste CSS" is how you get one.
  * **Every value has a working default.** An event that configures nothing
    resolves to exactly the page that shipped before this existed. `resolve`
    never returns a partial theme, so the renderer never has to guess.
  * **A bad value is dropped, not raised.** The saved theme drives a page a
    participant is about to load; a single unknown key must not be able to
    fail the save, and a hand-crafted payload must not be able to reach the
    page. Unknown enum values fall back to the default and unknown keys are
    not stored at all.

Pure module: dicts in, dicts out. `fetch` is the only function that touches
the database, and it treats a missing column as "never configured" so a
deployment without migration 030 keeps serving the form it serves today.
"""

from __future__ import annotations

import re
from typing import Any, Optional

# ---------------------------------------------------------------------------
# The closed sets
# ---------------------------------------------------------------------------
#
# Each of these is a key, not a value: the web app maps the key to a CSS
# variable it controls. That indirection is the point — it means the database
# can never hold a font name, a URL or a declaration that ends up in a style
# attribute on a public page.

# The typefaces on offer. Self-hosted through next/font at build time on the
# web side, so a participant's browser never talks to a font CDN — which keeps
# the page free of a third-party request nobody consented to.
FONTS: tuple[str, ...] = ("sans", "grotesk", "serif", "slab", "rounded")
DEFAULT_FONT = "sans"

# How much the page's own furniture is rounded. Three steps rather than a
# number: a slider producing 13px corners on the card and 4px on the button is
# how a form stops looking designed.
CORNERS: tuple[str, ...] = ("sharp", "soft", "round")
DEFAULT_CORNERS = "soft"

# The page behind the form. "dark" is a genuinely different page rather than an
# inverted one — see the web side's palette.
SURFACES: tuple[str, ...] = ("light", "soft", "dark")
DEFAULT_SURFACE = "light"

# What the visitor sees first. `title` is the event's name set large, `image` a
# photo on its own, `banner` the name laid over the photo.
HEADER_STYLES: tuple[str, ...] = ("title", "image", "banner")
DEFAULT_HEADER_STYLE = "title"

ALIGNMENTS: tuple[str, ...] = ("left", "center")
DEFAULT_ALIGNMENT = "center"

HEIGHTS: tuple[str, ...] = ("compact", "tall")
DEFAULT_HEIGHT = "compact"

DEFAULT_ACCENT = "#2563eb"

_HEX_LONG = re.compile(r"^#[0-9a-f]{6}$")
_HEX_SHORT = re.compile(r"^#[0-9a-f]{3}$")

MAX_TITLE = 120
MAX_SUBTITLE = 240
MAX_URL = 500


def _one_of(value: Any, allowed: tuple[str, ...], default: str) -> str:
    """A key from the set, or the default. Never the caller's string."""
    candidate = str(value or "").strip().lower()
    return candidate if candidate in allowed else default


def clean_colour(value: Any, default: str = DEFAULT_ACCENT) -> str:
    """A hex colour fit to be written into a CSS custom property.

    Accepts `#abc` and `#aabbcc`, in any case, with or without surrounding
    space — the three shapes a colour input and a pasted brand guideline
    actually produce. Everything else is the default, because the alternative
    is a value like `red; background: url(...)` reaching a stylesheet.
    """
    text = str(value or "").strip().lower()
    if not text:
        return default
    if not text.startswith("#"):
        text = "#" + text
    if _HEX_LONG.match(text):
        return text
    if _HEX_SHORT.match(text):
        return "#" + "".join(ch * 2 for ch in text[1:])
    return default


def clean_line(value: Any, limit: int) -> str:
    """One line of organizer-written text, with anything executable removed.

    Same treatment as `event_site.clean_text` and for the same reason, minus
    the paragraph structure: a heading is one line, so newlines collapse to
    spaces rather than becoming paragraph breaks.
    """
    text = str(value or "")
    text = re.sub(r"<[^>]*>", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()[:limit]


def clean_image(value: Any) -> str:
    """An image URL fit for a public page's `src`, or "".

    Only https, for the reason `event_site.clean_image` gives: a page served
    over TLS that pulls its header photo over plaintext is a mixed-content
    warning at best and a blocked, broken-looking page at worst. Unlike that
    one this drops rather than raises — the only writer is our own upload
    endpoint, which returns a valid URL, so anything else here is a
    hand-crafted payload and deserves silence rather than a 500 that would
    also throw away the rest of the organizer's theme.
    """
    text = str(value or "").strip()
    if not text.lower().startswith("https://"):
        return ""
    if any(ch in text for ch in ('"', "'", "<", ">", "\n", "\r", "\\")):
        return ""
    return text[:MAX_URL]


def default_theme() -> dict[str, Any]:
    """The page exactly as it looked before any of this existed."""
    return {
        "font": DEFAULT_FONT,
        "accent": DEFAULT_ACCENT,
        "surface": DEFAULT_SURFACE,
        "corners": DEFAULT_CORNERS,
        # A photo behind the whole page (migration-free: it rides in this JSONB
        # blob). Empty means the surface's plain gradient, exactly as before.
        "background_image": "",
        "header": {
            "style": DEFAULT_HEADER_STYLE,
            "image_url": "",
            "title": "",
            "subtitle": "",
            "align": DEFAULT_ALIGNMENT,
            "height": DEFAULT_HEIGHT,
        },
    }


def sanitize(payload: Any) -> dict[str, Any]:
    """What may be STORED, built only from keys this module defines.

    The output is a whole theme, not a patch: storing partial themes would mean
    every reader had to merge against the defaults, and the day one of them
    forgot, a page would render with no accent colour at all.
    """
    raw = payload if isinstance(payload, dict) else {}
    header_raw = raw.get("header")
    header_raw = header_raw if isinstance(header_raw, dict) else {}

    style = _one_of(header_raw.get("style"), HEADER_STYLES, DEFAULT_HEADER_STYLE)
    image = clean_image(header_raw.get("image_url"))
    # A header that is meant to BE a photo, without a photo, is a blank band.
    # Fall back to the title treatment rather than render nothing.
    if style in ("image", "banner") and not image:
        style = DEFAULT_HEADER_STYLE

    return {
        "font": _one_of(raw.get("font"), FONTS, DEFAULT_FONT),
        "accent": clean_colour(raw.get("accent")),
        "surface": _one_of(raw.get("surface"), SURFACES, DEFAULT_SURFACE),
        "corners": _one_of(raw.get("corners"), CORNERS, DEFAULT_CORNERS),
        "background_image": clean_image(raw.get("background_image")),
        "header": {
            "style": style,
            "image_url": image,
            "title": clean_line(header_raw.get("title"), MAX_TITLE),
            "subtitle": clean_line(header_raw.get("subtitle"), MAX_SUBTITLE),
            "align": _one_of(header_raw.get("align"), ALIGNMENTS, DEFAULT_ALIGNMENT),
            "height": _one_of(header_raw.get("height"), HEIGHTS, DEFAULT_HEIGHT),
        },
    }


def resolve(stored: Any) -> dict[str, Any]:
    """What may be RENDERED: a complete theme, whatever is in the column.

    Deliberately identical to `sanitize` in effect. Stored rows predate any
    key added later, and a row written by an older deploy is exactly as
    partial as a hand-crafted payload — running both through the same
    completion is what stops the renderer from ever seeing a hole.
    """
    return sanitize(stored)


def is_default(theme: Any) -> bool:
    """True when this theme changes nothing.

    Lets the editor tell "never touched" from "deliberately set back to
    neutral", which is the difference between offering a starting point and
    overwriting a choice somebody just made.
    """
    return resolve(theme) == default_theme()


def fetch(supabase: Any, event_id: str) -> Optional[dict[str, Any]]:
    """This event's stored theme, or None.

    None covers never configured, configured as null, and migration 030 not
    applied on this deployment — three situations the caller treats the same
    way, by rendering the defaults. Selected on its own rather than folded
    into a wider select, because PostgREST fails the whole query when one
    column is missing and taking the form's field configuration down with the
    theme would turn a cosmetic gap into an unusable form.
    """
    try:
        resp = (
            supabase.table("events")
            .select("registration_theme")
            .eq("id", event_id)
            .limit(1)
            .execute()
        )
    except Exception:
        return None
    rows = resp.data if isinstance(resp.data, list) else []
    if not rows or not isinstance(rows[0], dict):
        return None
    stored = rows[0].get("registration_theme")
    return stored if isinstance(stored, dict) else None
