"""
routers/transfers.py — Transfers and Ground Transportation endpoints.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any
from fastapi import APIRouter, Depends, HTTPException, Query, status
from supabase import Client

from dependencies import get_current_user, get_supabase_client, verify_event_access
from models.schemas import (
    TransferResponse,
    TransferCreate,
    TransferUpdate,
    TransferBulkUpdate,
    TransferPlanApply,
    TransferSettingsUpdate,
    MessageResponse,
)
from services import dispatch_service
from services.audit_service import log_change

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get(
    "/events/{event_id}/transfers",
    response_model=list[TransferResponse],
    summary="List all transfers for an event",
)
async def list_transfers(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> list[TransferResponse]:
    """
    List transfers booked for an event.
    """
    await verify_event_access(event_id, current_user, supabase)

    response = (
        supabase.table("transfers")
        .select("*, participants(first_name, last_name), flights(flight_number)")
        .eq("event_id", event_id)
        .execute()
    )

    results = []
    for row in response.data:
        part = row.get("participants")
        part_name = f"{part['first_name']} {part['last_name']}" if part else None
        fl = row.get("flights")
        flight_num = fl["flight_number"] if fl else None

        item = row.copy()
        item.pop("participants", None)
        item.pop("flights", None)
        item["participant_name"] = part_name
        item["flight_number"] = flight_num
        results.append(TransferResponse(**item))

    return results


@router.post(
    "/events/{event_id}/transfers",
    response_model=TransferResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a ground transfer booking",
)
async def create_transfer(
    event_id: str,
    body: TransferCreate,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> TransferResponse:
    """
    Create a ground transfer.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    # Verify participant is in event
    part = (
        supabase.table("participants")
        .select("id")
        .eq("id", str(body.participant_id))
        .eq("event_id", event_id)
        .single()
        .execute()
    )
    if not part.data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Participant not found in this event.",
        )

    # mode="json": TransferCreate has UUID/datetime fields that .model_dump()
    # alone would leave as non-JSON-serializable objects (see hotels.py's
    # assign_rooming_night for the same crash, confirmed via Railway logs).
    payload = body.model_dump(mode="json")
    payload["event_id"] = event_id

    result = supabase.table("transfers").insert(payload).execute()

    # Update participant has_transfer flag
    supabase.table("participants").update({"has_transfer": True}).eq("id", str(body.participant_id)).execute()

    return TransferResponse(**result.data[0])


@router.patch(
    "/transfers/{transfer_id}",
    response_model=TransferResponse,
    summary="Update transfer details",
)
async def update_transfer(
    transfer_id: str,
    body: TransferUpdate,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> TransferResponse:
    """
    Update transfer booking. Logs to audit trail.
    """
    existing = supabase.table("transfers").select("*").eq("id", transfer_id).single().execute()
    if not existing.data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Transfer not found.",
        )

    event_id = existing.data["event_id"]
    await verify_event_access(event_id, current_user, supabase, write=True)

    # mode="json": TransferUpdate.pickup_time is a datetime, and .model_dump()
    # alone leaves it as a raw Python object the Supabase client cannot
    # serialise into the request body — the same crash already fixed in
    # create_transfer above (see its comment), but never applied here because
    # nothing called this endpoint with a pickup_time until the transfers
    # list grew an edit button (2026-08-18).
    payload = body.model_dump(mode="json", exclude_none=True)

    # Direction is the one field a caller can now set that the database
    # constrains. Rejected rather than coerced: dropping somebody into a group
    # is a deliberate gesture, and silently storing a third value would make
    # them vanish from both lists.
    direction = payload.get("transfer_type")
    if direction is not None and direction not in (dispatch_service.ARRIVAL, dispatch_service.DEPARTURE):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="transfer_type doit valoir 'arrival' ou 'departure'.",
        )

    user_id = current_user["id"]

    for field, new_val in payload.items():
        old_val = str(existing.data.get(field) or "")
        new_val_str = str(new_val)
        if old_val != new_val_str:
            log_change(
                supabase=supabase,
                event_id=event_id,
                user_id=user_id,
                entity_type="transfer",
                entity_id=transfer_id,
                field_name=field,
                old_value=old_val,
                new_value=new_val_str,
                reason="manual_edit",
                source="manual_update",
            )

    result = supabase.table("transfers").update(payload).eq("id", transfer_id).execute()
    return TransferResponse(**result.data[0])


@router.post(
    "/events/{event_id}/transfers/bulk-update",
    summary="Apply one edit to many transfers at once",
)
async def bulk_update_transfers(
    event_id: str,
    body: TransferBulkUpdate,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Change the same fields on a list of transfers, in one write.

    Two things this does that a loop of PATCHes on the client cannot:

      * **One access check.** Not one per transfer, which on a few hundred
        rows was hundreds of concurrent requests each re-reading the event.
      * **All or nothing on the scope.** Only transfers that belong to
        `event_id` are touched, and ids that do not are reported back rather
        than silently ignored — a stale browser tab holding deleted ids should
        say so, not appear to succeed.

    Pickup TIME is accepted but the UI never sends it for a bulk edit: each
    group's time comes from its own flight, so one value applied to all of
    them would be wrong for all but one.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    ids = [str(i) for i in body.transfer_ids]
    if not ids:
        return {"updated": 0, "skipped": []}

    payload = body.patch.model_dump(mode="json", exclude_none=True)
    if not payload:
        return {"updated": 0, "skipped": []}

    direction = payload.get("transfer_type")
    if direction is not None and direction not in (dispatch_service.ARRIVAL, dispatch_service.DEPARTURE):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="transfer_type doit valoir 'arrival' ou 'departure'.",
        )

    # Scoped to this event on purpose: the ids arrive from a browser, and an
    # id from another event must not be editable through this door.
    try:
        owned = (
            supabase.table("transfers")
            .select("id")
            .eq("event_id", event_id)
            .in_("id", ids)
            .execute()
        ).data or []
    except Exception as exc:
        logger.error("Bulk transfer update: could not read transfers for %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible de lire les transferts de cet événement.",
        ) from exc

    owned_ids = [str(row["id"]) for row in owned]
    skipped = sorted(set(ids) - set(owned_ids))
    if not owned_ids:
        return {"updated": 0, "skipped": skipped}

    updated = 0
    # Chunked: PostgREST puts the id list in the URL, and a few hundred UUIDs
    # is a request line long enough to be refused by a proxy.
    for start in range(0, len(owned_ids), 100):
        chunk = owned_ids[start:start + 100]
        try:
            result = (
                supabase.table("transfers")
                .update(payload)
                .eq("event_id", event_id)
                .in_("id", chunk)
                .execute()
            )
            updated += len(result.data or [])
        except Exception as exc:
            logger.error("Bulk transfer update failed on %d rows: %s", len(chunk), exc)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="La modification groupée a échoué.",
            ) from exc

    # One audit line for the batch rather than one per field per row: a bulk
    # edit is one decision, and writing hundreds of entries for it buries the
    # individual corrections the log exists to show.
    try:
        log_change(
            supabase=supabase,
            event_id=event_id,
            user_id=current_user["id"],
            entity_type="transfer",
            entity_id=owned_ids[0],
            field_name="bulk_update",
            old_value=f"{updated} transfert(s)",
            new_value=", ".join(f"{k}={v}" for k, v in sorted(payload.items())),
            reason="bulk_edit",
            source="manual_update",
        )
    except Exception as exc:
        logger.warning("Could not log bulk transfer update: %s", exc)

    return {"updated": updated, "skipped": skipped}


@router.delete(
    "/transfers/{transfer_id}",
    response_model=MessageResponse,
    summary="Delete a transfer booking",
)
async def delete_transfer(
    transfer_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> MessageResponse:
    """
    Remove transfer record.
    """
    existing = supabase.table("transfers").select("*").eq("id", transfer_id).single().execute()
    if not existing.data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Transfer not found.",
        )

    event_id = existing.data["event_id"]
    participant_id = existing.data.get("participant_id")
    await verify_event_access(event_id, current_user, supabase, write=True)

    supabase.table("transfers").delete().eq("id", transfer_id).execute()

    # A participant whose only transfer was just deleted must stop reading as
    # "has a transfer" — otherwise the coverage card and the master list both
    # keep vouching for a booking that no longer exists. Checked after the
    # delete so a participant with a SECOND transfer (rare, but possible if
    # one was booked twice by hand) correctly keeps the flag.
    if participant_id:
        try:
            remaining = (
                supabase.table("transfers")
                .select("id", count="exact")
                .eq("participant_id", participant_id)
                .execute()
            )
            if not (remaining.count or 0):
                supabase.table("participants").update(
                    {"has_transfer": False}
                ).eq("id", participant_id).execute()
        except Exception as exc:
            logger.warning(
                "Could not refresh has_transfer for participant %s after delete: %s",
                participant_id, exc,
            )

    return MessageResponse(message="Successfully deleted transfer booking.")


@router.post(
    "/events/{event_id}/transfers/group",
    response_model=MessageResponse,
    summary="[obsolète] Auto-group arrivals into shuttle windows",
    deprecated=True,
)
async def auto_group_shuttles(
    event_id: str,
    window_minutes: int = Query(60, ge=15, le=180, description="Size of transfer grouping window in minutes."),
    pickup_location: str = Query("BRU airport", description="Where to pick up passengers."),
    dropoff_location: str = Query("Conference Hotel", description="Where to drop off passengers."),
    vehicle_type: str = Query("Shuttle Bus", description="Vehicle type assignment."),
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> MessageResponse:
    """
    OBSOLÈTE — plus appelé par l'application depuis 2026-08-20.

    Auto-groups all arrivals into shuttle slots and writes them straight to the
    database. Superseded by `/transfers/propose` + `/transfers/apply`, which
    differ on the two things that made this one wrong:

      * it takes ONE pickup location for the whole event, defaulting to
        "BRU airport", so everybody's sheet says Brussels whether they landed
        there or not — and two people landing at two airports in the same
        window are put in the same vehicle;
      * it writes immediately, with no plan for anybody to look at first.

    Kept reachable only so an existing integration does not 404 without
    warning. Nothing in the app calls it; delete it once that is confirmed.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    # Fetch all flights for this event
    flights_res = (
        supabase.table("flights")
        .select("id, participant_id, arrival_time, departure_time, flight_number")
        .eq("event_id", event_id)
        .execute()
    )

    if not flights_res.data:
        return MessageResponse(message="No flight records found to group.")

    # The flights table holds every segment of a trip (outbound AND return)
    # with no direction marker (mirrors the flights page's own "Aller/Retour"
    # heuristic: earliest departure = outbound). A shuttle pickup is only
    # needed for the OUTBOUND arrival at the event — treating every segment
    # as an "arrival" also books a bogus BRU-airport-to-hotel shuttle for a
    # participant's return flight landing back home, days later. Keep only
    # each participant's earliest-departing flight.
    earliest_by_participant: dict[str, dict[str, Any]] = {}
    for flight in flights_res.data:
        part_id = flight.get("participant_id")
        if not part_id:
            continue
        dep = flight.get("departure_time") or ""
        current = earliest_by_participant.get(part_id)
        if current is None or dep < (current.get("departure_time") or ""):
            earliest_by_participant[part_id] = flight
    outbound_flights = list(earliest_by_participant.values())

    if not outbound_flights:
        return MessageResponse(message="No flight records found to group.")

    # Preserve transfers that came from an imported transfer file. Those rows are
    # NOT linked to a flight (flight_id IS NULL), whereas calculated shuttles always
    # carry a flight_id. If a participant already has a file-imported transfer, we
    # keep it as-is and never overwrite it with a computed shuttle.
    existing_res = (
        supabase.table("transfers")
        .select("participant_id, flight_id")
        .eq("event_id", event_id)
        .execute()
    )
    imported_participants = {
        row["participant_id"]
        for row in (existing_res.data or [])
        if row.get("participant_id") and not row.get("flight_id")
    }

    # Parse and group by window
    grouped_transfers = 0
    preserved_imported = 0
    # Group flights by rounded arrival time window
    # We round to nearest block of window_minutes
    for flight in outbound_flights:
        part_id = flight["participant_id"]
        if not part_id:
            continue

        # This participant already has a real transfer from the imported file —
        # keep it, do not compute (and do not duplicate) a shuttle for them.
        if part_id in imported_participants:
            preserved_imported += 1
            continue

        arr_time_str = flight["arrival_time"]
        try:
            arr_dt = datetime.fromisoformat(arr_time_str.replace("Z", "+00:00"))
        except Exception:
            continue

        # Round arrival time up to the next slot on a fixed grid anchored to
        # midnight (minutes-since-midnight), not to the arrival's own clock
        # hour. Anchoring to "own hour" (previous behaviour) only produced a
        # genuine window_minutes-wide bucket when window_minutes evenly
        # divides 60 (30 or 60): for 90/120 ("1h30"/"2 heures" in the UI) it
        # silently collapsed back to hourly buckets shifted by a fixed
        # offset — two flights only 20 minutes apart could land in shuttle
        # slots a full hour apart. A single midnight-anchored grid gives
        # consistent window_minutes-wide buckets for every slot size.
        minutes_since_midnight = arr_dt.hour * 60 + arr_dt.minute
        rounded_minutes = (minutes_since_midnight // window_minutes + 1) * window_minutes
        day_start = arr_dt.replace(hour=0, minute=0, second=0, microsecond=0)
        pickup_dt = day_start + timedelta(minutes=rounded_minutes)
        pickup_ts = pickup_dt.isoformat()

        # Check if transfer already exists for this participant & flight_id
        exist = (
            supabase.table("transfers")
            .select("id")
            .eq("participant_id", part_id)
            .eq("flight_id", flight["id"])
            .execute()
        )

        payload = {
            "event_id": event_id,
            "participant_id": part_id,
            "transfer_type": "arrival",
            "flight_id": flight["id"],
            "pickup_location": pickup_location,
            "dropoff_location": dropoff_location,
            "pickup_time": pickup_ts,
            "vehicle_type": vehicle_type,
            "status": "scheduled",
        }

        if exist.data:
            supabase.table("transfers").update(payload).eq("id", exist.data[0]["id"]).execute()
        else:
            supabase.table("transfers").insert(payload).execute()

        supabase.table("participants").update({"has_transfer": True}).eq("id", part_id).execute()
        grouped_transfers += 1

    if preserved_imported:
        return MessageResponse(
            message=(
                f"Successfully auto-grouped {grouped_transfers} passengers into shuttle windows. "
                f"{preserved_imported} imported transfer(s) were kept as-is."
            )
        )
    return MessageResponse(message=f"Successfully auto-grouped {grouped_transfers} passengers into shuttle windows.")


# ---------------------------------------------------------------------------
# Automatic dispatching (feedback §1)
# ---------------------------------------------------------------------------
#
# Two endpoints, deliberately. `propose` computes and returns a plan and writes
# NOTHING; `apply` persists a plan the organizer has looked at, possibly after
# editing it. The feedback is explicit that the tool suggests the obvious
# answer and the human keeps control, and one endpoint doing both would make
# that impossible to honour.


@router.get(
    "/events/{event_id}/transfer-settings",
    summary="Get the event's vehicle fleet and safety margin",
)
async def get_transfer_settings(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Always resolved: an event that was never configured comes back with the
    fleet the feedback itself lists (taxi 3, van 7, minibus 18, bus 50) rather
    than with nothing to show."""
    await verify_event_access(event_id, current_user, supabase)
    return dispatch_service.resolve_settings(_stored_transfer_settings(supabase, event_id))


@router.put(
    "/events/{event_id}/transfer-settings",
    summary="Set the event's vehicle fleet and safety margin",
)
async def set_transfer_settings(
    event_id: str,
    body: TransferSettingsUpdate,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """A vehicle with no capacity, or a margin of thirty hours, is replaced by
    the default rather than stored: these numbers drive the planner, and a
    zero-seat vehicle would make it loop forever."""
    await verify_event_access(event_id, current_user, supabase, write=True)
    clean = dispatch_service.resolve_settings(body.model_dump())
    try:
        supabase.table("events").update({"transfer_settings": clean}).eq("id", event_id).execute()
    except Exception as exc:
        logger.error("Failed to save transfer settings for event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible d'enregistrer la configuration des transferts. "
                   "La migration 011 a-t-elle été appliquée ?",
        ) from exc
    return clean


@router.post(
    "/events/{event_id}/transfers/propose",
    summary="Propose a transfer plan from the flights (writes nothing)",
)
async def propose_transfers(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """The plan the flights imply: who travels together, when, and in what.

    Read-only on purpose. The organizer accepts it, splits a group, swaps a
    vehicle or moves an hour, and only then calls `apply`.
    """
    await verify_event_access(event_id, current_user, supabase)

    settings = dispatch_service.resolve_settings(_stored_transfer_settings(supabase, event_id))
    try:
        flights = (
            supabase.table("flights")
            .select("participant_id, flight_number, departure_time, arrival_time, "
                    "departure_airport, arrival_airport")
            .eq("event_id", event_id)
            .execute()
        ).data or []
    except Exception as exc:
        logger.error("Transfer proposal: could not read flights for %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible de lire les vols de cet événement.",
        ) from exc

    inbound, outbound = _split_legs(flights)
    proposals = (
        dispatch_service.propose_arrivals(inbound, settings)
        + dispatch_service.propose_departures(outbound, settings)
    )
    _attach_names(supabase, proposals)
    return {
        "settings": settings,
        "groups": proposals,
        "summary": dispatch_service.summarise(proposals),
    }


@router.post(
    "/events/{event_id}/transfers/apply",
    summary="Persist a transfer plan the organizer has accepted",
)
async def apply_transfers(
    event_id: str,
    body: TransferPlanApply,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Write the accepted groups as real transfers.

    Only the groups in the payload are written. An organizer who deleted one on
    screen deleted it, and re-deriving the plan here would silently put it
    back — which is exactly the kind of quiet override the feedback asks us not
    to build.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    # Applying is a REPLACEMENT, not an append.
    #
    # Every write below is an insert, so without this the second apply books
    # everybody a second time — and the second apply is the normal case, not an
    # edge one: the whole point of dragging somebody into another van is to fix
    # a plan and apply it again. The master list, which reads the transfers
    # table live, would then show the person in both vans at once, and the
    # driver sheet would carry them twice.
    #
    # Scoped to the (participant, direction) pairs this payload actually
    # covers: a transfer somebody created by hand for a person the plan does
    # not mention is not ours to remove.
    replacing = {
        (str(pid), group.direction)
        for group in body.groups
        for pid in group.participant_ids
        if group.pickup_time
    }
    replaced = _clear_previous(event_id, supabase, replacing, current_user["id"])

    written = 0
    skipped = 0
    scheduled_ids: set[str] = set()
    for group in body.groups:
        vehicle_name = None
        if isinstance(group.vehicle, dict):
            vehicle_name = str(group.vehicle.get("name") or "").strip() or None
        if not group.pickup_time:
            # A group flagged "no flight time" can still be accepted so the
            # people appear on the sheet, but there is nothing to schedule.
            skipped += len(group.participant_ids)
            continue
        for participant_id in group.participant_ids:
            try:
                supabase.table("transfers").insert({
                    "event_id": event_id,
                    "participant_id": participant_id,
                    "transfer_type": group.direction,
                    "pickup_location": group.pickup_location or "-",
                    "dropoff_location": group.dropoff_location or "-",
                    "pickup_time": group.pickup_time,
                    "vehicle_type": vehicle_name,
                    "status": "scheduled",
                }).execute()
                written += 1
                scheduled_ids.add(str(participant_id))
            except Exception as exc:
                logger.warning("Could not write transfer for %s: %s", participant_id, exc)

    if written:
        try:
            # Only the people a transfer was actually WRITTEN for. Flagging
            # everybody in the payload marked the skipped groups too — the
            # return flights with no time on them, the ones the response
            # itself reports as "à planifier à la main" — so they vanished
            # from the "Sans transfert" list that exists to catch them, while
            # the master list showed no transfer against their name. The one
            # list that was supposed to notice was the one being silenced.
            ids = sorted(scheduled_ids)
            for i in range(0, len(ids), 50):
                supabase.table("participants").update({"has_transfer": True}).in_(
                    "id", ids[i:i + 50]
                ).execute()
        except Exception as exc:
            logger.warning("Could not flag has_transfer after apply: %s", exc)

    return {"written": written, "skipped": skipped, "replaced": replaced}


def _clear_previous(
    event_id: str,
    supabase: Client,
    pairs: set[tuple[str, str]],
    user_id: str,
) -> int:
    """Drop the transfers this apply is about to write over.

    Read first, then delete by id: a blind delete on (participant, direction)
    would also take a transfer somebody typed in by hand for a leg the plan
    never proposed. Reading tells us exactly what is going, which is also what
    lets each removal be logged — a booking disappearing from a driver's sheet
    has to be answerable afterwards.
    """
    if not pairs:
        return 0

    participant_ids = sorted({pid for pid, _ in pairs})
    doomed: list[dict[str, Any]] = []
    try:
        for i in range(0, len(participant_ids), 50):
            rows = (
                supabase.table("transfers")
                .select("id, participant_id, transfer_type, pickup_time")
                .eq("event_id", event_id)
                .in_("participant_id", participant_ids[i:i + 50])
                .execute()
            ).data or []
            doomed.extend(
                r for r in rows
                if (str(r.get("participant_id")), str(r.get("transfer_type"))) in pairs
            )
    except Exception as exc:
        logger.warning("Could not read transfers to replace for %s: %s", event_id, exc)
        return 0

    removed = 0
    for row in doomed:
        try:
            log_change(
                supabase=supabase, event_id=event_id, user_id=user_id,
                entity_type="transfer", entity_id=row["id"],
                field_name="pickup_time",
                old_value=str(row.get("pickup_time") or ""), new_value=None,
                reason="replaced_by_new_plan", source="transfer_apply",
            )
            supabase.table("transfers").delete().eq("id", row["id"]).execute()
            removed += 1
        except Exception as exc:
            logger.warning("Could not replace transfer %s: %s", row.get("id"), exc)
    return removed


def _stored_transfer_settings(supabase: Client, event_id: str) -> Any:
    """The event's stored settings, or None before migration 011."""
    try:
        resp = (
            supabase.table("events")
            .select("transfer_settings")
            .eq("id", event_id)
            .limit(1)
            .execute()
        )
    except Exception:
        return None
    rows = resp.data if isinstance(resp.data, list) else []
    return rows[0].get("transfer_settings") if rows else None


def _attach_names(supabase: Client, proposals: list[dict[str, Any]]) -> None:
    """Add a ``participants: [{id, name}]`` list to each group, in place.

    ``dispatch_service`` stays pure — dicts in, dicts out, no database — so a
    proposal only ever carries ``participant_ids``. That is enough to compute
    with, but not enough to look at: an organizer deciding whether to move
    someone out of a group needs to see WHO is in it, not a UUID and a head
    count. Resolved here, once, for every group at once rather than per group.
    """
    ids = sorted({pid for group in proposals for pid in group.get("participant_ids", [])})
    names: dict[str, str] = {}
    for i in range(0, len(ids), 150):
        chunk = ids[i : i + 150]
        try:
            rows = (
                supabase.table("participants")
                .select("id, first_name, last_name")
                .in_("id", chunk)
                .execute()
            ).data or []
        except Exception as exc:
            logger.warning("Could not resolve participant names for dispatch: %s", exc)
            continue
        for row in rows:
            name = f"{row.get('first_name') or ''} {row.get('last_name') or ''}".strip()
            names[row["id"]] = name or row["id"]

    for group in proposals:
        group["participants"] = [
            {"id": pid, "name": names.get(pid, pid)}
            for pid in group.get("participant_ids", [])
        ]


def _event_hub(flights: list[dict[str, Any]]) -> str:
    """The airport this event is served by, read off the flights themselves.

    Everybody's way there lands at it and everybody's way home leaves from it,
    so it is by a wide margin the most frequent airport in the file — real
    data: ATH 125 times out of 250 airport mentions, every other airport under
    ten. Returns "" when nothing dominates, and every caller then falls back to
    the behaviour that does not need it.
    """
    counts: dict[str, int] = {}
    for flight in flights:
        for field in ("departure_airport", "arrival_airport"):
            code = str(flight.get(field) or "").strip().upper()
            if code:
                counts[code] = counts.get(code, 0) + 1
    if not counts:
        return ""
    top, n = max(counts.items(), key=lambda kv: kv[1])
    total = sum(counts.values())
    # Same shape of test as consolidation_service._infer_event_city: clearly
    # dominant, on a sample big enough to mean something.
    return top if n >= 6 and n >= 0.25 * total else ""


def _split_legs(flights: list[dict[str, Any]]) -> tuple[list[dict], list[dict]]:
    """Each participant's inbound leg and outbound leg.

    The flights table carries no direction marker, so for somebody with two or
    more segments the earliest departure is the way there and the latest is the
    way home — the same heuristic the flights page shows as Aller/Retour.

    A SINGLE segment used to count as an arrival, always. That was wrong for
    the people whose file holds only their way home, and the error was
    invisible while every transfer took one hardcoded pickup location: real
    data, three of them, one segment each, ATH->WAW, ATH->BRU and IST->IAH.
    Reading the airport off each person's own flight turned that into a van
    proposed at Warsaw to drive somebody to a hotel in Athens — while the
    departure transfer they actually needed was never proposed at all.

    So a lone segment is placed by where it goes: leaving the event's own
    airport makes it a way home, anything else a way there. With no
    identifiable hub the old assumption stands, because it is still the more
    common case.
    """
    hub = _event_hub(flights)

    by_participant: dict[str, list[dict]] = {}
    for flight in flights:
        pid = flight.get("participant_id")
        if pid:
            by_participant.setdefault(pid, []).append(flight)

    inbound: list[dict] = []
    outbound: list[dict] = []
    for segments in by_participant.values():
        ordered = sorted(segments, key=lambda f: str(f.get("departure_time") or ""))
        if len(ordered) > 1:
            inbound.append(ordered[0])
            outbound.append(ordered[-1])
            continue
        lone = ordered[0]
        leaves_hub = hub and str(lone.get("departure_airport") or "").strip().upper() == hub
        (outbound if leaves_hub else inbound).append(lone)
    return inbound, outbound
