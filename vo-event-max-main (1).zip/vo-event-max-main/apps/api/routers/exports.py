"""
routers/exports.py — Export generation and download endpoints.

Routes:
  POST  /api/events/{event_id}/exports          Generate an Excel export
  GET   /api/exports/{export_id}/download       Get a signed download URL
"""

from __future__ import annotations

import logging
import re
import unicodedata
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from supabase import Client

import config
from dependencies import get_current_user, get_supabase_client, verify_event_access
from models.schemas import (
    ExportDownloadResponse, ExportRequest, ExportResponse, MessageResponse,
    NotePresetsUpdate, ParticipantNoteCreate, SupplierExportRequest,
)
from services import (
    export_diff, export_service, master_list_service, note_presets, note_service,
    room_service, supplier_export,
)

logger = logging.getLogger(__name__)

router = APIRouter()


def _export_slug(event_id: str, supabase: Client) -> str:
    """
    A filename built from the event's NAME.

    The export used to be called ``export_8c805e54_20260812.xlsx``: eight
    characters of a UUID, meaningless the moment the file leaves the app and
    lands in a client's Downloads folder beside a dozen others.

    Accents are folded and anything that is not a letter, digit or dash is
    dropped, because this string also becomes a Supabase Storage path — a
    slash or a quote there would break the upload, and a bare space breaks the
    Content-Disposition header some browsers write. Falls back to the old
    UUID form if the event cannot be read, so an export never fails over a
    cosmetic detail.
    """
    name = ""
    try:
        resp = supabase.table("events").select("name").eq("id", event_id).single().execute()
        name = str((resp.data or {}).get("name") or "").strip()
    except Exception as exc:
        logger.warning("Could not read the event name for the export filename: %s", exc)

    slug = "".join(
        c for c in unicodedata.normalize("NFD", name)
        if unicodedata.category(c) != "Mn"
    )
    slug = re.sub(r"[^A-Za-z0-9]+", "-", slug).strip("-")[:60]
    return f"master-list_{slug}" if slug else f"export_{event_id[:8]}"


# ---------------------------------------------------------------------------
# POST /api/events/{event_id}/exports
# ---------------------------------------------------------------------------

@router.post(
    "/events/{event_id}/exports",
    response_model=ExportResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Generate an Excel export for a consolidation run",
)
async def create_export(
    event_id: str,
    body: ExportRequest,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> ExportResponse:
    """
    Generate a multi-sheet Excel workbook for the given consolidation run and
    upload it to Supabase Storage (private bucket).

    Sheets generated:
    1. **Master List** — all participants with colour-coded completeness rows
    2. **Exceptions** — unresolved exceptions from the run
    3. **Summary** — run statistics and metadata
    4. **Change Log** — last 500 change log entries for the event

    The export is stored privately; use ``GET /api/exports/{export_id}/download``
    to obtain a time-limited signed URL.
    """
    await verify_event_access(event_id, current_user, supabase)

    # Verify the run exists and belongs to this event
    run_id = body.run_id
    if not run_id:
        # Find latest completed consolidation run
        try:
            runs_resp = (
                supabase.table("consolidation_runs")
                .select("id, status")
                .eq("event_id", event_id)
                .eq("status", "completed")
                .order("started_at", desc=True)
                .limit(1)
                .execute()
            )
        except Exception as exc:
            logger.error("Failed to query latest completed run for event %s: %s", event_id, exc)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to find latest consolidation run.",
            ) from exc

        if not runs_resp.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No completed consolidation run found to export.",
            )
        run_id = uuid.UUID(runs_resp.data[0]["id"])
        run_status = runs_resp.data[0]["status"]
    else:
        try:
            run_resp = (
                supabase.table("consolidation_runs")
                .select("id, status")
                .eq("id", str(run_id))
                .eq("event_id", event_id)
                .single()
                .execute()
            )
        except Exception as exc:
            logger.error("Failed to verify specified run %s: %s", run_id, exc)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Consolidation run not found.",
            ) from exc
            
        if not run_resp.data:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Consolidation run not found.")
        run_status = run_resp.data["status"]

    if run_status != "completed":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Cannot export an incomplete or failed consolidation run.",
        )

    # Generate Excel bytes
    try:
        excel_bytes: bytes = await export_service.generate_excel(
            event_id=event_id,
            run_id=str(run_id),
            user_id=current_user["id"],
            supabase=supabase,
            role=current_user.get("role", "viewer"),
        )
    except Exception as exc:
        logger.error("Excel generation failed for event %s run %s: %s", event_id, body.run_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate Excel export.",
        ) from exc

    # Upload to Supabase Storage
    export_id = str(uuid.uuid4())
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    # The event's NAME, not eight characters of its UUID. The file lands in a
    # client's Downloads folder next to a dozen others; "export_8c805e54_…"
    # tells nobody which event it is.
    filename = f"{_export_slug(event_id, supabase)}_{timestamp}.xlsx"
    storage_path = f"exports/{event_id}/{export_id}/{filename}"

    try:
        supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).upload(
            path=storage_path,
            file=excel_bytes,
            file_options={
                "content-type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            },
        )
    except Exception as exc:
        logger.error("Failed to upload export to storage: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Export generated but upload to storage failed.",
        ) from exc

    # Register in exports table
    export_record = {
        "id": export_id,
        "run_id": str(run_id),
        "event_id": event_id,
        "storage_path": storage_path,
        "filename": filename,
        "created_by": current_user["id"],
    }
    # What this file says, so the NEXT one can tell the supplier what moved
    # (feedback §7). Written after the workbook, and after reading the previous
    # snapshot inside generate_excel — an export must never diff against
    # itself.
    try:
        _store_snapshot(
            supabase, event_id, export_id,
            export_diff.snapshot(master_list_service.build_master_rows(supabase, event_id)),
            current_user["id"],
        )
    except Exception as exc:
        logger.info("Could not snapshot this export: %s", exc)

    try:
        result = supabase.table("exports").insert(export_record).execute()
    except Exception as exc:
        logger.error("Failed to register export record: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Export uploaded but metadata registration failed.",
        ) from exc

    logger.info(
        "Export created: export_id=%s event_id=%s run_id=%s user=%s",
        export_id, event_id, run_id, current_user["id"],
    )

    return ExportResponse(**result.data[0])


# ---------------------------------------------------------------------------
# GET /api/exports/{export_id}/download
# ---------------------------------------------------------------------------

@router.get(
    "/exports/{export_id}/download",
    response_model=ExportDownloadResponse,
    summary="Get a signed download URL for an export file (valid 1 hour)",
)
async def download_export(
    export_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> ExportDownloadResponse:
    """
    Return a time-limited (1 hour) signed URL for downloading an export file.

    The file is stored in a private Supabase Storage bucket and cannot be
    accessed directly. The signed URL is single-use in the sense that it
    expires after 3600 seconds.
    """
    # Load export metadata
    try:
        export_resp = (
            supabase.table("exports")
            .select("*")
            .eq("id", export_id)
            .single()
            .execute()
        )
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Export not found.") from exc

    if not export_resp.data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Export not found.")

    export = export_resp.data

    # Verify the caller can access this event's exports
    await verify_event_access(export["event_id"], current_user, supabase)

    # The stored file was generated once, using whoever created IT's role —
    # dietary_requirements/food_allergy_info are baked in if that was an
    # admin/pm. This endpoint only checked event access, not role, so any
    # role with plain read access to the event could download an
    # admin-generated export's raw dietary columns even though the same
    # role gets them stripped from a FRESH export they generate themselves
    # (see 2026-07-21 audit). A non-admin/pm downloader gets a freshly
    # regenerated, role-appropriate copy instead of the original stored
    # file; admin/pm keep the fast path (serve the original as-is).
    role = current_user.get("role", "viewer")
    storage_path = export["storage_path"]

    # A supplier file is exempt: it is already narrower than anything a
    # regeneration would produce, and regenerating it would hand back a master
    # list in place of the ten columns the caller asked for.
    if role not in ("admin", "pm") and not supplier_export.is_supplier_file(export["filename"]):
        try:
            redacted_bytes = await export_service.generate_excel(
                event_id=export["event_id"],
                run_id=str(export["run_id"]),
                user_id=current_user["id"],
                supabase=supabase,
                role=role,
            )
        except Exception as exc:
            logger.error("Failed to regenerate redacted export %s for role %s: %s", export_id, role, exc)
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Failed to prepare a download for your role.",
            ) from exc

        redacted_path = f"exports/{export['event_id']}/{export_id}/redacted-{role}-{uuid.uuid4()}/{export['filename']}"
        try:
            supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).upload(
                path=redacted_path,
                file=redacted_bytes,
                file_options={
                    "content-type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                },
            )
        except Exception as exc:
            logger.error("Failed to upload redacted export %s for role %s: %s", export_id, role, exc)
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail="Failed to prepare a download for your role.",
            ) from exc
        storage_path = redacted_path

    # Generate a signed URL (3600 seconds = 1 hour)
    expiry_seconds = 3600
    try:
        signed = supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).create_signed_url(
            path=storage_path,
            expires_in=expiry_seconds,
        )
        signed_url: str = signed["signedURL"]
    except Exception as exc:
        logger.error("Failed to create signed URL for export %s: %s", export_id, exc)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Failed to generate download URL.",
        ) from exc

    expires_at = datetime.now(timezone.utc) + timedelta(seconds=expiry_seconds)

    return ExportDownloadResponse(
        export_id=uuid.UUID(export_id),
        signed_url=signed_url,
        expires_at=expires_at,
        filename=export["filename"],
    )


# ---------------------------------------------------------------------------
# Supplier exports (feedback §6)
# ---------------------------------------------------------------------------
#
# The master list carries seventy columns, passport numbers and medical
# information among them. A coach company asking for a passenger manifest
# received all of it. These endpoints send each supplier a fixed, server-side
# list of columns instead — and the sensitive ones are denied outright rather
# than merely left out, so no future edit and no ticked box can reintroduce
# them. See services/supplier_export for the denial itself.


@router.get(
    "/events/{event_id}/exports/suppliers",
    summary="List the supplier export profiles and the columns each one sends",
)
async def list_supplier_profiles(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """The columns come back with the profiles on purpose: somebody about to
    email a file to an outside company should see what is in it before it
    leaves, not after."""
    await verify_event_access(event_id, current_user, supabase)
    return {"profiles": supplier_export.available_profiles()}


def _latest_completed_run(supabase: Client, event_id: str) -> str | None:
    """The id of the most recent completed consolidation run, or None."""
    try:
        res = (
            supabase.table("consolidation_runs")
            .select("id")
            .eq("event_id", event_id)
            .eq("status", "completed")
            .order("started_at", desc=True)
            .limit(1)
            .execute()
        )
    except Exception as exc:
        logger.error("Failed to find latest run for event %s: %s", event_id, exc)
        return None
    rows = res.data or []
    return str(rows[0]["id"]) if rows else None


@router.post(
    "/events/{event_id}/exports/supplier",
    response_model=ExportResponse,
    summary="Generate an export limited to what one supplier needs",
)
async def create_supplier_export(
    event_id: str,
    body: SupplierExportRequest,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> ExportResponse:
    """Build the file, store it privately, and register it like any other
    export so it is downloaded through the same signed, expiring URL.

    No consolidation run is required: unlike the master list, a supplier sheet
    is a view of the current state, and an organizer sending the coach company
    tomorrow's pickups should not have to run a consolidation first.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    try:
        columns = supplier_export.columns_for(body.profile, body.columns)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc

    try:
        rows = master_list_service.build_master_rows(supabase, event_id)
        rows = supplier_export.enrich(
            body.profile, rows,
            room_lines=_room_lines(supabase, event_id),
            notes=_exportable_notes(supabase, event_id),
        )
        headers, values = supplier_export.build_rows(body.profile, rows, body.columns)
        excel_bytes = export_service.generate_simple_sheet(
            title=supplier_export.PROFILE_LABELS.get(body.profile, body.profile),
            headers=headers,
            rows=values,
        )
    except supplier_export.SensitiveColumnError as exc:
        # Belt and braces: columns_for already filtered. If this ever fires,
        # something is wrong enough that refusing is the only safe answer.
        logger.error("Refused a supplier export for %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc
    except Exception as exc:
        logger.error("Supplier export generation failed for %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible de generer cet export.",
        ) from exc

    # The run this export reflects. `exports.run_id` is NOT NULL, so inserting
    # None here failed EVERY supplier export: the file uploaded, the row was
    # rejected, and the only trace was "enregistrement echoue" — plus an orphan
    # file in Storage on each attempt.
    #
    # A supplier export is produced on demand rather than by a run, but it is
    # built from the master list that a run produced, so pointing at the run
    # that made that state is the truthful answer. Resolved BEFORE the upload,
    # so a refusal never leaves a file behind.
    run_id = _latest_completed_run(supabase, event_id)
    if not run_id:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Lancez d'abord une consolidation : l'export reflete la liste consolidee.",
        )

    export_id = str(uuid.uuid4())
    day = datetime.now(timezone.utc).strftime("%Y%m%d")
    filename = supplier_export.filename_for(body.profile, _export_slug(event_id, supabase), day)
    storage_path = f"exports/{event_id}/{export_id}/{filename}"

    try:
        supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).upload(
            path=storage_path,
            file=excel_bytes,
            file_options={
                "content-type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            },
        )
    except Exception as exc:
        logger.error("Failed to upload supplier export to storage: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Export genere mais televersement echoue.",
        ) from exc

    record = {
        "id": export_id,
        "run_id": run_id,
        "event_id": event_id,
        "storage_path": storage_path,
        "filename": filename,
        "created_by": current_user["id"],
    }
    try:
        result = supabase.table("exports").insert(record).execute()
    except Exception as exc:
        logger.error("Failed to register supplier export record: %s", exc)
        # The file is already in Storage and nothing will ever point at it now.
        # Left alone it accumulates one unreachable export per failed attempt.
        try:
            supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).remove([storage_path])
        except Exception:
            logger.warning("Could not clean up orphaned export %s", storage_path)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Export televerse mais enregistrement echoue.",
        ) from exc

    logger.info(
        "Supplier export created: profile=%s columns=%d event=%s user=%s",
        body.profile, len(columns), event_id, current_user["id"],
    )
    return ExportResponse(**result.data[0])


def _room_lines(supabase: Client, event_id: str) -> list[dict[str, Any]]:
    """The rooming view, or nothing before migration 012.

    Supplies the hotel sheet's room number and roommate columns. Failing here
    must cost the two columns and not the export.
    """
    try:
        participants = (
            supabase.table("participants")
            .select("id, first_name, last_name, room_type, room_number, roommate_participant_id")
            .eq("event_id", event_id)
            .execute()
        ).data or []
    except Exception:
        return []
    return room_service.participant_view(room_service.occupancy(participants))


def _exportable_notes(supabase: Client, event_id: str) -> list[dict[str, Any]]:
    """Notes somebody deliberately flagged as shareable, and only those.

    The filter is applied again in note_service.for_export against the
    profile: a flagged FLIGHT note still never reaches the hotel.
    """
    try:
        return (
            supabase.table("participant_notes")
            .select("participant_id, category, body, include_in_export")
            .eq("event_id", event_id)
            .eq("include_in_export", True)
            .execute()
        ).data or []
    except Exception:
        return []


# ---------------------------------------------------------------------------
# UPDATES between two exports (feedback §7)
# ---------------------------------------------------------------------------


def _previous_snapshot(supabase: Client, event_id: str) -> dict[str, Any] | None:
    """What the last export said, or None before migration 012 / on a first
    export. Failing here costs the UPDATES sheet, never the export."""
    try:
        resp = (
            supabase.table("export_snapshots")
            .select("payload")
            .eq("event_id", event_id)
            .order("created_at", desc=True)
            .limit(1)
            .execute()
        )
    except Exception as exc:
        logger.info("Export snapshots unavailable (migration 012 not applied?): %s", exc)
        return None
    rows = resp.data or []
    payload = rows[0].get("payload") if rows else None
    return payload if isinstance(payload, dict) else None


def _store_snapshot(
    supabase: Client, event_id: str, export_id: str, payload: dict[str, Any], user_id: str
) -> None:
    """Leave this export's own snapshot behind for the next one.

    Written AFTER the diff, so an export never compares itself to itself.
    """
    try:
        supabase.table("export_snapshots").insert({
            "event_id": event_id, "export_id": export_id,
            "payload": payload, "created_by": user_id,
        }).execute()
    except Exception as exc:
        logger.info("Could not store the export snapshot: %s", exc)


@router.get(
    "/events/{event_id}/exports/updates",
    summary="What changed since the last export",
)
async def export_updates(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """The UPDATES sheet's contents, before generating anything.

    Lets an organizer see what a supplier is about to be told, and decide
    whether the file is worth sending at all.
    """
    await verify_event_access(event_id, current_user, supabase)
    rows = master_list_service.build_master_rows(supabase, event_id)
    current = export_diff.snapshot(rows)
    changes = export_diff.diff(_previous_snapshot(supabase, event_id), current)
    return {"changes": changes, "summary": export_diff.summarise(changes)}


# ---------------------------------------------------------------------------
# Internal notes (feedback §8)
# ---------------------------------------------------------------------------


@router.get(
    "/events/{event_id}/participants/{participant_id}/notes",
    summary="Operational notes on a participant",
)
async def list_notes(
    event_id: str,
    participant_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Every note, internal ones included — this is the internal app.

    The categories come back with them so the fiche can show which of them
    could ever be shared, and with whom.
    """
    await verify_event_access(event_id, current_user, supabase)
    # Widest first: `preset_id` only exists after migration 028, and PostgREST
    # fails the WHOLE select on one unknown column — so a narrower retry keeps
    # notes working on a deployment that has not run it yet.
    columns = "id, category, body, include_in_export, author_id, created_at, preset_id"
    notes: list[dict[str, Any]] = []
    try:
        notes = (
            supabase.table("participant_notes").select(columns)
            .eq("participant_id", participant_id)
            .order("created_at", desc=True).execute()
        ).data or []
    except Exception:
        try:
            notes = (
                supabase.table("participant_notes")
                .select("id, category, body, include_in_export, author_id, created_at")
                .eq("participant_id", participant_id)
                .order("created_at", desc=True).execute()
            ).data or []
        except Exception as exc:
            logger.info("Notes unavailable (migration 012 not applied?): %s", exc)
            return {
                "notes": [], "categories": note_service.describe_categories(),
                "presets": [], "available": False,
            }
    return {
        "notes": notes,
        "categories": note_service.describe_categories(),
        "presets": note_presets.fetch(supabase, event_id),
        "available": True,
    }


@router.get(
    "/events/{event_id}/note-presets",
    summary="This event's named internal notes",
)
async def get_note_presets(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Empty before migration 028 or before any preset is saved — the notes
    screen then behaves exactly as it did before presets existed."""
    await verify_event_access(event_id, current_user, supabase)
    return {"presets": note_presets.fetch(supabase, event_id)}


@router.put(
    "/events/{event_id}/note-presets",
    summary="Save this event's named internal notes",
)
async def set_note_presets(
    event_id: str,
    body: NotePresetsUpdate,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Replaces the whole set. Deleting a preset never touches the notes
    already written from it — those keep their text and simply fall back to
    their category's colour, the same way a deleted rooming preset leaves the
    lists it generated alone."""
    await verify_event_access(event_id, current_user, supabase, write=True)
    clean = note_presets.resolve([p.model_dump() for p in body.presets])
    try:
        supabase.table("events").update({"note_presets": clean}).eq("id", event_id).execute()
    except Exception as exc:
        logger.error("Failed to save note presets for event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible d'enregistrer les presets. "
                   "La migration 028 a-t-elle été appliquée ?",
        ) from exc
    return {"presets": clean}


@router.post(
    "/events/{event_id}/participants/{participant_id}/notes",
    status_code=status.HTTP_201_CREATED,
    summary="Add an operational note",
)
async def add_note(
    event_id: str,
    participant_id: str,
    body: ParticipantNoteCreate,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Nothing is shared unless somebody deliberately says so, note by note.

    ``include_in_export`` is normalised by note_service: it is only honoured
    for a category that has a supplier destination, so ticking "share" on a
    general remark stores false rather than a flag that looks active and is
    not.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    cleaned = note_service.clean(body.body, body.category, body.include_in_export)
    if not cleaned:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Une note ne peut pas etre vide.",
        )
    row = {
        "event_id": event_id,
        "participant_id": participant_id,
        "author_id": current_user["id"],
        **cleaned,
    }
    # Only stamped when it names a preset this event actually has: an id from
    # a stale browser tab would otherwise colour a row after the preset it
    # refers to was deleted.
    preset_id = (body.preset_id or "").strip()
    if preset_id and any(p["id"] == preset_id for p in note_presets.fetch(supabase, event_id)):
        row["preset_id"] = preset_id

    try:
        result = supabase.table("participant_notes").insert(row).execute()
    except Exception as exc:
        # Before migration 028 the column does not exist. The note itself is
        # the point — save it without the stamp rather than refuse it.
        if "preset_id" in row:
            row.pop("preset_id")
            try:
                result = supabase.table("participant_notes").insert(row).execute()
                return (result.data or [{}])[0]
            except Exception:
                pass
        logger.error("Could not store a note for %s: %s", participant_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible d'enregistrer cette note. "
                   "La migration 012 a-t-elle ete appliquee ?",
        ) from exc
    return (result.data or [{}])[0]


@router.delete(
    "/events/{event_id}/participants/{participant_id}/notes/{note_id}",
    response_model=MessageResponse,
    summary="Delete an operational note",
)
async def delete_note(
    event_id: str,
    participant_id: str,
    note_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> MessageResponse:
    await verify_event_access(event_id, current_user, supabase, write=True)
    try:
        supabase.table("participant_notes").delete().eq("id", note_id).eq(
            "participant_id", participant_id
        ).execute()
    except Exception as exc:
        logger.error("Could not delete note %s: %s", note_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible de supprimer cette note.",
        ) from exc
    return MessageResponse(message="Note supprimee.")
