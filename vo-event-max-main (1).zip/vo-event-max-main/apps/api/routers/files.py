"""
routers/files.py — File upload, preview, and column mapping endpoints.

Routes:
  POST  /api/files/upload                  Upload a new source file
  GET   /api/files/{file_id}/preview       Preview columns and sample rows
  POST  /api/files/{file_id}/map-columns   Save column mapping (requires human confirmation)
  GET   /api/events/{event_id}/files       List all files for an event
  GET   /api/events/{event_id}/sources/versions      Which file replaces which (§20)
  GET   /api/files/{file_id}/replacement-impact      What replacing would change
  POST  /api/files/{file_id}/replaces/{old_file_id}  Retire the earlier version
  POST  /api/files/{file_id}/restore                 Undo a replacement
"""

from __future__ import annotations

import logging
import os
import re
import uuid
from datetime import datetime, timezone
from typing import Any

import pandas as pd
from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, HTTPException, Query, UploadFile, status
from supabase import Client

import config
from dependencies import get_current_user, get_supabase_client, is_consolidation_running, verify_event_access
from models.schemas import (
    ColumnMappingRequest,
    ColumnMappingResponse,
    FileListItem,
    FilePreviewResponse,
    FileUploadResponse,
    ColumnMappingSuggestion,
    MessageResponse,
)
from services.mapping_service import suggest_mapping, CANONICAL_FIELDS
from services.file_service import read_tabular
from services import consolidation_service, deletion_service
from services.audit_service import log_change

logger = logging.getLogger(__name__)

router = APIRouter()

ALLOWED_CONTENT_TYPES = {
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-excel",
    "text/csv",
    "application/csv",
}

_UNSAFE_STORAGE_CHARS_RE = re.compile(r"[^A-Za-z0-9._-]+")


def _safe_storage_filename(filename: str) -> str:
    """Neutralise the client-controlled filename before it becomes a segment
    of the Supabase Storage path. The {event_id}/{file_id}/ prefix is always
    server-generated, so this alone isn't a full path-traversal opening, but
    a filename like "../../other-event/x.xlsx" or one containing control/
    null characters has no business reaching a storage key unsanitised.
    original_filename (shown in the UI, used for extension detection on
    re-download) is intentionally left as the user's real name -- only the
    STORAGE PATH segment is sanitised here."""
    base = os.path.basename(filename).strip() or "upload"
    # os.path.basename only strips the OS-native separator; a filename
    # containing the OTHER slash style (e.g. a literal backslash on a
    # Linux server, or vice versa) would still smuggle path segments.
    base = base.replace("\\", "_").replace("/", "_")
    base = _UNSAFE_STORAGE_CHARS_RE.sub("_", base)
    # A bare "." or ".." SURVIVES basename (it has no separator to strip) and
    # is still a real path-traversal segment once joined into storage_path
    # ("{event_id}/{file_id}/.." resolves to "{event_id}/"). The character
    # allowlist above doesn't catch this either, since '.' itself is allowed
    # (needed for real extensions). A name that is ENTIRELY dots is never a
    # legitimate upload filename.
    if base.strip(".") == "":
        base = "upload"
    return base


def _parse_file_to_dataframe(content: bytes, filename: str) -> pd.DataFrame:
    """
    Parse raw file bytes into a Pandas DataFrame.

    Supports .xlsx, .xls, and .csv files. Raises HTTPException on parse error.

    Parameters
    ----------
    content: Raw file bytes.
    filename: Original filename (used to determine extension).
    """
    try:
        return read_tabular(content, filename)
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("Could not parse file %s: %s", filename, exc)
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Could not parse file: {exc}",
        ) from exc


def _df_sample(df: pd.DataFrame, n: int) -> list[dict[str, Any]]:
    """Return first ``n`` rows as list-of-dicts, safe for JSON."""
    return df.head(n).to_dict(orient="records")


# ---------------------------------------------------------------------------
# POST /api/files/upload
# ---------------------------------------------------------------------------

@router.post(
    "/files/upload",
    response_model=FileUploadResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Upload a source file for an event",
)
async def upload_file(
    background_tasks: BackgroundTasks,
    event_id: str = Form(..., description="UUID of the event this file belongs to."),
    source_type: str = Form(..., description="Source type: registration | fcm | email | hotel | transfer | activity | other"),
    file: UploadFile = File(..., description="The file to upload (.xlsx, .xls, .csv). Max 50 MB."),
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> FileUploadResponse:
    """
    Upload a raw source file for an event.

    Validation:
    - Extension must be .xlsx, .xls, or .csv
    - File size must not exceed 50 MB
    - event_id must belong to the caller's organisation

    The file is:
    1. Parsed with Pandas to extract columns and sample rows
    2. Uploaded to Supabase Storage at ``{event_id}/{file_id}/{filename}``
    3. Registered in the ``uploaded_files`` table with status ``pending``

    Returns column names and the first 5 rows so the frontend can
    immediately show the column-mapping UI.
    """
    # --- Validate extension ---
    filename: str = file.filename or "upload"
    ext = os.path.splitext(filename)[1].lower()
    if ext not in config.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=f"Unsupported file format '{ext}'. Accepted: {sorted(config.ALLOWED_EXTENSIONS)}",
        )

    # --- Read content + size check ---
    content: bytes = await file.read()
    if len(content) > config.MAX_UPLOAD_SIZE_BYTES:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail="File exceeds the maximum allowed size of 50 MB.",
        )

    # --- Verify event access ---
    await verify_event_access(event_id, current_user, supabase, write=True)

    # --- Parse with Pandas ---
    df = _parse_file_to_dataframe(content, filename)
    columns: list[str] = df.columns.tolist()
    row_count: int = len(df)
    sample_rows = _df_sample(df, 5)

    # --- Upload to Supabase Storage ---
    file_id = str(uuid.uuid4())
    storage_path = f"{event_id}/{file_id}/{_safe_storage_filename(filename)}"

    try:
        supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).upload(
            path=storage_path,
            file=content,
            file_options={"content-type": file.content_type or "application/octet-stream"},
        )
    except Exception as exc:
        logger.error("Supabase Storage upload failed for %s: %s", storage_path, exc)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="File storage upload failed. Please try again.",
        ) from exc

    # --- Register in uploaded_files table ---
    record = {
        "id": file_id,
        "event_id": event_id,
        "original_filename": filename,
        "storage_path": storage_path,
        "source_type": source_type,
        "row_count": row_count,
        "column_count": len(columns),
        "import_status": "pending",
        "imported_by": current_user["id"],
    }
    try:
        supabase.table("uploaded_files").insert(record).execute()
    except Exception as exc:
        logger.error("Failed to register uploaded_file record: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="File uploaded but metadata registration failed.",
        ) from exc

    logger.info(
        "File uploaded: file_id=%s event_id=%s rows=%d cols=%d user=%s",
        file_id, event_id, row_count, len(columns), current_user["id"],
    )

    raw_suggestions = suggest_mapping(columns, sample_rows)
    mapping_suggestions = {
        col: ColumnMappingSuggestion(**sug) for col, sug in raw_suggestions.items()
    }
    canonical_fields_list = sorted(list(CANONICAL_FIELDS))

    # FULLY AUTOMATIC pipeline, but OFF the request path: the AI mapping (slow on
    # the free tier) + consolidation run in the BACKGROUND so the upload returns
    # instantly. The file lands 'pending'; the background task maps it and
    # consolidates. The frontend polls the run for progress.
    import_status = "pending"
    background_tasks.add_task(
        consolidation_service.auto_map_and_consolidate,
        file_id=file_id,
        event_id=event_id,
        columns=columns,
        sample_rows=sample_rows,
        user_id=current_user["id"],
        supabase=supabase,
    )

    return FileUploadResponse(
        file_id=uuid.UUID(file_id),
        original_filename=filename,
        source_type=source_type,
        row_count=row_count,
        column_count=len(columns),
        columns=columns,
        sample_rows=sample_rows,
        import_status=import_status,
        mapping_suggestions=mapping_suggestions,
        canonical_fields=canonical_fields_list,
    )


# ---------------------------------------------------------------------------
# GET /api/files/{file_id}/preview
# ---------------------------------------------------------------------------

@router.get(
    "/files/{file_id}/preview",
    response_model=FilePreviewResponse,
    summary="Preview columns and sample rows of an uploaded file",
)
async def preview_file(
    file_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> FilePreviewResponse:
    """
    Return the column list and first 10 rows of an uploaded file.

    Fetches the file from Supabase Storage, parses it in-memory.
    Does NOT require the file to be in ``mapped`` status.
    """
    # Load the file metadata
    meta_resp = (
        supabase.table("uploaded_files")
        .select("*")
        .eq("id", file_id)
        .single()
        .execute()
    )
    if not meta_resp.data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found.")

    meta = meta_resp.data
    await verify_event_access(meta["event_id"], current_user, supabase)

    # Download from Supabase Storage
    try:
        raw: bytes = supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).download(
            meta["storage_path"]
        )
    except Exception as exc:
        logger.error("Storage download failed for %s: %s", meta["storage_path"], exc)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Could not retrieve file from storage.",
        ) from exc

    df = _parse_file_to_dataframe(raw, meta["original_filename"])
    columns = df.columns.tolist()
    sample_rows = _df_sample(df, 10)

    raw_suggestions = suggest_mapping(columns, sample_rows)
    mapping_suggestions = {
        col: ColumnMappingSuggestion(**sug) for col, sug in raw_suggestions.items()
    }
    canonical_fields_list = sorted(list(CANONICAL_FIELDS))

    # Points 5+6: has THIS PROJECT confirmed a mapping for a layout shaped
    # exactly like this one before? Read-only lookup — nothing here writes;
    # the background auto-map job (services.consolidation_service
    # .auto_map_and_consolidate) is what actually pre-fills column_mapping on
    # the file. This just tells the screen whether what it is about to show
    # is a fresh suggestion or a remembered answer, so the copy can say which.
    remembered = False
    try:
        org_id = consolidation_service._user_org_id(supabase, current_user["id"])
        project_id = consolidation_service.event_project_id(supabase, meta["event_id"])
        signature = consolidation_service.format_signature(meta.get("source_type"), columns)
        remembered = bool(
            consolidation_service.known_format_mapping(supabase, org_id, project_id, signature)
        )
    except Exception as exc:
        logger.info("Could not check mapping memory for file %s: %s", file_id, exc)

    return FilePreviewResponse(
        file_id=uuid.UUID(file_id),
        columns=columns,
        row_count=len(df),
        sample_rows=sample_rows,
        mapping_suggestions=mapping_suggestions,
        canonical_fields=canonical_fields_list,
        # Stored auto-mapping + per-column report (present once the background
        # auto-map has run — i.e. exactly when the file is in 'review').
        column_mapping=meta.get("column_mapping") or None,
        mapping_report=meta.get("mapping_report") or None,
        remembered=remembered,
    )


# ---------------------------------------------------------------------------
# POST /api/files/{file_id}/map-columns
# ---------------------------------------------------------------------------

@router.post(
    "/files/{file_id}/map-columns",
    response_model=ColumnMappingResponse,
    summary="Save column mapping for a file (requires human confirmation)",
)
async def map_columns(
    file_id: str,
    body: ColumnMappingRequest,
    background_tasks: BackgroundTasks,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> ColumnMappingResponse:
    """
    Save the column-to-field mapping for an uploaded file.

    **``confirmed`` must be ``true``** — this is a hard gate that enforces
    human review of the mapping before it is persisted. Used to confirm a
    brand-new format the first time it is seen (files in ``review`` status).

    On success the file transitions to ``mapped``, the confirmed layout is
    memorised org-wide so the SAME format is never reviewed again, and a
    consolidation is kicked off in the background.
    """
    # The Pydantic validator already ensures confirmed=True, but double-check
    if not body.confirmed:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Column mapping must be confirmed by a human reviewer (confirmed=true).",
        )

    # Load file metadata and check event access
    meta_resp = (
        supabase.table("uploaded_files")
        .select("id, event_id, import_status, source_type")
        .eq("id", file_id)
        .single()
        .execute()
    )
    if not meta_resp.data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found.")

    meta = meta_resp.data
    await verify_event_access(meta["event_id"], current_user, supabase, write=True)

    if meta["import_status"] == "processed":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="This file has already been processed. Create a new upload to re-map.",
        )

    # Persist mapping and advance status
    try:
        supabase.table("uploaded_files").update(
            {"column_mapping": body.mapping, "import_status": "mapped"}
        ).eq("id", file_id).execute()
    except Exception as exc:
        logger.error("Failed to save column mapping for file %s: %s", file_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to save column mapping.",
        ) from exc

    logger.info(
        "Column mapping saved: file_id=%s user=%s fields=%s",
        file_id, current_user["id"], list(body.mapping.values()),
    )

    # Memorise this format for THIS PROJECT (points 5+6) so the next matching
    # upload in the same project arrives pre-filled, ready to verify instead
    # of mapped from scratch. Never crosses into another project, even in the
    # same org — a client's confirmed column meaning is that client's alone.
    try:
        org_id = consolidation_service._user_org_id(supabase, current_user["id"])
        project_id = consolidation_service.event_project_id(supabase, meta["event_id"])
        signature = consolidation_service.format_signature(
            meta.get("source_type"), list(body.mapping.keys())
        )
        consolidation_service.remember_format(
            supabase, org_id, project_id, meta.get("source_type"),
            signature, body.mapping, current_user["id"],
        )
    except Exception as exc:
        logger.warning("Could not memorise format for file %s: %s", file_id, exc)

    # Now that the mapping is confirmed, fuse the file into the master list.
    background_tasks.add_task(
        consolidation_service.start_and_run_consolidation,
        event_id=meta["event_id"],
        user_id=current_user["id"],
        supabase=supabase,
    )

    return ColumnMappingResponse(
        file_id=uuid.UUID(file_id),
        import_status="mapped",
        mapping=body.mapping,
        message="Column mapping saved. File is ready for consolidation.",
    )


# ---------------------------------------------------------------------------
# GET /api/events/{event_id}/files
# ---------------------------------------------------------------------------

@router.get(
    "/events/{event_id}/files",
    response_model=list[FileListItem],
    summary="List all uploaded files for an event",
)
async def list_event_files(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> list[FileListItem]:
    """
    Return all files uploaded for a given event, ordered by upload time descending.

    Includes import status and error information so the frontend can show
    processing state for each file.
    """
    await verify_event_access(event_id, current_user, supabase)

    try:
        result = (
            supabase.table("uploaded_files")
            .select(
                "id, original_filename, source_type, row_count, column_count, "
                "import_status, imported_at, error_message"
            )
            .eq("event_id", event_id)
            .order("imported_at", desc=True)
            .execute()
        )
    except Exception as exc:
        logger.error("Failed to list files for event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve file list.",
        ) from exc

    return [FileListItem(**row) for row in result.data]


# ---------------------------------------------------------------------------
# Replace Source (feedback §20)
# ---------------------------------------------------------------------------
#
# Every upload is an Add/Update today, which is right for FCM Week 1 → Week 2:
# Week 2 does not invalidate Week 1, and somebody who only appeared in Week 1
# still has a real hotel booking. What was missing is the other intention — a
# corrected version of a file already imported, where keeping both means the
# master list is fed by a file somebody explicitly withdrew.
#
# Replacing is reversible and never deletes a participant. The old file stops
# being read; its rows stay for the audit trail; anybody it was the only source
# for is NAMED, and a human decides.


def _live_files(supabase: Client, event_id: str) -> list[dict[str, Any]]:
    """Every uploaded file of the event, with the §20 columns when they exist."""
    try:
        return (
            supabase.table("uploaded_files")
            .select("*")
            .eq("event_id", event_id)
            .order("imported_at", desc=True)
            .execute()
        ).data or []
    except Exception as exc:
        logger.error("Failed to load files for event %s: %s", event_id, exc)
        return []


def _records_of(supabase: Client, file_id: str) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    offset = 0
    while True:
        try:
            res = (
                supabase.table("source_records")
                .select("id, participant_id, normalized_data")
                .eq("file_id", file_id)
                .range(offset, offset + 999)
                .execute()
            )
        except Exception as exc:
            logger.warning("Could not read records of file %s: %s", file_id, exc)
            return out
        rows = res.data or []
        out.extend(rows)
        if len(rows) < 1000:
            return out
        offset += 1000


@router.get(
    "/events/{event_id}/sources/versions",
    summary="Which files could be replacing which (feedback §20)",
)
async def source_versions_overview(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Per file, the earlier live files of the same kind it could replace.

    Same source_type is the whole test. A hotel list never replaces an FCM
    export however similar the filenames look, and offering it would let
    somebody retire the wrong file with one click.
    """
    await verify_event_access(event_id, current_user, supabase)

    from services import source_versions

    files = _live_files(supabase, event_id)
    available = any("superseded_at" in f for f in files)

    return {
        "available": available,
        "files": [
            {
                "id": f["id"],
                "filename": f.get("original_filename"),
                "source_type": f.get("source_type"),
                "row_count": f.get("row_count"),
                "imported_at": f.get("imported_at"),
                "import_status": f.get("import_status"),
                "superseded_at": f.get("superseded_at"),
                "superseded_by": f.get("superseded_by"),
                "replaceable": [
                    {"id": c["id"], "filename": c.get("original_filename"),
                     "imported_at": c.get("imported_at"), "row_count": c.get("row_count")}
                    for c in source_versions.candidates(files, f)
                ],
            }
            for f in files
        ],
    }


@router.get(
    "/files/{file_id}/replacement-impact",
    summary="What replacing an earlier file with this one would change",
)
async def replacement_impact(
    file_id: str,
    replaces: str = Query(..., description="The file this one would replace."),
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """The preview that makes Replace a decision rather than a leap.

    Reads both files' already-parsed rows rather than re-downloading them, so
    what you see is what the engine actually holds — and reports the people who
    would be left with no live source at all, which is the question that
    actually matters.
    """
    from services import source_versions
    from services.consolidation_service import _norm_name

    new_file = _file_or_404(supabase, file_id)
    old_file = _file_or_404(supabase, replaces)
    event_id = new_file["event_id"]
    if old_file["event_id"] != event_id:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Both files must belong to the same event.")
    if old_file.get("source_type") != new_file.get("source_type"):
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "A file can only replace another of the same source type.",
        )
    await verify_event_access(event_id, current_user, supabase, write=True)

    old_records = _records_of(supabase, replaces)
    new_records = _records_of(supabase, file_id)
    report = source_versions.impact(old_records, new_records, _norm_name)

    # Everything still live once the old file is gone — including this one.
    other_live: list[dict[str, Any]] = []
    for f in _live_files(supabase, event_id):
        if f["id"] in (replaces,) or f.get("superseded_at"):
            continue
        other_live.extend(_records_of(supabase, f["id"]))

    orphan_ids = source_versions.orphaned(old_records, other_live)
    return {
        **report,
        "summary_line": source_versions.describe(report),
        "orphaned": _named(supabase, event_id, orphan_ids),
        "old_file": {"id": replaces, "filename": old_file.get("original_filename")},
        "new_file": {"id": file_id, "filename": new_file.get("original_filename")},
    }


@router.post(
    "/files/{file_id}/replaces/{old_file_id}",
    summary="Mark an earlier file as replaced by this one",
)
async def replace_source(
    file_id: str,
    old_file_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Retire the old file. Reversible, and nobody is deleted.

    Two things happen. The file is stamped superseded, so consolidation stops
    loading it. And its rows are unlinked from their participants, so the
    enrichment steps — which read a participant's rows directly — stop hearing
    a file that has been withdrawn. The rows themselves are kept.
    """
    from services import source_versions
    from services.consolidation_service import _norm_name

    new_file = _file_or_404(supabase, file_id)
    old_file = _file_or_404(supabase, old_file_id)
    event_id = new_file["event_id"]
    if old_file["event_id"] != event_id:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Both files must belong to the same event.")
    if old_file.get("source_type") != new_file.get("source_type"):
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "A file can only replace another of the same source type.",
        )
    if old_file_id == file_id:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "A file cannot replace itself.")
    await verify_event_access(event_id, current_user, supabase, write=True)

    old_records = _records_of(supabase, old_file_id)
    try:
        supabase.table("uploaded_files").update({
            "superseded_at": datetime.now(timezone.utc).isoformat(),
            "superseded_by": file_id,
            "superseded_reason": f"Remplacé par {new_file.get('original_filename') or file_id}",
        }).eq("id", old_file_id).execute()
    except Exception as exc:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            "Replacing a source needs migration 017 (uploaded_files.superseded_at).",
        ) from exc

    unlinked = 0
    ids = [r["id"] for r in old_records if r.get("participant_id")]
    for i in range(0, len(ids), 100):
        chunk = ids[i:i + 100]
        try:
            supabase.table("source_records").update(
                {"participant_id": None}
            ).in_("id", chunk).execute()
            unlinked += len(chunk)
        except Exception as exc:
            logger.warning("Could not unlink replaced rows: %s", exc)

    log_change(
        supabase, event_id=event_id, user_id=current_user["id"],
        entity_type="uploaded_file", entity_id=old_file_id,
        field_name="superseded_by", old_value=None, new_value=file_id,
        reason="replace_source", source="manual_update",
    )

    other_live: list[dict[str, Any]] = []
    for f in _live_files(supabase, event_id):
        if f["id"] == old_file_id or f.get("superseded_at"):
            continue
        other_live.extend(_records_of(supabase, f["id"]))

    return {
        "superseded": old_file_id,
        "by": file_id,
        "rows_unlinked": unlinked,
        # Named, never deleted: somebody with a room and a transfer is still
        # going on the trip, whatever a re-exported spreadsheet says.
        "orphaned": _named(
            supabase, event_id, source_versions.orphaned(old_records, other_live)
        ),
        "next_step": "Relancez une consolidation pour que la master list reflète le remplacement.",
    }


@router.post(
    "/files/{file_id}/restore",
    summary="Undo a replacement",
)
async def restore_source(
    file_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Put a superseded file back in service.

    The rows were never deleted, so this is a real undo rather than a
    re-import — the next consolidation re-links them.
    """
    file_row = _file_or_404(supabase, file_id)
    await verify_event_access(file_row["event_id"], current_user, supabase, write=True)

    try:
        supabase.table("uploaded_files").update({
            "superseded_at": None, "superseded_by": None, "superseded_reason": None,
        }).eq("id", file_id).execute()
    except Exception as exc:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            "Restoring a source needs migration 017.",
        ) from exc

    return {
        "restored": file_id,
        "next_step": "Relancez une consolidation pour réintégrer ce fichier.",
    }


def _file_or_404(supabase: Client, file_id: str) -> dict[str, Any]:
    try:
        res = supabase.table("uploaded_files").select("*").eq("id", file_id).single().execute()
    except Exception as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "File not found.") from exc
    if not res.data:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "File not found.")
    return res.data


def _named(supabase: Client, event_id: str, ids: list[str]) -> list[dict[str, Any]]:
    if not ids:
        return []
    try:
        rows = (
            supabase.table("participants")
            .select("id, first_name, last_name, has_hotel, has_transfer")
            .eq("event_id", event_id)
            .in_("id", ids[:500])
            .execute()
        ).data or []
    except Exception as exc:
        logger.warning("Could not name orphaned participants: %s", exc)
        return [{"participant_id": pid, "name": pid} for pid in ids]
    return [
        {
            "participant_id": r["id"],
            "name": " ".join(
                p for p in (r.get("first_name"), r.get("last_name")) if p
            ).strip() or r["id"],
            # Shown next to the name because they are what makes deleting the
            # person the wrong call: a booked room is not a spreadsheet row.
            "has_hotel": bool(r.get("has_hotel")),
            "has_transfer": bool(r.get("has_transfer")),
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# DELETE /api/files/{file_id}
# ---------------------------------------------------------------------------

@router.delete(
    "/files/{file_id}",
    response_model=MessageResponse,
    summary="Delete an uploaded file",
)
async def delete_file(
    file_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> MessageResponse:
    """
    Delete an uploaded file from both database and storage.
    Verifies event access first.
    """
    # Load file metadata
    meta_resp = (
        supabase.table("uploaded_files")
        .select("id, event_id, storage_path")
        .eq("id", file_id)
        .single()
        .execute()
    )
    if not meta_resp.data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found.")

    meta = meta_resp.data
    await verify_event_access(meta["event_id"], current_user, supabase, write=True)

    # Refuse to delete while a consolidation is running for this event: it
    # snapshots this file's source_record ids up front, deletes exactly
    # those, then deletes the uploaded_files row — but a concurrent
    # consolidation re-parses this same file mid-run and inserts FRESH
    # source_records for it. Rows inserted after deletion's snapshot but
    # before it removes the uploaded_files row survive the cleanup and are
    # then left permanently orphaned (file_id pointing at nothing).
    if is_consolidation_running(supabase, meta["event_id"]):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Une consolidation est en cours sur cet événement : la suppression "
                "est bloquée le temps qu’elle se termine (sans quoi le fichier "
                "laisserait des données orphelines). Réessayez dans une minute."
            ),
        )

    # 1. Delete from Supabase Storage
    try:
        supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).remove(
            [meta["storage_path"]]
        )
    except Exception as exc:
        logger.warning("Storage deletion failed/skipped for path %s: %s", meta["storage_path"], exc)

    # 2. Delete DB rows robustly (handles the 1000-row cap, the circular
    #    participants<->source_records FK, linked exceptions, and timeouts).
    try:
        deletion_service.delete_file_cascade(supabase, file_id)
    except Exception as exc:
        logger.error("Database deletion failed for file %s: %s", file_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete file records.",
        ) from exc

    logger.info("File deleted: file_id=%s user=%s", file_id, current_user["id"])
    return MessageResponse(message="File deleted successfully.")
