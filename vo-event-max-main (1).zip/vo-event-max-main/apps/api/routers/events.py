"""
routers/events.py — Event management endpoints.

Routes:
  POST   /api/events               Create a new event
  GET    /api/events/{event_id}    Get event details
  PATCH  /api/events/{event_id}    Update event metadata
  GET    /api/events/{event_id}/registration-fields   Public form configuration
  PUT    /api/events/{event_id}/registration-fields   Choose the form's questions
  GET    /api/events/{event_id}/registration-theme    How the public form looks
  PUT    /api/events/{event_id}/registration-theme    Restyle the public form
  POST   /api/events/{event_id}/registration-form/suggest  Propose one from a brief
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, UploadFile, status
from supabase import Client

import config
from dependencies import STAFF_ROLES, get_current_user, get_supabase_client, require_role, verify_event_access
from models.schemas import (
    EventCreate, EventResponse, EventSiteUpdate, EventUpdate, FieldPolicyUpdate, MessageResponse,
    ProjectCreate, ProjectResponse, RegistrationExtrasUpdate, RegistrationFieldsUpdate,
    RegistrationBadgesUpdate,
    RegistrationLayoutUpdate,
    RegistrationOpenUpdate, RegistrationSuggestRequest, RegistrationThemeUpdate,
)
from services import (
    deletion_service, field_policy, payload_cache, registration_assistant,
    registration_form, registration_layout, registration_theme,
)

logger = logging.getLogger(__name__)

router = APIRouter()


def _public_form_changed(event_id: str) -> None:
    """Drop this event's cached public form.

    Called by every endpoint below that changes what a visitor sees. Without
    it the form keeps serving the previous version for up to the cache TTL --
    harmless for a colour, wrong for `registration_open`, where it would go on
    accepting submissions to an event that closed.
    """
    payload_cache.public_form.invalidate(str(event_id))


def _memberships_by_project(supabase: Client, user_id: str) -> dict[str, dict] | None:
    """
    All sharing rows of a user, keyed by project_id. Returns None when the
    sharing migration (003) has not been applied yet, so callers keep the
    legacy org-wide behaviour instead of hiding everything.
    """
    try:
        res = (
            supabase.table("project_members")
            .select("project_id, access_level, event_ids")
            .eq("user_id", user_id)
            .execute()
        )
        return {m["project_id"]: m for m in (res.data or [])}
    except Exception as exc:
        if "42P01" in str(exc) or "project_members" in str(exc):
            return None
        logger.error("Failed to load memberships: %s", exc)
        return {}


def _shared_project_ids(supabase: Client, user_id: str) -> set[str] | None:
    memberships = _memberships_by_project(supabase, user_id)
    if memberships is None:
        return None
    return set(memberships.keys())


@router.get(
    "/roles",
    summary="The access ladder this deployment supports (feedback §21)",
)
async def list_roles(
    current_user: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    """What each level may do, so a settings screen states it rather than
    reimplementing it — the two drifting apart is how somebody grants access
    they did not mean to.

    ``mine`` is the caller's own level: the UI hides what it cannot use, and a
    button that 403s is worse than a button that is not there.
    """
    from services import roles

    return {
        "roles": roles.describe(),
        "mine": roles.normalise(current_user.get("role")),
        "can_manage_access": roles.can_manage_access(current_user.get("role")),
    }


@router.post(
    "/projects",
    response_model=ProjectResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new project",
)
async def create_project(
    body: ProjectCreate,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> ProjectResponse:
    """
    Create a new project inside the organization.
    """
    org_id = current_user["org_id"]
    user_id = current_user["id"]
    payload = {
        "org_id": org_id,
        "name": body.name,
        "client_name": body.client_name,
        "created_by": user_id,
    }
    try:
        result = supabase.table("projects").insert(payload).execute()
    except Exception as exc:
        logger.error("Failed to create project: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create project.",
        ) from exc

    return ProjectResponse(**result.data[0])


@router.get(
    "/projects",
    response_model=list[ProjectResponse],
    summary="List all projects in the organization",
)
async def list_projects(
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> list[ProjectResponse]:
    """
    List projects for the caller: staff (admin/pm) see every org project;
    other users only see projects shared with them (project_members).
    """
    org_id = current_user["org_id"]
    try:
        res = (
            supabase.table("projects")
            .select("*")
            .eq("org_id", org_id)
            .execute()
        )
    except Exception as exc:
        logger.error("Failed to list projects: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve projects.",
        ) from exc

    rows = res.data or []
    if current_user.get("role") not in STAFF_ROLES:
        shared = _shared_project_ids(supabase, current_user["id"])
        if shared is not None:                     # None = migration not applied yet
            rows = [r for r in rows if r["id"] in shared]

    return [ProjectResponse(**row) for row in rows]



@router.post(
    "/events",
    response_model=EventResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new event",
)
async def create_event(
    body: EventCreate,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> EventResponse:
    """
    Create a new event inside a project.

    Only ``admin`` and ``pm`` roles can create events. The project must belong
    to the caller's organisation (enforced by RLS on the Supabase side via the
    service-role client + manual org_id check).
    """
    # Verify the project belongs to the caller's org
    org_id: str = current_user["org_id"]
    proj_check = (
        supabase.table("projects")
        .select("id")
        .eq("id", str(body.project_id))
        .eq("org_id", org_id)
        .single()
        .execute()
    )
    if not proj_check.data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Project not found or access denied.",
        )

    payload = body.model_dump(mode="json", exclude_none=True)
    try:
        result = supabase.table("events").insert(payload).execute()
    except Exception as exc:
        logger.error("Failed to create event: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create event.",
        ) from exc

    return EventResponse(**result.data[0])


@router.get(
    "/events/{event_id}",
    response_model=EventResponse,
    summary="Get event details",
)
async def get_event(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> EventResponse:
    """
    Retrieve details for a single event.

    Raises HTTP 404 if the event does not exist or belongs to a different org
    (no information leakage about other tenants' events).
    """
    event = await verify_event_access(event_id, current_user, supabase)
    return EventResponse(**event)


@router.patch(
    "/events/{event_id}",
    response_model=EventResponse,
    summary="Update event metadata",
)
async def update_event(
    event_id: str,
    body: EventUpdate,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> EventResponse:
    """
    Partially update an event's metadata (name, dates, location, etc.).

    Only ``admin`` and ``pm`` roles may update events.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    updates = body.model_dump(mode="json", exclude_none=True)
    if not updates:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No fields provided for update.",
        )

    try:
        result = (
            supabase.table("events")
            .update(updates)
            .eq("id", event_id)
            .execute()
        )
    except Exception as exc:
        # organiser_contact (migration 016) and logo_url (migration 026)
        # arrive only from settings screens and only exist once their
        # migration has run. Renaming an event must not fail because an
        # optional column has not been added yet.
        optional_cols = {"organiser_contact", "logo_url"}
        present = optional_cols & updates.keys()
        if present:
            logger.info("Event update: dropping %s (migration not applied?): %s", sorted(present), exc)
            for col in present:
                updates.pop(col)
            if not updates:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"Saving {', '.join(sorted(present))} needs its migration first.",
                ) from exc
            try:
                result = supabase.table("events").update(updates).eq("id", event_id).execute()
            except Exception as inner:
                logger.error("Failed to update event %s: %s", event_id, inner)
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Failed to update event.",
                ) from inner
        else:
            logger.error("Failed to update event %s: %s", event_id, exc)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to update event.",
            ) from exc

    if not result.data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Event not found.")

    _public_form_changed(event_id)
    return EventResponse(**result.data[0])


@router.get(
    "/events/{event_id}/registration-link",
    summary="Get the public registration form link for an event",
)
async def get_registration_link(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """
    Return the public, unauthenticated registration form URL for an event
    (routers/public_registration.py), plus whether it currently accepts
    submissions.
    """
    await verify_event_access(event_id, current_user, supabase)

    try:
        resp = (
            supabase.table("events")
            .select("registration_token, registration_open")
            .eq("id", event_id)
            .single()
            .execute()
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Event not found, or migration 006 has not been applied yet.",
        ) from exc

    token = resp.data["registration_token"]

    # How many people actually filled the form. Counted from source_records,
    # which is the only place that knows: uploaded_files.row_count is written
    # once at import time for real uploads and is never touched by a form
    # submission, so reading it here always reported nothing (2026-08-03).
    submissions: Optional[int] = None
    try:
        files = (
            supabase.table("uploaded_files")
            .select("id")
            .eq("event_id", event_id)
            .eq("storage_path", f"public-form/{event_id}")
            .execute()
        )
        submissions = 0
        for f in files.data or []:
            counted = (
                supabase.table("source_records")
                .select("id", count="exact")
                .eq("file_id", f["id"])
                .limit(1)
                .execute()
            )
            submissions += counted.count or 0
    except Exception as exc:
        # Never let the counter break the link itself.
        logger.warning("Could not count registrations for event %s: %s", event_id, exc)
        submissions = None

    return {
        "token": token,
        "url": f"{config.WEB_APP_URL}/fr/register/{token}",
        "is_open": resp.data["registration_open"],
        "submissions": submissions,
    }


@router.patch(
    "/events/{event_id}/registration-open",
    summary="Open or close the public registration form for an event",
)
async def set_registration_open(
    event_id: str,
    body: RegistrationOpenUpdate,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Only admin/pm may open or close registration for an event."""
    await verify_event_access(event_id, current_user, supabase, write=True)

    try:
        supabase.table("events").update({"registration_open": body.is_open}).eq("id", event_id).execute()
    except Exception as exc:
        logger.error("Failed to toggle registration_open for event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update registration status.",
        ) from exc

    _public_form_changed(event_id)
    return {"is_open": body.is_open}


@router.get(
    "/events/{event_id}/registration-fields",
    summary="Get the public form's field configuration for an event",
)
async def get_registration_fields(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Which questions this event's public form asks, already resolved: an
    event that was never configured comes back with the defaults rather than
    with nothing, so the editor has something to show either way."""
    await verify_event_access(event_id, current_user, supabase)
    return {"fields": registration_form.resolve(registration_form.fetch(supabase, event_id))}


@router.put(
    "/events/{event_id}/registration-fields",
    summary="Choose which questions the public form asks",
)
async def set_registration_fields(
    event_id: str,
    body: RegistrationFieldsUpdate,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Only admin/pm may change the form. The payload is filtered against the
    catalogue before it is stored (identity fields forced on, unknown keys
    dropped) — this drives a public page, so it is not taken on trust."""
    await verify_event_access(event_id, current_user, supabase, write=True)

    to_sanitize: dict[str, Any] = {key: toggle.model_dump() for key, toggle in body.fields.items()}
    if body.order:
        to_sanitize["_order"] = body.order
    clean = registration_form.sanitize(to_sanitize)
    try:
        supabase.table("events").update({"registration_fields": clean}).eq("id", event_id).execute()
    except Exception as exc:
        logger.error("Failed to save registration fields for event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible d'enregistrer la configuration du formulaire. "
                   "La migration 007 a-t-elle été appliquée ?",
        ) from exc

    _public_form_changed(event_id)
    return {"fields": registration_form.resolve(clean)}


@router.post(
    "/events/{event_id}/registration-form/suggest",
    summary="Propose a whole form configuration from a description of the event",
)
async def suggest_registration_form(
    event_id: str,
    body: RegistrationSuggestRequest,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Read the brief, return a draft. Writes nothing.

    A POST because it has a body and costs a model call, not because it
    changes anything: the organizer reviews the proposal and applies it
    through the ordinary field/theme endpoints, which sanitize it again. That
    is deliberate \u2014 it means the worst a prompt injection hidden in an event
    description can do is propose the wrong questions to somebody who is
    looking straight at them.

    Restricted to admin/pm for the same reason the form endpoints are: it is
    the same configuration, arrived at faster.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)
    # Off the event loop: ai_service speaks to the provider over a synchronous
    # client, and uvicorn runs two workers. Awaiting it inline would block one
    # of them for up to the full 45s timeout, stalling every other request in
    # the deployment while an organizer waits for a form to be proposed.
    return await asyncio.to_thread(registration_assistant.propose, body.description)


@router.get(
    "/events/{event_id}/registration-theme",
    summary="Get how this event's public form looks",
)
async def get_registration_theme(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Always a complete theme, never a null: an event that was never styled
    comes back with the defaults, so the editor has something to show and the
    preview has something to render."""
    await verify_event_access(event_id, current_user, supabase)
    return {"theme": registration_theme.resolve(registration_theme.fetch(supabase, event_id))}


@router.put(
    "/events/{event_id}/registration-theme",
    summary="Choose how this event's public form looks",
)
async def set_registration_theme(
    event_id: str,
    body: RegistrationThemeUpdate,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Only admin/pm may restyle the form.

    The payload is rebuilt from the closed sets before it is stored rather
    than trusted: this drives a page open to the world with no login, so a
    value that is not a key this codebase defines must not be able to reach
    it.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    clean = registration_theme.sanitize(body.model_dump())
    try:
        supabase.table("events").update({"registration_theme": clean}).eq("id", event_id).execute()
    except Exception as exc:
        logger.error("Failed to save registration theme for event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible d'enregistrer l'apparence du formulaire. "
                   "La migration 030 a-t-elle \u00e9t\u00e9 appliqu\u00e9e ?",
        ) from exc

    _public_form_changed(event_id)
    return {"theme": clean}


@router.get(
    "/events/{event_id}/registration-layout",
    summary="How this event's public form is laid out in blocks",
)
async def get_registration_layout(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """The editor never opens on a blank page.

    An event that already arranged a layout gets it back; one that never did
    gets a starting point seeded with its own name — editable, but not yet
    live. ``active`` says which: the public form only renders blocks once a
    layout has actually been stored, so the editor can tell "this is a
    suggestion" from "this is what visitors see".
    """
    event = await verify_event_access(event_id, current_user, supabase)
    stored = registration_layout.fetch(supabase, event_id)
    layout = (
        registration_layout.sanitize(stored)
        if stored
        else registration_layout.default_layout(event.get("name", ""))
    )
    # A map of page -> blocks; "home" is the registration page. `active` is
    # false when nothing was ever stored — the layout returned is then a
    # starting point, not what visitors see.
    return {"layout": layout, "active": bool(stored)}


@router.put(
    "/events/{event_id}/registration-layout",
    summary="Arrange this event's public form in blocks",
)
async def set_registration_layout(
    event_id: str,
    body: RegistrationLayoutUpdate,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Only admin/pm may re-lay-out the form.

    The blocks are rebuilt from the closed sets before they are stored, never
    trusted: this drives a page open to the world with no login, so a block
    type or value this codebase does not define must not be able to reach it.
    Saving here is what switches the public page into block mode.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    clean = registration_layout.sanitize(body.pages)
    try:
        supabase.table("events").update({"registration_layout": clean}).eq("id", event_id).execute()
    except Exception as exc:
        logger.error("Failed to save registration layout for event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible d'enregistrer la mise en page du formulaire. "
                   "La migration 032 a-t-elle été appliquée ?",
        ) from exc

    _public_form_changed(event_id)
    return {"layout": clean, "active": True}


@router.get(
    "/events/{event_id}/registration-badges",
    summary="This event's named audiences for the form (point 13, v1)",
)
async def get_registration_badges(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Empty before migration 027 or before any badge is saved — a
    collaborator who has never used badges sees the same thing either way:
    no badges, every field shown to everyone, exactly as before."""
    await verify_event_access(event_id, current_user, supabase)
    return {"badges": registration_form.fetch_badges(supabase, event_id)}


@router.put(
    "/events/{event_id}/registration-badges",
    summary="Save this event's named audiences for the form",
)
async def set_registration_badges(
    event_id: str,
    body: RegistrationBadgesUpdate,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Replaces the whole set. Deleting a badge here does not touch any
    field's own badges list elsewhere — a field naming a badge that no
    longer exists simply never matches it again, same as a rooming preset
    referenced after being deleted."""
    await verify_event_access(event_id, current_user, supabase, write=True)
    clean = registration_form.resolve_badges([b.model_dump() for b in body.badges])
    try:
        supabase.table("events").update({"registration_badges": clean}).eq("id", event_id).execute()
    except Exception as exc:
        logger.error("Failed to save registration badges for event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible d'enregistrer les badges. La migration 027 a-t-elle été appliquée ?",
        ) from exc
    _public_form_changed(event_id)
    return {"badges": clean}


@router.get(
    "/events/{event_id}/registration-extras",
    summary="Get the event's own registration questions and confirmations",
)
async def get_registration_extras(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """The organizer's own questions and contractual tick-boxes, resolved.

    Empty lists on a deployment without migration 010, which is also exactly
    what an event that has defined none looks like — the editor renders the
    same "nothing yet" state either way.
    """
    await verify_event_access(event_id, current_user, supabase)
    custom_fields, confirmations = registration_form.fetch_extras(supabase, event_id)
    return {"custom_fields": custom_fields, "confirmations": confirmations}


@router.put(
    "/events/{event_id}/registration-extras",
    summary="Define the event's own registration questions and confirmations",
)
async def set_registration_extras(
    event_id: str,
    body: RegistrationExtrasUpdate,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Only admin/pm. Both lists are normalised before storage — malformed
    entries are dropped rather than stored, because a typo here becomes a
    public page that people outside the company cannot get past.

    Confirmations carry contractual weight (a cancellation policy with a
    deadline), so their wording is stored verbatim and shown as written.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    custom = registration_form.resolve_custom(body.custom_fields)
    confirmations = registration_form.resolve_confirmations(body.confirmations)
    try:
        supabase.table("events").update({
            "registration_custom_fields": custom,
            "registration_confirmations": confirmations,
        }).eq("id", event_id).execute()
    except Exception as exc:
        logger.error("Failed to save registration extras for event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible d'enregistrer les questions du formulaire. "
                   "La migration 010 a-t-elle été appliquée ?",
        ) from exc

    _public_form_changed(event_id)
    return {"custom_fields": custom, "confirmations": confirmations}


@router.get(
    "/events/{event_id}/field-policy",
    summary="Get which participant fields this event tracks, and how strictly",
)
async def get_field_policy(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """What this event needs to know about its participants (feedback §10).

    Returns the catalogue alongside the resolved policy so the settings screen
    can render labels, sections and defaults without hardcoding them. An event
    that was never configured comes back with the defaults — which are exactly
    the fields the exception engine already alerted on.
    """
    await verify_event_access(event_id, current_user, supabase)
    return {
        "policy": field_policy.for_event(supabase, event_id),
        "catalogue": field_policy.describe(),
    }


@router.put(
    "/events/{event_id}/field-policy",
    summary="Choose which participant fields this event requires",
)
async def set_field_policy(
    event_id: str,
    body: FieldPolicyUpdate,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Only admin/pm may change it: this decides what the whole team sees as a
    gap. Unknown keys and invalid states are dropped on the way in.

    Marking a field ``not_used`` silences its alerts and drops it from the
    quality score. It never deletes anything: a value arriving from a source
    file is still stored and still shown on the fiche.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    clean = field_policy.sanitize(body.policy)
    try:
        supabase.table("events").update({"field_policy": clean}).eq("id", event_id).execute()
    except Exception as exc:
        logger.error("Failed to save field policy for event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible d'enregistrer la configuration des champs. "
                   "La migration 008 a-t-elle été appliquée ?",
        ) from exc

    return {"policy": clean, "catalogue": field_policy.describe()}


# ---------------------------------------------------------------------------
# The mini event site (feedback §11)
# ---------------------------------------------------------------------------


@router.get(
    "/events/{event_id}/site",
    summary="The sections shown above the public registration form",
)
async def get_event_site(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Everything the editor needs: the stored sections and the catalogue.

    Returns the RAW rows, in all three languages — the public endpoint resolves
    one language and drops the empties, which is the wrong shape for editing.
    """
    from services import event_site

    await verify_event_access(event_id, current_user, supabase)
    try:
        rows = (
            supabase.table("event_site_sections")
            .select("slug, title, body, image_url, visible, position")
            .eq("event_id", event_id)
            .order("position")
            .execute()
        ).data or []
    except Exception as exc:
        logger.info("Event site unavailable (migration 018?): %s", exc)
        return {
            "sections": [], "catalogue": event_site.describe(),
            "summary": {}, "available": False,
        }

    return {
        "sections": rows,
        "catalogue": event_site.describe(),
        "summary": event_site.summarise(rows),
        "available": True,
    }


async def _upload_public_image(event_id: str, file: UploadFile, supabase: Client) -> str:
    """Validate, store in the PUBLIC bucket, return the URL. Shared by the
    mini-site image upload (point 9) and the event logo upload (point 11) —
    both need the same thing: an image an unauthenticated visitor's browser
    can load directly, which is what makes this bucket public in the first
    place rather than the private one everything else in this app uses."""
    from services import site_image_uploads

    content = await file.read(site_image_uploads.MAX_BYTES + 1)
    try:
        descriptor = site_image_uploads.validate(file.filename or "", content)
    except site_image_uploads.SiteImageRefused as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc

    path = site_image_uploads.storage_path(event_id, descriptor["ext"])
    try:
        supabase.storage.from_(config.SUPABASE_PUBLIC_BUCKET).upload(
            path=path, file=content,
            file_options={"content-type": descriptor["content_type"]},
        )
    except Exception as exc:
        logger.error("Public image upload failed for event %s: %s", event_id, exc)
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY,
            "L'image n'a pas pu être enregistrée. Le bucket "
            f"'{config.SUPABASE_PUBLIC_BUCKET}' existe-t-il et est-il public ?",
        ) from exc

    return supabase.storage.from_(config.SUPABASE_PUBLIC_BUCKET).get_public_url(path)


@router.post(
    "/events/{event_id}/site/image",
    summary="Upload a photo for a mini-site section, instead of pasting a link (point 9)",
)
async def upload_site_image(
    event_id: str,
    file: UploadFile,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, str]:
    """The URL is what a section's ``image_url`` becomes — nothing about how
    a section stores or renders its image changes, only how the organizer
    gets one in without hosting it themselves first."""
    await verify_event_access(event_id, current_user, supabase, write=True)
    return {"url": await _upload_public_image(event_id, file, supabase)}


@router.post(
    "/events/{event_id}/logo",
    summary="Upload this event's logo, instead of the default MAX mark (point 11)",
)
async def upload_event_logo(
    event_id: str,
    file: UploadFile,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, str]:
    """Returns a URL — it does not save it. The caller PATCHes
    ``logo_url`` onto the event with it, the same two-step shape as the
    mini-site image, so a preview can be shown before it is confirmed."""
    await verify_event_access(event_id, current_user, supabase, write=True)
    return {"url": await _upload_public_image(event_id, file, supabase)}


@router.put(
    "/events/{event_id}/site",
    summary="Replace the event site's sections",
)
async def set_event_site(
    event_id: str,
    body: EventSiteUpdate,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Save the whole site in one call.

    Every body is stripped of markup before it is stored: this text is rendered
    on a page open to the world with no login, and accepting HTML would make an
    organizer account a stored-XSS vector against every participant. A section
    the caller omits is deleted, which is what makes "remove this section" work
    without a second endpoint.
    """
    from services import event_site

    await verify_event_access(event_id, current_user, supabase, write=True)

    try:
        sections = event_site.sanitise_all(body.sections)
    except event_site.EventSiteError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc

    try:
        # Upsert first, delete second. The other order — clear the event then
        # insert — loses the whole site if the insert fails, and "my Welcome
        # text vanished when I hit Save" is not a recoverable state for
        # somebody who wrote it once.
        if sections:
            rows = [{**s, "event_id": event_id} for s in sections]
            try:
                supabase.table("event_site_sections").upsert(
                    rows, on_conflict="event_id,slug",
                ).execute()
            except Exception:
                # image_position only exists after migration 029. The text is
                # the point — save the section without the placement rather
                # than lose what somebody just wrote.
                supabase.table("event_site_sections").upsert(
                    [{k: v for k, v in r.items() if k != "image_position"} for r in rows],
                    on_conflict="event_id,slug",
                ).execute()
        keep = [s["slug"] for s in sections]
        removal = supabase.table("event_site_sections").delete().eq("event_id", event_id)
        if keep:
            # An omitted section is a deletion — that is what makes "empty it to
            # remove it" work without a second endpoint.
            removal = removal.not_.in_("slug", keep)
        removal.execute()
    except Exception as exc:
        logger.error("Failed to save event site for %s: %s", event_id, exc)
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            "Impossible d'enregistrer le mini-site. La migration 018 a-t-elle été appliquée ?",
        ) from exc

    _public_form_changed(event_id)
    return {
        "sections": sections,
        "catalogue": event_site.describe(),
        "summary": event_site.summarise(sections),
        "available": True,
    }


@router.delete(
    "/events/{event_id}",
    response_model=MessageResponse,
    summary="Delete an event and all its data",
)
async def delete_event(
    event_id: str,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> MessageResponse:
    """
    Permanently delete an event and every row that depends on it (participants,
    files, flights, hotels, transfers, activities, exceptions, runs, …).

    Only ``admin`` and ``pm`` roles may delete. Access is checked against the
    caller's organisation first.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)
    try:
        deletion_service.delete_event(supabase, event_id)
    except Exception as exc:
        logger.error("Failed to delete event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete event.",
        ) from exc
    return MessageResponse(message="Event deleted successfully.")


@router.delete(
    "/projects/{project_id}",
    response_model=MessageResponse,
    summary="Delete a project and all its events",
)
async def delete_project(
    project_id: str,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> MessageResponse:
    """
    Permanently delete a project together with every event under it and all
    their data. Only ``admin`` and ``pm`` roles may delete.
    """
    org_id: str = current_user["org_id"]
    proj_check = (
        supabase.table("projects")
        .select("id")
        .eq("id", project_id)
        .eq("org_id", org_id)
        .single()
        .execute()
    )
    if not proj_check.data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Project not found or access denied.",
        )
    try:
        deletion_service.delete_project(supabase, project_id)
    except Exception as exc:
        logger.error("Failed to delete project %s: %s", project_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete project.",
        ) from exc
    return MessageResponse(message="Project deleted successfully.")


@router.get(
    "/events",
    response_model=list[EventResponse],
    summary="List all events in the organization",
)
async def list_events(
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> list[EventResponse]:
    """
    List events for the caller: staff (admin/pm) see every org event; other
    users only see events of projects shared with them — and when the share
    is restricted to specific events, only those.
    """
    org_id = current_user["org_id"]
    try:
        res = (
            supabase.table("events")
            .select("*, projects!inner(org_id)")
            .eq("projects.org_id", org_id)
            # Most recently touched first. The query had no ORDER BY at all, so
            # Postgres returned whatever order it liked — and signing in lands
            # the user on events[0] (lib/landing.ts). On a real account that
            # meant opening an EMPTY event created days earlier while the one
            # being worked on sat second in the list: a dashboard reading
            # 0 participants, 0 sources, as the first screen after login
            # (2026-08-12).
            .order("updated_at", desc=True)
            .order("created_at", desc=True)
            .execute()
        )
    except Exception as exc:
        logger.error("Failed to list events: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve events.",
        ) from exc

    rows = res.data or []
    if current_user.get("role") not in STAFF_ROLES:
        memberships = _memberships_by_project(supabase, current_user["id"])
        if memberships is not None:                # None = migration not applied yet
            filtered = []
            for r in rows:
                m = memberships.get(r.get("project_id"))
                if not m:
                    continue
                restricted = m.get("event_ids")
                if restricted and r["id"] not in restricted:
                    continue
                filtered.append(r)
            rows = filtered

    return [EventResponse(**row) for row in rows]

