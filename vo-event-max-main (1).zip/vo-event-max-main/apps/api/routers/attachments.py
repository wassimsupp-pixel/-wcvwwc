"""
routers/attachments.py — the passport copies and photos, once they are in (§9).

The registration form collects these; without this router nothing could ever
look at one again. That is not a small omission: an organiser who asks for a
passport copy needs it at check-in, and a document the platform holds but
cannot show is pure liability — all of the risk, none of the use.

Three operations, and the reasons they are shaped this way:

  * **Listing** returns metadata only, never the storage path. The path is the
    one field that would let a client reach the object without passing an
    access check again.
  * **Downloading** streams the bytes through the API instead of handing out a
    signed URL. A URL outlives the check that produced it and travels into
    browser history, referrer headers and pasted messages; a stream is
    authorised at the moment it is read. The fetch is written to the change log
    — looking at somebody's identity document is an event worth recording.
  * **Deleting** is available to anybody who may write to the event, because a
    participant asking for their passport copy to be removed should not need an
    administrator. It removes the object *and* the row.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from supabase import Client

from dependencies import get_current_user, get_supabase_client, verify_event_access
from services import attachment_custody, audit_service

logger = logging.getLogger(__name__)

router = APIRouter()


def _disposition(filename: str) -> str:
    """``Content-Disposition`` carrying both spellings of the name.

    ``filename`` is the ASCII fallback every client understands; ``filename*``
    carries the real one, accents included. Sending only the first is how
    "Bénédicte Müller passeport.jpg" reaches a downloads folder as a row of
    underscores.
    """
    import re
    from urllib.parse import quote

    ascii_name = re.sub(r"[^\w.\-]+", "_", filename) or "document"
    return (
        f'attachment; filename="{ascii_name}"; '
        f"filename*=UTF-8''{quote(filename, safe='')}"
    )


@router.get(
    "/events/{event_id}/attachments",
    summary="Passport copies and photos collected for an event (§9)",
)
async def list_attachments(
    event_id: str,
    participant_id: Optional[str] = Query(
        None, description="Restrict to the documents of one participant."
    ),
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    await verify_event_access(event_id, current_user, supabase)
    items = attachment_custody.listing(
        supabase, event_id, participant_id=participant_id
    )
    return {"attachments": items, "total": len(items)}


@router.get(
    "/events/{event_id}/attachments/{attachment_id}/download",
    summary="Download one collected document",
)
async def download_attachment(
    event_id: str,
    attachment_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> Response:
    await verify_event_access(event_id, current_user, supabase)

    row = attachment_custody.find(supabase, event_id, attachment_id)
    if not row:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document introuvable.")
    if not row.get("claimed_at"):
        # An unclaimed row belongs to a form that was never submitted. Its
        # owner did not send it to anybody, and it is about to expire on its
        # own; serving it would publish something nobody ever handed over.
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document introuvable.")

    import config

    try:
        raw: bytes = supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).download(
            row["storage_path"]
        )
    except Exception as exc:
        logger.error("Attachment download failed for %s: %s", attachment_id, exc)
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY,
            "Le document n'a pas pu être récupéré.",
        ) from exc

    participant = None
    if row.get("participant_id"):
        try:
            participant = (
                supabase.table("participants")
                .select("first_name, last_name")
                .eq("id", row["participant_id"])
                .maybe_single()
                .execute()
            ).data
        except Exception:
            participant = None

    filename = attachment_custody.download_name(row, participant)

    # Recorded, not silent. Everything else in the change log answers "who
    # changed this?"; for an identity document the question that gets asked is
    # "who looked at it?", and it deserves the same answer.
    audit_service.log_change(
        supabase,
        event_id=event_id,
        user_id=current_user.get("id", ""),
        entity_type="registration_attachment",
        entity_id=str(attachment_id),
        field_name="download",
        old_value=None,
        new_value=str(row.get("kind") or ""),
        reason="attachment_downloaded",
        source="manual_update",
    )

    return Response(
        content=raw,
        media_type=row.get("content_type") or "application/octet-stream",
        headers={"Content-Disposition": _disposition(filename)},
    )


@router.delete(
    "/events/{event_id}/attachments/{attachment_id}",
    summary="Erase one collected document",
)
async def delete_attachment(
    event_id: str,
    attachment_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    await verify_event_access(event_id, current_user, supabase, write=True)

    row = attachment_custody.find(supabase, event_id, attachment_id)
    if not row:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document introuvable.")

    # Logged before the delete: afterwards there is no row left to describe,
    # and an erasure nobody can account for is worse than none.
    audit_service.log_change(
        supabase,
        event_id=event_id,
        user_id=current_user.get("id", ""),
        entity_type="registration_attachment",
        entity_id=str(attachment_id),
        field_name="deleted",
        old_value=str(row.get("original_name") or row.get("kind") or ""),
        new_value=None,
        reason="attachment_deleted",
        source="manual_update",
    )

    if not attachment_custody.delete(supabase, row):
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY,
            "Le document n'a pas pu être supprimé.",
        )
    return {"deleted": True, "id": attachment_id}
