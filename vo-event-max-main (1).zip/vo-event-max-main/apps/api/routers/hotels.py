"""
routers/hotels.py — Hotels and Rooming List management endpoints.
"""

from __future__ import annotations

import logging
from typing import Any, Optional
from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from supabase import Client

from dependencies import get_current_user, get_supabase_client, verify_event_access
from services import (
    consolidation_service, room_service, rooming_import, rooming_plan, rooming_service,
)
from models.schemas import (
    HotelResponse,
    HotelCreate,
    HotelUpdate,
    HotelNightResponse,
    HotelNightCreate,
    HotelNightUpdate,
    MessageResponse,
    RoomingGenerateRequest,
    RoomingImportApply,
    RoomingPresetsUpdate,
)
from services.audit_service import log_change

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get(
    "/events/{event_id}/hotels",
    response_model=list[HotelResponse],
    summary="List all hotels for an event",
)
async def list_hotels(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> list[HotelResponse]:
    """
    List hotels configured for an event.
    """
    await verify_event_access(event_id, current_user, supabase)

    response = (
        supabase.table("hotels")
        .select("*")
        .eq("event_id", event_id)
        .execute()
    )

    return [HotelResponse(**row) for row in response.data]


@router.post(
    "/events/{event_id}/hotels",
    response_model=HotelResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Add a new hotel property to an event",
)
async def create_hotel(
    event_id: str,
    body: HotelCreate,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> HotelResponse:
    """
    Add a hotel property to an event.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    payload = body.model_dump()
    payload["event_id"] = event_id

    result = supabase.table("hotels").insert(payload).execute()
    return HotelResponse(**result.data[0])


@router.patch(
    "/hotels/{hotel_id}",
    response_model=HotelResponse,
    summary="Update hotel property details",
)
async def update_hotel(
    hotel_id: str,
    body: HotelUpdate,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> HotelResponse:
    """
    Update hotel metadata. Logs to audit trail.
    """
    existing = supabase.table("hotels").select("*").eq("id", hotel_id).single().execute()
    if not existing.data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Hotel not found.",
        )

    event_id = existing.data["event_id"]
    await verify_event_access(event_id, current_user, supabase, write=True)

    payload = body.model_dump(exclude_none=True)
    user_id = current_user["id"]

    for field, new_val in payload.items():
        old_val = str(existing.data.get(field) or "")
        new_val_str = str(new_val)
        if old_val != new_val_str:
            log_change(
                supabase=supabase,
                event_id=event_id,
                user_id=user_id,
                entity_type="hotel",
                entity_id=hotel_id,
                field_name=field,
                old_value=old_val,
                new_value=new_val_str,
                reason="manual_edit",
                source="manual_update",
            )

    result = supabase.table("hotels").update(payload).eq("id", hotel_id).execute()
    return HotelResponse(**result.data[0])


@router.get(
    "/events/{event_id}/hotels/rooming",
    response_model=list[HotelNightResponse],
    summary="List rooming list nights for an event",
)
async def list_rooming_list(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> list[HotelNightResponse]:
    """
    Get all night room allocations for an event.
    """
    await verify_event_access(event_id, current_user, supabase)

    # Fetch hotels for this event
    hotels_res = supabase.table("hotels").select("id").eq("event_id", event_id).execute()
    hotel_ids = [h["id"] for h in hotels_res.data]

    if not hotel_ids:
        return []

    # Select room allocations
    response = (
        supabase.table("hotel_nights")
        .select("*, hotels(name), participants(first_name, last_name)")
        .in_("hotel_id", hotel_ids)
        .execute()
    )

    results = []
    for row in response.data:
        part = row.get("participants")
        part_name = f"{part['first_name']} {part['last_name']}" if part else None
        h_info = row.get("hotels")
        hotel_name = h_info["name"] if h_info else None

        item = row.copy()
        item.pop("participants", None)
        item.pop("hotels", None)
        item["participant_name"] = part_name
        item["hotel_name"] = hotel_name
        results.append(HotelNightResponse(**item))

    return results


@router.post(
    "/events/{event_id}/hotels/rooming",
    response_model=HotelNightResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Assign a hotel night to a participant",
)
async def assign_rooming_night(
    event_id: str,
    body: HotelNightCreate,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> HotelNightResponse:
    """
    Assign a rooming night to a participant.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    # Verify participant is in event
    part = (
        supabase.table("participants")
        .select("id")
        .eq("id", str(body.participant_id))
        .eq("event_id", event_id)
        .single()
        .execute()
    )
    if not part.data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Participant not found in this event.",
        )

    # Verify hotel belongs to event
    hotel = (
        supabase.table("hotels")
        .select("id")
        .eq("id", str(body.hotel_id))
        .eq("event_id", event_id)
        .single()
        .execute()
    )
    if not hotel.data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Hotel not found in this event.",
        )

    # mode="json" is required: HotelNightCreate has UUID/date fields, and the
    # plain .model_dump() leaves them as UUID/date objects, which the
    # supabase-py/httpx JSON encoder cannot serialize (TypeError, 500 that
    # surfaces to the browser as an opaque "Failed to fetch" — no CORS
    # headers make it onto that particular crash path).
    payload = body.model_dump(mode="json")

    # Unique check: participant cannot have duplicate nights
    exist = (
        supabase.table("hotel_nights")
        .select("id")
        .eq("participant_id", str(body.participant_id))
        .eq("night_date", str(body.night_date))
        .execute()
    )
    if exist.data:
        # Update existing
        result = (
            supabase.table("hotel_nights")
            .update({"hotel_id": str(body.hotel_id), "room_type": body.room_type, "status": body.status})
            .eq("id", exist.data[0]["id"])
            .execute()
        )
    else:
        result = supabase.table("hotel_nights").insert(payload).execute()

    # Update participant has_hotel status
    supabase.table("participants").update({"has_hotel": True}).eq("id", str(body.participant_id)).execute()

    return HotelNightResponse(**result.data[0])


@router.patch(
    "/hotels/rooming/{rooming_id}",
    response_model=HotelNightResponse,
    summary="Update rooming night details",
)
async def update_rooming_night(
    rooming_id: str,
    body: HotelNightUpdate,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> HotelNightResponse:
    """
    Update room status or type for a night.
    """
    existing = (
        supabase.table("hotel_nights")
        .select("*, hotels(event_id)")
        .eq("id", rooming_id)
        .single()
        .execute()
    )
    if not existing.data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Rooming night not found.",
        )

    event_id = existing.data["hotels"]["event_id"]
    await verify_event_access(event_id, current_user, supabase, write=True)

    # mode="json": HotelNightUpdate.hotel_id is UUID, same crash class as
    # assign_rooming_night if a client ever patches hotel_id here.
    payload = body.model_dump(mode="json", exclude_none=True)
    user_id = current_user["id"]

    for field, new_val in payload.items():
        old_val = str(existing.data.get(field) or "")
        new_val_str = str(new_val)
        if old_val != new_val_str:
            log_change(
                supabase=supabase,
                event_id=event_id,
                user_id=user_id,
                entity_type="hotel_night",
                entity_id=rooming_id,
                field_name=field,
                old_value=old_val,
                new_value=new_val_str,
                reason="manual_edit",
                source="manual_update",
            )

    result = supabase.table("hotel_nights").update(payload).eq("id", rooming_id).execute()
    return HotelNightResponse(**result.data[0])


@router.delete(
    "/hotels/rooming/{rooming_id}",
    response_model=MessageResponse,
    summary="Delete rooming assignment for a night",
)
async def delete_rooming_night(
    rooming_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> MessageResponse:
    """
    Delete a single night allocation.
    """
    existing = (
        supabase.table("hotel_nights")
        .select("*, hotels(event_id)")
        .eq("id", rooming_id)
        .single()
        .execute()
    )
    if not existing.data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Rooming night not found.",
        )

    event_id = existing.data["hotels"]["event_id"]
    await verify_event_access(event_id, current_user, supabase, write=True)

    supabase.table("hotel_nights").delete().eq("id", rooming_id).execute()
    return MessageResponse(message="Successfully deleted rooming night allocation.")


from pydantic import BaseModel, Field
from uuid import UUID

class HotelNightBulkCreate(BaseModel):
    hotel_id: UUID
    night_date: str
    room_type: str = Field(default="single")
    status: str = Field(default="confirmed")


@router.post(
    "/events/{event_id}/hotels/rooming/bulk",
    response_model=MessageResponse,
    summary="Assign a hotel night to all participants in bulk",
)
async def bulk_assign_rooming_night(
    event_id: str,
    body: HotelNightBulkCreate,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> MessageResponse:
    """
    Assign a rooming night to all participants of the event in bulk.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    # Verify hotel belongs to event
    hotel = (
        supabase.table("hotels")
        .select("id")
        .eq("id", str(body.hotel_id))
        .eq("event_id", event_id)
        .single()
        .execute()
    )
    if not hotel.data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Hotel not found in this event.",
        )

    # Fetch all participants for this event
    parts_resp = supabase.table("participants").select("id").eq("event_id", event_id).execute()
    part_ids = [p["id"] for p in parts_resp.data or []]

    if not part_ids:
        return MessageResponse(message="No participants found in this event to assign.")

    # Fetch existing rooming nights for these participants on this date
    existing = (
        supabase.table("hotel_nights")
        .select("id, participant_id")
        .in_("participant_id", part_ids)
        .eq("night_date", body.night_date)
        .execute()
    )
    existing_map = {n["participant_id"]: n["id"] for n in existing.data or []}

    payloads = []
    for p_id in part_ids:
        payload = {
            "hotel_id": str(body.hotel_id),
            "participant_id": p_id,
            "night_date": body.night_date,
            "room_type": body.room_type,
            "status": body.status
        }
        if p_id in existing_map:
            payload["id"] = existing_map[p_id]
        payloads.append(payload)

    # Bulk upsert hotel nights in chunks of 100
    if payloads:
        for i in range(0, len(payloads), 100):
            supabase.table("hotel_nights").upsert(payloads[i:i+100]).execute()

    # Bulk update participants in chunks of 50
    for i in range(0, len(part_ids), 50):
        supabase.table("participants").update({"has_hotel": True}).in_("id", part_ids[i:i+50]).execute()

    return MessageResponse(message="Successfully assigned rooming night to all participants.")


# ---------------------------------------------------------------------------
# Rooming list (feedback §5)
# ---------------------------------------------------------------------------
#
# Two endpoints that look similar and mean opposite things:
#
#   GET  /rooming-list          what was GENERATED, and whether it still holds
#   GET  /rooming-list/preview  what a generation WOULD produce right now
#
# The first is a document. The second is a proposal. Nothing but an explicit
# POST to /generate turns the second into the first — a consolidation may change
# every underlying fact and still not touch a list somebody has already sent to
# a hotel.


_ROOMMATE_GAP_LABELS = {
    "no_name": "aucun binôme indiqué",
    "unknown_name": "binôme introuvable parmi les participants",
    "ambiguous_name": "plusieurs participants portent ce nom",
    "contradicted": "le binôme désigné en a choisi un autre",
}


def roommate_gaps(participants: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Shared rooms with nobody confirmed on the other side.

    Recomputed here from the CURRENT fiches rather than read from the
    exceptions written at the last consolidation: somebody who fixed a
    roommate five minutes ago must not still be blocked by a stale card.

    Reuses the same pure resolver consolidation uses, so the block and the
    alerts can never disagree about who is unpaired.
    """
    _, unresolved = rooming_service.resolve_pairs(
        participants,
        same_person_name=consolidation_service._same_person_name,
        norm_name=consolidation_service._norm_name,
    )

    # A fiche already carrying a confirmed, mutual link is NOT a gap, whatever
    # the free-text roommate field says. The link is the answer; the name is
    # only how somebody asked for it, and it is routinely blank on the second
    # person of a pair (one of the two filled the form, or the pairing came
    # from an imported rooming file with no name column at all).
    by_id = {p["id"]: p for p in participants if p.get("id")}
    confirmed = {
        pid for pid, p in by_id.items()
        if (mate := p.get("roommate_participant_id"))
        and (by_id.get(mate) or {}).get("roommate_participant_id") == pid
    }

    out = []
    for gap in unresolved:
        if gap.get("participant_id") in confirmed:
            continue
        p = gap.get("participant") or {}
        name = f"{p.get('first_name') or ''} {p.get('last_name') or ''}".strip() or "?"
        out.append({
            "participant_id": gap.get("participant_id"),
            "name": name,
            "room_type": p.get("room_type") or "",
            "written_name": gap.get("written_name") or "",
            "reason": gap.get("reason"),
            "label": _ROOMMATE_GAP_LABELS.get(gap.get("reason", ""), gap.get("reason", "")),
        })
    return sorted(out, key=lambda g: g["name"])


def _rooming_inputs(
    event_id: str, supabase: Client
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], bool, dict[str, str]]:
    """The participants and nights a rooming list is built from.

    Returns ``(participants, nights, available, hotel_names)``. ``available`` is False when
    migration 012 has not run: the room number lives on the participant, and
    without that column there is nothing to read. Same graceful-degradation
    contract as everywhere else in this codebase.
    """
    try:
        participants = (
            supabase.table("participants")
            .select(
                "id, first_name, last_name, room_type, room_number, "
                "roommate_participant_id, locked_fields"
            )
            .eq("event_id", event_id)
            .execute()
        ).data or []
    except Exception as exc:
        logger.info("Rooming list unavailable (migration 012 not applied?): %s", exc)
        return [], [], False, {}

    nights: list[dict[str, Any]] = []
    hotel_names: dict[str, str] = {}
    try:
        hotels = supabase.table("hotels").select("id, name").eq("event_id", event_id).execute()
        rows = hotels.data or []
        hotel_ids = [h["id"] for h in rows]
        hotel_names = {h["id"]: (h.get("name") or "") for h in rows}
        if hotel_ids:
            nights = consolidation_service.fetch_all_hotel_nights(supabase, hotel_ids)
    except Exception as exc:
        logger.warning("Rooming list: could not read nights: %s", exc)

    return participants, nights, True, hotel_names


def _latest_generation(
    event_id: str, supabase: Client
) -> tuple[Optional[dict[str, Any]], bool]:
    """The most recent stored generation, and whether storage exists at all.

    ``(None, False)`` means migration 013 has not run — the feature is
    unavailable rather than empty, and the caller says so instead of pretending
    nobody has ever generated anything.
    """
    try:
        res = (
            supabase.table("rooming_lists")
            .select("*")
            .eq("event_id", event_id)
            .order("version", desc=True)
            .limit(1)
            .execute()
        )
    except Exception as exc:
        logger.info("Rooming generation storage unavailable (migration 013?): %s", exc)
        return None, False
    rows = res.data or []
    return (rows[0] if rows else None), True


@router.get(
    "/events/{event_id}/rooming-list",
    summary="The generated rooming list, and whether it still holds",
)
async def rooming_list(
    event_id: str,
    view: str = Query("rooms", pattern="^(rooms|participants)$"),
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """What the last generation said — not what the data says now.

    A rooming list is a document: printed, sent, referred to by number. So this
    returns the stored version verbatim, and separately reports whether the
    underlying data has moved on since (``stale``). It never silently serves a
    newer list under an older version number.

    Before migration 013 there is nowhere to store a generation, so the endpoint
    falls back to the live derivation and says ``storage_available: false`` —
    the screen keeps working, the Generate button explains itself.
    """
    await verify_event_access(event_id, current_user, supabase)

    participants, nights, available, hotel_names = _rooming_inputs(event_id, supabase)
    if not available:
        return {
            "view": view, "rooms": [], "participants": [], "summary": {},
            "available": False, "storage_available": False, "generated": False,
            "stale": False, "version": 0, "generated_at": None, "changes": [],
            "roommate_gaps": [],
        }

    latest, storage_available = _latest_generation(event_id, supabase)

    if not storage_available:
        # No storage yet: show the live derivation, as before migration 013.
        rooms = room_service.occupancy(participants, nights)
        return {
            "view": view,
            "rooms": rooms,
            "participants": room_service.participant_view(rooms),
            "summary": room_service.summarise(rooms),
            "available": True, "storage_available": False, "generated": False,
            "stale": False, "version": 0, "generated_at": None, "changes": [],
            "roommate_gaps": roommate_gaps(participants),
        }

    if latest is None:
        # Storage exists and nobody has generated. That is an empty screen ON
        # PURPOSE: the list is something a person makes, and showing a plausible
        # one here would be exactly the automatic behaviour this replaces.
        return {
            "view": view, "rooms": [], "participants": [], "summary": {},
            "available": True, "storage_available": True, "generated": False,
            "stale": False, "version": 0, "generated_at": None, "changes": [],
            "roommate_gaps": roommate_gaps(participants),
        }

    payload = latest.get("payload") or {}
    # Replayed with the SAME default room type the version was generated with.
    # Recomputing it as singles would make a list generated as doubles read as
    # permanently stale, and "regenerate" would never stop asking.
    generated_type = str(payload.get("default_room_type") or rooming_plan.DEFAULT_ROOM_TYPE)
    live = rooming_plan.plan(
        participants, nights, previous=payload,
        default_room_type=generated_type, hotel_names=hotel_names,
    )

    return {
        "view": view,
        "rooms": payload.get("rooms") or [],
        "participants": payload.get("participants") or [],
        "summary": latest.get("summary") or payload.get("summary") or {},
        "available": True,
        "storage_available": True,
        "generated": True,
        "version": latest.get("version") or 1,
        "generated_at": latest.get("generated_at"),
        "note": latest.get("note") or "",
        "stale": live["fingerprint"] != (latest.get("fingerprint") or ""),
        "changes": rooming_plan.differences(payload, live),
        "roommate_gaps": roommate_gaps(participants),
        "default_room_type": generated_type,
    }


def _stored_rooming_presets(supabase: Client, event_id: str) -> Any:
    """The event's saved presets, or None before migration 023."""
    try:
        resp = (
            supabase.table("events")
            .select("rooming_presets")
            .eq("id", event_id)
            .limit(1)
            .execute()
        )
    except Exception:
        return None
    rows = resp.data if isinstance(resp.data, list) else []
    return rows[0].get("rooming_presets") if rows else None


@router.get(
    "/events/{event_id}/rooming-presets",
    summary="The event's saved rooming-list numbering presets (point 4)",
)
async def get_rooming_presets(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Empty rather than an error before migration 023 — a collaborator who
    has never saved a preset sees the same thing either way: nothing saved
    yet, type the numbers once and save them."""
    await verify_event_access(event_id, current_user, supabase)
    return {"presets": rooming_plan.resolve_presets(_stored_rooming_presets(supabase, event_id))}


@router.put(
    "/events/{event_id}/rooming-presets",
    summary="Save the event's rooming-list numbering presets",
)
async def set_rooming_presets(
    event_id: str,
    body: RoomingPresetsUpdate,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Replaces the whole set — the same contract transfer-settings already
    uses. A collaborator who deleted a preset on screen deleted it; silently
    keeping it server-side would put it back."""
    await verify_event_access(event_id, current_user, supabase, write=True)
    clean = rooming_plan.resolve_presets([p.model_dump() for p in body.presets])
    try:
        supabase.table("events").update({"rooming_presets": clean}).eq("id", event_id).execute()
    except Exception as exc:
        logger.error("Failed to save rooming presets for event %s: %s", event_id, exc)
        raise HTTPException(
            status.HTTP_500_INTERNAL_SERVER_ERROR,
            "Impossible d'enregistrer les presets. La migration 023 a-t-elle été appliquée ?",
        ) from exc
    return {"presets": clean}


@router.get(
    "/events/{event_id}/rooming-list/preview",
    summary="What generating would produce right now",
)
async def rooming_list_preview(
    event_id: str,
    start_number: int = Query(rooming_plan.DEFAULT_START, ge=0, le=99999),
    prefix: str = Query("", max_length=8),
    renumber: bool = Query(False),
    default_room_type: str = Query(rooming_plan.DEFAULT_ROOM_TYPE),
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """A proposal, and the diff against the list currently in force.

    This is what makes "Regenerate" a decision rather than a leap: an organizer
    who has already sent version 3 to the hotel sees "2 départs, 1 changement de
    chambre" before pressing anything.
    """
    await verify_event_access(event_id, current_user, supabase)

    participants, nights, available, hotel_names = _rooming_inputs(event_id, supabase)
    if not available:
        return {"rooms": [], "participants": [], "summary": {}, "changes": [], "available": False}

    latest, _ = _latest_generation(event_id, supabase)
    previous = (latest or {}).get("payload") or None

    try:
        proposal = rooming_plan.plan(
            participants, nights,
            previous=previous, start_number=start_number,
            prefix=prefix, renumber=renumber,
            default_room_type=_room_type_option(default_room_type),
            hotel_names=hotel_names,
        )
    except rooming_plan.RoomingPlanError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc

    changes = rooming_plan.differences(previous, proposal)
    return {
        **proposal,
        "changes": changes,
        "summary_line": rooming_plan.describe(changes),
        "available": True,
        "current_version": (latest or {}).get("version") or 0,
    }


@router.post(
    "/events/{event_id}/rooming-list/generate",
    status_code=status.HTTP_201_CREATED,
    summary="Generate a new version of the rooming list",
)
async def generate_rooming_list(
    event_id: str,
    body: RoomingGenerateRequest | None = None,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Make the list. Deliberately, and with a version number.

    The generated numbers are written back onto the fiches so that every export
    and every screen reads one truth — except where somebody has locked
    ``room_number`` by hand, which is a correction and outranks a generation.
    """
    await verify_event_access(event_id, current_user, supabase)
    body = body or RoomingGenerateRequest()

    participants, nights, available, hotel_names = _rooming_inputs(event_id, supabase)
    if not available:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            "The rooming list needs migration 012 (participants.room_number).",
        )

    latest, storage_available = _latest_generation(event_id, supabase)
    if not storage_available:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            "Generating a rooming list needs migration 013 (rooming_lists).",
        )

    # §4: a shared room with nobody on the other side blocks the list. Refused
    # with the gaps named, so the answer is "go fix these four" rather than
    # "something is wrong". `force` generates anyway, deliberately.
    gaps = roommate_gaps(participants)
    if gaps and not body.force:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            detail={
                "code": "roommate_gaps",
                "message": (
                    f"{len(gaps)} chambre(s) partagée(s) sans binôme confirmé. "
                    "Corrigez-les, ou générez quand même."
                ),
                "gaps": gaps[:100],
                "count": len(gaps),
            },
        )

    previous = (latest or {}).get("payload") or None
    try:
        proposal = rooming_plan.plan(
            participants, nights,
            previous=previous, start_number=body.start_number,
            prefix=body.prefix, renumber=body.renumber,
            default_room_type=body.default_room_type,
            hotel_names=hotel_names,
        )
    except rooming_plan.RoomingPlanError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc

    if not proposal["rooms"]:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            "Nothing to generate: no participant has a stay or a room type yet.",
        )

    version = ((latest or {}).get("version") or 0) + 1
    changes = rooming_plan.differences(previous, proposal)

    stored = (
        supabase.table("rooming_lists")
        .insert({
            "event_id": event_id,
            "version": version,
            "payload": {
                "rooms": proposal["rooms"],
                "participants": proposal["participants"],
                "summary": proposal["summary"],
                # Stored so the staleness check can replay this generation
                # rather than recompute a different one.
                "default_room_type": body.default_room_type,
            },
            "summary": proposal["summary"],
            "fingerprint": proposal["fingerprint"],
            "note": (body.note or "").strip()[:500] or None,
            "generated_by": current_user["id"],
        })
        .execute()
    )

    written = _write_back_numbers(
        event_id, supabase, participants, proposal, current_user["id"]
    )

    return {
        "version": version,
        "id": (stored.data or [{}])[0].get("id"),
        "summary": proposal["summary"],
        "rooms": proposal["rooms"],
        "participants": proposal["participants"],
        "changes": changes,
        "summary_line": rooming_plan.describe(changes),
        "numbers_written": written,
    }


def _write_back_numbers(
    event_id: str,
    supabase: Client,
    participants: list[dict[str, Any]],
    proposal: dict[str, Any],
    user_id: str,
) -> int:
    """Put the generated numbers on the fiches, sparing the locked ones.

    A locked ``room_number`` is somebody's correction — typically the number the
    hotel phoned through — and a generation must not undo it. It is skipped
    silently here because the plan already refused to touch hotel-given numbers;
    a lock on top of that is belt and braces.
    """
    by_id = {p["id"]: p for p in participants if p.get("id")}
    written = 0
    for pid, number in rooming_plan.assignments(proposal).items():
        person = by_id.get(pid)
        if person is None:
            continue
        locked = person.get("locked_fields")
        if isinstance(locked, list):
            locked = {f: True for f in locked}
        elif not isinstance(locked, dict):
            locked = {}
        current = str(person.get("room_number") or "").strip()
        if locked.get("room_number") or current == number:
            continue
        try:
            log_change(
                supabase, event_id=event_id, user_id=user_id,
                entity_type="participant", entity_id=pid,
                field_name="room_number", old_value=current or None,
                new_value=number, reason="rooming_list_generated", source="system",
            )
            supabase.table("participants").update(
                {"room_number": number}
            ).eq("id", pid).execute()
            written += 1
        except Exception as exc:
            logger.warning("Rooming: could not write room %s on %s: %s", number, pid, exc)
    return written


# ---------------------------------------------------------------------------
# The hotel's own file, read back in
# ---------------------------------------------------------------------------
#
# We send them a list; three days later they send one back with the real room
# numbers on it. Retyping ninety of those by hand is precisely the work this
# product exists to remove, so it is two endpoints:
#
#   POST /rooming-list/import/preview   read the file, match, change nothing
#   POST /rooming-list/import           write the lines a person accepted
#
# Split in two on purpose. A hotel file with a shifted header row would
# otherwise move ninety people into the wrong rooms without anybody seeing it.

_IMPORT_MAX_BYTES = 10 * 1024 * 1024


def _room_type_option(value: Any) -> str:
    """The default room type, or ours if the caller sent something else.

    Query parameters arrive as free text; a typo must fall back to the safe
    answer rather than book an event into a room type nobody named.
    """
    candidate = str(value or "").strip().lower()
    return candidate if candidate in rooming_plan.ROOM_TYPES else rooming_plan.DEFAULT_ROOM_TYPE


def _participants_for_import(event_id: str, supabase: Client) -> list[dict[str, Any]]:
    """Everybody on the event, with what it takes to recognise them.

    Paged: PostgREST stops at a thousand rows, and an import that silently
    ignored participant 1001 would report them as "introuvable" and invite
    somebody to create a duplicate fiche.
    """
    out: list[dict[str, Any]] = []
    limit, offset = 1000, 0
    while True:
        resp = (
            supabase.table("participants")
            .select("id, first_name, last_name, email, room_number, room_type, locked_fields")
            .eq("event_id", event_id)
            .range(offset, offset + limit - 1)
            .execute()
        )
        rows = resp.data or []
        out.extend(rows)
        if len(rows) < limit:
            return out
        offset += limit


@router.post(
    "/events/{event_id}/rooming-list/import/preview",
    summary="Read a hotel's rooming file and show what it would change",
)
async def preview_rooming_import(
    event_id: str,
    file: UploadFile = File(..., description="The hotel's file (.xlsx, .xls, .csv)."),
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """What the file says, line by line, and nothing written.

    Every line comes back with a status and the fiche it resolved to, so the
    person about to press Apply can see that "Room" really was the room column
    and that the four unmatched names are the four people who cancelled.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    raw = await file.read()
    if len(raw) > _IMPORT_MAX_BYTES:
        raise HTTPException(
            status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            "Fichier trop volumineux (max 10 Mo).",
        )

    try:
        rows, mapping = rooming_import.read_file(raw, file.filename or "hotel.xlsx")
    except rooming_import.RoomingImportError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc
    except HTTPException:
        raise  # read_tabular already says what is wrong with the extension
    except Exception as exc:
        logger.warning("Rooming import: unreadable file for event %s: %s", event_id, exc)
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            "Fichier illisible. Attendu un .xlsx, .xls ou .csv.",
        ) from exc

    participants = _participants_for_import(event_id, supabase)
    result = rooming_import.match(rows, participants)
    return {
        "filename": file.filename or "",
        "columns": mapping,
        "lines": result["lines"],
        "summary": result["summary"],
        "summary_line": rooming_import.describe(result["summary"]),
    }


@router.post(
    "/events/{event_id}/rooming-list/import",
    summary="Write the room numbers a hotel's file gave us",
)
async def apply_rooming_import(
    event_id: str,
    body: RoomingImportApply,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Put the hotel's numbers on the fiches, one fiche at a time.

    One at a time, and a failure on one is recorded rather than raised: a batch
    that abandons on the first rejection leaves half the event updated and
    reports nothing, which is worse than either finishing or refusing.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    known = {p["id"]: p for p in _participants_for_import(event_id, supabase)}
    updated = 0
    skipped = 0
    failures: list[dict[str, str]] = []

    for line in body.lines:
        pid = str(line.participant_id)
        person = known.get(pid)
        if person is None:
            # Not on this event. Refused rather than written: the id came from
            # a browser, and an import must not reach across events.
            failures.append({"participant_id": pid, "error": "participant hors de cet événement"})
            continue

        number = line.room_number.strip()
        current = str(person.get("room_number") or "").strip()
        room_type = rooming_import.clean_type(line.room_type)
        current_type = str(person.get("room_type") or "").strip()

        updates: dict[str, Any] = {}
        if number and number != current:
            updates["room_number"] = number
        if room_type and room_type.lower() != current_type.lower():
            updates["room_type"] = room_type

        if not updates:
            skipped += 1
            continue

        if body.lock:
            # The hotel owns its room numbers. Locking says so, and keeps a
            # later generation or consolidation from taking one back.
            locked = person.get("locked_fields")
            if isinstance(locked, list):
                locked = {field: True for field in locked}
            elif not isinstance(locked, dict):
                locked = {}
            for field in updates:
                locked[field] = True
            updates["locked_fields"] = locked

        try:
            for field, value in updates.items():
                if field == "locked_fields":
                    continue
                log_change(
                    supabase, event_id=event_id, user_id=current_user["id"],
                    entity_type="participant", entity_id=pid,
                    field_name=field,
                    old_value=(current if field == "room_number" else current_type) or None,
                    new_value=value, reason="hotel_rooming_file", source="import",
                )
            supabase.table("participants").update(updates).eq("id", pid).execute()
            updated += 1
        except Exception as exc:
            logger.warning("Rooming import: could not write %s on %s: %s", number, pid, exc)
            failures.append({"participant_id": pid, "error": str(exc)[:200]})

    return {
        "updated": updated,
        "skipped": skipped,
        "failed": len(failures),
        "failures": failures[:50],
    }


@router.get(
    "/events/{event_id}/rooming-list/versions",
    summary="Every generation of this event's rooming list",
)
async def rooming_list_versions(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """The history, without the payloads.

    Versions are kept rather than overwritten: a hotel holding version 3 must
    still be answerable when the office is looking at version 5.
    """
    await verify_event_access(event_id, current_user, supabase)
    try:
        res = (
            supabase.table("rooming_lists")
            .select("id, version, summary, note, generated_at, generated_by")
            .eq("event_id", event_id)
            .order("version", desc=True)
            .execute()
        )
    except Exception as exc:
        logger.info("Rooming versions unavailable (migration 013?): %s", exc)
        return {"versions": [], "available": False}
    return {"versions": res.data or [], "available": True}
