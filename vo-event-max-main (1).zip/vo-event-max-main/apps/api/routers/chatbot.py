"""
routers/chatbot.py — Project-scoped conversational assistant (Feedback V1 §7).

Routes:
  GET    /api/events/{event_id}/chat/suggestions      Starter questions for the UI
  POST   /api/events/{event_id}/chat                  Ask a question about this event
  GET    /api/events/{event_id}/chat/conversations    My threads on this event
  GET    /api/chat/conversations/{conversation_id}    One thread, in full
  DELETE /api/chat/conversations/{conversation_id}    Forget a thread

Scope is enforced twice over: ``verify_event_access`` gates who may ask, and
services/chatbot_service only ever queries the event named in the path — the
assistant has no way to reach another event's data, which is exactly what the
brief asks for ("connecté uniquement à la mémoire de l'événement sélectionné").

Conversations add a third scope. They belong to the user who had them, and every
read is filtered by event AND user: an id alone is never enough to open somebody
else's thread.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from supabase import Client

from dependencies import get_current_user, get_supabase_client, verify_event_access
from models.schemas import (
    ChatAnswer, ChatConversationSummary, ChatMessage, ChatQuestion,
    ChatSuggestions, ChatTranscript, MessageResponse,
)
from services import chat_history, chatbot_service

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get(
    "/events/{event_id}/chat/suggestions",
    response_model=ChatSuggestions,
    summary="Starter questions and stated capabilities for the assistant",
)
async def get_suggestions(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> ChatSuggestions:
    await verify_event_access(event_id, current_user, supabase)
    return ChatSuggestions(
        questions=chatbot_service.SUGGESTED_QUESTIONS,
        capabilities=chatbot_service.CAPABILITIES_FR,
    )


@router.post(
    "/events/{event_id}/chat",
    response_model=ChatAnswer,
    summary="Ask a question about this event's consolidated data",
)
async def ask(
    event_id: str,
    body: ChatQuestion,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> ChatAnswer:
    """Answer, and remember the exchange.

    When ``conversation_id`` names a stored thread, the context comes from that
    record and the ``history`` in the request is ignored: a caller who can
    supply the history can supply a fabricated one, and the assistant's
    follow-up resolution would then be shaped by whatever they invented.

    Storage is entirely best-effort. A deployment without migration 019 answers
    exactly as it always did, with ``conversation_id`` coming back null and the
    browser continuing to carry the thread itself.
    """
    await verify_event_access(event_id, current_user, supabase)
    user_id = current_user["id"]

    conversation_id: Optional[str] = str(body.conversation_id) if body.conversation_id else None
    history = [t.model_dump() for t in body.history]

    if conversation_id:
        conversation, messages = chat_history.load(
            supabase, conversation_id, event_id, user_id
        )
        if conversation is None:
            # Either it never existed, belongs to somebody else, or the tables
            # are not there. None of the three is worth a 404 that empties the
            # user's screen: the question is still answerable, it just starts a
            # new thread.
            logger.info("Chat conversation %s not readable — starting a new one", conversation_id)
            conversation_id = None
        else:
            history = chat_history.recent(messages)

    result = chatbot_service.answer_question(
        question=body.question,
        event_id=event_id,
        supabase=supabase,
        user_role=current_user.get("role", "viewer"),
        history=history,
    )

    if conversation_id is None:
        conversation_id = chat_history.start(supabase, event_id, user_id, body.question)
    if conversation_id:
        chat_history.append(supabase, conversation_id, body.question, result)

    logger.info(
        "Chat event=%s user=%s intent=%s answered=%s thread=%s",
        event_id, user_id, result.get("intent"), result.get("answered"),
        conversation_id or "-",
    )
    return ChatAnswer(**result, conversation_id=conversation_id)


@router.get(
    "/events/{event_id}/chat/conversations",
    response_model=list[ChatConversationSummary],
    summary="My assistant threads on this event",
)
async def list_conversations(
    event_id: str,
    limit: int = Query(30, ge=1, le=100),
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> list[ChatConversationSummary]:
    """Mine, not the team's.

    What somebody asks the assistant reveals what they are worried about, and
    that is not team-wide information by default.
    """
    await verify_event_access(event_id, current_user, supabase)

    try:
        conversations = (
            supabase.table("chat_conversations")
            .select("*")
            .eq("event_id", event_id)
            .eq("user_id", current_user["id"])
            .order("updated_at", desc=True)
            .limit(limit)
            .execute()
        ).data or []
    except Exception as exc:
        logger.info("Chat history unavailable (migration 019?): %s", exc)
        return []

    if not conversations:
        return []

    # One query for every thread's messages rather than one per thread: a
    # sidebar that costs thirty round-trips to draw is a sidebar people close.
    counts: dict[str, list[dict[str, Any]]] = {}
    try:
        rows = (
            supabase.table("chat_messages")
            .select("conversation_id, role, answered")
            .in_("conversation_id", [c["id"] for c in conversations])
            .execute()
        ).data or []
        for row in rows:
            counts.setdefault(row["conversation_id"], []).append(row)
    except Exception as exc:
        logger.warning("Could not count chat messages: %s", exc)

    return [
        ChatConversationSummary(**chat_history.summarise(c, counts.get(c["id"], [])))
        for c in conversations
    ]


@router.get(
    "/chat/conversations/{conversation_id}",
    response_model=ChatTranscript,
    summary="One thread, in full",
)
async def get_conversation(
    conversation_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> ChatTranscript:
    conversation, messages = await _own_conversation(supabase, conversation_id, current_user)
    return ChatTranscript(
        conversation=ChatConversationSummary(
            **chat_history.summarise(conversation, messages)
        ),
        messages=[ChatMessage(**m) for m in messages],
    )


@router.delete(
    "/chat/conversations/{conversation_id}",
    response_model=MessageResponse,
    summary="Forget a thread",
)
async def delete_conversation(
    conversation_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> MessageResponse:
    """Deleting is real: the messages cascade with the conversation.

    A transcript nobody can remove is a transcript that accumulates, and this
    one holds what people asked about named participants.
    """
    await _own_conversation(supabase, conversation_id, current_user)
    try:
        supabase.table("chat_conversations").delete().eq("id", conversation_id).execute()
    except Exception as exc:
        logger.error("Could not delete conversation %s: %s", conversation_id, exc)
        raise HTTPException(
            status.HTTP_500_INTERNAL_SERVER_ERROR,
            "Impossible de supprimer cette conversation.",
        ) from exc
    return MessageResponse(message="Conversation supprimée.")


async def _own_conversation(
    supabase: Client, conversation_id: str, current_user: dict[str, Any]
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """The thread, if it is this user's. 404 otherwise — never 403.

    Telling somebody a conversation exists but is not theirs is itself a
    disclosure: it confirms that a colleague asked something, on this event, at
    this id.
    """
    try:
        found = (
            supabase.table("chat_conversations")
            .select("*")
            .eq("id", conversation_id)
            .eq("user_id", current_user["id"])
            .execute()
        ).data or []
    except Exception as exc:
        logger.info("Chat history unavailable (migration 019?): %s", exc)
        raise HTTPException(
            status.HTTP_404_NOT_FOUND, "Conversation introuvable."
        ) from exc

    if not found:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Conversation introuvable.")

    conversation = found[0]
    # Owning the thread is not enough. Access to a project can be revoked after
    # a conversation was had, and the transcript quotes that event's data — so
    # the event gate is re-checked on every read, not only when the question
    # was originally asked.
    await verify_event_access(conversation["event_id"], current_user, supabase)

    try:
        messages = (
            supabase.table("chat_messages")
            .select("role, content, intent, answered, row_count, created_at")
            .eq("conversation_id", conversation_id)
            .order("created_at")
            .limit(chat_history.MAX_TRANSCRIPT)
            .execute()
        ).data or []
    except Exception as exc:
        logger.warning("Could not read transcript: %s", exc)
        messages = []
    return conversation, messages
