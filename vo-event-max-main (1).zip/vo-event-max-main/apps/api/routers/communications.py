# -*- coding: utf-8 -*-
"""
communications.py
=================
Participant confirmation generation + communication tracking (feedback §13 and
the "Lettre individuelle" module).

Routes:
- POST /api/events/{event_id}/participants/{participant_id}/confirmation/generate
- GET  /api/events/{event_id}/communications
- PATCH /api/communications/{communication_id}
- POST  /api/communications/{communication_id}/send
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel, Field
from supabase import Client

from dependencies import get_current_user, get_supabase_client, require_role, verify_event_access
from services import confirmation_service, campaign_service

logger = logging.getLogger(__name__)


def _stamp() -> str:
    """Now, as a value Postgres accepts."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()

router = APIRouter()


class CommunicationUpdate(BaseModel):
    subject: Optional[str] = None
    body: Optional[str] = None
    status: Optional[str] = None


class CampaignRequest(BaseModel):
    mode: str = "template"          # 'template' (placeholders) or 'ai'
    subject: str = ""
    body: str = ""
    instructions: str = ""          # used in 'ai' mode
    send: bool = False              # False = generate/store only; True = deliver
    # Empty means every participant of the event. Naming one is the individual
    # letter: same personalisation, same tracking row, one recipient.
    participant_ids: list[str] = []


@router.post("/events/{event_id}/campaigns/preview")
async def preview_campaign(
    event_id: str,
    payload: CampaignRequest,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Preview a few personalized examples + recipient count (no send, no persist)."""
    await verify_event_access(event_id, current_user, supabase, write=True)
    return campaign_service.preview(
        supabase, event_id, payload.mode, payload.subject, payload.body,
        payload.instructions, participant_ids=payload.participant_ids,
    )


@router.post("/events/{event_id}/campaigns/send")
async def send_campaign(
    event_id: str,
    payload: CampaignRequest,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """
    Generate a personalized email per participant, store each in communications,
    and (if payload.send) deliver via the connected mailbox.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)
    return await campaign_service.run_campaign(
        supabase, event_id, payload.mode, payload.subject, payload.body,
        payload.instructions, payload.send, current_user["id"],
        participant_ids=payload.participant_ids,
    )


@router.post("/events/{event_id}/participants/{participant_id}/confirmation/generate")
async def generate_confirmation(
    event_id: str,
    participant_id: str,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """
    Generate an individual confirmation draft from the participant's consolidated
    data and persist it as a `communications` row (status=draft).
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    draft = confirmation_service.generate_confirmation(supabase, participant_id)

    row: Optional[dict[str, Any]] = None
    persisted = False
    try:
        payload = {
            "event_id": event_id,
            "participant_id": participant_id,
            "type": "confirmation",
            "channel": "email",
            "subject": draft["subject"],
            "body": draft["body"],
            "status": "draft",
            "created_by": current_user["id"],
        }
        res = supabase.table("communications").insert(payload).execute()
        row = res.data[0] if res.data else None
        persisted = True
    except Exception as exc:
        # Table may not exist yet (migration not run). Still return the draft so
        # the user can preview it; it just isn't tracked until the table exists.
        logger.warning("Could not persist communication (run migration 002?): %s", exc)

    return {
        "communication": row,
        "persisted": persisted,
        "subject": draft["subject"],
        "body": draft["body"],
        "facts": draft["facts"],
        "missing": draft["missing"],
        "source": draft["source"],
    }


@router.get(
    "/events/{event_id}/participants/{participant_id}/confirmation/pdf",
    summary="The participant's own confirmation, as a PDF (feedback §16)",
)
async def confirmation_pdf(
    event_id: str,
    participant_id: str,
    lang: str = "fr",
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> Response:
    """A functional document, deliberately — the design comes later (§16).

    Only facts actually present appear: a section with nothing behind it is
    omitted rather than printed empty, because a traveller reading
    "Transfer: —" concludes there is no transfer.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)

    from services import confirmation_pdf as pdf_service
    from services import registration_i18n

    facts = confirmation_service.facts_for(supabase, participant_id)
    facts.pop("_event_id", None)

    organiser = ""
    try:
        res = (
            supabase.table("events")
            .select("name, organiser_contact")
            .eq("id", event_id)
            .single()
            .execute()
        )
        organiser = (res.data or {}).get("organiser_contact") or ""
    except Exception:
        # The column is optional; a confirmation without a contact block is
        # still a valid confirmation.
        pass

    from datetime import date as _date

    try:
        data = pdf_service.build(
            facts, registration_i18n.normalise(lang), organiser=organiser,
            # Stamped so a participant holding two versions can tell which is
            # the later one — a confirmation without a date is unarguable.
            generated_on=_date.today().isoformat(),
        )
    except pdf_service.PdfUnavailable as exc:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            "PDF generation is unavailable on this deployment; use the email version.",
        ) from exc

    return Response(
        content=data,
        media_type="application/pdf",
        # Both spellings of the name: an ASCII fallback every client
        # understands, and the real one with its accents for the rest.
        headers={"Content-Disposition": pdf_service.content_disposition(facts)},
    )


# ---------------------------------------------------------------------------
# Request Missing Information (feedback §14)
# ---------------------------------------------------------------------------
#
# The loop the feedback describes is eight steps long and six of them already
# existed: the exception engine spots the gap, the email agent reads the reply,
# extracts the value, proposes it, a human validates, the master list updates.
# What was missing is steps 1 and 2 — prepare the mail, and send it.
#
# Nothing here sends. It builds drafts, in the participant's own language, and
# they go out through the same review-then-send lifecycle as every other
# outbound message. An email that leaves without anybody reading it is not a
# feature, it is an incident waiting for a Monday morning.


class InformationRequestBody(BaseModel):
    """Which gaps to chase. Empty means every unresolved exception."""
    exception_ids: list[str] = []
    participant_ids: list[str] = []
    deadline: str = ""
    sender: str = ""


# Columns added by later migrations. Selected separately because PostgREST fails
# the WHOLE select when one column is absent, and a deployment that has not run
# 009/010 must still be able to chase a missing phone number.
_EXTRA_COLUMNS = (
    "id, language, passport_number, passport_expiry, date_of_birth, "
    "emergency_contact_name, emergency_contact_phone, pmr_needs, roommate_name"
)


def _participants_for_requests(
    supabase: Client, event_id: str, participant_ids: list[str]
) -> list[dict[str, Any]]:
    """The core fiche, enriched with whatever extended columns exist."""
    query = (
        supabase.table("participants")
        .select(
            "id, first_name, last_name, email, phone, nationality, "
            "dietary_requirements, has_flight"
        )
        .eq("event_id", event_id)
    )
    if participant_ids:
        query = query.in_("id", participant_ids)
    rows = query.execute().data or []

    try:
        extra_query = supabase.table("participants").select(_EXTRA_COLUMNS).eq("event_id", event_id)
        if participant_ids:
            extra_query = extra_query.in_("id", participant_ids)
        extra = {r["id"]: r for r in (extra_query.execute().data or [])}
    except Exception as exc:
        logger.info("Information requests: extended columns unavailable: %s", exc)
        extra = {}

    for row in rows:
        for key, value in (extra.get(row["id"]) or {}).items():
            if key != "id":
                row.setdefault(key, value)
    return rows


def _build_requests(
    supabase: Client, event_id: str, payload: InformationRequestBody
) -> dict[str, Any]:
    """Everything both endpoints need, composed but not persisted."""
    from services import field_policy, information_request

    query = (
        supabase.table("exceptions")
        .select("id, participant_id, exception_type, context_data")
        .eq("event_id", event_id)
        .eq("resolved", False)
    )
    if payload.exception_ids:
        query = query.in_("id", payload.exception_ids)
    exceptions = query.execute().data or []

    wanted = information_request.fields_from_exceptions(exceptions)
    if payload.participant_ids:
        keep = set(payload.participant_ids)
        wanted = {pid: ask for pid, ask in wanted.items() if pid in keep}

    participants = _participants_for_requests(
        supabase, event_id, payload.participant_ids or list(wanted)
    )
    policy = field_policy.for_event(supabase, event_id)
    requests, skipped = information_request.plan_requests(participants, wanted, policy)

    event_name = ""
    try:
        res = supabase.table("events").select("name").eq("id", event_id).single().execute()
        event_name = (res.data or {}).get("name") or ""
    except Exception:
        pass

    drafts = []
    for request in requests:
        subject, body = information_request.compose(
            request, event_name, sender=payload.sender, deadline=payload.deadline
        )
        drafts.append({**request, "subject": subject, "body": body})

    return {
        "drafts": drafts,
        "skipped": skipped,
        "summary": information_request.summarise(requests, skipped),
        "event_name": event_name,
    }


@router.post("/events/{event_id}/information-requests/preview")
async def preview_information_requests(
    event_id: str,
    payload: InformationRequestBody,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """What would be asked, of whom, in which language. Persists nothing.

    The ``skipped`` list is as important as the drafts: "we prepared 40 of your
    47" is only useful with the other seven named — and one of the reasons is
    that we have no email address for them at all, which no amount of emailing
    will fix.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)
    return _build_requests(supabase, event_id, payload)


@router.post("/events/{event_id}/information-requests")
async def create_information_requests(
    event_id: str,
    payload: InformationRequestBody,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Store the drafts. Sending stays a separate, deliberate act.

    Each row records the fields it asked about, so the reply the email agent
    parses can be matched against the question rather than trusted on its own.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)
    built = _build_requests(supabase, event_id, payload)

    created: list[dict[str, Any]] = []
    tracked = True
    for draft in built["drafts"]:
        row = {
            "event_id": event_id,
            "participant_id": draft["participant_id"],
            "type": "information_request",
            "channel": "email",
            "subject": draft["subject"],
            "body": draft["body"],
            "status": "draft",
            "created_by": current_user["id"],
        }
        if tracked:
            row["language"] = draft["language"]
            row["context_data"] = {
                "fields": draft["fields"],
                "exception_ids": draft["exception_ids"],
            }
        try:
            res = supabase.table("communications").insert(row).execute()
            created.append((res.data or [{}])[0])
        except Exception as exc:
            if tracked:
                # Migration 014 not applied: retry once without the two new
                # columns rather than losing the whole batch. The drafts are
                # still stored and still sendable; only the link back to the
                # exception is lost.
                logger.info("Information requests: falling back (migration 014?): %s", exc)
                tracked = False
                row.pop("language", None)
                row.pop("context_data", None)
                try:
                    res = supabase.table("communications").insert(row).execute()
                    created.append((res.data or [{}])[0])
                    continue
                except Exception as inner:
                    logger.warning("Could not store information request: %s", inner)
            else:
                logger.warning("Could not store information request: %s", exc)

    return {
        "created": created,
        "count": len(created),
        "skipped": built["skipped"],
        "summary": built["summary"],
        "tracked": tracked,
    }


# ---------------------------------------------------------------------------
# Nights outside the programme — one letter each, sent as a batch
# ---------------------------------------------------------------------------
#
# The same shape as the information requests above and for the same reason: a
# grouped send of individual letters. Each person is told about their own
# flights and their own nights, and nothing about anybody else's — thirty-six
# people are in this position on one live event, and none of them needs to
# know that.


class OwnExpenseNoticeBody(BaseModel):
    """Who to write to. Empty means everybody the flights place outside the
    programme's dates."""
    participant_ids: list[str] = []
    # A single night outside the dates is usually a late flight rather than an
    # extension; the organizer can raise the bar before writing to anybody.
    min_nights: int = Field(default=1, ge=1, le=60)
    sender: str = ""


def _build_notices(
    supabase: Client, event_id: str, payload: OwnExpenseNoticeBody
) -> dict[str, Any]:
    """Everything both endpoints need, composed but not persisted."""
    from datetime import date as _date

    from services import own_expense_notice, travel_checks

    def _as_day(value):
        if not value:
            return None
        try:
            return _date.fromisoformat(str(value)[:10])
        except (TypeError, ValueError):
            return None

    try:
        event = (
            supabase.table("events").select("name, start_date, end_date")
            .eq("id", event_id).limit(1).execute()
        ).data or [{}]
    except Exception:
        event = [{}]
    event_row = event[0] if event else {}
    start, end = _as_day(event_row.get("start_date")), _as_day(event_row.get("end_date"))

    # Refused rather than guessed. "Outside the programme" has no meaning
    # without the programme's own dates, and a letter telling somebody their
    # nights are their own is not a thing to send on an assumption.
    if not start or not end:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            "Renseignez les dates de l'événement avant d'écrire aux participants : "
            "sans elles, « hors programme » ne veut rien dire.",
        )

    flights: list[dict[str, Any]] = []
    offset = 0
    while True:
        rows = (
            supabase.table("flights")
            .select("participant_id, departure_time, status")
            .eq("event_id", event_id)
            .range(offset, offset + 999)
            .execute()
        ).data or []
        flights.extend(rows)
        if len(rows) < 1000:
            break
        offset += 1000

    stays = travel_checks.staying_at_own_expense(flights, start, end)
    ids = [s["participant_id"] for s in stays]
    participants = _participants_for_requests(supabase, event_id, ids) if ids else []

    notices, skipped = own_expense_notice.plan_notices(
        participants, stays,
        min_nights=payload.min_nights,
        only=payload.participant_ids or None,
    )

    event_name = event_row.get("name") or ""
    drafts = []
    for notice in notices:
        subject, body = own_expense_notice.compose(
            notice, event_name,
            str(event_row.get("start_date") or ""), str(event_row.get("end_date") or ""),
            sender=payload.sender,
        )
        drafts.append({**notice, "subject": subject, "body": body})

    return {
        "drafts": drafts,
        "skipped": skipped,
        "summary": own_expense_notice.summarise(notices, skipped),
        "event_name": event_name,
        "event_start": event_row.get("start_date") or "",
        "event_end": event_row.get("end_date") or "",
    }


@router.post("/events/{event_id}/own-expense-notices/preview")
async def preview_own_expense_notices(
    event_id: str,
    payload: OwnExpenseNoticeBody,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Who would be written to, in which language, saying what. Writes nothing.

    Every draft comes back in full. Telling ninety people that nights they
    have booked are at their own expense is the kind of message that gets read
    twice and forwarded to a manager, so it is shown before it exists.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)
    return _build_notices(supabase, event_id, payload)


@router.post("/events/{event_id}/own-expense-notices")
async def create_own_expense_notices(
    event_id: str,
    payload: OwnExpenseNoticeBody,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Store the letters as drafts. Sending stays a separate, deliberate act.

    Each row records the nights it claimed, so a reply saying "no, I changed my
    flight" can be read against what we actually asserted.
    """
    await verify_event_access(event_id, current_user, supabase, write=True)
    built = _build_notices(supabase, event_id, payload)

    created: list[dict[str, Any]] = []
    tracked = True
    for draft in built["drafts"]:
        row = {
            "event_id": event_id,
            "participant_id": draft["participant_id"],
            "type": "own_expense_notice",
            "channel": "email",
            "subject": draft["subject"],
            "body": draft["body"],
            "status": "draft",
            "created_by": current_user["id"],
        }
        if tracked:
            row["language"] = draft["language"]
            row["context_data"] = {
                "nights": draft["nights"],
                "arrives_early_days": draft["arrives_early_days"],
                "stays_late_days": draft["stays_late_days"],
                "first_departure": draft["first_departure"],
                "last_departure": draft["last_departure"],
            }
        try:
            res = supabase.table("communications").insert(row).execute()
            created.append((res.data or [{}])[0])
        except Exception as exc:
            if tracked:
                # Migration 014 not applied: retry once without the two newer
                # columns rather than losing the batch. The letters are still
                # stored and still sendable; only the trace of what we claimed
                # is lost.
                logger.info("Own-expense notices: falling back (migration 014?): %s", exc)
                tracked = False
                row.pop("language", None)
                row.pop("context_data", None)
                try:
                    res = supabase.table("communications").insert(row).execute()
                    created.append((res.data or [{}])[0])
                    continue
                except Exception as inner:
                    logger.warning("Could not store own-expense notice: %s", inner)
            else:
                logger.warning("Could not store own-expense notice: %s", exc)

    return {
        "created": created,
        "count": len(created),
        "skipped": built["skipped"],
        "summary": built["summary"],
        "tracked": tracked,
    }


@router.get("/events/{event_id}/communications")
async def list_communications(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> list[dict[str, Any]]:
    """Tracking table: all communications for an event with participant names."""
    await verify_event_access(event_id, current_user, supabase)
    try:
        res = (
            supabase.table("communications")
            .select("*, participants(first_name, last_name, email)")
            .eq("event_id", event_id)
            .order("created_at", desc=True)
            .execute()
        )
    except Exception as exc:
        logger.warning("communications list failed (run migration 002?): %s", exc)
        return []

    out = []
    for row in res.data or []:
        part = row.get("participants")
        row["participant_name"] = f"{part['first_name']} {part['last_name']}" if part else None
        out.append(row)
    return out


@router.patch("/communications/{communication_id}")
async def update_communication(
    communication_id: str,
    body: CommunicationUpdate,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Edit a communication's subject/body/status."""
    existing = supabase.table("communications").select("event_id").eq("id", communication_id).maybe_single().execute()
    if not existing.data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Communication not found.")
    await verify_event_access(existing.data["event_id"], current_user, supabase, write=True)

    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No fields to update.")
    # An ISO timestamp, not the string "now()": PostgREST posts the value
    # verbatim and Postgres refuses "now()" as a timestamptz, failing the whole
    # update. Marking a confirmation as sent has been silently impossible.
    updates["updated_at"] = _stamp()

    res = supabase.table("communications").update(updates).eq("id", communication_id).execute()
    return res.data[0] if res.data else {}


@router.post("/communications/{communication_id}/send")
async def send_communication(
    communication_id: str,
    current_user: dict[str, Any] = Depends(require_role(["admin", "pm"])),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """
    Mark a communication as sent. (Actual delivery via the connected mailbox is
    a follow-up; this records the validated send and its timestamp.)
    """
    existing = supabase.table("communications").select("event_id").eq("id", communication_id).maybe_single().execute()
    if not existing.data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Communication not found.")
    await verify_event_access(existing.data["event_id"], current_user, supabase, write=True)

    res = (
        supabase.table("communications")
        .update({"status": "sent", "sent_at": _stamp(), "updated_at": _stamp()})
        .eq("id", communication_id)
        .execute()
    )
    return res.data[0] if res.data else {}
