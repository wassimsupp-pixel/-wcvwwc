"""
routers/public_registration.py — Public, unauthenticated event registration form.

Routes:
  GET  /api/public/register/{token}   Event name + open/closed status
  POST /api/public/register/{token}   Submit a registration

No auth: the token in the URL (events.registration_token, an opaque UUID
distinct from the event id) is the only gate. Degrades safely — until
migration 006 is applied, `registration_token` doesn't exist and every
request here 404s; nothing else in the app is affected.

A submission becomes a normal ``source_records`` row (source_type
'registration') under a single per-event "virtual" uploaded_files row.
consolidation_service.run_consolidation has a matching branch that reads
these back directly (there's no real document in Storage to parse for this
"file"). A successful submit then fires a real OS thread (see
_trigger_background_consolidation below) that runs start_and_run_consolidation
so the new participant lands in the master list within seconds, without the
visitor's browser waiting on it — see that function's docstring for why a
plain FastAPI BackgroundTask isn't used here.
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Response, UploadFile, status
from supabase import Client

import config
from dependencies import get_supabase_client
from models.schemas import PublicRegistrationInfo, PublicRegistrationSubmit
from services import (
    attachment_custody, consolidation_service, payload_cache, registration_form,
    registration_i18n, registration_layout, registration_theme, registration_uploads,
)

logger = logging.getLogger(__name__)

router = APIRouter()

_FORM_FILENAME = "Formulaire d'inscription en ligne"
# Same-email resubmits within this window beyond this count are refused —
# not a real WAF, but stops the obvious double-click / scripted-repeat case
# without needing external rate-limiting infra (no Redis in this stack).
_THROTTLE_WINDOW = timedelta(hours=1)
_THROTTLE_MAX_PER_EMAIL = 3


def _event_logo(supabase: Client, event_id: str) -> str | None:
    """This event's own logo (point 11), or None — kept OUT of
    _find_event_by_token's select on purpose: PostgREST fails the WHOLE
    query when one column is absent, and the public form must keep working
    on a deployment that has not applied migration 026 yet."""
    try:
        res = (
            supabase.table("events")
            .select("logo_url")
            .eq("id", event_id)
            .maybe_single()
            .execute()
        )
        return (res.data or {}).get("logo_url") if res else None
    except Exception:
        return None


def _find_event_by_token(supabase: Client, token: str) -> dict[str, Any] | None:
    try:
        resp = (
            supabase.table("events")
            .select("id, name, project_id, registration_open")
            .eq("registration_token", token)
            .single()
            .execute()
        )
    except Exception:
        return None
    return resp.data


def _system_actor(supabase: Client, project_id: str) -> str | None:
    """The project owner stands in as the 'actor' for records a public form
    creates on nobody's behalf — avoids adding a dedicated service user."""
    try:
        resp = supabase.table("projects").select("created_by").eq("id", project_id).single().execute()
        return resp.data["created_by"] if resp.data else None
    except Exception as exc:
        logger.error("Could not resolve system actor for project %s: %s", project_id, exc)
        return None


def _get_or_create_form_file(supabase: Client, event_id: str, imported_by: str | None) -> str:
    # Ordered so that if two first-ever submissions raced and both inserted a
    # virtual file (no unique constraint on this tuple), every later call
    # converges on the same winner instead of scattering rows across both.
    existing = (
        supabase.table("uploaded_files")
        .select("id")
        .eq("event_id", event_id)
        .eq("source_type", "registration")
        .eq("original_filename", _FORM_FILENAME)
        .order("id")
        .execute()
    )
    if existing.data:
        return existing.data[0]["id"]
    supabase.table("uploaded_files").insert({
        "event_id": event_id,
        "original_filename": _FORM_FILENAME,
        "storage_path": f"public-form/{event_id}",
        "source_type": "registration",
        "import_status": "processed",
        "imported_by": imported_by,
        "column_mapping": {},
    }).execute()
    # Re-read instead of trusting our own insert: the concurrent racer's row
    # may sort first, and both writers must agree on the winning file id.
    settled = (
        supabase.table("uploaded_files")
        .select("id")
        .eq("event_id", event_id)
        .eq("source_type", "registration")
        .eq("original_filename", _FORM_FILENAME)
        .order("id")
        .execute()
    )
    return settled.data[0]["id"]


# A registration wave (organizer mails the link to hundreds of people) must
# not turn into one full master-list rebuild per submission. Each run takes
# 30-60s of DB work; one per minute keeps the list near-live at a fraction
# of the load, and a submission that lands during someone else's run is
# picked up by that run's end-of-run chain (consolidation_service's
# _late_public_form_submissions), so nothing is ever left behind.
_MIN_SECONDS_BETWEEN_RUNS = 60.0


def _debounce_wait_seconds(last_run_started_at: str | None, now: datetime) -> float:
    """Seconds to sleep before starting a run so runs stay at least
    _MIN_SECONDS_BETWEEN_RUNS apart. 0 when there's no previous run, the
    previous one is old enough, or its timestamp is unparsable."""
    if not last_run_started_at:
        return 0.0
    try:
        started = datetime.fromisoformat(last_run_started_at.replace("Z", "+00:00"))
    except ValueError:
        return 0.0
    elapsed = (now - started).total_seconds()
    if elapsed < 0:  # clock skew — don't sleep on a future timestamp
        return 0.0
    return max(0.0, _MIN_SECONDS_BETWEEN_RUNS - elapsed)


def _run_consolidation_in_thread(event_id: str, user_id: str) -> None:
    """Executed inside the dedicated thread started by
    _trigger_background_consolidation. Builds its own Supabase client (a
    request-scoped one shouldn't be assumed safe to reuse once the request
    that created it has returned) and its own asyncio event loop (threads
    don't have one by default) to run the same consolidation path a mapped
    Excel upload uses."""
    try:
        from dependencies import _build_supabase_client
        thread_supabase = _build_supabase_client()

        # Anti-burst debounce (best-effort — any failure falls through to a
        # normal immediate run rather than losing the trigger).
        try:
            triggered_at = datetime.now(timezone.utc)
            last = (
                thread_supabase.table("consolidation_runs")
                .select("started_at")
                .eq("event_id", event_id)
                .order("started_at", desc=True)
                .limit(1)
                .execute()
            )
            wait = _debounce_wait_seconds(
                (last.data or [{}])[0].get("started_at"), triggered_at
            )
            if wait > 0:
                time.sleep(wait)
                # A run that started after this submission was inserted has
                # already read it (the public-form branch reads at step 3) —
                # nothing left to do. If clock skew makes this skip wrongly,
                # that run's end-of-run count check chains a follow-up anyway.
                newer = (
                    thread_supabase.table("consolidation_runs")
                    .select("id")
                    .eq("event_id", event_id)
                    .gte("started_at", triggered_at.isoformat())
                    .limit(1)
                    .execute()
                )
                if newer.data:
                    return
        except Exception:
            pass

        asyncio.run(consolidation_service.start_and_run_consolidation(event_id, user_id, thread_supabase))
    except Exception:
        logger.exception("Background consolidation thread failed for event %s", event_id)


def _trigger_background_consolidation(event_id: str, user_id: str) -> None:
    """Fire-and-forget on a real OS thread, deliberately NOT FastAPI's
    BackgroundTasks: a real submission measured ~58s end to end (2026-07-26)
    because BackgroundTasks awaits the consolidation coroutine on the same
    event loop that still has to flush this request's response, and
    run_consolidation makes many synchronous (blocking) Supabase calls on
    that loop. A plain thread runs fully independently, so the visitor sees
    "Merci !" immediately while the master list updates in the background.
    start_and_run_consolidation no-ops if a run is already fresh for this
    event, so concurrent submissions don't pile up overlapping runs."""
    threading.Thread(target=_run_consolidation_in_thread, args=(event_id, user_id), daemon=True).start()


@router.get(
    "/public/register/{token}",
    response_model=PublicRegistrationInfo,
    summary="Get event info for the public registration form",
)
async def get_registration_info(
    token: str,
    lang: str = "fr",
    # Point 13 (v1): which audience this link was sent to — never something
    # the registrant picks, always appended to the link itself
    # (?badge=slug), the way a real event sends the VIP list a different
    # link than the general one. An unrecognised badge behaves exactly like
    # none at all: every field with no badges list stays visible, and any
    # field actually gated to real badges the link's own value does not
    # match stays hidden — the safe direction on a typo.
    badge: Optional[str] = None,
    response: Response = None,  # type: ignore[assignment]
    supabase: Client = Depends(get_supabase_client),
) -> PublicRegistrationInfo:
    """The form's shape, with the labels in the participant's language.

    Relabelled server-side rather than in the browser (feedback §12): the
    catalogue lives here, the organizer's own questions live in the database,
    and the required-field errors are produced here too. Translating only the
    page chrome would give a form that is Dutch above the fold and French in
    its error messages.

    An unsupported code resolves to French rather than 404ing — the language a
    visitor asks for must never be able to make the form unreachable.
    """
    # Served from cache when we have it. This page costs six database round
    # trips to build and `supabase-py` is synchronous, so each of those blocks
    # the whole worker's event loop rather than just this request — which is
    # what turns three hundred people opening one emailed link into a queue.
    # Two visitors holding the same link in the same language see identical
    # JSON, so it is built once and handed to the rest.
    cache_key = payload_cache.form_key(token, lang, badge)
    cached = payload_cache.public_form.get(cache_key)
    if cached is not None:
        if response is not None:
            response.headers["X-Cache"] = "HIT"
        return PublicRegistrationInfo(**cached)

    event = _find_event_by_token(supabase, token)
    if not event:
        # Deliberately not cached: an unknown token is a bot walking the
        # namespace, and remembering its 404s is how a cache becomes a place
        # to store other people's noise.
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Formulaire introuvable.")
    locale = "en"  # The public registration form is English-only (product rule).
    custom_fields, confirmations = registration_form.fetch_extras(supabase, event["id"])
    fields = registration_form.resolve(registration_form.fetch(supabase, event["id"]), badge=badge)
    # Resolved once: a map of page -> blocks. Its non-home keys are pages the
    # organizer composed in blocks; the nav must include them even when they
    # have no classic body, or a block-only page would be unreachable.
    layout = registration_layout.resolve(registration_layout.fetch(supabase, event["id"]))
    info = PublicRegistrationInfo(
        event_id=event["id"],
        event_name=event["name"],
        is_open=bool(event.get("registration_open", True)),
        fields=registration_i18n.translate_fields(fields, locale),
        # The organizer wrote these in their own words; translating them would
        # mean guessing at wording that may be contractual.
        custom_fields=custom_fields,
        confirmations=confirmations,
        locale=locale,
        # English-only public form: one language, so the page shows no switcher.
        supported_locales=["en"],
        sections=_site_sections(
            supabase, event["id"], locale,
            layout_pages=[k for k in layout if k != "home"],
        ),
        logo_url=_event_logo(supabase, event["id"]),
        # Resolved rather than raw: the page renders a theme, and an event
        # that configured none still has to be given one.
        theme=registration_theme.resolve(registration_theme.fetch(supabase, event["id"])),
        # A map of page -> blocks, {} until an organizer arranges a page and
        # saves — each page then reads its own blocks, or the classic layout
        # when absent, so this adds a capability without changing existing forms.
        layout=layout,
        # Not advertised at all without migration 021 -- otherwise a
        # required passport copy would lock the form for everybody.
        attachments=(
            registration_uploads.requested(fields)
            if attachment_custody.available(supabase) else []
        ),
    )

    # Stored as a plain dict rather than the model: a cached Pydantic object is
    # one accidental mutation away from poisoning every later visitor, and
    # rebuilding from a dict costs nothing next to the six reads it replaces.
    # Owned by the event id so a save can drop it — see the invalidations in
    # routers/events.py.
    payload_cache.public_form.put(cache_key, str(event["id"]), info.model_dump(mode="json"))
    if response is not None:
        response.headers["X-Cache"] = "MISS"
    return info


def _site_sections(
    supabase: Client,
    event_id: str,
    locale: str,
    layout_pages: Optional[list[str]] = None,
) -> list[dict[str, Any]]:
    """The mini site above the form (§11), in the visitor's language.

    Best-effort by design: a page that cannot render its Welcome text must
    still render its form. A broken decoration is not a reason to make an
    event unregisterable.

    `layout_pages` are pages the organizer composed in blocks. A block-only page
    has no classic body, so `event_site.render` drops it — but it still needs a
    nav tab, or it is unreachable. Each such page (known, visible, not already
    shown) is added with a title from its stored section or the catalogue.
    """
    from services import event_site

    try:
        rows = (
            supabase.table("event_site_sections")
            .select("slug, title, body, image_url, visible, position")
            .eq("event_id", event_id)
            .order("position")
            .execute()
        ).data or []
    except Exception as exc:
        logger.info("Event site unavailable (migration 018 not applied?): %s", exc)
        rows = []

    sections = event_site.render(rows, locale)
    if not layout_pages:
        return sections

    present = {s["slug"] for s in sections}
    by_slug = {str(r.get("slug") or "").strip().lower(): r for r in rows}
    for slug in layout_pages:
        if slug in present or not event_site.known(slug):
            continue
        row = by_slug.get(slug)
        if row is not None and not row.get("visible", True):
            continue  # a hidden page stays hidden even when it has blocks
        stored_title = row.get("title") if isinstance(row, dict) else None
        title = ""
        if isinstance(stored_title, dict):
            title = stored_title.get(locale) or stored_title.get("fr") or ""
        sections.append({
            "slug": slug,
            "title": title or event_site.default_title(slug, locale),
            "paragraphs": [],
            "image_url": "",
            "image_position": "above",
            "position": event_site.clean_position(row.get("position") if row else None, slug),
        })

    return sorted(sections, key=lambda s: s["position"])


@router.post(
    "/public/register/{token}/attachment",
    status_code=status.HTTP_201_CREATED,
    summary="Upload a passport copy or a photo from the public form (§9)",
)
async def upload_attachment(
    token: str,
    kind: str = Form(..., description="passport_scan | photo"),
    file: UploadFile = File(...),
    lang: str = "fr",
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """A file from somebody with no account, no session and no history with us.

    Everything that can be refused is refused before a byte reaches storage:
    the token must be live, the event must still be open, the kind must be one
    the event actually asked for, and the file's own bytes must agree with its
    extension. The storage key is generated here — the visitor contributes
    nothing to it.
    """
    locale = "en"  # The public registration form is English-only (product rule).

    event = _find_event_by_token(supabase, token)
    if not event:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Formulaire introuvable.")
    if not event.get("registration_open", True):
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            registration_i18n.message("closed", locale),
        )
    event_id = event["id"]

    # Only what this event asked for. An upload field nobody enabled is not a
    # field, and accepting one anyway would make every event a file host.
    fields = registration_form.resolve(registration_form.fetch(supabase, event_id))
    if kind not in {entry["kind"] for entry in registration_uploads.requested(fields)}:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            "Ce document n'est pas demandé pour cet événement.",
        )

    # Read with a hard ceiling rather than trusting Content-Length, which the
    # client also controls. One byte over the cap and we stop.
    content = await file.read(registration_uploads.MAX_BYTES + 1)
    try:
        descriptor = registration_uploads.validate(
            kind, file.filename or "", content, file.content_type or ""
        )
    except registration_uploads.UploadRefused as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc

    # Piggybacked rather than scheduled: there is no cron in this deployment,
    # and an upload is exactly the moment an event's abandoned ones are worth
    # clearing. Bounded and best-effort — it must never fail somebody's
    # registration.
    try:
        attachment_custody.purge_orphans(supabase, event_id)
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("Orphan purge failed for %s: %s", event_id, exc)

    if _too_many_uploads(supabase, event_id):
        raise HTTPException(
            status.HTTP_429_TOO_MANY_REQUESTS,
            "Trop de fichiers envoyés récemment. Réessayez plus tard.",
        )

    path = registration_uploads.storage_path(event_id, descriptor)
    try:
        supabase.storage.from_(config.SUPABASE_STORAGE_BUCKET).upload(
            path=path, file=content,
            file_options={"content-type": descriptor["content_type"]},
        )
    except Exception as exc:
        logger.error("Registration attachment upload failed for %s: %s", event_id, exc)
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY,
            "Le fichier n'a pas pu être enregistré. Réessayez.",
        ) from exc

    try:
        res = supabase.table("registration_attachments").insert({
            "event_id": event_id,
            "kind": descriptor["kind"],
            "storage_path": path,
            "original_name": descriptor["filename"],
            "content_type": descriptor["content_type"],
            "byte_size": descriptor["byte_size"],
        }).execute()
        attachment_id = (res.data or [{}])[0].get("id")
    except Exception as exc:
        logger.error("Could not record attachment (migration 021?): %s", exc)
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            "Les pièces jointes ne sont pas encore activées pour cet événement.",
        ) from exc

    return {
        "id": attachment_id,
        "kind": descriptor["kind"],
        "filename": descriptor["filename"],
        "byte_size": descriptor["byte_size"],
    }


# An unauthenticated upload endpoint is a storage bill waiting to happen. The
# window is per event rather than per visitor on purpose: we have no reliable
# identity for the caller, and rate-limiting on something they control would
# limit nobody.
_UPLOAD_WINDOW = timedelta(minutes=10)
_UPLOAD_MAX_PER_EVENT = 200


def _too_many_uploads(supabase: Client, event_id: str) -> bool:
    since = (datetime.now(timezone.utc) - _UPLOAD_WINDOW).isoformat()
    try:
        res = (
            supabase.table("registration_attachments")
            .select("id", count="exact")
            .eq("event_id", event_id)
            .gte("created_at", since)
            .execute()
        )
        return (res.count or 0) >= _UPLOAD_MAX_PER_EVENT
    except Exception:
        # No table, or no count: let the upload through. The insert that
        # follows will fail loudly if the table is genuinely missing.
        return False


@router.post(
    "/public/register/{token}",
    status_code=status.HTTP_201_CREATED,
    summary="Submit a public registration for an event",
)
async def submit_registration(
    token: str,
    body: PublicRegistrationSubmit,
    lang: str = "fr",
    # Point 13 (v1): the SAME badge the form was fetched with. Re-sent by
    # the browser on submit (not trusted from the body) so a field hidden
    # for this badge is not required of it either — matching what the
    # visitor actually saw, not what a different badge's link would show.
    badge: Optional[str] = None,
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, str]:
    # The language the participant filled the form in decides the language of
    # everything they read back — including the refusals. A Dutch form that
    # answers "Merci de renseigner : Nationalité" is a form somebody gives up on.
    locale = "en"  # The public registration form is English-only (product rule).

    event = _find_event_by_token(supabase, token)
    if not event:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Formulaire introuvable.")
    if not event.get("registration_open", True):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=registration_i18n.message("closed", locale),
        )

    event_id = event["id"]

    # Honeypot: a bot fills every field it finds, including this one, hidden
    # from real visitors by CSS. Report success without touching the
    # database so scripted retries don't learn anything from the response.
    if body.website.strip():
        logger.warning("Public registration honeypot triggered for event %s", event_id)
        return {"status": "ok", "message": registration_i18n.message("submitted", locale)}

    system_user_id = _system_actor(supabase, event["project_id"])
    if not system_user_id:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible d'enregistrer l'inscription pour le moment. Réessayez plus tard.",
        )

    try:
        file_id = _get_or_create_form_file(supabase, event_id, system_user_id)
    except Exception as exc:
        logger.error("Failed to get/create public-form file for event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Impossible d'enregistrer l'inscription pour le moment. Réessayez plus tard.",
        ) from exc

    # Throttle by email within this event's form submissions only.
    since = (datetime.now(timezone.utc) - _THROTTLE_WINDOW).isoformat()
    try:
        recent = (
            supabase.table("source_records")
            .select("raw_data")
            .eq("file_id", file_id)
            .gte("created_at", since)
            .execute()
        )
        recent_count = sum(
            1 for r in (recent.data or [])
            if str((r.get("raw_data") or {}).get("email", "")).strip().lower() == body.email
        )
    except Exception as exc:
        logger.warning("Throttle check failed for event %s, allowing submission: %s", event_id, exc)
        recent_count = 0
    if recent_count >= _THROTTLE_MAX_PER_EMAIL:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Trop de tentatives avec cette adresse email. Réessayez plus tard.",
        )

    raw = body.model_dump(
        mode="json",
        exclude={"consent", "website", "custom", "confirmations",
                 "attachments", "companion"},
    )

    # The organizer decides which answers are mandatory, and that decision is
    # enforced here rather than only in the browser: this endpoint is public
    # and takes JSON, so the form's own `required` attributes prove nothing.
    resolved = registration_form.resolve(registration_form.fetch(supabase, event_id), badge=badge)
    custom_fields, confirmations = registration_form.fetch_extras(supabase, event_id)

    wanted_files = (
        registration_uploads.requested(resolved)
        if attachment_custody.available(supabase) else []
    )
    missing = (
        registration_form.missing_required(resolved, raw)
        + registration_form.missing_custom(custom_fields, body.custom)
        + registration_uploads.missing_required(wanted_files, body.attachments)
    )
    if missing:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=registration_i18n.message("missing_fields", locale, fields=", ".join(missing)),
        )

    # Contractual tick-boxes get their own message: "merci de renseigner la
    # politique d'annulation" would be nonsense — nothing was left blank, an
    # agreement was withheld.
    unticked = registration_form.missing_confirmations(confirmations, body.confirmations)
    if unticked:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=registration_i18n.message("missing_confirmations", locale, fields=", ".join(unticked)),
        )

    # The organizer's own answers sit beside the catalogue ones, exactly like
    # an unrecognised column from an uploaded file. They reach the master list
    # and the exports through the same catch-all path, with no extra plumbing.
    answers = registration_form.keep_custom_answers(custom_fields, body.custom)
    raw.update(answers)

    # What was agreed to, and when. An export that shows a cancellation policy
    # was accepted is worth nothing without the date it was accepted on.
    if confirmations:
        raw["confirmations_accepted"] = ", ".join(
            c["label"] for c in confirmations if body.confirmations.get(c["key"]) is True
        )
        raw["confirmations_accepted_at"] = datetime.now(timezone.utc).isoformat()

    # Bind the uploads to this submission. Checked against this event's own
    # unclaimed rows: an id alone must never be enough to attach somebody
    # else's passport to your own registration.
    claimed = _claim_attachments(supabase, event_id, body.attachments)
    for kind, label in claimed.items():
        raw[kind] = label

    normalized = {k: v for k, v in raw.items() if v not in (None, "")}

    try:
        count_resp = (
            supabase.table("source_records")
            .select("id", count="exact")
            .eq("file_id", file_id)
            .execute()
        )
        row_index = count_resp.count or 0
        rows = [{
            "file_id": file_id,
            "event_id": event_id,
            "row_index": row_index,
            "raw_data": raw,
            "normalized_data": normalized,
        }]

        # A second person registered in the same submission (§9) becomes a
        # second row, not a note on the first: a companion is a participant,
        # with their own fiche, their own flight and their own dietary
        # requirement. The consolidation engine then treats them like anybody
        # else.
        companion = _companion_row(body, raw)
        if companion:
            rows.append({
                "file_id": file_id,
                "event_id": event_id,
                "row_index": row_index + 1,
                "raw_data": companion,
                "normalized_data": {
                    k: v for k, v in companion.items() if v not in (None, "")
                },
            })

        supabase.table("source_records").insert(rows).execute()
    except Exception as exc:
        logger.error("Failed to insert public registration for event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Échec de l'enregistrement. Réessayez.",
        ) from exc

    _trigger_background_consolidation(event_id, system_user_id)
    return {"status": "ok", "message": registration_i18n.message("submitted", locale)}


def _claim_attachments(
    supabase: Client, event_id: str, requested: list[dict[str, str]]
) -> dict[str, str]:
    """Bind uploaded files to the submission that references them.

    Two checks, and both matter. The row must belong to THIS event, and it must
    still be unclaimed — otherwise an id, which is the only secret involved,
    would be enough to attach somebody else's passport to your own
    registration, or to re-attach your own to a stranger's.

    Returns ``{kind: filename}`` for what was actually claimed, so the row
    records the document by name rather than by an id nobody can read.
    """
    out: dict[str, str] = {}
    for item in requested or []:
        kind = str((item or {}).get("kind") or "").strip()
        attachment_id = str((item or {}).get("id") or "").strip()
        if kind not in registration_uploads.KINDS or not attachment_id:
            continue
        try:
            found = (
                supabase.table("registration_attachments")
                .select("id, kind, original_name, claimed_at")
                .eq("id", attachment_id)
                .eq("event_id", event_id)
                .eq("kind", kind)
                .is_("claimed_at", "null")
                .execute()
            ).data or []
        except Exception as exc:
            logger.info("Attachments unavailable (migration 021?): %s", exc)
            return out
        if not found:
            logger.warning(
                "Registration referenced an attachment it cannot claim (event %s)", event_id
            )
            continue
        try:
            supabase.table("registration_attachments").update(
                {"claimed_at": datetime.now(timezone.utc).isoformat()}
            ).eq("id", attachment_id).execute()
        except Exception as exc:
            logger.warning("Could not mark attachment %s claimed: %s", attachment_id, exc)
            continue
        out[kind] = found[0].get("original_name") or kind
    return out


# Fields a companion inherits from the main registrant rather than retyping.
# Everything here is a property of the TRIP or of the household, not of the
# person: asking somebody to enter their own company again for their spouse is
# how a form gets abandoned halfway.
_INHERITED = (
    "company", "address", "postal_code", "city", "country",
    "arrival_date", "departure_date", "arrival_flight", "departure_flight",
    "arrival_airport", "transfer_needed", "language",
)


def _companion_row(body: PublicRegistrationSubmit, main: dict[str, Any]) -> dict[str, Any] | None:
    """The second participant's own row, or None when there is no companion."""
    companion = body.companion
    if companion is None:
        return None

    row: dict[str, Any] = {
        k: v for k, v in companion.model_dump(mode="json").items()
        if k != "shares_room" and v not in (None, "")
    }
    if not row.get("first_name") or not row.get("last_name"):
        return None

    for key in _INHERITED:
        if not row.get(key) and main.get(key):
            row[key] = main[key]

    if companion.shares_room:
        # Written both ways so the pairing step (§4) resolves it reciprocally
        # rather than treating one side as a claim about the other.
        row["roommate"] = f"{main.get('first_name', '')} {main.get('last_name', '')}".strip()
        row["room_type"] = main.get("room_type") or "twin"
        main["roommate"] = f"{row['first_name']} {row['last_name']}".strip()
        # Assigned when falsy, not merely when absent: the key is always
        # present here (the model declares it) and holds None. setdefault would
        # leave the main registrant with no room type while their companion
        # says twin — and the pairing step, which reads room_type on BOTH
        # sides, would then refuse to link a pair we already know about.
        if not main.get("room_type"):
            main["room_type"] = row["room_type"]

    # Recorded so an organizer reading the master list knows this fiche arrived
    # attached to somebody else's registration rather than on its own.
    row["registered_with"] = f"{main.get('first_name', '')} {main.get('last_name', '')}".strip()
    return row
