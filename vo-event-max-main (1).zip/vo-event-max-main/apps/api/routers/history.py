"""
routers/history.py — The change log, made readable (feedback §19).

Every field-level change has been recorded since the beginning; none of it was
ever readable. This exposes it as the seven columns the feedback asks for —
user, date, time, field, old value, new value, source — with the filters
somebody actually reaches for when a client asks "why does it say Vegetarian
now?".

Two deliberate refusals:

  * **Sensitive values are not reprinted.** The log holds passport numbers in
    plain text because that is what changed; a screen that reprints them turns
    an audit trail into a second copy of the data (§23). The change is shown,
    the content is masked.
  * **An inferred origin is labelled as inferred.** Rows written before
    migration 015 have no source column, and history_service reconstructs one
    from the reason code. Somebody arguing about who changed a passport number
    needs to know which lines are evidence and which are reconstruction.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from fastapi import APIRouter, Depends, Query
from supabase import Client

from dependencies import get_current_user, get_supabase_client, verify_event_access
from services import history_service

logger = logging.getLogger(__name__)

router = APIRouter()

# A history screen is paged, not streamed: nobody reads 40 000 lines, and
# fetching them to render twenty is how a page takes nine seconds to open.
MAX_PAGE = 500


@router.get(
    "/events/{event_id}/history",
    summary="The change log, in the seven columns of feedback §19",
)
async def event_history(
    event_id: str,
    participant_id: Optional[str] = Query(None),
    field: Optional[str] = Query(None),
    source: Optional[str] = Query(None),
    since: Optional[str] = Query(None, description="ISO date; changes at or after it"),
    limit: int = Query(100, ge=1, le=MAX_PAGE),
    offset: int = Query(0, ge=0),
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """Who changed what, when, and where the new value came from."""
    await verify_event_access(event_id, current_user, supabase)

    query = (
        supabase.table("change_log")
        .select("*")
        .eq("event_id", event_id)
        .order("changed_at", desc=True)
    )
    if participant_id:
        query = query.eq("entity_id", participant_id)
    if field:
        query = query.eq("field_name", field)
    if since:
        query = query.gte("changed_at", since)

    try:
        rows = (query.range(offset, offset + limit - 1).execute()).data or []
    except Exception as exc:
        logger.warning("History unavailable for event %s: %s", event_id, exc)
        return {
            "lines": [], "summary": {}, "sources": history_service.describe_sources(),
            "available": False, "has_more": False,
        }

    # Filtering on the origin happens here rather than in the query: half the
    # rows have no stored source and their origin is inferred, so a WHERE clause
    # would silently hide exactly the rows this feature exists to explain.
    lines = history_service.readable(
        rows,
        users=_names(supabase, "users", {r.get("user_id") for r in rows}),
        participants=_participant_names(supabase, event_id, rows),
    )
    if source:
        lines = [line for line in lines if line["source"] == source]

    return {
        "lines": lines,
        "summary": history_service.summarise(lines),
        "sources": history_service.describe_sources(),
        "available": True,
        "has_more": len(rows) == limit,
        "offset": offset,
    }


def _names(supabase: Client, table: str, ids: set[Any]) -> dict[str, str]:
    """id -> display name, best effort. A history that cannot name a user still
    renders — with the id, which is worse but not wrong."""
    wanted = [i for i in ids if i]
    if not wanted:
        return {}
    try:
        res = supabase.table(table).select("id, full_name, email").in_("id", wanted).execute()
    except Exception as exc:
        logger.info("History: could not resolve %s names: %s", table, exc)
        return {}
    return {
        row["id"]: (row.get("full_name") or row.get("email") or row["id"])
        for row in (res.data or [])
    }


def _participant_names(
    supabase: Client, event_id: str, rows: list[dict[str, Any]]
) -> dict[str, str]:
    ids = {r.get("entity_id") for r in rows if r.get("entity_type") == "participant"}
    wanted = [i for i in ids if i]
    if not wanted:
        return {}
    try:
        res = (
            supabase.table("participants")
            .select("id, first_name, last_name")
            .eq("event_id", event_id)
            .in_("id", wanted)
            .execute()
        )
    except Exception as exc:
        logger.info("History: could not resolve participant names: %s", exc)
        return {}
    return {
        row["id"]: " ".join(
            p for p in (row.get("first_name"), row.get("last_name")) if p
        ).strip() or row["id"]
        for row in (res.data or [])
    }
