"""
routers/participants.py — Participant management endpoints.

Routes:
  GET   /api/events/{event_id}/participants          Paginated + filtered participant list
  GET   /api/participants/{participant_id}            Full participant detail
  PATCH /api/participants/{participant_id}            Update a single field (with change_log)
  POST  /api/participants/{participant_id}/lock/{field}    Lock a field
  POST  /api/participants/{participant_id}/unlock/{field}  Unlock a field
"""

from __future__ import annotations

import logging
import math
from datetime import date
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from supabase import Client

from dependencies import get_current_user, get_supabase_client, verify_event_access
from models.schemas import (
    MessageResponse,
    ParticipantListItem,
    ParticipantListResponse,
    ParticipantResponse,
    ParticipantUpdate,
    ParticipantLookupItem,
)
from services.audit_service import log_change
from services import master_list_service, parallel, travel_checks

logger = logging.getLogger(__name__)

router = APIRouter()


# What only admin/pm may read, named once so a field added to the master list
# cannot quietly join the response for everybody.
#
# Two families, and both are gated for the same reason rather than by analogy:
#
#   * health — dietary requirements, allergies, and `medical_info`, which
#     holds what a client tells us so the on-site team can prepare
#     ("Epilepsy, DTD or OSA?");
#   * identity documents — the passport number, its expiry and the date of
#     birth. These were NOT gated until 2026-08-25: the master list stripped
#     the food fields and handed every viewer account a passport number in the
#     same response. Nothing on screen showed it, which is exactly why it went
#     unnoticed — the leak was in the payload, not in the table.
#
# Stripped in the router rather than in `build_master_rows`, because the
# quality score counts missing passports and must keep reading them.
STAFF_ONLY_FIELDS: tuple[str, ...] = (
    "dietary_requirements",
    "food_allergy_info",
    "medical_info",
    "passport_number",
    "passport_expiry",
    "date_of_birth",
)


@router.get(
    "/events/{event_id}/master-list",
    summary="Enriched master list: participants merged with rich source fields",
)
async def get_master_list(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """
    One consolidated row per participant, merging the participant record with the
    rich master-file fields imported from the source files (attendee category,
    job title, region, country, passport, food/allergy …) — feedback §6.
    """
    await verify_event_access(event_id, current_user, supabase)
    role: str = current_user.get("role", "viewer")
    rows = master_list_service.build_master_rows(supabase, event_id)
    if role not in ("admin", "pm"):
        for r in rows:
            for field in STAFF_ONLY_FIELDS:
                r.pop(field, None)
    # Union of user-defined custom mapping field names, so the client can render
    # one extra column per custom field.
    custom_fields = sorted({k for r in rows for k in (r.get("custom") or {}).keys()})
    return {"items": rows, "total": len(rows), "custom_fields": custom_fields}

# Fields that are always selected for the detail view
PARTICIPANT_FULL_SELECT = (
    "id, event_id, first_name, last_name, email, company, phone, nationality, "
    "dietary_requirements, completeness_status, has_flight, has_hotel, has_transfer, "
    "has_activities, verification_note, locked_fields, registration_source_id, "
    "fcm_source_id, created_at, updated_at"
)

# Fields returned in list view (no dietary_requirements)
PARTICIPANT_LIST_SELECT = (
    "id, event_id, first_name, last_name, email, company, phone, "
    "completeness_status, has_flight, has_hotel, has_transfer, has_activities"
)

# Fields that may NOT be updated via the API (system-managed)
# The single-field PATCH/lock endpoints below used to take an
# IMMUTABLE_FIELDS BLOCKLIST (id/event_id/created_at/updated_at/
# registration_source_id/fcm_source_id) — every OTHER column not on that
# short list (completeness_status,
# locked_fields, has_flight/has_hotel/has_transfer/has_activities,
# verification_note...) was writable by any user with write access to the
# event, including a client-role "editor". Those are engine-managed fields
# (set by consolidation/matching, not meant to be user-editable) — a client
# could e.g. set locked_fields to freeze dietary_requirements against future
# re-imports, or fake has_flight/has_hotel for reporting. Restricted to
# exactly the fields the participant edit form actually exposes
# (apps/web/.../participants/[participantId]/page.tsx's EDITABLE_FIELDS).
# locked_fields has its own dedicated POST /participants/{id}/lock endpoint
# and is deliberately NOT here.
CLIENT_EDITABLE_FIELDS = {
    "first_name", "last_name", "email", "company", "phone",
    "nationality", "dietary_requirements",
}


def _participant_sources(participant_id: str, supabase: Client) -> list[str]:
    """
    The kinds of file this fiche was actually built from, read from the records
    LINKED to it.

    ``registration_source_id`` / ``fcm_source_id`` are only ever set by the two
    steps that create a fiche from a registration row or match it to an FCM
    one. A fiche created by the orphan-record linking step (a traveller present
    only in a flight export, say) has both NULL — so its detail page claimed
    "Aucune source associée" while listing that person's two source rows a few
    centimetres below. Reading the link table itself cannot disagree with what
    the page shows.
    """
    try:
        recs = (
            supabase.table("source_records")
            .select("file_id")
            .eq("participant_id", participant_id)
            .limit(500)
            .execute()
        ).data or []
        file_ids = sorted({r["file_id"] for r in recs if r.get("file_id")})
        if not file_ids:
            return []
        files = (
            supabase.table("uploaded_files")
            .select("source_type")
            .in_("id", file_ids)
            .execute()
        ).data or []
        return sorted({f["source_type"] for f in files if f.get("source_type")})
    except Exception as exc:
        logger.warning("Could not resolve sources for participant %s: %s", participant_id, exc)
        return []


def _extension_fields(participant_id: str, supabase: Client) -> dict[str, Any]:
    """The migration-022 columns, or {} on a deployment that hasn't run it.

    Kept OUT of PARTICIPANT_FULL_SELECT deliberately: PostgREST fails the
    WHOLE select when one column is absent, and the participant detail
    endpoint must keep working regardless of whether §3's extension columns
    exist yet.
    """
    try:
        res = (
            supabase.table("participants")
            .select("extension_requested, extension_start, extension_end, extension_hotel")
            .eq("id", participant_id)
            .maybe_single()
            .execute()
        )
        return (res.data if res else None) or {}
    except Exception as exc:
        logger.info("Extension fields unavailable for %s (migration 022?): %s", participant_id, exc)
        return {}


def _strip_dietary(participant: dict, role: str) -> dict:
    """
    Remove dietary_requirements from the participant dict for non-admin/pm roles.

    This is an application-layer enforcement layered on top of the RLS policy.
    """
    if role not in ("admin", "pm"):
        participant = participant.copy()
        participant.pop("dietary_requirements", None)
    return participant


# ---------------------------------------------------------------------------
# GET /api/events/{event_id}/participants
# ---------------------------------------------------------------------------

@router.get(
    "/events/{event_id}/participants",
    response_model=ParticipantListResponse,
    summary="List participants for an event (paginated + filtered)",
)
async def list_participants(
    event_id: str,
    page: int = Query(1, ge=1, description="Page number (1-indexed)."),
    page_size: int = Query(50, ge=1, le=200, description="Results per page (max 200)."),
    status_filter: Optional[str] = Query(None, alias="status", description="Filter by completeness_status: complete | incomplete | conflict"),
    has_flight: Optional[bool] = Query(None, description="Filter by flight status."),
    has_hotel: Optional[bool] = Query(None, description="Filter by hotel status."),
    has_transfer: Optional[bool] = Query(None, description="Filter by transfer status."),
    search: Optional[str] = Query(None, description="Substring search on first_name, last_name, email, company, phone."),
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> ParticipantListResponse:
    """
    Return a paginated, filterable list of participants for an event.

    Filters:
    - ``status``: completeness_status value
    - ``has_flight``, ``has_hotel``: boolean flags
    - ``search``: case-insensitive substring match on name / email (ilike)

    Note: dietary_requirements is NOT returned in the list view for any role.
    Use the detail endpoint to retrieve it (admin/pm only).
    """
    await verify_event_access(event_id, current_user, supabase)

    offset = (page - 1) * page_size

    # Build query
    q = (
        supabase.table("participants")
        .select(PARTICIPANT_LIST_SELECT, count="exact")
        .eq("event_id", event_id)
    )

    if status_filter:
        q = q.eq("completeness_status", status_filter)
    if has_flight is not None:
        q = q.eq("has_flight", has_flight)
    if has_hotel is not None:
        q = q.eq("has_hotel", has_hotel)
    if has_transfer is not None:
        q = q.eq("has_transfer", has_transfer)
    if search:
        # Multi-column case-insensitive search: name, email, company and phone
        # (feedback §9 — search must not be limited to the email address).
        pattern = f"%{search}%"
        q = q.or_(
            f"first_name.ilike.{pattern},last_name.ilike.{pattern},"
            f"email.ilike.{pattern},company.ilike.{pattern},phone.ilike.{pattern}"
        )

    q = q.order("last_name").order("first_name").range(offset, offset + page_size - 1)

    try:
        result = q.execute()
    except Exception as exc:
        logger.error("Failed to list participants for event %s: %s", event_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve participant list.",
        ) from exc

    total = result.count or 0
    total_pages = max(1, math.ceil(total / page_size))

    items = [ParticipantListItem(**row) for row in (result.data or [])]

    return ParticipantListResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
    )


@router.get(
    "/events/{event_id}/participants/coverage",
    summary="Identity + coverage flags for every participant (one table read)",
)
async def list_coverage(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """
    Who is missing a flight / hotel / transfer / activity, and nothing else.

    The Flights, Hébergements and Exceptions pages used to answer that by
    loading the full master list — which merges ten tables, including every
    ``source_records.normalized_data`` blob, plus flights, hotel nights,
    transfers, activities, exceptions and communications — and then throwing
    all of it away to filter one boolean. This reads a single table, returns
    the eight columns those pages actually display, and leaves the master list
    to the page that genuinely needs it.

    Coverage of the programme's DATES is here too, for the same reason: who is
    outside them is derived from their own flights, and the three pages that
    ask "who is missing something" are the three that need to know who is
    paying for their own nights. Reading it from the master list instead would
    put ten tables behind a page that wanted four booleans and a number.

    Same shape as the master-list rows those pages consumed, so nothing
    downstream had to change.
    """
    await verify_event_access(event_id, current_user, supabase)

    def _people() -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        offset = 0
        while True:
            res = (
                supabase.table("participants")
                .select(
                    "id, first_name, last_name, email, company, completeness_status, "
                    "has_flight, has_hotel, has_transfer, has_activities"
                )
                .eq("event_id", event_id)
                .order("last_name")
                .order("first_name")
                .range(offset, offset + 999)      # PostgREST caps a select at 1000
                .execute()
            )
            rows = res.data or []
            out.extend(rows)
            if len(rows) < 1000:
                break
            offset += 1000
        return out

    def _flights() -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        offset = 0
        while True:
            res = (
                supabase.table("flights")
                .select("participant_id, departure_time, status")
                .eq("event_id", event_id)
                .range(offset, offset + 999)
                .execute()
            )
            rows = res.data or []
            out.extend(rows)
            if len(rows) < 1000:
                break
            offset += 1000
        return out

    def _event() -> list[dict[str, Any]]:
        return (
            supabase.table("events").select("start_date, end_date")
            .eq("id", event_id).limit(1).execute()
        ).data or []

    read = parallel.gather(
        {"people": _people, "flights": _flights, "event": _event},
        label=f"coverage {event_id}", default=[],
    )

    items = read["people"] or []
    event_row = (read["event"] or [{}])[0]
    outside: dict[str, dict[str, Any]] = {
        stay["participant_id"]: stay
        for stay in travel_checks.staying_at_own_expense(
            read["flights"] or [],
            _as_day(event_row.get("start_date")),
            _as_day(event_row.get("end_date")),
        )
    }
    for row in items:
        stay = outside.get(row.get("id"))
        row["own_expense"] = bool(stay)
        row["nights_outside_programme"] = stay["extra_nights"] if stay else 0
        row["arrives_early_days"] = stay["arrives_early_days"] if stay else 0
        row["stays_late_days"] = stay["stays_late_days"] if stay else 0

    return {"items": items, "total": len(items)}


def _as_day(value: Any) -> Optional[date]:
    """A stored date string as a date, or None if it is not one."""
    if not value:
        return None
    try:
        return date.fromisoformat(str(value)[:10])
    except (TypeError, ValueError):
        return None


@router.get(
    "/events/{event_id}/participants/lookup",
    response_model=list[ParticipantLookupItem],
    summary="Get minimal participant info for select dropdowns (non-paginated)",
)
async def lookup_participants(
    event_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> list[ParticipantLookupItem]:
    """
    Get a minimal lookup list of participants for dropdowns.
    Always verifies event access first.
    """
    await verify_event_access(event_id, current_user, supabase)

    all_items = []
    page_size = 1000
    offset = 0

    while True:
        try:
            res = (
                supabase.table("participants")
                .select("id, first_name, last_name, completeness_status")
                .eq("event_id", event_id)
                .order("last_name")
                .order("first_name")
                .range(offset, offset + page_size - 1)
                .execute()
            )
            data = res.data or []
            all_items.extend(data)
            if len(data) < page_size:
                break
            offset += page_size
        except Exception as exc:
            logger.error("Failed to lookup participants: %s", exc)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve participant list.",
            ) from exc

    return [ParticipantLookupItem(**row) for row in all_items]


# ---------------------------------------------------------------------------
# GET /api/participants/{participant_id}
# ---------------------------------------------------------------------------

@router.get(
    "/participants/{participant_id}",
    response_model=ParticipantResponse,
    summary="Get full participant detail",
)
async def get_participant(
    participant_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> ParticipantResponse:
    """
    Retrieve the full record for a single participant.

    dietary_requirements is only populated for ``admin`` and ``pm`` roles.
    For ``client`` and ``viewer`` roles, the field will be ``null`` in the response.
    """
    try:
        result = (
            supabase.table("participants")
            .select(PARTICIPANT_FULL_SELECT)
            .eq("id", participant_id)
            .single()
            .execute()
        )
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Participant not found.") from exc

    if not result.data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Participant not found.")

    participant = result.data

    # Verify event access (org isolation)
    await verify_event_access(participant["event_id"], current_user, supabase)

    # RGPD: strip dietary data for non-admin/pm
    role: str = current_user.get("role", "viewer")
    participant = _strip_dietary(participant, role)
    participant["sources"] = _participant_sources(participant_id, supabase)

    participant.update(_extension_fields(participant_id, supabase))

    return ParticipantResponse(**participant)


# ---------------------------------------------------------------------------
# GET /api/participants/{participant_id}/consolidated
# ---------------------------------------------------------------------------

@router.get(
    "/participants/{participant_id}/consolidated",
    summary="Full consolidated master-list view for one participant",
)
async def get_participant_consolidated(
    participant_id: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> dict[str, Any]:
    """
    Return everything merged for a participant: their flights, transfers, hotel
    nights, activities, and the raw source rows they were consolidated from.

    This is the "operational master list" for a single attendee (feedback §6).
    Raw source rows (which can contain dietary/allergy data) are only included
    for admin/pm roles (RGPD).
    """
    part = (
        supabase.table("participants")
        .select("id, event_id")
        .eq("id", participant_id)
        .single()
        .execute()
    )
    if not part.data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Participant not found.")
    await verify_event_access(part.data["event_id"], current_user, supabase)

    role: str = current_user.get("role", "viewer")
    pid = participant_id

    def _safe(fn) -> list[dict[str, Any]]:
        try:
            return fn().data or []
        except Exception as exc:  # a missing table/column shouldn't 500 the whole view
            logger.warning("Consolidated view sub-query failed for %s: %s", pid, exc)
            return []

    flights = _safe(lambda: supabase.table("flights").select("*").eq("participant_id", pid).execute())
    transfers = _safe(lambda: supabase.table("transfers").select("*").eq("participant_id", pid).execute())
    hotel_nights = _safe(
        lambda: supabase.table("hotel_nights").select("*, hotels(name, city)").eq("participant_id", pid).execute()
    )
    activities = _safe(
        lambda: supabase.table("participant_activities").select("*, activities(name)").eq("participant_id", pid).execute()
    )

    source_records: list[dict[str, Any]] = []
    if role in ("admin", "pm"):
        source_records = _safe(
            lambda: supabase.table("source_records")
            .select("id, file_id, normalized_data, raw_data, uploaded_files(source_type, original_filename)")
            .eq("participant_id", pid)
            .execute()
        )

    return {
        "flights": flights,
        "transfers": transfers,
        "hotel_nights": hotel_nights,
        "activities": activities,
        "source_records": source_records,
    }


# ---------------------------------------------------------------------------
# PATCH /api/participants/{participant_id}
# ---------------------------------------------------------------------------

@router.patch(
    "/participants/{participant_id}",
    response_model=ParticipantResponse,
    summary="Update a single participant field",
)
async def update_participant(
    participant_id: str,
    body: ParticipantUpdate,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> ParticipantResponse:
    """
    Update a single field on a participant record.

    Rules:
    - ``dietary_requirements`` can only be updated by ``admin`` / ``pm``
    - System fields (``id``, ``event_id``, ``created_at``, etc.) cannot be updated
    - The change is written to ``change_log`` BEFORE the update is applied
    - If ``lock=true``, the field is added to ``locked_fields``
    """
    user_role: str = current_user.get("role", "viewer")

    # Guard: dietary_requirements is RGPD-sensitive
    if body.field == "dietary_requirements" and user_role not in ("admin", "pm"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only admin and pm roles may update dietary_requirements.",
        )

    # Guard: only the fields the participant edit form actually exposes may be
    # set through this endpoint — everything else (completeness_status,
    # locked_fields, has_flight/has_hotel/has_transfer/has_activities,
    # verification_note...) is engine-managed, set by consolidation/matching,
    # not user-editable.
    if body.field not in CLIENT_EDITABLE_FIELDS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Field '{body.field}' cannot be modified via the API.",
        )

    # Load existing participant
    try:
        existing_resp = (
            supabase.table("participants")
            .select(PARTICIPANT_FULL_SELECT)
            .eq("id", participant_id)
            .single()
            .execute()
        )
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Participant not found.") from exc

    if not existing_resp.data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Participant not found.")

    existing = existing_resp.data
    await verify_event_access(existing["event_id"], current_user, supabase, write=True)

    old_value = existing.get(body.field)

    # Write to change_log BEFORE making the update
    log_change(
        supabase=supabase,
        event_id=existing["event_id"],
        user_id=current_user["id"],
        entity_type="participant",
        entity_id=participant_id,
        field_name=body.field,
        old_value=str(old_value) if old_value is not None else None,
        new_value=str(body.value) if body.value is not None else None,
        reason=body.reason,
        source="manual_update",
    )

    # Build update payload
    updates: dict[str, Any] = {body.field: body.value}

    if body.lock:
        locked_fields: dict = existing.get("locked_fields") or {}
        locked_fields[body.field] = True
        updates["locked_fields"] = locked_fields

    # Apply update
    try:
        result = (
            supabase.table("participants")
            .update(updates)
            .eq("id", participant_id)
            .execute()
        )
    except Exception as exc:
        logger.error("Failed to update participant %s: %s", participant_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update participant.",
        ) from exc

    updated = result.data[0]
    updated = _strip_dietary(updated, user_role)
    return ParticipantResponse(**updated)


# ---------------------------------------------------------------------------
# POST /api/participants/{participant_id}/lock/{field}
# ---------------------------------------------------------------------------

@router.post(
    "/participants/{participant_id}/lock/{field}",
    response_model=MessageResponse,
    summary="Lock a participant field against re-import overwrites",
)
async def lock_field(
    participant_id: str,
    field: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> MessageResponse:
    """
    Add ``field`` to the participant's ``locked_fields``.

    Locked fields retain their manually-set values when the consolidation
    engine re-runs — new imports cannot overwrite them.
    """
    if field not in CLIENT_EDITABLE_FIELDS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Field '{field}' is a system field and cannot be locked.",
        )

    existing_resp = (
        supabase.table("participants")
        .select("id, event_id, locked_fields")
        .eq("id", participant_id)
        .single()
        .execute()
    )
    if not existing_resp.data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Participant not found.")

    existing = existing_resp.data
    await verify_event_access(existing["event_id"], current_user, supabase, write=True)

    locked_fields: dict = existing.get("locked_fields") or {}
    locked_fields[field] = True

    log_change(
        supabase=supabase,
        event_id=existing["event_id"],
        user_id=current_user["id"],
        entity_type="participant",
        entity_id=participant_id,
        field_name=f"locked_fields.{field}",
        old_value="false",
        new_value="true",
        reason="lock",
        source="manual_update",
    )

    supabase.table("participants").update({"locked_fields": locked_fields}).eq("id", participant_id).execute()

    return MessageResponse(message=f"Field '{field}' is now locked for participant {participant_id}.")


# ---------------------------------------------------------------------------
# POST /api/participants/{participant_id}/unlock/{field}
# ---------------------------------------------------------------------------

@router.post(
    "/participants/{participant_id}/unlock/{field}",
    response_model=MessageResponse,
    summary="Unlock a participant field to allow re-import overwrites",
)
async def unlock_field(
    participant_id: str,
    field: str,
    current_user: dict[str, Any] = Depends(get_current_user),
    supabase: Client = Depends(get_supabase_client),
) -> MessageResponse:
    """
    Remove ``field`` from the participant's ``locked_fields``.

    After unlocking, re-imports can overwrite the field value.
    """
    existing_resp = (
        supabase.table("participants")
        .select("id, event_id, locked_fields")
        .eq("id", participant_id)
        .single()
        .execute()
    )
    if not existing_resp.data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Participant not found.")

    existing = existing_resp.data
    await verify_event_access(existing["event_id"], current_user, supabase, write=True)

    locked_fields: dict = existing.get("locked_fields") or {}
    was_locked = locked_fields.pop(field, False)

    if not was_locked:
        return MessageResponse(message=f"Field '{field}' was not locked.")

    log_change(
        supabase=supabase,
        event_id=existing["event_id"],
        user_id=current_user["id"],
        entity_type="participant",
        entity_id=participant_id,
        field_name=f"locked_fields.{field}",
        old_value="true",
        new_value="false",
        reason="unlock",
        source="manual_update",
    )

    supabase.table("participants").update({"locked_fields": locked_fields}).eq("id", participant_id).execute()

    return MessageResponse(message=f"Field '{field}' is now unlocked for participant {participant_id}.")
