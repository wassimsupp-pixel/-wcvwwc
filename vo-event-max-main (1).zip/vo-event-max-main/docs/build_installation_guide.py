# -*- coding: utf-8 -*-
"""The installation guide, generated from what the code actually reads.

Every variable in this document was pulled out of the source with a grep, not
remembered: `os.getenv` for the API, `process.env` for the web app, the
migrations directory for the SQL. That is the point -- a handover document
drifts from the code the day it is written by hand.

NO SECRET VALUE APPEARS HERE. Names, purposes and where to obtain each one.
The client generates their own keys on their own accounts; a runbook carrying
live credentials is a runbook that leaks them.
"""
import glob
import io
import os
import textwrap
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    KeepTogether, PageBreak, Paragraph, Preformatted, SimpleDocTemplate, Spacer, Table, TableStyle,
)

HERE = os.path.dirname(os.path.abspath(__file__))

OUT = ("C:/Users/wassi/Desktop/antigravity/scratch/vo-event-max/docs/"
       "Installation-VO-Event-Max.pdf")

INK = colors.HexColor("#0f172a")
MUTED = colors.HexColor("#5b6b82")
ACCENT = colors.HexColor("#1b4f72")
RULE = colors.HexColor("#d6dde8")
BAND = colors.HexColor("#eef2f7")

styles = getSampleStyleSheet()
S = {
    "title": ParagraphStyle("t", parent=styles["Title"], fontName="Helvetica-Bold",
                            fontSize=22, leading=26, textColor=ACCENT, alignment=TA_LEFT,
                            spaceAfter=2),
    "sub": ParagraphStyle("s", parent=styles["Normal"], fontName="Helvetica",
                          fontSize=10.5, leading=15, textColor=MUTED, spaceAfter=14),
    "h1": ParagraphStyle("h1", parent=styles["Heading1"], fontName="Helvetica-Bold",
                         fontSize=14.5, leading=18, textColor=ACCENT,
                         spaceBefore=16, spaceAfter=7),
    "h2": ParagraphStyle("h2", parent=styles["Heading2"], fontName="Helvetica-Bold",
                         fontSize=11.5, leading=15, textColor=INK,
                         spaceBefore=11, spaceAfter=5),
    "p": ParagraphStyle("p", parent=styles["Normal"], fontName="Helvetica",
                        fontSize=9.5, leading=14, textColor=INK, spaceAfter=6),
    "note": ParagraphStyle("n", parent=styles["Normal"], fontName="Helvetica-Oblique",
                           fontSize=9, leading=13, textColor=MUTED, spaceAfter=6),
    "cell": ParagraphStyle("c", parent=styles["Normal"], fontName="Helvetica",
                           fontSize=8.2, leading=11, textColor=INK),
    "cellb": ParagraphStyle("cb", parent=styles["Normal"], fontName="Helvetica-Bold",
                            fontSize=8.2, leading=11, textColor=INK),
    "mono": ParagraphStyle("m", parent=styles["Normal"], fontName="Courier",
                           fontSize=8.2, leading=11, textColor=INK),
    "monoh": ParagraphStyle("mh", parent=styles["Normal"], fontName="Courier-Bold",
                            fontSize=8.2, leading=11, textColor=colors.white),
    # A filename heading above each copy-paste block.
    "codeh": ParagraphStyle("ch", parent=styles["Normal"], fontName="Helvetica-Bold",
                            fontSize=9.5, leading=12, textColor=ACCENT,
                            spaceBefore=10, spaceAfter=3, keepWithNext=1),
    # The copy-paste SQL itself. Small mono so wrapped lines stay rare.
    "code": ParagraphStyle("cd", parent=styles["Normal"], fontName="Courier",
                           fontSize=6.8, leading=8.4, textColor=INK,
                           backColor=colors.HexColor("#f7f9fc"),
                           borderColor=RULE, borderWidth=0.4, borderPadding=5,
                           spaceAfter=8),
}


def wrap_sql(text, width=104):
    """Fold long lines so a copy-paste block fits the page.

    PostgreSQL treats any run of whitespace as one separator, so breaking a
    long line at a space and letting the reader's paste re-join it changes
    nothing about the SQL. Continuations keep the original line's indent.
    """
    out = []
    for raw in text.replace("\t", "    ").rstrip("\n").split("\n"):
        line = raw.rstrip()
        if not line.strip():
            out.append("")
            continue
        indent = line[: len(line) - len(line.lstrip())]
        if len(line) <= width:
            out.append(line)
            continue
        pieces = textwrap.wrap(
            line.strip(), width=width, initial_indent=indent, subsequent_indent=indent,
            break_long_words=True, break_on_hyphens=False, replace_whitespace=False,
        )
        out.extend(pieces or [line])
    return "\n".join(out)


def code_block(path):
    """A file's exact contents as one copy-paste block.

    Preformatted takes the text literally — it does not parse paragraph markup —
    so the SQL is passed raw: `<`, `<=`, `<>` and `&` reach the page as
    themselves, and a copy-paste out of the PDF yields runnable SQL. (Escaping
    here would print the entities verbatim, since nothing un-escapes them.)
    """
    with open(path, encoding="utf-8") as fh:
        raw = fh.read()
    return Preformatted(wrap_sql(raw), S["code"])


def para(text, style="p"):
    return Paragraph(text, S[style])


def table(rows, widths, header=True):
    data = []
    for i, row in enumerate(rows):
        if header and i == 0:
            data.append([Paragraph("<b>%s</b>" % c, S["cell"]) for c in row])
        else:
            data.append([
                Paragraph(c, S["mono"] if j == 0 and "_" in c else S["cell"])
                for j, c in enumerate(row)
            ])
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    style = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.4, RULE),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]
    if header:
        style += [("BACKGROUND", (0, 0), (-1, 0), BAND)]
    t.setStyle(TableStyle(style))
    return t


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(MUTED)
    canvas.drawString(20 * mm, 12 * mm,
                      "VO Event Max \u2014 Guide d'installation \u2014 aucune cl\u00e9 secr\u00e8te dans ce document")
    canvas.drawRightString(190 * mm, 12 * mm, "page %d" % doc.page)
    canvas.setStrokeColor(RULE)
    canvas.line(20 * mm, 16 * mm, 190 * mm, 16 * mm)
    canvas.restoreState()


story = []
A = story.append

# ===========================================================================
A(para("VO Event Max", "title"))
A(para("Installation sur vos propres serveurs \u2014 Supabase, Railway, Vercel.<br/>"
       "Document g\u00e9n\u00e9r\u00e9 le 6 septembre 2026 \u00e0 partir du code source.", "sub"))

A(para("Ce que vous allez installer", "h1"))
A(para(
    "L'application se compose de <b>trois services ind\u00e9pendants</b>. Chacun se cr\u00e9e sur "
    "votre propre compte, avec vos propres cl\u00e9s. Aucune valeur secr\u00e8te ne figure dans ce "
    "document : vous g\u00e9n\u00e9rez les v\u00f4tres, et elles ne quittent jamais vos comptes."))
A(Spacer(1, 4))
A(table([
    ["Service", "R\u00f4le", "Ce qu'il h\u00e9berge"],
    ["Supabase", "Base de donn\u00e9es et fichiers",
     "PostgreSQL, l'authentification des comptes, et deux espaces de stockage "
     "(fichiers import\u00e9s, images publiques)."],
    ["Railway", "API",
     "Le service Python (FastAPI) : consolidation, d\u00e9tection d'anomalies, exports, "
     "assistant IA."],
    ["Vercel", "Application web",
     "L'interface Next.js : \u00e9crans organisateur et formulaire d'inscription public."],
], [26 * mm, 38 * mm, 106 * mm]))
A(Spacer(1, 6))
A(para(
    "<b>Ordre obligatoire :</b> Supabase d'abord (les deux autres ont besoin de ses cl\u00e9s), "
    "puis Railway, puis Vercel (qui a besoin de l'adresse de l'API).", "note"))

# ===========================================================================
A(para("\u00c9tape 1 \u2014 Supabase", "h1"))

A(para("1.1 Cr\u00e9er le projet", "h2"))
A(para(
    "Cr\u00e9ez un projet sur <b>supabase.com</b>. Choisissez la r\u00e9gion "
    "<b>Europe (Paris, eu-west-3)</b> \u2014 c'est la r\u00e9gion pour laquelle le sch\u00e9ma a \u00e9t\u00e9 "
    "\u00e9crit, et elle garde les donn\u00e9es des participants dans l'Union europ\u00e9enne, ce que "
    "votre d\u00e9l\u00e9gu\u00e9 \u00e0 la protection des donn\u00e9es vous demandera."))
A(para(
    "Notez d\u00e8s la cr\u00e9ation, depuis <i>Project Settings \u2192 API</i> : l'<b>URL du projet</b>, "
    "la cl\u00e9 <b>anon / publishable</b> (elle ira dans Vercel, elle est publique par nature) "
    "et la cl\u00e9 <b>service_role</b> (elle ira dans Railway). "
    "<b>La cl\u00e9 service_role contourne toutes les r\u00e8gles de s\u00e9curit\u00e9 de la base : elle ne "
    "doit jamais \u00eatre plac\u00e9e c\u00f4t\u00e9 navigateur, ni dans Vercel.</b>"))

A(para("1.2 Cr\u00e9er le sch\u00e9ma", "h2"))
A(para(
    "Dans <i>SQL Editor</i>, ex\u00e9cutez ces quatre fichiers <b>dans cet ordre</b>. Ils se "
    "trouvent dans le d\u00e9p\u00f4t, dossier <font face='Courier'>docs/</font>."))
A(Spacer(1, 3))
A(table([
    ["Fichier", "Contenu"],
    ["schema.sql", "17 tables de base, s\u00e9curit\u00e9 au niveau des lignes (RLS) activ\u00e9e, "
                   "et la restriction sur le r\u00e9gime alimentaire (donn\u00e9e sensible)."],
    ["schema_phase2.sql", "6 tables : vols, h\u00f4tels, nuits, transferts, activit\u00e9s."],
    ["schema_email_agent.sql", "1 table : l'agent de messagerie."],
    ["supabase_trigger.sql", "Le d\u00e9clencheur qui cr\u00e9e une ligne utilisateur \u00e0 chaque "
                             "inscription de compte."],
], [42 * mm, 128 * mm]))

A(PageBreak())

A(para("1.3 Appliquer les migrations", "h2"))
A(para(
    "Toujours dans <i>SQL Editor</i>, ex\u00e9cutez les 30 migrations <b>dans l'ordre "
    "num\u00e9rique</b>. Elles sont toutes idempotentes : les relancer ne casse rien. "
    "Les num\u00e9ros 001 et 025 n'existent pas, ce n'est pas un oubli. "
    "Le contenu complet de chaque migration figure en <b>annexe</b>, pr\u00eat \u00e0 copier-coller."))
A(Spacer(1, 3))

MIGRATIONS = [
    ("002", "Communications"), ("003", "Partage de projets"),
    ("004", "File d'arbitrage IA des rapprochements"), ("005", "RLS des membres de projet"),
    ("006", "Formulaire d'inscription public"), ("007", "Champs du formulaire"),
    ("008", "Politique de champs par \u00e9v\u00e9nement"), ("009", "Colocataires et origine des nuits"),
    ("010", "Questions propres \u00e0 l'\u00e9v\u00e9nement"), ("011", "Flotte de transferts et marge"),
    ("012", "Chambres, notes internes, instantan\u00e9s d'export"), ("013", "Rooming lists g\u00e9n\u00e9r\u00e9es"),
    ("014", "Demande d'informations manquantes"), ("015", "Origine d'une modification"),
    ("016", "Bloc de contact organisateur"), ("017", "Ajout / remplacement de source"),
    ("018", "Mini-site sur le lien d'inscription"), ("019", "M\u00e9moire de l'assistant"),
    ("020", "\u00c9chelle d'acc\u00e8s (r\u00f4les)"), ("021", "Copies de passeport et photos"),
    ("022", "Prolongation de s\u00e9jour \u00e0 frais propres"), ("023", "Num\u00e9rotation des rooming lists"),
    ("024", "M\u00e9moire de mapping par projet"), ("026", "Un logo par \u00e9v\u00e9nement"),
    ("027", "Badges, visibilit\u00e9 et ordre des champs"), ("028", "Notes internes nomm\u00e9es"),
    ("029", "Place de la photo dans une section"), ("030", "Apparence du formulaire public"),
    ("031", "Provisioning SSO sécurisé : verrou de domaine + rôle"),
    ("032", "Mise en page du formulaire en blocs"),
]
rows = [["N\u00b0", "Objet", "N\u00b0", "Objet"]]
half = (len(MIGRATIONS) + 1) // 2
for i in range(half):
    left = MIGRATIONS[i]
    right = MIGRATIONS[i + half] if i + half < len(MIGRATIONS) else ("", "")
    rows.append([left[0], left[1], right[0], right[1]])
A(table(rows, [11 * mm, 74 * mm, 11 * mm, 74 * mm]))
A(Spacer(1, 6))
A(para(
    "<b>Une seule exception :</b> la migration <b>020</b> doit \u00eatre ex\u00e9cut\u00e9e <b>seule</b>, "
    "sans rien d'autre dans la m\u00eame fen\u00eatre. Elle ajoute une valeur \u00e0 un type \u00e9num\u00e9r\u00e9, "
    "ce que PostgreSQL refuse de faire \u00e0 l'int\u00e9rieur d'une transaction group\u00e9e.", "note"))
A(para(
    "La migration <b>031</b> remplace le d\u00e9clencheur de l'\u00e9tape 1.2 par une version "
    "s\u00e9curis\u00e9e (d\u00e9taill\u00e9e \u00e0 l'\u00c9tape 4). Sans elle, tout nouveau compte devient "
    "administrateur de l'organisation : ne la sautez pas.", "note"))

A(para("1.4 Cr\u00e9er les deux espaces de stockage", "h2"))
A(para(
    "Dans <i>Storage</i>. Ils ne sont <b>pas</b> cr\u00e9\u00e9s par les migrations : un espace de "
    "stockage ne se cr\u00e9e pas en SQL. Les oublier donne l'erreur "
    "\u00ab L'image n'a pas pu \u00eatre enregistr\u00e9e \u00bb au premier logo t\u00e9l\u00e9vers\u00e9."))
A(Spacer(1, 3))
A(table([
    ["Nom", "Acc\u00e8s", "Limite", "Contenu"],
    ["event-files", "Priv\u00e9", "\u2014", "Fichiers import\u00e9s (FCM, inscriptions, rooming)."],
    ["event-site-public", "Public", "5 Mo", "Logos, images du mini-site, photo d'en-t\u00eate du "
                                            "formulaire. Le navigateur d'un participant doit "
                                            "pouvoir les charger sans \u00eatre connect\u00e9."],
], [36 * mm, 18 * mm, 16 * mm, 100 * mm]))

A(PageBreak())

# ===========================================================================
A(para("\u00c9tape 2 \u2014 Railway (l'API)", "h1"))
A(para(
    "Cr\u00e9ez un projet sur <b>railway.app</b>, connectez le d\u00e9p\u00f4t et pointez le service sur "
    "le dossier <font face='Courier'>apps/api</font>. La commande de d\u00e9marrage est d\u00e9j\u00e0 dans "
    "<font face='Courier'>apps/api/railway.toml</font>."))
A(para(
    "<b>R\u00e9glez la r\u00e9gion du service sur l'Europe</b> (<i>Settings \u2192 Regions</i> \u2192 "
    "<b>EU West / europe-west4</b>). C'est \u00e0 faire \u00e0 la main dans le tableau de bord : "
    "contrairement \u00e0 ce qu'on pourrait croire, la ligne <font face='Courier'>region</font> "
    "du <font face='Courier'>railway.toml</font> ne place pas le service. Une API en Am\u00e9rique "
    "avec une base en Europe paie un aller-retour transatlantique sur <b>chaque</b> requ\u00eate "
    "\u2014 ~330 ms au lieu de ~40 ms, mesur\u00e9 \u2014 et c'est la premi\u00e8re cause de lenteur des "
    "\u00e9crans internes. Base et API doivent \u00eatre sur le m\u00eame continent.", "note"))

A(para("2.1 Variables obligatoires", "h2"))
A(para("Sans elles l'API ne d\u00e9marre pas.", "note"))
A(Spacer(1, 2))
A(table([
    ["Variable", "Valeur \u00e0 fournir"],
    ["SUPABASE_URL", "L'URL du projet Supabase (\u00e9tape 1.1)."],
    ["SUPABASE_SERVICE_ROLE_KEY", "La cl\u00e9 <b>service_role</b> (\u00e9tape 1.1). Jamais ailleurs "
                                  "que sur Railway."],
    ["SECRET_KEY", "Une cha\u00eene al\u00e9atoire que vous g\u00e9n\u00e9rez (32 caract\u00e8res ou plus). "
                   "Sert \u00e0 signer les jetons internes."],
    ["WEB_APP_URL", "L'adresse publique de l'application Vercel, une fois l'\u00e9tape 3 faite. "
                    "Utilis\u00e9e dans les liens des e-mails envoy\u00e9s aux participants."],
    ["ALLOWED_ORIGINS", "La m\u00eame adresse Vercel. C'est la liste des sites autoris\u00e9s \u00e0 "
                        "appeler l'API ; une adresse manquante bloque toute l'interface."],
    ["ENVIRONMENT", "<font face='Courier'>production</font>"],
], [52 * mm, 118 * mm]))

A(para("2.2 Intelligence artificielle \u2014 au moins une cl\u00e9", "h2"))
A(para(
    "Les fournisseurs sont essay\u00e9s dans cet ordre ; le premier qui r\u00e9pond gagne. "
    "Sans aucune cl\u00e9, l'application fonctionne toujours : le mapping des colonnes et "
    "l'assistant de formulaire retombent sur des r\u00e8gles par mots-cl\u00e9s, et le disent \u00e0 "
    "l'\u00e9cran.", "note"))
A(Spacer(1, 2))
A(table([
    ["Variable", "Fournisseur", "Obtenir la cl\u00e9 sur"],
    ["ANTHROPIC_API_KEY", "Claude (recommand\u00e9, essay\u00e9 en premier)", "console.anthropic.com"],
    ["NVIDIA_API_KEY", "NVIDIA NIM (secours)", "build.nvidia.com"],
    ["OPENAI_API_KEY", "OpenAI (secours)", "platform.openai.com"],
    ["GEMINI_API_KEY", "Google Gemini (dernier secours)", "aistudio.google.com"],
], [48 * mm, 72 * mm, 50 * mm]))

A(para("2.3 Messagerie \u2014 optionnel", "h2"))
A(para(
    "\u00c0 renseigner uniquement si vous utilisez l'agent de messagerie (lecture des r\u00e9ponses "
    "des participants dans une bo\u00eete Gmail ou Outlook).", "note"))
A(Spacer(1, 2))
A(table([
    ["Variable", "Pour"],
    ["GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET", "Connexion \u00e0 une bo\u00eete Gmail (OAuth)."],
    ["MAIL_OAUTH_REDIRECT_URI", "L'adresse de retour OAuth, sur votre domaine."],
    ["MICROSOFT_CLIENT_ID / _SECRET / _TENANT_ID", "Connexion \u00e0 une bo\u00eete Outlook."],
    ["MAIL_SYNC_MAX_MESSAGES", "Plafond de messages lus par synchronisation."],
], [72 * mm, 98 * mm]))

A(PageBreak())

A(para("2.4 R\u00e9glages fins \u2014 tous optionnels", "h2"))
A(para(
    "Chacun a une valeur par d\u00e9faut qui convient. Ils existent pour ajuster sans "
    "red\u00e9ployer.", "note"))
A(Spacer(1, 2))
A(table([
    ["Variable", "D\u00e9faut", "Effet"],
    ["ANTHROPIC_MODEL", "claude-opus-5", "Le mod\u00e8le Claude utilis\u00e9."],
    ["ANTHROPIC_EFFORT", "high", "Profondeur de r\u00e9flexion : low \u2192 max. Baisser rend "
                                 "l'assistant plus rapide et moins fin."],
    ["PUBLIC_CACHE_TTL", "60", "Dur\u00e9e (secondes) du cache du formulaire public. "
                               "Ce cache est ce qui permet \u00e0 500 personnes d'ouvrir le "
                               "lien en m\u00eame temps."],
    ["PUBLIC_CACHE_MAX_ENTRIES", "1000", "Plafond d'entr\u00e9es en m\u00e9moire."],
    ["SUPABASE_STORAGE_BUCKET", "event-files", "Nom de l'espace priv\u00e9."],
    ["SUPABASE_PUBLIC_BUCKET", "event-site-public", "Nom de l'espace public."],
    ["CLIENT_OPERATIONAL_ACCESS", "1", "\u00c0 0, le r\u00f4le \u00ab client \u00bb perd l'acc\u00e8s interne."],
    ["NVIDIA_MODEL, NVIDIA_VISION_MODEL,<br/>NVIDIA_FAST_MODEL, NVIDIA_PROSE_MODEL",
     "voir le code", "Mod\u00e8les NVIDIA par usage."],
    ["GEMINI_MODEL", "gemini-2.5-flash", "Le mod\u00e8le Gemini utilis\u00e9."],
], [58 * mm, 30 * mm, 82 * mm]))
A(Spacer(1, 5))
A(para(
    "Les variables commen\u00e7ant par <font face='Courier'>RAILWAY_</font> sont inject\u00e9es "
    "automatiquement par la plateforme. N'y touchez pas.", "note"))

# ===========================================================================
A(para("\u00c9tape 3 \u2014 Vercel (l'application web)", "h1"))
A(para(
    "Cr\u00e9ez un projet sur <b>vercel.com</b>, connectez le m\u00eame d\u00e9p\u00f4t et pointez la racine "
    "sur <font face='Courier'>apps/web</font>. Trois variables, toutes pr\u00e9fix\u00e9es "
    "<font face='Courier'>NEXT_PUBLIC_</font>, ce qui signifie qu'elles sont "
    "<b>visibles dans le navigateur</b> \u2014 c'est voulu, et c'est pourquoi la cl\u00e9 "
    "service_role n'a rien \u00e0 faire ici."))
A(Spacer(1, 3))
A(table([
    ["Variable", "Valeur \u00e0 fournir"],
    ["NEXT_PUBLIC_SUPABASE_URL", "L'URL du projet Supabase."],
    ["NEXT_PUBLIC_SUPABASE_ANON_KEY", "La cl\u00e9 <b>anon / publishable</b>. Publique par "
                                      "conception, prot\u00e9g\u00e9e par les r\u00e8gles RLS de la base."],
    ["NEXT_PUBLIC_API_URL", "L'adresse publique du service Railway (\u00e9tape 2), sans barre "
                            "oblique finale."],
], [58 * mm, 112 * mm]))
A(Spacer(1, 6))
A(para(
    "<b>Une fois Vercel d\u00e9ploy\u00e9</b>, revenez sur Railway et renseignez "
    "<font face='Courier'>WEB_APP_URL</font> et "
    "<font face='Courier'>ALLOWED_ORIGINS</font> avec l'adresse obtenue. "
    "C'est la seule d\u00e9pendance circulaire de l'installation.", "note"))

A(PageBreak())

# ===========================================================================
A(para("\u00c9tape 4 \u2014 Connexion Microsoft 365 (SSO)", "h1"))
A(para(
    "Cette \u00e9tape est <b>optionnelle</b> et n'ajoute aucun code : le bouton "
    "\u00ab Continuer avec Microsoft \u00bb est d\u00e9j\u00e0 dans l'application. Elle permet au "
    "personnel de se connecter avec son compte Microsoft 365 (Entra ID) au lieu d'un "
    "mot de passe. Trois choses \u00e0 configurer, aucune cl\u00e9 \u00e0 acheter."))

A(para("4.1 Enregistrer l'application dans Microsoft Entra ID", "h2"))
A(para(
    "Sur <b>portal.azure.com</b> \u2192 <i>Microsoft Entra ID</i> \u2192 <i>App registrations</i> "
    "\u2192 <i>New registration</i> :"))
A(Spacer(1, 2))
A(table([
    ["Champ", "Valeur"],
    ["Comptes pris en charge",
     "\u00ab Comptes dans cet annuaire d'organisation uniquement \u00bb (mono-locataire). "
     "C'est ce qui restreint la connexion au seul tenant du client : aucun autre "
     "compte Microsoft ne peut s'authentifier."],
    ["Redirect URI (type Web)",
     "https://&lt;votre-projet&gt;.supabase.co/auth/v1/callback"],
], [42 * mm, 128 * mm]))
A(Spacer(1, 4))
A(para(
    "Relevez ensuite l'<b>Application (client) ID</b> et le <b>Directory (tenant) ID</b>, "
    "puis cr\u00e9ez un secret dans <i>Certificates &amp; secrets</i> \u2192 <i>New client "
    "secret</i> et copiez sa <b>valeur</b> imm\u00e9diatement (elle ne r\u00e9appara\u00eet plus)."))

A(para("4.2 Activer le fournisseur Azure dans Supabase", "h2"))
A(para(
    "Dans Supabase \u2192 <i>Authentication</i> \u2192 <i>Providers</i> \u2192 <i>Azure</i>, activez le "
    "fournisseur et renseignez :"))
A(Spacer(1, 2))
A(table([
    ["Champ Supabase", "Valeur"],
    ["Application (client) ID", "L'identifiant relev\u00e9 \u00e0 l'\u00e9tape 4.1."],
    ["Secret Value", "La valeur du secret cr\u00e9\u00e9 \u00e0 l'\u00e9tape 4.1."],
    ["Azure Tenant URL", "https://login.microsoftonline.com/&lt;tenant-id&gt;"],
], [46 * mm, 124 * mm]))
A(Spacer(1, 4))
A(para(
    "Toujours dans <i>Authentication</i> \u2192 <i>URL Configuration</i>, ajoutez l'adresse "
    "Vercel aux <i>Redirect URLs</i> autoris\u00e9es avec le suffixe "
    "<font face='Courier'>/**</font> (par ex. "
    "<font face='Courier'>https://votre-app.vercel.app/**</font>) : sans cela, le retour "
    "de Microsoft est rejet\u00e9.", "note"))

A(para("4.3 Fermer la porte \u2014 le verrou de domaine", "h2"))
A(para(
    "La migration <b>031</b> (\u00e9tape 1.3) s\u00e9curise la cr\u00e9ation de compte, par mot de "
    "passe comme par Microsoft. Elle laisse volontairement la porte ouverte tant que "
    "vous n'avez pas d\u00e9clar\u00e9 votre domaine, pour que le tout premier administrateur "
    "puisse entrer."))
A(para(
    "<b>Tant qu'aucun domaine n'est d\u00e9clar\u00e9, n'importe quel compte Microsoft au monde "
    "peut cr\u00e9er un compte (en simple lecteur).</b> D\u00e8s que le premier administrateur "
    "est connect\u00e9, ex\u00e9cutez dans le SQL Editor :"))
A(Spacer(1, 2))
A(table([
    ["INSERT INTO public.allowed_signup_domains (domain, note)<br/>"
     "VALUES ('votre-domaine.com', 'Personnel via Microsoft 365');"],
], [170 * mm], header=False))
A(Spacer(1, 4))
A(para(
    "\u00c0 partir de l\u00e0, toute inscription venant d'un autre domaine est refus\u00e9e \u2014 "
    "l'utilisateur voit \u00ab Ce compte Microsoft n'est pas autoris\u00e9 sur cette instance \u00bb. "
    "Le premier compte est administrateur ; les suivants sont lecteurs, \u00e0 promouvoir "
    "manuellement.", "note"))

A(PageBreak())

# ===========================================================================
A(para("V\u00e9rifier que tout est en place", "h1"))
A(para("Quatre contr\u00f4les, dans l'ordre. Chacun se fait depuis un navigateur."))
A(Spacer(1, 3))
A(table([
    ["#", "Contr\u00f4le", "R\u00e9sultat attendu"],
    ["1", "Ouvrir <font face='Courier'>&lt;API&gt;/api/events/x/field-policy</font>",
     "Une erreur <b>401</b>. Un <b>404</b> signifie que l'API n'est pas d\u00e9ploy\u00e9e."],
    ["2", "Ouvrir l'adresse Vercel", "La page de connexion s'affiche."],
    ["3", "Cr\u00e9er un compte, puis un \u00e9v\u00e9nement",
     "Si la cr\u00e9ation de compte \u00e9choue, le d\u00e9clencheur de l'\u00e9tape 1.2 n'est pas pass\u00e9."],
    ["4", "T\u00e9l\u00e9verser un logo sur l'\u00e9v\u00e9nement",
     "S'il refuse, l'espace <font face='Courier'>event-site-public</font> manque (\u00e9tape 1.4)."],
], [8 * mm, 74 * mm, 88 * mm]))

A(para("Un point d'attention sur les comptes", "h2"))
A(para(
    "La migration 005 active une r\u00e8gle permanente : un compte cr\u00e9\u00e9 avec un r\u00f4le autre "
    "qu'<b>admin</b> ou <b>pm</b> (viewer, client, project_user, freelancer) ne verra "
    "<b>aucun \u00e9v\u00e9nement</b> tant qu'il n'a pas \u00e9t\u00e9 ajout\u00e9 explicitement aux membres du "
    "projet concern\u00e9. Ce n'est pas un bug d'installation : c'est le fonctionnement voulu. "
    "\u00c0 savoir avant de cr\u00e9er le premier compte non-administrateur."))

# ===========================================================================
A(para("Capacit\u00e9 \u2014 ce que cette installation supporte", "h1"))
A(para(
    "Chiffres mesur\u00e9s sur le d\u00e9ploiement de r\u00e9f\u00e9rence le 6 septembre 2026, API et base "
    "dans la m\u00eame r\u00e9gion europ\u00e9enne (voir \u00c9tape 2). Mesur\u00e9s, non estim\u00e9s."))
A(Spacer(1, 3))
A(table([
    ["Usage", "Capacit\u00e9 mesur\u00e9e", "Verdict"],
    ["Participants ouvrant le formulaire d'inscription",
     "120 requ\u00eates/s \u2014 500 personnes servies en 4 \u00e0 5 secondes",
     "Confortable. Le formulaire est mis en cache."],
    ["Organisateurs utilisant les \u00e9crans internes",
     "~20 requ\u00eates/s sur le chemin le plus lourd \u2014 m\u00e9diane 0,4 s \u00e0 20 simultan\u00e9s",
     "60 \u00e0 100 organisateurs actifs en m\u00eame temps."],
], [50 * mm, 62 * mm, 58 * mm]))
A(Spacer(1, 6))
A(para(
    "Ces deux chiffres ne se comparent pas : le formulaire public est servi depuis un "
    "cache m\u00e9moire, les \u00e9crans internes interrogent la base \u00e0 chaque affichage. "
    "Ce dernier chiffre d\u00e9pend directement du fait que l'API et la base soient sur le "
    "m\u00eame continent : avant de rapprocher les r\u00e9gions, le m\u00eame d\u00e9ploiement plafonnait \u00e0 "
    "10-15 organisateurs simultan\u00e9s avec des pages \u00e0 9 secondes. Pour une \u00e9quipe "
    "d'organisateurs, 60 \u00e0 100 en simultan\u00e9 couvre largement l'usage r\u00e9el. Au-del\u00e0 de "
    "plusieurs centaines, une \u00e9volution technique est n\u00e9cessaire \u2014 elle est chiffr\u00e9e "
    "s\u00e9par\u00e9ment."))

A(PageBreak())

# ===========================================================================
A(para("S\u00e9curit\u00e9 et confidentialit\u00e9 des donn\u00e9es", "h1"))
A(para(
    "Section v\u00e9rifi\u00e9e dans le code source le 6 septembre 2026, endpoint par endpoint. "
    "Comme le reste du document, c'est un constat technique, pas un avis juridique.", "note"))
A(Spacer(1, 3))
A(table([
    ["M\u00e9canisme", "Ce qu'il garantit"],
    ["Une installation par client",
     "Chaque client a son propre Supabase, son propre Railway, son propre Vercel. "
     "Les donn\u00e9es d'un client vivent dans une base physiquement distincte : aucune "
     "base n'est partag\u00e9e entre clients."],
    ["Acc\u00e8s par l'API<br/>(participants, vols, h\u00f4tels\u2026)",
     "La cl\u00e9 service_role reste c\u00f4t\u00e9 serveur. Chaque endpoint de donn\u00e9es exige une "
     "authentification \u2014 seul le formulaire d'inscription public en est dispens\u00e9, par "
     "conception. Un acc\u00e8s \u00e0 un \u00e9v\u00e9nement v\u00e9rifie qu'il appartient \u00e0 l'organisation de "
     "l'utilisateur, sinon 404 : l'\u00e9v\u00e9nement d'une autre organisation n'est m\u00eame pas "
     "r\u00e9v\u00e9l\u00e9 comme existant. \u00c9crire exige en plus le niveau \u00ab editor \u00bb."],
    ["Acc\u00e8s direct par le navigateur",
     "La cl\u00e9 publique ne touche qu'une seule table (les profils utilisateurs), "
     "prot\u00e9g\u00e9e par la s\u00e9curit\u00e9 au niveau des lignes : chacun ne voit que son "
     "organisation."],
    ["RLS en d\u00e9fense de profondeur",
     "Activ\u00e9e sur les 12 tables centrales (organisations, utilisateurs, projets, "
     "\u00e9v\u00e9nements, participants, exceptions\u2026), m\u00eame l\u00e0 o\u00f9 l'API contr\u00f4le d\u00e9j\u00e0."],
    ["Cr\u00e9ation de compte (migr. 031)",
     "Seuls les domaines e-mail d\u00e9clar\u00e9s peuvent cr\u00e9er un compte ; seul le tout "
     "premier compte est administrateur, les suivants sont lecteurs."],
    ["Donn\u00e9es sensibles (art. 9 RGPD)",
     "R\u00e9gime alimentaire et besoins PMR masqu\u00e9s selon le r\u00f4le : seuls admin et pm "
     "les voient."],
    ["Secrets",
     "Aucune valeur secr\u00e8te n'est dans le d\u00e9p\u00f4t (fichiers d'environnement vides). La "
     "cl\u00e9 service_role ne quitte jamais Railway."],
], [42 * mm, 128 * mm]))

A(para("Trois points \u00e0 confirmer avant la mise en production", "h2"))
A(Spacer(1, 2))
A(table([
    ["#", "\u00c0 faire", "Pourquoi"],
    ["1", "Ins\u00e9rer votre domaine dans allowed_signup_domains",
     "Sans \u00e7a, la porte reste ouverte \u00e0 tout compte Microsoft (\u00e9tape 4.3)."],
    ["2", "V\u00e9rifier que RLS est bien actif",
     "Le contr\u00f4le #1 (401 sur l'API) prouve que l'API n'est pas ouverte ; en base, "
     "Authentication \u2192 Policies doit lister les politiques d'isolation par "
     "organisation."],
    ["3", "D\u00e9finir une r\u00e8gle de conservation",
     "Aucune suppression automatique apr\u00e8s \u00e9v\u00e9nement n'est cod\u00e9e ; les donn\u00e9es de "
     "participants restent jusqu'\u00e0 suppression manuelle."],
], [8 * mm, 68 * mm, 94 * mm]))

# ===========================================================================
A(para("Sous-traitants et donn\u00e9es personnelles", "h1"))
A(para(
    "\u00c0 d\u00e9clarer dans votre registre de traitements. Ce paragraphe est un inventaire "
    "technique v\u00e9rifi\u00e9 dans le code, pas un avis juridique : faites-le valider par votre "
    "d\u00e9l\u00e9gu\u00e9 \u00e0 la protection des donn\u00e9es.", "note"))
A(Spacer(1, 2))
A(table([
    ["Sujet", "Situation"],
    ["H\u00e9bergement", "Supabase (Paris), Railway (Pays-Bas), Vercel. Donn\u00e9es dans l'UE si "
                        "la r\u00e9gion de l'\u00e9tape 1.1 est respect\u00e9e."],
    ["Fournisseurs d'IA", "Les invites envoy\u00e9es contiennent des <b>faits calcul\u00e9s</b> "
                          "(comptages, statuts) et, lorsqu'une question porte sur une "
                          "personne, son <b>nom</b>. Ni num\u00e9ro de passeport, ni date de "
                          "naissance, ni r\u00e9gime alimentaire n'est transmis."],
    ["Donn\u00e9es sensibles", "Le r\u00e9gime alimentaire peut r\u00e9v\u00e9ler une conviction religieuse, "
                              "les besoins PMR un \u00e9tat de sant\u00e9 (article 9 RGPD). "
                              "L'application les masque d\u00e9j\u00e0 selon le r\u00f4le, mais elles sont "
                              "collect\u00e9es et stock\u00e9es."],
    ["Conservation", "Aucune suppression automatique apr\u00e8s \u00e9v\u00e9nement n'est impl\u00e9ment\u00e9e. "
                     "\u00c0 d\u00e9finir comme proc\u00e9dure."],
], [34 * mm, 136 * mm]))

# ===========================================================================
# Annexe — le SQL complet, copiable-collable
# ===========================================================================
A(PageBreak())
A(para("Annexe — tout le SQL, prêt à copier-coller", "h1"))
A(para(
    "Chaque bloc ci-dessous est le contenu exact d'un fichier du dépôt. Copiez un bloc "
    "entier dans le <i>SQL Editor</i> de Supabase et exécutez-le. Les lignes trop longues "
    "sont repliées pour tenir dans la page : le SQL reste valide, PostgreSQL traitant tout "
    "retour à la ligne comme une simple espace.", "note"))

A(para("A. Schéma de base — à exécuter en premier (Étape 1.2)", "h2"))
for fn in ("schema.sql", "schema_phase2.sql", "schema_email_agent.sql", "supabase_trigger.sql"):
    path = os.path.join(HERE, fn)
    if not os.path.exists(path):
        continue
    A(para(fn, "codeh"))
    A(code_block(path))

A(PageBreak())
A(para("B. Migrations — dans l'ordre numérique (Étape 1.3)", "h2"))
A(para(
    "Rappel : la <b>020</b> se lance seule (elle ajoute une valeur à un type énuméré, "
    "interdit dans une transaction groupée), et la <b>031</b> ne doit pas être sautée "
    "(elle ferme le trou par lequel tout nouveau compte deviendrait administrateur).", "note"))
for num, label in MIGRATIONS:
    matches = sorted(glob.glob(os.path.join(HERE, "migrations", "%s_*.sql" % num)))
    if not matches:
        continue
    path = matches[0]
    if num == "020":
        A(para(
            "⚠ Migration 020 — à exécuter SEULE, rien d'autre dans la même fenêtre.", "note"))
    A(para("Migration %s — %s" % (num, label), "codeh"))
    A(para("<font face='Courier'>%s</font>" % os.path.basename(path), "note"))
    A(code_block(path))

os.makedirs(os.path.dirname(OUT), exist_ok=True)
doc = SimpleDocTemplate(
    OUT, pagesize=A4,
    leftMargin=20 * mm, rightMargin=20 * mm, topMargin=18 * mm, bottomMargin=22 * mm,
    title="VO Event Max \u2014 Guide d'installation",
    author="VO Event Max",
    subject="Installation sur Supabase, Railway et Vercel",
)
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print("PDF ecrit :", OUT, "(%d octets)" % os.path.getsize(OUT))
