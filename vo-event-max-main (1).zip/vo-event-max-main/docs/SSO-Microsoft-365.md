# Connexion Microsoft 365 (Entra ID) — mise en service

Le code est en place côté application. Ce qui reste ci-dessous ne peut être fait
que par le client : cela se passe dans **son** tenant Microsoft et manipule
**ses** secrets — je n'y ai pas accès et ne dois pas les voir.

Ordre : **A** (Microsoft) → **B** (Supabase) → **C** (verrou de sécurité).
Compter ~30 minutes.

---

## Ce qui a déjà été codé

| Élément | Fichier |
|---|---|
| Bouton « Continuer avec Microsoft 365 » | `apps/web/src/app/[locale]/login/page.tsx` |
| Page de retour OAuth | `apps/web/src/app/[locale]/auth/callback/page.tsx` |
| Provisioning sécurisé (rôle `viewer`, verrou de domaine) | `docs/migrations/031_sso_provisioning.sql` |
| Traductions FR / NL / EN | `apps/web/src/messages/*.json` |

Le bouton lance la redirection vers Microsoft ; **qui a le droit d'obtenir un
compte est décidé dans la base** (migration 031), jamais dans le bouton — parce
que n'importe qui peut atteindre la page de connexion.

---

## A. Microsoft Entra ID (portail Azure)

1. **portal.azure.com** → *Microsoft Entra ID* → *App registrations* → *New registration*.
2. **Name** : `VO Event Max`.
3. **Supported account types** :
   - **Single tenant** (recommandé) — seuls les comptes de l'organisation du
     client peuvent se connecter. C'est la première ligne de défense.
   - Multitenant seulement si des invités externes doivent entrer (déconseillé
     ici).
4. **Redirect URI** : type **Web**, valeur = l'URL de rappel **de Supabase**,
   pas celle de l'app :
   ```
   https://<REF_PROJET>.supabase.co/auth/v1/callback
   ```
   (`<REF_PROJET>` = le sous-domaine du projet Supabase.)
5. *Register*. Noter le **Application (client) ID** et le **Directory (tenant) ID**.
6. *Certificates & secrets* → *New client secret* → copier immédiatement la
   **Value** (elle ne se réaffiche jamais). C'est un secret : elle va dans
   Supabase et nulle part ailleurs.
7. *API permissions* : `openid`, `email`, `profile` (Microsoft Graph, déléguées)
   sont suffisantes ; elles sont généralement déjà présentes.

---

## B. Supabase (dashboard)

1. *Authentication* → *Providers* → **Azure** → *Enable*.
2. **Application (client) ID** : celui de l'étape A.5.
3. **Secret Value** : la valeur copiée en A.6.
4. **Azure Tenant URL** (single tenant — le verrou correspondant à A.3) :
   ```
   https://login.microsoftonline.com/<TENANT_ID>
   ```
   Laisser vide (= `common`) accepterait n'importe quel compte Microsoft du
   monde : à ne faire que si le multitenant est réellement voulu.
5. *Save*.
6. *Authentication* → *URL Configuration* → **Redirect URLs** : autoriser les
   URL de retour de l'app, toutes langues confondues :
   ```
   https://<DOMAINE_DE_L_APP>/fr/auth/callback
   https://<DOMAINE_DE_L_APP>/nl/auth/callback
   https://<DOMAINE_DE_L_APP>/en/auth/callback
   ```
   ou un joker : `https://<DOMAINE_DE_L_APP>/**`.

---

## C. Le verrou de sécurité (à ne pas oublier)

La migration `031` doit être appliquée (elle fait partie des 29+ du guide
d'installation). Elle change deux choses :

- **le premier compte** créé sur une instance vide devient `admin` (bootstrap) ;
  **tous les suivants sont `viewer`** — personne n'est admin par le simple fait
  de se connecter ;
- une table `allowed_signup_domains` : **tant qu'elle est vide, n'importe qui
  peut créer un compte.** Dès que le premier admin du client est entré, verrouiller :

  ```sql
  INSERT INTO public.allowed_signup_domains (domain, note)
  VALUES ('domaine-du-client.com', 'Personnel du client via Microsoft 365');
  ```

  À partir de là, toute connexion — mot de passe **ou** Microsoft — dont le
  domaine e-mail n'est pas listé est refusée proprement (l'utilisateur voit un
  message, aucun compte fantôme n'est créé).

> Le single tenant (A.3) et le verrou de domaine (C) font le même travail à deux
> niveaux : Microsoft ne laisse passer que le tenant du client, et la base ne
> provisionne que le domaine du client. Garder les deux.

---

## Vérification

1. Se déconnecter, ouvrir la page de connexion, cliquer **Continuer avec Microsoft 365**.
2. S'authentifier avec un compte **du domaine du client** → retour sur l'app,
   session ouverte, rôle `viewer` (ou `admin` si c'est le tout premier compte).
3. Essayer un compte **hors domaine** après avoir rempli `allowed_signup_domains`
   → refus avec le message « Ce compte Microsoft n'est pas autorisé sur cette
   instance ». C'est le comportement attendu.
4. Un admin promeut ensuite les bons utilisateurs (`pm`, `admin`) depuis
   l'application.
