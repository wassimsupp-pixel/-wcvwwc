-- ============================================================================
-- Migration 029 — Where the photo sits inside a mini-site section
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Point 13 asked to arrange "la place de la photo et des textes à ma guise".
-- Section ORDER needed no migration (the `position` column already existed and
-- was simply hardcoded to the catalogue's order in code). This is the other
-- half: whether a section's photo appears above its text or below it.
--
-- Two values only, 'above' | 'below'. On a page read mostly on a phone every
-- other arrangement collapses into one of those two anyway, so a free canvas
-- would offer choices that do not survive a narrow screen.
--
-- Without this migration nothing breaks: the editor's control saves without
-- the field, and every photo keeps rendering above its text as it does today.
-- ============================================================================

ALTER TABLE event_site_sections
  ADD COLUMN IF NOT EXISTS image_position TEXT NOT NULL DEFAULT 'above';

COMMENT ON COLUMN event_site_sections.image_position IS
  'Point 13: where this section''s photo sits relative to its text — ''above'' (default) or ''below''. services/event_site.clean_image_position is the authority.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
SELECT 'event_site_sections.image_position' AS item,
       CASE WHEN EXISTS (SELECT 1 FROM information_schema.columns
         WHERE table_name = 'event_site_sections' AND column_name = 'image_position')
       THEN 'OK' ELSE 'MANQUANT' END AS status;
