-- ============================================================================
-- Migration 011 — Per-event transfer fleet and safety margin
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Feedback §1, the point the review called one of the most important: MAX
-- organises ground transport FROM the flights. People on the same plane travel
-- together, people landing close enough in time can share, and the vehicle is
-- chosen from the head count.
--
-- Two numbers make that possible and neither belongs in code, because both
-- change per event and per destination:
--
--   vehicles                 the fleet actually available, with real capacities
--   min_hours_before_flight  how early to leave the hotel for a departure
--                            ("Vol 14h00, 3h de marge -> depart 11h00")
--
-- Shape:
--   {"vehicles": [{"name": "Taxi", "capacity": 3}, ...],
--    "min_hours_before_flight": 3,
--    "grouping_window_minutes": 60}
--
-- NULL / absent => the defaults in services/dispatch_service.py, which are the
-- four vehicles the feedback itself lists (taxi 3, van 7, minibus 18, bus 50)
-- and a three-hour margin. The planner works on an unconfigured event; it just
-- works with those.
--
-- Nothing here stores a PLAN. The proposal endpoint computes and returns one
-- without writing, and only groups the organizer accepts become rows in
-- `transfers` — the tool proposes, the human decides.
-- ============================================================================

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS transfer_settings JSONB;

COMMENT ON COLUMN events.transfer_settings IS
  'Dispatching parameters: available fleet with capacities, minimum hours before a flight, and the arrival grouping window. NULL = defaults (see services/dispatch_service.py). Re-validated on write: a zero-capacity vehicle is replaced, never stored.';
