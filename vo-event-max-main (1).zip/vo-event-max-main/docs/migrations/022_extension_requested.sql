-- ============================================================================
-- Migration 022 — Prolongation de séjour à frais propres (feedback §3)
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Four questions have sat in the registration form's field catalogue since an
-- earlier pass on §3 — "Souhaitez-vous prolonger votre séjour à vos frais ?"
-- and its start date, end date, and hotel — fully wired on the form side
-- (services/registration_form.py, translated fr/nl/en) and completely inert on
-- the other end: no column existed to hold an answer, so consolidation had
-- nowhere to put one and every reply was silently dropped.
--
-- These are plain participant facts (not flight/hotel/transfer specifics that
-- belong in their own tables), so they land directly on participants,
-- alongside room_type and roommate_name which arrived the same way.
--
-- Without this migration the form still asks the question; the answer still
-- goes nowhere. Applying it does not backfill anything already lost — only
-- submissions from AFTER the next consolidation carry it through.
-- ============================================================================

ALTER TABLE participants
  ADD COLUMN IF NOT EXISTS extension_requested TEXT;
ALTER TABLE participants
  ADD COLUMN IF NOT EXISTS extension_start TEXT;
ALTER TABLE participants
  ADD COLUMN IF NOT EXISTS extension_end TEXT;
ALTER TABLE participants
  ADD COLUMN IF NOT EXISTS extension_hotel TEXT;

COMMENT ON COLUMN participants.extension_requested IS
  'The registrant''s own answer to "would you like to extend your stay at your own expense?" (§3). Free text as submitted, not a boolean — the form asks it as an open question, not a checkbox.';
COMMENT ON COLUMN participants.extension_start IS 'When a personal extension begins, as the registrant wrote it.';
COMMENT ON COLUMN participants.extension_end IS 'When a personal extension ends, as the registrant wrote it.';
COMMENT ON COLUMN participants.extension_hotel IS 'Where the registrant said they would stay during the extension, if anywhere organised.';


-- ---------------------------------------------------------------------------
-- Verification — expect 4 rows, all OK
-- ---------------------------------------------------------------------------
SELECT column_name AS item,
       'OK' AS status
FROM information_schema.columns
WHERE table_name = 'participants'
  AND column_name IN ('extension_requested', 'extension_start', 'extension_end', 'extension_hotel')
ORDER BY column_name;
