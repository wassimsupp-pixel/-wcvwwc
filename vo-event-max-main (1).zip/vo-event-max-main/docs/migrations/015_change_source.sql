-- ============================================================================
-- Migration 015 — Where a change came from (feedback §19)
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- change_log has recorded who / when / which field / from what / to what since
-- the beginning. The column it never had is the one that actually settles an
-- argument: WHERE the new value came from.
--
--   "Phone changed from X to Y"                  invites the question
--   "Phone changed because Tuesday's FCM said so" answers it
--
-- Deliberately NOT back-filled. Rows written before this migration have no
-- origin, and services/history_service infers one from the reason code while
-- flagging it as inferred. Stamping a confident guess onto historical audit
-- rows would make the log less trustworthy, not more.
-- ============================================================================


-- One of: fcm_upload | registration_form | hotel_file | transfer_file |
--         manual_update | participant_email | ai_suggestion | system
--
-- Kept as TEXT rather than an ENUM on purpose: a new import kind must never be
-- able to fail an audit write. The canonical set lives in
-- services/history_service.LABELS, and an unrecognised value renders as
-- "Origine inconnue" instead of taking a consolidation down.
ALTER TABLE change_log
  ADD COLUMN IF NOT EXISTS source TEXT;

-- The file that carried the value, when there was one. Lets "Import FCM"
-- become "Import FCM — FCM_Week3.xlsx" without a second lookup per row.
ALTER TABLE change_log
  ADD COLUMN IF NOT EXISTS source_file_id UUID REFERENCES uploaded_files(id) ON DELETE SET NULL;

-- The history screen reads by event, newest first, and by participant on the
-- fiche. Both are indexed: an audit trail nobody can open is not an audit trail.
CREATE INDEX IF NOT EXISTS idx_change_log_event_time
  ON change_log(event_id, changed_at DESC);
CREATE INDEX IF NOT EXISTS idx_change_log_entity_time
  ON change_log(entity_id, changed_at DESC);
CREATE INDEX IF NOT EXISTS idx_change_log_source
  ON change_log(event_id, source);

COMMENT ON COLUMN change_log.source IS
  'Where the new value came from (feedback §19). NULL on rows written before migration 015; history_service infers those and marks them as inferred rather than presenting a guess as a record.';
COMMENT ON COLUMN change_log.source_file_id IS
  'The uploaded file that carried the value, when the change came from an import.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
-- Expect two rows.
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_name = 'change_log'
  AND column_name IN ('source', 'source_file_id')
ORDER BY column_name;
