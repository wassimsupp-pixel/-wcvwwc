-- ============================================================================
-- Migration 028 — Named internal notes with their own colour
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- The team writes the same handful of remarks constantly ("Super VIP",
-- "cadeau dans la chambre", "appeler personnellement"). A preset is that
-- remark, named once per event, with a colour the team picks — applying it
-- writes a normal note and stamps which preset it came from.
--
-- Two columns, because the two facts live in different places:
--
--   events.note_presets            the catalogue, per event, managed by the
--                                  team from the participant screen
--   participant_notes.preset_id    which preset a given note came from, so
--                                  the master list can colour that person's
--                                  row with the preset's own colour instead
--                                  of the generic category colour
--
-- Without this migration nothing breaks: no presets can be saved, and the
-- master list keeps colouring rows by note category exactly as it does today
-- (services/note_presets.highlight_color falls back on its own).
-- ============================================================================

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS note_presets JSONB NOT NULL DEFAULT '[]'::jsonb;

COMMENT ON COLUMN events.note_presets IS
  'Named reusable internal notes for this event ([{id, name, body, color, category}, ...]). services/note_presets.resolve is the authority on what a valid entry looks like.';

ALTER TABLE participant_notes
  ADD COLUMN IF NOT EXISTS preset_id TEXT;

COMMENT ON COLUMN participant_notes.preset_id IS
  'Which events.note_presets entry this note was created from, if any. Drives the master-list row colour; NULL means the row falls back to its category colour. A preset deleted afterwards simply stops matching — the note itself is untouched.';

CREATE INDEX IF NOT EXISTS idx_participant_notes_preset
  ON participant_notes(participant_id, preset_id)
  WHERE preset_id IS NOT NULL;


-- ---------------------------------------------------------------------------
-- Verification — expect both rows to say OK
-- ---------------------------------------------------------------------------
SELECT 'events.note_presets' AS item,
       CASE WHEN EXISTS (SELECT 1 FROM information_schema.columns
         WHERE table_name = 'events' AND column_name = 'note_presets')
       THEN 'OK' ELSE 'MANQUANT' END AS status
UNION ALL
SELECT 'participant_notes.preset_id',
       CASE WHEN EXISTS (SELECT 1 FROM information_schema.columns
         WHERE table_name = 'participant_notes' AND column_name = 'preset_id')
       THEN 'OK' ELSE 'MANQUANT' END;
