-- ============================================================================
-- Migration 027 — Badges, per-field visibility, and a custom field order
-- (point 13, v1: "formulaire modulable par badge")
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- "Modulable par badge" starts here: an organizer names categories once per
-- event (VIP, Speaker, Staff — whatever the event calls them), and each
-- question on the form can be restricted to only the badges that should see
-- it. A badge is never self-selected on the form; it comes from WHICH LINK a
-- person was sent (?badge=slug appended to the same registration token), the
-- way a real event already sends the VIP list a different link than the
-- general one.
--
-- Per-field badge lists and the custom field order both live INSIDE the
-- existing events.registration_fields JSONB (migration 007) — no schema
-- change needed there, only what services/registration_form writes into it.
-- This migration only adds the new column for the badge list itself.
--
-- Deliberately v1. A visual drag-and-drop canvas and brand-new block types
-- beyond the existing question catalogue are their own, later pass — this
-- gives an organizer real control over WHO sees WHICH existing question and
-- in WHAT order, which is the part that was completely unbuildable before.
--
-- Without this migration the form works exactly as today: no badges exist,
-- every field's badge list resolves empty (visible to everyone), and the
-- field order falls back to the catalogue's own order.
-- ============================================================================

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS registration_badges JSONB NOT NULL DEFAULT '[]'::jsonb;

COMMENT ON COLUMN events.registration_badges IS
  'Point 13 (v1): named categories this event''s form can be shown differently to — [{id, name}, ...]. Selected by ?badge= on the registration link, never by the registrant. services/registration_form.resolve_badges is the authority on what a valid entry looks like.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
SELECT 'events.registration_badges' AS item,
       CASE WHEN EXISTS (
         SELECT 1 FROM information_schema.columns
         WHERE table_name = 'events' AND column_name = 'registration_badges'
       ) THEN 'OK' ELSE 'MANQUANT' END AS status;
