-- ============================================================================
-- Migration 008 — Per-event participant field policy
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Answers feedback §10: "si l'événement n'a pas besoin de nationalité, on ne
-- doit pas avoir 150 participants en alerte Nationality missing".
--
-- Shape: {"<field_key>": "required" | "optional" | "not_used", ...}
--
--   required   the event needs it. Blank raises an exception and weighs on the
--              completeness score.
--   optional   stored and displayed, never alerted on, never scored.
--   not_used   this event does not collect it. Invisible to the exception
--              engine and dropped from the score's weighting entirely.
--
-- `not_used` NEVER deletes anything. A value arriving from a source file is
-- still stored and still shown on the fiche — the engine's first promise is
-- that nothing is lost, and a configuration screen must not be able to break
-- it.
--
-- NULL / absent => the defaults in services/field_policy.py, which are exactly
-- the fields the exception engine already alerted on before this migration.
-- Nothing changes until somebody deliberately configures an event, and nothing
-- breaks while this migration is unapplied: field_policy.fetch() treats the
-- missing column as "not configured" and every caller falls back to defaults.
-- ============================================================================

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS field_policy JSONB;

COMMENT ON COLUMN events.field_policy IS
  'Per-event participant field policy: {field_key: "required"|"optional"|"not_used"}. NULL = defaults (see services/field_policy.py). Drives exception detection and the data-quality score, never storage.';
