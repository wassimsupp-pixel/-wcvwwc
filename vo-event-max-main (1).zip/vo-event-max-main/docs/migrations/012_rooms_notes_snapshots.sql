-- ============================================================================
-- Migration 012 — Rooms, internal notes, and export snapshots
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- The last three structural gaps from the MAX / LivaNova feedback:
--
--   §5  a real rooming list -- a hotel works by ROOM, and hotel_nights is
--       indexed by (participant, night), so "304 = Tina + Leslie" could not
--       be written at all
--   §8  internal notes with a category and a say in whether they leave
--   §7  an UPDATES tab comparing each export to the one before it
--
-- Every feature degrades to a no-op until this runs.
-- ============================================================================


-- ---------------------------------------------------------------------------
-- 1. Rooms (§5)
-- ---------------------------------------------------------------------------
-- Deliberately thin. A room is a number and a type; WHO is in it comes from
-- the roommate link and the nights, which are already the source of truth. A
-- separate occupancy table would be a second truth able to drift out of step
-- with the first, and a rooming list that contradicts itself between two tabs
-- is worse than one that is merely incomplete.

CREATE TABLE IF NOT EXISTS rooms (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id    UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  hotel_id    UUID        REFERENCES hotels(id) ON DELETE CASCADE,
  number      TEXT        NOT NULL,
  room_type   TEXT        NOT NULL DEFAULT 'single',
  notes       TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (hotel_id, number)
);

CREATE INDEX IF NOT EXISTS idx_rooms_event ON rooms(event_id);

ALTER TABLE rooms ENABLE ROW LEVEL SECURITY;

-- The room number on the fiche. Denormalised on purpose: the hotel sends back
-- a spreadsheet of names and numbers long before anybody creates room records,
-- and a participant must be able to carry their number from the moment it is
-- known.
ALTER TABLE participants
  ADD COLUMN IF NOT EXISTS room_number TEXT;

ALTER TABLE hotel_nights
  ADD COLUMN IF NOT EXISTS room_id UUID REFERENCES rooms(id) ON DELETE SET NULL;

COMMENT ON TABLE rooms IS
  'Physical rooms. Occupancy is NOT stored here: it is derived from participants.roommate_participant_id and hotel_nights, so the two views can never contradict each other.';
COMMENT ON COLUMN participants.room_number IS
  'Room number as the hotel gave it, before any room record exists. Two roommates with different numbers raise a room_number_mismatch rather than one silently winning.';


-- ---------------------------------------------------------------------------
-- 2. Internal notes (§8)
-- ---------------------------------------------------------------------------
-- include_in_export defaults to FALSE, and that default is the feature. The
-- failure mode is not "we forgot to share a remark" -- it is a coach company
-- reading "difficult client, handle carefully" about somebody in their van.
--
-- The category is not decoration either: it decides which supplier could ever
-- see the note once flagged. 'general' has no destination and can therefore
-- never be exported, whatever it says.

CREATE TABLE IF NOT EXISTS participant_notes (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id          UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  participant_id    UUID        NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
  category          TEXT        NOT NULL DEFAULT 'general',
  body              TEXT        NOT NULL,
  include_in_export BOOLEAN     NOT NULL DEFAULT FALSE,
  author_id         UUID        REFERENCES users(id) ON DELETE SET NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT participant_notes_category_check
    CHECK (category IN ('general', 'accommodation', 'flight', 'transfer', 'activity'))
);

CREATE INDEX IF NOT EXISTS idx_participant_notes_participant
  ON participant_notes(participant_id);
CREATE INDEX IF NOT EXISTS idx_participant_notes_exportable
  ON participant_notes(event_id, category)
  WHERE include_in_export = TRUE;

ALTER TABLE participant_notes ENABLE ROW LEVEL SECURITY;

COMMENT ON TABLE participant_notes IS
  'Operational remarks. include_in_export defaults to FALSE and is only honoured for a category that has a supplier destination -- see services/note_service.EXPORTABLE_TO.';


-- ---------------------------------------------------------------------------
-- 3. Export snapshots (§7)
-- ---------------------------------------------------------------------------
-- What each export said, so the next one can say what changed. Compared
-- against a STORED snapshot rather than against two files somebody happens to
-- still have -- and keyed by participant id, because names change and keying
-- on a name reports one person as another leaving and a stranger arriving.

CREATE TABLE IF NOT EXISTS export_snapshots (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id    UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  export_id   UUID        REFERENCES exports(id) ON DELETE SET NULL,
  payload     JSONB       NOT NULL,
  created_by  UUID        REFERENCES users(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_export_snapshots_event
  ON export_snapshots(event_id, created_at DESC);

ALTER TABLE export_snapshots ENABLE ROW LEVEL SECURITY;

COMMENT ON TABLE export_snapshots IS
  'One row per export: the tracked fields as that file stated them. The next export diffs against the most recent one to build its UPDATES sheet.';
