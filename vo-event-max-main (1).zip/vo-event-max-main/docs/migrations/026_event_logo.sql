-- ============================================================================
-- Migration 026 — A logo per event, instead of the fixed MAX mark (point 11)
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- The public registration form always showed the same MAX wordmark, whoever
-- the event was actually for. This lets each event carry its own logo —
-- LivaNova, or any other client — uploaded once from the registration-form
-- settings screen and shown on that event's public form from then on.
--
-- Without this migration the form keeps showing the MAX mark exactly as
-- today; nothing breaks, the upload control simply has nowhere to save to.
-- ============================================================================

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS logo_url TEXT;

COMMENT ON COLUMN events.logo_url IS
  'Point 11: this event''s own logo, shown on its public registration form instead of the default MAX mark. A public, permanent URL — uploaded via POST /events/{id}/logo into the SAME public bucket the mini-site images use (config.SUPABASE_PUBLIC_BUCKET), since an unauthenticated visitor''s browser has to load it directly.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
SELECT 'events.logo_url' AS item,
       CASE WHEN EXISTS (
         SELECT 1 FROM information_schema.columns
         WHERE table_name = 'events' AND column_name = 'logo_url'
       ) THEN 'OK' ELSE 'MANQUANT' END AS status;
