-- ============================================================================
-- Migration 024 — Column-mapping memory, scoped to the project (points 5+6)
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- column_mapping_templates already existed and already did almost exactly
-- this — a confirmed mapping was remembered so an identical file layout did
-- not need re-mapping. It was scoped to the ORGANISATION, which meant an
-- agency running two different clients under one org could have one client's
-- confirmed column meaning silently applied to the other's file, purely
-- because both happened to export a similarly-shaped spreadsheet.
--
-- This adds project_id as the actual scoping key. Existing rows keep
-- project_id NULL and simply stop matching anything going forward — nothing
-- is deleted, and nothing is silently applied across a project boundary
-- while this is unset. The next confirmed mapping in each project writes a
-- fresh, correctly-scoped row.
--
-- Also — deliberately, together with this migration, not a schema change on
-- its own — a recognised format no longer skips human review. It arrives
-- PRE-FILLED from memory, but a person still confirms it: memory is meant to
-- save typing, not the one check that catches a passport number landing in
-- the wrong column before it reaches a hotel or a supplier export.
--
-- Without this migration, mapping memory keeps working exactly as before —
-- org-wide, silent on a recognised format — until it is applied.
-- ============================================================================

ALTER TABLE column_mapping_templates
  ADD COLUMN IF NOT EXISTS project_id UUID REFERENCES projects(id) ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS idx_column_mapping_templates_project
  ON column_mapping_templates(project_id, template_name);

COMMENT ON COLUMN column_mapping_templates.project_id IS
  'Points 5+6: the project this confirmed mapping belongs to. NULL on rows saved before this migration — those no longer match anything, on purpose, rather than risk an org-wide match crossing into a different client''s project.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
SELECT 'column_mapping_templates.project_id' AS item,
       CASE WHEN EXISTS (
         SELECT 1 FROM information_schema.columns
         WHERE table_name = 'column_mapping_templates' AND column_name = 'project_id'
       ) THEN 'OK' ELSE 'MANQUANT' END AS status;
