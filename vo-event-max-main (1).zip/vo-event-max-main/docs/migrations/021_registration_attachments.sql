-- ============================================================================
-- Migration 021 — Passport copies and photos from the registration form (§9)
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- §9 lists a passport copy and an identity photo among what the form should be
-- able to collect. That means an endpoint taking a file from somebody with no
-- account and no session — the least trusted input the system has.
--
-- The shape below reflects three decisions made in services/registration_uploads:
--
--   * the visitor's filename is stored as a LABEL and never as a path. The
--     storage key is generated server-side, extension included;
--   * content_type is what we DETECTED, not what the browser claimed. A client
--     controls the header it sends, and that header decides how anything
--     downstream renders the file;
--   * an attachment starts life unclaimed, and is bound to a participant only
--     when the form it belongs to is actually submitted. An upload nobody
--     completed is a row to sweep, not a document about a person.
--
-- The files live in the SAME private Supabase Storage bucket as the imported
-- source files. There is no public URL: reading one goes through the API, which
-- checks event access first.
--
-- Without this migration the form works exactly as today and simply does not
-- offer the two upload fields.
-- ============================================================================

CREATE TABLE IF NOT EXISTS registration_attachments (
  id             UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id       UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  -- passport_scan | photo — services/registration_uploads.KINDS
  kind           TEXT        NOT NULL,
  storage_path   TEXT        NOT NULL,
  -- The visitor's own filename, kept so an organizer recognises the document.
  -- Sanitised on the way in; never used to build a path.
  original_name  TEXT,
  content_type   TEXT,
  byte_size      INTEGER     NOT NULL DEFAULT 0,
  -- NULL until the submission that references it goes through. Consolidation
  -- fills it once the fiche exists.
  participant_id UUID        REFERENCES participants(id) ON DELETE SET NULL,
  claimed_at     TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_registration_attachments_event
  ON registration_attachments(event_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_registration_attachments_participant
  ON registration_attachments(participant_id);
-- Uploads nobody ever submitted: the sweep list.
CREATE INDEX IF NOT EXISTS idx_registration_attachments_orphans
  ON registration_attachments(event_id, created_at)
  WHERE claimed_at IS NULL;

ALTER TABLE registration_attachments ENABLE ROW LEVEL SECURITY;

COMMENT ON TABLE registration_attachments IS
  'Files uploaded from the public registration form (feedback §9). Stored in the private bucket; no public URL exists. An unclaimed row is an upload whose form was never submitted.';
COMMENT ON COLUMN registration_attachments.content_type IS
  'Detected from the file''s own bytes, never taken from the browser''s header — that header is attacker-controlled and decides how anything downstream renders the file.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
SELECT 'registration_attachments' AS item,
       CASE WHEN to_regclass('public.registration_attachments') IS NOT NULL
            THEN 'OK' ELSE 'MANQUANT' END AS status;
