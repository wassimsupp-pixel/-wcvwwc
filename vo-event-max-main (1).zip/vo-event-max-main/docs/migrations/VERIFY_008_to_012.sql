-- ============================================================================
-- Verification des migrations 008 a 012
-- ============================================================================
-- A coller dans Supabase > SQL Editor apres ALL_008_to_012.sql.
--
-- Contrairement au DDL, cette requete RENVOIE des lignes : une par element
-- attendu, avec OK ou MANQUANT. Tout doit etre OK.
-- ============================================================================

WITH attendu(categorie, objet, detail) AS (
  VALUES
    -- Migration 008
    ('008 · champs par projet',    'events',             'field_policy'),
    -- Migration 009
    ('009 · roommates & nuitees',  'participants',       'roommate_name'),
    ('009 · roommates & nuitees',  'participants',       'roommate_participant_id'),
    ('009 · roommates & nuitees',  'participants',       'room_type'),
    ('009 · roommates & nuitees',  'hotel_nights',       'night_kind'),
    ('009 · roommates & nuitees',  'hotel_nights',       'source'),
    -- Migration 010
    ('010 · formulaire',           'events',             'registration_custom_fields'),
    ('010 · formulaire',           'events',             'registration_confirmations'),
    -- Migration 011
    ('011 · transferts',           'events',             'transfer_settings'),
    -- Migration 012
    ('012 · rooming & notes',      'participants',       'room_number'),
    ('012 · rooming & notes',      'hotel_nights',       'room_id')
)
SELECT
  a.categorie,
  a.objet || '.' || a.detail AS colonne,
  CASE WHEN c.column_name IS NULL THEN '❌ MANQUANT' ELSE '✅ OK' END AS etat
FROM attendu a
LEFT JOIN information_schema.columns c
  ON c.table_schema = 'public'
 AND c.table_name   = a.objet
 AND c.column_name  = a.detail

UNION ALL

SELECT
  '012 · nouvelles tables',
  t.nom,
  CASE WHEN to_regclass('public.' || t.nom) IS NULL THEN '❌ MANQUANT' ELSE '✅ OK' END
FROM (VALUES ('rooms'), ('participant_notes'), ('export_snapshots')) AS t(nom)

ORDER BY 1, 2;
