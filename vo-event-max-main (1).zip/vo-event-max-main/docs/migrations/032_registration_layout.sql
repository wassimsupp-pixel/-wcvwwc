-- ============================================================================
-- Migration 032 — The public form can be arranged in blocks
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Migration 030 let an event choose how its form LOOKS — accent, typeface,
-- surface — but every form kept the same skeleton: a header, then a single
-- column of fields. An organizer who wanted the photo beside the intro, two
-- paragraphs before the form, or a title laid over a full-bleed image had no
-- way to say so.
--
-- This column holds an ordered list of BLOCKS the organizer arranges freely:
-- a photo (inline or full-bleed with text over it), a heading, a paragraph, a
-- button, a divider, and the form itself. Each block carries its own
-- placement, alignment, colour and typeface.
--
-- It stores a closed schema, never CSS or markup. services/registration_layout.py
-- is the authority: a block's type is one of a fixed list, and every value
-- inside it is an enum key, a validated hex, a bounded line of text, or an
-- https image URL from our own bucket. It rewrites the whole list on every
-- save, dropping anything it does not recognise, so a block a hand-crafted
-- payload invents cannot reach the page. This matters here for the same reason
-- it did in 030: the form is a page open to the world with no login, and a
-- crowd loads it.
--
-- Without this migration nothing breaks, and nothing even changes. Layout is
-- opt-in: registration_layout.fetch treats the missing column as "never
-- configured", the public payload sends an empty list, and the page renders
-- the classic header-then-fields layout exactly as it does today. Only a
-- stored, non-empty layout switches a form into block mode — so no existing
-- form's appearance moves until someone opens the editor and saves.
-- ============================================================================

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS registration_layout JSONB;

COMMENT ON COLUMN events.registration_layout IS
  'How this event''s public registration form is laid out: an ordered list of blocks (image, title, text, form, button, divider), each with placement/alignment/colour/typeface. A closed schema of enum keys, validated hex colours, bounded text and https URLs — never CSS or markup. services/registration_layout.py is the authority; it rewrites the whole list on save and guarantees exactly one form block. NULL (or empty) means "never configured" and renders the classic layout.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
SELECT 'events.registration_layout' AS item,
       CASE WHEN EXISTS (
         SELECT 1 FROM information_schema.columns
         WHERE table_name = 'events' AND column_name = 'registration_layout'
       ) THEN 'OK' ELSE 'MANQUANT' END AS status;
