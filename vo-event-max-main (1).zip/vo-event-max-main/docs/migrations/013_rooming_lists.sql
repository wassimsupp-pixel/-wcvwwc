-- ============================================================================
-- Migration 013 — Generated rooming lists
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Migration 012 gave us rooms. This one gives us a rooming LIST: the document
-- an organizer decides to make, sends to a hotel, and refers to by number for
-- three weeks.
--
-- The difference is not cosmetic. Until now the rooming view was derived on
-- every read, which meant it could renumber itself between two page loads
-- because somebody cancelled on Tuesday. A list that does that cannot be sent
-- to anybody. So a generation is stored, versioned, and never rewritten by a
-- consolidation -- when the data moves on, the stored list is flagged stale and
-- a human decides whether to regenerate.
--
-- Without this migration the rooming screen keeps working exactly as it does
-- today (a live derivation) and the "Generate" action reports itself
-- unavailable.
-- ============================================================================


CREATE TABLE IF NOT EXISTS rooming_lists (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id     UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  version      INTEGER     NOT NULL,
  payload      JSONB       NOT NULL,
  summary      JSONB       NOT NULL DEFAULT '{}'::jsonb,
  fingerprint  TEXT        NOT NULL DEFAULT '',
  note         TEXT,
  generated_by UUID        REFERENCES users(id) ON DELETE SET NULL,
  generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (event_id, version)
);

CREATE INDEX IF NOT EXISTS idx_rooming_lists_event
  ON rooming_lists(event_id, version DESC);

ALTER TABLE rooming_lists ENABLE ROW LEVEL SECURITY;

COMMENT ON TABLE rooming_lists IS
  'One row per generation. Versions are kept rather than overwritten: a hotel holding version 3 must still be answerable when the office is looking at version 5.';
COMMENT ON COLUMN rooming_lists.payload IS
  'The rooms as generated, each carrying origin = hotel | generated. Only numbers we generated may be revisited by a later generation.';
COMMENT ON COLUMN rooming_lists.fingerprint IS
  'Hash of the list this generation produced. Recomputed live on every read; a difference means the underlying data has moved on and the stored list is stale.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
-- Expect one row, columns = 9.
SELECT 'rooming_lists' AS table_name,
       COUNT(*)        AS columns
FROM information_schema.columns
WHERE table_name = 'rooming_lists';
