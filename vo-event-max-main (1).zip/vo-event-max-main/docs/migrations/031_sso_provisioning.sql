-- ============================================================
-- 031 — Safe provisioning for SSO (Microsoft 365 / Entra ID) and password signup
-- ============================================================
--
-- WHY THIS EXISTS
--
-- The original trigger (docs/supabase_trigger.sql) put *every* new account into
-- the first organisation in the table and gave it the `admin` role. That is
-- fine for a single-seat demo. It is a hole the moment a real client's data is
-- in that org and a public "Sign in with Microsoft" button exists: any
-- Microsoft account on earth could click it, be provisioned into the client's
-- org, and land as an administrator of the client's data.
--
-- This migration closes that hole without changing how the legitimate first
-- admin gets in. Two changes, nothing more:
--
--   1. A DOMAIN GATE. `allowed_signup_domains` lists the e-mail domains that may
--      create an account. While it is EMPTY the gate is open (so a fresh
--      deployment can bootstrap and so local dev is unaffected). The client
--      inserts their own domain(s) before go-live, and from then on a signup —
--      by password OR by Microsoft SSO — whose e-mail domain is not listed is
--      refused. The exception rolls back the whole transaction, so no orphaned
--      auth.users row is left behind and Supabase returns a clean error.
--
--   2. ROLE BY BOOTSTRAP, NOT BY DEFAULT. The very first user of an empty
--      instance becomes `admin` so the client can get in and start inviting.
--      Everyone after that is a `viewer`. An administrator promotes people
--      deliberately; nobody is handed admin by the act of logging in.
--
-- Each client runs their own deployment (their own Supabase), so there is one
-- organisation per instance. The risk this addresses is therefore not one
-- client seeing another's data — it is an outsider joining the single org.
--
-- Idempotent: safe to run more than once.

-- ------------------------------------------------------------
-- 1. The allow-list. Empty = open (bootstrap / dev). Populated = enforced.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.allowed_signup_domains (
  domain     TEXT        PRIMARY KEY,
  note       TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE public.allowed_signup_domains IS
  'E-mail domains permitted to create an account. Empty table = no restriction. '
  'The signup trigger refuses any address whose domain is absent once this has rows. '
  'Compared case-insensitively against the part after @. Example row: (''livanova.com'').';

-- Only the service role reaches this table (the trigger runs SECURITY DEFINER,
-- and admins manage it through the API). RLS on + no policy = closed to anon.
ALTER TABLE public.allowed_signup_domains ENABLE ROW LEVEL SECURITY;

-- ------------------------------------------------------------
-- 2. The hardened provisioning function.
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
DECLARE
  default_org_id     UUID;
  default_project_id UUID;
  default_event_id   UUID;
  signup_domain      TEXT;
  domains_configured BOOLEAN;
  existing_users     BIGINT;
  assigned_role      user_role;
BEGIN
  -- --- Domain gate -------------------------------------------------------
  -- Everything after the last @, lower-cased. A malformed address with no
  -- domain yields '' and is refused whenever the gate is active.
  signup_domain := lower(split_part(new.email, '@', 2));
  SELECT EXISTS (SELECT 1 FROM public.allowed_signup_domains) INTO domains_configured;

  IF domains_configured
     AND NOT EXISTS (
       SELECT 1 FROM public.allowed_signup_domains
       WHERE lower(domain) = signup_domain
     )
  THEN
    -- Aborts the signup transaction. GoTrue surfaces this as an auth error;
    -- for the Microsoft flow it comes back as ?error=... on the callback URL.
    RAISE EXCEPTION 'signup_not_allowed: the domain "%" is not permitted on this instance', signup_domain
      USING ERRCODE = 'insufficient_privilege';
  END IF;

  -- --- Organisation (get-or-create; one per instance) --------------------
  SELECT id INTO default_org_id FROM public.organizations LIMIT 1;
  IF default_org_id IS NULL THEN
    INSERT INTO public.organizations (name, slug)
    VALUES ('VO Communication Group', 'vo-group')
    RETURNING id INTO default_org_id;
  END IF;

  -- --- Role: first user of an empty instance bootstraps as admin ---------
  SELECT count(*) INTO existing_users FROM public.users;
  assigned_role := CASE WHEN existing_users = 0 THEN 'admin'::user_role
                        ELSE 'viewer'::user_role END;

  INSERT INTO public.users (id, org_id, email, full_name, role, preferred_language)
  VALUES (
    new.id,
    default_org_id,
    new.email,
    COALESCE(new.raw_user_meta_data->>'full_name',
             new.raw_user_meta_data->>'name',              -- Microsoft sends 'name'
             'Utilisateur'),
    assigned_role,
    COALESCE(new.raw_user_meta_data->>'preferred_language', 'fr')
  );

  -- --- Sandbox project + event, only while bootstrapping the instance ----
  -- Unchanged from the original seed so the frontend's fallback event route
  -- keeps working; runs only when there is no project yet.
  SELECT id INTO default_project_id FROM public.projects WHERE org_id = default_org_id LIMIT 1;
  IF default_project_id IS NULL THEN
    INSERT INTO public.projects (org_id, name, client_name, created_by)
    VALUES (default_org_id, 'LivaNova Meetings', 'LivaNova', new.id)
    RETURNING id INTO default_project_id;

    SELECT id INTO default_event_id FROM public.events WHERE project_id = default_project_id LIMIT 1;
    IF default_event_id IS NULL THEN
      INSERT INTO public.events (id, project_id, name, event_type)
      VALUES ('00000000-0000-0000-0000-000000000003', default_project_id, 'Kick-off Meeting Barcelona', 'meeting')
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;

  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- The trigger itself is unchanged; re-declared so this migration stands alone.
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ------------------------------------------------------------
-- 3. Go-live reminder (kept as a comment, not executed — the domain is the
--    client's to choose):
--
--    INSERT INTO public.allowed_signup_domains (domain, note)
--    VALUES ('client-domain.com', 'Client staff via Microsoft 365');
--
--    Until a row exists here, ANYONE who can reach the login page can create
--    an account. Add the client's domain the moment the first admin is in.
-- ------------------------------------------------------------
