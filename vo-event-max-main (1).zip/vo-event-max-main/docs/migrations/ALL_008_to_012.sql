-- ============================================================================
-- VO Event Max — migrations 008 a 012, regroupees
-- ============================================================================
-- A coller en une fois dans Supabase > SQL Editor > New query > Run.
--
-- Tout est idempotent : relancer ce fichier ne casse rien et ne duplique rien.
-- Chaque bloc reste disponible separement dans docs/migrations/ si tu preferes
-- les passer un par un.
--
--   008  events.field_policy                      champs requis / optionnels / non utilises
--   009  participants.roommate_*, room_type       roommates, extensions, nuitees
--        hotel_nights.night_kind, .source
--   010  events.registration_custom_fields        questions libres + cases contractuelles
--        events.registration_confirmations
--   011  events.transfer_settings                 flotte de vehicules + marge avant vol
--   012  TABLES rooms, participant_notes,         rooming list, notes internes, onglet UPDATES
--        export_snapshots
--        + participants.room_number, hotel_nights.room_id
--
-- Avant : tout le code neuf se met en veille silencieuse et l'app se comporte
-- comme avant. Apres : roommates, nuitees deduites, chambres, notes et UPDATES
-- s'activent a la prochaine consolidation.
-- ============================================================================




-- >>>>>>>>>>>>>>>>>>>>  008_field_policy.sql  <<<<<<<<<<<<<<<<<<<<

-- ============================================================================
-- Migration 008 — Per-event participant field policy
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Answers feedback §10: "si l'événement n'a pas besoin de nationalité, on ne
-- doit pas avoir 150 participants en alerte Nationality missing".
--
-- Shape: {"<field_key>": "required" | "optional" | "not_used", ...}
--
--   required   the event needs it. Blank raises an exception and weighs on the
--              completeness score.
--   optional   stored and displayed, never alerted on, never scored.
--   not_used   this event does not collect it. Invisible to the exception
--              engine and dropped from the score's weighting entirely.
--
-- `not_used` NEVER deletes anything. A value arriving from a source file is
-- still stored and still shown on the fiche — the engine's first promise is
-- that nothing is lost, and a configuration screen must not be able to break
-- it.
--
-- NULL / absent => the defaults in services/field_policy.py, which are exactly
-- the fields the exception engine already alerted on before this migration.
-- Nothing changes until somebody deliberately configures an event, and nothing
-- breaks while this migration is unapplied: field_policy.fetch() treats the
-- missing column as "not configured" and every caller falls back to defaults.
-- ============================================================================

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS field_policy JSONB;

COMMENT ON COLUMN events.field_policy IS
  'Per-event participant field policy: {field_key: "required"|"optional"|"not_used"}. NULL = defaults (see services/field_policy.py). Drives exception detection and the data-quality score, never storage.';


-- >>>>>>>>>>>>>>>>>>>>  009_rooming_and_nights.sql  <<<<<<<<<<<<<<<<<<<<

-- ============================================================================
-- Migration 009 — Roommates, and where each night comes from
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Covers three feedback points that all land on the same two tables:
--
--   §4  Twin/double rooms and roommate matching — two people register
--       separately, each writes the other's name, and the engine had no way to
--       connect them. The hotel received two singles for one twin.
--   §3  Personal extensions — the official programme ends on the 3rd, the
--       participant flies home on the 5th. Two nights the client booked, two
--       the participant pays for, and nothing distinguished them.
--   §2  Nights derived from flight dates, cross-checked against the rooming
--       list when one exists.
--
-- Until this migration runs, all three features degrade to clean no-ops:
-- services/consolidation_service.resolve_roommates and
-- derive_nights_from_flights probe for the columns, log once, and return
-- without writing. Consolidation behaves exactly as it did before.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. Who shares a room with whom
-- ---------------------------------------------------------------------------

-- The name as the file wrote it. Kept alongside the resolved link rather than
-- replaced by it: when the name matches nobody, the raw text is the only clue
-- an organizer has to work out who was meant.
ALTER TABLE participants
  ADD COLUMN IF NOT EXISTS roommate_name TEXT;

-- The resolved link. ON DELETE SET NULL, never CASCADE: deleting one occupant
-- must not delete the other. Self-referencing, and always written on BOTH
-- fiches by services/rooming_service so neither side is the "owner".
ALTER TABLE participants
  ADD COLUMN IF NOT EXISTS roommate_participant_id UUID
  REFERENCES participants(id) ON DELETE SET NULL;

-- The room type the participant asked for, on the fiche rather than only on
-- each night: "this person wants a twin" is a fact about them that exists
-- before any night is booked, and it is what tells the engine a missing
-- roommate is worth an alert.
ALTER TABLE participants
  ADD COLUMN IF NOT EXISTS room_type TEXT;

CREATE INDEX IF NOT EXISTS idx_participants_roommate
  ON participants(roommate_participant_id)
  WHERE roommate_participant_id IS NOT NULL;

COMMENT ON COLUMN participants.roommate_name IS
  'Roommate as named in the source file, before resolution. Free text — a rooming list says "Leslie", not a UUID.';
COMMENT ON COLUMN participants.roommate_participant_id IS
  'Resolved roommate. Always symmetric: if A points at B then B points at A. Two linked fiches are NEVER merged by the deduplication engine (see consolidation_service.roommate_veto).';
COMMENT ON COLUMN participants.room_type IS
  'Requested room type (single / twin / double / suite). A twin with no roommate raises ROOMMATE_MISSING.';

-- ---------------------------------------------------------------------------
-- 2. Who is paying for each night, and where the night came from
-- ---------------------------------------------------------------------------

-- 'program'   covered by the official programme dates
-- 'extension' outside them — the participant's own extension, before or after
--
-- Defaults to 'program' so every night that already exists keeps the meaning
-- it had: an event with no dates set has no extensions, which is the truthful
-- answer rather than a guess.
ALTER TABLE hotel_nights
  ADD COLUMN IF NOT EXISTS night_kind TEXT NOT NULL DEFAULT 'program';

-- 'imported'            read from a rooming list
-- 'derived_from_flights' inferred from the travel dates
--
-- Worth storing because the two carry different authority: an imported night
-- is a fact and is never overwritten, a derived one is an inference. It is
-- also what lets the mismatch check know which side to trust.
ALTER TABLE hotel_nights
  ADD COLUMN IF NOT EXISTS source TEXT NOT NULL DEFAULT 'imported';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'hotel_nights_night_kind_check'
  ) THEN
    ALTER TABLE hotel_nights
      ADD CONSTRAINT hotel_nights_night_kind_check
      CHECK (night_kind IN ('program', 'extension'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'hotel_nights_source_check'
  ) THEN
    ALTER TABLE hotel_nights
      ADD CONSTRAINT hotel_nights_source_check
      CHECK (source IN ('imported', 'derived_from_flights', 'manual'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_hotel_nights_extension
  ON hotel_nights(participant_id)
  WHERE night_kind = 'extension';

COMMENT ON COLUMN hotel_nights.night_kind IS
  'program = inside the event dates, extension = the participant''s own nights (before or after). Set on every run by consolidation_service.derive_nights_from_flights.';
COMMENT ON COLUMN hotel_nights.source IS
  'Where the night came from. An imported night is never overwritten by a derived one — the inference yields to the fact.';


-- >>>>>>>>>>>>>>>>>>>>  010_registration_extras.sql  <<<<<<<<<<<<<<<<<<<<

-- ============================================================================
-- Migration 010 — The questions the catalogue cannot know about
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Feedback §9 asks for a genuinely configurable registration form. Migration
-- 007 made the CATALOGUE configurable — which of the known fields an event
-- shows and insists on. This adds the two things a catalogue structurally
-- cannot provide, both taken from the reference form MAX already runs for
-- Coca-Cola (base.timetoreconnect.eu):
--
--   1. The organizer's own questions. That form asks for a favourite sweet and
--      a favourite song. No catalogue will ever hold those, and that is the
--      point: fifty built-in fields still cannot ask the one question this
--      particular trip needs.
--
--   2. Contractual tick-boxes. That same form carries a cancellation policy
--      with a hard date ("je ne peux pas participer si j'annule après le 15
--      juillet") and a confirmation that the attendee is the right commercial
--      contact. Both are worded per trip and carry real consequences; neither
--      belongs in code.
--
-- Until this migration runs, services/registration_form.fetch_extras() returns
-- empty lists and the form renders exactly the catalogue — what it did before.
-- ============================================================================

-- [{"key": "...", "label": "...", "type": "text|textarea|select|date|boolean",
--   "required": bool, "options": ["..."]}, ...]
--
-- Answers land in source_records.normalized_data under the organizer's own
-- key, exactly like an unrecognised column from an uploaded file. They reach
-- the master list and the exports through the existing catch-all, with no
-- extra plumbing and no risk of being dropped.
ALTER TABLE events
  ADD COLUMN IF NOT EXISTS registration_custom_fields JSONB;

-- [{"key": "...", "label": "...", "text": "the full wording shown"}, ...]
--
-- Every entry is mandatory by construction: an optional tick-box that changes
-- nothing is a question, not a confirmation. Which ones were accepted, and the
-- timestamp, are written onto the submission — an export showing that a
-- cancellation policy was agreed to is worth nothing without the date.
ALTER TABLE events
  ADD COLUMN IF NOT EXISTS registration_confirmations JSONB;

COMMENT ON COLUMN events.registration_custom_fields IS
  'Organizer-defined questions for the public form. Filtered through services/registration_form.resolve_custom on the way out; unknown keys in a submission are dropped, never stored.';
COMMENT ON COLUMN events.registration_confirmations IS
  'Contractual tick-boxes (cancellation policy, role confirmation). All mandatory. Acceptance and its timestamp are recorded on the submission.';


-- >>>>>>>>>>>>>>>>>>>>  011_transfer_dispatch.sql  <<<<<<<<<<<<<<<<<<<<

-- ============================================================================
-- Migration 011 — Per-event transfer fleet and safety margin
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Feedback §1, the point the review called one of the most important: MAX
-- organises ground transport FROM the flights. People on the same plane travel
-- together, people landing close enough in time can share, and the vehicle is
-- chosen from the head count.
--
-- Two numbers make that possible and neither belongs in code, because both
-- change per event and per destination:
--
--   vehicles                 the fleet actually available, with real capacities
--   min_hours_before_flight  how early to leave the hotel for a departure
--                            ("Vol 14h00, 3h de marge -> depart 11h00")
--
-- Shape:
--   {"vehicles": [{"name": "Taxi", "capacity": 3}, ...],
--    "min_hours_before_flight": 3,
--    "grouping_window_minutes": 60}
--
-- NULL / absent => the defaults in services/dispatch_service.py, which are the
-- four vehicles the feedback itself lists (taxi 3, van 7, minibus 18, bus 50)
-- and a three-hour margin. The planner works on an unconfigured event; it just
-- works with those.
--
-- Nothing here stores a PLAN. The proposal endpoint computes and returns one
-- without writing, and only groups the organizer accepts become rows in
-- `transfers` — the tool proposes, the human decides.
-- ============================================================================

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS transfer_settings JSONB;

COMMENT ON COLUMN events.transfer_settings IS
  'Dispatching parameters: available fleet with capacities, minimum hours before a flight, and the arrival grouping window. NULL = defaults (see services/dispatch_service.py). Re-validated on write: a zero-capacity vehicle is replaced, never stored.';


-- >>>>>>>>>>>>>>>>>>>>  012_rooms_notes_snapshots.sql  <<<<<<<<<<<<<<<<<<<<

-- ============================================================================
-- Migration 012 — Rooms, internal notes, and export snapshots
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- The last three structural gaps from the MAX / LivaNova feedback:
--
--   §5  a real rooming list -- a hotel works by ROOM, and hotel_nights is
--       indexed by (participant, night), so "304 = Tina + Leslie" could not
--       be written at all
--   §8  internal notes with a category and a say in whether they leave
--   §7  an UPDATES tab comparing each export to the one before it
--
-- Every feature degrades to a no-op until this runs.
-- ============================================================================


-- ---------------------------------------------------------------------------
-- 1. Rooms (§5)
-- ---------------------------------------------------------------------------
-- Deliberately thin. A room is a number and a type; WHO is in it comes from
-- the roommate link and the nights, which are already the source of truth. A
-- separate occupancy table would be a second truth able to drift out of step
-- with the first, and a rooming list that contradicts itself between two tabs
-- is worse than one that is merely incomplete.

CREATE TABLE IF NOT EXISTS rooms (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id    UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  hotel_id    UUID        REFERENCES hotels(id) ON DELETE CASCADE,
  number      TEXT        NOT NULL,
  room_type   TEXT        NOT NULL DEFAULT 'single',
  notes       TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (hotel_id, number)
);

CREATE INDEX IF NOT EXISTS idx_rooms_event ON rooms(event_id);

ALTER TABLE rooms ENABLE ROW LEVEL SECURITY;

-- The room number on the fiche. Denormalised on purpose: the hotel sends back
-- a spreadsheet of names and numbers long before anybody creates room records,
-- and a participant must be able to carry their number from the moment it is
-- known.
ALTER TABLE participants
  ADD COLUMN IF NOT EXISTS room_number TEXT;

ALTER TABLE hotel_nights
  ADD COLUMN IF NOT EXISTS room_id UUID REFERENCES rooms(id) ON DELETE SET NULL;

COMMENT ON TABLE rooms IS
  'Physical rooms. Occupancy is NOT stored here: it is derived from participants.roommate_participant_id and hotel_nights, so the two views can never contradict each other.';
COMMENT ON COLUMN participants.room_number IS
  'Room number as the hotel gave it, before any room record exists. Two roommates with different numbers raise a room_number_mismatch rather than one silently winning.';


-- ---------------------------------------------------------------------------
-- 2. Internal notes (§8)
-- ---------------------------------------------------------------------------
-- include_in_export defaults to FALSE, and that default is the feature. The
-- failure mode is not "we forgot to share a remark" -- it is a coach company
-- reading "difficult client, handle carefully" about somebody in their van.
--
-- The category is not decoration either: it decides which supplier could ever
-- see the note once flagged. 'general' has no destination and can therefore
-- never be exported, whatever it says.

CREATE TABLE IF NOT EXISTS participant_notes (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id          UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  participant_id    UUID        NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
  category          TEXT        NOT NULL DEFAULT 'general',
  body              TEXT        NOT NULL,
  include_in_export BOOLEAN     NOT NULL DEFAULT FALSE,
  author_id         UUID        REFERENCES users(id) ON DELETE SET NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT participant_notes_category_check
    CHECK (category IN ('general', 'accommodation', 'flight', 'transfer', 'activity'))
);

CREATE INDEX IF NOT EXISTS idx_participant_notes_participant
  ON participant_notes(participant_id);
CREATE INDEX IF NOT EXISTS idx_participant_notes_exportable
  ON participant_notes(event_id, category)
  WHERE include_in_export = TRUE;

ALTER TABLE participant_notes ENABLE ROW LEVEL SECURITY;

COMMENT ON TABLE participant_notes IS
  'Operational remarks. include_in_export defaults to FALSE and is only honoured for a category that has a supplier destination -- see services/note_service.EXPORTABLE_TO.';


-- ---------------------------------------------------------------------------
-- 3. Export snapshots (§7)
-- ---------------------------------------------------------------------------
-- What each export said, so the next one can say what changed. Compared
-- against a STORED snapshot rather than against two files somebody happens to
-- still have -- and keyed by participant id, because names change and keying
-- on a name reports one person as another leaving and a stranger arriving.

CREATE TABLE IF NOT EXISTS export_snapshots (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id    UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  export_id   UUID        REFERENCES exports(id) ON DELETE SET NULL,
  payload     JSONB       NOT NULL,
  created_by  UUID        REFERENCES users(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_export_snapshots_event
  ON export_snapshots(event_id, created_at DESC);

ALTER TABLE export_snapshots ENABLE ROW LEVEL SECURITY;

COMMENT ON TABLE export_snapshots IS
  'One row per export: the tracked fields as that file stated them. The next export diffs against the most recent one to build its UPDATES sheet.';
