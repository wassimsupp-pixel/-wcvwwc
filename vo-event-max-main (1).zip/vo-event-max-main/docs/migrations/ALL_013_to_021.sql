-- ============================================================================
-- Migrations 013 → 021, in one paste
-- ============================================================================
-- Copy this whole file into the Supabase SQL editor and run it once. It is
-- idempotent: running it twice changes nothing, and running it on a database
-- that already has some of these columns is safe.
--
--   013  rooming_lists          a rooming list somebody GENERATES (§5)
--   014  communications columns Request Missing Information (§14)
--   015  change_log columns     where a change came from (§19)
--   016  events.organiser_contact  the PDF's contact block (§16)
--   017  uploaded_files columns    Add/Update vs Replace Source (§20)
--   018  event_site_sections     the registration link as a mini site (§11)
--   019  chat_conversations      the assistant remembers the conversation
--   020  user_role values        the access ladder (§21)  ⚠️ run on its own
--   021  registration_attachments  passport copies and photos (§9)
--
-- ⚠️ Migration 020 is NOT in this file. ALTER TYPE ... ADD VALUE cannot run
-- inside a transaction block on older PostgreSQL, so it has to be pasted on its
-- own — see docs/migrations/020_access_ladder.sql.
--
-- Every feature above already degrades to a clean no-op without its migration,
-- so nothing is broken until you run this — the screens simply say what is
-- missing. Run it when convenient, not urgently.
-- ============================================================================


-- ---------------------------------------------------------------------------
-- 013 — Generated rooming lists (§5)
-- ---------------------------------------------------------------------------
-- The rooming view used to be derived on every read, which meant it could
-- renumber itself between two page loads because somebody cancelled on
-- Tuesday. A document you send to a hotel cannot do that. Generations are
-- stored and versioned; a consolidation never rewrites one.

CREATE TABLE IF NOT EXISTS rooming_lists (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id     UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  version      INTEGER     NOT NULL,
  payload      JSONB       NOT NULL,
  summary      JSONB       NOT NULL DEFAULT '{}'::jsonb,
  fingerprint  TEXT        NOT NULL DEFAULT '',
  note         TEXT,
  generated_by UUID        REFERENCES users(id) ON DELETE SET NULL,
  generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (event_id, version)
);

CREATE INDEX IF NOT EXISTS idx_rooming_lists_event
  ON rooming_lists(event_id, version DESC);

ALTER TABLE rooming_lists ENABLE ROW LEVEL SECURITY;

COMMENT ON TABLE rooming_lists IS
  'One row per generation. Versions are kept rather than overwritten: a hotel holding version 3 must still be answerable when the office is looking at version 5.';


-- ---------------------------------------------------------------------------
-- 014 — Request Missing Information (§14)
-- ---------------------------------------------------------------------------
-- An information request IS a communication, so it lives on the table that
-- already tracks every outbound message. These two columns record WHAT was
-- asked, so the reply can be matched against the question.

ALTER TABLE communications
  ADD COLUMN IF NOT EXISTS context_data JSONB NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE communications
  ADD COLUMN IF NOT EXISTS language TEXT;

CREATE INDEX IF NOT EXISTS idx_communications_type
  ON communications(event_id, type, status);

COMMENT ON COLUMN communications.context_data IS
  'For type = information_request: the fields asked for, with the reason, plus the exception ids that prompted them.';
COMMENT ON COLUMN communications.language IS
  'ISO 639-1 code the message was composed in. Stored, not derived: a sent email does not change language when the participant does.';


-- ---------------------------------------------------------------------------
-- 015 — Where a change came from (§19)
-- ---------------------------------------------------------------------------
-- change_log has recorded who / when / which field / from what / to what since
-- the beginning. The column that was missing is the one that ends an argument.
--
-- NOT back-filled on purpose: rows written before this have their origin
-- reconstructed from the reason code and are labelled as reconstructed.
-- Stamping a confident guess onto historical audit rows would make the log less
-- trustworthy, not more.

ALTER TABLE change_log
  ADD COLUMN IF NOT EXISTS source TEXT;

ALTER TABLE change_log
  ADD COLUMN IF NOT EXISTS source_file_id UUID REFERENCES uploaded_files(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_change_log_event_time
  ON change_log(event_id, changed_at DESC);
CREATE INDEX IF NOT EXISTS idx_change_log_entity_time
  ON change_log(entity_id, changed_at DESC);
CREATE INDEX IF NOT EXISTS idx_change_log_source
  ON change_log(event_id, source);

COMMENT ON COLUMN change_log.source IS
  'Where the new value came from: fcm_upload | registration_form | hotel_file | transfer_file | manual_update | participant_email | ai_suggestion | system. NULL on rows written before migration 015.';


-- ---------------------------------------------------------------------------
-- 016 — The organiser contact block (§16)
-- ---------------------------------------------------------------------------
-- The last line of §16's list for the participant PDF, and the one fact
-- nobody had a place to write down. Free text because whose number goes on the
-- document changes per event.

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS organiser_contact TEXT;

COMMENT ON COLUMN events.organiser_contact IS
  'Free-text contact block printed at the bottom of the participant confirmation PDF. Empty means the PDF omits the block entirely.';


-- ---------------------------------------------------------------------------
-- 017 — Add/Update Source vs Replace Source (§20)
-- ---------------------------------------------------------------------------
-- Every upload is additive today, which is right for FCM Week 1 → Week 2.
-- These columns express the OTHER intention: a corrected version of a file
-- already imported. Superseding is reversible and never deletes a participant.

ALTER TABLE uploaded_files
  ADD COLUMN IF NOT EXISTS superseded_at TIMESTAMPTZ;

ALTER TABLE uploaded_files
  ADD COLUMN IF NOT EXISTS superseded_by UUID REFERENCES uploaded_files(id) ON DELETE SET NULL;

ALTER TABLE uploaded_files
  ADD COLUMN IF NOT EXISTS superseded_reason TEXT;

CREATE INDEX IF NOT EXISTS idx_uploaded_files_live
  ON uploaded_files(event_id, source_type)
  WHERE superseded_at IS NULL;

COMMENT ON COLUMN uploaded_files.superseded_at IS
  'Set when a later file replaces this one. A superseded file is skipped by consolidation but its source_records are kept.';


-- ---------------------------------------------------------------------------
-- 018 — The registration link becomes a small event site (§11)
-- ---------------------------------------------------------------------------
-- No CMS: seven known section kinds, three languages, plain text. Tags are
-- stripped before storage — this is rendered on a page open to the world with
-- no login, and markup would make an organizer account an XSS vector.

CREATE TABLE IF NOT EXISTS event_site_sections (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id   UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  slug       TEXT        NOT NULL,
  position   INTEGER     NOT NULL DEFAULT 0,
  title      JSONB       NOT NULL DEFAULT '{}'::jsonb,
  body       JSONB       NOT NULL DEFAULT '{}'::jsonb,
  image_url  TEXT,
  visible    BOOLEAN     NOT NULL DEFAULT TRUE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (event_id, slug)
);

CREATE INDEX IF NOT EXISTS idx_event_site_sections_event
  ON event_site_sections(event_id, position);

ALTER TABLE event_site_sections ENABLE ROW LEVEL SECURITY;

COMMENT ON TABLE event_site_sections IS
  'The mini event site shown above the public registration form (feedback §11).';


-- ---------------------------------------------------------------------------
-- 019 — The assistant remembers the conversation
-- ---------------------------------------------------------------------------
-- A conversation belongs to a USER, not just to an event: two organizers on the
-- same event do not read each other's threads. Only the assistant's PROSE is
-- stored, never the rows it returned — those are participant data, and a
-- transcript holding them would be a second, unmanaged copy of the master list.

CREATE TABLE IF NOT EXISTS chat_conversations (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id   UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id    UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title      TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chat_conversations_owner
  ON chat_conversations(event_id, user_id, updated_at DESC);

CREATE TABLE IF NOT EXISTS chat_messages (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID        NOT NULL REFERENCES chat_conversations(id) ON DELETE CASCADE,
  role            TEXT        NOT NULL,
  content         TEXT        NOT NULL,
  intent          TEXT,
  answered        BOOLEAN,
  row_count       INTEGER     NOT NULL DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chat_messages_role_check CHECK (role IN ('user', 'assistant'))
);

CREATE INDEX IF NOT EXISTS idx_chat_messages_conversation
  ON chat_messages(conversation_id, created_at);

ALTER TABLE chat_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages      ENABLE ROW LEVEL SECURITY;


-- ---------------------------------------------------------------------------
-- 021 — Passport copies and photos from the registration form (§9)
-- ---------------------------------------------------------------------------
-- The visitor's filename is stored as a LABEL, never as a path; the storage key
-- is generated server-side. content_type is what we DETECTED from the bytes,
-- not what the browser claimed — that header is attacker-controlled and decides
-- how anything downstream renders the file.

CREATE TABLE IF NOT EXISTS registration_attachments (
  id             UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id       UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  kind           TEXT        NOT NULL,
  storage_path   TEXT        NOT NULL,
  original_name  TEXT,
  content_type   TEXT,
  byte_size      INTEGER     NOT NULL DEFAULT 0,
  participant_id UUID        REFERENCES participants(id) ON DELETE SET NULL,
  claimed_at     TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_registration_attachments_event
  ON registration_attachments(event_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_registration_attachments_participant
  ON registration_attachments(participant_id);
CREATE INDEX IF NOT EXISTS idx_registration_attachments_orphans
  ON registration_attachments(event_id, created_at)
  WHERE claimed_at IS NULL;

ALTER TABLE registration_attachments ENABLE ROW LEVEL SECURITY;


-- ============================================================================
-- Verification — expect exactly 10 rows, all saying OK
-- ============================================================================
SELECT 'rooming_lists (013)'          AS item,
       CASE WHEN to_regclass('public.rooming_lists') IS NOT NULL
            THEN 'OK' ELSE 'MANQUANT' END AS status
UNION ALL
SELECT 'communications.context_data (014)',
       CASE WHEN EXISTS (SELECT 1 FROM information_schema.columns
                         WHERE table_name='communications' AND column_name='context_data')
            THEN 'OK' ELSE 'MANQUANT' END
UNION ALL
SELECT 'communications.language (014)',
       CASE WHEN EXISTS (SELECT 1 FROM information_schema.columns
                         WHERE table_name='communications' AND column_name='language')
            THEN 'OK' ELSE 'MANQUANT' END
UNION ALL
SELECT 'change_log.source (015)',
       CASE WHEN EXISTS (SELECT 1 FROM information_schema.columns
                         WHERE table_name='change_log' AND column_name='source')
            THEN 'OK' ELSE 'MANQUANT' END
UNION ALL
SELECT 'change_log.source_file_id (015)',
       CASE WHEN EXISTS (SELECT 1 FROM information_schema.columns
                         WHERE table_name='change_log' AND column_name='source_file_id')
            THEN 'OK' ELSE 'MANQUANT' END
UNION ALL
SELECT 'events.organiser_contact (016)',
       CASE WHEN EXISTS (SELECT 1 FROM information_schema.columns
                         WHERE table_name='events' AND column_name='organiser_contact')
            THEN 'OK' ELSE 'MANQUANT' END
UNION ALL
SELECT 'uploaded_files.superseded_at (017)',
       CASE WHEN EXISTS (SELECT 1 FROM information_schema.columns
                         WHERE table_name='uploaded_files' AND column_name='superseded_at')
            THEN 'OK' ELSE 'MANQUANT' END
UNION ALL
SELECT 'event_site_sections (018)',
       CASE WHEN to_regclass('public.event_site_sections') IS NOT NULL
            THEN 'OK' ELSE 'MANQUANT' END
UNION ALL
SELECT 'chat_conversations (019)',
       CASE WHEN to_regclass('public.chat_conversations') IS NOT NULL
            THEN 'OK' ELSE 'MANQUANT' END
UNION ALL
SELECT 'registration_attachments (021)',
       CASE WHEN to_regclass('public.registration_attachments') IS NOT NULL
            THEN 'OK' ELSE 'MANQUANT' END;
