-- ============================================================================
-- Migration 020 — The access ladder (feedback §21)
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- §21 names five levels and wraps one instruction around them: "dans un premier
-- temps, on peut probablement garder la majorité de l'équipe en Administrateur.
-- Mais l'architecture doit déjà permettre plusieurs niveaux."
--
-- So this adds the levels without moving anybody. Existing users keep the role
-- they have and the access that comes with it; the new values sit unused until
-- somebody is deliberately assigned one.
--
--   project_user   only the projects they are invited to
--   freelancer     one specific project, usually a few named events inside it
--   participant    no access to the internal app at all — their registration
--                  link and their mini event site, and nothing else
--
-- ⚠️ ALTER TYPE ... ADD VALUE cannot run inside a transaction block on older
-- PostgreSQL. Run this file on its own, not pasted after other statements.
--
-- Without this migration everything behaves exactly as today: services/roles
-- resolves an unknown role to `viewer`, which is the least privileged level,
-- so a half-applied migration fails closed rather than open.
-- ============================================================================

ALTER TYPE user_role ADD VALUE IF NOT EXISTS 'project_user';
ALTER TYPE user_role ADD VALUE IF NOT EXISTS 'freelancer';
ALTER TYPE user_role ADD VALUE IF NOT EXISTS 'participant';

COMMENT ON COLUMN users.role IS
  'Access level (feedback §21): admin | pm (both org-wide) | project_user | freelancer | viewer (all three scoped by project_members) | client | participant (no operational access). services/roles is the authority on what each may do.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
-- Expect seven rows.
SELECT enumlabel AS role
FROM pg_enum
WHERE enumtypid = 'user_role'::regtype
ORDER BY enumsortorder;
