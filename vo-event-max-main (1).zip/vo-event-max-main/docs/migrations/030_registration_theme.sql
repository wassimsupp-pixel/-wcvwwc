-- ============================================================================
-- Migration 030 — The public form can look like the client it is for
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Migration 007 made the form ask different questions per event, and 026 gave
-- each event its own logo. The page itself never changed: same accent, same
-- typeface, same centred wordmark on a white card, whoever the event was for.
-- An organizer sending a link to three hundred people on behalf of a client
-- had no way to make the page look like that client.
--
-- This column holds the appearance choices — typeface, accent colour, surface,
-- corner style, and what the visitor sees first (a large title, a photo, or
-- the title laid over the photo).
--
-- It stores KEYS, never CSS. services/registration_theme.py is the authority
-- on which keys exist, and it rewrites the whole object on every save, so a
-- value that is not in one of its tuples cannot reach the page. That matters
-- more here than in most columns: this drives a page open to the world with
-- no login, and a free-text style field would make every organizer account a
-- stored-XSS vector against every participant.
--
-- Without this migration nothing breaks. registration_theme.fetch treats the
-- missing column as "never configured" and every form renders exactly as it
-- does today; the editor's controls simply have nowhere to save to.
-- ============================================================================

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS registration_theme JSONB;

COMMENT ON COLUMN events.registration_theme IS
  'How this event''s public registration form looks: {font, accent, surface, corners, header{style,image_url,title,subtitle,align,height}}. Closed sets of keys plus one validated hex colour — never CSS. services/registration_theme.py is the authority; it rewrites the whole object on save. NULL means "never configured" and renders the default page.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
SELECT 'events.registration_theme' AS item,
       CASE WHEN EXISTS (
         SELECT 1 FROM information_schema.columns
         WHERE table_name = 'events' AND column_name = 'registration_theme'
       ) THEN 'OK' ELSE 'MANQUANT' END AS status;
