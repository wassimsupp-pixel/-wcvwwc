-- ============================================================================
-- Migration 010 — The questions the catalogue cannot know about
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Feedback §9 asks for a genuinely configurable registration form. Migration
-- 007 made the CATALOGUE configurable — which of the known fields an event
-- shows and insists on. This adds the two things a catalogue structurally
-- cannot provide, both taken from the reference form MAX already runs for
-- Coca-Cola (base.timetoreconnect.eu):
--
--   1. The organizer's own questions. That form asks for a favourite sweet and
--      a favourite song. No catalogue will ever hold those, and that is the
--      point: fifty built-in fields still cannot ask the one question this
--      particular trip needs.
--
--   2. Contractual tick-boxes. That same form carries a cancellation policy
--      with a hard date ("je ne peux pas participer si j'annule après le 15
--      juillet") and a confirmation that the attendee is the right commercial
--      contact. Both are worded per trip and carry real consequences; neither
--      belongs in code.
--
-- Until this migration runs, services/registration_form.fetch_extras() returns
-- empty lists and the form renders exactly the catalogue — what it did before.
-- ============================================================================

-- [{"key": "...", "label": "...", "type": "text|textarea|select|date|boolean",
--   "required": bool, "options": ["..."]}, ...]
--
-- Answers land in source_records.normalized_data under the organizer's own
-- key, exactly like an unrecognised column from an uploaded file. They reach
-- the master list and the exports through the existing catch-all, with no
-- extra plumbing and no risk of being dropped.
ALTER TABLE events
  ADD COLUMN IF NOT EXISTS registration_custom_fields JSONB;

-- [{"key": "...", "label": "...", "text": "the full wording shown"}, ...]
--
-- Every entry is mandatory by construction: an optional tick-box that changes
-- nothing is a question, not a confirmation. Which ones were accepted, and the
-- timestamp, are written onto the submission — an export showing that a
-- cancellation policy was agreed to is worth nothing without the date.
ALTER TABLE events
  ADD COLUMN IF NOT EXISTS registration_confirmations JSONB;

COMMENT ON COLUMN events.registration_custom_fields IS
  'Organizer-defined questions for the public form. Filtered through services/registration_form.resolve_custom on the way out; unknown keys in a submission are dropped, never stored.';
COMMENT ON COLUMN events.registration_confirmations IS
  'Contractual tick-boxes (cancellation policy, role confirmation). All mandatory. Acceptance and its timestamp are recorded on the submission.';
