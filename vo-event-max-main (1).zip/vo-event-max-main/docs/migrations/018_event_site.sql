-- ============================================================================
-- Migration 018 — The registration link becomes a small event site (§11)
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- The question asked during the presentation was whether the link sent to a
-- participant could carry more than a form. §11 answers yes, and is explicit
-- that no CMS is needed: a title, a text, an image, a few sections.
--
-- So: one thin table, seven known section kinds, and three languages — because
-- §12 already established that a Dutch participant gets a Dutch form, and a
-- French welcome page above a Dutch form would undo that.
--
-- Text is stored as TEXT and rendered as TEXT. The body is written by an
-- organizer and shown on a page open to the world with no login; accepting
-- markup would make every organizer account a stored-XSS vector against every
-- participant. services/event_site strips tags before storing.
--
-- Without this migration the registration link shows the form alone, exactly as
-- it does today.
-- ============================================================================

CREATE TABLE IF NOT EXISTS event_site_sections (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id   UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  -- welcome | information | programme | practical | accommodation |
  -- destination | conditions — see services/event_site.SECTIONS
  slug       TEXT        NOT NULL,
  position   INTEGER     NOT NULL DEFAULT 0,
  -- {"fr": "...", "nl": "...", "en": "..."} — a missing language falls back
  -- rather than rendering an empty section.
  title      JSONB       NOT NULL DEFAULT '{}'::jsonb,
  body       JSONB       NOT NULL DEFAULT '{}'::jsonb,
  image_url  TEXT,
  visible    BOOLEAN     NOT NULL DEFAULT TRUE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (event_id, slug)
);

CREATE INDEX IF NOT EXISTS idx_event_site_sections_event
  ON event_site_sections(event_id, position);

ALTER TABLE event_site_sections ENABLE ROW LEVEL SECURITY;

COMMENT ON TABLE event_site_sections IS
  'The mini event site shown above the public registration form (feedback §11). One row per section kind per event; UNIQUE(event_id, slug) means a section is edited, never duplicated.';
COMMENT ON COLUMN event_site_sections.body IS
  'Plain text per language. Tags are stripped before storage — this is rendered on a page open to the world, and markup would make an organizer account an XSS vector.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
-- Expect one row, columns = 9.
SELECT 'event_site_sections' AS table_name,
       COUNT(*)              AS columns
FROM information_schema.columns
WHERE table_name = 'event_site_sections';
