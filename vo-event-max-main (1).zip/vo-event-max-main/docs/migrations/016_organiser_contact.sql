-- ============================================================================
-- Migration 016 — The organiser's contact block (feedback §16)
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- §16 lists what the participant PDF must carry, and the last line of that list
-- is "Contact organisation". Everything else on it is already consolidated
-- somewhere; this is the one fact nobody had a place to write down.
--
-- Free text rather than three columns (name / email / phone) on purpose: whose
-- number goes on the document changes per event -- sometimes the project
-- manager, sometimes a 24/7 line, sometimes the client's own travel desk -- and
-- a rigid shape would be worked around by putting everything in the "name"
-- field anyway.
--
-- Without this migration the PDF simply has no contact block. Everything else
-- on it is unaffected.
-- ============================================================================

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS organiser_contact TEXT;

COMMENT ON COLUMN events.organiser_contact IS
  'Free-text contact block printed at the bottom of the participant confirmation PDF (feedback §16). One line per line; empty means the PDF omits the block entirely.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
-- Expect one row.
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_name = 'events' AND column_name = 'organiser_contact';
