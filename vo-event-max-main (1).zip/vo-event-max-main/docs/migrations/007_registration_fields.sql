-- 007 — Per-event configuration of the public registration form.
--
-- Which questions the form asks, and which answers are mandatory, so an
-- organizer can adapt it to the event instead of sending everyone the same
-- twenty fields (passport number for a one-day city conference, and so on).
--
-- Shape: {"<field_key>": {"enabled": bool, "required": bool}, ...}
-- NULL / absent  => every field shown, nothing extra required, i.e. exactly
-- how the form behaved before this migration. Nothing breaks while it is
-- unapplied: services/registration_form.fetch() treats the missing column as
-- "not configured" and the form falls back to its defaults.
--
-- Safe to run more than once.

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS registration_fields JSONB;

COMMENT ON COLUMN events.registration_fields IS
  'Public registration form configuration: {field_key: {enabled, required}}. NULL = all fields shown, only identity required.';
