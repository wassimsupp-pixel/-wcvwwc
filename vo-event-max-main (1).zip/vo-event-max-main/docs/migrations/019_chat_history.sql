-- ============================================================================
-- Migration 019 — The assistant remembers the conversation
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- The assistant already accepted a history, but the BROWSER carried it: close
-- the tab and the thread was gone. Somebody who asked four questions on Monday
-- to narrow down a problem came back on Tuesday to an empty box.
--
-- Two things worth knowing about the shape below.
--
-- A conversation belongs to a USER, not just to an event. Two organizers on the
-- same event do not read each other's threads: what somebody asks reveals what
-- they are worried about, and that is not team-wide information by default.
--
-- Only the assistant's PROSE is stored, never the rows it returned. Those rows
-- are real participant data — names, dietary requirements — and keeping them
-- would make every conversation a second, unmanaged copy of the master list.
-- row_count is kept instead, so a transcript can say "42 participants" without
-- holding the forty-two names. Both tables cascade from the event, so deleting
-- an event takes its conversations with it (§23).
--
-- Without this migration the assistant answers exactly as it does today; the
-- thread simply lives in the browser and dies with the tab.
-- ============================================================================

CREATE TABLE IF NOT EXISTS chat_conversations (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id   UUID        NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id    UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title      TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- The list is read as "my conversations on this event, most recent first".
CREATE INDEX IF NOT EXISTS idx_chat_conversations_owner
  ON chat_conversations(event_id, user_id, updated_at DESC);

CREATE TABLE IF NOT EXISTS chat_messages (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID        NOT NULL REFERENCES chat_conversations(id) ON DELETE CASCADE,
  role            TEXT        NOT NULL,
  content         TEXT        NOT NULL,
  -- Which rule answered, whether it could, and how many rows it returned.
  -- Diagnostic rather than decorative: a thread full of `answered = false` is
  -- somebody repeatedly asking something the data cannot support.
  intent          TEXT,
  answered        BOOLEAN,
  row_count       INTEGER     NOT NULL DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chat_messages_role_check CHECK (role IN ('user', 'assistant'))
);

CREATE INDEX IF NOT EXISTS idx_chat_messages_conversation
  ON chat_messages(conversation_id, created_at);

ALTER TABLE chat_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages      ENABLE ROW LEVEL SECURITY;

COMMENT ON TABLE chat_conversations IS
  'One assistant thread, owned by the user who had it. Scoped by event AND user on every read: an id alone must never be enough to open somebody else''s conversation.';
COMMENT ON COLUMN chat_messages.content IS
  'The assistant''s prose only. The rows it returned are NOT stored — they are participant data, and a transcript holding them would be an unmanaged second copy of the master list.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
-- Expect two rows saying OK.
SELECT 'chat_conversations' AS item,
       CASE WHEN to_regclass('public.chat_conversations') IS NOT NULL
            THEN 'OK' ELSE 'MANQUANT' END AS status
UNION ALL
SELECT 'chat_messages',
       CASE WHEN to_regclass('public.chat_messages') IS NOT NULL
            THEN 'OK' ELSE 'MANQUANT' END;
