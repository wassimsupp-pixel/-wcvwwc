-- ============================================================================
-- Migration 009 — Roommates, and where each night comes from
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Covers three feedback points that all land on the same two tables:
--
--   §4  Twin/double rooms and roommate matching — two people register
--       separately, each writes the other's name, and the engine had no way to
--       connect them. The hotel received two singles for one twin.
--   §3  Personal extensions — the official programme ends on the 3rd, the
--       participant flies home on the 5th. Two nights the client booked, two
--       the participant pays for, and nothing distinguished them.
--   §2  Nights derived from flight dates, cross-checked against the rooming
--       list when one exists.
--
-- Until this migration runs, all three features degrade to clean no-ops:
-- services/consolidation_service.resolve_roommates and
-- derive_nights_from_flights probe for the columns, log once, and return
-- without writing. Consolidation behaves exactly as it did before.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. Who shares a room with whom
-- ---------------------------------------------------------------------------

-- The name as the file wrote it. Kept alongside the resolved link rather than
-- replaced by it: when the name matches nobody, the raw text is the only clue
-- an organizer has to work out who was meant.
ALTER TABLE participants
  ADD COLUMN IF NOT EXISTS roommate_name TEXT;

-- The resolved link. ON DELETE SET NULL, never CASCADE: deleting one occupant
-- must not delete the other. Self-referencing, and always written on BOTH
-- fiches by services/rooming_service so neither side is the "owner".
ALTER TABLE participants
  ADD COLUMN IF NOT EXISTS roommate_participant_id UUID
  REFERENCES participants(id) ON DELETE SET NULL;

-- The room type the participant asked for, on the fiche rather than only on
-- each night: "this person wants a twin" is a fact about them that exists
-- before any night is booked, and it is what tells the engine a missing
-- roommate is worth an alert.
ALTER TABLE participants
  ADD COLUMN IF NOT EXISTS room_type TEXT;

CREATE INDEX IF NOT EXISTS idx_participants_roommate
  ON participants(roommate_participant_id)
  WHERE roommate_participant_id IS NOT NULL;

COMMENT ON COLUMN participants.roommate_name IS
  'Roommate as named in the source file, before resolution. Free text — a rooming list says "Leslie", not a UUID.';
COMMENT ON COLUMN participants.roommate_participant_id IS
  'Resolved roommate. Always symmetric: if A points at B then B points at A. Two linked fiches are NEVER merged by the deduplication engine (see consolidation_service.roommate_veto).';
COMMENT ON COLUMN participants.room_type IS
  'Requested room type (single / twin / double / suite). A twin with no roommate raises ROOMMATE_MISSING.';

-- ---------------------------------------------------------------------------
-- 2. Who is paying for each night, and where the night came from
-- ---------------------------------------------------------------------------

-- 'program'   covered by the official programme dates
-- 'extension' outside them — the participant's own extension, before or after
--
-- Defaults to 'program' so every night that already exists keeps the meaning
-- it had: an event with no dates set has no extensions, which is the truthful
-- answer rather than a guess.
ALTER TABLE hotel_nights
  ADD COLUMN IF NOT EXISTS night_kind TEXT NOT NULL DEFAULT 'program';

-- 'imported'            read from a rooming list
-- 'derived_from_flights' inferred from the travel dates
--
-- Worth storing because the two carry different authority: an imported night
-- is a fact and is never overwritten, a derived one is an inference. It is
-- also what lets the mismatch check know which side to trust.
ALTER TABLE hotel_nights
  ADD COLUMN IF NOT EXISTS source TEXT NOT NULL DEFAULT 'imported';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'hotel_nights_night_kind_check'
  ) THEN
    ALTER TABLE hotel_nights
      ADD CONSTRAINT hotel_nights_night_kind_check
      CHECK (night_kind IN ('program', 'extension'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'hotel_nights_source_check'
  ) THEN
    ALTER TABLE hotel_nights
      ADD CONSTRAINT hotel_nights_source_check
      CHECK (source IN ('imported', 'derived_from_flights', 'manual'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_hotel_nights_extension
  ON hotel_nights(participant_id)
  WHERE night_kind = 'extension';

COMMENT ON COLUMN hotel_nights.night_kind IS
  'program = inside the event dates, extension = the participant''s own nights (before or after). Set on every run by consolidation_service.derive_nights_from_flights.';
COMMENT ON COLUMN hotel_nights.source IS
  'Where the night came from. An imported night is never overwritten by a derived one — the inference yields to the fact.';
