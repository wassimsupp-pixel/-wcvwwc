-- ============================================================================
-- Migration 014 — Request Missing Information (feedback §14)
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- The exception engine already notices that Sophie's dietary requirements say
-- "YES" and nothing else, and the email agent already reads her reply and
-- proposes "Vegetarian" for a human to validate. The half that was missing is
-- the outbound one: composing the question and remembering that it was asked.
--
-- Two columns on the table that already tracks every outbound message. No new
-- table: an information request IS a communication, and giving it its own
-- storage would mean two places to look for "what have we sent this person".
--
-- Without this migration the feature still composes and previews requests; it
-- just cannot record WHICH fields were asked, so the drafts are stored as
-- ordinary communications and the exceptions are not linked back.
-- ============================================================================


-- What was asked, and what prompted it.
--   {"fields": [{"key": "dietary_requirements", "reason": "uninformative"}],
--    "exception_ids": ["..."]}
--
-- Keyed by field rather than free text so a reply can be matched against the
-- question: the email agent proposes an update, and knowing we asked exactly
-- this person exactly this field is what makes accepting it safe.
ALTER TABLE communications
  ADD COLUMN IF NOT EXISTS context_data JSONB NOT NULL DEFAULT '{}'::jsonb;

-- The language the message was written in. Stored rather than re-derived: the
-- participant's preference can change after the fact, and a sent email does not
-- retroactively become Dutch.
ALTER TABLE communications
  ADD COLUMN IF NOT EXISTS language TEXT;

CREATE INDEX IF NOT EXISTS idx_communications_type
  ON communications(event_id, type, status);

COMMENT ON COLUMN communications.context_data IS
  'For type = information_request: the fields asked for, with the reason, plus the exception ids that prompted them. Lets a reply be matched to a question.';
COMMENT ON COLUMN communications.language IS
  'ISO 639-1 code the message was composed in (fr | nl | en). Stored, not derived: a sent email does not change language when the participant does.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
-- Expect two rows.
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_name = 'communications'
  AND column_name IN ('context_data', 'language')
ORDER BY column_name;
