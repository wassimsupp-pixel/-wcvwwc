-- ============================================================================
-- Migration 023 — Rooming list numbering presets, staff-managed (point 4)
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- Generating a rooming list already took a starting number and a prefix per
-- call ("start at 301, prefix B-") — nothing new there. What was missing was
-- memory: every single generation meant retyping the same two values, because
-- nothing remembered them between visits to the page.
--
-- A preset is nothing the planner does not already accept; it is that pair,
-- named and saved, so a collaborator picks "Hôtel B — étage 3" from a list
-- instead of remembering it wrote 301/B- last time. Stored on the EVENT, not
-- globally: the numbering a hotel wants is a property of that event's
-- contract with that hotel, not a house style to carry into the next one.
--
-- Without this migration the rooming list generator works exactly as today —
-- start_number and prefix are still typed per generation — the presets panel
-- simply has nothing to show or save.
-- ============================================================================

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS rooming_presets JSONB NOT NULL DEFAULT '[]'::jsonb;

COMMENT ON COLUMN events.rooming_presets IS
  'Saved numbering conventions for this event''s rooming list (point 4): [{id, name, start_number, prefix}, ...]. Managed entirely by the team from the rooming page — services/rooming_plan.resolve_presets is the authority on what a valid entry looks like.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
SELECT 'events.rooming_presets' AS item,
       CASE WHEN EXISTS (
         SELECT 1 FROM information_schema.columns
         WHERE table_name = 'events' AND column_name = 'rooming_presets'
       ) THEN 'OK' ELSE 'MANQUANT' END AS status;
