-- ============================================================================
-- Migration 029 — Where the photo sits inside a mini-site section
-- ============================================================================
-- Copy this whole file into the Supabase SQL editor and run it once. It is
-- idempotent: running it twice changes nothing.
--
-- Everything before this (004, 022, 023, 024, 026, 027, 028) is applied and
-- verified. This is the only one left.
--
-- Point 13 asked to arrange "la place de la photo et des textes à ma guise".
-- Section ORDER needed no migration (the `position` column already existed and
-- was simply hardcoded to the catalogue's order in code). This is the other
-- half: whether a section's photo appears above its text or below it.
--
-- Without this migration nothing breaks — verified against the 5 sections
-- currently stored in production: the editor's control saves without the
-- field, and every photo keeps rendering above its text as it does today.
--
-- ⚠️ Still NOT included, deliberately: migration 003 (project_members). It is
-- already applied, but note the standing rule it created: any account that is
-- not admin/pm now needs an explicit project_members row or it sees 404 on
-- every event.
-- ============================================================================

ALTER TABLE event_site_sections
  ADD COLUMN IF NOT EXISTS image_position TEXT NOT NULL DEFAULT 'above';

COMMENT ON COLUMN event_site_sections.image_position IS
  'Point 13: where this section''s photo sits relative to its text — ''above'' (default) or ''below''. services/event_site.clean_image_position is the authority.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
SELECT 'event_site_sections.image_position' AS item,
       CASE WHEN EXISTS (SELECT 1 FROM information_schema.columns
         WHERE table_name = 'event_site_sections' AND column_name = 'image_position')
       THEN 'OK' ELSE 'MANQUANT' END AS status;
