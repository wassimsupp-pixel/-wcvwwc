-- ============================================================================
-- Migration 017 — Add/Update Source vs Replace Source (feedback §20)
-- ============================================================================
-- Run this in the Supabase SQL editor. It is idempotent (safe to re-run).
--
-- MAX receives a fresh FCM export every week, and the same person is in all
-- three. The engine already handles that correctly. What it could not express
-- is the difference between two intentions:
--
--   Add / Update Source  another file about the same event. Week 2 does not
--                        invalidate Week 1, and somebody who only ever appeared
--                        in Week 1 still has a real hotel booking.
--   Replace Source       a corrected version of a file already imported. Week 2
--                        IS Week 1, redone — keeping both means the master list
--                        is fed by a file somebody explicitly withdrew.
--
-- Superseding is reversible and NEVER deletes anybody. The old file stops
-- feeding the master list; its rows stay in source_records for the audit trail,
-- and any participant it was the only source for is NAMED rather than removed.
--
-- Without this migration everything behaves exactly as it does today: every
-- upload is additive, and the replace action reports itself unavailable.
-- ============================================================================

ALTER TABLE uploaded_files
  ADD COLUMN IF NOT EXISTS superseded_at TIMESTAMPTZ;

ALTER TABLE uploaded_files
  ADD COLUMN IF NOT EXISTS superseded_by UUID REFERENCES uploaded_files(id) ON DELETE SET NULL;

ALTER TABLE uploaded_files
  ADD COLUMN IF NOT EXISTS superseded_reason TEXT;

-- The consolidation loads live files per event on every run.
CREATE INDEX IF NOT EXISTS idx_uploaded_files_live
  ON uploaded_files(event_id, source_type)
  WHERE superseded_at IS NULL;

COMMENT ON COLUMN uploaded_files.superseded_at IS
  'Set when a later file replaces this one (feedback §20). A superseded file is skipped by consolidation but its source_records are kept: the master list stops hearing it, the audit trail does not lose it.';
COMMENT ON COLUMN uploaded_files.superseded_by IS
  'The file that replaced this one. NULL means this file is live.';


-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
-- Expect three rows.
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_name = 'uploaded_files'
  AND column_name IN ('superseded_at', 'superseded_by', 'superseded_reason')
ORDER BY column_name;
